# EZ-Trac Workflows

## Fargate App Name
  `eztrac-workflows`

## Description
  React/redux UI around handling workflows with multiple dependencies.
  Contains an add person workflow and deactivate person workflows
  Add person adds a person to the costing engine DB and chosen efforts in core
  Deactivate person deactivates them, updates their efforts, and saves a reason in QC for under allocation.

## Dependencies
  * ez-trac-core-services
  * ez-trac-qc
  * ez-trac-costing-sevices
  * ez-trac-suggestion

## Tech Debt
  * Some code duplication throughout, not very well tested in some of the sagas.
  * Needs to handle more corner cases, especially in adding.
  * Currently doesn't work to let you manually continue if it fails to call suggestion when adding person.
  
## Kibana logging
  This app has requests logged in a way that kibana can pick them up through the syslog drain.
  
  * [Non Prod Logs][kibana-nonprod]

  * [Prod Logs][kibana-prod]
 


[kibana-nonprod]: https://awskibana.velocity.ag/_plugin/kibana/#/discover?_g=()&_a=(columns:!(_source),index:%5Bcf_app-%5DYYYY.MM.DD,interval:auto,query:(query_string:(analyze_wildcard:!t,query:'app:%22ez-trac-workflows%22%20AND%20NonProd')),sort:!('@timestamp',desc))
[kibana-prod]: https://awskibana.velocity.ag/_plugin/kibana/#/discover?_g=()&_a=(columns:!(_source),index:%5Bcf_app-%5DYYYY.MM.DD,interval:auto,query:(query_string:(analyze_wildcard:!t,query:'app:%22ez-trac-workflows%22%20AND%20Prod')),sort:!('@timestamp',desc))


## Local Ocelot:
Local ocelot configuration is defined in `.ocelot.json` file in the project root.

### Symlink
You can keep your route configuration in sync with the repo with a symlink.

If you have your ocelot configuration under `~/.ocelot` and your routes stored
under `~/.routes`, you can symlink
the routefile to your ocelot route directory with the following:

```
ln -s "$PWD/.ocelot.json" ~/.ocelot/routes/ez-trac-workflow.json
```