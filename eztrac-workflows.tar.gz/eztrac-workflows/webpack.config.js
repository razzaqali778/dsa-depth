const webpack = require('webpack')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
const LightningExpressPlugin = require('./LightningExpressPlugin')

const path = `${__dirname}/public/scripts/`

module.exports = {
  mode: 'production',
  devtool: false,
  entry: [
    './src/client/styles/style.scss',
    './src/client',
  ],
  module: {
    rules: [
      { test: /\.m?js$/, resolve: { fullySpecified: false } },
      { test: /\.jsx?$/, use: 'babel-loader', exclude: /node_modules/ },
      {
        test: /\.s?css$/,
        use: [MiniCssExtractPlugin.loader, 'css-loader', 'sass-loader'],
      },
    ],
  },
  output: {
    filename: 'bundle.js',
    path,
    publicPath: '/ez-trac-workflows/scripts/',
  },
  plugins: [
    new LightningExpressPlugin(),
    new MiniCssExtractPlugin({
      filename: '../styles/style.css',
    }),
  ],
  resolve: {
    extensions: [
      '.js',
      '.json',
      '.jsx',
    ],
  },
}
