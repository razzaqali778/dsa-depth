const packageJson = require('./package.json')

const config = {
    projectId: 'a78af89b-8576-4669-8b6f-51db445f1209',
    projectName: packageJson.name,
    contextRoot: 'ez-trac-workflows',
    team: 'WORKFORCE-DEV-ADMINS',
    pipelineClientId: 'fc5e8fa2-cae2-4b2b-a958-da09257cc72c',
    deployableVersion: packageJson.version,
    quiet: true,
}
module.exports = config
