# eztrac-workflows — Node 22 / Toolchain Upgrade

This document summarizes the Node 22 upgrade and vulnerability remediation for `eztrac-workflows`. It is intended for reviewers, deployers, and anyone running the app locally via `eztrac-local-setup`.

**App version:** `1.1.50` (unchanged in `package.json`)  
**Target Node:** `22.x` (was `^18`)

---

## Executive summary

The upgrade modernizes the JavaScript toolchain for this Express + React/Webpack UI while keeping **React 16** and **Material UI beta** (no MUI 5 migration in this pass):

| Area | Before | After |
|------|--------|-------|
| Node | ^18 | **22.x** |
| Babel | 6.x | **7.x** (`@babel/preset-env` + `preset-react`, `core-js` 3) |
| Webpack | 4.x | **5.x** |
| Jest | 20.x | **29.x** |
| ESLint | 3.x + `eslint-plugin-wyze` | **8.x** (Airbnb 19, wyze removed) |
| Dev reload | `piping` | **Removed** |
| Polyfills | `babel-polyfill` | **`core-js` 3** via `useBuiltIns: "usage"` |
| OpenSSL flag | `--openssl-legacy-provider` | **Removed** (Webpack 5 + OpenSSL 3) |
| Lockfile | `package-lock.json` committed | **Removed** (`preinstall` + `legacy-peer-deps`) |
| `xlsx` | npm `~0.18.5` | **SheetJS CDN `0.20.3`** |
| `superagent` | 4.1.0 | **^10.2.2** |

`npm audit` reports **0 vulnerabilities** after overrides.

---

## Files changed

### Configuration & build

| File | Change |
|------|--------|
| `package.json` | engines `22.x`, Babel/Jest/ESLint/Webpack upgrades, `overrides`, `preinstall` |
| `package-lock.json` | **Deleted** |
| `.babelrc` | Babel 7 + `core-js` usage; `env.test` → `node: "current"` |
| `.npmrc` | `legacy-peer-deps=true` |
| `.eslintrc` | ESLint 8 / Airbnb 19; `@babel/eslint-parser`; removed wyze + webpack resolver |
| `test/.eslintrc` | Removed wyze rule |
| `webpack.config.js` / `webpack.dev.config.js` | Webpack 5 `rules`/`use`; drop polyfill entry & `OccurrenceOrderPlugin` |
| `LightningExpressPlugin.js` | `compilation.emitAsset` + `webpack.sources.RawSource` |
| `.github/workflows/{np-deploy,prepare,release,temp-release}-le.yml` | Default `node_version` → `22.15.0` |

### Application runtime

| File | Change |
|------|--------|
| `app.js` | `@babel/register`; removed `babel-polyfill` and `piping` |
| `src/server/index.js` | CommonJS webpack.dev config; drop `noInfo` for webpack-dev-middleware v6 |
| Lint-only source fixes | `LOCKDOWN` constant, max-len wraps, EffortHeader destructuring, etc. |

### Local setup (`eztrac-notes/eztrac-local-setup`)

| File | Change |
|------|--------|
| `compose.yaml` | `workflows` `NODE_VERSION: "22"`; drop `openssl-legacy-provider` |
| `scripts/install.sh` | `eztrac-workflows\|22` |
| `scripts/lib.sh` | `workflows) echo 22` |
| `docs/diagrams.md` | workflows Node 22 |

---

## Detailed changes by area

### 1. Node.js 18 → 22

```json
"engines": { "node": "22.x" }
```

- Local: `nvm use 22` before `npm install` / `npm run dev`
- CI defaults to `22.15.0`
- Compose / host install use Node 22 for workflows

`@bayerit/config` / phoenix packages may log `EBADENGINE` (they declare `^20` or `<21`); installs and runtime work on Node 22 (same pattern as QC/cron).

### 2. Babel 6 → 7 / Webpack 4 → 5

**Removed:** Babel 6 stack, `babel-polyfill`, `piping`, `react-hot-loader`, `eslint-plugin-wyze`

**Added:** `@babel/*` 7.x, `core-js` 3, `babel-loader` 9, Webpack 5 + matching css/sass loaders

Production packaging still uses `LightningExpressPlugin` (writes `.env`, service-bindings, deployable-version). That path calls `config.init()` and needs working Vault/AWS SSO credentials.

### 3. Jest 20 → 29 / ESLint 3 → 8

- Jest 29 + `babel-jest` + `jest-environment-jsdom` (phoenix/`window` setup)
- ESLint 8 + Airbnb 19; node import resolver (webpack resolver broke on MiniCssExtractPlugin/ajv)

### 4. Dependencies & vulnerabilities

**Bumped:** `express` ~4.22, `lodash` ~4.18, `superagent` ^10.2.2, `cross-env` ~7, `dotenv` ~16

**Overrides:** `uuid` ^11.1.1, `js-yaml`, `brace-expansion`, `follow-redirects`, nested `@bayerit/*` lodash/joi/AWS SDK pins, etc.

**xlsx:** switched from vulnerable npm `0.18.x` to SheetJS CDN build `https://cdn.sheetjs.com/xlsx-0.20.3/xlsx-0.20.3.tgz`

Do **not** run `npm audit fix --force`.

```bash
rm -rf node_modules
npm install
npm audit   # expect 0 vulnerabilities
```

---

## Verification

```bash
nvm use 22
npm install
npm run lint
npm run test:only
# Client bundle smoke (no Vault):
NODE_ENV=production npx webpack --mode production --config webpack.dev.config.js
npm audit              # expect 0 vulnerabilities
```

Full `npm run build` / `*:package` requires Vault + AWS SSO (`aws sso login`) for `LightningExpressPlugin`.

Local compose: rebuild the `workflows` service so it picks up Node 22, then open the workflows route via Ocelot.

---

## Residual / follow-ups

- Material UI `1.0.0-beta` kept intentionally; migrate to `@mui/material` separately
- React 16 kept; upgrade React separately if needed
- `@bayerit/phoenix-navbar` engines still exclude Node 22 (`EBADENGINE` warning only)
- Production pack depends on Vault/AWS credentials (unchanged operational requirement)
