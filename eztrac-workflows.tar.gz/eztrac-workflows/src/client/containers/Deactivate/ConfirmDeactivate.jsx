import { connect } from 'react-redux'
import React from 'react'
import { getNewEffortsTotal } from '../../redux/selectors/common/getEffortTotals'
import DeactivateResultsBox from './DeactivateResultsBox'
import NavButtons from '../Common/NavButtons'
import getPersonName from '../../redux/selectors/common/getPersonName'


// TODO: Tell them that they will be removed from efforts for the current and next month

const ConfirmDeactivate = ({
  newEffortsTotal,
  selectedPerson,
  selectedReason,
  personName,
}) => (
  <div>
    <p>
      You have selected:
      <b>
        { personName }
        {' '}
        (
        { selectedPerson }
        )
        {' '}
      </b>
      with the reason:
      {' '}
      <b>{ selectedReason }</b>
      {' '}
      for deactivation.
    </p>
    <p>
      Their efforts will be updated to a total of
      {newEffortsTotal}
      %
    </p>
    <p>Is this correct?</p>
    <NavButtons />
    <DeactivateResultsBox />
  </div>
)

const mapStateToProps = state => ({
  activeStep: state.step,
  newEffortsTotal: getNewEffortsTotal(state),
  selectedPerson: state.deactivateSelections.selectedPerson,
  selectedReason: state.deactivateSelections.selectedReason,
  personName: getPersonName(state),
})

export default connect(mapStateToProps, {})(ConfirmDeactivate)
