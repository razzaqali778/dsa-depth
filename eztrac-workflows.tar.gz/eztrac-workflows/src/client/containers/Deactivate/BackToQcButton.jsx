import { Button, CircularProgress } from 'material-ui'
import React, { useState } from 'react'
import superagent from 'superagent'
import { serviceBindings } from '../../redux/sagas/helpers/getServiceBindings'
import BackToQcWarningModal from './BackToQcWarningModal'

const qcUi = window.phoenix.urls.ui['ez-trac-qc']
const backLink = `${qcUi}`

const fetchPersonStatus = async personId => {
  const response = await superagent
    .get(`${serviceBindings.costingServices}/v1/person/${personId}`)
    .set(phoenix.authHeader && phoenix.authHeader()) // eslint-disable-line

  return response.body.isActive
}

const BackToQcButton = ({ selectedPersonId, previousSite }) => {
  const [ showModal, setShowModal ] = useState(false)
  const [ fetchingPersonStatus, setFetchingPersonStatus ] = useState(false)

  const handleBackButtonClick = async () => {
    setFetchingPersonStatus(true)
    const isUserActive = await fetchPersonStatus(selectedPersonId)
    if ( isUserActive ) {
      setFetchingPersonStatus(false)
      setShowModal(true)
    } else {
      window.location.href = `${backLink}/${previousSite}`
    }
  }

  return (
    <div>
      <Button
        disabled={fetchingPersonStatus}
        onClick={handleBackButtonClick}
        size="small"
        style={{
          marginTop: '10px',
        }}
        variant="raised"
      >
        Back to
        {' '}
        {previousSite}
        {' '}
        QC
        {fetchingPersonStatus && <CircularProgress className="button-progress-indicator" size={20} />}
      </Button>
      {showModal && (
      <BackToQcWarningModal
        closeModal={() => setShowModal(false)}
        path={`${backLink}/${previousSite}`}
        show={showModal}
      />
      )}
    </div>
  )
}

export default BackToQcButton
