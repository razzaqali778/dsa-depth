import { connect } from 'react-redux'
import React from 'react'
import Select from 'react-select'
import { deactivateSelections as deactivateSelectionActions, stepper as stepperActions } from '../../redux/actions'
import { isReasonSelected } from '../../redux/selectors/common/stepperValidations'
import NavButtons from '../Common/NavButtons'
import getReasonSelectOptions from '../../redux/selectors/deactivate/getReasonSelectOptions'
import getSelectedReasonObject from '../../redux/selectors/common/getSelectedReasonObject'

const ReasonSelect = ({
  setSelectedReason,
  selectedReason,
  isReasonSelectedProp,
  reasonSelectOptions,
}) => (
  <div>
    <Select
      className="column select-box"
      name="reason-select"
      onChange={setSelectedReason}
      options={reasonSelectOptions}
      placeholder="Select Reason"
      value={selectedReason}
    />
    <NavButtons isNextDisabled={!isReasonSelectedProp} />
  </div>
)

const mapStateToProps = state => ({
  selectedReason: getSelectedReasonObject(state),
  activeStep: state.stepper,
  isReasonSelectedProp: isReasonSelected(state),
  reasonSelectOptions: getReasonSelectOptions(state),
})

export default connect(mapStateToProps, { ...deactivateSelectionActions, ...stepperActions })(ReasonSelect)
