import { connect } from 'react-redux'
import Divider from 'material-ui/Divider'
import React from 'react'
import keys from 'lodash/keys'
import ResultCard from '../../components/ResultCard'

const messageMap = {
  deactivate: 'Deactivating person.',
  efforts: 'Updating effort(s).',
  reason: 'Saving reason.',
}

const DeactivateResultsBox = ({
  errorResults,
}) => (
  <div>
    { errorResults ? (
      <div className="columns">
        { keys(errorResults).map( key => (
          <div className="column" key={`err-${key}`}>
            <ResultCard
              hasError={errorResults[key].hasError}
              header={messageMap[key]}
              message={errorResults[key].message}
            />
            <Divider />
          </div>
        ))}
      </div>
    ) : null}
  </div>
)


const mapStateToProps = state => ({
  errorResults: state.deactivateSelections.deactivationResults,
})

export default connect(mapStateToProps, {})(DeactivateResultsBox)
