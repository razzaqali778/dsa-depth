import { Button, Modal } from 'react-bootstrap'
import React from 'react'

const BackToQcWarning = ({ closeModal, path, show }) => (
  <div>
    <Modal onHide={closeModal} show={show}>
      <Modal.Header closeButton>
        <Modal.Title>No changes made</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        Return to QC without deactivating the user?
        <br />
      </Modal.Body>
      <Modal.Footer>
        <a className="btn btn-primary" href={path}>OK</a>
        <Button onClick={closeModal}>Cancel</Button>
      </Modal.Footer>
    </Modal>
  </div>
)
export default BackToQcWarning
