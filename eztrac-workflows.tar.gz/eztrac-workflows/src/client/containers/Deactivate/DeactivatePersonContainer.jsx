import { connect } from 'react-redux'
import Paper from 'material-ui/Paper'
import React from 'react'
import Stepper, {
  Step,
  StepLabel,
} from 'material-ui/Stepper'
import { deactivateSelections as deactivateSelectionActions, stepper as stepperActions } from '../../redux/actions'
import { getPreviousSite, getSelectedPerson } from '../../redux/selectors'
import BackToQcButton from './BackToQcButton'
import RenderContent from './DeactivateStepperContent'

const DeactivatePersonContainer = ({
  activeStep,
  selectedPerson,
  previousSite,
}) => (
  <div className="workflow-container">
    <Paper elevation={3} style={{ height: '100%' }}>
      <div className="paper-contents">
        <h2 className="paper-title">Deactivate Person</h2>
        <Stepper
          activeStep={activeStep}
          style={{
            display: 'inline-flex',
            marginLeft: '20px',
            width: '60%',
          }}
        >
          <Step>
            <StepLabel>
              Select Person
            </StepLabel>
          </Step>
          <Step>
            <StepLabel>
              Select Reason
            </StepLabel>
          </Step>
          <Step>
            <StepLabel>
              Update Efforts
            </StepLabel>
          </Step>
          <Step>
            <StepLabel>
              Confirm
            </StepLabel>
          </Step>
        </Stepper>
        <RenderContent />
        { previousSite && <BackToQcButton previousSite={previousSite} selectedPersonId={selectedPerson} /> }
      </div>
    </Paper>
  </div>
)

const mapStateToProps = state => ({
  activeStep: state.stepper,
  selectedPerson: getSelectedPerson(state),
  previousSite: getPreviousSite(state),
})

export default connect(mapStateToProps, { ...deactivateSelectionActions, ...stepperActions })(DeactivatePersonContainer)
