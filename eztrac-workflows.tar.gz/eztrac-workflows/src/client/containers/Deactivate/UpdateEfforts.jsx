import { connect } from 'react-redux'
import Moment from 'moment'
import React from 'react'
import TextField from 'material-ui/TextField'
import {
  deactivateSelections as deactivateSelectionActions,
  efforts as effortsActions,
  stepper as stepperActions,
} from '../../redux/actions'
import { getCurrentTimeframe, getEndDate } from '../../redux/selectors'
import { getOriginalEffortsTotal } from '../../redux/selectors/common/getEffortTotals'
import { singleEffortValidation, totalEffortValidation } from '../../redux/selectors/common/effortValidations'
import EffortTable from '../Common/EffortTable'
import NavButtons from '../Common/NavButtons'
import getPersonName from '../../redux/selectors/common/getPersonName'

const UpdateEfforts = ({
  currentTimeframe,
  endDate,
  isPercentValid,
  originalTotal,
  personName,
  setEndDate,
}) => (
  <div className="columns">
    <div className="column is-4">
      <h4>{personName}</h4>
      {(originalTotal === 100) && (
      <TextField
        defaultValue={new Moment(endDate).format('YYYY-MM-DD')}
        inputProps={{
          min: new Moment(currentTimeframe.startDate).add(1, 'days').format('YYYY-MM-DD'),
          max: new Moment(currentTimeframe.endDate).format('YYYY-MM-DD'),
        }}
        label="Employee End Date"
        mode="landscape"
        onChange={evt => setEndDate(evt.target.value)}
        style={{ width: 200 }}
        type="date"
      />
      ) }
      <NavButtons isNextDisabled={!isPercentValid} />
    </div>
    <div className="column">
      <EffortTable />
    </div>
  </div>
)

const mapStateToProps = state => ({
  efforts: state.efforts,
  activeStep: state.stepper,
  selectedPerson: state.deactivateSelections.selectedPerson,
  isPercentValid: singleEffortValidation(state) && totalEffortValidation(state),
  endDate: getEndDate(state),
  currentTimeframe: getCurrentTimeframe(state),
  originalTotal: getOriginalEffortsTotal(state),
  personName: getPersonName(state),
})

export default connect(mapStateToProps, {
  ...effortsActions,
  ...stepperActions,
  ...deactivateSelectionActions,
})(UpdateEfforts)
