import { connect } from 'react-redux'
import React from 'react'
import { stepper as stepperActions } from '../../redux/actions'
import ConfirmDeactivate from './ConfirmDeactivate'
import PersonSelect from '../Common/PersonSelect'
import ReasonSelect from './ReasonSelect'
import UpdateEfforts from './UpdateEfforts'

const RenderContent = ({
  activeStep,
}) => {
  switch ( activeStep ) {
    case 0: return <PersonSelect />
    case 1: return <ReasonSelect />
    case 2: return <UpdateEfforts />
    case 3: return <ConfirmDeactivate />
    default: return (<div />)
  }
}

const mapStateToProps = state => ({
  activeStep: state.stepper,
})

export default connect(mapStateToProps, { ...stepperActions })(RenderContent)
