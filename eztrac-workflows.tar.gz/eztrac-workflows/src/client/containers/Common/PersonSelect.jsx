import { connect } from 'react-redux'
import React from 'react'
import Select from 'react-select'
import { deactivateSelections as deactivateSelectionActions, stepper as stepperActions } from '../../redux/actions'
import { isPersonSelected } from '../../redux/selectors/common/stepperValidations'
import NavButtons from './NavButtons'
import getPeopleSelectOpts from '../../redux/selectors/common/getPeopleSelectOpts'
import getSelectedPersonObject from '../../redux/selectors/common/getSelectedPersonObject'

const RenderContent = ({
  peopleSelectOptions,
  setSelectedPerson,
  selectedPerson,
  isPersonSelectedProp,
}) => (
  <div>
    <Select
      className="column select-box"
      name="person-select"
      onChange={setSelectedPerson}
      options={peopleSelectOptions}
      placeholder="Select Person"
      value={selectedPerson}
    />
    <NavButtons isNextDisabled={!isPersonSelectedProp} />
  </div>
)

const mapStateToProps = state => ({
  peopleSelectOptions: getPeopleSelectOpts(state),
  selectedPerson: getSelectedPersonObject(state),
  activeStep: state.stepper,
  isPersonSelectedProp: isPersonSelected(state),
})

export default connect(mapStateToProps, { ...deactivateSelectionActions, ...stepperActions })(RenderContent)
