import { Button, Glyphicon } from 'react-bootstrap'
import { utils, write } from 'xlsx'
import FileSaver from 'file-saver'
import React from 'react'

const exportToCSV = (csvData, fileName) => {
  const date = new Date()
  const dateParts = [ date.getMonth() + 1, date.getDate(), date.getFullYear(), date.getHours(), date.getMinutes() ]
  const dateFileNamePart = `_${dateParts.join('_')}`

  const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
  const fileExtension = '.xlsx'

  const ws = utils.json_to_sheet(csvData)
  const wb = { Sheets: { data: ws }, SheetNames: [ 'data' ] }
  const excelBuffer = write(wb, { bookType: 'xlsx', type: 'array' })
  const data = new Blob([ excelBuffer ], { type: fileType }) // eslint-disable-line no-undef

  FileSaver.saveAs(data, fileName + dateFileNamePart + fileExtension)
}

const SaveToXlsxButton = ({ csvData, fileName }) => (
  <Button
    className="btn downloadCSVButton"
    color="default"
    onClick={() => exportToCSV(csvData, fileName)}
    title="Export to excel"
  >
    <Glyphicon glyph="download-alt" />
  </Button>
)

export default SaveToXlsxButton
