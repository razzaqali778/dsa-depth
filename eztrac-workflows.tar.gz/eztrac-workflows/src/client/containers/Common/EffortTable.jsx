import { connect } from 'react-redux'
import Divider from 'material-ui/Divider'
import Help from 'material-ui-icons/Help'
import Paper from 'material-ui/Paper'
import React from 'react'
import TextField from 'material-ui/TextField'
import isUndefined from 'lodash/isUndefined'
import { getNewEffortsTotal, getOriginalEffortsTotal } from '../../redux/selectors/common/getEffortTotals'
import { getCurrentEfforts } from '../../redux/selectors'
import { efforts as effortsActions } from '../../redux/actions'

const paperStyle = {
  padding: '15px 15px 15px 15px',
}

const dividerStyle = {
  margin: '5px 0px 15px 0px',
}

// TODO: Show next month's efforts

const EffortHeader = ({ originalEffortsTotal }) => (
  <div className="columns">
    <div className="column">
      <p>Team Name</p>
    </div>
    <div className="column is-4 align-right">
      Updated Participation
      <span
        data-balloon={originalEffortsTotal < 100
          ? 'Please enter new participation values below.'
          : 'Select an end date to autocalculate percentages or enter new values manually.'}
        data-balloon-pos="up"
      >
        <Help style={{
          fontSize: '14px', height: '14px', width: '14px', marginLeft: '5px',
        }}
        />
      </span>
    </div>
    <div className="column is-4 align-right">
      <p>Original Participation</p>
    </div>
  </div>
)

const TableRow = ({
  newPercent,
  teamName,
  teamId,
  originalValue,
  updatePercent,
  errorText,
}) => (
  <div className="columns">
    <div className="column">
      <p>{teamName}</p>
    </div>
    <div className="column is-4 align-right">
      <TextField
        error={!(isUndefined(errorText) || errorText === '')}
        helperText={errorText}
        helpertextclassname="error-text"
        id={`${teamName} Participation`}
        inputProps={{
          style: {
            textAlign: 'right',
            paddingRight: '4px',
            fontSize: '14px',
            height: 'auto',
          },
        }}
        onChange={evt => updatePercent({ teamId, newPercent: evt.target.value })}
        style={{
          width: '40%',
          marginTop: '-5px',
        }}
        value={newPercent}
      />
      %
    </div>
    <div className="column is-4 align-right">
      <p>{`${originalValue} %`}</p>
    </div>
  </div>
)

const TotalRow = ({
  newEffortsTotal,
  originalEffortsTotal,
}) => (
  <div className="columns">
    <div className="column">
      <p>Total</p>
    </div>
    <div className="column is-4 align-right">
      <p>
        { newEffortsTotal }
        {' '}
        %
      </p>
    </div>
    <div className="column is-4 align-right">
      <p>
        { originalEffortsTotal }
        {' '}
        %
      </p>
    </div>
  </div>
)

const EffortTable = ({
  currentEfforts,
  newEffortsTotal,
  originalEffortsTotal,
  updatePercent,
}) => (
  currentEfforts.length > 0 ? (
    <div className="effort-table">
      <Paper elevation={1} style={paperStyle}>
        <EffortHeader originalEffortsTotal={originalEffortsTotal} />
        <Divider style={dividerStyle} />
        {currentEfforts.map(({
          teamName, teamId, newPercent, percent, errorText,
        }) => (
          <TableRow
            errorText={errorText}
            key={teamId}
            newPercent={newPercent}
            originalValue={percent}
            teamId={teamId}
            teamName={teamName || teamId}
            updatePercent={updatePercent}
          />
        ))}
        <TotalRow
          efforts={currentEfforts}
          newEffortsTotal={newEffortsTotal}
          originalEffortsTotal={originalEffortsTotal}
        />
      </Paper>
    </div>
  ) : <p>This person has no efforts. Please continue. </p>

)

const mapStateToProps = state => ({
  currentEfforts: getCurrentEfforts(state),
  newEffortsTotal: getNewEffortsTotal(state),
  originalEffortsTotal: getOriginalEffortsTotal(state),
})

export default connect(mapStateToProps, { ...effortsActions })(EffortTable)
