import { connect } from 'react-redux'
import Button from 'material-ui/Button'
import React from 'react'
import isNull from 'lodash/isNull'
import ResetButton from './ResetButton'
import { deactivateSelections as deactivateSelectionActions, stepper as stepperActions } from '../../redux/actions'

const BackButton = ({
  activeStep,
  callResults,
  stepPrevious,
}) => activeStep > 0 ? (
  <Button
    className="button"
    disabled={!isNull(callResults)}
    onClick={stepPrevious}
    variant="raised"
  >
    Back
  </Button>
) : null

const NextButton = ({
  isNextDisabled,
  stepNext,
}) => (
  <Button
    className="button"
    color="primary"
    disabled={isNextDisabled}
    onClick={stepNext}
    style={{ cursor: isNextDisabled ? 'not-allowed' : 'pointer' }}
    variant="raised"
  >
    Next
  </Button>
)

const ConfirmButton = ({
  deactivatePerson,
  callResults,
}) => (
  <Button
    className="button"
    color="primary"
    disabled={!isNull(callResults)}
    onClick={deactivatePerson}
    variant="raised"
  >
    Okay
  </Button>
)

const LastButton = ({
  activeStep,
  isNextDisabled,
  stepNext,
  deactivatePerson,
  callResults,
  resetDeactivation,
}) => {
  if ( activeStep < 3 ) {
    return (<NextButton isNextDisabled={isNextDisabled} stepNext={stepNext} />)
  }

  return (
    <div style={{ display: 'inline' }}>
      <ConfirmButton callResults={callResults} deactivatePerson={deactivatePerson} />
      <ResetButton callResults={callResults} resetDeactivation={resetDeactivation} />
    </div>
  )
}

const NavButtons = ({
  deactivatePerson,
  isNextDisabled,
  activeStep,
  resetDeactivation,
  stepNext,
  stepPrevious,
  callResults,
}) => (
  <div>
    <BackButton activeStep={activeStep} callResults={callResults} stepPrevious={stepPrevious} />
    <LastButton
      activeStep={activeStep}
      callResults={callResults}
      deactivatePerson={deactivatePerson}
      isNextDisabled={isNextDisabled}
      resetDeactivation={resetDeactivation}
      stepNext={stepNext}
    />
  </div>
)

const mapStateToProps = state => ({
  isPersonSelectedProp: state.isPersonSelected,
  activeStep: state.stepper,
  callResults: state.deactivateSelections.deactivationResults,
})

export default connect(mapStateToProps, { ...stepperActions, ...deactivateSelectionActions })(NavButtons)
