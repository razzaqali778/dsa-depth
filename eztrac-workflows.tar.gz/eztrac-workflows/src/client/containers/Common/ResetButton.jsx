import { connect } from 'react-redux'
import Button from 'material-ui/Button'
import React from 'react'
import isNull from 'lodash/isNull'
import {
  deactivateSelections as deactivateSelectionActions,
  resetWorkflow as resetWorkflowActions,
  stepper as stepperActions,
} from '../../redux/actions'

const ResetButton = ({
  resetStepper,
  callResults,
}) => (
  <Button
    className="button"
    color="primary"
    disabled={isNull(callResults)}
    onClick={resetStepper}
    variant="raised"
  >
    Next Person
  </Button>
)

const mapStateToProps = state => ({
  isPersonSelectedProp: state.isPersonSelected,
})

export default connect(
  mapStateToProps,
  { ...stepperActions, ...deactivateSelectionActions, ...resetWorkflowActions },
)(ResetButton)
