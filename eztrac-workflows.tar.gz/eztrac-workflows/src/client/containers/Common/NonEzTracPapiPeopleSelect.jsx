import { connect } from 'react-redux'
import React from 'react'
import Select from 'react-select'
import debounce from 'lodash/debounce'
import isEmpty from 'lodash/isEmpty'
import NavButtons from './NavButtons'
import { addSelections as addSelectionsActions, people as peopleActions } from '../../redux/actions'


const RenderContent = ({
  fetchPersonSuggestion,
  selectedPerson,
  setPapiSearchText,
  papiPeople,
}) => (
  <div>
    <Select
      className="column select-box"
      clearable={false}
      multi={false}
      name="person-select"
      onChange={fetchPersonSuggestion}
      onInputChange={debounce(setPapiSearchText, 200)}
      options={papiPeople}
      placeholder="Select Person"
      value={selectedPerson}
    />
    <NavButtons isNextDisabled={isEmpty(selectedPerson) || !selectedPerson.id} />
  </div>
)

const mapStateToProps = state => ({
  activeStep: state.stepper,
  selectedPerson: state.addSelections.selectedPerson,
  papiPeople: state.people.papiPeople,
})

export default connect(mapStateToProps, { ...peopleActions, ...addSelectionsActions })(RenderContent)
