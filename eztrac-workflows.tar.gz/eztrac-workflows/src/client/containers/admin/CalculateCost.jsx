import { CircularProgress } from 'material-ui'
import Button from 'material-ui/Button'
import Paper from 'material-ui/Paper'
import React, { useState } from 'react'
import { recalculateCostsAction } from '../../actions/admin/recalculateCostsAction'

function CalculateCost() {
  const [ error, setError ] = useState('')
  const [ loading, setLoading ] = useState(false)

  const recalculate = async () => {
    setLoading(true)
    const result = await recalculateCostsAction()
    if ( result.status ) {
      setError('')
    } else {
      console.error( // eslint-disable-line no-console
        `Error recalculating at step ${result.step} with message ${result.error}`,
      )
      setError(`Error recalculating the costs at step ${result.step}. Please try again and if that doesn't work,
                        please contact us in the #eztrac teams channel
                        with this message for assistance.\n ${result.error}`)
    }
    setLoading(false)
  }

  return (
    <div className="workflow-container">
      <Paper elevation={3}>
        <div className="admin-actions-paper">
          <div>Recalculate team engagement costs</div>
          <div style={{ marginTop: '15px' }}>
            <Button
              className="button"
              disabled={loading}
              onClick={async () => recalculate()}
              variant="raised"
            >
              Recalculate
              {loading && (
                <CircularProgress
                  className="button-progress-indicator"
                  size={20}
                />
              )}
            </Button>
            {error && <div className="admin-actions-error">{error}</div>}
          </div>
        </div>
      </Paper>
    </div>
  )
}

export default CalculateCost
