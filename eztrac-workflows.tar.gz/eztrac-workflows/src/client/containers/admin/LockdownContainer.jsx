import { connect } from 'react-redux'
import Paper from 'material-ui/Paper'
import React, { useCallback, useEffect, useState } from 'react'
import Switch from 'material-ui/Switch'
import superagent from 'superagent'
import { serviceBindings } from '../../redux/sagas/helpers/getServiceBindings'
import { lockdownAction } from '../../actions/admin/lockdownAction'

function LockdownContainer() {
  const [ lockdownError, setError ] = useState('')
  const [ locked, setLocked ] = useState(false)
  const [ currentTimeframe, setCurrentTimeframe ] = useState({})
  const [ loading, setLoading ] = useState(false)
  const [ loadingTimeFrames, setLoadingTimeFrame ] = useState(true)

  useEffect(() => {
    superagent
      .get(`${serviceBindings.coreServices}/v2/timeframes/current`)
      .set(phoenix.authHeader && phoenix.authHeader()) // eslint-disable-line
      .then(resp => {
        const timeframe = resp.body
        setCurrentTimeframe(timeframe)
        if ( timeframe.lockdown ) {
          setLocked(timeframe.lockdown)
        }
        setLoadingTimeFrame(false)
      })
  }, [ locked ])

  const toggleLocked = useCallback(
    async (id, lockdownStatus) => {
      setLoading(true)
      const result = await lockdownAction(lockdownStatus, id)
      if ( result.status ) {
        setLocked(lockdownStatus)
        setError('')
      } else {
        console.error(
          `Error locking down at step ${result.step} with message ${result.error}`,
        ) // eslint-disable-line no-console
        setError(`Error locking current timeframe at step ${result.step}. Try reloading the page, if that doesn't work,
                          please contact us in the #eztrac teams channel
                          with this message for assistance.\n ${result.error}`)
      }
      setLoading(false)
    },
    [ setLocked, setError, setLoading ],
  )

  return (
    <div className="workflow-container">
      <Paper elevation={3}>
        <div className="admin-actions-paper">
          {loadingTimeFrames ? (
            <div className="velocity-spinner-container">
              <i className="velocity-spinner-small-inline" />
              <span>Loading time frame lockdown section...</span>
            </div>
          ) : (
            <div>
              <div>
                Current timeframe
                {' '}
                {currentTimeframe.name}
                {' '}
                lockdown status
              </div>
              <div>
                <i
                  className="velocity-spinner-small-inline"
                  style={{ visibility: loading ? 'visible' : 'hidden' }}
                />
                <Switch
                  checked={locked}
                  disabled={loading}
                  inputProps={{ 'aria-label': 'controlled' }}
                  name="lockdownSwitch"
                  onChange={async () => toggleLocked(
                    currentTimeframe.id,
                    !locked,
                    setLocked,
                    setError,
                    setLoading,
                  )}
                  size="lg"
                />
                {locked
                  ? 'locked, toggle to unlock.'
                  : 'unlocked, toggle to lock.'}
                {lockdownError && (
                  <div className="admin-actions-error">{lockdownError}</div>
                )}
              </div>
            </div>
          )}
        </div>
      </Paper>
    </div>
  )
}

export default connect()(LockdownContainer)
