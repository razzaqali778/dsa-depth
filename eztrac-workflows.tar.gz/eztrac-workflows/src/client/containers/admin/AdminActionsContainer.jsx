import React from 'react'
import CalculateCost from './CalculateCost'
import LockdownContainer from './LockdownContainer'
import RunHealthCheck from './RunHealthCheck'

function AdminActionsContainer() {
  return (
    <div>
      <LockdownContainer />
      <CalculateCost />
      <RunHealthCheck />
    </div>
  )
}

export default AdminActionsContainer
