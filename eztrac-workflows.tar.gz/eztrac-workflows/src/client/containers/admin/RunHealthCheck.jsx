import { connect } from 'react-redux'
import Paper from 'material-ui/Paper'
import React, { useEffect, useState } from 'react'
import Select from 'react-select'
import isEmpty from 'lodash/isEmpty'
import { renderDownloadButton } from '../../utils/runHealthCheckUtils'
import { healthCheck as healthCheckActions } from '../../redux/actions'
import { getCurrentTimeframe, getHealthCheck } from '../../redux/selectors'

function RunHealthCheck({
  allTimeframes,
  currentTimeframeData,
  setHealthCheckTimeframe,
  selectedHealthCheckData,
}) {
  const [ timeframeOptions, setTimeframeOptions ] = useState([])
  const [ selectedTimeframe, setSelectedTimeframe ] = useState({})
  const [ loading, setLoading ] = useState(true)

  useEffect(() => {
    setLoading(true)
    const currentTimeframe = {
      ...currentTimeframeData,
      label: currentTimeframeData.name,
    }
    if ( !isEmpty(allTimeframes) ) {
      const options = allTimeframes.filter(
        timeframe => timeframe.id >= currentTimeframe.id,
      )
      const optionsWithLabel = options.map(tf => ({ ...tf, label: tf.name }))
      setTimeframeOptions(optionsWithLabel)
      setLoading(false)
    }
    if ( !isEmpty(currentTimeframe) && currentTimeframe.label !== undefined ) {
      setSelectedTimeframe(currentTimeframe)
      setHealthCheckTimeframe(currentTimeframe.id)
    }
  }, [ allTimeframes, currentTimeframeData ])

  const onSelect = value => {
    if ( value !== selectedTimeframe ) {
      setSelectedTimeframe(value)
      setHealthCheckTimeframe(value.id)
    }
  }

  const renderHealthCheckSection = () => {
    if ( !isEmpty(selectedTimeframe) ) {
      return (
        <div>
          <div>Run health check</div>
          <p>
            Click the button to download the health check for the chosen
            timeframe.
          </p>
          <div className="health-check-flexbox">
            <div>
              <Select
                className="health-check-time-frame"
                clearable={false}
                defaultValue={timeframeOptions[0]}
                name="time-frame-select"
                onChange={onSelect}
                options={timeframeOptions}
                placeholder="Select Time Frame"
                value={selectedTimeframe}
              />
            </div>
            {renderDownloadButton(selectedTimeframe, selectedHealthCheckData)}
          </div>
        </div>
      )
    }

    return (
      <div>
        <div>Run health check</div>
        <p>No selected timeframe. Please choose from the dropdown below. </p>
        <div className="health-check-flexbox">
          <div>
            <Select
              className="health-check-time-frame"
              clearable={false}
              name="time-frame-select"
              onChange={onSelect}
              options={timeframeOptions}
              placeholder="Select Time Frame"
            />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="workflow-container">
      <Paper elevation={3} style={{ height: '100%' }}>
        <div className="admin-actions-paper">
          {loading ? (
            <div className="velocity-spinner-container">
              <i className="velocity-spinner-small-inline" />
              <span>Loading Health Check section...</span>
            </div>
          ) : (
            renderHealthCheckSection()
          )}
        </div>
      </Paper>
    </div>
  )
}

const mapStateToProps = state => ({
  currentTimeframeData: getCurrentTimeframe(state),
  allTimeframes: state.timeframes.allTimeframes,
  selectedHealthCheckData: getHealthCheck(state),
})

export default connect(mapStateToProps, { ...healthCheckActions })(
  RunHealthCheck,
)
