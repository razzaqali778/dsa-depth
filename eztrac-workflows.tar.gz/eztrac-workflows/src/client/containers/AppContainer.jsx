import { MuiThemeProvider, createMuiTheme } from 'material-ui/styles'
import { connect } from 'react-redux'
import React from 'react'
import LoadingBlocker from '../components/LoadingBlocker'
import RenderRoute from '../routes'
import getIsLoading from '../redux/selectors/common/getIsLoading'

const velocityPrimary = '#2980b9'
const velocityDefault = '#5f7481'
const velocityDanger = '#c0392b'

const velocityTheme = {
  fontFamily: 'Open Sans,sans-serif',
  palette: {
    primary: {
      main: velocityPrimary,
    },
    secondary: {
      main: velocityDefault,
    },
    error: {
      main: velocityDanger,
    },
  },
  raisedButton: {
    textColor: '#333',
    color: '#ecf0f1',
    disabledColor: '#f3f5f6',
  },
  textField: {
    floatingLabelColor: '#000000',
  },
  card: {
    titleColor: '#FFF',
  },
  typography: {
    htmlFontSize: 10, // velocity style sheets set <html> font size to 10, mui calculates all sizes based on 14 by default
  },
}

const theme = createMuiTheme(velocityTheme)

const AppContainer = ({
  page,
  isLoading,
}) => (
  <div>
    <div>
      <MuiThemeProvider theme={theme}>
        <div>
          <LoadingBlocker isLoading={isLoading} />
          <RenderRoute page={page} />
        </div>
      </MuiThemeProvider>
    </div>
  </div>
)

const mapStateToProps = state => ({
  page: state.page,
  isLoading: getIsLoading(state),
})

export default connect(mapStateToProps, {})(AppContainer)
