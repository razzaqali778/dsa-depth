import { connect } from 'react-redux'
import React from 'react'
import { stepper as stepperActions } from '../../redux/actions'
import AddPersonConfirmAll from './AddPersonConfirmAll'
import AddPersonEfforts from './AddPersonEfforts'
import ConfirmAddPerson from './ConfirmAddPerson'
import NonEzTracPapiPeopleSelect from '../Common/NonEzTracPapiPeopleSelect'

const RenderContent = ({
  activeStep,
}) => {
  switch ( activeStep ) {
    case 0: return <NonEzTracPapiPeopleSelect />
    case 1: return <ConfirmAddPerson />
    case 2: return <AddPersonEfforts />
    case 3: return <AddPersonConfirmAll />
    default: return (<div />)
  }
}

const mapStateToProps = state => ({
  activeStep: state.stepper,
})

export default connect(mapStateToProps, { ...stepperActions })(RenderContent)
