import { connect } from 'react-redux'
import Paper from 'material-ui/Paper' // { DropDownMenu,  MenuItem,  Paper }
import React from 'react'
import Select from 'react-select'
import isEmpty from 'lodash/isEmpty'
import NavButtons from './NavButtonsForAddPerson'
import AddedResultsBox from './AddedResultsBox'
import { addSelections as addSelectionsActions, costGroupsRates as costGroupsRatesActions } from '../../redux/actions'

// TODO these are redeclarted in EffortTable
const paperStyle = {
  padding: '15px 15px 15px 15px',
}

const personRow = (key, value) => (
  <div className="columns">
    <div className="column">
      {key}
    </div>
    <div className="column">
      {value}
    </div>
  </div>
)

const DropDownRate = ({
  rateData,
  selectedRate,
  setSelectedRate,
}) => (
  <div className="columns">
    <div className="column">
      Rate
    </div>
    <Select
      className="column select-box"
      clearable={false}
      multi={false}
      name="costGroup-select"
      onChange={setSelectedRate}
      options={rateData}
      value={selectedRate}
    />
  </div>
)

const DropDownCostGroup = ({
  costGroupData,
  selectedCostGroup,
  setSelectedCostGroup,
}) => (
  <div className="columns">
    <div className="column">
      CostGroup
    </div>
    <Select
      className="column select-box"
      clearable={false}
      multi={false}
      name="costGroup-select"
      onChange={setSelectedCostGroup}
      options={costGroupData}
      value={selectedCostGroup}
    />
  </div>
)

const ConfirmAddPerson = ({
  costGroupData,
  rateData,
  selectedPerson,
  selectedCostGroup,
  selectedRate,
  setSelectedCostGroup,
  setSelectedRate,
}) => (
  <div>
    <div className="columns">
      <div className="column">
        <p>
          You are about to add
          <b>{selectedPerson.label}</b>
          {' '}
          to Ez-Trac.
        </p>
        <p>Is this correct?</p>
      </div>
      <div className="column">
        <Paper style={paperStyle}>
          {personRow('ID', selectedPerson.value)}
          {personRow('Name', selectedPerson.fullName)}
          {personRow('Employee Type', selectedPerson.employeeType)}

          <DropDownRate
            rateData={rateData}
            selectedPerson={selectedPerson}
            selectedRate={selectedRate}
            setSelectedRate={setSelectedRate}
          />
          <DropDownCostGroup
            costGroupData={costGroupData}
            selectedCostGroup={selectedCostGroup}
            selectedPerson={selectedPerson}
            setSelectedCostGroup={setSelectedCostGroup}
          />

        </Paper>
      </div>
    </div>
    <NavButtons isNextDisabled={isEmpty(selectedCostGroup) || isEmpty(selectedRate)} />
    <AddedResultsBox />
  </div>
)

const mapStateToProps = state => ({
  activeStep: state.stepper,
  selectedPerson: state.addSelections.selectedPerson,
  costGroupData: state.costGroupsRates.costGroupData,
  rateData: state.costGroupsRates.rateData,
  selectedCostGroup: state.costGroupsRates.selectedCostGroup,
  selectedRate: state.costGroupsRates.selectedRate,
})

export default connect(mapStateToProps, { ...addSelectionsActions, ...costGroupsRatesActions })(ConfirmAddPerson)
