import { connect } from 'react-redux'
import Paper from 'material-ui/Paper'
import React from 'react'
import Stepper, {
  Step,
  StepLabel,
} from 'material-ui/Stepper'
import RenderContent from './AddPersonStepperContent'
import { stepper as stepperActions } from '../../redux/actions'


const AddPersonContainer = ({
  activeStep,
}) => (
  <div className="workflow-container">
    <Paper elevation={3} style={{ height: '100%' }}>
      <div className="paper-contents">
        <h2 className="paper-title">Add Person</h2>
        <Stepper
          activeStep={activeStep}
          style={{
            display: 'inline-flex',
            marginLeft: '20px',
            width: '60%',
          }}
        >
          <Step>
            <StepLabel>
              Select Person
            </StepLabel>
          </Step>
          <Step>
            <StepLabel>
              Validate Attributes
            </StepLabel>
          </Step>
          <Step>
            <StepLabel>
              Add Efforts
            </StepLabel>
          </Step>
          <Step>
            <StepLabel>
              Confirm
            </StepLabel>
          </Step>
        </Stepper>
        <RenderContent />
      </div>
    </Paper>
  </div>
)

const mapStateToProps = state => ({
  activeStep: state.stepper,
})

export default connect(mapStateToProps, { ...stepperActions })(AddPersonContainer)
