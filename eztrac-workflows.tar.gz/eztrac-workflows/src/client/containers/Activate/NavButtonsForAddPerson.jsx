import { connect } from 'react-redux'
import Button from 'material-ui/Button'
import React from 'react'
import {
  addSelections as addSelectionsActions,
  stepper as stepperActions,
} from '../../redux/actions'
import ResetButton from '../Common/ResetButton'

const BackButton = ({
  activeStep,
  callResults,
  stepPrevious,
}) => activeStep > 0 ? (
  <Button
    className="button"
    disabled={callResults !== null}
    onClick={stepPrevious}
    variant="raised"
  >
    Back
  </Button>
) : null

const NextButton = ({
  isNextDisabled,
  stepNext,
}) => (
  <Button
    className="button"
    color="primary"
    disabled={isNextDisabled}
    onClick={stepNext}
    style={{ cursor: isNextDisabled ? 'not-allowed' : 'pointer' }}
    variant="raised"
  >
    Next
  </Button>
)

const ConfirmButton = ({
  addPerson,
  callResults,
}) => (
  <Button
    className="button"
    color="primary"
    disabled={callResults !== null}
    label="Confirm"
    onClick={addPerson}
    variant="raised"
  >
    Confirm
  </Button>
)

const LastButton = ({
  activeStep,
  addPerson,
  callResults,
  isNextDisabled,
  stepNext,
}) => {
  if ( activeStep < 3 ) {
    return (<NextButton isNextDisabled={isNextDisabled} stepNext={stepNext} />)
  }

  return (
    <div style={{ display: 'inline' }}>
      <ConfirmButton addPerson={addPerson} callResults={callResults} />
      <ResetButton callResults={callResults} />
    </div>
  )
}
const NavButtons = ({
  addPerson,
  callResults,
  isNextDisabled,
  activeStep,
  stepNext,
  stepPrevious,
}) => (
  <div>
    <BackButton activeStep={activeStep} callResults={callResults} stepPrevious={stepPrevious} />
    <LastButton
      activeStep={activeStep}
      addPerson={addPerson}
      callResults={callResults}
      isNextDisabled={isNextDisabled}
      stepNext={stepNext}
    />
  </div>
)

const mapStateToProps = state => ({
  activeStep: state.stepper,
  isPersonSelectedProp: state.isPersonSelected,
  selectedPerson: state.addSelections.selectedPerson,
  callResults: state.addSelections.addedPersonResults,

})

export default connect( mapStateToProps, { ...stepperActions, ...addSelectionsActions } )( NavButtons )
