import { connect } from 'react-redux'
import Divider from 'material-ui/Divider'
import React from 'react'
import ResultCard from '../../components/ResultCard'

const AddedResultsBox = ({
  results,
}) => (
  <div>
    { results ? (
      <div className="columns">
        <div className="column" key="results-person">
          <ResultCard
            hasError={results.person.hasError}
            header="Adding person to cost calc"
            message={results.person.message}
          />
          <Divider />
        </div>
        <div className="column" key="results-efforts">
          <ResultCard
            hasError={results.efforts.hasError}
            header="Updating effort(s)"
            message={results.efforts.message}
          />
          <Divider />
        </div>
      </div>
    ) : null}
  </div>
)


const mapStateToProps = state => ({
  results: state.addSelections.addedPersonResults,
})

export default connect(mapStateToProps, {})(AddedResultsBox)
