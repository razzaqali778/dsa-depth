import { connect } from 'react-redux'
import Divider from 'material-ui/Divider'
import Help from 'material-ui-icons/Help'
import Paper from 'material-ui/Paper'
import React from 'react'
import TextField from 'material-ui/TextField'
import isUndefined from 'lodash/isUndefined'
import { getNewEffortsTotal } from '../../redux/selectors/common/getEffortTotals'
import { efforts as effortsActions, teams as teamsActions } from '../../redux/actions'

const paperStyle = {
  padding: '15px 15px 15px 15px',
}

const dividerStyle = {
  margin: '5px 0px 15px 0px',
}

const EffortHeader = () => (
  <div className="columns">
    <div className="column">
      <p>Team Name</p>
    </div>
    <div className="column is-4 align-right">
      Updated Participation
      <span
        data-balloon="Select a team to update efforts"
        data-balloon-pos="up"
      >
        <Help style={{
          fontSize: '14px', height: '14px', width: '14px', marginLeft: '5px',
        }}
        />
      </span>
    </div>
  </div>
)

// TODO: consolidate with EffortTable
const TableRow = ({
  percent,
  teamName,
  teamId,
  updatePercent,
  errorText,
}) => (
  <div className="columns">
    <div className="column">
      <p>{ teamName }</p>
    </div>
    <div className="column is-4 align-right">
      <TextField
        error={!(isUndefined(errorText) || errorText === '')}
        helperText={errorText}
        helpertextclassname="error-text"
        id={`${teamName} Participation`}
        inputProps={{
          style: {
            textAlign: 'right',
            paddingRight: '4px',
            fontSize: '14px',
            height: 'auto',
          },
        }}
        onChange={evt => updatePercent({ teamId, newPercent: evt.target.value })}
        style={{
          width: '40%',
          height: '35px',
          marginTop: '-5px',
        }}
        value={percent}
      />
      {' '}
      %
    </div>
  </div>
)


const TotalRow = ({
  currentEfforts,
  getEffortsTotal,
}) => (
  <div className="columns">
    <div className="column">
      <p>Total</p>
    </div>
    <div className="column is-4 align-right">
      <p>
        { currentEfforts.length === 0 ? 0 : getEffortsTotal }
        {' '}
        %
      </p>
    </div>
  </div>
)


const AddPersonEffortTable = ({
  percent,
  currentEfforts,
  updatePercent,
  getEffortsTotal,
}) => (
  (
    <div className="effort-table">
      <Paper elevation={1} style={paperStyle}>
        <EffortHeader />
        <Divider style={dividerStyle} />

        {currentEfforts.map(({
          label, teamId, newPercent, errorText,
        }) => (
          <TableRow
            errorText={errorText}
            key={teamId}
            percent={newPercent}
            teamId={teamId}
            teamName={label}
            updatePercent={updatePercent}
          />
        ))}


        <TotalRow
          currentEfforts={currentEfforts}
          getEffortsTotal={getEffortsTotal}
          percent={percent}
        />
      </Paper>
    </div>
  )
)

const mapStateToProps = state => ({
  percent: state.addSelections.percent,
  selectedPerson: state.addSelections.selectedPerson,
  currentEfforts: state.efforts.current,
  getEffortsTotal: getNewEffortsTotal(state),
})

export default connect(mapStateToProps, { ...teamsActions, ...effortsActions })(AddPersonEffortTable)
