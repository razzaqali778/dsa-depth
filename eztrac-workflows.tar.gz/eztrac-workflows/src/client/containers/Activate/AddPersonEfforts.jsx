import { connect } from 'react-redux'
import Moment from 'moment'
import React from 'react'
import Select from 'react-select'
import TextField from 'material-ui/TextField'
import debounce from 'lodash/debounce'
import {
  addSelections as addSelectionActions,
  deactivateSelections as deactivateSelectionActions,
  efforts as effortsActions,
  teams as teamsActions,
} from '../../redux/actions'
import { getCurrentTimeframe, getStartDate } from '../../redux/selectors'
import { getValidTeams } from '../../redux/selectors/common/getValidTeams'
import { singleEffortValidation, totalEffortValidation } from '../../redux/selectors/common/effortValidations'
import EffortTable from './AddPersonEffortsTable'
import NavButtons from './NavButtonsForAddPerson'

const AddPersonEfforts = ({
  teams,
  fetchSearchTeams,
  selectedPerson,
  addNewEffort,
  setParticipation,
  startDate,
  numberOfEfforts,
  totalPercent,
  isPercentValid,
  currentTimeframe,
}) => (
  <div className="columns">
    <div className="column is-4">
      <h4>{selectedPerson.fullName}</h4>
      <TextField
        defaultValue={new Moment(startDate).format('YYYY-MM-DD')}
        inputProps={{
          min: new Moment(currentTimeframe.startDate).add(1, 'days').format('YYYY-MM-DD'),
          max: new Moment(currentTimeframe.endDate).format('YYYY-MM-DD'),
        }}
        label="Employee Start Date"
        mode="landscape"
        onChange={evt => setParticipation(evt.target.value)}
        style={{ width: 200 }}
        type="date"
      />
      <Select
        className="column select-box"
        clearable
        multi={false}
        name="team-select"
        onChange={
          team => {
            const newEffort = {
              teamName: team.name,
              label: team.label,
              teamId: team.id,
              newPercent: numberOfEfforts === 0 ? totalPercent : 0,
            }
            addNewEffort(newEffort)
          }
        }
        onInputChange={debounce(fetchSearchTeams, 200)}
        options={teams}
        placeholder="Select Team"
        value=""
      />
      <NavButtons isNextDisabled={!isPercentValid} />
    </div>
    <div className="column">
      <EffortTable />
    </div>
  </div>
)

const mapStateToProps = state => ({
  efforts: state.efforts,
  activeStep: state.stepper,
  selectedPerson: state.addSelections.selectedPerson,
  teams: getValidTeams(state),
  currentEfforts: state.efforts.current,
  currentTimeframe: getCurrentTimeframe(state),
  startDate: getStartDate(state),
  numberOfEfforts: state.efforts.current.length,
  totalPercent: state.addSelections.percent,
  isPercentValid: singleEffortValidation(state) && totalEffortValidation(state) && state.efforts.current.length > 0,
})

export default connect(mapStateToProps, {
  ...addSelectionActions,
  ...deactivateSelectionActions,
  ...effortsActions,
  ...teamsActions,
} )(AddPersonEfforts)
