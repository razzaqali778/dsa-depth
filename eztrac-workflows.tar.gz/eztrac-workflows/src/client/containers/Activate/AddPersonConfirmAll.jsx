import { connect } from 'react-redux'
import React from 'react'
import { getNewEffortsTotal } from '../../redux/selectors/common/getEffortTotals'
import AddedResultsBox from './AddedResultsBox'
import NavButtons from './NavButtonsForAddPerson'


// TODO: Tell them that they will be removed from efforts for the current and next month

const ConfirmActivate = ({
  selectedPerson,
  currentTimeframe,
  currentEfforts,
  effortsTotal,
}) => (
  <div>
    <p>
      You have chosen to add:
      <b>{ selectedPerson.fullName }</b>
    </p>
    <p>
      Their participation on team
      <b>
        { currentEfforts.map(effort => effort.label).join(', ') }
        {' '}
      </b>
    </p>
    <p>
      will be set to a total of
      <b>
        { effortsTotal }
        %
      </b>
      {' '}
      for the
      <b>{ currentTimeframe.name }</b>
      {' '}
      time frame.
    </p>
    <p>Is this correct?</p>
    <NavButtons />
    <AddedResultsBox />
  </div>
)

const mapStateToProps = state => ({
  activeStep: state.step,
  selectedPerson: state.addSelections.selectedPerson,
  currentEfforts: state.efforts.current,
  currentTimeframe: state.timeframes.currentTimeframe,
  effortsTotal: getNewEffortsTotal(state),
})

export default connect(mapStateToProps)(ConfirmActivate)
