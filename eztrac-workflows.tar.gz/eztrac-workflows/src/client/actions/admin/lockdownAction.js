import superagent from 'superagent'
import { recalculateCostsAction } from './recalculateCostsAction'
import { serviceBindings } from '../../redux/sagas/helpers/getServiceBindings'

export const lockdownAction = async (lockdown, id) => {
  try {
    await superagent
      .patch(`${serviceBindings.coreServices}/v2/timeframes/${id}`)
            .set(phoenix.authHeader && phoenix.authHeader()) // eslint-disable-line
      .send({ lockdown })
  } catch ( err ) {
    return {
      status: false,
      error: err,
      step: 'Lockdown',
    }
  }

  if ( lockdown ) {
    try {
      await superagent
        .put(`${serviceBindings.qcServices}/v1/archive/${id}`)
                .set(phoenix.authHeader && phoenix.authHeader()) // eslint-disable-line
    } catch ( err ) {
      return {
        status: false,
        error: err,
        step: 'QC Archive Call',
      }
    }

    const result = await recalculateCostsAction()

    if ( !result.status ) {
      return result
    }
  }

  return { status: true }
}
