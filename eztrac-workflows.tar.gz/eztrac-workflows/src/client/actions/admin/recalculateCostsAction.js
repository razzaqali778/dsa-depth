import superagent from 'superagent'
import { serviceBindings } from '../../redux/sagas/helpers/getServiceBindings'

export const recalculateCostsAction = async () => {
  try {
    await superagent
      .put(`${serviceBindings.coreServices}/v2/cost/standard-teams`)
                  .set(phoenix.authHeader && phoenix.authHeader()) // eslint-disable-line
  } catch ( err ) {
    return {
      status: false,
      error: err,
      step: 'Re-costing standard teams',
    }
  }

  return { status: true }
}
