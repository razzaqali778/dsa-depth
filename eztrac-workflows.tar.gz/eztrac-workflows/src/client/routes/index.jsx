import React from 'react'
import universal from 'react-universal-component'
import { ADD_PERSON_WORKFLOW, ADMIN_ACTIONS, DEACTIVATE_WORKFLOW } from '../redux/constants/pages'

const componentMap = {
  [DEACTIVATE_WORKFLOW]: universal(() => import('../containers/Deactivate/DeactivatePersonContainer')),
  [ADD_PERSON_WORKFLOW]: universal(() => import('../containers/Activate/AddPersonContainer')),
  [ADMIN_ACTIONS]: universal(() => import('../containers/admin/AdminActionsContainer')),
}
const NotFound = () => <div>404 - PAGE NOT FOUND AT PATH</div>

const RenderRoute = ({ page }) => {
  const Component = componentMap[page] || NotFound

  return <Component />
}

export default RenderRoute
