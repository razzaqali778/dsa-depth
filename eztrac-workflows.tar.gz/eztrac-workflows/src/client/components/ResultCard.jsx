import Card, {
  CardContent,
  CardHeader,
} from 'material-ui/Card'
import React from 'react'

export default ({ header, hasError, message }) => (
  <Card style={{ marginTop: '10px' }}>
    <CardHeader
      classes={{
        root: 'card-root',
        title: hasError ? 'card-header-error' : 'card-header-success',
        subheader: `card-subheader ${hasError ? 'card-content-error' : 'card-content-success'}`,
      }}
      subheader={`${hasError ? 'FAILURE ' : 'SUCCESS '} ${header}`}
    />
    <CardContent
      classes={{ root: hasError ? 'card-content-error' : 'card-content-success' }}
    >
      {`${message}`}
    </CardContent>
  </Card>
)
