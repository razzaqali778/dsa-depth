const namespace = 'resetWorkflow'
export const RESET_STEPPER = `${namespace}/RESET_STEPPER`
