const namespace = 'teams'

export const SET_ALL_TEAMS = `${namespace}/SET_ALL_TEAMS`
export const FETCH_SEARCH_TEAMS = `${namespace}/FETCH_SEARCH_TEAMS`
