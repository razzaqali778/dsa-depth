const namespace = 'page'

export const HOME = `${namespace}/HOME`
export const DEACTIVATE_WORKFLOW = `${namespace}/DEACTIVATE_WORKFLOW`
export const ADD_PERSON_WORKFLOW = `${namespace}/ADD_PERSON_WORKFLOW`
export const ADMIN_ACTIONS = `${namespace}/ADMIN_ACTIONS`
export const LOCKDOWN = `${namespace}/LOCKDOWN`
