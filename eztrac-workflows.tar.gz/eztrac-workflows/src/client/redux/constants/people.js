const namespace = 'people'

export const FETCH_PERSON_SUGGESTION = `${namespace}/FETCH_PERSON_SUGGESTION`
export const SET_PEOPLE = `${namespace}/SET_PEOPLE`
export const SET_PAPI_PEOPLE = `${namespace}/SET_PAPI_PEOPLE`
export const SET_PAPI_SEARCH_TEXT = `${namespace}/SET_PAPI_SEARCH_TEXT`
