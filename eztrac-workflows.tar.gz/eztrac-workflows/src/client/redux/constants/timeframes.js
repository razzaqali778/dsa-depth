const namespace = 'timeframes'

export const SET_CURRENT_TIMEFRAME = `${namespace}/SET_CURRENT_TIMEFRAME`
export const SET_NEXT_TIMEFRAME = `${namespace}/SET_NEXT_TIMEFRAME`
export const SET_ALL_TIMEFRAMES = `${namespace}/SET_ALL_TIMEFRAMES`
