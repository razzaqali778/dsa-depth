const namespace = 'deactivateSelections'

export const SET_SELECTED_PERSON = `${namespace}/SET_SELECTED_PERSON`

export const SET_SELECTED_REASON = `${namespace}/SET_SELECTED_REASON`

export const DEACTIVATE_PERSON = `${namespace}/DEACTIVATE_PERSON`

export const SET_DEACTIVATION_RESULTS = `${namespace}/SET_DEACTIVATION_RESULTS`

export const SET_END_DATE = `${namespace}/SET_END_DATE`

export const SET_PREVIOUS_SITE = `${namespace}/SET_PREVIOUS_SITE`

export const FETCH_DEACTIVATE_REASONS = `${namespace}/FETCH_DEACTIVATE_REASONS`
export const SET_DEACTIVATE_REASONS = `${namespace}/SET_DEACTIVATE_REASONS`
export const SEND_DEACTIVATE_MESSAGE = `${namespace}/SEND_DEACTIVATE_MESSAGE`
