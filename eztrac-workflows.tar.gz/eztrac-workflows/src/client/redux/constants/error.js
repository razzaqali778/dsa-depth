const namespace = 'error'

export const TEAMS_ERROR = `${namespace}/TEAMS_ERROR`
