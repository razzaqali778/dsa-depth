const namespace = 'stepper'

export const STEP_NEXT = `${namespace}/STEP_NEXT`
export const STEP_PREVIOUS = `${namespace}/STEP_PREVIOUS`
export const SET_STEP = `${namespace}/SET_STEP`
