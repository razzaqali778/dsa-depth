const namespace = 'addSelections'

export const ADD_PERSON = `${namespace}/ADD_PERSON`
export const ADD_RESULTS = `${namespace}/ADD_RESULTS`
export const SET_SELECTED_PERSON_WITH_SUGGESTION = `${namespace}/SET_SELECTED_PERSON_WITH_SUGGESTION`
export const SET_ADD_PERSON_RESULT = `${namespace}/SET_ADD_PERSON_RESULT`
export const SET_SELECTED_PERSON_SUGGESTION_LOADING = `${namespace}/SET_SELECTED_PERSON_SUGGESTION_LOADING`
export const SET_ALL_TEAMS = `${namespace}/SET_ALL_TEAMS`
export const SEND_TASK = `${namespace}/SEND_TASK`
export const SET_START_DATE = `${namespace}/SET_START_DATE`
export const SET_PERCENT = `${namespace}/SET_PERCENT`
export const SET_PARTICIPATION = `${namespace}/SET_PARTICIPATION`
