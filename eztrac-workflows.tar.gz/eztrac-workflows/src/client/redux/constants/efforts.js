const namespace = 'efforts'
export const SET_CURRENT_EFFORTS = `${namespace}/SET_CURRENT_EFFORTS`
export const ADD_NEW_EFFORT = `${namespace}/ADD_NEW_EFFORT`
export const SET_FUTURE_EFFORTS = `${namespace}/SET_FUTURE_EFFORTS`
export const SET_EFFORTS_LOADING = `${namespace}/SET_EFFORTS_LOADING`
export const UPDATE_PERCENT = `${namespace}/UPDATE_PERCENT`
