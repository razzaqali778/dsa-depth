const namespace = 'user'

export const SET_USER = `${namespace}/SET_USER`
