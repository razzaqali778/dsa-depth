const namespace = 'healthCheck'

export const FETCH_HEALTH_CHECK = `${namespace}/FETCH_HEALTH_CHECK`
export const SET_HEALTH_CHECK = `${namespace}/SET_HEALTH_CHECK`
export const SET_HEALTH_CHECK_TIMEFRAME = `${namespace}/SET_HEALTH_CHECK_TIMEFRAME`
