const namespace = 'costGroupsRates'

export const FETCH_ALL_RATE_DATA = `${namespace}/FETCH_ALL_RATE_DATA`
export const FETCH_ALL_COST_GROUP_DATA = `${namespace}/FETCH_ALL_COST_GROUP_DATA`
export const SET_ALL_COST_GROUP_DATA = `${namespace}/SET_ALL_COST_GROUP_DATA`
export const SET_ALL_RATE_DATA = `${namespace}/SET_ALL_RATE_DATA`
export const SET_SELECTED_COST_GROUP = `${namespace}/SET_SELECTED_COST_GROUP`
export const SET_SELECTED_RATE = `${namespace}/SET_SELECTED_RATE`
