import getOrElse from 'lodash/get'
import {
  ADD_PERSON_WORKFLOW,
  ADMIN_ACTIONS,
  DEACTIVATE_WORKFLOW,
  HOME,
} from './constants/pages'
import { FETCH_ALL_COST_GROUP_DATA, FETCH_ALL_RATE_DATA } from './constants/costGroupsRates'
import { FETCH_DEACTIVATE_REASONS, SET_PREVIOUS_SITE, SET_SELECTED_PERSON } from './constants/deactivateSelections'
import { SET_PARTICIPATION } from './constants/addSelections'

const baseUrl = '/ez-trac-workflows'
const previousSiteKey = 'deactivatePrevSite'

const getStorage = key => {
  const value = window.sessionStorage.getItem(key)

  return value
}

const removeStorageItem = key => window.sessionStorage.removeItem(key)

const deactivateThunk = async (dispatch, getState) => {
  const id = getOrElse(getState(), 'location.query.id', false)
  const previousSite = getStorage(previousSiteKey)
  if ( id ) {
    const action = { type: SET_SELECTED_PERSON, payload: { value: id.toUpperCase() } }
    setTimeout(() => dispatch(action), 10)
  }

  setTimeout(() => dispatch({ type: SET_PREVIOUS_SITE, payload: previousSite }), 10)
  setTimeout( () => dispatch({ type: FETCH_DEACTIVATE_REASONS }), 10)
  removeStorageItem(previousSiteKey)
}

const addPersonThunk = async dispatch => {
  const costGroupAction = { type: FETCH_ALL_COST_GROUP_DATA, payload: null }
  const rateAction = { type: FETCH_ALL_RATE_DATA, payload: null }
  const percentAction = { type: SET_PARTICIPATION, payload: new Date() }
  setTimeout( () => dispatch(costGroupAction), 10 )
  setTimeout( () => dispatch(rateAction), 10)
  setTimeout( () => dispatch(percentAction), 10)
}

export default {
  [HOME]: { path: baseUrl, thunk: deactivateThunk },
  [DEACTIVATE_WORKFLOW]: { path: `${baseUrl}/deactivate-person`, thunk: deactivateThunk },
  [ADD_PERSON_WORKFLOW]: { path: `${baseUrl}/add-person`, thunk: addPersonThunk },
  [ADMIN_ACTIONS]: { path: `${baseUrl}/admin-actions` },
}
