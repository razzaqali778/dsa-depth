import { NOT_FOUND } from 'redux-first-router'
import {
  ADD_PERSON_WORKFLOW, ADMIN_ACTIONS, DEACTIVATE_WORKFLOW, HOME,
} from '../constants/pages'

// create a map instead of an array for O(1) lookup and so home can point to a page
const constMap = {
  [HOME]: DEACTIVATE_WORKFLOW, // map the root path to deactivate workflow -- TODO TEMPORARY
  [DEACTIVATE_WORKFLOW]: DEACTIVATE_WORKFLOW,
  [ADD_PERSON_WORKFLOW]: ADD_PERSON_WORKFLOW,
  [ADMIN_ACTIONS]: ADMIN_ACTIONS,
  [NOT_FOUND]: NOT_FOUND,
}

export default (state = '', action = {}) => constMap[action.type] || state
