import { combineReducers } from 'redux'
import addSelections from './addSelections'
import costGroupsRates from './costGroupsRates'
import deactivateSelections from './deactivateSelections'
import efforts from './efforts'
import healthCheck from './healthCheck'
import page from './page'
import people from './people'
import stepper from './stepper'
import teams from './teams'
import timeframes from './timeframes'
import user from './user'

export default location => combineReducers({
  addSelections,
  costGroupsRates,
  people,
  deactivateSelections,
  efforts,
  healthCheck,
  stepper,
  user,
  teams,
  timeframes,
  page,
  location,
})
