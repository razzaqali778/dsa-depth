import { combineReducers } from 'redux'
import { SET_HEALTH_CHECK } from '../constants/healthCheck'

const healthCheck = (state = {}, action = {}) => {
  switch ( action.type ) {
    case SET_HEALTH_CHECK:
      return action.payload
    default:
      return state
  }
}

const reducer = combineReducers({ healthCheck })

export default reducer
