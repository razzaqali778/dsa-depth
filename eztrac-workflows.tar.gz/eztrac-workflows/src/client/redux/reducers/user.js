import { SET_USER } from '../constants/user'

const initialState = {
  entitlements: {
    'my-app': [],
  },
}

const reducer = ( state = initialState, action = {} ) => {
  switch ( action.type ) {
    case SET_USER:
      return {
        ...action.payload,
      }
    default:
      return state
  }
}

export default reducer

