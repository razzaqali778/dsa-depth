import { combineReducers } from 'redux'
import getOrElse from 'lodash/get'
import { DEACTIVATE_WORKFLOW } from '../constants/pages'
import { RESET_STEPPER } from '../constants/resetWorkflow'
import {
  SET_DEACTIVATE_REASONS,
  SET_DEACTIVATION_RESULTS,
  SET_END_DATE,
  SET_PREVIOUS_SITE,
  SET_SELECTED_PERSON,
  SET_SELECTED_REASON,
} from '../constants/deactivateSelections'

const selectedPerson = (state = null, action = {}) => {
  switch ( action.type ) {
    case SET_SELECTED_PERSON: return getOrElse(action, 'payload.value', null)
    case RESET_STEPPER: return null
    default: return state
  }
}

const selectedReason = (state = null, action = {}) => {
  switch ( action.type ) {
    case SET_SELECTED_REASON: return getOrElse(action, 'payload.value', null)
    case DEACTIVATE_WORKFLOW: {
      const val = getOrElse(action, 'meta.query.reason', false)

      return val || state
    }
    case RESET_STEPPER: return null
    default: return state
  }
}

const endDate = (state = new Date(), action = {}) => {
  switch ( action.type ) {
    case SET_END_DATE: return action.payload
    case RESET_STEPPER: return new Date()
    default: return state
  }
}

const deactivationResults = (state = null, action = {}) => {
  switch ( action.type ) {
    case SET_DEACTIVATION_RESULTS: {
      return { ...state, ...action.payload }
    }
    case RESET_STEPPER: return null
    default: return state
  }
}

const deactivateReasons = ( state = [], action = {}) => {
  switch ( action.type ) {
    case SET_DEACTIVATE_REASONS: { return action.payload }
    default: return state
  }
}

const previousSite = ( state = [], action = {}) => {
  switch ( action.type ) {
    case SET_PREVIOUS_SITE: {
      return action.payload
    }
    default: return state
  }
}

const reducer = combineReducers({
  deactivationResults,
  endDate,
  selectedReason,
  selectedPerson,
  deactivateReasons,
  previousSite,
})


export default reducer
