import { combineReducers } from 'redux'
import { RESET_STEPPER } from '../constants/resetWorkflow'
import {
  SET_ADD_PERSON_RESULT,
  SET_PARTICIPATION,
  SET_PERCENT,
  SET_SELECTED_PERSON_SUGGESTION_LOADING,
  SET_SELECTED_PERSON_WITH_SUGGESTION,
  SET_START_DATE,
} from '../constants/addSelections'


const addedPersonResults = (state = null, action = {}) => {
  switch ( action.type ) {
    case SET_ADD_PERSON_RESULT: return { ...state, ...action.payload }
    case RESET_STEPPER: return null
    default: return state
  }
}

const selectedPerson = (state = null, action = {}) => {
  switch ( action.type ) {
    case SET_SELECTED_PERSON_WITH_SUGGESTION: return action.payload
    case RESET_STEPPER: return null

    default: return state
  }
}

const suggestionLoading = (state = false, action = {}) => {
  switch ( action.type ) {
    case SET_SELECTED_PERSON_SUGGESTION_LOADING: return action.payload
    case RESET_STEPPER: return false
    default: return state
  }
}

const startDate = (state = new Date().toLocaleDateString(), action = {}) => {
  switch ( action.type ) {
    case SET_START_DATE: return action.payload
    case SET_PARTICIPATION: return action.payload
    case RESET_STEPPER: return new Date().toLocaleDateString()
    default: return state
  }
}

const percent = (state = null, action = {}) => {
  switch ( action.type ) {
    case SET_PERCENT: return action.payload
    case RESET_STEPPER: return null
    default: return state
  }
}

const reducer = combineReducers({
  selectedPerson,
  suggestionLoading,
  addedPersonResults,
  startDate,
  percent,
})


export default reducer
