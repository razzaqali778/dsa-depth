import { combineReducers } from 'redux'
import {
  ADD_NEW_EFFORT,
  SET_CURRENT_EFFORTS,
  SET_EFFORTS_LOADING,
  SET_FUTURE_EFFORTS,
  UPDATE_PERCENT,
} from '../constants/efforts'
import { RESET_STEPPER } from '../constants/resetWorkflow'

const setErrorText = percent => {
  if ( isNaN(percent) ) {
    return 'Not A Number'
  } if ( percent < 0 || percent > 100 || percent === '' ) {
    return 'Out Of Range'
  }

  return ''
}

const loading = ( state = false, action = {} ) => {
  switch ( action.type ) {
    case SET_EFFORTS_LOADING: return action.payload
    default: return state
  }
}

const current = (state = [], action = {}) => {
  switch ( action.type ) {
    case ADD_NEW_EFFORT: return [ ...state, action.payload ]
    case SET_CURRENT_EFFORTS: return action.payload
    case RESET_STEPPER: return []
    case UPDATE_PERCENT: return state.map( item => item.teamId === action.payload.teamId
      ? {
        ...item,
        newPercent: action.payload.newPercent,
        errorText: setErrorText(action.payload.newPercent),
      }
      : item)
    default: return state
  }
}
const next = (state = [], action = {}) => {
  switch ( action.type ) {
    case SET_FUTURE_EFFORTS: return action.payload
    case RESET_STEPPER: return []
    case UPDATE_PERCENT: return state.map( item => item.teamId === action.payload.teamId
      ? {
        ...item,
        newPercent: action.payload.newPercent,
        errorText: setErrorText(action.payload.newPercent),
      }
      : item)
    default: return state
  }
}
const reducer = combineReducers({
  current,
  next,
  loading,
})
export default reducer
