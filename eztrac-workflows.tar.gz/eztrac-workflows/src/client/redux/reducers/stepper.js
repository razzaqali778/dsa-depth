import getOrElse from 'lodash/get'
import { DEACTIVATE_WORKFLOW } from '../constants/pages'
import { RESET_STEPPER } from '../constants/resetWorkflow'
import {
  SET_STEP,
  STEP_NEXT,
  STEP_PREVIOUS,
} from '../constants/stepper'

const reducer = ( state = 0, action = {} ) => {
  switch ( action.type ) {
    case STEP_NEXT: return state + 1
    case STEP_PREVIOUS: return state - 1
    case SET_STEP: return action.payload
    case RESET_STEPPER: return 0
    case DEACTIVATE_WORKFLOW: return parseInt(getOrElse(action, 'meta.query.step', state), 10)
    default: return state
  }
}

export default reducer
