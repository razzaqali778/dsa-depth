import { combineReducers } from 'redux'
import {
  FETCH_ALL_COST_GROUP_DATA,
  FETCH_ALL_RATE_DATA,
  SET_ALL_COST_GROUP_DATA,
  SET_ALL_RATE_DATA,
  SET_SELECTED_COST_GROUP,
  SET_SELECTED_RATE,
} from '../constants/costGroupsRates'

const checkArray = (theArray, state) => Array.isArray(theArray) ? state : theArray

const costGroupData = ( state = null, action = {} ) => {
  switch ( action.type ) {
    case FETCH_ALL_COST_GROUP_DATA: return action.payload
    case SET_ALL_COST_GROUP_DATA: return action.payload
    default: return state
  }
}

const selectedCostGroup = ( state = null, action = {} ) => {
  switch ( action.type ) {
    case SET_SELECTED_COST_GROUP: return checkArray(action.payload, state)
    default: return state
  }
}

const selectedRate = ( state = null, action = {} ) => {
  switch ( action.type ) {
    case SET_SELECTED_RATE: return checkArray(action.payload, state)
    default: return state
  }
}


const rateData = ( state = null, action = {} ) => {
  switch ( action.type ) {
    case FETCH_ALL_RATE_DATA: return action.payload
    case SET_ALL_RATE_DATA: return action.payload
    default: return state
  }
}

const reducer = combineReducers({
  costGroupData,
  rateData,
  selectedCostGroup,
  selectedRate,
})

export default reducer
