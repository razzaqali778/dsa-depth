import { combineReducers } from 'redux'
import { RESET_STEPPER } from '../constants/resetWorkflow'
import { SET_PAPI_PEOPLE, SET_PEOPLE } from '../constants/people'

const allPeople = (state = [], action = {}) => {
  switch ( action.type ) {
    case SET_PEOPLE: return action.payload
    default: return state
  }
}

const papiPeople = (state = [], action = {}) => {
  switch ( action.type ) {
    case SET_PAPI_PEOPLE: return action.payload
    case RESET_STEPPER: return []
    default: return state
  }
}

const reducer = combineReducers({
  allPeople,
  papiPeople,
})

export default reducer
