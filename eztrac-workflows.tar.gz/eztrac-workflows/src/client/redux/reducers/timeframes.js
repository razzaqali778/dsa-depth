import { combineReducers } from 'redux'
import { SET_ALL_TIMEFRAMES, SET_CURRENT_TIMEFRAME, SET_NEXT_TIMEFRAME } from '../constants/timeframes'

const currentTimeframe = (state = {}, action = {}) => {
  switch ( action.type ) {
    case SET_CURRENT_TIMEFRAME: {
      return { ...action.payload, currentTimeframeLocked: action.payload.lockdownState }
    }
    default:
      return state
  }
}
const nextTimeframe = (state = {}, action = {}) => {
  switch ( action.type ) {
    case SET_NEXT_TIMEFRAME:
      return action.payload
    default:
      return state
  }
}
const allTimeframes = (state = {}, action = {}) => {
  switch ( action.type ) {
    case SET_ALL_TIMEFRAMES:
      return action.payload
    default:
      return state
  }
}

const reducer = combineReducers({
  currentTimeframe,
  nextTimeframe,
  allTimeframes,
})

export default reducer
