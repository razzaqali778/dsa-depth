import { combineReducers } from 'redux'
import { RESET_STEPPER } from '../constants/resetWorkflow'
import { SET_ALL_TEAMS } from '../constants/teams'

const teams = (state = null, action = {}) => {
  switch ( action.type ) {
    case SET_ALL_TEAMS: return action.payload
    case RESET_STEPPER: return null
    default: return state
  }
}

const reducer = combineReducers({ teams })

export default reducer
