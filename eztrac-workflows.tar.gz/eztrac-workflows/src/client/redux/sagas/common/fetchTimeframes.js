import { call, put as dispatch } from 'redux-saga/effects'
import { get } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export default function* () {
  const getAllOpts = {
    baseUrl: serviceBindings.coreServices,
    path: '/v2/timeframes',
  }

  const getCurrentOpts = {
    baseUrl: serviceBindings.coreServices,
    path: '/v2/timeframes/current',
  }

  const getNextOpts = {
    baseUrl: serviceBindings.coreServices,
    path: '/v2/timeframes/current/offset/1',
  }

  const currentTimeframe = yield call(get, getCurrentOpts)
  const nextTimeframe = yield call(get, getNextOpts)
  const allTimeframes = yield call(get, getAllOpts)

  if ( !currentTimeframe.error ) {
    yield dispatch(actions.setCurrentTimeframe({
      ...currentTimeframe,
      currentTimeframeLocked: currentTimeframe.lockdown,
    }))
  }
  if ( !nextTimeframe.error ) {
    yield dispatch(actions.setNextTimeframe(nextTimeframe))
  }
  if ( !allTimeframes.error ) {
    yield dispatch(actions.setAllTimeframes(allTimeframes))
  }
}
