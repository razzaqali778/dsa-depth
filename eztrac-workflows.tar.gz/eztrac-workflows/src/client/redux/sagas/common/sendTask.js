import { call, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import _ from 'lodash'
import getOrElse from 'lodash/get'
import map from 'lodash/map'
import moment from 'moment'
import actions from '../../actions'
import { post } from '../helpers/network'
import { getAddSelectedPerson, getSelectedCostGroup, getSelectedRate } from '../../selectors'

const peadminHome = window.phoenix.serviceBindings['peadmin-home']
const velocityHome = window.phoenix.serviceBindings['velocity-home']
const messagingUrl = window.phoenix.serviceBindings['messaging-url']

export const sendTask = function* f() {
  const selectedPerson = yield select(getAddSelectedPerson)
  const selectedCostGroup = yield select(getSelectedCostGroup)
  const selectedRate = yield select(getSelectedRate)
  const departmentName = selectedPerson.department.name ? selectedPerson.department.name : 'Unknown'

  const opsLeadsCall = yield call(post, {
    baseUrl: `https://profile.${velocityHome}`,
    path: '/v3/graphql',
    body: { query: '{ getGroupById(id: "PE-STRATEGY-AND-OPERATIONS-LEADS") { members { members { id } } } }' },
  })

  const opsLeads = getOrElse(opsLeadsCall, 'data.getGroupById.members.members', [])
  const opsLeadsList = map(opsLeads, ({ id }) => id )
  const fakeOpsLeads = [ 'DJIAN', 'CCASE' ]
  const combinedOpsLeads = _.concat( opsLeadsList, fakeOpsLeads )
  const dynamicOpsLeads = peadminHome.includes('np') ? fakeOpsLeads : combinedOpsLeads

  const payload = {
    actions: [
      {
        title: 'view',
        url: `https://${peadminHome}/ez-trac-costing/people?personId=${selectedPerson.id}&edit=true&task=true`,
      },
    ],
    body: {
      markdown: `Please review the new profile for **${selectedPerson.fullName}** `
                  + `from the department **${departmentName}**. They have been suggested the `
                  + `cost group of **${selectedCostGroup.label}** with the rate of **${selectedRate.label}.**`,
    },
    dueDate: moment().add( 1, 'w' ).format( 'YYYY-MM-DD' ),
    recipients: dynamicOpsLeads,
    sender: 'Ez Trac',
    tags: [
      'Ez Trac',
    ],
    senderKey: selectedPerson.id,
    title: 'Review Person Added to Ez-Trac',
  }

  yield call(post, {
    baseUrl: messagingUrl,
    path: '/v5/tasks',
    body: payload,
  })
}

export default function* () {
  yield* takeLatest([
    actions.sendTask().type,
  ], sendTask)
}
