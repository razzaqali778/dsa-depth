import { call, put as dispatch, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import filter from 'lodash/filter'
import find from 'lodash/find'
import getOrElse from 'lodash/get'
import map from 'lodash/map'
import actions from '../../actions'
import { post } from '../helpers/network'
import { getAllPeople } from '../../selectors'

export const fetchNonEzTracPapiPeopleSaga = function* f({ payload }) {
  if ( payload === '' ) {
    yield dispatch(actions.setPapiPeople([]))

    return
  }

  const velocityHome = window.phoenix.serviceBindings['velocity-home']

  const getPapiPeople = {
    baseUrl: `https://profile.${velocityHome}`,
    path: '/v3/graphql',
    body: { query: `{ searchUsers(query: "${payload}") { members { id legalName { full } employeeType organization { name } } } }` }, // eslint-disable-line max-len
  }

  const papiPeopleCall = yield call(post, getPapiPeople)
  const papiPeople = getOrElse(papiPeopleCall, 'data.searchUsers.members', [])
  const eztPeople = yield select(getAllPeople)
  const newPeople = filter(papiPeople, papiPerson => (
    find(eztPeople, e => e.personId === papiPerson.id) === undefined
  ))

  const filteredPapiPeople = filter(newPeople, p => p.employeeType !== 'Mechanical' && p.employeeType !== 'External')

  const formattedPeople = map(filteredPapiPeople, p => ({
    value: p.id,
    label: `${p.legalName.full} (${p.id})`,
    fullName: p.legalName.full,
    employeeType: p.employeeType,
    department: p.organization ? p.organization.name : undefined,
  }))

  yield dispatch(actions.setPapiPeople(formattedPeople))
}

export default function* () {
  yield* takeLatest([
    actions.setPapiSearchText().type,
  ], fetchNonEzTracPapiPeopleSaga)
}
