import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { get } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export const fetchHealthCheck = function* f({ payload }) {
  const healthCheck = yield call(get, {
    baseUrl: serviceBindings.coreServices,
    path: `/v2/healthCheck/efforts/timeFrameId/${payload}`,
  })

  if ( !healthCheck.error ) {
    yield dispatch(actions.setHealthCheck(healthCheck))
  } else {
    console.error(healthCheck.error) // eslint-disable-line no-console
  }
}

export default function* () {
  yield* takeLatest([
    actions.setHealthCheckTimeframe().type,
  ], fetchHealthCheck)
}
