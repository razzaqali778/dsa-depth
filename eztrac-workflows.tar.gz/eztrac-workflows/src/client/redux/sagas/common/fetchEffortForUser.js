import {
  all, call, put as dispatch, select,
} from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import isEmpty from 'lodash/isEmpty'
import map from 'lodash/map'
import reduce from 'lodash/reduce'
import { get } from '../helpers/network'
import { getCurrentTimeframe } from '../helpers/getTakes'
import { getSelectedPerson } from '../../selectors'
import { serviceBindings } from '../helpers/getServiceBindings'
import { setSuggestedParticipation } from './setSuggestedParticipation'
import actions from '../../actions'
import getFutureTimeFrames from '../../selectors/common/getFutureTimeFrames'

function* getEffortsWithTeamNames(efforts) {
  const teamIds = Array.from(new Set(map(efforts, 'teamId')))
  const teamsInfo = yield all(
    map(teamIds, teamId => {
      const getTeamOpts = {
        baseUrl: serviceBindings.coreServices,
        path: `/v2/team/${teamId}`,
      }

      return call(get, getTeamOpts)
    }),
  )

  if ( !teamsInfo.error && !isEmpty(teamsInfo) ) {
    const teamMap = reduce(
      teamsInfo,
      (memo, val) => {
        memo[val.id] = val.name // eslint-disable-line no-param-reassign

        return memo
      },
      {},
    )

    const effortsWithTeamNames = map(efforts, effort => ({
      ...effort,
      teamName: teamMap[effort.teamId],
    }))

    return effortsWithTeamNames
  }

  return []
}

function* processCurrentEfforts(currentEfforts) {
  if ( !currentEfforts.error ) {
    const effortsWithTeamNames = yield call(getEffortsWithTeamNames, currentEfforts)
    if ( !effortsWithTeamNames.error && !isEmpty(effortsWithTeamNames) ) {
      yield dispatch(actions.setCurrentEfforts(effortsWithTeamNames))
      yield call(setSuggestedParticipation)
    }
  } else {
    console.error(currentEfforts.error) // eslint-disable-line no-console
  }
}

function* processFutureEfforts(futureEfforts) {
  if ( !futureEfforts.error ) {
    const effortsWithTeamNames = yield call(getEffortsWithTeamNames, futureEfforts)
    if ( !effortsWithTeamNames.error && !isEmpty(effortsWithTeamNames) ) {
      yield dispatch(actions.setFutureEfforts(effortsWithTeamNames))
    }
  } else {
    console.error(futureEfforts.error) // eslint-disable-line no-console
  }
}

const fetchEffortForUser = function* f() { // eslint-disable-line max-statements
  yield dispatch(actions.setEffortsLoading(true))

  const { id: timeframeId } = yield call(getCurrentTimeframe)
  const futureTimeframes = yield select(getFutureTimeFrames)
  const userId = yield select(getSelectedPerson)
  const getCurrentOpts = {
    baseUrl: serviceBindings.coreServices,
    path: `/v2/efforts/timeframes/${timeframeId}/user/${userId}`,
  }
  const getFutureOpts = futureTimeframes.map(({ id }) => ({
    baseUrl: serviceBindings.coreServices,
    path: `/v2/efforts/timeframes/${id}/user/${userId}`,
  }))

  const currentEfforts = yield call(get, getCurrentOpts)
  const futureEfforts = yield all(getFutureOpts.map(opts => call(get, opts)))

  yield call(processCurrentEfforts, currentEfforts)

  yield call(processFutureEfforts, futureEfforts.flat())

  yield dispatch(actions.setEffortsLoading(false))
}

export const exportedForTesting = {
  processCurrentEfforts,
  processFutureEfforts,
  fetchEffortForUser,
  getEffortsWithTeamNames,
}

export default function* () {
  yield takeLatest([
    actions.setSelectedPerson().type,
  ], fetchEffortForUser)
}
