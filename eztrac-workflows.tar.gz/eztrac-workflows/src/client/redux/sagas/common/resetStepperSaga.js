import { put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import actions from '../../actions'

export const resetStepperSaga = function* f() {
  yield dispatch(actions.setParticipation(new Date()))
}

export default function* () {
  yield takeLatest([
    actions.resetStepper().type,
  ], resetStepperSaga)
}
