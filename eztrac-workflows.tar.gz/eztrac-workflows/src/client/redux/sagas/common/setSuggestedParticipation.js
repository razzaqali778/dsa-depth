import { put as dispatch, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { getCurrentEfforts } from '../../selectors'
import { getSuggestedEfforts } from '../../selectors/common/getFractionWorked'
import actions from '../../actions'

export const setSuggestedParticipation = function* f() {
  const effortList = yield select(getCurrentEfforts)
  const fractionWorked = yield select(getSuggestedEfforts)

  const updatedEfforts = effortList.map(effort => ({
    ...effort,
    newPercent: Math.round(fractionWorked * effort.percent),
  }))

  yield dispatch(actions.setCurrentEfforts(updatedEfforts))
}

export default function* () {
  yield takeLatest([
    actions.setEndDate().type,
  ], setSuggestedParticipation)
}
