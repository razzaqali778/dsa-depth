import { call, put } from 'redux-saga/effects'
import { queries, queryProfile } from '@bayerit/profile-client'
import actions from '../../actions'

export const fetchUser = async () => {
  const userProfile = await queryProfile(queries.currentUserWithEntitlements('ez-trac'))

  return userProfile
}

export default function* () {
  const { error, getCurrentUser } = yield call(fetchUser)
  if ( !error ) {
    if ( getCurrentUser ) {
      yield put(actions.setUser({ ...getCurrentUser }))
    }
  }
}
