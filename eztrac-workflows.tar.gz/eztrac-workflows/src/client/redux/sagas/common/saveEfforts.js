import { all, call, select } from 'redux-saga/effects'
import isEmpty from 'lodash/isEmpty'
import { getCurrentEfforts } from '../../selectors'
import { put } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'

export const saveEfforts = function* f() {
  const efforts = yield select(getCurrentEfforts)

  const calls = efforts.map(effort => {
    const newPercent = effort.newPercent ? parseInt(effort.newPercent, 10) : null

    if ( !newPercent || effort.percent === newPercent ) { return null }

    const options = {
      baseUrl: serviceBindings.coreServices,
      path: `/v2/efforts/timeframes/${effort.timeFrameId}/team/${effort.teamId}/user/${effort.userId}`,
      body: { percent: newPercent },
      headers: { accept: 'text/plain' },
    }

    return call(put, options)
  }).filter(a => a)


  if ( isEmpty(calls) ) { return [] }

  const callResult = yield all(calls)

  return callResult.map((result, idx) => {
    const {
      timeFrameId, teamId, userId, percent, newPercent,
    } = efforts[idx]

    return result === null
      ? {
        timeFrameId, teamId, userId, percent, newPercent,
      }
      : result
  })
}

export default saveEfforts
