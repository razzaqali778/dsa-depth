import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import isEmpty from 'lodash/isEmpty'
import map from 'lodash/map'
import { get } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export const fetchAllTeamsSaga = function* f({ payload }) {
  const teams = yield call(get, {
    baseUrl: serviceBindings.coreServices,
    path: `/v2/teams?q=${payload}`,
  })

  if ( isEmpty(teams) || teams.error ) {
    const allTeamsUnknown = [
      {
        value: 'Unknown',
        label: 'Unknown',
        id: '-1',
        name: 'Unknown',
      },
    ]

    yield dispatch(actions.setAllTeams(allTeamsUnknown))
  } else {
    const allTeams = map(teams, t => ({
      value: t.id,
      label: t.name,
      name: t.name,
      id: t.id,
    }))

    yield dispatch(actions.setAllTeams(allTeams))
  }
}

export default function* () {
  yield* takeLatest([
    actions.fetchSearchTeams().type,
  ], fetchAllTeamsSaga)
}
