import { call, put as dispatch } from 'redux-saga/effects'
import { map } from 'lodash'
import { takeLatest } from 'redux-saga'
import sortBy from 'lodash/sortBy'
import { get } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export function* getAllCostGroupsSaga() {
  const result = yield call(get, {
    baseUrl: serviceBindings.costingServices,
    path: '/v1/costGroups?isActive=true',
  })

  if ( result.error ) {
    console.error('ERROR in CostGroup Saga: ', result.error) // eslint-disable-line no-console
  } else {
    const costGroups = map( result, item => {
      const cg = { key: item.id, value: item.id, label: item.name }

      return cg
    })

    const sortedCostGroups = sortBy(costGroups, 'label')

    yield dispatch(actions.setAllCostGroupData(sortedCostGroups))
  }
}

export default function* () {
  yield* takeLatest(
    [
      actions.fetchAllCostGroupData().type,
    ],
    getAllCostGroupsSaga,
  )
}
