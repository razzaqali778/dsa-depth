import { call, put as dispatch } from 'redux-saga/effects'
import getOrElse from 'lodash/get'
import sortBy from 'lodash/sortBy'
import { get } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export default function* () {
  const getOpts = {
    baseUrl: serviceBindings.costingServices,
    path: '/v1/people?isActive=true',
  }

  const people = yield call(get, getOpts)
  const sortedPeople = sortBy(people, person => getOrElse(person, 'personName', '').toUpperCase())

  if ( !people.error ) {
    yield dispatch(actions.setPeople(sortedPeople))
  }
}

