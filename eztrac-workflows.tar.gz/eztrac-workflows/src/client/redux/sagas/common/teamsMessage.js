import { call, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { getCurrentUserName, getSelectedPerson, getSelectedReason } from '../../selectors'
import { post } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'
import getPersonName from '../../selectors/common/getPersonName'

export const teamsMessage = function* f() {
  const deactivatedPerson = yield select(getPersonName)
  const deactivatedPersonId = yield select(getSelectedPerson)
  const deactivatedReason = yield select(getSelectedReason)
  const currentUserName = yield select(getCurrentUserName)

  const title = `${deactivatedPerson} has been deactivated with the reason ${deactivatedReason} by ${currentUserName}.` // eslint-disable-line max-len

  const peadminHome = `https://${window.phoenix.serviceBindings['peadmin-home']}`

  const options = {
    text: `${title} Reactivate in <${peadminHome}/ez-trac-costing/people?personId=${deactivatedPersonId}|Costing Engine> and\nRemove reason in <${peadminHome}/ez-trac-qc/participation?q=${deactivatedPersonId}&showWithReasons=true|Participation QC>`, // eslint-disable-line max-len
  }

  const card = {
    type: 'AdaptiveCard',
    $schema: 'https://adaptivecards.io/schemas/adaptive-card.json',
    version: '1.5',
    body: [
      {
        type: 'TextBlock',
        size: 'Medium',
        weight: 'Bolder',
        wrap: true,
        color: 'good',
        text: title,
      },
      {
        type: 'TextBlock',
        wrap: true,
        text: options.text,
      },
    ],
    msteams: {
      width: 'Full',
    },
  }

  const data = {
    type: 'message',
    attachments: [
      {
        contentType: 'application/vnd.microsoft.card.adaptive',
        content: {
          ...card,
        },
      },
    ],
  }

  const postOpts = {
    baseUrl: serviceBindings.eztracTeamsHook,
    path: '',
    body: data,
  }

  yield call(post, postOpts)
}

export default function* () {
  yield* takeLatest([
    actions.sendDeactivateMessage().type,
  ], teamsMessage)
}
