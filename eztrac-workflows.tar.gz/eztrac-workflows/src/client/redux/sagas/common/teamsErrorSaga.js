import { call } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { post } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export const teamsError = function* f({ payload }) {
  const velocityHome = `https://${window.phoenix.serviceBindings['velocity-home']}`
  const location = velocityHome.includes('-np') ? 'NP' : 'PROD'
  const fields = JSON.stringify(payload.fields)
  const options = {
    text: `Error in env: ${location}, step: ${payload.step}. Fields ${fields}`,
  }

  const card = {
    type: 'AdaptiveCard',
    $schema: 'https://adaptivecards.io/schemas/adaptive-card.json',
    version: '1.5',
    body: [
      {
        type: 'TextBlock',
        size: 'Medium',
        weight: 'Bolder',
        wrap: true,
        color: 'attention',
        text: payload.title || 'Error',
      },
      {
        type: 'TextBlock',
        wrap: true,
        text: options.text,
      },
    ],
    msteams: {
      width: 'Full',
    },
  }

  const data = {
    type: 'message',
    attachments: [
      {
        contentType: 'application/vnd.microsoft.card.adaptive',
        content: {
          ...card,
        },
      },
    ],
  }

  const postOpts = {
    baseUrl: serviceBindings.eztracTeamsHook,
    path: '',
    body: data,
  }
  yield call(post, postOpts)
}

export default function* () {
  yield* takeLatest([
    actions.teamsError().type,
  ], teamsError)
}
