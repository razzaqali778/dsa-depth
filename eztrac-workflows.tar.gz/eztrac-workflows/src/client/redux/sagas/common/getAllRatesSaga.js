import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import map from 'lodash/map'
import sortBy from 'lodash/sortBy'
import { get } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export function* getAllRatesSaga() {
  const result = yield call(get, {
    baseUrl: serviceBindings.costingServices,
    path: '/v1/rates?isActive=true',
  })


  if ( result.error ) {
    console.error('ERROR in Rate Saga: ', result.error) // eslint-disable-line no-console
  } else {
    const rates = map( result, item => {
      const rate = { key: item.id, value: item.id, label: item.name }

      return rate
    })

    const sortedRates = sortBy(rates, 'label')

    yield dispatch(actions.setAllRateData(sortedRates))
  }
}

export default function* () {
  yield* takeLatest(
    [
      actions.fetchAllRateData().type,
    ],
    getAllRatesSaga,
  )
}
