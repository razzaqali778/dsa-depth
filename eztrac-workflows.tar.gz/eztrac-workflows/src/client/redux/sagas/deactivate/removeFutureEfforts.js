import { all, call, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { del } from '../helpers/network'
import { getFutureEfforts } from '../../selectors'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export const removeFutureEfforts = function* f() {
  const efforts = yield select(getFutureEfforts)
  const calls = efforts.map(effort => {
    const options = {
      baseUrl: serviceBindings.coreServices,
      path: `/v2/efforts/timeframes/${effort.timeFrameId}/team/${effort.teamId}/user/${effort.userId}`,
      body: { percent: parseInt(effort.newPercent, 10) },
      headers: { accept: 'text/plain' },
    }

    return call(del, options)
  })

  const callResult = yield all(calls)

  return callResult
}

export default function* () {
  yield takeLatest([
    actions.deactivatePerson().type,
  ], removeFutureEfforts)
}
