import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { get } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export const fetchDeactivateReasons = function* f() {
  const deactivateReasons = yield call(get, {
    baseUrl: serviceBindings.qcServices,
    path: '/v2/reasons?deactivatable=true',
  })

  yield dispatch(actions.setDeactivateReasons(deactivateReasons))
}

export default function* () {
  yield takeLatest([
    actions.fetchDeactivateReasons().type,
  ], fetchDeactivateReasons)
}
