import { call, put as dispatch, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import Moment from 'moment'
import findIndex from 'lodash/findIndex'
import getOrElse from 'lodash/get'
import has from 'lodash/has'
import actions from '../../actions'
import { serviceBindings } from '../helpers/getServiceBindings'
import { patch, put } from '../helpers/network'
import {
  getCurrentTimeframeId, getCurrentUserId, getSelectedPerson, getSelectedReason,
} from '../../selectors'
import saveEfforts from '../common/saveEfforts'

const handleErrors = function* f({
  response,
  deactivateResponse,
  updateReasonResponse,
  effortResult,
  selectedPerson,
  currentUserId,
}) {
  const makeError = (title, error) => {
    const { error: { method, url, status } } = error

    return ({
      title,
      value: `method: ${method}\nurl: ${url}\ntext: ${status}`,
    })
  }

  const errors = [
    ...!response.deactivate
      ? [ makeError('Error deactivating to cost calc', deactivateResponse.error) ] : [],
    ...!response.reason
      ? [ makeError('Error saving reason to QC', updateReasonResponse.error) ] : [],
    ...!response.efforts && effortResult
      ? effortResult.map(r => r.error ? makeError('Error updating effort', r.error) : null).filter(d => d) : [],
  ]

  const uiUrls = window.phoenix.urls.ui
  const costingUi = uiUrls['ez-trac-costing']
  const qcUi = uiUrls['ez-trac-qc']
  const ezUi = uiUrls['ez-trac-original']

  const successes = [
    ...response.deactivate
      ? [{ title: 'Undo deactivating in cost calc', value: `<${costingUi}/people?personId=${selectedPerson}|Cost Calc>` }] // eslint-disable-line max-len
      : [],
    ...response.reason
      ? [{
        title: 'Undo reason in QC',
        value: `<${qcUi}/participation?q=${selectedPerson}&showWithReasons=true|QC>`,
      }] : [],
    ...response.efforts && effortResult ? effortResult.map(
      ({
        error, timeFrameId: effortTimeframeId, teamId, userId, percent,
      }) => !error
        ? {
          title: 'Reset Effort',
          value: `<${ezUi}/#/effort?team=${teamId}&timeframe=${effortTimeframeId}|Effort Screen> for User ${userId} to ${percent}`, // eslint-disable-line max-len
        } : null,
    ).filter(d => d) : [],
  ]

  const fields = [
    ...errors,
    ...successes,
  ]

  const error = `step: 'deactivate', title: 'Workflows encountered an error deactivating ${selectedPerson} -- Logged in user: ${currentUserId}', ${fields}`// eslint-disable-line max-len

  yield dispatch(actions.teamsError(error))
}
export const deactivatePerson = function* f() {
  const selectedPerson = yield select(getSelectedPerson)
  const selectedReason = yield select(getSelectedReason)
  const timeFrameId = yield select(getCurrentTimeframeId)
  const currentUserId = yield select(getCurrentUserId)

  const putOpts = {
    baseUrl: serviceBindings.qcServices,
    path: '/v1/qc/discrepancy',
    body: {
      timeFrameId,
      userId: selectedPerson,
      reason: selectedReason,
      updatedTime: new Moment().format('x'),
      updatedUserId: currentUserId,
    },
  }

  const patchOpts = {
    baseUrl: serviceBindings.costingServices,
    path: `/v1/person/${selectedPerson}`,
    body: { isActive: false },
    headers: { accept: 'text/plain' },
  }
  const updateReasonResponse = yield call(put, putOpts)
  const deactivateResponse = yield call(patch, patchOpts)

  const effortResult = yield call(saveEfforts)

  const effortErrorIndex = findIndex(effortResult, 'error')

  const response = {
    deactivate: {
      hasError: has(deactivateResponse, 'error'),
      message: getOrElse(deactivateResponse, 'error.statusText', 'OK'),
    },
    reason: {
      hasError: has(updateReasonResponse, 'error'),
      message: getOrElse(updateReasonResponse, 'error.statusText', 'OK'),
    },
    efforts: {
      hasError: effortErrorIndex !== -1,
      message: getOrElse(effortResult, `[${effortErrorIndex}].error.statusText`, 'OK'),
    },
  }

  if ( !response.deactivate || !response.reason || !response.efforts ) {
    yield* handleErrors({
      response,
      deactivateResponse,
      updateReasonResponse,
      effortResult,
      selectedPerson,
      currentUserId,
    })
  }
  // TODO uncomment after fixing https://monsanto.aha.io/features/PT1-281
  /* else {
    yield dispatch(actions.sendDeactivateMessage())
  } */

  yield dispatch(actions.setDeactivationResults(response))
}

export default function* () {
  yield takeLatest([
    actions.deactivatePerson().type,
  ], deactivatePerson)
}
