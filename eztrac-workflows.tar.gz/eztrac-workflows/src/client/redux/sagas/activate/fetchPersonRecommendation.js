import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import isEmpty from 'lodash/isEmpty'
import { get } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

export const fetchPersonRecommendation = function* f({ payload }) {
  yield dispatch(actions.setSelectedPersonSuggestionLoading(true))

  const suggestion = yield call(get, {
    baseUrl: serviceBindings.suggestionService,
    path: `/v1/people/user/${payload.value}`,
  })

  if ( suggestion.error || isEmpty(suggestion) ) {
    console.error( 'NO SUGGESTION: ', suggestion ) // eslint-disable-line no-console
    const personWithUnknownSuggestion = {
      ...payload,
      rateName: 'Unknown',
      costGroupName: 'Unknown',
      id: payload.value,
    }

    yield dispatch(actions.setSelectedPersonWithSuggestion(personWithUnknownSuggestion))
  } else {
    const personWithSuggestion = {
      ...payload,
      ...suggestion[0],
    }

    yield dispatch(actions.setSelectedCostGroup( { label: suggestion[0].costGroupName } ))
    yield dispatch(actions.setSelectedRate( { label: suggestion[0].rateName } ))
    yield dispatch(actions.setSelectedPersonWithSuggestion(personWithSuggestion))
  }

  yield dispatch(actions.setSelectedPersonSuggestionLoading(false))
}

export default function* () {
  yield* takeLatest([
    actions.fetchPersonSuggestion().type,
  ], fetchPersonRecommendation)
}
