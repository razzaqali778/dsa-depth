import {
  all, call, put as dispatch, select,
} from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import findIndex from 'lodash/findIndex'
import getOrElse from 'lodash/get'
import isUndefined from 'lodash/isUndefined'
import map from 'lodash/map'
import {
  getAddSelectedPerson,
  getCurrentEfforts,
  getCurrentTimeframeId,
  getCurrentUserId,
  getSelectedCostGroup,
  getSelectedRate,
} from '../../selectors'
import { getNewEffortsTotal } from '../../selectors/common/getEffortTotals'
import { put } from '../helpers/network'
import { serviceBindings } from '../helpers/getServiceBindings'
import actions from '../../actions'

const handleErrors = function* f({
  done,
  userId: currentUser,
  selectedPerson,
  costingResult,
  currentEfforts,
  effortResults,
  currentTimeframe,
}) {
  const makeError = (title, error = {}) => {
    const { method, url, status } = error.error || error

    return ({
      title,
      value: `method: ${method}\nurl: ${url}\ntext: ${status}`,
    })
  }

  const effortMapFunc = (result, idx) => {
    const { teamId, newPercent, teamName } = currentEfforts[idx]

    return result === null
      ? { teamId, newPercent, teamName }
      : result
  }

  const effortResult = map(effortResults, effortMapFunc)

  const errors = [
    ...done.person.hasError
      ? [ makeError('Error activating to cost calc', costingResult.error) ] : [],
    ...done.efforts.hasError && effortResults
      ? effortResults.map(r => r.error ? makeError('Error updating effort', r.error) : null).filter(d => d) : [],
  ]

  const uiUrls = window.phoenix.urls.ui
  const costingUi = uiUrls['ez-trac-costing']
  const ezUi = uiUrls['ez-trac-original']

  const successes = [
    ...done.person.hasError
      ? []
      : [{ title: 'Undo activating in cost calc', value: `<${costingUi}/people?personId=${selectedPerson}|Cost Calc>` }], // eslint-disable-line max-len
    ...done.efforts.hasError
      ? []
      : effortResult.map(
        ({ error, teamId, teamName }) => !error
          ? {
            title: `Remove From Effort for ${teamName}`,
            value: `<${ezUi}/#/effort?team=${teamId}&timeframe=${currentTimeframe}|Effort Screen> for User ${selectedPerson.label}`, // eslint-disable-line max-len
          } : null,
      ).filter(d => d),
  ]


  const fields = [
    ...errors,
    ...successes,
  ]

  const error = {
    step: 'activate',
    title: `Workflows encountered an error activating ${selectedPerson.label} -- Logged in user: ${currentUser}`,
    fields,
  }

  yield dispatch(actions.teamsError(error))
}

export const addPerson = function* f() { // eslint-disable-line max-statements
  yield dispatch(actions.setSelectedPersonSuggestionLoading(true))

  const selectedPerson = yield select(getAddSelectedPerson)
  const selectedCostGroup = yield select(getSelectedCostGroup)
  const selectedRate = yield select(getSelectedRate)
  const userId = yield select(getCurrentUserId)

  const payload = {
    personId: selectedPerson.id,
    personName: selectedPerson.fullName,
    rateName: selectedRate.label,
    costGroupName: selectedCostGroup.label,
    isEmployee: (selectedPerson.employeeType === 'Employee'),
    isActive: true,
    modifiedBy: userId,
  }

  const totalPercent = yield select(getNewEffortsTotal)
  const currentTimeframe = yield select(getCurrentTimeframeId)
  const currentEfforts = yield select(getCurrentEfforts)

  const costingResult = yield call(put, {
    baseUrl: serviceBindings.costingServices,
    path: '/v1/person',
    body: payload,
  })

  const effortCalls = currentEfforts.map(effort => call(put, {
    baseUrl: serviceBindings.coreServices,
    path: `/v2/efforts/timeframes/${currentTimeframe}/team/${effort.teamId}/user/${selectedPerson.id}`,
    body: { percent: parseInt(effort.newPercent, 10) },
    headers: { accept: 'text/plain' },
  }))

  const allResult = yield all(effortCalls)
  // The result returns null if successful
  const effortErrorIndex = findIndex(allResult, r => r !== null)
  const teams = currentEfforts.map(effort => effort.label).join(', ')

  const done = {
    person: {
      hasError: !isUndefined(costingResult.error),
      message: costingResult.error
        ? `Unable to add ${selectedPerson.fullName} to Costing Engine.\n${getOrElse(costingResult, 'error.statusText', '')}` // eslint-disable-line max-len
        : `Added ${selectedPerson.fullName} to Costing Engine.`,
    },
    efforts: {
      hasError: effortErrorIndex > -1,
      message: effortErrorIndex > -1
        ? `Unable to add ${selectedPerson.fullName} to ${teams} with a percentage of ${totalPercent}%.\n${getOrElse(allResult, `[${effortErrorIndex}].error.statusText`, '')}` // eslint-disable-line max-len
        : `Added ${selectedPerson.fullName} to ${teams} with a percentage of ${totalPercent}%.`,
    },
  }

  if ( done.person.hasError || done.efforts.hasError ) {
    yield* handleErrors({
      done,
      userId,
      selectedPerson,
      costingResult,
      currentEfforts,
      effortResults: allResult,
      currentTimeframe,
    })
  }

  if ( !costingResult.error ) {
    yield dispatch(actions.sendTask())
  }

  yield dispatch(actions.setAddPersonResult(done))
  yield dispatch(actions.setSelectedPersonSuggestionLoading(false))
}

export default function* () {
  yield* takeLatest([
    actions.addPerson().type,
  ], addPerson)
}
