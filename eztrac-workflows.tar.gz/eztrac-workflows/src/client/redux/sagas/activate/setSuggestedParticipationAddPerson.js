import { put as dispatch, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { getSuggestedEffortsAddPerson } from '../../selectors/common/getFractionWorked'
import actions from '../../actions'

export const setSuggestedParticipationAddPerson = function* f() {
  // dispatch reset
  const fractionWorkedAddPerson = yield select(getSuggestedEffortsAddPerson)
  const updatedAddPersonEfforts = Math.round(fractionWorkedAddPerson * 100)

  yield dispatch(actions.setPercent(updatedAddPersonEfforts))
}

export default function* () {
  yield takeLatest([
    actions.setParticipation().type,
  ], setSuggestedParticipationAddPerson)
}
