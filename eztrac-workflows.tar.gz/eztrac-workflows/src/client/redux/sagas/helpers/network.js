import superagent from 'superagent'

function makeNetworkCall(method, globalHeaders = {}) {
  return async ({
    baseUrl = '',
    body,
    headers = {},
    path,
  }) => {
    const finalUrl = typeof baseUrl === 'function' ? baseUrl() : baseUrl + path
    try {
      const result = await superagent[method](finalUrl)
        .set({ ...globalHeaders, ...headers })
        .send(body)
        .then(response => response.body)

      return result
    } catch ( error ) {
      return { error: error.response || error }
    }
  }
}

const wrapMakeNetworkCall = method => {
  const networkCall = makeNetworkCall(method)

  return options => networkCall({
    ...options,
    headers: {
      accept: options.headers ? options.headers.accept : 'application/json',
      ...phoenix.authHeader && phoenix.authHeader(), // eslint-disable-line
    },
  })
}

export const get = wrapMakeNetworkCall('get')
export const del = wrapMakeNetworkCall('del')
export const post = wrapMakeNetworkCall('post')
export const patch = wrapMakeNetworkCall('patch')
export const put = wrapMakeNetworkCall('put')
