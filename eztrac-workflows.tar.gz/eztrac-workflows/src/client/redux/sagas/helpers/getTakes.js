import { select, take } from 'redux-saga/effects'
import {
  getCurrentTimeframe as currentTimeframeSelector,
  getNextTimeframe as nextTimeframeSelector,
} from '../../selectors'
import actions from '../../actions'

const isEmpty = obj => Object.values(obj) < 1

export const getCurrentTimeframe = function* f() {
  if ( isEmpty(yield select(currentTimeframeSelector)) ) {
    yield take(actions.setCurrentTimeframe().type)
  }

  return yield select(currentTimeframeSelector)
}

export const getNextTimeframe = function* f() {
  if ( isEmpty(yield select(nextTimeframeSelector)) ) {
    yield take(actions.setNextTimeframe().type)
  }

  return yield select(nextTimeframeSelector)
}
