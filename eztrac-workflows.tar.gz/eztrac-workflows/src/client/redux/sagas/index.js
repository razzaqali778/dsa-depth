import { fork } from 'redux-saga/effects'
import addPersonListener from './activate/addPerson'
import deactivatePersonListener from './deactivate/deactivatePerson'
import fetchAllTeamsSaga from './common/fetchAllTeamsSaga'
import fetchDeactivateReasonsSaga from './deactivate/fetchDeactivateReasonsSaga'
import fetchEffortForUserListener from './common/fetchEffortForUser'
import fetchHealthCheck from './common/fetchHealthCheck'
import fetchNonEzTracPapiPeople from './common/fetchNonEzTracPapiPeopleSaga'
import fetchPeopleSaga from './common/fetchPeopleSaga'
import fetchPersonRecommendation from './activate/fetchPersonRecommendation'
import fetchTimeframes from './common/fetchTimeframes'
import fetchUser from './common/fetchUser'
import getAllCostGroupsSaga from './common/getAllCostGroupsSaga'
import getAllRatesSaga from './common/getAllRatesSaga'
import removeFutureEffortsListener from './deactivate/removeFutureEfforts'
import resetStepperSaga from './common/resetStepperSaga'
import sendTask from './common/sendTask'
import setSuggestedParticipation from './common/setSuggestedParticipation'
import setSuggestedParticipationAddPerson from './activate/setSuggestedParticipationAddPerson'
import teamsErrorSaga from './common/teamsErrorSaga'
import teamsMessage from './common/teamsMessage'

export default function* main() { //eslint-disable-line
  yield fork(addPersonListener)
  yield fork(deactivatePersonListener)
  yield fork(fetchEffortForUserListener)
  yield fork(fetchHealthCheck)
  yield fork(fetchAllTeamsSaga)
  yield fork(fetchPeopleSaga)
  yield fork(fetchTimeframes)
  yield fork(fetchUser)
  yield fork(getAllCostGroupsSaga)
  yield fork(getAllRatesSaga)
  yield fork(setSuggestedParticipation)
  yield fork(setSuggestedParticipationAddPerson)
  yield fork(removeFutureEffortsListener)
  yield fork(fetchNonEzTracPapiPeople)
  yield fork(fetchPersonRecommendation)
  yield fork(sendTask)
  yield fork(resetStepperSaga)
  yield fork(fetchDeactivateReasonsSaga)
  yield fork(teamsMessage)
  yield fork(teamsErrorSaga)
}
