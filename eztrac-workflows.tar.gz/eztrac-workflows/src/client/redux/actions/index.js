import { isUndefined, omitBy, values } from 'lodash'
import {
  addSelections as addConstants,
  costGroupsRates as costGroupsRatesConstants,
  deactivateSelections as deactivateConstants,
  efforts as effortsConstants,
  error as errorConstants,
  healthCheck as healthCheckConstants,
  people as peopleConstants,
  resetWorkflow as resetWorkflowConstants,
  stepper as stepperConstants,
  teams as teamsConstants,
  timeframes as timeframeConstants,
  user as userConstants,
} from '../constants'

const keyify = input => {
  const baseName = input.substring(input.lastIndexOf('/') + 1)

  return baseName
    .toLowerCase()
    .replace(/_([a-z])/g, (_, match) => match.toUpperCase())
}

const makeActions = constants => values(constants).reduce(
  (actions, type) => ({
    ...actions,
    [keyify(type)]: (payload, meta, error) => omitBy({
      error, meta, payload, type,
    }, isUndefined),
  }),
  {},
)

export const costGroupsRates = makeActions(costGroupsRatesConstants)
export const people = makeActions(peopleConstants)
export const deactivateSelections = makeActions(deactivateConstants)
export const addSelections = makeActions(addConstants)
export const efforts = makeActions(effortsConstants)
export const resetWorkflow = makeActions(resetWorkflowConstants)
export const stepper = makeActions(stepperConstants)
export const timeframes = makeActions(timeframeConstants)
export const user = makeActions(userConstants)
export const teams = makeActions(teamsConstants)
export const error = makeActions(errorConstants)
export const healthCheck = makeActions(healthCheckConstants)

export default {
  ...addSelections,
  ...costGroupsRates,
  ...people,
  ...deactivateSelections,
  ...efforts,
  ...healthCheck,
  ...resetWorkflow,
  ...stepper,
  ...timeframes,
  ...user,
  ...teams,
  ...error,
}
