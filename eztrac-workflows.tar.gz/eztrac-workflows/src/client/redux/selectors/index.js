export const getAllPeople = state => state.people.allPeople

export const getSelectedPerson = state => state.deactivateSelections.selectedPerson

export const getAddSelectedPerson = state => state.addSelections.selectedPerson

export const getSelectedReason = state => state.deactivateSelections.selectedReason

export const getStartDate = state => state.addSelections.startDate
export const getEndDate = state => state.deactivateSelections.endDate
export const getPercent = state => state.addSelections.percent

export const getCurrentEfforts = state => state.efforts.current
export const getFutureEfforts = state => state.efforts.next

export const getCurrentTimeframe = state => state.timeframes.currentTimeframe
export const getCurrentTimeframeId = state => state.timeframes.currentTimeframe.id

export const getNextTimeframe = state => state.timeframes.nextTimeframe

export const getAllTimeframes = state => state.timeframes.allTimeframes

export const getCurrentUserId = state => state.user.id
export const getCurrentUserName = state => state.user.preferredName.full
export const getPage = state => state.page

export const getEffortsLoading = state => state.efforts.loading
export const getSelectedPersonSuggestionLoading = state => state.addSelections.suggestionLoading

export const getSelectedTeam = state => state.teams.selectedTeams[0]
export const getTeams = state => state.teams.teams
export const getSelectedCostGroup = state => state.costGroupsRates.selectedCostGroup
export const getSelectedRate = state => state.costGroupsRates.selectedRate

export const getReasons = state => state.deactivateSelections.deactivateReasons

export const getHealthCheck = state => state.healthCheck.healthCheck

export const getPreviousSite = state => state.deactivateSelections.previousSite
