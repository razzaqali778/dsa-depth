import { createSelector } from 'reselect'
import reduce from 'lodash/reduce'
import { getCurrentEfforts } from '..'

export const getOriginalEffortsTotal = createSelector(
  getCurrentEfforts,
  effortsList => reduce(effortsList, (sum, val) => sum + parseInt(val.percent, 10), 0),
)

export const getNewEffortsTotal = createSelector(
  getCurrentEfforts,
  effortsList => reduce(effortsList, (sum, val) => sum + parseInt(val.newPercent, 10), 0),
)
