import { createSelector } from 'reselect'
import find from 'lodash/find'
import getOrElse from 'lodash/get'
import { getAllPeople, getSelectedPerson } from '..'

const selector = createSelector( getAllPeople, getSelectedPerson, ( people, selectedPerson ) => {
  const foundPerson = find(people, person => person.personId === selectedPerson)

  return getOrElse(foundPerson, 'personName', selectedPerson)
})

export default selector
