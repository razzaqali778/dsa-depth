import { createSelector } from 'reselect'
import inRange from 'lodash/inRange'
import reduce from 'lodash/reduce'
import { getCurrentEfforts } from '..'

export const singleEffortValidation = createSelector(
  getCurrentEfforts,
  effortList => !(effortList.some(({ errorText }) => errorText && errorText !== '')),
)

export const totalEffortValidation = createSelector( getCurrentEfforts, effortsList => {
  const totalValues = reduce(effortsList, (sum, val) => sum + parseInt(val.newPercent, 10), 0)

  return inRange(totalValues, 101)
})
