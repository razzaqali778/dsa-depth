import { createSelector } from 'reselect'
import { getSelectedPerson } from '..'
import getPersonName from './getPersonName'

export default createSelector(
  getPersonName,
  getSelectedPerson,
  (name, id) => name && id ? ({ value: id, label: name }) : null,
)
