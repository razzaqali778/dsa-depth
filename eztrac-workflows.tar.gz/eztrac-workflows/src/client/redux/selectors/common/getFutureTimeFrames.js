import { createSelector } from 'reselect'
import { getAllTimeframes, getCurrentTimeframe } from '..'

const selector = createSelector(
  getAllTimeframes,
  getCurrentTimeframe,
  (allTimeframes, currentTimeframes) => allTimeframes.length ? allTimeframes.filter(
    timeframe => timeframe.startDate > currentTimeframes.startDate,
  ) : [],
)

export default selector
