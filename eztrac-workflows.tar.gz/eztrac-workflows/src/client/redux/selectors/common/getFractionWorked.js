import { createSelector } from 'reselect'
import Moment from 'moment-business-days'
import { getCurrentTimeframe, getEndDate, getStartDate } from '..'
import { getOriginalEffortsTotal } from './getEffortTotals'


export const getSuggestedEffortsAddPerson = createSelector(
  getStartDate,
  startDate => {
    const startDateDate = new Date(startDate)
    const startDateMoment = new Moment({
      year: startDateDate.getFullYear(),
      month: startDateDate.getMonth(),
      date: startDateDate.getDate(),
    })

    const monthBusinessDays = startDateMoment.monthBusinessDays()
    const businessDayCount = monthBusinessDays.length
    const daysToEnd = startDateMoment.businessDiff(monthBusinessDays[businessDayCount - 1])
    const percentWorked = (daysToEnd) / businessDayCount

    return percentWorked
  },
)

export const getSuggestedEfforts = createSelector(
  getCurrentTimeframe,
  getEndDate,
  getOriginalEffortsTotal,
  (currentTimeframe, endDate, effortTotal) => {
    if ( effortTotal === 100 ) {
      const monthEnd = new Moment(currentTimeframe.endDate)
      const lastDay = new Moment(endDate)
      const daystoEnd = monthEnd.businessDiff(lastDay) - 1
      const daysInMonth = monthEnd.monthBusinessDays().length
      const percentWorked = (daysInMonth - daystoEnd) / daysInMonth

      return percentWorked
    }

    return 1
  },
)


export default {
  getSuggestedEfforts,
  getSuggestedEffortsAddPerson,
}
