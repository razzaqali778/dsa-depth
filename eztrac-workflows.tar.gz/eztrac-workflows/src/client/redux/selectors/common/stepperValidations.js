import { createSelector } from 'reselect'
import { getSelectedPerson, getSelectedReason } from '..'

export const isPersonSelected = createSelector(getSelectedPerson, selectedPerson => selectedPerson !== null)

export const isReasonSelected = createSelector(getSelectedReason, selectedReason => selectedReason !== null)
