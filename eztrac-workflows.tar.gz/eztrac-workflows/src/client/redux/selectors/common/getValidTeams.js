import { createSelector } from 'reselect'
import differenceBy from 'lodash/differenceBy'
import { getCurrentEfforts, getTeams } from '..'

export const getValidTeams = createSelector( getTeams, getCurrentEfforts, (teams, efforts) => {
  const validTeams = differenceBy(teams, efforts, 'label')

  return validTeams
})
