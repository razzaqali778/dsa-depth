import { createSelector } from 'reselect'
import { getAllPeople } from '..'

const selector = createSelector(
  getAllPeople,
  peopleList => peopleList.map(({ personId, personName }) => ({
    value: personId,
    label: personName,
  })),
)

export default selector
