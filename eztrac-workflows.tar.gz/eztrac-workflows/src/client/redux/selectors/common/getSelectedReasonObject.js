import { createSelector } from 'reselect'
import { getSelectedReason } from '..'

export default createSelector(
  getSelectedReason,
  reason => reason ? ({ value: reason, label: reason }) : null,
)
