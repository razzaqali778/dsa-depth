import { createSelector } from 'reselect'
import isEmpty from 'lodash/isEmpty'
import { ADD_PERSON_WORKFLOW, DEACTIVATE_WORKFLOW, LOCKDOWN } from '../../constants/pages'
import {
  getAllPeople, getCurrentTimeframe, getEffortsLoading, getPage, getSelectedPersonSuggestionLoading,
} from '..'

export default createSelector(
  getAllPeople,
  getPage,
  getEffortsLoading,
  getSelectedPersonSuggestionLoading,
  getCurrentTimeframe,
  (people, page, effortsLoading, selectedPersonSuggestionLoading, currentTimeframe) => {
    switch ( page ) {
      case DEACTIVATE_WORKFLOW: return isEmpty(people) || effortsLoading
      case ADD_PERSON_WORKFLOW: return isEmpty(people) || selectedPersonSuggestionLoading
      case LOCKDOWN: return isEmpty(currentTimeframe)
      default: return false
    }
  },

)
