import { createSelector } from 'reselect'
import map from 'lodash/map'
import {
  getReasons,
} from '..'

const getReasonSelectOptions = createSelector(
  getReasons,
  reasons => map(reasons, ({ reasonName }) => ({
    label: reasonName,
    value: reasonName,
  })),
)

export default getReasonSelectOptions
