import { applyMiddleware, compose, createStore } from 'redux'
import { connectRoutes } from 'redux-first-router'
import queryString from 'query-string'
import { loadState } from '../localStorage'
import makeMiddleware, { runSagas } from './middleware'
import makeReducers from './reducers'
import routesMap from './routesMap'

const createHistory = require('history').createBrowserHistory

const history = createHistory()
const { reducer, middleware, enhancer } = connectRoutes(history, routesMap, { querySerializer: queryString })

const reducers = makeReducers(reducer)

const persistedState = loadState()
const makeStore = () => {
  const store = createStore(
    reducers,
    compose(
      enhancer,
      applyMiddleware(middleware, ...makeMiddleware),
      window.devToolsExtension ? window.devToolsExtension() : f => f,
    ),
    persistedState,
  )

  runSagas()

  return store
}

export default makeStore
