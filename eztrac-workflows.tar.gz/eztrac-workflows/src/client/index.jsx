import { Provider } from 'react-redux'
import { render } from 'react-dom'
import React from 'react'
import navbar from '@bayerit/phoenix-navbar'
import AppContainer from './containers/AppContainer'
import makeStore from './redux'

navbar.install({
  element: document.querySelector('.nav'),
  suiteId: 'pe-admin',
  productId: 'ez-trac',
  cookieName: 'ez-trac-qc',
})
  .then(() => {
    const store = makeStore()

    render(
      <Provider store={store}>
        <AppContainer />
      </Provider>,
      document.getElementById('root'),
    )
  })
  .catch(err => {
    // Errors thrown as part of installation will likely be from invalid
    // auth tokens. Be sure to run a local ocelot instance to avoid this.
    console.error(err) // eslint-disable-line no-console
  })
