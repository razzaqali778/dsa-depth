import { isEmpty } from 'lodash'
import React from 'react'
import SaveToXlsxButton from '../containers/Common/SaveToXlsxButton'

const formatCsvWithArray = csvData => {
  const formattedData = csvData.map(obj => ({
    ...obj,
    errors: obj.errors.join(', '),
  }))

  return formattedData
}

const isDifferentTimeframeSelected = (selectedTimeframe, selectedData) => (
  selectedTimeframe
  && (isEmpty(selectedData) || selectedData[0].timeFrameName !== selectedTimeframe.name)
)

export const renderDownloadButton = (selectedTimeframe, selectedData) => (
  isDifferentTimeframeSelected(selectedTimeframe, selectedData)
    ? (
      <div className="loadingDataTxt">
        <div className="velocity-spinner-container">
          <i className="velocity-spinner-small-inline" />
        </div>
      </div>
    )
    : (
      <SaveToXlsxButton
        csvData={formatCsvWithArray(selectedData)}
        fileName="HealthCheck"
      />
    )
)
