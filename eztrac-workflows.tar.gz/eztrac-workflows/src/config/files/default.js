const config = {
  'velocity-home': { value: 'velocity-np.ag' },
  'peadmin-home': { value: 'peadmin-np.monsanto.net' },
  'phoenix-home': { value: 'phoenix-tools-np.io', env: 'NonProd' },
  'ez-trac-urls': {
    ui: {
      'ez-trac-workflows': 'https://peadmin-np.monsanto.net/ez-trac-workflows',
      'ez-trac-costing': 'https://peadmin-np.monsanto.net/ez-trac-costing',
      'ez-trac-qc': 'https://peadmin-np.monsanto.net/ez-trac-qc',
    },
    services: {
      'ez-trac-costing': 'https://ez-trac-costing-services.velocity-np.ag',
      'ez-trac-suggestion': 'https://ez-trac-suggestion.velocity-np.ag',
      'ez-trac-core': 'https://ez-trac-core-services.velocity-np.ag',
      'ez-trac-qc': 'https://ez-trac-qc-services.velocity-np.ag/ez-trac-qc/services',
    },
  },
  syslog: '',
  'messaging-url': { value: 'https://messaging.velocity-np.ag' },
  'ez-trac-teams-hook': {
    value: 'vault://secret/ez-trac/teams/alerts-np/url',
  },
  'workforce-approle': {
    role_name: 'workforce-dev-admins-eztrac-np',
  },
}

module.exports = config
