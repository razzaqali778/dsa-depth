const _ = require('lodash')
const defaultConfig = require('./default')

module.exports = _.merge(defaultConfig, {
  'velocity-home': { value: 'velocity.ag' },
  'peadmin-home': { value: 'peadmin.monsanto.net' },
  'phoenix-home': { value: 'phoenix-tools.io', env: 'Prod' },
  'ez-trac-urls': {
    ui: {
      'ez-trac-workflows': 'https://peadmin.monsanto.net/ez-trac-workflows',
      'ez-trac-costing': 'https://peadmin.monsanto.net/ez-trac-costing',
      'ez-trac-qc': 'https://peadmin.monsanto.net/ez-trac-qc',
    },
    services: {
      'ez-trac-costing': 'https://ez-trac-costing-services.velocity.ag',
      'ez-trac-suggestion': 'https://ez-trac-suggestion.velocity.ag',
      'ez-trac-core': 'https://ez-trac-core-services.velocity.ag',
      'ez-trac-qc': 'https://ez-trac-qc-services.velocity.ag/ez-trac-qc/services',
    },
  },
  syslog: '',
  'messaging-url': { value: 'https://messaging.velocity.ag' },
  'ez-trac-teams-hook': {
    value: 'vault://secret/ez-trac/teams/alerts-prod/url',
  },
  'workforce-approle': {
    role_name: 'workforce-dev-admins-eztrac-prod',
  },
})
