const {
  Config, source, processor, env,
} = require('@bayerit/config')
const _ = require('lodash')

const determineEnvironmentFileName = () => {
  if ( !_.isEmpty(process.env.DEPLOYABLE_ENV) ) {
    return process.env.DEPLOYABLE_ENV
  }

  return process.env.NODE_ENV || 'default'
}

// GitHub Actions EKS runners cannot assume workforce-dev-admins-eztrac-np.
// Resolve vault:// secrets in CI via other_vault env injection instead.
const isCi = Boolean(process.env.CI || process.env.GITHUB_ACTIONS)

const config = new Config({
  sources: [
    source.fromJS({ src: `${__dirname}/files/${determineEnvironmentFileName()}` }),
  ],
  processors: [
    processor.readVaultFromConfig({
      enabled: env.inDevelopment,
      auth: { type: 'local' },
    }),
    processor.readVaultFromConfig({
      enabled: env.inProduction && !isCi,
      auth: {
        type: 'awsRole',
        roleName: { inConfig: 'workforce-approle.role_name' },
      },
    }),
  ],
  required: [],
})

module.exports = config
