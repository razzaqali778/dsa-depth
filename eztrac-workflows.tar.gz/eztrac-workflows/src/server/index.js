const express = require('express')
const fs = require('fs')
const bindingsMiddleware = require('@bayerit/phoenix-service-bindings-middleware')
const { generateHtmlMiddleware } = require('@bayerit/phoenix-html-middleware')
const config = require('../config')


const app = express()
const baseUrl = '/ez-trac-workflows'

if ( process.env.NODE_ENV !== 'production' ) {
  /* eslint-disable global-require, import/newline-after-import */
  const webpack = require('webpack')
  const configWebpack = require('../../webpack.dev.config')
  const compiler = webpack(configWebpack)
  const webpackDevMiddleware = require('webpack-dev-middleware')
  const middlewareOptions = {
    publicPath: `${baseUrl}/scripts/`,
  }

  app.use(webpackDevMiddleware(compiler, middlewareOptions))
}

const defaultClientBindings = config.config
const ezTracUrls = config.get('ez-trac-urls')
const serviceBindingsRouter = bindingsMiddleware(defaultClientBindings, { localOcelot: true, urls: ezTracUrls })
app.use(`${baseUrl}/service-bindings`, serviceBindingsRouter)

const css = '//static-assets.velocity.ag/styles/1.0.0/velocity.css'

app.get(`${baseUrl}*`, ( req, res ) => res.send(`
    <!doctype html>
    <html>
      <head>
        <title>EZ-Trac Workflows</title>
        <link rel="stylesheet" type="text/css" href="https://phoenix-tools.io/assets/cached/peadmin/styles/navbar.css">
        <link rel="stylesheet" type="text/css" href="https://phoenix-tools.io/assets/cached/peadmin/styles/mat1.1.1.css">
        <link rel="stylesheet" type="text/css" href="${css}">
        <link rel="stylesheet" type="text/css" href="${baseUrl}/styles/style.css">
      </head>
      <body>
        <div class="nav"></div>
        <div id="root"></div>
        <script src="${baseUrl}/service-bindings"></script>
        <script src="${baseUrl}/scripts/bundle.js"></script>
      </body>
    </html>
  `))

function checkFileExistsSync(filepath) {
  let flag = true
  try {
    fs.accessSync(filepath, fs.constants.F_OK)
  } catch ( e ) {
    flag = false
  }

  return flag
}

if ( !fs.existsSync('./public') ) {
  fs.mkdirSync('./public')
}

const htmlOptions = {
  defaultSuite: 'velocity',
  lightningExpress: true,
}

const generateIndex = async (req, res) => {
  await generateHtmlMiddleware(
    baseUrl,
    'ez-trac-workflows',
    [ 'cookie' ],
    htmlOptions,
  )(req, res)

  const indexFile = './public/index.html'

  if ( global.indexHtml !== 'undefined' && !checkFileExistsSync(indexFile) ) {
    fs.writeFileSync(indexFile, global.indexHtml)
  }
}

app.get('/*', generateIndex)


const port = process.env.PORT || 3032
const server = app.listen(port, () =>
  console.log( // eslint-disable-line
    `Listening at http://${server.address().host || 'localhost'}:${port}${baseUrl}`,
  ))

module.exports = server

