require('@babel/register')
require('dotenv').config()
const config = require('./src/config')

config
  .init()
  .then(() => require('./src/server'))
  .catch((err) => {
    console.error('Error: ', err)
    process.exit()
  })
