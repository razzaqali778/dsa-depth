import superagent from 'superagent'
import { lockdownAction } from '../../../src/client/actions/admin/lockdownAction'

describe('lockdown ez trac', () => {
  beforeEach(() => {
    superagent.put = jest.fn().mockReturnValue({
      set: () => {},
    })
    superagent.patch = jest.fn().mockReturnValue({
      set: () => ({ send: () => {} }),
    })
  })

  it('executes the correct functions on lockdown action', async () => {
    await lockdownAction(true, 1)
    expect(superagent.patch).toHaveBeenCalledTimes(1)
    expect(superagent.put).toHaveBeenCalledTimes(2)
  })

  it('executes the correct functions on unlock action', async () => {
    await lockdownAction(false, 1)
    expect(superagent.patch).toHaveBeenCalledTimes(1)
    expect(superagent.put).toHaveBeenCalledTimes(0)
  })
})
