import superagent from 'superagent'
import { recalculateCostsAction } from '../../../src/client/actions/admin/recalculateCostsAction'

describe('recalculate costs', () => {
  it('executes the correct functions on recalculate action', async () => {
    superagent.put = jest.fn().mockReturnValue({})
    await recalculateCostsAction()
    expect(superagent.put).toHaveBeenCalledTimes(1)
  })

  it('returns error object when http call fails', async () => {
    const errorMessage = 'test error'
    superagent.put = jest.fn().mockImplementation(() => {
      throw new Error(errorMessage)
    })
    const result = await recalculateCostsAction()
    expect(result.status).toBe(false)
    expect(result.error.message).toBe(errorMessage)
  })
})
