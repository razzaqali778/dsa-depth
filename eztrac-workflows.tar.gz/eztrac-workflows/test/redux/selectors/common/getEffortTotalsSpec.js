import {
  getNewEffortsTotal,
  getOriginalEffortsTotal,
} from '../../../../src/client/redux/selectors/common/getEffortTotals'

describe('getEffortsTotal', () => {
  it('returns the sum of original efforts correctly using getOringinalEffortsTotal', () => {
    const mockState = {
      efforts: {
        current: [{ percent: 50, newPercent: 25 }, { percent: 20, newPercent: 40 }],
        next: [],
      },
    }

    const actual = getOriginalEffortsTotal(mockState)

    expect(actual).toEqual(70)
  })
  it('returns the sum of new efforts correctly using getNewEffortsTotal', () => {
    const mockState = {
      efforts: {
        current: [{ percent: 50, newPercent: 25 }, { percent: 20, newPercent: 40 }],
        next: [],
      },
    }

    const actual = getNewEffortsTotal(mockState)

    expect(actual).toEqual(65)
  })
  it('returns a placeholder using getNewEffortsTotal if no effort has been entered', () => {
    const mockState = {
      efforts: {},
    }
    const actual = getNewEffortsTotal(mockState)
    expect(actual).toEqual(0)
  })
})
