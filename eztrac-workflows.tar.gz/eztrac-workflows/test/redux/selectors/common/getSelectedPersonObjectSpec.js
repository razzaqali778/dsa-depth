import selector from '../../../../src/client/redux/selectors/common/getSelectedPersonObject'

const mockStateFactory = mockSelectedPerson => ({
  deactivateSelections: {
    selectedPerson: mockSelectedPerson,
  },
  people: {
    allPeople: [
      { personName: 'meme queen', personId: 'crgood' },
      { personName: 'fresh', personId: 'wholesome' },
      { personName: 'mister meseeks', personId: 'memes' },
    ],
  },
})


describe('getSelectedPersonObjectSelector', () => {
  it('gets a person name from the selectedPerson (user id) in state', () => {
    const mockState = mockStateFactory('crgood')

    const formattedMockState = {
      value: 'crgood',
      label: 'meme queen',
    }

    const actual = selector(mockState)

    expect(actual).toEqual(formattedMockState)
  })
})
