import selector from '../../../../src/client/redux/selectors/common/getPeopleSelectOpts'

describe('getPeopleSelectOpts', () => {
  it('gets people from state', () => {
    const mockState = {
      people: {
        allPeople: [{
          personName: 'wee',
          personId: 'B0RK',
          bleh: 'bl33h3h3',
        }, {
          personName: 'another person',
          personId: 'yiss',
          notImportant: 'nope',
        }],
      },
    }
    const expected = [{ value: 'B0RK', label: 'wee' }, { value: 'yiss', label: 'another person' }]

    const actual = selector(mockState)

    expect(actual).toEqual(expected)
  })
})
