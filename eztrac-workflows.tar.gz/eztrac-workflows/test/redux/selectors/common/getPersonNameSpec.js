import selector from '../../../../src/client/redux/selectors/common/getPersonName'

const mockStateFactory = mockSelectedPerson => ({
  deactivateSelections: {
    selectedPerson: mockSelectedPerson,
  },
  people: {
    allPeople: [
      { personName: 'meme queen', personId: 'crgood' },
      { personName: 'fresh', personId: 'wholesome' },
      { personName: 'mister meseeks', personId: 'memes' },
    ],
  },
})


describe('getPersonName selector', () => {
  it('gets a person name from the selectedPerson (user id) in state', () => {
    const mockState = mockStateFactory('crgood')

    const actual = selector(mockState)

    expect(actual).toEqual('meme queen')
  })

  it('returns the user id from state if they do not have a name', () => {
    const mockState = mockStateFactory('memes')

    const actual = selector(mockState)

    expect(actual).toEqual('mister meseeks')
  })
})
