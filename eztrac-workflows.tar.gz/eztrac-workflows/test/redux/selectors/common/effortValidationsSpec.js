import {
  singleEffortValidation,
  totalEffortValidation,
} from '../../../../src/client/redux/selectors/common/effortValidations'

describe('effortValidations', () => {
  it(' singleEffortValidation finds and returns boolean if errorText is not empty', () => {
    const mockState = {
      efforts: {
        current: [{ errorText: '' }, { errorText: '' }, { errorText: 'Not A Number' }],
        next: [],
      },
    }

    const isValid = singleEffortValidation(mockState)

    expect(isValid).toEqual(false)
  })
  it('totalEffortValidation finds and returns boolean if totalEffort is out of range', () => {
    const mockState = {
      efforts: {
        current: [{ newPercent: 55, percent: 50 }, { newPercent: 55, percent: 50 }],
        next: [],
      },
    }

    const isTotalValid = totalEffortValidation(mockState)

    expect(isTotalValid).toEqual(false)
  })
})
