import { getValidTeams } from '../../../../src/client/redux/selectors/common/getValidTeams'

describe('getValidTeams spec', () => {
  it('Gets all teams and selected teams and deletes selected teams from all teams', () => {
    const mockState = {
      teams: {
        teams: [
          { label: 'goat' },
          { label: 'goat2' },
        ],
      },
      efforts: {
        current: [
          { label: 'goat' },
        ],
      },
    }

    const result = [
      { label: 'goat2' },
    ]

    const validTeams = getValidTeams(mockState)
    expect(validTeams).toEqual(result)
  })
})
