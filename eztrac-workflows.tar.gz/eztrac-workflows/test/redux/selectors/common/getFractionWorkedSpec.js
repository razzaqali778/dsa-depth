import Moment from 'moment'
import {
  getSuggestedEfforts,
  getSuggestedEffortsAddPerson,
} from '../../../../src/client/redux/selectors/common/getFractionWorked'

describe('getFractionWorked', () => {
  it('Add Person, returns a fraction of days worked given a start date', () => {
    const mockStartDate = new Moment({
      year: 2017,
      month: 0,
      day: 5,
    })

    const mockState = {
      addSelections: {
        startDate: mockStartDate,
      },
    }

    // 21 business days in January
    // 5Jan17 is the 4th business day
    // Which leaves
    getSuggestedEffortsAddPerson(mockState)
  })

  it('returns fraction of days worked in a month when efforts = 100%', () => {
    const mockState = {
      efforts: {
        current: [{ percent: 50 }, { percent: 50 }],
        next: [],
      },

      deactivateSelections: {
        endDate: 15,
      },

      timeframes: {
        currentTimeframe: {
          endDate: 30,
        },
      },
    }

    Moment.fn.businessDiff = jest.fn(() => 12) // 11 business days left in a month with 30 days, counting the day they leave
    Moment.fn.monthBusinessDays = jest.fn(() => new Array(23).fill(0))

    const response = getSuggestedEfforts(mockState)

    const actual = Math.round(100 * response)

    expect(actual).toEqual(52)
  })

  it('returns 1 if the total effort percent is less than/over 100.', () => {
    const mockState = {
      efforts: {
        current: [{ percent: 20 }, { percent: 10 }],
        next: [],
      },
      deactivateSelections: {
        endDate: 15,
      },

      timeframes: {
        currentTimeframe: {
          endDate: 30,
        },
      },
    }

    const actual = getSuggestedEfforts(mockState)

    expect(actual).toEqual(1)
  })
})
