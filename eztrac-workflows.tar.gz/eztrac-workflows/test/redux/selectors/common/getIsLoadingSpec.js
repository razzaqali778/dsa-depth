import { ADD_PERSON_WORKFLOW, DEACTIVATE_WORKFLOW, LOCKDOWN } from '../../../../src/client/redux/constants/pages'
import selector from '../../../../src/client/redux/selectors/common/getIsLoading'

describe('is loading', () => {
  describe('workflow', () => {
    it('returns true if people are not loaded', () => {
      const state = {
        page: DEACTIVATE_WORKFLOW,
        people: { allPeople: [] },
        efforts: { loading: false },
        addSelections: { suggestionLoading: false },
        timeframes: {},
      }

      expect(selector(state)).toBe(true)
    })

    it('returns false if people are loaded', () => {
      const state = {
        page: DEACTIVATE_WORKFLOW,
        people: { allPeople: [{ some: 'stuff' }] },
        efforts: { loading: false },
        addSelections: { suggestionLoading: false },
        timeframes: {},
      }

      expect(selector(state)).toBe(false)
    })
  })

  it('returns true if people are loaded but efforts are not', () => {
    const state = {
      page: DEACTIVATE_WORKFLOW,
      people: { allPeople: [{ some: 'stuff' }] },
      efforts: { loading: true },
      addSelections: { suggestionLoading: false },
      timeframes: {},
    }

    expect(selector(state)).toBe(true)
  })

  it('returns true if people are loading', () => {
    const state = {
      page: ADD_PERSON_WORKFLOW,
      people: { allPeople: [] },
      efforts: { loading: false },
      addSelections: { suggestionLoading: false },
      timeframes: {},
    }

    expect(selector(state)).toBe(true)
  })

  it('returns true if people are loaded but selectedPersonSuggestion is loading', () => {
    const state = {
      page: ADD_PERSON_WORKFLOW,
      people: { allPeople: [{ some: 'stuff' }] },
      efforts: { loading: false },
      addSelections: { suggestionLoading: true },
      timeframes: {},
    }

    expect(selector(state)).toBe(true)
  })

  it('returns false if people are loaded or selectedPersonSuggestion is not loading', () => {
    const state = {
      page: ADD_PERSON_WORKFLOW,
      people: { allPeople: [{ some: 'stuff' }] },
      efforts: { loading: false },
      addSelections: { suggestionLoading: false },
      timeframes: {},
    }

    expect(selector(state)).toBe(false)
  })

  it('returns true for lockdown if currentTimeframe is not loaded', () => {
    const state = {
      page: LOCKDOWN,
      people: { allPeople: [{ some: 'stuff' }] },
      efforts: { loading: false },
      addSelections: { suggestionLoading: false },
      timeframes: { currentTimeframe: {} },
    }

    expect(selector(state)).toBe(true)
  })
  it('returns true for lockdown if currentTimeframe is not loaded', () => {
    const state = {
      page: LOCKDOWN,
      people: { allPeople: [{ some: 'stuff' }] },
      efforts: { loading: false },
      addSelections: { suggestionLoading: false },
      timeframes: {},
    }

    expect(selector(state)).toBe(true)
  })
  it('returns false for lockdown if currentTimeframe is loaded', () => {
    const state = {
      page: LOCKDOWN,
      people: { allPeople: [{ some: 'stuff' }] },
      efforts: { loading: false },
      addSelections: { suggestionLoading: false },
      timeframes: { currentTimeframe: { name: 'some timeframe' } },
    }

    expect(selector(state)).toBe(false)
  })
})
