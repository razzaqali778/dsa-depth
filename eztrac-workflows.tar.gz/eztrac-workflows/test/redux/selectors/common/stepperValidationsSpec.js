import {
  isPersonSelected,
  isReasonSelected,
} from '../../../../src/client/redux/selectors/common/stepperValidations'

describe('stepperValidations', () => {
  describe('isPersonSelected', () => {
    it('returns true if a person has been selected', () => {
      const mockState = {
        deactivateSelections: {
          selectedPerson: {
            name: 'blah',
            id: 'yo',
          },
        },
      }

      const actual = isPersonSelected(mockState)

      expect(actual).toBe(true)
    })

    it('returns false if a person is not selected (person is null)', () => {
      const mockState = {
        deactivateSelections: {
          selectedPerson: null,
        },
      }

      const actual = isPersonSelected(mockState)

      expect(actual).toBe(false)
    })
  })

  describe('isReasonSelected', () => {
    it('returns true if a reason is selected', () => {
      const mockState = {
        deactivateSelections: {
          selectedReason: { label: 'SOW', value: 'SOW' },
        },
      }

      const actual = isReasonSelected(mockState)

      expect(actual).toBe(true)
    })

    it('returns false if a reason is not selected', () => {
      const mockState = {
        deactivateSelections: {
          selectedReason: null,
        },
      }

      const actual = isReasonSelected(mockState)

      expect(actual).toBe(false)
    })
  })
})
