import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { SET_HEALTH_CHECK } from '../../../../src/client/redux/constants/healthCheck'
import { get } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import listener, { fetchHealthCheck } from '../../../../src/client/redux/sagas/common/fetchHealthCheck'

const mockHealthCheck = [
  {
    timeFrameName: 'Feb 2023',
    teamName: 'Team 1',
    teamId: 'TEAM-1',
    errors: [ 'Effort has allocations but no costs, team members or engagements' ],
  },

  {
    timeFrameName: 'Feb 2023',
    teamName: 'Team 2',
    teamId: 'TEAM-2',
    errors: [ 'Effort has allocations but no costs, team members or engagements' ],
  },
]

const payload = '42302'

const healthCheckRequest = {
  baseUrl: urls.coreServices,
  path: `/v2/healthCheck/efforts/timeFrameId/${payload}`,
}

describe('fetchHealthCheck', () => {
  it('listens for correct action fired', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const constants = [ 'healthCheck/SET_HEALTH_CHECK_TIMEFRAME' ]

    expect(step()).toEqual(takeLatest(constants, fetchHealthCheck).next().value)
  })

  it('gets health check for chosen timeframeId', () => {
    const gen = fetchHealthCheck({ payload })
    const step = lastYield => gen.next(lastYield).value

    const action = {
      type: SET_HEALTH_CHECK,
      payload: mockHealthCheck,
    }

    expect(step()).toEqual(call(get, healthCheckRequest))
    expect(step(mockHealthCheck)).toEqual(dispatch(action))
    expect(gen.next().done).toEqual(true)
  })
})
