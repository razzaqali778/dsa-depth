import { all, call, select } from 'redux-saga/effects'
import pick from 'lodash/pick'
import { getCurrentEfforts } from '../../../../src/client/redux/selectors'
import { put } from '../../../../src/client/redux/sagas/helpers/network'
import { saveEfforts as saga } from '../../../../src/client/redux/sagas/common/saveEfforts'
import { urls } from '../../../urlConsts'

describe('safeEfforts', () => {
  it('saves efforts', () => {
    const gen = saga()
    const step = lastYield => gen.next(lastYield).value

    const mockState = {
      efforts: [
        {
          userId: 'yoo123',
          id: 'yee321',
          newPercent: 1337,
          percent: 1330,
          timeFrameId: 123,
          teamId: 'TEAM TEAM',
        },
        {
          userId: 'blorf',
          id: 'blorf0',
          newPercent: 18,
          percent: 17,
          timeFrameId: 123,
          teamId: 'TEAM TEAM',
        },
      ],
    }

    const { efforts } = mockState

    const calls = efforts.map(effort => {
      const options = {
        baseUrl: urls.coreServices,
        path: `/v2/efforts/timeframes/${effort.timeFrameId}/team/${effort.teamId}/user/${effort.userId}`,
        body: { percent: parseInt(effort.newPercent, 10) },
        headers: { accept: 'text/plain' },
      }

      return call(put, options)
    })

    const actual = all(calls)
    expect(step()).toEqual(select(getCurrentEfforts))
    expect(step(efforts)).toEqual(actual)
    expect(step([ null, null ])).toEqual(
      mockState.efforts.map(effort => pick(effort, [ 'timeFrameId', 'teamId', 'userId', 'percent', 'newPercent' ])),
    )
    expect(gen.next().done).toBe(true)
  })
})
