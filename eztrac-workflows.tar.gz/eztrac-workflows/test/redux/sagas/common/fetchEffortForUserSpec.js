import {
  all, call, put as dispatch, select,
} from 'redux-saga/effects'
import {
  SET_CURRENT_EFFORTS,
  SET_EFFORTS_LOADING,
  SET_FUTURE_EFFORTS,
} from '../../../../src/client/redux/constants/efforts'
import { exportedForTesting } from '../../../../src/client/redux/sagas/common/fetchEffortForUser'
import { get } from '../../../../src/client/redux/sagas/helpers/network'
import { getCurrentTimeframe } from '../../../../src/client/redux/sagas/helpers/getTakes'
import { getSelectedPerson } from '../../../../src/client/redux/selectors'
import { setSuggestedParticipation } from '../../../../src/client/redux/sagas/common/setSuggestedParticipation'
import { urls } from '../../../urlConsts'
import getFutureTimeFrames from '../../../../src/client/redux/selectors/common/getFutureTimeFrames'

describe('fetchEffortForUser', () => {
  it('processes current efforts', () => {
    const { processCurrentEfforts, getEffortsWithTeamNames } = exportedForTesting
    const mockCurrentEfforts = [
      {
        teamId: 'blah',
        percent: 50,
        timeframe: 1,
      },
      {
        teamId: 'blah1',
        percent: 50,
        timeframe: 1,
      },
    ]
    const mockCurrentEffortsWithTeamNames = mockCurrentEfforts.map(
      effort => ({ ...effort, teamName: effort.teamId.toUpperCase() }),
    )
    const gen = processCurrentEfforts(mockCurrentEfforts)
    const step = lastYield => gen.next(lastYield).value

    expect(step()).toEqual(call(getEffortsWithTeamNames, mockCurrentEfforts))
    expect(step(mockCurrentEffortsWithTeamNames)).toEqual(
      dispatch({
        type: SET_CURRENT_EFFORTS,
        payload: mockCurrentEffortsWithTeamNames,
      }),
    )
    expect(step()).toEqual(call(setSuggestedParticipation))
    expect(gen.next().done).toBe(true)
  })

  it('processes future efforts', () => {
    const { processFutureEfforts, getEffortsWithTeamNames } = exportedForTesting
    const mockFutureEfforts = [
      {
        teamId: 'blah',
        percent: 100,
        timeframe: 2,
      },
      {
        teamId: 'blah1',
        percent: 30,
        timeframe: 2,
      },
      {
        teamId: 'blah',
        percent: 50,
        timeframe: 3,
      },
    ]
    const mockFutureEffortsWithTeamNames = mockFutureEfforts.map(effort => ({
      ...effort,
      teamName: effort.teamId.toUpperCase(),
    }))
    const gen = processFutureEfforts(mockFutureEfforts)
    const step = lastYield => gen.next(lastYield).value

    expect(step()).toEqual(call(getEffortsWithTeamNames, mockFutureEfforts))
    expect(step(mockFutureEffortsWithTeamNames)).toEqual(
      dispatch({
        type: SET_FUTURE_EFFORTS,
        payload: mockFutureEffortsWithTeamNames,
      }),
    )
    expect(gen.next().done).toBe(true)
  })

  it('fetches team name for efforts', () => {
    const { getEffortsWithTeamNames } = exportedForTesting
    const mockEfforts = [
      {
        teamId: 'blah',
        percent: 100,
        timeframe: 2,
      },
      {
        teamId: 'blah1',
        percent: 30,
        timeframe: 2,
      },
      {
        teamId: 'blah',
        percent: 50,
        timeframe: 3,
      },
    ]

    const teamOpts = Array.from(
      new Set(mockEfforts.map(effort => effort.teamId)),
    ).map(teamId => ({
      baseUrl: urls.coreServices,
      path: `/v2/team/${teamId}`,
    }))

    const gen = getEffortsWithTeamNames(mockEfforts)
    const step = lastYield => gen.next(lastYield).value

    expect(step()).toEqual(all(teamOpts.map(opts => call(get, opts))))
  })

  it('fetches the current and next efforts for a user', () => {
    // eslint-disable-line max-statements
    const {
      fetchEffortForUser: saga,
      processCurrentEfforts,
      processFutureEfforts,
    } = exportedForTesting
    const gen = saga()
    const step = lastYield => gen.next(lastYield).value

    const mockTimeframe = { id: 12345 }
    const mockFutureTimeframe = [{ id: 23456 }, { id: 34567 }]

    const mockUser = 'crg00f'

    const mockEfforts = [
      { teamId: 'blah', percent: 50, timeframe: mockTimeframe },
      { teamId: 'blah2', percent: 100, timeframe: mockTimeframe },
    ]
    const mockFutureEfforts = [
      [
        { teamId: 'blah', percent: 50, timeframe: mockFutureTimeframe[0].id },
        { teamId: 'blah3', percent: 100, timeframe: mockFutureTimeframe[0].id },
      ],
      [{ teamId: 'blah', percent: 20, timeframe: mockFutureTimeframe[1].id }],
    ]

    const getOpts = {
      baseUrl: urls.coreServices,
      path: `/v2/efforts/timeframes/${mockTimeframe.id}/user/${mockUser}`,
    }
    const getFutureOpts = mockFutureTimeframe.map(timeframe => ({
      baseUrl: urls.coreServices,
      path: `/v2/efforts/timeframes/${timeframe.id}/user/${mockUser}`,
    }))

    const makeLoadingAction = payload => ({
      type: SET_EFFORTS_LOADING,
      payload,
    })

    expect(step()).toEqual(dispatch(makeLoadingAction(true)))
    expect(step()).toEqual(call(getCurrentTimeframe))
    expect(step(mockTimeframe)).toEqual(select(getFutureTimeFrames))
    expect(step(mockFutureTimeframe)).toEqual(select(getSelectedPerson))
    expect(step(mockUser)).toEqual(call(get, getOpts))
    expect(step(mockEfforts)).toEqual(
      all(getFutureOpts.map(opts => call(get, opts))),
    )
    expect(step(mockFutureEfforts)).toEqual(
      call(processCurrentEfforts, mockEfforts),
    )
    expect(step()).toEqual(
      call(processFutureEfforts, mockFutureEfforts.flat()),
    )
    expect(step()).toEqual(dispatch(makeLoadingAction(false)))
    expect(gen.next().done).toBe(true)
  })
})
