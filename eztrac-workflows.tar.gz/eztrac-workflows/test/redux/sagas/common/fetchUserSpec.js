import { call, put as dispatch } from 'redux-saga/effects'
import { SET_USER } from '../../../../src/client/redux/constants/user'
import fetchUserSaga, { fetchUser } from '../../../../src/client/redux/sagas/common/fetchUser'

describe('Fetch User', () => {
  it('fetches users entitlements', () => {
    const gen = fetchUserSaga()
    const step = lastYield => gen.next(lastYield).value

    const user = {
      getCurrentUser: {
        stuff: 'lol',
      },
    }

    const action = {
      type: SET_USER,
      payload: {
        ...user.getCurrentUser,
      },
    }

    expect(step()).toEqual(call(fetchUser))
    expect(step(user)).toEqual(dispatch(action))
    expect(gen.next().done).toEqual(true)
  })
})
