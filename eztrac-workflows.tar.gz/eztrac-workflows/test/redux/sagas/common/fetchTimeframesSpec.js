import { call, put as dispatch } from 'redux-saga/effects'
import {
  SET_ALL_TIMEFRAMES,
  SET_CURRENT_TIMEFRAME,
  SET_NEXT_TIMEFRAME,
} from '../../../../src/client/redux/constants/timeframes'
import { get } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import saga from '../../../../src/client/redux/sagas/common/fetchTimeframes'

describe('fetchTimeframes', () => {
  const currentTimeframe = {
    id: 525600,
    endDate: 'last day of january maybe',
    name: 'Some month',
    startDate: 'january probably',
  }
  const nextTimeframe = {
    id: 525601,
    endDate: 'last day of february',
    name: 'Some month',
    startDate: 'february probably',
  }
  const allTimeframes = [ currentTimeframe, nextTimeframe ]

  const currentAction = {
    type: SET_CURRENT_TIMEFRAME,
    payload: currentTimeframe,
  }

  const allAction = {
    type: SET_ALL_TIMEFRAMES,
    payload: allTimeframes,
  }

  const nextAction = {
    type: SET_NEXT_TIMEFRAME,
    payload: nextTimeframe,
  }

  const getCurrentOpts = {
    baseUrl: urls.coreServices,
    path: '/v2/timeframes/current',
  }

  const getAllOpts = {
    baseUrl: urls.coreServices,
    path: '/v2/timeframes',
  }

  const getNextOpts = {
    baseUrl: urls.coreServices,
    path: '/v2/timeframes/current/offset/1',
  }

  it('fetches timeframes', () => {
    const gen = saga()
    const step = lastYield => gen.next(lastYield).value

    expect(step()).toEqual(call(get, getCurrentOpts))
    expect(step(currentTimeframe)).toEqual(call(get, getNextOpts))
    expect(step(nextTimeframe)).toEqual(call(get, getAllOpts))
    expect(step(allTimeframes)).toEqual(dispatch(currentAction))
    expect(step()).toEqual(dispatch(nextAction))
    expect(step(nextTimeframe)).toEqual(dispatch(allAction))
    expect(gen.next().done).toBe(true)
  })
})
