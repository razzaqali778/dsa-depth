import { call, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import moment from 'moment'
import { SEND_TASK } from '../../../../src/client/redux/constants/addSelections'
import { getAddSelectedPerson, getSelectedCostGroup, getSelectedRate } from '../../../../src/client/redux/selectors'
import { post } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import listener, { sendTask } from '../../../../src/client/redux/sagas/common/sendTask'

const { messagingUrl } = urls
const peadminUrl = window.phoenix.serviceBindings['peadmin-home']
const profileURL = urls.papiUrl

const selectedPerson = {
  id: 'KKOU',
  fullName: 'Kevin Ou',
  rateName: 'Standard',
  costGroupName: 'P&E PD',
  employeeType: 'Employee',
  isActive: true,
  department: {
    name: 'Darius hurts people.',
  },
}

const selectedCostGroup = {
  label: 'Cody sucks cost group',
}

const selectedRate = {
  label: 'Cody sucks rate',
}

const payload = {
  actions: [
    {
      title: 'view',
      url: `https://${peadminUrl}/ez-trac-costing/people?personId=${selectedPerson.id}&edit=true&task=true`,
    },
  ],
  body: {
    markdown: `Please review the new profile for **${selectedPerson.fullName}** `
                + `from the department **${selectedPerson.department.name}**. They have been suggested the `
                + `cost group of **${selectedCostGroup.label}** with the rate of **${selectedRate.label}.**`,
  },
  dueDate: moment().add( 1, 'w' ).format( 'YYYY-MM-DD' ),
  recipients: [ 'DJIAN', 'CCASE' ],
  sender: 'Ez Trac',
  tags: [
    'Ez Trac',
  ],
  senderKey: selectedPerson.id,
  title: 'Review Person Added to Ez-Trac',
}

const postTaskRequest = {
  baseUrl: messagingUrl,
  path: '/v5/tasks',
  body: payload,
}

const opsLeadsRequest = {
  baseUrl: profileURL,
  path: '/v3/graphql',
  body: { query: '{ getGroupById(id: "PE-STRATEGY-AND-OPERATIONS-LEADS") { members { members { id } } } }' },
}

const opsLeadsResponse = {
  data: {
    getGroupById: {
      members: {
        members: [
          { id: 'CWCAME' },
        ],
      },
    },
  },
}


describe( 'submits tasks', () => {
  it('listens for correct action fired', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const constants = [
      SEND_TASK,
    ]

    expect(step()).toEqual(takeLatest(constants, sendTask).next().value)
  } )

  it( 'notifies ops leads of tasks', () => {
    const gen = sendTask()
    const step = lastYield => gen.next(lastYield).value

    expect(step()).toEqual(select(getAddSelectedPerson))
    expect(step(selectedPerson)).toEqual(select(getSelectedCostGroup))
    expect(step(selectedCostGroup)).toEqual(select(getSelectedRate))
    expect(step(selectedRate)).toEqual(call(post, opsLeadsRequest))
    expect(step(opsLeadsResponse)).toEqual(call(post, postTaskRequest))
    expect(gen.next().done).toEqual(true)
  } )
} )
