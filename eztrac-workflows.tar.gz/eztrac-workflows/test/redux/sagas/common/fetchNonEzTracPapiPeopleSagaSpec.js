import { call, put as dispatch, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { getAllPeople } from '../../../../src/client/redux/selectors'
import { post } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import listener, {
  fetchNonEzTracPapiPeopleSaga,
} from '../../../../src/client/redux/sagas/common/fetchNonEzTracPapiPeopleSaga'

describe('fetch people from papi who are not in ez-trac', () => {
  const payload = 'Darius'

  const papiPeople = {
    data: {
      searchUsers: {
        members: [
          {
            id: 'DHARR2',
            legalName: {
              full: 'Darius Harrison',
            },
            employeeType: 'Employee',
            organization: {
              name: 'PD',
            },
          },
          {
            id: 'SCARY',
            legalName: {
              full: 'Darius Scarrison',
            },
            employeeType: 'Employee',
            organization: {
              name: 'PD',
            },
          },
          {
            id: 'GARY',
            legalName: {
              full: 'Garius Garretson',
            },
            employeeType: 'Mechanical',
            organization: {
              name: 'PD',
            },
          },
          {
            id: 'CART',
            legalName: {
              full: 'Carius Cartrison',
            },
            employeeType: 'External',
            organization: {
              name: 'PD',
            },
          },
        ],
      },
    },
  }

  const ezTracPeople = [{
    costGroupName: 'Unknown',
    isActive: true,
    isEmployee: true,
    modifiedBy: 'EZ-TRAC-CRON',
    personId: 'SCARY',
    personName: 'Darius Scarrison',
    rateName: 'Unknown',
  }]

  it('listens for correct action fired', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const constants = [
      'people/SET_PAPI_SEARCH_TEXT',
    ]

    expect(step()).toEqual(takeLatest(constants, fetchNonEzTracPapiPeopleSaga).next().value)
  })

  it('fetches people from papi', () => {
    const gen = fetchNonEzTracPapiPeopleSaga({ payload })
    const step = lastYield => gen.next(lastYield).value

    const getPapiPeople = {
      baseUrl: urls.papiUrl,
      path: '/v3/graphql',
      body: { query: `{ searchUsers(query: "${payload}") { members { id legalName { full } employeeType organization { name } } } }` }, // eslint-disable-line max-len
    }

    const formattedPayload = [{
      value: 'DHARR2',
      label: 'Darius Harrison (DHARR2)',
      fullName: 'Darius Harrison',
      employeeType: 'Employee',
      department: 'PD',
    }]

    const action = {
      type: 'people/SET_PAPI_PEOPLE',
      payload: formattedPayload,
    }

    expect(step()).toEqual(call(post, getPapiPeople))
    expect(step(papiPeople)).toEqual(select(getAllPeople))
    expect(step(ezTracPeople)).toEqual(dispatch(action))
    expect(gen.next().done).toBe(true)
  })
})
