import { put as dispatch, select } from 'redux-saga/effects'
import { SET_CURRENT_EFFORTS } from '../../../../src/client/redux/constants/efforts'
import { getCurrentEfforts } from '../../../../src/client/redux/selectors'
import { getSuggestedEfforts } from '../../../../src/client/redux/selectors/common/getFractionWorked'
import { setSuggestedParticipation as saga } from '../../../../src/client/redux/sagas/common/setSuggestedParticipation'

describe('setSuggestedParticipation', () => {
  it('sets suggested participation from efforts in state', () => {
    const gen = saga()
    const step = lastYield => gen.next(lastYield).value

    const mockCurrentEfforts = [
      { thingy1: 'not important', percent: 30, newPercent: 30 },
      { thingy2: 'not important2', percent: 20, newPercent: 20 },
      { thingy3: 'not important3', percent: 50, newPercent: 50 },
    ]
    const mockUpdatedEfforts = [
      { thingy1: 'not important', percent: 30, newPercent: 15 },
      { thingy2: 'not important2', percent: 20, newPercent: 10 },
      { thingy3: 'not important3', percent: 50, newPercent: 25 },
    ]

    const mockPercent = 0.5

    const action = {
      type: SET_CURRENT_EFFORTS,
      payload: mockUpdatedEfforts,
    }

    expect(step()).toEqual(select(getCurrentEfforts))
    expect(step(mockCurrentEfforts)).toEqual(select(getSuggestedEfforts))
    expect(step(mockPercent)).toEqual(dispatch(action))
  })
})
