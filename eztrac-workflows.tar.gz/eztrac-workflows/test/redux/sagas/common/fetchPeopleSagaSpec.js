import { call, put as dispatch } from 'redux-saga/effects'
import { SET_PEOPLE } from '../../../../src/client/redux/constants/people'
import { get } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import saga from '../../../../src/client/redux/sagas/common/fetchPeopleSaga'

describe('fetchPeopleSaga', () => {
  const makePerson = ( num, isActive ) => ({
    personId: `UID${num}`,
    rateName: `Rate${num}`,
    personName: `Name${num}`,
    isActive,
  })

  it('fetches people', () => {
    const gen = saga()
    const step = lastYield => gen.next(lastYield).value

    const getOpts = {
      baseUrl: urls.costingServices,
      path: '/v1/people?isActive=true',
    }

    const mockPeople = [ makePerson(0, true), makePerson(1, true) ]

    const action = {
      type: SET_PEOPLE,
      payload: mockPeople,
    }

    expect(step()).toEqual(call(get, getOpts))
    expect(step(mockPeople)).toEqual(dispatch(action))
    expect(gen.next().done).toBe(true)
  })
})
