import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { SET_ALL_TEAMS } from '../../../../src/client/redux/constants/teams'
import { get } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import listener, { fetchAllTeamsSaga } from '../../../../src/client/redux/sagas/common/fetchAllTeamsSaga'

const allTeams = [
  {
    id: '11652',
    name: 'Data Delivery - Advancement',
    label: 'Data Delivery - Advancement',
    value: '11652',
  },
  {
    id: '11653',
    name: 'Data Delivery - Genomics',
    label: 'Data Delivery - Genomics',
    value: '11653',
  },
]

const allTeamsUnknown = [
  {
    id: '-1',
    name: 'Unknown',
    label: 'Unknown',
    value: 'Unknown',
  },
]

const payload = 'DariusScarriusStrawberriusGaryius'

const teamsRequest = {
  baseUrl: urls.coreServices,
  path: `/v2/teams?q=${payload}`,
}


describe('fetchAllTeamsSaga', () => {
  it('listens for correct action fired', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const constants = [ 'teams/FETCH_SEARCH_TEAMS' ]

    expect(step()).toEqual(takeLatest(constants, fetchAllTeamsSaga).next().value)
  })

  it('gets all teams', () => {
    const gen = fetchAllTeamsSaga({ payload })
    const step = lastYield => gen.next(lastYield).value

    const action = {
      type: SET_ALL_TEAMS,
      payload: allTeams,
    }

    expect(step()).toEqual(call(get, teamsRequest))
    expect(step(allTeams)).toEqual(dispatch(action))
    expect(gen.next().done).toEqual(true)
  })

  it('fails to get all teams', () => {
    const gen = fetchAllTeamsSaga({ payload })
    const step = lastYield => gen.next(lastYield).value

    const errrorReponse = { error: {} }

    const action = {
      type: SET_ALL_TEAMS,
      payload: allTeamsUnknown,
    }

    expect(step()).toEqual(call(get, teamsRequest))
    expect(step(errrorReponse)).toEqual(dispatch(action))
    expect(gen.next().done).toEqual(true)
  })
})
