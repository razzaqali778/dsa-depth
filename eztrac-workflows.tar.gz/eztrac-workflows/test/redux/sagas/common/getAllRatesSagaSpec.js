import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { get } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import listener, { getAllRatesSaga } from '../../../../src/client/redux/sagas/common/getAllRatesSaga'

describe('All Rate Saga', () => {
  it('listens for correct action fired', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const constants = [
      'costGroupsRates/FETCH_ALL_RATE_DATA',
    ]

    expect(step()).toEqual(takeLatest(constants, getAllRatesSaga).next().value)
  })

  it('fetches all rate data', () => {
    const gen = getAllRatesSaga()
    const step = lastYield => gen.next(lastYield).value
    const options = {
      baseUrl: urls.costingServices,
      path: '/v1/rates?isActive=true',
    }

    const mockResult = [
      {
        name: 'Slalom SOW',
        hourlyRate: '160',
        id: 'SLALOM-SOW',
        isActive: 'true',
        modifiedBy: 'automatic',
      },
      {
        name: 'High Rate',
        hourlyRate: '125',
        id: 'HIGH-RATE',
        isActive: 'true',
        modifiedBy: 'automatic',
      },
    ]

    const mockResultReturn = [
      {
        label: 'High Rate',
        value: 'HIGH-RATE',
        key: 'HIGH-RATE',
      },
      {
        key: 'SLALOM-SOW',
        label: 'Slalom SOW',
        value: 'SLALOM-SOW',
      },
    ]

    const action = {
      type: 'costGroupsRates/SET_ALL_RATE_DATA',
      payload: mockResultReturn,
    }

    expect(step()).toEqual(call(get, options))
    expect(step(mockResult)).toEqual(dispatch(action))
    expect(gen.next().done).toBe(true)
  })
})
