import { call, select } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { getCurrentUserName, getSelectedPerson, getSelectedReason } from '../../../../src/client/redux/selectors'
import { post } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import getPersonName from '../../../../src/client/redux/selectors/common/getPersonName'
import listener, { teamsMessage as saga } from '../../../../src/client/redux/sagas/common/teamsMessage'

it('listens for correct action fired', () => {
  const gen = listener()
  const step = lastYield => gen.next(lastYield).value
  const constants = [
    'deactivateSelections/SEND_DEACTIVATE_MESSAGE',
  ]

  expect(step()).toEqual(takeLatest(constants, saga).next().value)
})

it('posts message to teams', () => {
  const gen = saga()
  const step = lastYield => gen.next(lastYield).value

  const mockName = 'jimmy johns'
  const mockReason = 'ran outta bread'
  const mockUserName = 'station, penn'
  const mockPerson = 'jjgarg'

  const options = {
    text: 'jimmy johns has been deactivated with the reason ran outta bread by station, penn. Reactivate in <https://peadmin-np.monsanto.net/ez-trac-costing/people?personId=jjgarg|Costing Engine> and\nRemove reason in <https://peadmin-np.monsanto.net/ez-trac-qc/participation?q=jjgarg&showWithReasons=true|Participation QC>', // eslint-disable-line max-len
    hookUrl: 'testHookUrl',
  }
  const title = 'jimmy johns has been deactivated with the reason ran outta bread by station, penn.'

  const card = {
    type: 'AdaptiveCard',
    $schema: 'https://adaptivecards.io/schemas/adaptive-card.json',
    version: '1.5',
    body: [
      {
        type: 'TextBlock',
        size: 'Medium',
        weight: 'Bolder',
        wrap: true,
        color: 'good',
        text: title,
      },
      {
        type: 'TextBlock',
        wrap: true,
        text: options.text,
      },
    ],
    msteams: {
      width: 'Full',
    },
  }

  const data = {
    type: 'message',
    attachments: [
      {
        contentType: 'application/vnd.microsoft.card.adaptive',
        content: {
          ...card,
        },
      },
    ],
  }

  const postOpts = {
    baseUrl: urls.teamsHookUrl,
    path: '',
    body: data,
  }

  expect(step()).toEqual(select(getPersonName))
  expect(step(mockName)).toEqual(select(getSelectedPerson))
  expect(step(mockPerson)).toEqual(select(getSelectedReason))
  expect(step(mockReason)).toEqual(select(getCurrentUserName))
  expect(step(mockUserName)).toEqual(call(post, postOpts))
  expect(gen.next().done).toBe(true)
})
