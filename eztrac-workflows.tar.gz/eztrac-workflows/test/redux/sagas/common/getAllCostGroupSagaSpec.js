import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import { get } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import listener, { getAllCostGroupsSaga } from '../../../../src/client/redux/sagas/common/getAllCostGroupsSaga'

describe('All Cost Group Saga', () => {
  it('listens for correct action fired', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const constants = [
      'costGroupsRates/FETCH_ALL_COST_GROUP_DATA',
    ]

    expect(step()).toEqual(takeLatest(constants, getAllCostGroupsSaga).next().value)
  })

  it('fetches all cost group data', () => {
    const gen = getAllCostGroupsSaga()
    const step = lastYield => gen.next(lastYield).value
    const options = {
      baseUrl: urls.costingServices,
      path: '/v1/costGroups?isActive=true',
    }
    const mockResult = [
      {
        id: 'TPS', name: 'Technology Pipeline Solutions', costCenter: '82AB', isActive: false,
      },
      {
        id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
      },
    ]

    const mockResultReturn = [
      { key: 'PROD-DEV', label: 'Product Development', value: 'PROD-DEV' },
      { key: 'TPS', label: 'Technology Pipeline Solutions', value: 'TPS' },
    ]

    const action = {
      type: 'costGroupsRates/SET_ALL_COST_GROUP_DATA',
      payload: mockResultReturn,
    }

    expect(step()).toEqual(call(get, options))
    expect(step(mockResult)).toEqual(dispatch(action))
    expect(gen.next().done).toBe(true)
  })
})
