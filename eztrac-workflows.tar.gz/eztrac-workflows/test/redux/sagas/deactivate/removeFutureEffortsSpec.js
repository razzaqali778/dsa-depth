import { all, call, select } from 'redux-saga/effects'
import { del } from '../../../../src/client/redux/sagas/helpers/network'
import { getFutureEfforts } from '../../../../src/client/redux/selectors'
import { removeFutureEfforts as saga } from '../../../../src/client/redux/sagas/deactivate/removeFutureEfforts'
import { urls } from '../../../urlConsts'

describe('removeFutureEfforts', () => {
  it('removes the selected person from efforts in future timeframes', () => {
    const gen = saga()
    const step = lastYield => gen.next(lastYield).value

    const mockState = {
      efforts: [
        {
          userId: 'yoo123',
          id: 'yee321',
          newPercent: 1337,
          timeFrameId: 123,
          teamId: 'TEAM TEAM',
        },
        {
          userId: 'blorf',
          id: 'blorf0',
          newPercent: 18,
          timeFrameId: 124,
          teamId: 'TEAM TEAM',
        },
      ],
    }

    const { efforts } = mockState

    const calls = efforts.map(effort => {
      const options = {
        baseUrl: urls.coreServices,
        path: `/v2/efforts/timeframes/${effort.timeFrameId}/team/${effort.teamId}/user/${effort.userId}`,
        body: { percent: parseInt(effort.newPercent, 10) },
        headers: { accept: 'text/plain' },
      }

      return call(del, options)
    })

    const actual = all(calls)

    expect(step()).toEqual(select(getFutureEfforts))
    expect(step(efforts)).toEqual(actual)
    expect(gen.next().done).toBe(true)
  })
})
