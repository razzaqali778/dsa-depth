import { call, put as dispatch, select } from 'redux-saga/effects'
import { fn as momentProto } from 'moment'
import {
  // SEND_DEACTIVATE_MESSAGE,
  SET_DEACTIVATION_RESULTS,
} from '../../../../src/client/redux/constants/deactivateSelections'
import {
  getCurrentTimeframeId,
  getCurrentUserId,
  getSelectedPerson,
  getSelectedReason,
} from '../../../../src/client/redux/selectors'
import { patch, put } from '../../../../src/client/redux/sagas/helpers/network'
import { deactivatePerson as saga } from '../../../../src/client/redux/sagas/deactivate/deactivatePerson'
import { urls } from '../../../urlConsts'
import saveEfforts from '../../../../src/client/redux/sagas/common/saveEfforts'

describe('deactivatePerson', () => {
  Date.now = jest.fn(() => 111) // 14.02.2017
  momentProto.format = jest.fn(arg => arg === 'x' ? 111 : 0)

  it('deactivates a person, making a put request to ezqc and patch request to cost-calc', () => {
    const gen = saga()
    const step = lastYield => gen.next(lastYield).value

    const mockSelectedPerson = 'moooooo'
    const mockSelectedReason = 'SOW'

    const mockTimeframeId = 525600

    const mockUserId = 'crg00f'

    const putOpts = {
      baseUrl: urls.qcServices,
      path: '/v1/qc/discrepancy',
      body: {
        timeFrameId: mockTimeframeId,
        userId: mockSelectedPerson,
        reason: mockSelectedReason,
        updatedTime: 111,
        updatedUserId: mockUserId,
      },
    }
    const patchOpts = {
      baseUrl: urls.costingServices,
      path: `/v1/person/${mockSelectedPerson}`,
      body: { isActive: false },
      headers: { accept: 'text/plain' },
    }

    const deactivateResult = {}
    const reasonResult = {}
    // const sendTeamsAction = {
    //   type: SEND_DEACTIVATE_MESSAGE,
    // }
    const action = {
      type: SET_DEACTIVATION_RESULTS,
      payload: {
        deactivate: { hasError: false, message: 'OK' },
        efforts: { hasError: false, message: 'OK' },
        reason: { hasError: false, message: 'OK' },
      },
    }

    expect(step()).toEqual(select(getSelectedPerson))
    expect(step(mockSelectedPerson)).toEqual(select(getSelectedReason))
    expect(step(mockSelectedReason)).toEqual(select(getCurrentTimeframeId))
    expect(step(mockTimeframeId)).toEqual(select(getCurrentUserId))
    expect(step(mockUserId)).toEqual(call(put, putOpts))
    expect(step(reasonResult)).toEqual(call(patch, patchOpts))
    expect(step(deactivateResult)).toEqual(call(saveEfforts))
    // TODO uncomment after fixing https://monsanto.aha.io/features/PT1-281
    // expect(step([{}])).toEqual(dispatch(sendTeamsAction))
    expect(step()).toEqual(dispatch(action))
    expect(gen.next().done).toBe(true)
  })
})
