import { call, put as dispatch } from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import {
  SET_SELECTED_COST_GROUP,
  SET_SELECTED_RATE,
} from '../../../../src/client/redux/constants/costGroupsRates'
import {
  SET_SELECTED_PERSON_SUGGESTION_LOADING,
  SET_SELECTED_PERSON_WITH_SUGGESTION,
} from '../../../../src/client/redux/constants/addSelections'
import { get } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import listener, {
  fetchPersonRecommendation,
} from '../../../../src/client/redux/sagas/activate/fetchPersonRecommendation'

const person = {
  employeeType: 'Employee',
  fullName: 'Kevin Ou',
  label: 'Kevin Ou (KKOU)',
  value: 'KKOU',
}

const suggestion = [{
  rateName: 'Standard',
  costGroupName: 'P&E PD',
  id: person.value,
}]

const suggestionRequest = {
  baseUrl: urls.suggestionServices,
  path: `/v1/people/user/${person.value}`,
}

const unknownUnknown = {
  rateName: 'Unknown',
  costGroupName: 'Unknown',
  id: person.value,
}

const startingAction = {
  type: SET_SELECTED_PERSON_SUGGESTION_LOADING,
  payload: true,
}

const finishingAction = {
  type: SET_SELECTED_PERSON_SUGGESTION_LOADING,
  payload: false,
}

describe('fetchPersonRecomendation', () => {
  it('listens for correct action fired', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const constants = [ 'people/FETCH_PERSON_SUGGESTION' ]

    expect(step()).toEqual(takeLatest(constants, fetchPersonRecommendation).next().value)
  })

  it('fetches suggestion for person', () => {
    const gen = fetchPersonRecommendation({ payload: person })

    const step = lastYield => gen.next(lastYield).value

    const action = {
      type: SET_SELECTED_PERSON_WITH_SUGGESTION,
      payload: { ...suggestion[0], ...person },
    }

    const costGroupAction = {
      type: SET_SELECTED_COST_GROUP,
      payload: { label: 'P&E PD' },
    }

    const rateAction = {
      type: SET_SELECTED_RATE,
      payload: { label: 'Standard' },
    }

    expect(step()).toEqual(dispatch(startingAction))
    expect(step()).toEqual(call(get, suggestionRequest))
    expect(step(suggestion)).toEqual(dispatch( costGroupAction ))
    expect(step()).toEqual(dispatch( rateAction ))
    expect(step()).toEqual(dispatch(action))
    expect(step()).toEqual(dispatch(finishingAction))
    expect(gen.next().done).toEqual(true)
  })

  it('if suggestion request fails, returns person with Unknown Unknown', () => {
    const gen = fetchPersonRecommendation({ payload: person })
    const step = lastYield => gen.next(lastYield).value

    const errrorReponse = { error: {} }

    const action = {
      type: SET_SELECTED_PERSON_WITH_SUGGESTION,
      payload: { ...unknownUnknown, ...person },
    }
    expect(step()).toEqual(dispatch(startingAction))
    expect(step()).toEqual(call(get, suggestionRequest))
    expect(step(errrorReponse)).toEqual(dispatch(action))
    expect(step()).toEqual(dispatch(finishingAction))
    expect(gen.next().done).toEqual(true)
  })

  it('if suggestion request returns empty array, person is returned with Unknown Unknown', () => {
    const gen = fetchPersonRecommendation({ payload: person })
    const step = lastYield => gen.next(lastYield).value

    const emptyArr = []
    const action = {
      type: SET_SELECTED_PERSON_WITH_SUGGESTION,
      payload: { ...unknownUnknown, ...person },
    }
    expect(step()).toEqual(dispatch(startingAction))
    expect(step()).toEqual(call(get, suggestionRequest))
    expect(step(emptyArr)).toEqual(dispatch(action))
    expect(step()).toEqual(dispatch(finishingAction))
    expect(gen.next().done).toEqual(true)
  })
})
