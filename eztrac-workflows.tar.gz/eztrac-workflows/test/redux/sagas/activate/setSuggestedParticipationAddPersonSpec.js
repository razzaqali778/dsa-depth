import { put as dispatch, select } from 'redux-saga/effects'
import { SET_PERCENT } from '../../../../src/client/redux/constants/addSelections'
import { getSuggestedEffortsAddPerson } from '../../../../src/client/redux/selectors/common/getFractionWorked'
import {
  setSuggestedParticipationAddPerson as saga,
} from '../../../../src/client/redux/sagas/activate/setSuggestedParticipationAddPerson'

describe('setSuggestedParticipation', () => {
  it('sets suggested participation in state', () => {
    const gen = saga()
    const step = lastYield => gen.next(lastYield).value

    const mockPercent = 0.5

    const action = {
      type: SET_PERCENT,
      payload: mockPercent * 100,
    }

    expect(step()).toEqual(select(getSuggestedEffortsAddPerson))
    expect(step(mockPercent)).toEqual(dispatch(action))
  })
})
