import {
  all, call, put as dispatch, select,
} from 'redux-saga/effects'
import { takeLatest } from 'redux-saga'
import {
  ADD_PERSON,
  SEND_TASK,
  SET_ADD_PERSON_RESULT,
  SET_SELECTED_PERSON_SUGGESTION_LOADING,
} from '../../../../src/client/redux/constants/addSelections'
import {
  getAddSelectedPerson,
  getCurrentEfforts,
  getCurrentTimeframeId,
  getCurrentUserId,
  getSelectedCostGroup,
  getSelectedRate,
} from '../../../../src/client/redux/selectors'
import { getNewEffortsTotal } from '../../../../src/client/redux/selectors/common/getEffortTotals'
import { put } from '../../../../src/client/redux/sagas/helpers/network'
import { urls } from '../../../urlConsts'
import listener, { addPerson } from '../../../../src/client/redux/sagas/activate/addPerson'


const selectedPerson = {
  id: 'KKOU',
  fullName: 'Kevin Ou',
  rateName: 'Standard',
  costGroupName: 'P&E PD',
  employeeType: 'Employee',
  isActive: true,
  label: 'Kevin Ou (KKOU)',
}

const selectedTeams = [
  {
    teamId: 'Freon',
    label: 'WOOOO',
    newPercent: 20,
  },
  {
    teamId: 'Freedom',
    label: 'FREEDOM',
    newPercent: 20,
  },
]

const costGroupName = { label: 'P&E PD' }
const rateName = { label: 'Standard' }

const efforts = '32100'
const userId = 'kkou'
const currentPercent = 20

const payload = {
  personId: selectedPerson.id,
  personName: selectedPerson.fullName,
  rateName: selectedPerson.rateName,
  costGroupName: selectedPerson.costGroupName,
  isEmployee: ( selectedPerson.employeeType === 'Employee' ),
  isActive: true,
  modifiedBy: 'kkou',
}

const effortPutRequest = {
  baseUrl: urls.coreServices,
  path: `/v2/efforts/timeframes/${efforts}/team/${selectedTeams[0].teamId}/user/${selectedPerson.id}`,
  body: { percent: currentPercent },
  headers: { accept: 'text/plain' },
}

const effortPutRequest2 = {
  baseUrl: urls.coreServices,
  path: `/v2/efforts/timeframes/${efforts}/team/${selectedTeams[1].teamId}/user/${selectedPerson.id}`,
  body: { percent: currentPercent },
  headers: { accept: 'text/plain' },
}

const putRequest = {
  baseUrl: urls.costingServices,
  path: '/v1/person',
  body: payload,
}

const setLoadingTrue = {
  type: SET_SELECTED_PERSON_SUGGESTION_LOADING,
  payload: true,
}

const setLoadingFalse = {
  type: SET_SELECTED_PERSON_SUGGESTION_LOADING,
  payload: false,
}

const allResult = [ null, null ]
const teams = 'WOOOO, FREEDOM'

describe('addPerson saga', () => {
  it('listens for correct action fired', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const constants = [
      ADD_PERSON,
    ]

    expect(step()).toEqual(takeLatest(constants, addPerson).next().value)
  })

  it('adds person to cost calc DB', () => {
    const gen = addPerson()
    const step = lastYield => gen.next(lastYield).value

    const action = {
      type: SET_ADD_PERSON_RESULT,
      payload: {
        person: {
          hasError: false,
          message: `Added ${payload.personName} to Costing Engine.`,
        },
        efforts: {
          hasError: false,
          message: `Added ${selectedPerson.fullName} to ${teams}`
          + ` with a percentage of ${currentPercent}%.`,
        },
      },
    }

    const sendTask = {
      type: SEND_TASK,
    }


    expect(step()).toEqual(dispatch(setLoadingTrue))
    expect(step()).toEqual(select(getAddSelectedPerson))
    expect(step(selectedPerson)).toEqual(select(getSelectedCostGroup))
    expect(step(costGroupName)).toEqual(select(getSelectedRate))
    expect(step(rateName)).toEqual(select(getCurrentUserId))
    expect(step(userId)).toEqual(select(getNewEffortsTotal))
    expect(step(currentPercent)).toEqual(select(getCurrentTimeframeId))
    expect(step(efforts)).toEqual(select(getCurrentEfforts))
    expect(step(selectedTeams)).toEqual(call(put, putRequest))
    expect(step(selectedPerson)).toEqual(all([ call(put, effortPutRequest), call(put, effortPutRequest2) ]))
    expect(step(allResult)).toEqual(dispatch(sendTask))
    expect(step()).toEqual(dispatch(action))
    expect(step()).toEqual(dispatch(setLoadingFalse))
    expect(gen.next().done).toBe(true)
  })

  it('fails to add person to calc DB', () => {
    const gen = addPerson()
    const step = lastYield => gen.next(lastYield).value

    const errorResponse = {
      error: {
        method: 'PUT',
        url: 'costing-url',
        status: 500,
      },
    }

    const effortError = {
      error: {
        status: 500,
        statusText: 'Internal Server Error',
        url: 'effort-url',
        method: 'PUT',
      },
    }
    const allResultError = [ effortError, effortError ]
    const action = {
      type: SET_ADD_PERSON_RESULT,
      payload: {
        person: {
          hasError: true,
          message: `Unable to add ${selectedPerson.fullName} to Costing Engine.\n`,
        },
        efforts: {
          hasError: true,
          message: `Unable to add ${selectedPerson.fullName} to`
          + ` ${teams} with a percentage of ${currentPercent}%.\nInternal Server Error`,
        },
      },
    }

    const teamsAction = {
      type: 'error/TEAMS_ERROR',
      payload: {
        step: 'activate',
        title: 'Workflows encountered an error activating Kevin Ou (KKOU) -- Logged in user: kkou',
        fields: [{
          title: 'Error activating to cost calc',
          value: 'method: PUT\nurl: costing-url\ntext: 500',
        }, {
          title: 'Error updating effort',
          value: 'method: PUT\nurl: effort-url\ntext: 500',
        }, {
          title: 'Error updating effort',
          value: 'method: PUT\nurl: effort-url\ntext: 500',
        }],
      },
    }

    expect(step()).toEqual(dispatch(setLoadingTrue))
    expect(step()).toEqual(select(getAddSelectedPerson))
    expect(step(selectedPerson)).toEqual(select(getSelectedCostGroup))
    expect(step(costGroupName)).toEqual(select(getSelectedRate))
    expect(step(rateName)).toEqual(select(getCurrentUserId))
    expect(step(userId)).toEqual(select(getNewEffortsTotal))
    expect(step(currentPercent)).toEqual(select(getCurrentTimeframeId))
    expect(step(efforts)).toEqual(select(getCurrentEfforts))
    expect(step(selectedTeams)).toEqual(call(put, putRequest))
    expect(step(errorResponse)).toEqual(all([ call(put, effortPutRequest), call(put, effortPutRequest2) ]))
    expect(step(allResultError)).toEqual(dispatch(teamsAction))
    expect(step()).toEqual(dispatch(action))
    expect(step()).toEqual(dispatch(setLoadingFalse))
    expect(gen.next().done).toBe(true)
  })
})
