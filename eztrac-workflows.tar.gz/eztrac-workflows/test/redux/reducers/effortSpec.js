import {
  ADD_NEW_EFFORT,
  SET_CURRENT_EFFORTS,
  SET_FUTURE_EFFORTS,
  UPDATE_PERCENT,
} from '../../../src/client/redux/constants/efforts'
import reducer from '../../../src/client/redux/reducers/efforts'

const initialState = { current: [], next: [], loading: false }

describe('efforts reducer', () => {
  it('exports the correct default state', () => {
    expect(reducer()).toEqual(initialState)
  })
  it('responds correctly to SET_CURRENT_EFFORTS', () => {
    const action = {
      type: SET_CURRENT_EFFORTS,
      payload: [{ effort: 'effort' }],
    }
    const expected = { ...initialState, current: [{ effort: 'effort' }], next: [] }
    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })

  it('responds correctly to ADD_NEW_EFFORT', () => {
    const mockState = {
      current: [{ someRandomEffort: 'yeah, mon' }],
      next: [],
      loading: false,
    }

    const action = {
      type: ADD_NEW_EFFORT,
      payload: {
        newPercent: 41,
        teamId: 'Flarius',
        teamName: 'Agrigarius',
        timeFrameId: 1234,
      },
    }

    const expected = { ...mockState, current: [ ...mockState.current, action.payload ], next: [] }
    const actual = reducer(mockState, action)
    expect(actual).toEqual(expected)
  })

  it('responds correctly to SET_FUTURE_EFFORTS', () => {
    const action = {
      type: SET_FUTURE_EFFORTS,
      payload: [{ effort: 'effort' }],
    }
    const expected = { ...initialState, current: [], next: [{ effort: 'effort' }] }
    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })
  it('ignores unrecognized actions', () => {
    const action = {
      type: 'OTHER_ACTION',
      payload: [{ effort: 'whatever' }],
    }
    const state = { ...initialState, current: [{ effort: 'Some Effort' }], next: [] }
    const actual = reducer(state, action)
    expect(actual).toEqual(state)
  })

  it('UPDATE_PERCENT updates effort percentage in state on change', () => {
    const mockState = {
      current: [{
        timeFrameId: 32008,
        teamId: 'RICOCHET',
        percent: 100,
        userId: 'MSKEMM',
      },
      {
        timeFrameId: 32008,
        teamId: 'ELD-TEAM-2',
        percent: 100,
        userId: 'MSKEMM',
      }],
      next: [],
    }

    const action = {
      type: UPDATE_PERCENT,
      payload: { teamId: 'ELD-TEAM-2', newPercent: 20 },
    }

    const result = reducer(mockState, action)

    const expected = {
      ...initialState,
      current: [{
        timeFrameId: 32008,
        teamId: 'RICOCHET',
        percent: 100,
        userId: 'MSKEMM',
      },
      {
        timeFrameId: 32008,
        teamId: 'ELD-TEAM-2',
        percent: 100,
        userId: 'MSKEMM',
        newPercent: 20,
        errorText: '',
      }],
      next: [],
    }

    expect(result).toEqual(expected)
  })

  it('UPDATE_PERCENT returns Not A Number error if input is not a number.', () => {
    const mockState = {
      ...initialState,
      current: [{
        timeFrameId: 32008,
        teamId: 'RICOCHET',
        percent: 100,
        userId: 'MSKEMM',
      },
      {
        timeFrameId: 32008,
        teamId: 'ELD-TEAM-2',
        percent: 100,
        userId: 'MSKEMM',
      }],
      next: [],
    }
    const action = {
      type: UPDATE_PERCENT,
      payload: { teamId: 'ELD-TEAM-2', newPercent: 'gonna break things wee' },
    }

    const actual = reducer(mockState, action)

    const expected = {
      ...initialState,
      current: [{
        timeFrameId: 32008,
        teamId: 'RICOCHET',
        percent: 100,
        userId: 'MSKEMM',
      },
      {
        timeFrameId: 32008,
        teamId: 'ELD-TEAM-2',
        percent: 100,
        userId: 'MSKEMM',
        errorText: 'Not A Number',
        newPercent: 'gonna break things wee',
      }],
      next: [],
    }

    expect(actual).toEqual(expected)
  })

  it('UPDATE_PERCENT sets the error text to Out Of Range when input is under 0%.', () => {
    const mockState = {
      current: [{
        timeFrameId: 32008,
        teamId: 'RICOCHET',
        percent: 100,
        userId: 'MSKEMM',
      },
      {
        timeFrameId: 32008,
        teamId: 'ELD-TEAM-2',
        percent: 100,
        userId: 'MSKEMM',
      }],
      next: [],
    }

    const mockInput = '-1'

    const action = {
      type: UPDATE_PERCENT,
      payload: { teamId: 'ELD-TEAM-2', newPercent: mockInput },
    }

    const actual = reducer(mockState, action)

    const expected = {
      ...initialState,
      current: [{
        timeFrameId: 32008,
        teamId: 'RICOCHET',
        percent: 100,
        userId: 'MSKEMM',
      },
      {
        timeFrameId: 32008,
        teamId: 'ELD-TEAM-2',
        percent: 100,
        userId: 'MSKEMM',
        errorText: 'Out Of Range',
        newPercent: '-1',
      }],
      next: [],
    }

    expect(actual).toEqual(expected)
  })

  it('UPDATE_PERCENT sets the error text to Out Of Range when input is over 100%.', () => {
    const mockState = {
      current: [{
        timeFrameId: 32008,
        teamId: 'RICOCHET',
        percent: 100,
        userId: 'MSKEMM',
      },
      {
        timeFrameId: 32008,
        teamId: 'ELD-TEAM-2',
        percent: 100,
        userId: 'MSKEMM',
      }],
      next: [],
    }

    const mockInput = '101'

    const action = {
      type: UPDATE_PERCENT,
      payload: { teamId: 'ELD-TEAM-2', newPercent: mockInput },
    }

    const actual = reducer(mockState, action)

    const expected = {
      ...initialState,
      current: [{
        timeFrameId: 32008,
        teamId: 'RICOCHET',
        percent: 100,
        userId: 'MSKEMM',
      },
      {
        timeFrameId: 32008,
        teamId: 'ELD-TEAM-2',
        percent: 100,
        userId: 'MSKEMM',
        errorText: 'Out Of Range',
        newPercent: '101',
      }],
      next: [],
    }

    expect(actual).toEqual(expected)
  })
})

