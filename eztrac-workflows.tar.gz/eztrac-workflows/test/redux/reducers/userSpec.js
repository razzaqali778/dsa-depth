import { SET_USER } from '../../../src/client/redux/constants/user'
import reducer from '../../../src/client/redux/reducers/user'

const initialState = {
  entitlements: {
    'my-app': [],
  },
}

describe('User reducer', () => {
  it('exports the correct default state', () => {
    expect(reducer()).toEqual(initialState)
  })

  it('responds correctly to SET_USER', () => {
    const action = {
      type: SET_USER,
      payload: { entitlements: 'SEAN KIM' },
    }

    const expected = {
      ...initialState,
      entitlements: 'SEAN KIM',
    }

    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })
})

