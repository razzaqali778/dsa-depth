import { RESET_STEPPER } from '../../../src/client/redux/constants/resetWorkflow'
import {
  SET_ADD_PERSON_RESULT,
  SET_PERCENT,
  SET_SELECTED_PERSON_SUGGESTION_LOADING,
  SET_SELECTED_PERSON_WITH_SUGGESTION,
  SET_START_DATE,
} from '../../../src/client/redux/constants/addSelections'
import reducer from '../../../src/client/redux/reducers/addSelections'

const initialState = {
  addedPersonResults: null,
  selectedPerson: null,
  suggestionLoading: false,
  startDate: new Date().toLocaleDateString(),
  percent: null,
}

describe('addselections reducer spec', () => {
  it('exports the default state', () => {
    const actual = reducer()
    expect(actual).toEqual(initialState)
  })

  it('sets the added person result in state', () => {
    const action = {
      type: SET_ADD_PERSON_RESULT,
      payload: {
        added: true,
        message: 'Successfully added GARYIUS.',
      },
    }

    const expected = {
      ...initialState,
      addedPersonResults: action.payload,
    }

    const actual = reducer(initialState, action)

    expect(actual).toEqual(expected)
  })

  it('sets the currently selected person in the store', () => {
    const action = {
      type: SET_SELECTED_PERSON_WITH_SUGGESTION,
      payload: {
        label: 'Mike Weaver',
        value: 'MAWEAV1',
        employeeType: 'Employee',
        rateName: 'Standard',
        costGroupName: 'P&E Leadership and Admin',
        id: 'MAWEAV1',
      },
    }

    const expected = {
      ...initialState,
      selectedPerson: action.payload,
    }

    const actual = reducer(initialState, action)

    expect(actual).toEqual(expected)
  })

  it('sets the add person page to true when loading', () => {
    const action = {
      type: SET_SELECTED_PERSON_SUGGESTION_LOADING,
      payload: true,
    }

    const expected = {
      ...initialState,
      suggestionLoading: action.payload,
    }

    const actual = reducer(initialState, action)

    expect(actual).toEqual(expected)
  })

  it('reset add person workflow', () => {
    const action = {
      type: RESET_STEPPER,
      payload: {},
    }

    const somethingState = {
      addedPersonResults: {
        added: true,
      },
      selectedPerson: {
        Darius: true,
      },
      suggestionLoading: true,
      startDate: new Date().toLocaleDateString(),
    }

    const actual = reducer(somethingState, action)

    expect(actual).toEqual({ ...initialState, startDate: somethingState.startDate })
  })


  it('sets start date for new person in state', () => {
    const currentDate = '11/12/2017'

    const action = {
      type: SET_START_DATE,
      payload: currentDate,
    }

    const expected = {
      ...initialState,
      startDate: action.payload,
    }

    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })

  it('sets percent for new person in state', () => {
    const percent = 50

    const action = {
      type: SET_PERCENT,
      payload: percent,
    }

    const expected = {
      ...initialState,
      percent: action.payload,
    }

    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })
})
