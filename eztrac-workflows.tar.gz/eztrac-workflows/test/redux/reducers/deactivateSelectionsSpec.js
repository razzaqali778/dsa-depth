import {
  SET_DEACTIVATE_REASONS,
  SET_DEACTIVATION_RESULTS,
  SET_END_DATE,
  SET_SELECTED_PERSON,
  SET_SELECTED_REASON,
} from '../../../src/client/redux/constants/deactivateSelections'
import reducer from '../../../src/client/redux/reducers/deactivateSelections'

global.Date = jest.fn(() => 111)

const initialState = {
  deactivationResults: null,
  selectedReason: null,
  selectedPerson: null,
  endDate: new Date(),
  deactivateReasons: [],
  previousSite: [],
}

describe('deactivateSelections reducer', () => {
  it('exports the default state', () => {
    const actual = reducer()
    expect(actual).toEqual(initialState)
  })

  it('sets the currently selected person in the store', () => {
    const action = {
      type: SET_SELECTED_PERSON,
      payload: { label: 'an id', value: 'an id' },
    }

    const expected = {
      ...initialState,
      selectedPerson: 'an id',
    }

    const actual = reducer(initialState, action)

    expect(actual).toEqual(expected)
  })

  it('sets the selected reason in the store', () => {
    const action = {
      type: SET_SELECTED_REASON,
      payload: { label: 'A reason', value: 'A reason value' },
    }
    const actual = reducer(initialState, action)
    const expected = {
      ...initialState,
      selectedReason: 'A reason value',
    }
    expect(actual).toEqual(expected)
  })

  it('sets the deactivation results in the store', () => {
    const action = {
      type: SET_DEACTIVATION_RESULTS,
      payload: {
        deactivate: false,
        reason: false,
      },
    }
    const actual = reducer(initialState, action)
    const expected = {
      ...initialState,
      deactivationResults: { deactivate: false, reason: false },
    }
    expect(actual).toEqual(expected)
  })
  it('sets the deactivation results in the store', () => {
    const action = {
      type: SET_DEACTIVATION_RESULTS,
      payload: {
        efforts: false,
      },
    }
    const state = {
      ...initialState,
      deactivationResults: { deactivate: false, reason: false },
    }
    const actual = reducer(state, action)
    const expected = {
      ...initialState,
      deactivationResults: { deactivate: false, efforts: false, reason: false },
    }
    expect(actual).toEqual(expected)
  })
  it('sets the end date results in the store', () => {
    const action = {
      type: SET_END_DATE,
      payload: 123,
    }
    const actual = reducer(initialState, action)
    const expected = {
      ...initialState,
      endDate: 123,
    }
    expect(actual).toEqual(expected)
  })

  it('responds correctly to SET_DEACTIVATE_REASONS', () => {
    const action = {
      type: SET_DEACTIVATE_REASONS,
      payload: [ 'some', 'data' ],
    }
    const actual = reducer(initialState, action)
    const expected = {
      ...initialState,
      deactivateReasons: [ 'some', 'data' ],
    }
    expect(actual).toEqual(expected)
  })

  it('ignores unreconized actions', () => {
    const action = {
      type: 'SOME_OTHER_ACTION',
      payload: { label: 'A', value: 'an id' },
    }
    const actual = reducer(initialState, action)
    expect(actual).toEqual(initialState)
  })
})
