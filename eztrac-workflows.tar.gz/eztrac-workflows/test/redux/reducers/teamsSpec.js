import { SET_ALL_TEAMS } from '../../../src/client/redux/constants/teams'
import reducer from '../../../src/client/redux/reducers/teams'

const initialState = {
  teams: null,
}

describe('addselections reducer spec', () => {
  it('exports the default state', () => {
    const actual = reducer()
    expect(actual).toEqual(initialState)
  })

  it('sets all teams in state', () => {
    const action = {
      type: SET_ALL_TEAMS,
      payload: [
        {
          id: '11652',
          name: 'Data Delivery - Advancement',
        },
        {
          id: '11653',
          name: 'Data Delivery - Genomics',
        }],
    }

    const expected = {
      ...initialState,
      teams: action.payload,
    }

    const actual = reducer(initialState, action)

    expect(actual).toEqual(expected)
  })
})
