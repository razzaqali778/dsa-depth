import {
  SET_ALL_COST_GROUP_DATA,
  SET_ALL_RATE_DATA,
  SET_SELECTED_COST_GROUP,
  SET_SELECTED_RATE,
} from '../../../src/client/redux/constants/costGroupsRates'
import reducer from '../../../src/client/redux/reducers/costGroupsRates' //eslint-disable-line

describe('Cost Group Reducer Spec', () => {
  const emptyInitialState = {
    costGroupData: null,
    rateData: null,
    selectedCostGroup: null,
    selectedRate: null,
  }

  it('exports the correct default state', () => {
    expect(reducer()).toEqual(emptyInitialState)
  })

  it('responds to SET_ALL_COST_GROUP_DATA', () => {
    const action = {
      type: SET_ALL_COST_GROUP_DATA,
      payload: [
        {
          id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
        },
        {
          id: 'TPS', name: 'Technology Pipeline Solutions', costCenter: '82AB', isActive: false,
        },
      ],
    }

    const expected = {
      ...emptyInitialState,
      costGroupData: action.payload,
    }

    expect(reducer(emptyInitialState, action)).toEqual(expected)
  })


  it('responds to SET_ALL_RATE_DATA', () => {
    const action = {
      type: SET_ALL_RATE_DATA,
      payload: [
        {
          name: 'Slalom SOW',
          hourlyRate: '160',
          id: 'SLALOM-SOW',
          isActive: 'true',
          modifiedBy: 'automatic',
        },
        {
          name: 'High Rate',
          hourlyRate: '125',
          id: 'HIGH-RATE',
          isActive: 'true',
          modifiedBy: 'automatic',
        },
      ],
    }

    const expected = {
      ...emptyInitialState,
      rateData: action.payload,
    }

    expect(reducer(emptyInitialState, action)).toEqual(expected)
  })

  it('returns the previous value if an empty array is passed when setting cost group', () => {
    const mockState = {
      ...emptyInitialState,
      selectedCostGroup: {
        label: 'darius scarius',
      },
    }

    const action = {
      type: SET_SELECTED_COST_GROUP,
      payload: [],
    }

    expect(reducer(mockState, action)).toEqual(mockState)
  })

  it('returns the previous value if an empty array is passed when setting rate', () => {
    const mockState = {
      ...emptyInitialState,
      selectedRate: {
        label: 'darius scarius rate',
      },
    }

    const action = {
      type: SET_SELECTED_RATE,
      payload: [],
    }

    expect(reducer(mockState, action)).toEqual(mockState)
  })
})
