import {
  SET_ALL_TIMEFRAMES,
  SET_CURRENT_TIMEFRAME,
  SET_NEXT_TIMEFRAME,
} from '../../../src/client/redux/constants/timeframes'
import reducer from '../../../src/client/redux/reducers/timeframes'

const initialState = { allTimeframes: {}, currentTimeframe: {}, nextTimeframe: {} }

describe('timeframes reducer', () => {
  it('exports the correct default state', () => {
    expect(reducer()).toEqual(initialState)
  })

  it('responds correctly to SET_ALL_TIMEFRAMES', () => {
    const action = {
      type: SET_ALL_TIMEFRAMES,
      payload: [{ name: 'name1' }, { name: 'name2' }, { name: 'name3' }, { name: 'name4' }],
    }
    const expected = {
      ...initialState,
      allTimeframes: [
        { name: 'name1' },
        { name: 'name2' },
        { name: 'name3' },
        { name: 'name4' },
      ],
    }
    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })

  it('responds correctly to SET_CURRENT_TIMEFRAME', () => {
    const action = {
      type: SET_CURRENT_TIMEFRAME,
      payload: { name: 'name1' },
    }
    const expected = { ...initialState, currentTimeframe: { name: 'name1' } }
    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })

  it('responds correctly to SET_NEXT_TIMEFRAME', () => {
    const action = {
      type: SET_NEXT_TIMEFRAME,
      payload: { name: 'name1' },
    }
    const expected = { ...initialState, nextTimeframe: { name: 'name1' } }
    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })

  it('ignores other constants', () => {
    const action = {
      type: 'some other constant',
      payload: [{ name: 'name1' }, { name: 'name2' }],
    }
    const state = {
      allTimeframes: [ '0', 'bill', '123' ],
      currentTimeframe: 'bill',
      nextTimeframe: '123',
    }
    const expected = { ...state }
    const actual = reducer(state, action)
    expect(actual).toEqual(expected)
  })
})
