import getOrElse from 'lodash/get'
import { DEACTIVATE_WORKFLOW } from '../../../src/client/redux/constants/pages'
import { RESET_STEPPER } from '../../../src/client/redux/constants/resetWorkflow'
import {
  SET_STEP,
  STEP_NEXT,
  STEP_PREVIOUS,
} from '../../../src/client/redux/constants/stepper'
import reducer from '../../../src/client/redux/reducers/stepper'

const initialState = 0

describe('Stepper Tests', () => {
  it('exports the correct default state', () => {
    expect(reducer()).toEqual(initialState)
  })

  it('responds correctly to STEP_NEXT', () => {
    const action = {
      type: STEP_NEXT,
    }

    const expected = initialState + 1

    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })

  it('responds correctly to STEP_PREVIOUS', () => {
    const action = {
      type: STEP_PREVIOUS,
    }

    const expected = initialState - 1

    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })

  it('responds correctly to SET_STEP', () => {
    const action = {
      type: SET_STEP,
      payload: 666,
    }

    const expected = action.payload

    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })

  it('responds correctly to RESET_STEPPER', () => {
    const action = {
      type: RESET_STEPPER,
    }

    const expected = 0

    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })

  it('responds correctly to DEACTIVATE_WORKFLOW', () => {
    const action = {
      type: DEACTIVATE_WORKFLOW,
    }

    const expected = parseInt(getOrElse(action, 'meta.query.step', initialState), 10)

    const actual = reducer(initialState, action)
    expect(actual).toEqual(expected)
  })
})
