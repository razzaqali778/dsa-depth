import { SET_PAPI_PEOPLE, SET_PEOPLE } from '../../../src/client/redux/constants/people'
import reducer from '../../../src/client/redux/reducers/people'

const initialState = {
  allPeople: [],
  papiPeople: [],
}

describe('people reducer', () => {
  it('exports the correct default state', () => {
    expect(reducer()).toEqual(initialState)
  })

  it('responds correctly to SET_PEOPLE', () => {
    const action = {
      type: SET_PEOPLE,
      payload: [{ name: 'name1' }, { name: 'name2' }],
    }
    const expected = [{ name: 'name1' }, { name: 'name2' }]
    const actual = reducer(initialState, action)

    expect(actual).toEqual({ ...initialState, allPeople: expected })
  })

  it('responds correctly to SET_PAPI_PEOPLE', () => {
    const action = {
      type: SET_PAPI_PEOPLE,
      payload: [{ value: 'NAME', label: 'label' }],
    }
    const expected = [{ value: 'NAME', label: 'label' }]
    const actual = reducer(initialState, action)

    expect(actual).toEqual({ ...initialState, papiPeople: expected })
  })

  it('ignores unrecognized actions', () => {
    const action = {
      type: 'OTHER_ACTION',
      payload: [{ name: 'name1' }, { name: 'name2' }],
    }
    const actual = reducer(initialState, action)

    expect(actual).toEqual(initialState)
  })
})
