import { SET_HEALTH_CHECK } from '../../../src/client/redux/constants/healthCheck'
import reducer from '../../../src/client/redux/reducers/healthCheck' //eslint-disable-line

describe('Health Check reducer spec', () => {
  const emptyInitialState = {
    healthCheck: {},
  }

  it('exports the correct default state', () => {
    expect(reducer()).toEqual(emptyInitialState)
  })

  it('responds correctly to SET_HEALTH_CHECK, sets healthCheck result in state', () => {
    const action = {
      type: SET_HEALTH_CHECK,
      payload: {
        timeframeid: 42301,
      },
    }

    const expected = {
      ...emptyInitialState,
      healthCheck: action.payload,
    }
    const actual = reducer(emptyInitialState, action)

    expect(actual).toEqual(expected)
  })
})
