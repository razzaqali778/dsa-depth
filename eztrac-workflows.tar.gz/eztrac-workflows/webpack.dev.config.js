const webpack = require('webpack')

const path = `${__dirname}/public/scripts/`

module.exports = {
  mode: 'development',
  devtool: 'source-map',
  entry: [
    './src/client/styles/style.scss',
    './src/client',
  ],
  module: {
    rules: [
      { test: /\.m?js$/, resolve: { fullySpecified: false } },
      { test: /\.jsx?$/, use: 'babel-loader', exclude: /node_modules/ },
      {
        test: /\.s?css$/,
        use: ['style-loader', 'css-loader', 'sass-loader'],
      },
    ],
  },
  output: {
    filename: 'bundle.js',
    path,
    publicPath: '/ez-trac-workflows/scripts/',
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: JSON.stringify('development'),
      },
    }),
  ],
  resolve: {
    extensions: [
      '.js',
      '.json',
      '.jsx',
    ],
  },
}
