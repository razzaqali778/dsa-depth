# FLEX Documentation

Read these first:

1. [Architecture](./architecture.md)
2. [Module Blueprint](./module-blueprint.md)
3. [Observability (OTEL + Grafana)](./observability.md)
4. [Local SonarQube](./sonarqube-local.md)
5. [FLEX architecture draw.io](./diagrams/flex-architecture.drawio)

ADRs:

- [RPT Integration Approach](./adr/rpt-integration-approach.md)
- [RabbitMQ Message Broker](./adr/rabbitmq-message-broker.md)

Doc rule:

```text
Keep docs small.
Do not duplicate architecture explanations across multiple files.
Update the draw.io diagram when module, DB, source API, or broker boundaries change.
```
