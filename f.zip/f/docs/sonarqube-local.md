# Local SonarQube

SonarQube starts automatically with **`make up`** (same as Grafana and Postgres).

## Fixed local credentials

After the first successful bootstrap, these stay the same on every run:

| | Value |
|---|--------|
| **URL** | http://localhost:9000 |
| **Login** | `admin` |
| **Password** | `Flex-Sonar-Dev1` |
| **Project key** | `flex` |

The scan token is written to **`.flex/sonar/dev-credentials.env`** (gitignored). `make urls` prints login + token after bootstrap.

First SonarQube start can take **2–3 minutes** — `make status` shows when it is ready.

## Skip Sonar on startup

```bash
make up SONAR=0
```

## Stop Sonar without tearing down everything

```bash
make sonar-down
```

## Run a scan manually

```bash
npm run test:coverage
make sonar-scan
# or
npm run sonar:scan
```

`sonar-scan` loads the token from `.flex/sonar/dev-credentials.env` if `SONAR_TOKEN` is empty in `.env`.

Coverage reports from `apps/api/coverage/lcov.info` and `apps/web/coverage/lcov.info` are uploaded with the analysis.

## Git hook integration

The pre-push hook runs `npm run sonar:scan` after build and coverage. If SonarQube is not running or `SONAR_TOKEN` is missing, the scan is **skipped with a warning** (push is not blocked).

Set `SONAR_SCAN_STRICT=true` in `.env` to fail the push when Sonar is unreachable or coverage is missing.

## Reset Sonar data

```bash
make reset-infra   # removes volumes — next `make up` re-provisions project + token
```

## SonarCloud (optional)

```env
SONAR_CLOUD=true
SONAR_HOST_URL=https://sonarcloud.io
SONAR_ORGANIZATION=your-org
SONAR_TOKEN=your-cloud-token
SONAR_PROJECT_KEY=your-cloud-project-key
```

## Related

- [Git hooks plan](../plans/githooks.md)
- [Sonar + OTEL plan](../plans/sonar_otel_grafana.md)
