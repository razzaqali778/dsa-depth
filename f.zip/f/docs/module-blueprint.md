# FLEX Module Blueprint

## Generated Backend Structure

`npm run module -- module-name` creates the NestJS module boilerplate:

```text
apps/api/src/modules/{module}/
  {module}.definition.ts
  {module}.module.ts
  application/
    ports/
      {module}-event-publisher.port.ts
      {module}-repository.port.ts
      {module}-source-adapter.port.ts
    services/
      {module}.service.ts
  domain/
    events/
      {module}-snapshot-stored.event.ts
  infrastructure/
    events/
      README.md
    integrations/
      README.md
    persistence/
      README.md
  presentation/
    controllers/
      {module}.controller.ts
    dto/
      {module}-summary.response.ts
```

The generated module definition includes:

```text
databaseName: flex_{module}
databaseUrlEnvVar: {MODULE}_DATABASE_URL
```

## Generated Frontend Structure

```text
apps/web/src/modules/{module}/
  api/
    {module}.api.ts
  pages/
    {module}-page.tsx
  state/
    {module}.slice.ts
  types/
    {module}.types.ts
```

## Command

```bash
npm run module -- module-name
```

If `make` is installed:

```bash
make module MODULE=module-name
```

After generation, register:

- backend module in `apps/api/src/app.module.ts`
- module definition in `apps/api/src/platform/modules/flex-module.catalog.ts`
- frontend route in `apps/web/src/app/router/app-router.tsx`
- frontend reducer in `apps/web/src/app/store/module-reducers.ts`

## Redux Toolkit

Every generated frontend module gets a Redux Toolkit slice:

```text
apps/web/src/modules/{module}/state/{module}.slice.ts
```

The slice includes:

- `status`
- `selectedId`
- `error`

Register it in:

```text
apps/web/src/app/store/module-reducers.ts
```

## Where Integration Goes

Integration is inside the owning module, not in a separate business module.

Examples:

```text
Outcomes owns Workpath adapter:
apps/api/src/modules/outcomes/infrastructure/integrations/workpath

FinOps owns EzTrac, Planview, DataOne adapters:
apps/api/src/modules/finops/infrastructure/integrations/eztrac
apps/api/src/modules/finops/infrastructure/integrations/planview
apps/api/src/modules/finops/infrastructure/integrations/dataone

People Planning owns RPT and Workday adapters:
apps/api/src/modules/people-planning/infrastructure/integrations/rpt
apps/api/src/modules/people-planning/infrastructure/integrations/workday
```

Shared integration types live in:

```text
apps/api/src/platform/integration
```

Frontend-specific response types live in the respective frontend module.

## Flow Per Module

Read flow:

```text
controller -> service -> repository -> module physical DB
```

Refresh/sync flow:

```text
controller -> service -> source adapter -> external API -> canonical event -> subscriber -> repository -> module physical DB
```

The frontend never calls an external system directly.
