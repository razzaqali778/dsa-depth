# Observability (OpenTelemetry + Grafana)

## Start the stack

```bash
make observability
```

Or start everything (Postgres + Sonar + observability):

```bash
make stack
```

Stop:

```bash
make observability-down
make stack-down
```

## Local URLs

| Service | URL |
|---------|-----|
| Grafana | http://localhost:3001 |
| Prometheus | http://localhost:9090 |
| Tempo | http://localhost:3200 |
| OTEL Collector (OTLP HTTP) | http://localhost:4318 |
| OTEL Collector (OTLP gRPC) | localhost:4317 |

Pre-provisioned Grafana dashboards (folder **FLEX**):

- **FLEX Platform Overview**
- **FLEX API — Traces**
- **FLEX API — Metrics**

## Configure the API

Copy [`.env.example`](../.env.example) to `.env`:

```env
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318
OTEL_SERVICE_NAME=flex-api
```

Start the API:

```bash
npm run dev:api
```

Generate traces:

```bash
curl http://localhost:3000/api/auth/summary
curl http://localhost:3000/api/health
```

Within ~30 seconds, open Grafana → **Explore → Tempo** and search for `resource.service.name = "flex-api"`.

## Architecture

```text
flex-api (NestJS)
  → OTLP HTTP :4318
  → OTEL Collector
       ├─ traces  → Tempo
       └─ metrics → Prometheus (:8889 scrape)
  → Grafana (datasources pre-linked)
```

Custom spans are created by:

- [`TracingInterceptor`](../apps/api/src/platform/telemetry/tracing.interceptor.ts) — controller layer
- [`@Traced()`](../apps/api/src/platform/telemetry/traced.decorator.ts) — service layer
- Auto-instrumentation — HTTP, Express, PostgreSQL

## Troubleshooting

| Problem | Fix |
|---------|-----|
| No traces in Grafana | Run `make observability`; confirm `OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318` |
| API starts but no export | Check collector logs: `docker compose logs otel-collector` |
| Port 3000 vs 3001 | API runs on **3000**; Grafana runs on **3001** |
| Disable telemetry in tests | Set `OTEL_SDK_DISABLED=true` |

## Adding dashboards

See the [Grafana dashboards skill](../.cursor/skills/grafana-dashboards/SKILL.md).

## Related

- [Sonar + OTEL plan](../plans/sonar_otel_grafana.md)
