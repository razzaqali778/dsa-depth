# FLEX Architecture

## Decision

FLEX is a modular monolith.

There are four business modules inside one NestJS API:

- Outcomes
- Business UseCase
- FinOps
- People Planning

Integration is not a fifth business module. Integration is a boundary:

- shared platform ports live under `apps/api/src/platform/integration`
- concrete external API clients live inside the owning module
- data is stored only by the owning module in its own physical DB
- each business module has a separate physical database

## Layers

| Layer | Purpose | Location |
| --- | --- | --- |
| Network layer | API prefix, CORS, validation, ingress-facing HTTP setup | `apps/api/src/platform/network` |
| Auth layer | gateway user headers, local auth mode, guards | `apps/api/src/platform/auth` |
| API layer | Nest controllers and DTOs | `apps/api/src/modules/*/presentation` |
| Service layer | module application orchestration | `apps/api/src/modules/*/application/services` |
| Integration ports | shared adapter contracts | `apps/api/src/platform/integration` |
| Module adapters | external API clients and mappers owned by a module | `apps/api/src/modules/*/infrastructure/integrations` |
| Data layer | module repository ports and physical database metadata | `apps/api/src/platform/database` and `apps/api/src/modules/*/application/ports` |
| Messaging layer | future event bus/RabbitMQ contract | `apps/api/src/platform/messaging` |

## Shared Code Rule

There are no shared contracts or shared database packages in the boilerplate.

Rules:

- module API DTOs stay inside their respective API or web module
- module event types stay inside their respective API module
- database code stays inside the owning module `infrastructure/persistence`
- shared platform contracts stay under `apps/api/src/platform`

## Module Ownership

| Module | Owns DB | Owns external adapters | Stores |
| --- | --- | --- | --- |
| Outcomes | database `flex_outcomes` | Workpath | Workpath outcome snapshots and FLEX outcome data |
| Business UseCase | database `flex_business_usecase` | module projections | ROI, business cases, prioritization projections |
| FinOps | database `flex_finops` | EzTrac, Planview, DataOne | forecasts, actuals, variance snapshots |
| People Planning | database `flex_people_planning` | RPT, Workday | skills, staffing, capacity snapshots |

The integration layer does not own business data. It only defines shared contracts and technical rules.

## Normal Read / CRUD Flow

Frontend reads from FLEX only.

```text
React page
  -> shared API client
  -> API Gateway / ALB / ingress
  -> Nest controller
  -> module service
  -> module repository
  -> owning module DB
```

Example:

```text
People Planning page
  -> GET /api/people-planning/...
  -> PeoplePlanningController
  -> PeoplePlanningService
  -> PeoplePlanningRepository
  -> database flex_people_planning
```

## Source Sync / Refresh Flow

When the frontend triggers refresh, FLEX still goes through the backend.

```text
React refresh action
  -> module API endpoint
  -> module service / sync use case
  -> module-owned source adapter
  -> external system API
  -> canonical mapper
  -> publish canonical source snapshot event
  -> owning module subscriber/handler
  -> owning module repository
  -> owning module DB
```

In the modulith, the publish/subscribe step can be in-process first. RabbitMQ is added only when the team accepts the async runtime design.

## Broker Rule

RabbitMQ is not used for simple reads.

RabbitMQ is for:

- canonical source snapshot events
- cross-module projection updates
- long-running async workflows
- future service extraction

Planned broker shape:

```text
module publisher
  -> EventBusPort
  -> RabbitMQ exchange
  -> module subscriber
  -> owning module DB
```

Before adding runtime RabbitMQ code, define:

- exchange names
- routing keys
- queue ownership
- retry policy
- DLQ policy
- idempotency keys
- security and operations owner

## Physical Database Rule

FLEX uses one backend runtime, but multiple physical databases.

```text
NestJS API on one port
  -> OUTCOMES_DATABASE_URL
  -> BUSINESS_USECASE_DATABASE_URL
  -> FINOPS_DATABASE_URL
  -> PEOPLE_PLANNING_DATABASE_URL
```

| Boundary | Physical database | Env var |
| --- | --- | --- |
| Outcomes DB | `flex_outcomes` | `OUTCOMES_DATABASE_URL` |
| Business UseCase DB | `flex_business_usecase` | `BUSINESS_USECASE_DATABASE_URL` |
| FinOps DB | `flex_finops` | `FINOPS_DATABASE_URL` |
| People Planning DB | `flex_people_planning` | `PEOPLE_PLANNING_DATABASE_URL` |
| Integration Control DB | `flex_integration_control` | `INTEGRATION_CONTROL_DATABASE_URL` |

Rules:

- a module writes only its own physical DB
- source snapshots are stored in the respective module DB
- integration control stores technical sync status only
- cross-module reads use APIs, projections, or events
- no direct SQL joins across module databases as an integration pattern

## Diagram

Open the editable draw.io file:

- [FLEX architecture draw.io](./diagrams/flex-architecture.drawio)
