.PHONY: up-apps down-apps api web

up-apps:
	@./scripts/ops/start-apps.sh

down-apps:
	@./scripts/ops/stop-apps.sh

api:
	@$(NPM) run dev:api

web:
	@$(NPM) run dev:web
