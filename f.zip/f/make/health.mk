.PHONY: up down status urls wait-healthy help runtime

.DEFAULT_GOAL := help

runtime:
	@./scripts/ops/container-runtime.sh info || (echo "No container runtime ready." && exit 1)

help:
	@echo "FLEX operations — run 'make <target>'"
	@echo ""
	@echo "Primary:"
	@echo "  runtime         Show detected container runtime (podman/docker)"
	@echo "  up              Start infra (Postgres + Grafana/OTEL + SonarQube) + apps"
	@echo "  down            Stop apps and container infra"
	@echo "  status          Rich service dashboard (health, uptime, memory, tips)"
	@echo "  urls            Print local URLs"
	@echo ""
	@echo "Flags (with make up):"
	@echo "  APPS=0          Infra only (no API/web)"
	@echo "  OBSERVABILITY=0 Skip Grafana/OTEL (Postgres + SonarQube still start)"
	@echo "  SONAR=0         Skip SonarQube (on by default)"
	@echo "  FLEX_BIND_HOST=0.0.0.0  Expose ports on LAN (default: 127.0.0.1)"
	@echo "  FLEX_ENV=cloud  Skip local Postgres (cloud DB URLs in .env)"
	@echo ""
	@echo "Infra:"
	@echo "  up-infra        Postgres + observability + SonarQube (SONAR=0 to skip)"
	@echo "  down-infra      Stop all container services"
	@echo "  logs SERVICE=x  Tail compose logs (e.g. SERVICE=grafana)"
	@echo ""
	@echo "Apps:"
	@echo "  up-apps         Start API + Web in background"
	@echo "  down-apps       Stop background API + Web"
	@echo "  api / web       Start one app in foreground"
	@echo ""
	@echo "Quality:"
	@echo "  test / typecheck / build / sonar-scan"

up: up-infra wait-healthy
	@if [ "$(APPS)" = "1" ]; then $(MAKE) up-apps; fi
	@$(OPS)/print-urls.sh

down: down-apps down-infra

status:
	@FORCE_COLOR=1 $(OPS)/status.sh

urls:
	@$(OPS)/print-urls.sh

wait-healthy:
	@$(OPS)/wait-healthy.sh
