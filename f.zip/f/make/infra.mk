.PHONY: up-infra up-infra-minimal up-infra-full down-infra logs reset-infra sonar-reset \
	deps observability observability-down sonar sonar-down stack stack-down

up-infra:
	@./scripts/ops/up-infra.sh

up-infra-minimal:
	@$(COMPOSE) up -d postgres

up-infra-full:
	@$(COMPOSE) up -d postgres
	@$(COMPOSE) --profile observability up -d tempo prometheus loki otel-collector grafana
	@$(COMPOSE) --profile sonar up -d sonar-db sonarqube

down-infra:
	@$(COMPOSE) --profile observability --profile sonar down --remove-orphans 2>/dev/null || true
	@$(COMPOSE) down --remove-orphans 2>/dev/null || true

logs:
	@test -n "$(SERVICE)" || (echo "Usage: make logs SERVICE=grafana" && exit 1)
	@$(COMPOSE) logs -f $(SERVICE)

reset-infra:
	@echo "WARNING: This removes container volumes for FLEX infra."
	@$(COMPOSE) --profile observability --profile sonar down -v --remove-orphans 2>/dev/null || true
	@$(COMPOSE) down -v --remove-orphans 2>/dev/null || true

# Legacy aliases
deps: up-infra-minimal
observability:
	@$(COMPOSE) --profile observability up -d tempo prometheus loki otel-collector grafana
observability-down:
	@$(COMPOSE) --profile observability stop tempo prometheus loki otel-collector grafana
sonar:
	@$(COMPOSE) --profile sonar up -d sonar-db sonarqube
sonar-down:
	@$(COMPOSE) --profile sonar stop sonar-db sonarqube

sonar-reset:
	@echo "▶ Stopping SonarQube and removing Sonar volumes..."
	@$(COMPOSE) --profile sonar down -v --remove-orphans 2>/dev/null || true
	@rm -rf .flex/sonar
	@echo "✔ Sonar reset — run 'make up' to provision admin/Flex-Sonar-Dev1 + scan token"
stack: up-infra-full
stack-down: down-infra
