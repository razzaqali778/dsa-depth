.PHONY: install dev typecheck build module test test-coverage check sonar-scan

install:
	$(NPM) install

dev:
	$(NPM) run dev

typecheck:
	$(NPM) run typecheck

build:
	$(NPM) run build

test:
	$(NPM) run test

test-coverage:
	$(NPM) run test:coverage

check: typecheck test
	$(NPM) run lint

sonar-scan:
	@./scripts/sonar-scan.sh

module:
	@test -n "$(MODULE)" || (echo "Usage: make module MODULE=module-name" && exit 1)
	@./scripts/create-flex-module.sh "$(MODULE)"
