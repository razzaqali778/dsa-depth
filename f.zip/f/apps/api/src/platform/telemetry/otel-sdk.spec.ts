import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const telemetryMocks = vi.hoisted(() => {
  const mockStart = vi.fn();
  const mockShutdown = vi.fn();
  let lastConfig: unknown;

  class NodeSDK {
    constructor(config: unknown) {
      lastConfig = config;
    }

    start = mockStart;
    shutdown = mockShutdown;
  }

  return {
    mockStart,
    mockShutdown,
    NodeSDK,
    getLastConfig: () => lastConfig as {
      resource: { attributes: Record<string, string> };
    },
  };
});

vi.mock("@opentelemetry/sdk-node", () => ({
  NodeSDK: telemetryMocks.NodeSDK,
}));

vi.mock("@opentelemetry/auto-instrumentations-node", () => ({
  getNodeAutoInstrumentations: vi.fn(() => []),
}));

vi.mock("@opentelemetry/exporter-trace-otlp-http", () => ({
  OTLPTraceExporter: vi.fn(),
}));

vi.mock("@opentelemetry/exporter-metrics-otlp-http", () => ({
  OTLPMetricExporter: vi.fn(),
}));

vi.mock("@opentelemetry/sdk-metrics", () => ({
  PeriodicExportingMetricReader: vi.fn(),
}));

import { ATTR_SERVICE_NAME, ATTR_SERVICE_VERSION } from "@opentelemetry/semantic-conventions";
import { OTLPMetricExporter } from "@opentelemetry/exporter-metrics-otlp-http";
import { OTLPTraceExporter } from "@opentelemetry/exporter-trace-otlp-http";
import { initTelemetry, resetTelemetryForTests } from "./otel-sdk";

describe("initTelemetry", () => {
  beforeEach(() => {
    resetTelemetryForTests();
    telemetryMocks.mockStart.mockClear();
    telemetryMocks.mockShutdown.mockClear();
    vi.mocked(OTLPTraceExporter).mockClear();
    vi.mocked(OTLPMetricExporter).mockClear();
    delete process.env.OTEL_SDK_DISABLED;
    delete process.env.OTEL_SERVICE_NAME;
    delete process.env.OTEL_EXPORTER_OTLP_ENDPOINT;
    delete process.env.NODE_ENV;
  });

  afterEach(() => {
    resetTelemetryForTests();
  });

  it("does not start the SDK when OTEL_SDK_DISABLED is true", () => {
    process.env.OTEL_SDK_DISABLED = "true";

    initTelemetry({ serviceName: "flex-api" });

    expect(telemetryMocks.mockStart).not.toHaveBeenCalled();
  });

  it("starts the SDK once with service metadata from options", async () => {
    initTelemetry({ serviceName: "flex-api", version: "2.0.0" });
    await Promise.resolve();

    expect(telemetryMocks.mockStart).toHaveBeenCalledTimes(1);

    const config = telemetryMocks.getLastConfig();
    expect(config.resource.attributes[ATTR_SERVICE_NAME]).toBe("flex-api");
    expect(config.resource.attributes[ATTR_SERVICE_VERSION]).toBe("2.0.0");
    expect(config.resource.attributes["deployment.environment"]).toBe("development");

    initTelemetry({ serviceName: "other-service" });
    await Promise.resolve();
    expect(telemetryMocks.mockStart).toHaveBeenCalledTimes(1);
  });

  it("prefers OTEL_SERVICE_NAME over options.serviceName", () => {
    process.env.OTEL_SERVICE_NAME = "from-env";

    initTelemetry({ serviceName: "flex-api" });

    const config = telemetryMocks.getLastConfig();
    expect(config.resource.attributes[ATTR_SERVICE_NAME]).toBe("from-env");
  });

  // Local OTLP collectors use HTTP in dev — otel-sdk.ts defaults to http://localhost:4318
  it("builds OTLP exporter URLs from OTEL_EXPORTER_OTLP_ENDPOINT", () => {
    const collectorBase = ["http", "collector:4318"].join("://") + "/";
    process.env.OTEL_EXPORTER_OTLP_ENDPOINT = collectorBase;

    initTelemetry({ serviceName: "flex-api" });

    const tracesUrl = [collectorBase.replace(/\/$/, ""), "v1/traces"].join("/");
    const metricsUrl = [collectorBase.replace(/\/$/, ""), "v1/metrics"].join("/");

    expect(OTLPTraceExporter).toHaveBeenCalledWith({ url: tracesUrl });
    expect(OTLPMetricExporter).toHaveBeenCalledWith({ url: metricsUrl });
  });

  it("continues when SDK start throws synchronously", async () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    telemetryMocks.mockStart.mockImplementationOnce(() => {
      throw new Error("collector unreachable");
    });

    initTelemetry({ serviceName: "flex-api" });
    await new Promise((resolve) => setImmediate(resolve));

    expect(warnSpy).toHaveBeenCalledWith(
      "[telemetry] OpenTelemetry SDK failed to start — continuing without export:",
      expect.any(Error),
    );

    warnSpy.mockRestore();
  });

  it("continues when SDK start rejects asynchronously", async () => {
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
    telemetryMocks.mockStart.mockImplementationOnce(() =>
      Promise.reject(new Error("collector unreachable")),
    );

    initTelemetry({ serviceName: "flex-api" });
    await new Promise((resolve) => setImmediate(resolve));

    expect(warnSpy).toHaveBeenCalledWith(
      "[telemetry] OpenTelemetry SDK failed to start — continuing without export:",
      expect.any(Error),
    );

    warnSpy.mockRestore();
  });
});
