import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import type { AuthenticatedUser, AuthMode } from "./auth-context";
import { IS_PUBLIC_ROUTE } from "./public.decorator";

type RequestWithUser = {
  headers: Record<string, string | string[] | undefined>;
  user?: AuthenticatedUser;
};

@Injectable()
export class GatewayAuthGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_ROUTE, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (isPublic) {
      return true;
    }

    const authMode = (process.env.AUTH_MODE ?? "disabled") as AuthMode;
    const request = context.switchToHttp().getRequest<RequestWithUser>();

    if (authMode === "disabled") {
      request.user = {
        id: "local-dev",
        email: "local-dev@flex",
        displayName: "Local Developer",
        roles: ["Admin"],
      };
      return true;
    }

    const userId = this.readHeader(request, "x-flex-user-id");

    if (!userId) {
      throw new UnauthorizedException("Missing gateway identity header: x-flex-user-id");
    }

    request.user = {
      id: userId,
      email: this.readHeader(request, "x-flex-user-email"),
      displayName: this.readHeader(request, "x-flex-user-name"),
      roles: this.readHeader(request, "x-flex-user-roles")?.split(",").map((role) => role.trim()).filter(Boolean) ?? [],
    };

    return true;
  }

  private readHeader(request: RequestWithUser, name: string): string | undefined {
    const value = request.headers[name];

    if (Array.isArray(value)) {
      return value[0];
    }

    return value;
  }
}
