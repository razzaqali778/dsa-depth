import { vi } from "vitest";
import { UnauthorizedException } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import type { ExecutionContext } from "@nestjs/common";
import type { AuthenticatedUser } from "./auth-context";
import { GatewayAuthGuard } from "./gateway-auth.guard";

type MockRequest = {
  headers: Record<string, string | string[] | undefined>;
  user?: AuthenticatedUser;
};

function makeContext(request: MockRequest) {
  return {
    getHandler: () => ({}),
    getClass: () => ({}),
    switchToHttp: () => ({
      getRequest: () => request,
    }),
  } as ExecutionContext;
}

describe("GatewayAuthGuard", () => {
  let guard: GatewayAuthGuard;
  let reflector: Reflector;
  const originalAuthMode = process.env.AUTH_MODE;

  beforeEach(() => {
    reflector = new Reflector();
    guard = new GatewayAuthGuard(reflector);
  });

  afterEach(() => {
    process.env.AUTH_MODE = originalAuthMode;
  });

  it("allows public routes", () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(true);

    expect(guard.canActivate(makeContext({ headers: {} }))).toBe(true);
  });

  it("sets a local developer user when auth is disabled", () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    process.env.AUTH_MODE = "disabled";

    const request: MockRequest = { headers: {} };
    expect(guard.canActivate(makeContext(request))).toBe(true);
    expect(request).toMatchObject({
      user: {
        id: "local-dev",
        email: "local-dev@flex",
        displayName: "Local Developer",
        roles: ["Admin"],
      },
    });
  });

  it("defaults to disabled auth when AUTH_MODE is unset", () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    delete process.env.AUTH_MODE;

    const request: MockRequest = { headers: {} };
    expect(guard.canActivate(makeContext(request))).toBe(true);
    expect(request.user).toBeDefined();
  });

  it("throws when gateway auth is enabled without identity headers", () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    process.env.AUTH_MODE = "gateway";

    expect(() => guard.canActivate(makeContext({ headers: {} }))).toThrow(
      new UnauthorizedException("Missing gateway identity header: x-flex-user-id"),
    );
  });

  it("maps gateway identity headers onto the request user", () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    process.env.AUTH_MODE = "gateway";

    const request: MockRequest = {
      headers: {
        "x-flex-user-id": "user-1",
        "x-flex-user-email": "user@flex",
        "x-flex-user-name": "User One",
        "x-flex-user-roles": "Admin, Viewer",
      },
    };

    expect(guard.canActivate(makeContext(request))).toBe(true);
    expect(request).toMatchObject({
      user: {
        id: "user-1",
        email: "user@flex",
        displayName: "User One",
        roles: ["Admin", "Viewer"],
      },
    });
  });

  it("reads the first value when a header is provided as an array", () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    process.env.AUTH_MODE = "gateway";

    const request: MockRequest = {
      headers: {
        "x-flex-user-id": ["user-2", "ignored"],
      },
    };

    expect(guard.canActivate(makeContext(request))).toBe(true);
    expect(request.user).toMatchObject({ id: "user-2", roles: [] });
  });
});
