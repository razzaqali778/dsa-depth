import { Module } from "@nestjs/common";
import { APP_GUARD } from "@nestjs/core";
import { GatewayAuthGuard } from "./gateway-auth.guard";

@Module({
  providers: [
    {
      provide: APP_GUARD,
      useClass: GatewayAuthGuard,
    },
  ],
})
export class AuthModule {}
