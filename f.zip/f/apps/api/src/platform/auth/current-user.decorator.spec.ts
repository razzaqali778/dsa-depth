import { ROUTE_ARGS_METADATA } from "@nestjs/common/constants";
import type { ExecutionContext } from "@nestjs/common";
import { CurrentUser } from "./current-user.decorator";

function getDecoratorFactory() {
  class TestController {
    handler(@CurrentUser() _user: unknown) {}
  }

  const metadata = Reflect.getMetadata(ROUTE_ARGS_METADATA, TestController, "handler");
  const key = Object.keys(metadata)[0];

  return metadata[key].factory;
}

describe("CurrentUser", () => {
  it("returns the authenticated user from the request", () => {
    const user = { id: "user-1", roles: ["Admin"] };
    const context = {
      switchToHttp: () => ({
        getRequest: () => ({ user }),
      }),
    } as ExecutionContext;

    expect(getDecoratorFactory()(undefined, context)).toBe(user);
  });

  it("returns undefined when no user is attached to the request", () => {
    const context = {
      switchToHttp: () => ({
        getRequest: () => ({}),
      }),
    } as ExecutionContext;

    expect(getDecoratorFactory()(undefined, context)).toBeUndefined();
  });
});
