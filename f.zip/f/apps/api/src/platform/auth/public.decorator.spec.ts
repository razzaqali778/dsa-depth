import { IS_PUBLIC_ROUTE, Public } from "./public.decorator";

describe("Public", () => {
  it("marks routes as public via metadata", () => {
    class TestController {
      @Public()
      handler() {}
    }

    expect(Reflect.getMetadata(IS_PUBLIC_ROUTE, TestController.prototype.handler)).toBe(true);
  });
});
