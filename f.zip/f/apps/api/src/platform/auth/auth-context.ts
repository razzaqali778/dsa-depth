export type AuthMode = "disabled" | "gateway";

export type AuthenticatedUser = {
  id: string;
  email?: string;
  displayName?: string;
  roles: string[];
};
