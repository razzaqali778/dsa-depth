import { vi } from "vitest";
import type { INestApplication } from "@nestjs/common";
import { ValidationPipe } from "@nestjs/common";
import { configureNetworkLayer } from "./configure-network";

describe("configureNetworkLayer", () => {
  const originalCorsOrigin = process.env.CORS_ORIGIN;

  afterEach(() => {
    process.env.CORS_ORIGIN = originalCorsOrigin;
  });

  it("configures the global API prefix, CORS, and validation pipe", () => {
    delete process.env.CORS_ORIGIN;

    const useGlobalPipes = vi.fn();
    const app = {
      setGlobalPrefix: vi.fn(),
      enableCors: vi.fn(),
      useGlobalPipes,
    } as unknown as INestApplication;

    configureNetworkLayer(app);

    expect(app.setGlobalPrefix).toHaveBeenCalledWith("api");
    expect(app.enableCors).toHaveBeenCalledWith({
      credentials: true,
      origin: true,
    });
    expect(useGlobalPipes).toHaveBeenCalledTimes(1);
    expect(useGlobalPipes.mock.calls[0][0]).toBeInstanceOf(ValidationPipe);
  });

  it("parses comma-separated CORS origins from the environment", () => {
    process.env.CORS_ORIGIN = "https://a.flex,https://b.flex";

    const app = {
      setGlobalPrefix: vi.fn(),
      enableCors: vi.fn(),
      useGlobalPipes: vi.fn(),
    } as unknown as INestApplication;

    configureNetworkLayer(app);

    expect(app.enableCors).toHaveBeenCalledWith({
      credentials: true,
      origin: ["https://a.flex", "https://b.flex"],
    });
  });
});
