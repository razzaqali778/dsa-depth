import { bootstrapModules } from "./bootstrap-modules";
import { FLEX_MODULE_CATALOG } from "./flex-module.catalog";
import type { FlexModuleDefinition } from "./flex-module.definition";

class MockModuleA {}
class MockModuleB {}

const makeDefinition = (
  key: string,
  enabled: boolean,
  nestModule: new () => unknown,
): FlexModuleDefinition => ({
  key,
  displayName: `Display ${key}`,
  route: `/${key}`,
  nestModule: nestModule as FlexModuleDefinition["nestModule"],
  enabled,
  databaseBoundary: `${key}_boundary`,
  databaseName: `${key}_db`,
  databaseUrlEnvVar: `${key.toUpperCase()}_DATABASE_URL`,
  responsibilities: [],
  sourceIntegrations: [],
  publishesEvents: [],
  consumesEvents: [],
});

describe("bootstrapModules", () => {
  beforeEach(() => {
    // Clear catalog before each test
    for (const key of Object.keys(FLEX_MODULE_CATALOG)) {
      delete FLEX_MODULE_CATALOG[key];
    }
  });

  afterEach(() => {
    for (const key of Object.keys(FLEX_MODULE_CATALOG)) {
      delete FLEX_MODULE_CATALOG[key];
    }
  });

  it("should return an empty array when the catalog is empty", () => {
    const result = bootstrapModules();
    expect(result).toEqual([]);
  });

  it("should return only enabled modules", () => {
    FLEX_MODULE_CATALOG["module-a"] = makeDefinition("module-a", true, MockModuleA);
    FLEX_MODULE_CATALOG["module-b"] = makeDefinition("module-b", false, MockModuleB);

    const result = bootstrapModules();

    expect(result).toHaveLength(1);
    expect(result[0]).toBe(MockModuleA);
  });

  it("should return all modules when all are enabled", () => {
    FLEX_MODULE_CATALOG["module-a"] = makeDefinition("module-a", true, MockModuleA);
    FLEX_MODULE_CATALOG["module-b"] = makeDefinition("module-b", true, MockModuleB);

    const result = bootstrapModules();

    expect(result).toHaveLength(2);
    expect(result).toContain(MockModuleA);
    expect(result).toContain(MockModuleB);
  });

  it("should return an empty array when all modules are disabled", () => {
    FLEX_MODULE_CATALOG["module-a"] = makeDefinition("module-a", false, MockModuleA);
    FLEX_MODULE_CATALOG["module-b"] = makeDefinition("module-b", false, MockModuleB);

    const result = bootstrapModules();

    expect(result).toEqual([]);
  });
});
