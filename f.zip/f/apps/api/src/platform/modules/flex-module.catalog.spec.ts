import {
  FLEX_MODULE_CATALOG,
  getFlexModuleDefinition,
} from "./flex-module.catalog";
import type { FlexModuleDefinition } from "./flex-module.definition";

describe("FLEX_MODULE_CATALOG", () => {
  it("should be an object", () => {
    expect(typeof FLEX_MODULE_CATALOG).toBe("object");
    expect(FLEX_MODULE_CATALOG).not.toBeNull();
  });
});

describe("getFlexModuleDefinition", () => {
  it("should return undefined for an unknown module key", () => {
    expect(getFlexModuleDefinition("non-existent-module")).toBeUndefined();
  });

  it("should return the definition for a registered module key", () => {
    const mockDefinition: FlexModuleDefinition = {
      key: "test-module",
      displayName: "Test Module",
      route: "/test",
      nestModule: class TestModule {},
      enabled: true,
      databaseBoundary: "test_boundary",
      databaseName: "test_db",
      databaseUrlEnvVar: "TEST_DATABASE_URL",
      responsibilities: ["testing"],
      sourceIntegrations: [],
      publishesEvents: [],
      consumesEvents: [],
    };

    FLEX_MODULE_CATALOG["test-module"] = mockDefinition;

    const result = getFlexModuleDefinition("test-module");
    expect(result).toBe(mockDefinition);

    // cleanup
    delete FLEX_MODULE_CATALOG["test-module"];
  });
});
