import { Controller, Get } from "@nestjs/common";
import { Public } from "../platform/auth/public.decorator";

@Public()
@Controller("health")
export class HealthController {
  @Get()
  getHealth() {
    return {
      status: "ok",
      service: "resource-allocation-api",
    };
  }
}
