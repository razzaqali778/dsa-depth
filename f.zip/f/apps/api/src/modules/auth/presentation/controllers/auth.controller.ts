import { Controller, Get } from "@nestjs/common";
import { AuthService } from "../../application/services/auth.service";

@Controller("auth")
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Get("summary")
  getSummary() {
    return this.authService.getSummary();
  }
}
