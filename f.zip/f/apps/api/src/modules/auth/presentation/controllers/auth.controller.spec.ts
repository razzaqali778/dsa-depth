import { vi } from "vitest";
import { AuthController } from "./auth.controller";
import type { AuthService } from "../../application/services/auth.service";

describe("AuthController", () => {
  it("delegates summary requests to AuthService", async () => {
    const summary = { module: "auth", currentPhase: "boilerplate" };
    const authService = {
      getSummary: vi.fn().mockResolvedValue(summary),
    } as unknown as AuthService;
    const controller = new AuthController(authService);

    await expect(controller.getSummary()).resolves.toBe(summary);
    expect(authService.getSummary).toHaveBeenCalledTimes(1);
  });
});
