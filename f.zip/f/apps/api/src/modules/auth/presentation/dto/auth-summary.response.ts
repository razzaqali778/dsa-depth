import type { SourceIntegrationDefinition } from "../../../../platform/modules/flex-module.definition";

export type AuthSummaryResponseDto = {
  module: string;
  displayName: string;
  route: string;
  responsibilities: string[];
  sourceIntegrations: SourceIntegrationDefinition[];
  databaseBoundary: string;
  databaseName: string;
  databaseUrlEnvVar: string;
  publishesEvents: string[];
  consumesEvents: string[];
  currentPhase: "boilerplate";
};
