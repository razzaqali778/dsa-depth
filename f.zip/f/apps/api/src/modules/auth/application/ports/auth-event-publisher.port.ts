import type { IntegrationEvent } from "../../../../platform/messaging/integration-event";

export interface AuthEventPublisherPort {
  publish<TPayload>(event: IntegrationEvent<TPayload>): Promise<void>;
}
