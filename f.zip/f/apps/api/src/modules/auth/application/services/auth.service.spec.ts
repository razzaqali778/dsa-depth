import { AuthService } from "./auth.service";
import { authDefinition } from "../../auth.definition";

describe("AuthService", () => {
  const service = new AuthService();

  it("returns the auth module summary", async () => {
    await expect(service.getSummary()).resolves.toEqual({
      module: authDefinition.key,
      displayName: authDefinition.displayName,
      route: authDefinition.route,
      responsibilities: authDefinition.responsibilities,
      sourceIntegrations: authDefinition.sourceIntegrations,
      databaseBoundary: authDefinition.databaseBoundary,
      databaseName: authDefinition.databaseName,
      databaseUrlEnvVar: authDefinition.databaseUrlEnvVar,
      publishesEvents: authDefinition.publishesEvents,
      consumesEvents: authDefinition.consumesEvents,
      currentPhase: "boilerplate",
    });
  });
});
