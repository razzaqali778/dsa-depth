import type { CanonicalSnapshot } from "../../../../platform/database/module-database.port";

export interface AuthRepositoryPort<TRecord = unknown> {
  saveSnapshot(snapshot: CanonicalSnapshot<TRecord>): Promise<void>;
}
