import type { SourceAdapterPort } from "../../../../platform/integration/source-adapter.port";

export type AuthSourceAdapterPort<TRecord = unknown> = SourceAdapterPort<TRecord>;
