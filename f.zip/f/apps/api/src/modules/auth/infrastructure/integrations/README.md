# Auth Integrations

External API clients and canonical mappers owned by Auth belong here.
