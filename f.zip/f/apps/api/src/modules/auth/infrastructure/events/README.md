# Auth Events

Outbox, EventBus publisher, and subscriber implementations owned by Auth belong here.
