export const AUTH_SNAPSHOT_STORED_EVENT = "auth.snapshot-stored.v1";

export type AuthSnapshotStoredEventPayload = {
  sourceSystem: string;
  capturedAt: string;
  recordCount: number;
};
