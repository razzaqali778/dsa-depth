import { AUTH_SNAPSHOT_STORED_EVENT } from "./auth-snapshot-stored.event";

describe("auth domain events", () => {
  it("exports the snapshot stored event name", () => {
    expect(AUTH_SNAPSHOT_STORED_EVENT).toBe("auth.snapshot-stored.v1");
  });
});
