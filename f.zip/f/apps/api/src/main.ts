import { initTelemetry } from "./platform/telemetry/otel-sdk";

initTelemetry({ serviceName: "flex-api", version: "0.1.0" });

import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import { configureNetworkLayer } from "./platform/network/configure-network";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  configureNetworkLayer(app);

  await app.listen(
    Number(process.env.API_PORT ?? 3000),
    process.env.FLEX_BIND_HOST ?? "127.0.0.1",
  );
}

void bootstrap();
