type RequestOptions = {
  signal?: AbortSignal;
};

const defaultApiBaseUrl = "/api";

function getApiBaseUrl() {
  return import.meta.env.VITE_FLEX_API_BASE_URL ?? defaultApiBaseUrl;
}

async function request<TResponse>(path: string, options: RequestInit = {}): Promise<TResponse> {
  const baseUrl = getApiBaseUrl().replace(/\/$/, "");
  const url = `${baseUrl}${path.startsWith("/") ? path : `/${path}`}`;
  const headers = new Headers(options.headers);

  if (!headers.has("content-type")) {
    headers.set("content-type", "application/json");
  }

  const response = await fetch(url, {
    ...options,
    headers,
  });

  if (!response.ok) {
    throw new Error(`FLEX API request failed: ${response.status} ${response.statusText}`);
  }

  return response.json() as Promise<TResponse>;
}

export const apiGatewayClient = {
  get<TResponse>(path: string, options: RequestOptions = {}) {
    return request<TResponse>(path, {
      method: "GET",
      signal: options.signal,
    });
  },
};
