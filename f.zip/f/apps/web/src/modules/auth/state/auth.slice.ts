import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { AuthState, AuthStatus } from "../types/auth.types";

const initialState: AuthState = {
  status: "idle",
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    statusChanged: (state, action: PayloadAction<AuthStatus>) => {
      state.status = action.payload;
    },
    selectedIdChanged: (state, action: PayloadAction<string | undefined>) => {
      state.selectedId = action.payload;
    },
    errorChanged: (state, action: PayloadAction<string | undefined>) => {
      state.error = action.payload;
    },
  },
});

export const { statusChanged, selectedIdChanged, errorChanged } = authSlice.actions;
export const authReducer = authSlice.reducer;
