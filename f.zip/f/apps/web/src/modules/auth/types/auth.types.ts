export type AuthSourceIntegration = {
  sourceSystem: string;
  direction: "read-only" | "write-back-future";
  adapterBoundary: string;
  ownedByModule: boolean;
};

export type AuthSummary = {
  module: string;
  displayName: string;
  route: string;
  responsibilities: string[];
  sourceIntegrations: AuthSourceIntegration[];
  databaseBoundary: string;
  databaseName: string;
  databaseUrlEnvVar: string;
  publishesEvents: string[];
  consumesEvents: string[];
  currentPhase: string;
};

export type AuthStatus = "idle" | "loading" | "succeeded" | "failed";

export type AuthState = {
  status: AuthStatus;
  selectedId?: string;
  error?: string;
};
