import { useAppSelector } from "../../../shared/hooks/redux";

export function AuthPage() {
  const status = useAppSelector((state) => state.auth.status);

  return (
    <section className="page-stack">
      <div>
        <span className="eyebrow">Auth</span>
        <h1>Auth</h1>
        <p className="page-copy">Status: {status}</p>
      </div>
    </section>
  );
}
