import { configureStore } from "@reduxjs/toolkit";
import { render, screen } from "@testing-library/react";
import { Provider } from "react-redux";
import { AuthPage } from "./auth-page";
import { authReducer } from "../state/auth.slice";

describe("AuthPage", () => {
  it("renders the module status", () => {
    const store = configureStore({ reducer: { auth: authReducer } });

    render(
      <Provider store={store}>
        <AuthPage />
      </Provider>,
    );

    expect(screen.getByRole("heading", { name: "Auth" })).toBeInTheDocument();
    expect(screen.getByText(/Status: idle/)).toBeInTheDocument();
  });
});
