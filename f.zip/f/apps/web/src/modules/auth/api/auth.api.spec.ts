import { vi } from "vitest";
import { apiGatewayClient } from "../../../shared/api/api-gateway.client";
import { getAuthSummary } from "./auth.api";

vi.mock("../../../shared/api/api-gateway.client", () => ({
  apiGatewayClient: { get: vi.fn() },
}));

describe("auth api", () => {
  it("requests the module summary", () => {
    getAuthSummary();

    expect(apiGatewayClient.get).toHaveBeenCalledWith("/auth/summary", { signal: undefined });
  });
});
