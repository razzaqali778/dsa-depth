import { apiGatewayClient } from "../../../shared/api/api-gateway.client";
import type { AuthSummary } from "../types/auth.types";

export function getAuthSummary(signal?: AbortSignal) {
  return apiGatewayClient.get<AuthSummary>("/auth/summary", { signal });
}
