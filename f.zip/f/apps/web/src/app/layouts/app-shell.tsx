import { NavLink, Outlet } from "react-router-dom";
import { BriefcaseBusiness, type LucideIcon } from "lucide-react";

type NavItem = {
  to: string;
  label: string;
  icon: LucideIcon;
};

const NAV_LINKS: NavItem[] = [
  // Module nav links are added here by the generator (scripts/create-flex-module.sh).
  { to: "/auth", label: "Auth", icon: BriefcaseBusiness },
];

export function AppShell() {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span>BAYER AG</span>
          <strong>FLEX</strong>
        </div>
        <nav className="nav-list">
          {NAV_LINKS.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
              <Icon size={20} />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="signed-in">
          <span>Signed in as</span>
          <strong>Bayer Portfolio Lead</strong>
        </div>
      </aside>
      <main className="main-panel">
        <Outlet />
      </main>
    </div>
  );
}
