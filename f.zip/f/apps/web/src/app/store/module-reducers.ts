// Module reducers are registered here.
// The generator (scripts/create-flex-module.sh) appends additional entries automatically.

import { authReducer } from "../../modules/auth/state/auth.slice";

export const moduleReducers = {
  auth: authReducer,
};
