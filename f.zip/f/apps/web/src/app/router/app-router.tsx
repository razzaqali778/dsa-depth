import { Route, Routes } from "react-router-dom";
import { AppShell } from "../layouts/app-shell";
import { AuthPage } from "../../modules/auth/pages/auth-page";

// Module page imports and routes are registered here.
// The generator (scripts/create-flex-module.sh) appends additional entries automatically.

export function AppRouter() {
  return (
    <Routes>
      <Route element={<AppShell />}>
        <Route path="/" element={<div className="page-stack"><h1>Welcome to FLEX</h1></div>} />
        <Route path="/auth" element={<AuthPage />} />
      </Route>
    </Routes>
  );
}
