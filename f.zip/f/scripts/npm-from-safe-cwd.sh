#!/usr/bin/env bash
# macOS blocks getcwd() inside ~/Desktop for Terminal unless the app has
# Desktop folder access. Run npm from $HOME with --prefix instead.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"
if [[ -s "$NVM_DIR/nvm.sh" ]]; then
  # shellcheck source=/dev/null
  source "$NVM_DIR/nvm.sh"
  if [[ -f "$ROOT/.nvmrc" ]]; then
    NODE_VERSION="$(tr -d '[:space:]' < "$ROOT/.nvmrc")"
    nvm install "$NODE_VERSION" >/dev/null
    nvm use "$NODE_VERSION" >/dev/null
  fi
fi

cd "$HOME"
exec npm --prefix "$ROOT" "$@"
