#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
RUN_DIR="${ROOT}/.flex/run"

stop_pid_file() {
  local name="$1"
  local pid_file="$RUN_DIR/${name}.pid"
  if [[ -f "$pid_file" ]]; then
    local pid
    pid="$(cat "$pid_file")"
    if kill -0 "$pid" 2>/dev/null; then
      echo "▶ Stopping ${name} (pid $pid)..."
      kill "$pid" 2>/dev/null || true
      # Also kill child processes (npm/node)
      pkill -P "$pid" 2>/dev/null || true
    fi
    rm -f "$pid_file"
  fi
}

stop_pid_file "api"
stop_pid_file "web"

echo "✔ Apps stopped"
