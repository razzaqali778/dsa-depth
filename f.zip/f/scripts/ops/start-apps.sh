#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

RUN_DIR="${ROOT}/.flex/run"
mkdir -p "$RUN_DIR"

API_PORT="${API_PORT:-3000}"
WEB_PORT="${WEB_PORT:-5173}"
AUTH_MODE="${AUTH_MODE:-disabled}"
FLEX_BIND_HOST="${FLEX_BIND_HOST:-127.0.0.1}"

stop_if_running() {
  local pid_file="$1"
  if [[ -f "$pid_file" ]]; then
    local pid
    pid="$(cat "$pid_file")"
    if kill -0 "$pid" 2>/dev/null; then
      echo "  Stopping existing process (pid $pid)..."
      kill "$pid" 2>/dev/null || true
      sleep 1
    fi
    rm -f "$pid_file"
  fi
}

stop_if_running "$RUN_DIR/api.pid"
stop_if_running "$RUN_DIR/web.pid"

echo "▶ Starting API on port ${API_PORT}..."
AUTH_MODE="$AUTH_MODE" API_PORT="$API_PORT" FLEX_BIND_HOST="$FLEX_BIND_HOST" \
  nohup ./scripts/npm-from-safe-cwd.sh run dev:api >"$RUN_DIR/api.log" 2>&1 &
echo $! >"$RUN_DIR/api.pid"

echo "▶ Starting Web on port ${WEB_PORT}..."
WEB_PORT="$WEB_PORT" FLEX_BIND_HOST="$FLEX_BIND_HOST" \
  nohup ./scripts/npm-from-safe-cwd.sh run dev:web >"$RUN_DIR/web.log" 2>&1 &
echo $! >"$RUN_DIR/web.pid"

# Brief wait for apps to bind ports
sleep 3

echo "✔ Apps started (logs: .flex/run/api.log, .flex/run/web.log)"
