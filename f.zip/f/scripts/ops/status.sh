#!/usr/bin/env bash
# Beautiful FLEX service status — health, uptime, memory, URLs, and daily motivation.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

# shellcheck disable=SC1091
source "$ROOT/scripts/ops/container-runtime.sh" 2>/dev/null || true

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

API_PORT="${API_PORT:-3000}"
WEB_PORT="${WEB_PORT:-5173}"
GRAFANA_PORT="${GRAFANA_PORT:-3001}"
SONAR_PORT="${SONAR_PORT:-9000}"
RUN_DIR="${ROOT}/.flex/run"
COMPOSE_PROJECT="${COMPOSE_PROJECT:-flex}"

# ── Terminal styling ──────────────────────────────────────────────────────────
if [[ -t 1 ]] || [[ -n "${FORCE_COLOR:-}" ]]; then
  if [[ -z "${NO_COLOR:-}" ]]; then
    BOLD='\033[1m' DIM='\033[2m' RESET='\033[0m'
    GREEN='\033[32m' RED='\033[31m' YELLOW='\033[33m' CYAN='\033[36m' MAGENTA='\033[35m' BLUE='\033[34m'
  else
    BOLD='' DIM='' RESET='' GREEN='' RED='' YELLOW='' CYAN='' MAGENTA='' BLUE=''
  fi
else
  BOLD='' DIM='' RESET='' GREEN='' RED='' YELLOW='' CYAN='' MAGENTA='' BLUE=''
fi

# ── Helpers ───────────────────────────────────────────────────────────────────
check_tcp() {
  nc -z localhost "$1" 2>/dev/null
}

check_http() {
  curl -sf --max-time 2 "$1" >/dev/null 2>&1
}

pick_daily_quote() {
  local quotes_file="$ROOT/scripts/ops/dev-quotes.txt"
  [[ -f "$quotes_file" ]] || return 0
  local -a lines=()
  local line
  while IFS= read -r line || [[ -n "$line" ]]; do
    if [[ "$line" =~ ^[[:space:]]*# ]]; then continue; fi
    if [[ -z "${line// }" ]]; then continue; fi
    lines+=("$line")
  done <"$quotes_file"
  ((${#lines[@]} > 0)) || return 0
  local day idx
  day=$(date +%j | sed 's/^0*//')
  day=${day:-0}
  idx=$((day % ${#lines[@]}))
  echo "${lines[$idx]}"
}

format_rss_mb() {
  local kb="${1:-0}"
  if [[ "$kb" =~ ^[0-9]+$ ]] && ((kb > 0)); then
    awk -v k="$kb" 'BEGIN { printf "%.1f MB", k/1024 }'
  else
    echo "—"
  fi
}

parse_mem_usage() {
  local raw="${1:-}"
  [[ -n "$raw" ]] || { echo "—"; return; }
  echo "$raw" | awk '{print $1}'
}

container_row_for_service() {
  local service="$1"
  grep -E "^${COMPOSE_PROJECT}-${service}-" "$CONTAINER_CACHE" 2>/dev/null | head -1 || true
}

memory_for_container() {
  local cname="$1"
  grep -E "^${cname}\|" "$STATS_CACHE" 2>/dev/null | cut -d'|' -f2 | head -1 || true
}

process_info() {
  local pid_file="$1"
  local pid=""
  [[ -f "$pid_file" ]] && pid=$(cat "$pid_file" 2>/dev/null || true)
  if [[ -z "$pid" ]] || ! kill -0 "$pid" 2>/dev/null; then
    echo "|||"
    return
  fi
  ps -p "$pid" -o etime=,rss=,state= 2>/dev/null | awk '{$1=$1};1' || echo "|||"
}

health_label() {
  case "$1" in
    healthy)  echo -e "${GREEN}OK${RESET}" ;;
    starting) echo -e "${YELLOW}WAIT${RESET}" ;;
    stopped)  echo -e "${RED}STOP${RESET}" ;;
    down)     echo -e "${RED}DOWN${RESET}" ;;
    external) echo -e "${BLUE}EXT${RESET}" ;;
    *)        echo -e "${DIM}—${RESET}" ;;
  esac
}

dot_pad() {
  # name .......... (dots fill to width 18)
  local name="$1" width=18
  local len=${#name}
  local dots=$((width - len))
  ((dots < 1)) && dots=1
  printf '%s %s' "$name" "$(printf '%*s' "$dots" '' | tr ' ' '.')"
}

# ── Runtime detection (non-fatal) ─────────────────────────────────────────────
RUNTIME_OK=0
CONTAINER_RUNTIME="${CONTAINER_RUNTIME:-unknown}"
COMPOSE="${COMPOSE:-}"
if resolve_container_runtime 2>/dev/null; then
  RUNTIME_OK=1
fi

CONTAINER_CACHE=$(mktemp)
STATS_CACHE=$(mktemp)
trap 'rm -f "$CONTAINER_CACHE" "$STATS_CACHE"' EXIT

if [[ "$RUNTIME_OK" -eq 1 ]]; then
  $CONTAINER_RUNTIME ps -a \
    --format '{{.Names}}|{{.State}}|{{.Status}}|{{.RunningFor}}' 2>/dev/null \
    | grep -E "^${COMPOSE_PROJECT}-" >"$CONTAINER_CACHE" || true
  if [[ -s "$CONTAINER_CACHE" ]]; then
    $CONTAINER_RUNTIME stats --no-stream --format '{{.Name}}|{{.MemUsage}}' 2>/dev/null \
      | grep -E "^${COMPOSE_PROJECT}-" >"$STATS_CACHE" || true
  fi
fi

# ── Service probes ────────────────────────────────────────────────────────────
probe_container() {
  local service="$1" url="$2" probe_type="$3" probe_target="$4" down_tip="$5"
  local row cname cstate cstatus cuptime mem health state uptime tip=""

  row=$(container_row_for_service "$service")
  if [[ -n "$row" ]]; then
    IFS='|' read -r cname cstate cstatus cuptime _ <<<"$row"
    mem=$(parse_mem_usage "$(memory_for_container "$cname")")
    state="$cstate"
    uptime="${cuptime:-—}"
  else
    cstate="not started"
    state="not started"
    uptime="—"
    mem="—"
    tip="$down_tip"
  fi

  local reachable=0
  if [[ "$probe_type" == "http" ]]; then
    check_http "$probe_target" && reachable=1
  else
    check_tcp "$probe_target" && reachable=1
  fi

  if [[ "$reachable" -eq 1 ]]; then
    health="healthy"
  elif [[ "$cstate" == "running" ]]; then
    health="starting"
    tip="${tip:-$service is running but not responding yet — try: make logs SERVICE=$service}"
  elif [[ "$cstate" == "not started" ]]; then
    health="down"
  else
    health="stopped"
    tip="${tip:-Container stopped — run: make up-infra}"
  fi

  echo "$health|$state|$uptime|$mem|$url|$tip"
}

probe_process() {
  local name="$1" pid_file="$2" url="$3" probe_type="$4" probe_target="$5" down_tip="$6"
  local info etime rss pstate mem health state uptime tip=""
  local pid="" reachable=0

  info=$(process_info "$pid_file")
  IFS='|' read -r etime rss pstate _ <<<"${info}|||"
  [[ -f "$pid_file" ]] && pid=$(cat "$pid_file" 2>/dev/null || true)

  if [[ "$probe_type" == "http" ]]; then
    check_http "$probe_target" && reachable=1
  else
    check_tcp "$probe_target" && reachable=1
  fi

  if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
    state="running"
    uptime="${etime:-—}"
    mem=$(format_rss_mb "${rss// /}")
  elif [[ "$reachable" -eq 1 ]]; then
    state="external"
    uptime="—"
    mem="—"
    echo "healthy|external|—|—|$url|"
    return
  else
    state="not started"
    uptime="—"
    mem="—"
    tip="$down_tip"
  fi

  if [[ "$reachable" -eq 1 ]]; then
    health="healthy"
  elif [[ "$state" == "running" ]]; then
    health="starting"
    local log_name="${name#flex-}"
    tip="${tip:-$name is starting — check .flex/run/${log_name}.log}"
  else
    health="down"
  fi

  echo "$health|$state|$uptime|$mem|$url|$tip"
}

# ── Collect all services ────────────────────────────────────────────────────────
SVC_NAMES=()
SVC_ROWS=()
SVC_TIPS=()

add_service() {
  local name="$1" row="$2" tip
  SVC_NAMES+=("$name")
  SVC_ROWS+=("$row")
  tip=$(echo "$row" | cut -d'|' -f6-)
  if [[ -n "$tip" ]]; then
    SVC_TIPS+=("$tip")
  fi
}

add_service "postgres" "$(probe_container postgres "localhost:5432" tcp 5432 "Postgres not running — run: make up")"
add_service "grafana" "$(probe_container grafana "http://localhost:${GRAFANA_PORT}/" http "http://localhost:${GRAFANA_PORT}/api/health" "Grafana not running — run: make up")"
add_service "prometheus" "$(probe_container prometheus "http://localhost:9090/" http "http://localhost:9090/-/healthy" "Prometheus not running — run: make up")"
add_service "tempo" "$(probe_container tempo "http://localhost:3200/" tcp 3200 "Tempo not running — run: make up")"
add_service "loki" "$(probe_container loki "http://localhost:3100/" tcp 3100 "Loki not running — run: make up")"
add_service "otel-collector" "$(probe_container otel-collector "localhost:4318" http "http://localhost:13133/" "OTEL collector not running — run: make up")"
add_service "sonarqube" "$(probe_container sonarqube "http://localhost:${SONAR_PORT}/" http "http://localhost:${SONAR_PORT}/api/system/status" "SonarQube not running — run: make up (first start can take ~2 min)")"
add_service "flex-api" "$(probe_process flex-api "$RUN_DIR/api.pid" "http://localhost:${API_PORT}/" http "http://localhost:${API_PORT}/api/health" "API not running — run: make up-apps")"
# Tag external API in tips after probe
for i in "${!SVC_NAMES[@]}"; do
  if [[ "${SVC_NAMES[$i]}" == "flex-api" ]]; then
    if [[ "${SVC_ROWS[$i]}" == *"|external|"* ]]; then
      SVC_TIPS+=("API responding but not managed by make — run: make up-apps to own the process")
    fi
    break
  fi
done
add_service "flex-web" "$(probe_process flex-web "$RUN_DIR/web.pid" "http://localhost:${WEB_PORT}/" http "http://localhost:${WEB_PORT}/" "Web not running — run: make up-apps")"

# ── Counts ────────────────────────────────────────────────────────────────────
healthy=0
total=${#SVC_NAMES[@]}
for row in "${SVC_ROWS[@]}"; do
  if [[ "$(echo "$row" | cut -d'|' -f1)" == "healthy" ]]; then
    healthy=$((healthy + 1))
  fi
done

# ── Header ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${BOLD}${CYAN}  FLEX Service Status${RESET}"
echo -e "${DIM}  $(date '+%A, %B %-d %Y · %H:%M %Z')${RESET}"
if [[ "$RUNTIME_OK" -eq 1 ]]; then
  echo -e "${DIM}  Runtime: ${CONTAINER_RUNTIME} (${COMPOSE})${RESET}"
else
  echo -e "${YELLOW}  Container runtime: not available (port checks only)${RESET}"
fi
echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""

quote=$(pick_daily_quote || true)
if [[ -n "${quote:-}" ]]; then
  echo -e "  ${MAGENTA}💬${RESET} ${DIM}${quote}${RESET}"
  echo ""
fi

if [[ "$healthy" -eq "$total" ]]; then
  echo -e "  ${GREEN}${BOLD}All ${total} services healthy${RESET} ${GREEN}— you're crushing it today.${RESET}"
elif [[ "$healthy" -eq 0 ]]; then
  echo -e "  ${BOLD}0/${total}${RESET} services healthy"
  echo -e "  ${YELLOW}Nothing's up yet — run ${BOLD}make up${RESET}${YELLOW} to start your stack.${RESET}"
else
  echo -e "  ${BOLD}${healthy}/${total}${RESET} services healthy"
fi
echo ""

# ── Table ─────────────────────────────────────────────────────────────────────
echo -e "  ${BOLD}SERVICE            HEALTH  STATE        UPTIME       MEMORY     URL${RESET}"
echo -e "  ${DIM}────────────────────────────────────────────────────────────────────────────${RESET}"

for i in "${!SVC_NAMES[@]}"; do
  name="${SVC_NAMES[$i]}"
  IFS='|' read -r health state uptime mem url _ <<<"${SVC_ROWS[$i]}"
  label=$(health_label "$health")
  padded=$(dot_pad "$name")
  printf "  %-19s %-11b %-12s %-12s %-10s %s\n" \
    "$padded" "$label" "$state" "$uptime" "$mem" "$url"
done

echo ""

# Container memory total (best-effort)
if [[ -s "$STATS_CACHE" ]]; then
  total_mem=$(awk -F'|' '{
    split($2, a, " / "); gsub(/[^0-9.]/, "", a[1]); if (a[1]+0 > 0) s += a[1]
  } END {
    if (s >= 1024) printf "%.1f GB", s/1024; else if (s > 0) printf "%.0f MB", s; else print "—"
  }' "$STATS_CACHE" 2>/dev/null || echo "—")
  running_ct=$(awk -F'|' '$2 == "running" { n++ } END { print n+0 }' "$CONTAINER_CACHE" 2>/dev/null || echo 0)
  echo -e "  ${DIM}Containers: ${running_ct} running · ~${total_mem} combined memory${RESET}"
  echo ""
fi

# ── Quick access ──────────────────────────────────────────────────────────────
# User-facing services for quick access links
QUICK_ACCESS_NAMES="flex-web flex-api grafana prometheus sonarqube"

echo -e "  ${BOLD}Quick access${RESET}"
echo -e "  ${DIM}────────────${RESET}"
reachable_count=0
for i in "${!SVC_NAMES[@]}"; do
  name="${SVC_NAMES[$i]}"
  if [[ " $QUICK_ACCESS_NAMES " != *" $name "* ]]; then continue; fi
  IFS='|' read -r health _ _ _ url _ <<<"${SVC_ROWS[$i]}"
  if [[ "$health" != "healthy" ]]; then continue; fi
  reachable_count=$((reachable_count + 1))
  case "$name" in
    grafana)     label="Grafana (dashboards)" ;;
    flex-api)    label="API" ;;
    flex-web)    label="Web app" ;;
    sonarqube)   label="SonarQube" ;;
    prometheus)  label="Prometheus" ;;
    *)           label="$name" ;;
  esac
  echo -e "  ${GREEN}→${RESET} ${label}: ${CYAN}${url}${RESET}"
  if [[ "$name" == "flex-api" ]]; then
    echo -e "  ${GREEN}→${RESET} Auth module: ${CYAN}http://localhost:${API_PORT}/api/auth/summary${RESET}"
  fi
done

if [[ "$reachable_count" -eq 0 ]]; then
  echo -e "  ${RED}No services reachable on localhost.${RESET}"
fi
echo ""

# ── Tips ──────────────────────────────────────────────────────────────────────
if ((${#SVC_TIPS[@]} > 0)); then
  echo -e "  ${BOLD}Tips${RESET}"
  echo -e "  ${DIM}────${RESET}"
  printf '%s\n' "${SVC_TIPS[@]}" | sort -u | while IFS= read -r tip; do
    echo -e "  ${YELLOW}•${RESET} $tip"
  done
  echo ""
fi

if [[ "$RUNTIME_OK" -eq 0 ]]; then
  echo -e "  ${YELLOW}•${RESET} Start container runtime: ${BOLD}podman machine start${RESET} or Docker Desktop"
  echo ""
fi

echo -e "  ${DIM}make urls · make logs SERVICE=grafana · make up · make down${RESET}"
echo ""
