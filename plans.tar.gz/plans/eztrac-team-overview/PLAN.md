# eztrac-team-overview — Issues & Fix Plan

> Standalone Python 3.11 desktop tool (pandas + seaborn). Pulls a full year of
> allocation data via the QC endpoints using the user's **browser cookies** for
> auth and writes Excel charts. Single file: `eztrac-team-overview.py`.
> Scale: ~70 CWIDs × ~12 months ≈ **840+ HTTP calls**, run sequentially today.

Source: code-level audit [Analyze eztrac-team-overview](e0c84ba0-15e3-404a-9a96-9c1d4e23cba7).

---

## 1. Bugs

| # | Severity | Issue | Line(s) | Fix |
|---|---|---|---|---|
| B1 | Critical | `get_full_name` reads module-global `cookie_jar` instead of a param | 62-66, 351 | Pass `cookie_jar` as argument |
| B2 | Critical | `cookie_jar` undefined after extraction failure → used anyway | 350-361 | On failure log + `sys.exit(1)`; fix logging call |
| B3 | Critical | Bearer token failure not handled → `"Bearer None"` → all 401 | 147-156, 369-372 | Validate token; try/except JSON parse; abort |
| B4 | Critical | `asyncio.gather(return_exceptions=True)` results iterated as data → `TypeError` mid-run | 243-247 | `isinstance(x, Exception)` guard |
| B5 | High | Fake async: blocking `requests.get` in `async` coroutines (no real concurrency) | 174-207, 238-243 | `httpx.AsyncClient`/`aiohttp` or `ThreadPoolExecutor` |
| B6 | High | No HTTP timeouts anywhere | 62,100,140,192 | `timeout=(10,60)` |
| B7 | High | Unchecked JSON parse on allocation responses | 199-207 | try/except + structured log |
| B8 | High | `get_full_name` can return `None` / hit undefined var | 75-89 | Default `full_name=username`; catch KeyError |
| B9 | High | macOS Edge kill command malformed (`"Microsoft\\ Edge"`) | 320 | `["killall","Microsoft Edge"]` |
| B10 | Medium | Wrong timeframe name in skip warning (always last TF) | 236-237,245-257 | Zip results to `timeframes_of_interest.items()` |
| B11 | Medium | Empty `effortTeams` `[]` treated as failure | 206-207,246-257 | Distinguish `None` (fail) vs `[]` (no data) |
| B12 | Medium | Opens `ez-trac-core` URL but API targets `ez-trac-qc` (cookie mismatch) | 334 | Open QC URL |
| B13 | Medium | Chart save path missing extension | 285 | `reports/{user}.png` |
| B14 | Medium | Velocity search takes `results[0]` without CWID match | 56-79 | Match exact CWID |

## 2. Latency / scale

| # | Severity | Issue | Line(s) | Fix |
|---|---|---|---|---|
| L1 | Critical | ~840 sequential HTTP calls (async scaffolding is fake) | 174-207,235-243 | True async + semaphore(10–20) |
| L2 | High | Sequential Velocity profile lookups per user | 223-233 | Parallelize + cache CWID→name |
| L3 | High | No retry/backoff on transient failures | 62,100,140,192 | `urllib3.Retry`/`tenacity` |
| L4 | High | Bearer token not refreshed during long runs | 369-372 | Refresh on 401 / periodically |
| L5 | Medium | O(n²) DataFrame growth via repeated `pd.concat` in loop | 213-221,272 | Collect list → single concat |
| L6 | Medium | No connection pooling / session reuse | all HTTP | `requests.Session()` |

## 3. Robustness / UX

| # | Severity | Issue | Line(s) | Fix |
|---|---|---|---|---|
| R1 | High | Kills Microsoft **Excel** on Windows without warning (data loss) | 327 | Remove |
| R2 | High | Force-kills all Edge instances | 309-329 | Read cookies without kill / prompt |
| R3 | Medium | No progress feedback during long per-month fetches | 223-243 | Nested progress / ETA |
| R4 | Medium | Hardcoded relative paths (CWD-dependent) | 285,344-346,375,388 | Resolve relative to script dir |
| R5 | Medium | No config file / CLI flags (everything hardcoded) | `__main__` | argparse: users-file, year, browser, workers, skip-plots |
| R6 | Medium | Blocking `input()` prompts break automation | 316,399 | `--non-interactive` |
| R7 | Medium | README says Chrome; code uses Edge | README:23 vs 351 | Align |

## Phased priority
- **P0** (crashes/data loss): B1–B4, B9, R1, R2.
- **P1** (correctness): B6, B7, B10, B12, B8, L3, L4.
- **P2** (performance): B5, L1, L2, L5, L6.
- **P3** (UX): R3–R7, B13, B14.

**Estimated impact:** P0+P2 can cut a typical 70-user run from ~15–30 min to
~2–5 min with bounded parallelism, while eliminating silent auth failures.
