# eztrac-core-services — Issues & Fix Plan

> TypeScript/Express REST API (port **3560**), pg-promise + Postgres. The
> **system of record**: teams, monthly efforts, computed spend. Calls
> costing-services + VIP over HTTP. Tables grow to **millions of rows**
> (`team_cost_breakdown`, `team_cost_allocation`, `team_cost_member`).

Source: code-level audit [Analyze eztrac-core-services](ba9b34a9-19c7-4d9e-ad56-5381d93b5884).

---

## 1. Bugs (correctness / concurrency / error handling)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| B1 | Critical | `deleteEffortEngagements` skips closed-timeframe authorization (other write paths enforce it) | `src/api/effort/engagement/effortEngagementService.ts:164-182` | Resolve future TF ids, call `validateUserIsAuthorizedToModifyChosenTimeFrames`, pass `isAdmin` from route |
| B2 | High | `getCurrentTimeFrameWithOffset` hardcodes `setDate(2)` → wrong month near boundaries | `src/api/timeframe/timeFrameRepository.ts:36-44` | Normalize to first-of-month UTC for `(month+offset)` |
| B3 | High | `timeframesOlderThanQuery` self-join always true (`start >= start`) | `src/api/effort/engagement/effortEngagementsRepository.ts:33-37` | Compare against `startTimeFrame.timeframe_start_date`; add test |
| B4 | High | Workdays query dereferences possibly-null row + unguarded `JSON.parse` | `src/api/timeframe/timeFrameRepository.ts:89-101` | Null-check → `[]`/`NotFoundError`; try/catch parse |
| B5 | High | Spend crashes when allocations exist but no breakdowns (`groupedBreakdowns[effortId]` undefined) | `src/api/spend/spendService.ts:72-74` | Default `?? []` |
| B6 | Medium | `getOrCreatePeople` condition `>= 0` always true → wasted PAPI call | `src/api/person/personService.ts:11` | `> 0` |
| B7 | Medium | `createPerson` no idempotency → PK races on concurrent member writes | `src/api/person/personRepository.ts:25-33` | `INSERT ... ON CONFLICT (user_id) DO NOTHING` |
| B8 | Medium | `isAdmin` unguarded `JSON.parse` of profile header crashes writes | `src/util/security/isAdmin.ts:3-5` | try/catch → treat as non-admin |
| B9 | Medium | `updateEffort` delete-then-insert, last-write-wins on concurrent PATCH | `src/api/effort/effortRepository.ts:187-238` | `SELECT ... FOR UPDATE` / version column / per-key queue |
| B10 | Medium | BigInt→Number precision loss on costs > 2^53 | `src/api/spend/spendService.ts:38,56-59` | Keep `bigint` until serialize |
| B11 | Low | Error middleware calls `next(err)` after response sent | `server.ts:126-140` | Remove trailing `next(err)` |

Good news: **no SQL injection** found — all queries are parameterized.

## 2. Latency / scale (millions of rows)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| L1 | Critical | Health check N+1: full-effort load per team | `src/api/healthcheck/healthCheckEffortsService.ts:25-31` | Batch-load all efforts for `(timeFrameId, teamIds[])` |
| L2 | Critical | `costAllTeams`: sequential per-timeframe full reload + recost | `src/api/costcalc/standardTeamCosting.ts:54-86` | Bounded-concurrency parallelism (p-limit) |
| L3 | Critical | `getEffortEngagementsByTeam` unbounded historical scan when TF params omitted | `.../effortEngagementsRepository.ts:89-94` (route `effortEngagementRouteGet.ts:66`) | Require TF range / default recent N months + pagination |
| L4 | High | O(n²) in-memory joins hydrating full efforts | `src/api/effort/effortService.ts:66-125` | Pre-group children into `Map<effortId,T[]>` |
| L5 | High | Many unbounded read endpoints (allocations, efforts, members, spend, GET export) | see audit §2.7 | Keyset pagination + mandatory TF/team filters |
| L6 | High | Missing indexes on hot join/filter cols | `migrations/0000000000000-init.sql:654-668` | Add `team_cost(team_id)`, `team_cost_allocation(team_cost_id)`, `team_cost_member(team_cost_id)`, `timeframe(start,end)` |
| L7 | High | No HTTP timeouts on outbound calls (costing/VIP/PAPI) | `src/util/superagentWrapper.ts:5-8` | `.timeout({response:30000,deadline:60000})` |
| L8 | High | GET export re-fetches full VIP hierarchy + person catalog every request | `src/api/GETExport/fullGetEntriesGenerator.ts:63-80` | TTL cache (5–15m) + chunked PAPI |
| L9 | Medium | Pool `max:200` + 10-min idle, no `statement_timeout` | `src/db/dbManager.ts:5-18` | Right-size pool + statement/query timeouts |
| L10 | Medium | GET export runs 3 independent queries sequentially | `.../fullGetEntriesGenerator.ts:42-50` | `Promise.all` |
| L11 | Medium | `bodyParser` limit 50 MB | `server.ts:91` | Lower to 1–5 MB |

## 3. Data-freshness / recost correctness

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| F1 | Critical | Partial recost leaves **stale breakdowns** for efforts that should go to zero (delete only scoped to ids present in new batch) | `src/api/costcalc/standardTeamCosting.ts:30-59`, `effortRepository.ts:241-263` | Delete breakdowns for **all** effort ids in scope, then insert; unify with the member/engagement recost path |
| F2 | High | Costing omission → mixed fresh/stale within a timeframe (`.find()` miss silently keeps old rows) | `standardTeamCosting.ts:36-48` | Treat missing costing result as error or explicit zero-out |
| F3 | Medium | Allocation PATCH skips recost by design; spend multiplies stored breakdowns by new % | `effortAllocationService.ts:70`, `effortService.ts:204-214` | Document invariant; add `breakdown_updated_at`; optional async recost |
| F4 | Medium | Per-row triggers recompute `team_cost.cost` during bulk replace → O(n) trigger fires + mid-tx inconsistency | `init.sql:65-100`, `effortRepository.ts:253-260` | Single end-of-tx `UPDATE ... SET cost = SUM(...)` |

## Slowest paths to profile first (`EXPLAIN ANALYZE`)
1. `GET /spend/startTimeFrame/../endTimeFrame/..`
2. `PUT /cost/standard-teams`
3. `GET /getExport/timeFrameId/:id/all`
4. `GET /healthCheck/efforts/timeFrameId/:id`
5. `GET /efforts/engagements/team/:teamId` (no range)

## Phased priority
- **P0**: F1 (stale breakdowns), B1 (delete auth), L1 (health-check N+1), L6 (indexes).
- **P1**: L7 (timeouts), B2 (date logic), L3/L5 (pagination), L8 (export cache), L2 (parallel recost).
- **P2**: L4 (Map grouping), L9 (pool), B10 (BigInt), B4/B5 (null safety).
