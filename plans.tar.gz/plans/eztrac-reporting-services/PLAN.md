# eztrac-reporting-services — Issues & Fix Plan

> Express (CommonJS) API on port **9092**. The "join layer": for a timeframe
> range it fetches 7 things in parallel from VIP + Core + Costing and stitches
> them into initiative spending trees. This is one of the slowest user-facing
> paths in the whole app.

This folder already contains a **detailed, phased plan**. This file is the
index; the depth is in:

| Doc | What it covers |
|---|---|
| [`OVERVIEW.md`](./OVERVIEW.md) | Original latency + bug overview and phase table. |
| [`phase-1-quick-wins/PLAN.md`](./phase-1-quick-wins/PLAN.md) + [`BUGS.md`](./phase-1-quick-wins/BUGS.md) | Critical bug fixes + fast latency wins. |
| [`phase-2-caching-layer/PLAN.md`](./phase-2-caching-layer/PLAN.md) | Server-side caching. |
| [`phase-3-performance-optimization/PLAN.md`](./phase-3-performance-optimization/PLAN.md) | Algorithm optimization (kill O(n²)). |
| [`phase-4-monitoring-observability/PLAN.md`](./phase-4-monitoring-observability/PLAN.md) | Monitoring. |
| [`SPENDING_ZERO_LATENCY_FRESH_DATA_PLAN.md`](./SPENDING_ZERO_LATENCY_FRESH_DATA_PLAN.md) | The "near‑zero latency **and** always‑fresh" architecture (precomputed `team_cost_spend` ledger in Core + version/event‑based cache). **Read this for the millions‑of‑rows story.** |

## Top issues (summary)

### Bugs
- **CRITICAL — operator-precedence bug** in `src/api/getSpendingForRange.js` (`recursive()`): `sum + child.totalExpenditure || 0` parses as `(sum + x) || 0`, so a single `undefined` child wipes the accumulator → **under-reported dollars**. Fix: `sum + (child.totalExpenditure || 0)`.
- No error handling / `Promise.all` all-or-nothing on the 7 upstream calls — one blip 500s the whole report.
- `console.log` timing in `src/api/external/vipServices/getAllInitiatives.js` (use the structured logger).

### Latency (this is where "can't get the data / too slow" lives)
- OAuth token fetched **7× per request** (no token cache).
- **No server-side caching** of near-static reference data.
- **No request timeouts** on upstream calls → hangs when Core/VIP/Costing are slow.
- **No pagination** — fetches ALL rows every request (the millions-of-rows killer).
- **O(n²) join** in `src/api/models/EffortSpendingMap.js` (`.find()` in nested loops) → replace with a `Map` for O(1).
- No response compression / streaming for large payloads.

## Recommended sequence
1. **Phase 1** (1–2 days): fix the precedence bug, token cache, timeouts+retry, `Promise.allSettled`, logger.
2. **Phase 2/3**: caching layer + O(1) join + kill remaining quadratic transforms.
3. **Spending ledger** ([`SPENDING_...md`](./SPENDING_ZERO_LATENCY_FRESH_DATA_PLAN.md)): move to Core's precomputed `team_cost_spend` + **version-based** (not clock-based) cache so reports are *both* fast and never stale. This is the strategic fix for millions of rows.

## Data-freshness caveat
The current WIP 5-minute caches + browser `Cache-Control: max-age=300` make
reports **stale up to ~5–10 min** after an effort edit. Switch dynamic spend to
event/version-based invalidation (see the spending plan §4–5).
