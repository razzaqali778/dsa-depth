/**
 * Cache Invalidation Routes
 * 
 * Admin endpoints to manage the cache.
 * Add this to: eztrac-reporting-services/src/api/routes.js
 * 
 * Endpoints:
 *   GET  /v2/admin/cache/stats          - View cache statistics
 *   POST /v2/admin/cache/invalidate     - Clear all cache
 *   POST /v2/admin/cache/invalidate/:key - Clear specific cache key
 */

const express = require('express')
const router = express.Router()
const cache = require('../../util/cacheService')
const logger = require('../../logger')

/**
 * GET /v2/admin/cache/stats
 * Returns cache hit/miss statistics and current state
 */
router.get('/cache/stats', (req, res) => {
    const stats = cache.getStats()
    res.json({
        success: true,
        data: stats
    })
})

/**
 * POST /v2/admin/cache/invalidate
 * Clears the entire cache
 */
router.post('/cache/invalidate', (req, res) => {
    logger.info(`Cache flush requested by user: ${req.userId}`)
    cache.flush()
    res.json({
        success: true,
        message: 'All cache entries cleared'
    })
})

/**
 * POST /v2/admin/cache/invalidate/:key
 * Clears a specific cache key or pattern
 * 
 * Examples:
 *   POST /v2/admin/cache/invalidate/teams:all
 *   POST /v2/admin/cache/invalidate/spendings:1:12
 *   POST /v2/admin/cache/invalidate/pattern/spendings  (clears all spending keys)
 */
router.post('/cache/invalidate/:key', (req, res) => {
    const {key} = req.params
    logger.info(`Cache invalidation requested for key: ${key} by user: ${req.userId}`)
    
    const deleted = cache.invalidate(key)
    res.json({
        success: true,
        message: `Cache key '${key}' invalidated`,
        keysRemoved: deleted
    })
})

/**
 * POST /v2/admin/cache/invalidate/pattern/:pattern
 * Clears all cache keys matching a pattern
 */
router.post('/cache/invalidate/pattern/:pattern', (req, res) => {
    const {pattern} = req.params
    logger.info(`Cache pattern invalidation requested: ${pattern} by user: ${req.userId}`)
    
    const deleted = cache.invalidatePattern(pattern)
    res.json({
        success: true,
        message: `Cache pattern '${pattern}' invalidated`,
        keysRemoved: deleted
    })
})

module.exports = router
