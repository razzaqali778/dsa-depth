/**
 * In-Memory Cache Module with TTL
 * 
 * A lightweight, production-ready cache for eztrac-reporting-services.
 * Uses node-cache under the hood with added metrics and memory protection.
 * 
 * Install: npm install node-cache
 */

const NodeCache = require('node-cache')
const logger = require('../../logger')

// Cache configuration
const CACHE_CONFIG = {
    stdTTL: 300,           // Default TTL: 5 minutes (in seconds)
    checkperiod: 60,       // Check for expired keys every 60 seconds
    maxKeys: 1000,         // Maximum number of keys (memory protection)
    useClones: false,      // Don't clone on get (faster, but be careful with mutations)
    deleteOnExpire: true
}

// TTL presets for different data types (in seconds)
const TTL_PRESETS = {
    STATIC: 1800,      // 30 minutes - teams, people
    SEMI_STATIC: 900,  // 15 minutes - initiatives, engagements
    DYNAMIC: 300,      // 5 minutes - spendings, effort engagements
    SHORT: 60          // 1 minute - for rapidly changing data
}

class CacheService {
    constructor(config = CACHE_CONFIG) {
        this.cache = new NodeCache(config)
        this.stats = {
            hits: 0,
            misses: 0,
            sets: 0,
            deletes: 0,
            errors: 0
        }

        // Log cache events
        this.cache.on('expired', (key) => {
            logger.debug(`Cache key expired: ${key}`)
        })

        this.cache.on('del', (key) => {
            logger.debug(`Cache key deleted: ${key}`)
        })

        logger.info('CacheService initialized', {config})
    }

    /**
     * Get a value from cache
     * @param {string} key - Cache key
     * @returns {*|undefined} - Cached value or undefined if miss
     */
    get(key) {
        try {
            const value = this.cache.get(key)
            if (value !== undefined) {
                this.stats.hits++
                logger.debug(`Cache HIT: ${key}`)
                return value
            }
            this.stats.misses++
            logger.debug(`Cache MISS: ${key}`)
            return undefined
        } catch (error) {
            this.stats.errors++
            logger.error(`Cache GET error for key ${key}:`, error.message)
            return undefined
        }
    }

    /**
     * Set a value in cache with optional TTL
     * @param {string} key - Cache key
     * @param {*} value - Value to cache
     * @param {number} [ttl] - TTL in seconds (uses default if not specified)
     * @returns {boolean} - Success
     */
    set(key, value, ttl) {
        try {
            const success = ttl
                ? this.cache.set(key, value, ttl)
                : this.cache.set(key, value)
            
            if (success) {
                this.stats.sets++
                logger.debug(`Cache SET: ${key} (TTL: ${ttl || CACHE_CONFIG.stdTTL}s)`)
            }
            return success
        } catch (error) {
            this.stats.errors++
            logger.error(`Cache SET error for key ${key}:`, error.message)
            return false
        }
    }

    /**
     * Get or fetch pattern - returns cached value or fetches and caches
     * @param {string} key - Cache key
     * @param {Function} fetchFn - Async function to fetch data on cache miss
     * @param {number} [ttl] - TTL in seconds
     * @returns {Promise<*>} - Cached or freshly fetched value
     */
    async getOrFetch(key, fetchFn, ttl) {
        // Check cache first
        const cached = this.get(key)
        if (cached !== undefined) {
            return cached
        }

        // Cache miss - fetch fresh data
        const startTime = Date.now()
        const freshData = await fetchFn()
        const elapsed = Date.now() - startTime

        // Store in cache
        this.set(key, freshData, ttl)

        logger.info(`Cache populated: ${key} (fetched in ${elapsed}ms)`)
        return freshData
    }

    /**
     * Delete a specific key
     * @param {string} key - Cache key to delete
     */
    invalidate(key) {
        const deleted = this.cache.del(key)
        this.stats.deletes += deleted
        logger.info(`Cache invalidated: ${key} (${deleted} keys removed)`)
        return deleted
    }

    /**
     * Delete all keys matching a pattern
     * @param {string} pattern - Pattern to match (simple string contains)
     */
    invalidatePattern(pattern) {
        const keys = this.cache.keys().filter(key => key.includes(pattern))
        keys.forEach(key => this.cache.del(key))
        this.stats.deletes += keys.length
        logger.info(`Cache pattern invalidated: ${pattern} (${keys.length} keys removed)`)
        return keys.length
    }

    /**
     * Clear entire cache
     */
    flush() {
        this.cache.flushAll()
        logger.info('Cache flushed (all keys removed)')
    }

    /**
     * Get cache statistics
     */
    getStats() {
        const nodeStats = this.cache.getStats()
        return {
            ...this.stats,
            hitRate: this.stats.hits + this.stats.misses > 0
                ? ((this.stats.hits / (this.stats.hits + this.stats.misses)) * 100).toFixed(2) + '%'
                : '0%',
            keys: this.cache.keys().length,
            memoryUsage: nodeStats,
            ttlPresets: TTL_PRESETS
        }
    }
}

// Singleton instance
const cacheService = new CacheService()

module.exports = cacheService
module.exports.CacheService = CacheService
module.exports.TTL_PRESETS = TTL_PRESETS
