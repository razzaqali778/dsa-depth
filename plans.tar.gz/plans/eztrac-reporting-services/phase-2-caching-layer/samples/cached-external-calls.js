/**
 * Cached External Service Calls
 * 
 * Shows how to wrap existing external service calls with the cache layer.
 * Each call uses appropriate TTL based on data volatility.
 * 
 * File to modify: eztrac-reporting-services/src/api/getSpendingForRange.js
 */

const cache = require('../../util/cacheService') // The cache-middleware.js module
const {TTL_PRESETS} = require('../../util/cacheService')
const logger = require('../../logger')

// Import original external call functions
const getAllInitiatives = require('./external/vipServices/getAllInitiatives')
const getAllSpendings = require('./external/coreServices/getAllSpendings')
const getAllTeams = require('./external/coreServices/getAllTeams')
const getCostGroups = require('./external/costingServices/getCostGroups')
const getAllEngagements = require('./external/costingServices/getAllEngagements')
const getAllEffortEngagements = require('./external/coreServices/getAllEffortEngagements')
const getAllPeople = require('./external/costingServices/getAllPeople')

/**
 * Cached version of getAllTeams
 * Teams rarely change - cache for 30 minutes
 */
const getCachedTeams = () => {
    return cache.getOrFetch(
        'teams:all',
        () => getAllTeams(),
        TTL_PRESETS.STATIC // 30 minutes
    )
}

/**
 * Cached version of getAllPeople
 * People data rarely changes - cache for 30 minutes
 */
const getCachedPeople = () => {
    return cache.getOrFetch(
        'people:all',
        () => getAllPeople(),
        TTL_PRESETS.STATIC // 30 minutes
    )
}

/**
 * Cached version of getCostGroups
 * Cost groups are admin-configured - cache for 60 minutes
 */
const getCachedCostGroups = () => {
    return cache.getOrFetch(
        'costGroups:all',
        () => getCostGroups(),
        TTL_PRESETS.STATIC // 30 minutes (could be longer)
    )
}

/**
 * Cached version of getAllInitiatives
 * Initiative tree changes occasionally - cache for 15 minutes
 */
const getCachedInitiatives = () => {
    return cache.getOrFetch(
        'initiatives:tree',
        () => getAllInitiatives(),
        TTL_PRESETS.SEMI_STATIC // 15 minutes
    )
}

/**
 * Cached version of getAllEngagements
 * Engagements change with planning - cache for 15 minutes
 */
const getCachedEngagements = () => {
    return cache.getOrFetch(
        'engagements:all',
        () => getAllEngagements(),
        TTL_PRESETS.SEMI_STATIC // 15 minutes
    )
}

/**
 * Cached version of getAllSpendings
 * Spendings change frequently - cache for 5 minutes
 * Key includes timeframe to differentiate requests
 */
const getCachedSpendings = (startTimeFrame, endTimeFrame) => {
    return cache.getOrFetch(
        `spendings:${startTimeFrame}:${endTimeFrame}`,
        () => getAllSpendings(startTimeFrame, endTimeFrame),
        TTL_PRESETS.DYNAMIC // 5 minutes
    )
}

/**
 * Cached version of getAllEffortEngagements
 * Effort data changes frequently - cache for 5 minutes
 * Key includes timeframe to differentiate requests
 */
const getCachedEffortEngagements = (startTimeFrame, endTimeFrame) => {
    return cache.getOrFetch(
        `effortEngagements:${startTimeFrame}:${endTimeFrame}`,
        () => getAllEffortEngagements(startTimeFrame, endTimeFrame),
        TTL_PRESETS.DYNAMIC // 5 minutes
    )
}

/**
 * Refactored getSpendingForRange using cached calls
 * 
 * This replaces the original Promise.all with cached versions.
 * Static data will be served from cache on subsequent requests.
 */
const getSpendingForRange = async (startTimeframe, endTimeframe) => {
    const startTime = Date.now()

    logger.info(`Fetching spending data for range: ${startTimeframe} - ${endTimeframe}`)

    const [
        initiatives,
        spending,
        teams,
        costGroups,
        engagements,
        effortEngagements,
        people
    ] = await Promise.all([
        getCachedInitiatives(),                              // 15 min cache
        getCachedSpendings(startTimeframe, endTimeframe),    // 5 min cache
        getCachedTeams(),                                    // 30 min cache
        getCachedCostGroups(),                               // 30 min cache
        getCachedEngagements(),                              // 15 min cache
        getCachedEffortEngagements(startTimeframe, endTimeframe), // 5 min cache
        getCachedPeople()                                    // 30 min cache
    ])

    const elapsed = Date.now() - startTime
    const cacheStats = cache.getStats()

    logger.info(`Data fetched in ${elapsed}ms`, {
        elapsed,
        cacheHitRate: cacheStats.hitRate,
        cacheHits: cacheStats.hits,
        cacheMisses: cacheStats.misses
    })

    return {initiatives, spending, teams, costGroups, engagements, effortEngagements, people}
}

module.exports = {
    getSpendingForRange,
    getCachedTeams,
    getCachedPeople,
    getCachedCostGroups,
    getCachedInitiatives,
    getCachedEngagements,
    getCachedSpendings,
    getCachedEffortEngagements
}
