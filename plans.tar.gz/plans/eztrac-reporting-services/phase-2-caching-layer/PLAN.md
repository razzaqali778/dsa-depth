# Phase 2: Server-Side Caching Layer

## Objective

Implement an in-memory caching layer in `eztrac-reporting-services` to avoid redundant calls to external services for data that rarely changes.

## Timeline: 3-5 Days

---

## Analysis: What Data Can Be Cached?

| Data Source | Changes Frequency | Cache TTL | Rationale |
|-------------|-------------------|-----------|-----------|
| Teams | Rarely (weekly) | 30 minutes | Team structure changes infrequently |
| People | Rarely (weekly) | 30 minutes | People data is relatively static |
| Cost Groups | Rarely (monthly) | 60 minutes | Cost groups are admin-configured |
| Initiatives Tree | Occasionally (daily) | 15 minutes | New initiatives added periodically |
| Engagements | Occasionally (daily) | 15 minutes | Engagements change with planning |
| Spendings | Frequently (hourly) | 5 minutes | Active spending entries |
| Effort Engagements | Frequently (hourly) | 5 minutes | Active effort tracking |

---

## Tasks

### 2.1 Implement Cache Utility Module

Create a reusable cache module with:
- TTL-based expiration
- Key-based storage
- Cache hit/miss metrics
- Manual invalidation API
- Memory limit protection

**See:** `samples/cache-middleware.js`

---

### 2.2 Wrap External Calls with Cache

Modify each external service call to check cache first:

```
Request → Check Cache → [HIT] → Return cached data
                      → [MISS] → Fetch from service → Store in cache → Return
```

**See:** `samples/cached-external-calls.js`

---

### 2.3 Add Cache Invalidation Endpoint

Create an admin endpoint to manually invalidate cache:
- `POST /v2/admin/cache/invalidate` - Clear all cache
- `POST /v2/admin/cache/invalidate/:key` - Clear specific cache key
- `GET /v2/admin/cache/stats` - View cache hit/miss stats

**See:** `samples/cache-invalidation.js`

---

### 2.4 Add Cache Headers to Responses

Add HTTP cache headers so the UI can also cache responses:
- `Cache-Control: max-age=300` (5 minutes for spending data)
- `ETag` header for conditional requests
- `Last-Modified` header

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                  eztrac-reporting-services                    │
│                                                              │
│  ┌──────────┐    ┌──────────────┐    ┌──────────────────┐  │
│  │  Routes   │───▶│  Cache Layer │───▶│  External Calls  │  │
│  │  /v2/*    │    │  (node-cache)│    │  (superagent)    │  │
│  └──────────┘    └──────┬───────┘    └──────────────────┘  │
│                         │                                    │
│                  ┌──────▼───────┐                           │
│                  │  In-Memory   │                           │
│                  │  Store       │                           │
│                  │  - TTL       │                           │
│                  │  - Max Size  │                           │
│                  │  - Stats     │                           │
│                  └──────────────┘                           │
└─────────────────────────────────────────────────────────────┘
```

---

## Acceptance Criteria

- [ ] Static data (teams, people, cost groups) cached with 30-60 min TTL
- [ ] Dynamic data (spendings, efforts) cached with 5 min TTL
- [ ] Cache hit/miss metrics logged
- [ ] Admin endpoint to invalidate cache
- [ ] Memory usage bounded (max 100MB cache)
- [ ] Cache key includes timeframe parameters for time-sensitive data
- [ ] Unit tests for cache module

## Estimated Impact

- **First request**: Same latency as before (cache miss)
- **Subsequent requests**: 50-70% faster (cache hits for static data)
- **Typical scenario**: 3 out of 7 calls cached (teams, people, cost groups) = ~40% reduction
