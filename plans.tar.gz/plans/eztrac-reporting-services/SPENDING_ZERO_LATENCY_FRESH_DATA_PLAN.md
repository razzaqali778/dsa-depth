# Spending Reports — Zero‑Latency + Always‑Fresh Plan

> Status: **Proposal for review** (nothing here is implemented yet — the current
> uncommitted changes in `eztrac-core-services` and `eztrac-reporting-services`
> are the *starting point*, described in section 1).
>
> Goal of this doc: explain what we changed and why, compare it with the old
> approach and the alternatives, and propose a concrete plan that gives us
> **near‑zero read latency** *and* **no stale data**, while **never losing
> existing data in any environment** (local, NP, prod).

---

## 0. TL;DR

- **Old approach:** every report click made Core recompute spend from raw
  efforts, plus reporting re‑fetched everything and did a slow O(n²) join.
  Always fresh, always slow.
- **What we just built (starting point):**
  1. **Core** — a precomputed aggregate table `team_cost_spend`, kept current by
     *write‑through* on effort save, plus *backfill* endpoints and a *startup
     backfill* guard. New read endpoint `/reporting/spend`.
  2. **Reporting** — an in‑memory cache (`cacheService.js`) with TTLs, token
     caching, boot warmup, an O(1) join, and a browser `Cache-Control` header.
- **The conflict:** the reporting **time‑based caches (5 min) on spend + the
  full tree + the browser `Cache-Control`** directly break the "must be fresh"
  rule. They can show numbers that are up to 5–10 minutes stale after finance
  edits an effort.
- **Recommended direction:** keep the Core `team_cost_spend` ledger as the
  source of truth, wire reporting to read it (`/reporting/spend`), and switch
  reporting from **time‑based caching** to **event‑based (version/invalidation)
  caching**. That is the only way to get *both* near‑zero latency *and* freshness.

---

## 1. What we changed (the current uncommitted work)

### 1A. Core (`eztrac-core-services`) — precomputed ledger

| File | Change |
|------|--------|
| `migrations/20260717050000000_team-cost-spend.sql` | New table `team_cost_spend` + 3 indexes (timeframe, timeframe+team, timeframe+initiative). |
| `dbSchemaDump.sql` | Documents the new table. |
| `src/api/spend/models.ts` | Shared types: `SpendLineItem`, `InitiativeSpending`, `EffortSpending`, `TeamTimeFrameKey`. |
| `src/api/spend/teamCostSpendRepository.ts` | DB access: `replaceEffortSpendingsForKeys` (delete+insert per team/timeframe, in a tx), `getRowsByTimeRange`, and row↔API‑shape mappers. |
| `src/api/spend/spendService.ts` | Live compute helpers + `refreshTeamCostSpendForKeys` (write‑through), `getReportingSpendInTimeRange` (read table, fallback to live), `backfillTeamCostSpendInTimeRange`, `backfillAllTeamCostSpend`, `ensureTeamCostSpendBackfilled` (startup guard w/ advisory lock). |
| `src/api/spend/routes.ts` | New endpoints: `GET /reporting/spend/...`, `POST /reporting/spend/backfill`, `POST /reporting/spend/backfill/startTimeFrame/.../endTimeFrame/...`. |
| `src/api/effort/effortService.ts` | After `updateEfforts`, calls `refreshTeamCostSpendForKeys` (write‑through). |
| `server.ts` | Registers the repo; fires `ensureTeamCostSpendBackfilled()` in the background on boot. |
| `src/api/AppRepositories.ts`, `test/common/baseBuilders.ts` | DI wiring + test stub. |
| `src/config/files/development.ts` | `EZTRAC_LOCAL_DB=1` → point to local `CoreDb_local` instead of shared NP RDS. |

**Mental model:** instead of recomputing spend on every read, we keep a
**ledger** (`team_cost_spend`) that is updated when efforts are saved.

### 1B. Reporting (`eztrac-reporting-services`) — faster assembly

| File | Change |
|------|--------|
| `src/util/cacheService.js` | New in‑memory cache: `get/set`, TTL tiers (STATIC 30m, SEMI_STATIC 15m, DYNAMIC 5m, TOKEN 50m), in‑flight coalescing, stats. |
| `src/util/getToken.js` | Cache OAuth token (~50m) + coalesce concurrent token fetches. |
| `src/api/getSpendingForRange.js` | Wrap each upstream call in `cache.getOrFetch`; **cache the full spending tree for 5m (DYNAMIC)**; `warmStaticCaches()`; stage timing logs. |
| `src/api/models/EffortSpendingMap.js` | Build a `Map` `teamId:engagementId → comment` once → O(1) lookups (was O(n²) `.find`). |
| `src/api/routes.js` | Adds `Cache-Control: private, max-age=300` on the spending response. |
| `server.js` | Calls `warmStaticCaches()` after listen. |
| `getAllSpendings.js` | Still calls **live** Core `/spend` (not `/reporting/spend` yet). |

**Two independent wins here:** (a) safe wins — token cache, static ref caches,
O(1) join, warmup; (b) risky wins — the **5‑minute spend/tree cache + browser
`Cache-Control`**, which is what creates staleness.

---

## 2. Old vs New — side by side

| Topic | Old | New (current WIP) | Fresh + fast target |
|-------|-----|-------------------|----------------------|
| Core work per read | Full recompute from efforts | Table read (fallback to live) via `/reporting/spend` — *but reporting still calls live `/spend`* | Table read only |
| When spend is computed | At read time | At effort‑save time (write‑through) + backfill | Same |
| Reporting reference data (teams/people/…) | Re‑fetched each click | Cached 15–30m | Cached, invalidate on change |
| Reporting spend/tree | Recomputed each click | **Cached 5m (stale risk)** | **Version/event‑based cache (fresh)** |
| Join | O(n²) `.find` | O(1) Map | O(1) Map |
| Auth token | Fetched many times | Cached ~50m | Cached ~50m |
| Freshness | Always fresh | **Can be up to ~5–10m stale** | **Always fresh** |
| Dev DB safety | Shared NP | Optional local `*_local` copy | Local copy for risky ops |

---

## 3. Why we did it this way (and the trade‑offs)

- **Why a table instead of just caching?** A cache is a *sticky note* that goes
  wrong the moment finance edits an effort until it expires. A table is a
  *ledger*: write‑through keeps it correct after each save, and reads are a fast
  indexed lookup. Correct **and** fast.
- **Why write‑through (on effort save)?** It keeps the ledger current exactly
  when data changes, so reads never need to recompute.
- **Why a startup backfill with an advisory lock?** So a fresh environment (or a
  newly migrated table) self‑populates all history once, and only **one** pod
  does it (no double‑backfill / thundering herd).
- **Why the reporting caches?** Reference data (team/person/cost‑group names)
  changes rarely, so caching it is a safe, big latency win. **The problem is we
  applied the same time‑based caching to the spend numbers**, which must be
  fresh.

---

## 4. The freshness problem (must fix)

These three things violate "data must not be stale":

1. `getSpendingForRange.js` — `spendingTree:*` cached for `TTL.DYNAMIC` (5 min).
2. `getSpendingForRange.js` — `spendings:*` cached for `TTL.DYNAMIC` (5 min).
3. `routes.js` — `Cache-Control: private, max-age=300` lets the **browser** hold
   a stale response for 5 min (a Refresh may still serve from disk cache).

If finance edits an effort, Core write‑through updates `team_cost_spend`
instantly, but reporting can still serve the old cached tree for up to 5 minutes
— so the UI looks stale even though Core is correct.

**Fix:** replace time‑based caching of *dynamic* data with **event‑based
invalidation** (see section 5). Keep time‑based caching only for token +
reference data.

---

## 5. Recommended architecture — near‑zero latency AND fresh

The key idea: **latency and freshness are only compatible if "fresh" is cheap to
detect.** We make freshness cheap with a **version stamp** per timeframe range.

### 5.1 Source of truth: Core `team_cost_spend` (keep it)
- Reporting reads `GET /reporting/spend/...` (switch off live `/spend`).
- Write‑through already keeps it current on effort save.

### 5.2 Add a cheap "version" signal in Core
- Add `updated_at` awareness (already on the table). Expose a tiny endpoint:
  `GET /reporting/spend/version/startTimeFrame/{s}/endTimeFrame/{e}` returning
  `MAX(updated_at)` (+ row count) for that range. This is a fast indexed query.
- Optionally return it as an **ETag** / `Last-Modified` header on the spend read
  itself.

### 5.3 Reporting caches by version, not by clock
- Cache key becomes `spendingTree:{s}:{e}:{version}`.
- On each request, reporting does a cheap **version check** first:
  - version unchanged → serve cached tree (near‑zero latency, and provably fresh).
  - version changed → recompute tree, cache under the new version key.
- Reference data (teams/people/cost groups) stays on TTL caching **but** also
  gets an explicit invalidation hook when it changes.

### 5.4 Fix the browser layer
- Change `Cache-Control` to `no-cache` (or `private, max-age=0, must-revalidate`)
  and rely on **ETag** revalidation, so the browser always confirms freshness
  but pays ~0 bytes when nothing changed (`304 Not Modified`).

### 5.5 Result
- First click (cold): one table read + join (fast; no effort recompute).
- Repeat click, nothing changed: version check hit → instant, and **guaranteed
  fresh**.
- After an effort edit: version changes → next click recomputes automatically →
  **fresh immediately**, no waiting for a TTL to expire.

---

## 6. Alternative approaches considered

| Approach | Latency | Freshness | Complexity | Notes |
|----------|---------|-----------|------------|-------|
| **A. Live recompute every read (old)** | Poor | Perfect | Low | Current pain. |
| **B. Time‑based cache only (current WIP)** | Good | **Stale up to TTL** | Low | Violates "no stale". |
| **C. Precomputed table + write‑through + version‑based cache (recommended)** | Excellent | Perfect | Medium | Best balance; builds on what we already wrote. |
| **D. DB materialized view (`REFRESH MATERIALIZED VIEW CONCURRENTLY`)** | Excellent read | Stale until refresh | Medium | Refresh is periodic → stale window; no write‑through granularity. |
| **E. Postgres trigger‑maintained aggregate** | Excellent | Perfect | High | Logic lives in SQL triggers — harder to test/debug than app write‑through. |
| **F. Event/CDC driven (LISTEN/NOTIFY or queue)** | Excellent | Near‑perfect | High | Good for multi‑service invalidation; more moving parts. |
| **G. External cache (Redis) with pub/sub invalidation** | Excellent | Perfect (with invalidation) | Medium‑High | Needed only if we run **multiple reporting pods** (in‑memory cache isn't shared). |

**Recommendation:** **C**, with **G** added *only if* reporting runs more than
one instance (otherwise the in‑memory cache is per‑pod and can diverge). If we
already run multiple reporting replicas, jump straight to **C + G**.

> Multi‑pod caveat: the current in‑memory `cacheService` and the version check
> both assume a single reporting instance for perfect freshness. With N pods, a
> shared store (Redis) or always doing the (cheap) version check against Core is
> required.

---

## 7. Data safety — no data loss in any environment

Non‑negotiable: **existing data must never be lost** (local, NP, prod).

1. **Migration is additive only.** `team_cost_spend` is a *new* table; the up
   migration only `CREATE`s. The down migration `DROP`s only the new table —
   **never** touches efforts/allocations/breakdowns (the real source data). Keep
   it that way.
2. **`team_cost_spend` is derived, not primary.** It can always be rebuilt from
   efforts via backfill. Losing it = a rebuild, not data loss. Source tables are
   never mutated by this feature.
3. **Write‑through is delete+insert scoped to one `(team, timeframe)` in a tx.**
   Verify it can never delete more than the intended key set, and that a failed
   insert rolls back the delete (it's in `db.tx`, so it does).
4. **Backfill must be ranged in prod.** Full‑history backfill can be huge; use
   `POST /reporting/spend/backfill/startTimeFrame/.../endTimeFrame/...` in
   batches. Confirm memory/time bounds before running prod‑wide.
5. **Startup backfill only fills when empty** and is guarded by an advisory lock
   — it will not clobber populated data. Keep the "count > 0 → skip" guard.
6. **Never point local tooling at NP/prod by accident.** `EZTRAC_LOCAL_DB=1`
   selects `CoreDb_local`. Backfill/repair experiments run against the local
   copy first. Document a hard check before any prod backfill.
7. **Prod rollout order:** migrate (create table) → deploy code (write‑through
   starts) → ranged backfill history → verify → switch reporting to
   `/reporting/spend`. Live `/spend` stays as fallback the whole time.
8. **Rollback:** reporting can revert to live `/spend`; Core can drop the table
   without affecting source data. No destructive step in the happy path.

---

## 8. Proposed implementation phases

> Nothing below is done yet — this is the sequence to review before we start.

### Phase 0 — Decisions (needs your input, see section 10)
- Confirm freshness SLA (truly 0 stale vs "within a few seconds").
- Confirm number of reporting pods (single vs multi → Redis?).
- Confirm prod DB migration/backfill window + who runs it.

### Phase 1 — Lock in the safe wins (no freshness risk)
- Keep: token cache, reference‑data caches, O(1) join, boot warmup.
- **Remove/relax the risky bits now:** drop the 5‑min `spendings:*` and
  `spendingTree:*` caches (or gate behind a flag) and change `Cache-Control` to
  revalidate. This restores freshness immediately even before Phase 2.

### Phase 2 — Make Core the fast source
- Run migration in each env (additive).
- Ranged backfill history into `team_cost_spend`.
- Switch `getAllSpendings.js` to call `/reporting/spend` (keep live `/spend` as
  fallback on error/empty).

### Phase 3 — Version‑based freshness (the real "0 latency + fresh")
- Add Core version endpoint / ETag (`MAX(updated_at)` per range).
- Reporting: version‑keyed tree cache + cheap version check per request.
- Browser: ETag revalidation (`304` on no change).

### Phase 4 — Scale + observe (optional / if multi‑pod)
- Redis shared cache + invalidation on effort save (pub/sub) if >1 reporting pod.
- Metrics: cache hit rate, version‑check latency, stage timings, backfill runtime.
- Alert if `team_cost_spend` write‑through failures spike.

### Phase 5 — Verification
- After an effort edit, the report reflects it on the **next** click (no TTL wait).
- Load test wide ranges (e.g. multi‑year) for read latency.
- Confirm backfill correctness: table totals == live recompute for sampled ranges.

---

## 9. How to verify freshness (acceptance test)

1. Open Spending Reports, note a team/initiative total for a range.
2. In Core, edit an effort that affects that total.
3. Confirm `team_cost_spend` row `updated_at` bumped (write‑through worked).
4. Re‑open / refresh the report → total updates **immediately** (no 5‑min wait).
5. Confirm a repeat click with no changes is instant (version‑check hit / `304`).

---

## 10. Open questions for you

1. **Freshness SLA:** must it be *instantly* fresh on the next click (version
   approach), or is "within N seconds" acceptable (cheaper)?
2. **Reporting scale:** one pod or many? (Decides whether we need Redis for a
   shared, correct cache.)
3. **Prod backfill:** who runs it, and what's the safe timeframe range/batch
   size? Any known row‑count ceiling?
4. **Cut over reporting to `/reporting/spend` now**, or keep live `/spend` until
   backfill is verified in each env?
5. **Keep any short cache at all** for the spend tree, or zero caching of
   dynamic spend (rely purely on the fast table read + reference caches)?

---

*Related: `eztrac-notes/eztrac-local-setup/docs/SPENDING_PERFORMANCE.md`
(detailed narrative of the current changes) and `plans/README.md` (original
phased latency plan).*
