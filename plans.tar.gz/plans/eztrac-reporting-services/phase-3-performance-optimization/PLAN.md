# Phase 3: Performance Optimization

## Objective

Optimize the heavy in-memory data processing that happens after external data is fetched. Focus on algorithm improvements and efficient data structures.

## Timeline: 3-5 Days

---

## Tasks

### 3.1 Optimize EffortSpendingMap - O(n²) → O(n)

**Problem:** The current `recursive()` function uses `.filter()` inside a recursive tree traversal. For each node, it scans the entire spending array:

```javascript
// Current: O(n * m) where n = tree nodes, m = spending items
const spendItems = spendingData.filter(s => s.initiativeId === node.id)
```

With 500 initiatives and 10,000 spending items, this is 5,000,000 comparisons.

**Fix:** Pre-index spending data into a Map for O(1) lookups:

```javascript
// Optimized: O(n + m) - build index once, lookup is O(1)
const spendingIndex = new Map()
spendingData.forEach(item => {
    if (!spendingIndex.has(item.initiativeId)) {
        spendingIndex.set(item.initiativeId, [])
    }
    spendingIndex.get(item.initiativeId).push(item)
})

// In recursive: O(1) lookup
const spendItems = spendingIndex.get(node.id) || []
```

**See:** `samples/optimized-effort-map.js`

---

### 3.2 Implement Response Streaming for Large Payloads

**Problem:** The server builds the entire JSON response in memory before sending. For large datasets, this:
- Increases memory usage (entire response buffered)
- Delays Time-To-First-Byte (TTFB)
- Can cause timeouts for very large responses

**Fix:** Use JSON streaming for large responses.

**See:** `samples/streaming-response.js`

---

### 3.3 Optimize Tree Building with Worker Threads

**Problem:** The recursive tree building and mapping is CPU-intensive and blocks the event loop. During processing, the server can't handle other requests.

**Fix:** Move heavy computation to a worker thread.

**See:** `samples/parallel-processing.js`

---

### 3.4 Reduce Payload Size

**Problem:** The API returns all fields for all items, even if the UI only needs a subset.

**Fix Options:**
1. **Field selection** - Allow clients to specify which fields they need
2. **Compression** - Already enabled via `compression()` middleware (verify it works)
3. **Pagination** - For endpoints that return lists

---

## Acceptance Criteria

- [ ] EffortSpendingMap uses indexed lookups (Map) instead of .filter()
- [ ] Large responses are streamed (TTFB < 500ms)
- [ ] Heavy computation doesn't block event loop (worker threads)
- [ ] Response payload size reduced by 30%+ with field selection
- [ ] Benchmark tests show measurable improvement

## Estimated Impact

- **Map indexing**: 80-90% reduction in processing time for large datasets
- **Streaming**: 50% improvement in TTFB
- **Worker threads**: Event loop stays responsive during heavy computation
