/**
 * Optimized EffortSpendingMap - O(n²) → O(n)
 * 
 * Problem: The recursive() function uses .filter() inside tree traversal.
 * For each node in the tree, it scans ALL spending items.
 * 
 * Solution: Pre-index data into Maps for O(1) lookups.
 * 
 * File to modify: eztrac-reporting-services/src/api/getSpendingForRange.js
 */

const logger = require('../../logger')

/**
 * Build lookup indexes from flat arrays for O(1) access
 * Call this ONCE before starting the recursive tree traversal.
 */
const buildIndexes = (spendingData, effortEngagements, engagements, teams, people) => {
    const startTime = Date.now()

    // Index spending by initiativeId: Map<initiativeId, SpendItem[]>
    const spendingByInitiative = new Map()
    spendingData.forEach(item => {
        const key = item.initiativeId
        if (!spendingByInitiative.has(key)) {
            spendingByInitiative.set(key, [])
        }
        spendingByInitiative.get(key).push(item)
    })

    // Index effort engagements by initiativeId: Map<initiativeId, EffortEngagement[]>
    const effortByInitiative = new Map()
    effortEngagements.forEach(item => {
        const key = item.initiativeId
        if (!effortByInitiative.has(key)) {
            effortByInitiative.set(key, [])
        }
        effortByInitiative.get(key).push(item)
    })

    // Index engagements by id: Map<engagementId, Engagement>
    const engagementById = new Map()
    engagements.forEach(item => {
        engagementById.set(item.id, item)
    })

    // Index teams by id: Map<teamId, Team>
    const teamById = new Map()
    teams.forEach(item => {
        teamById.set(item.id, item)
    })

    // Index people by id: Map<personId, Person>
    const personById = new Map()
    people.forEach(item => {
        personById.set(item.id, item)
    })

    const elapsed = Date.now() - startTime
    logger.info(`Indexes built in ${elapsed}ms`, {
        spendingEntries: spendingData.length,
        effortEntries: effortEngagements.length,
        engagementEntries: engagements.length,
        teamEntries: teams.length,
        peopleEntries: people.length
    })

    return {
        spendingByInitiative,
        effortByInitiative,
        engagementById,
        teamById,
        personById
    }
}

/**
 * OPTIMIZED recursive function using pre-built indexes
 * 
 * Before: O(n * m) - filter() scans all items for each node
 * After:  O(1) - Map.get() for each node
 */
const recursiveOptimized = (node, indexes) => {
    const children = node.children || []

    // O(1) lookup instead of O(m) filter
    const spendItems = indexes.spendingByInitiative.get(node.id) || []
    const effortItems = indexes.effortByInitiative.get(node.id) || []

    // Fixed operator precedence (Phase 1 bug fix included)
    const childExpenditure = children.reduce(
        (sum, child) => sum + (child.totalExpenditure || 0), 0
    )

    const expenditure = spendItems.reduce(
        (sum, item) => sum + (item.spend || 0), 0
    )

    // Enrich effort items with engagement/team/person data (also O(1) lookups)
    const enrichedEffort = effortItems.map(effort => {
        const engagement = indexes.engagementById.get(effort.engagementId)
        const team = engagement ? indexes.teamById.get(engagement.teamId) : null
        const person = indexes.personById.get(effort.personId)

        return {
            ...effort,
            engagementName: engagement?.name || 'Unknown',
            teamName: team?.name || 'Unknown',
            personName: person?.name || 'Unknown'
        }
    })

    return {
        ...node,
        totalExpenditure: childExpenditure + expenditure,
        spending: spendItems,
        effort: enrichedEffort,
        children: children.map(child => recursiveOptimized(child, indexes))
    }
}

/**
 * Main entry point - builds indexes then processes tree
 */
const buildSpendingTree = (initiativeTree, spendingData, effortEngagements, engagements, teams, people) => {
    const startTime = Date.now()

    // Step 1: Build indexes (one-time cost)
    const indexes = buildIndexes(spendingData, effortEngagements, engagements, teams, people)

    // Step 2: Process tree with O(1) lookups
    const result = recursiveOptimized(initiativeTree, indexes)

    const elapsed = Date.now() - startTime
    logger.info(`Spending tree built in ${elapsed}ms`)

    return result
}

// ============================================================
// BENCHMARK: Compare old vs new approach
// ============================================================

const benchmark = () => {
    // Simulate data
    const nodeCount = 500
    const spendingCount = 10000

    const nodes = Array.from({length: nodeCount}, (_, i) => ({id: i, children: []}))
    const spending = Array.from({length: spendingCount}, (_, i) => ({
        initiativeId: Math.floor(Math.random() * nodeCount),
        spend: Math.random() * 1000
    }))

    // OLD approach: filter for each node
    console.time('OLD: filter approach')
    nodes.forEach(node => {
        const items = spending.filter(s => s.initiativeId === node.id)
        items.reduce((sum, item) => sum + (item.spend || 0), 0)
    })
    console.timeEnd('OLD: filter approach')

    // NEW approach: Map index
    console.time('NEW: Map index approach')
    const index = new Map()
    spending.forEach(item => {
        if (!index.has(item.initiativeId)) index.set(item.initiativeId, [])
        index.get(item.initiativeId).push(item)
    })
    nodes.forEach(node => {
        const items = index.get(node.id) || []
        items.reduce((sum, item) => sum + (item.spend || 0), 0)
    })
    console.timeEnd('NEW: Map index approach')
}

// Uncomment to run benchmark:
// benchmark()

module.exports = {buildSpendingTree, buildIndexes, recursiveOptimized}
