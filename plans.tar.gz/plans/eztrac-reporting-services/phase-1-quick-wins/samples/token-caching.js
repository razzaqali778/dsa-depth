/**
 * Token Caching Implementation
 * 
 * Problem: getToken() is called 7 times per request (once per external service call).
 * Each call makes a network round-trip to the OAuth provider.
 * 
 * Solution: Cache the token in memory with TTL. OAuth tokens typically expire in 1 hour,
 * so we cache for 50 minutes to have a safety margin.
 * 
 * File to modify: eztrac-reporting-services/src/util/getToken.js
 */

const {httpGetToken} = require('@monsantoit/oauth-azure')
const config = require('../config')
const logger = require('../../logger')

// Token cache
let cachedToken = null
let tokenExpiresAt = 0
const TOKEN_TTL_MS = 50 * 60 * 1000 // 50 minutes (tokens expire in 60 min)

// Prevent multiple simultaneous token fetches (thundering herd)
let tokenFetchPromise = null

const getToken = async () => {
    const now = Date.now()

    // Return cached token if still valid
    if (cachedToken && now < tokenExpiresAt) {
        return cachedToken
    }

    // If a token fetch is already in progress, wait for it (prevents thundering herd)
    if (tokenFetchPromise) {
        logger.info('Token fetch already in progress, waiting...')
        return tokenFetchPromise
    }

    // Fetch new token
    try {
        logger.info('Fetching new OAuth token...')
        const startTime = Date.now()

        tokenFetchPromise = httpGetToken({
            clientId: config.get('oauth-client.id'),
            clientSecret: config.get('oauth-client.secret')
        })()

        cachedToken = await tokenFetchPromise
        tokenExpiresAt = now + TOKEN_TTL_MS

        const elapsed = Date.now() - startTime
        logger.info(`OAuth token fetched in ${elapsed}ms, cached for ${TOKEN_TTL_MS / 1000}s`)

        return cachedToken
    } catch (error) {
        // Clear cache on error so next call retries
        cachedToken = null
        tokenExpiresAt = 0
        logger.error('Failed to fetch OAuth token:', error.message)
        throw error
    } finally {
        tokenFetchPromise = null
    }
}

// Utility to manually invalidate token (useful for testing or forced refresh)
const invalidateToken = () => {
    cachedToken = null
    tokenExpiresAt = 0
    logger.info('Token cache invalidated')
}

module.exports = getToken
module.exports.invalidateToken = invalidateToken
