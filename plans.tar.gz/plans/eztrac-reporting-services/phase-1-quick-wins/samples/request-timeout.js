/**
 * Request Timeout & Retry Implementation
 * 
 * Problem: External service calls have no timeout or retry logic.
 * If any service is slow/down, the entire request hangs indefinitely.
 * 
 * Solution: Create a wrapper that adds timeout, retry, and error context
 * to all external HTTP calls.
 * 
 * Usage: Replace direct superagent calls with this wrapper.
 */

const agent = require('superagent')
const logger = require('../../logger')

const DEFAULT_TIMEOUT = 30000 // 30 seconds
const DEFAULT_RETRIES = 1
const RETRY_DELAY_MS = 1000 // 1 second between retries

/**
 * Sleep utility for retry delays
 */
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/**
 * Makes an HTTP GET request with timeout, retry, and structured error handling.
 * 
 * @param {Object} options
 * @param {string} options.url - The URL to fetch
 * @param {string} options.token - Bearer token for authorization
 * @param {string} options.serviceName - Name of the service (for logging)
 * @param {number} [options.timeout] - Timeout in ms (default: 30000)
 * @param {number} [options.retries] - Number of retries (default: 1)
 * @returns {Promise<Object>} - Response body
 */
const fetchWithRetry = async ({
    url,
    token,
    serviceName,
    timeout = DEFAULT_TIMEOUT,
    retries = DEFAULT_RETRIES
}) => {
    let lastError = null

    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const startTime = Date.now()

            const result = await agent
                .get(url)
                .set('Authorization', `Bearer ${token}`)
                .set('Accept-Encoding', 'gzip, deflate') // Request compressed response
                .timeout({
                    response: timeout,  // Wait for server to start sending response
                    deadline: timeout * 2 // Total time for the request (including large payloads)
                })

            const elapsed = Date.now() - startTime
            logger.info(`[${serviceName}] Request completed in ${elapsed}ms (attempt ${attempt + 1})`, {
                url,
                elapsed,
                attempt: attempt + 1,
                statusCode: result.status
            })

            return result

        } catch (error) {
            lastError = error
            const elapsed = Date.now()

            // Determine if error is retryable
            const isRetryable = isRetryableError(error)

            logger.warn(`[${serviceName}] Request failed (attempt ${attempt + 1}/${retries + 1})`, {
                url,
                error: error.message,
                code: error.code,
                status: error.status,
                isRetryable,
                attempt: attempt + 1
            })

            // Don't retry if error is not retryable or we've exhausted retries
            if (!isRetryable || attempt >= retries) {
                break
            }

            // Wait before retrying (exponential backoff)
            const delay = RETRY_DELAY_MS * Math.pow(2, attempt)
            logger.info(`[${serviceName}] Retrying in ${delay}ms...`)
            await sleep(delay)
        }
    }

    // All retries exhausted - throw enriched error
    const enrichedError = new Error(
        `[${serviceName}] Failed after ${retries + 1} attempts: ${lastError.message}`
    )
    enrichedError.originalError = lastError
    enrichedError.serviceName = serviceName
    enrichedError.url = url
    enrichedError.status = lastError.status || 503
    throw enrichedError
}

/**
 * Determines if an error is retryable
 */
const isRetryableError = (error) => {
    // Network errors (timeout, connection refused, etc.)
    if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT' || error.code === 'ECONNRESET') {
        return true
    }
    // Server errors (5xx) are retryable
    if (error.status && error.status >= 500) {
        return true
    }
    // Client errors (4xx) are NOT retryable
    if (error.status && error.status >= 400 && error.status < 500) {
        return false
    }
    return true // Default: retry on unknown errors
}

/**
 * Example: Refactored getAllSpendings using fetchWithRetry
 * 
 * File: eztrac-reporting-services/src/api/external/coreServices/getAllSpendings.js
 */
const getToken = require('../../../util/getToken') // Uses cached version
const config = require('../../../config')
const {EffortInitiativeSpending} = require('../../models')

const getAllSpendings = async (startTimeFrame, endTimeFrame) => {
    const token = await getToken()

    const result = await fetchWithRetry({
        url: `${config.get('ez-trac-core-url')}/spend/startTimeFrame/${startTimeFrame}/endTimeFrame/${endTimeFrame}`,
        token,
        serviceName: 'CoreServices:getAllSpendings',
        timeout: 30000,
        retries: 1
    })

    return result.body.map((item) => new EffortInitiativeSpending(item))
}

/**
 * Example: Refactored getSpendingForRange with Promise.allSettled pattern
 * 
 * File: eztrac-reporting-services/src/api/getSpendingForRange.js
 */
const getSpendingForRangeWithErrorHandling = async (startTimeframe, endTimeframe) => {
    const results = await Promise.allSettled([
        getAllInitiatives(),
        getAllSpendings(startTimeframe, endTimeframe),
        getAllTeams(),
        getCostGroups(),
        getAllEngagements(),
        getAllEffortEngagements(startTimeframe, endTimeframe),
        getAllPeople()
    ])

    // Check for failures and provide detailed error info
    const serviceNames = [
        'VIP:Initiatives', 'Core:Spendings', 'Core:Teams',
        'Costing:CostGroups', 'Costing:Engagements',
        'Core:EffortEngagements', 'Costing:People'
    ]

    const failures = results
        .map((result, index) => ({result, serviceName: serviceNames[index]}))
        .filter(({result}) => result.status === 'rejected')

    if (failures.length > 0) {
        const failedServices = failures.map(f => f.serviceName).join(', ')
        const error = new Error(`Failed to fetch data from: ${failedServices}`)
        error.status = 503
        error.details = failures.map(f => ({
            service: f.serviceName,
            error: f.result.reason.message
        }))
        logger.error('External service failures:', error.details)
        throw error
    }

    // All succeeded - extract values
    const [initiatives, spending, teams, costGroups, engagements, effortEngagements, people] =
        results.map(r => r.value)

    return {initiatives, spending, teams, costGroups, engagements, effortEngagements, people}
}

module.exports = {fetchWithRetry, isRetryableError, getAllSpendings}
