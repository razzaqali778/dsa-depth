/**
 * Operator Precedence Bug Fix
 * 
 * File to modify: eztrac-reporting-services/src/api/getSpendingForRange.js
 * 
 * This shows the before/after of the recursive() function fix.
 */

// ============================================================
// BEFORE (BUGGY) - Current implementation
// ============================================================

const recursive_BUGGY = (node, spendingData) => {
    const children = node.children || []
    const spendItems = spendingData.filter(s => s.initiativeId === node.id)

    // BUG: (sum + child.totalExpenditure) || 0
    // If child.totalExpenditure is undefined, sum + undefined = NaN
    // Then NaN || 0 = 0, LOSING all previously accumulated sum
    const childExpenditure = children.reduce(
        (sum, child) => sum + child.totalExpenditure || 0, 0
    )

    // Same bug here
    const expenditure = spendItems.reduce((sum, item) => sum + item.spend || 0, 0)

    return {
        ...node,
        totalExpenditure: childExpenditure + expenditure,
        children: children.map(child => recursive_BUGGY(child, spendingData))
    }
}

// ============================================================
// AFTER (FIXED) - Corrected implementation
// ============================================================

const recursive_FIXED = (node, spendingData) => {
    const children = node.children || []
    const spendItems = spendingData.filter(s => s.initiativeId === node.id)

    // FIXED: Parentheses ensure || 0 applies only to the individual value
    const childExpenditure = children.reduce(
        (sum, child) => sum + (child.totalExpenditure || 0), 0
    )

    // FIXED: Same fix applied here
    const expenditure = spendItems.reduce(
        (sum, item) => sum + (item.spend || 0), 0
    )

    return {
        ...node,
        totalExpenditure: childExpenditure + expenditure,
        children: children.map(child => recursive_FIXED(child, spendingData))
    }
}

// ============================================================
// TEST CASES to verify the fix
// ============================================================

const testCases = () => {
    // Test Case 1: All values present
    const result1 = [
        {totalExpenditure: 100},
        {totalExpenditure: 200},
        {totalExpenditure: 300}
    ].reduce((sum, child) => sum + (child.totalExpenditure || 0), 0)
    console.assert(result1 === 600, `Expected 600, got ${result1}`)

    // Test Case 2: Some undefined values (this is where the bug manifests)
    const result2 = [
        {totalExpenditure: 100},
        {totalExpenditure: undefined}, // This would cause NaN in buggy version
        {totalExpenditure: 300}
    ].reduce((sum, child) => sum + (child.totalExpenditure || 0), 0)
    console.assert(result2 === 400, `Expected 400, got ${result2}`)

    // Test Case 3: Buggy version for comparison
    const result3_buggy = [
        {totalExpenditure: 100},
        {totalExpenditure: undefined},
        {totalExpenditure: 300}
    ].reduce((sum, child) => sum + child.totalExpenditure || 0, 0)
    console.assert(result3_buggy === 300, `Buggy version gives ${result3_buggy} instead of 400`)
    // Note: Buggy version gives 300 because:
    // Iteration 1: 0 + 100 = 100 ✅
    // Iteration 2: (100 + undefined) || 0 = NaN || 0 = 0 ❌ (lost 100!)
    // Iteration 3: (0 + 300) || 0 = 300

    // Test Case 4: All undefined
    const result4 = [
        {totalExpenditure: undefined},
        {totalExpenditure: null},
        {}
    ].reduce((sum, child) => sum + (child.totalExpenditure || 0), 0)
    console.assert(result4 === 0, `Expected 0, got ${result4}`)

    console.log('All test cases passed!')
}

// Run tests
testCases()

module.exports = {recursive_FIXED}
