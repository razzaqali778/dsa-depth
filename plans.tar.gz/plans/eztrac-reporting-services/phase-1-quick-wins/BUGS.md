# Documented Bugs - EzTrac Reporting

## Bug #1: Operator Precedence in Expenditure Calculation (CRITICAL)

**Severity:** 🔴 Critical  
**Component:** eztrac-reporting-services  
**File:** `src/api/getSpendingForRange.js` (Lines 35-36, 40)

### Description

The `recursive()` function has an operator precedence bug that can cause incorrect financial calculations. The `||` operator has lower precedence than `+`, causing the entire sum expression to be evaluated before the fallback.

### Current Code (Buggy)

```javascript
const childExpenditure = children.reduce(
    (sum, child) => sum + child.totalExpenditure || 0,
    0
)
const expenditure = spendItems.reduce((sum, item) => sum + item.spend || 0, 0)
```

### How It Fails

```
Iteration 1: sum=0, child.totalExpenditure=100 → (0 + 100) || 0 = 100 ✅
Iteration 2: sum=100, child.totalExpenditure=undefined → (100 + undefined) || 0 = NaN || 0 = 0 ❌
// Lost the accumulated 100!

Iteration 3: sum=0, child.totalExpenditure=50 → (0 + 50) || 0 = 50
// Final result: 50 instead of correct 150
```

### Fix

```javascript
const childExpenditure = children.reduce(
    (sum, child) => sum + (child.totalExpenditure || 0),
    0
)
const expenditure = spendItems.reduce((sum, item) => sum + (item.spend || 0), 0)
```

### Impact

Financial reports may show incorrect (lower) expenditure totals when any child initiative has undefined/null spending data.

---

## Bug #2: localForage Race Condition in UI

**Severity:** 🟡 Medium  
**Component:** eztrac-reporting  
**File:** `src/client/redux/sagas/retrieveStoredDataSaga.js`

### Description

When multiple `retrieveStoredData` actions are dispatched in quick succession (e.g., user rapidly changes timeframes), the saga can:
1. Read stale/empty data from localForage
2. Overwrite valid cached data with empty results
3. Display inconsistent data

### Current Code (Problematic)

```javascript
let returnVal = yield localForage.getItem(payload.storeParam, (err, val) =>
    val === null ? [] : val)

if (isEmpty(returnVal)) {
    // Fetches from network...
    // Another saga instance could be writing to same key simultaneously
}

if (storeName !== '') {
    localForage.setItem(storeName, returnVal)  // No await! Fire and forget
}
```

### Issues

1. `localForage.setItem` is not awaited - no guarantee of write order
2. `takeLatest` helps but doesn't prevent the race between read and write
3. The callback in `getItem` is not properly integrated with the generator

### Fix

```javascript
// Use takeLatest (already done) + add a debounce + await writes
export function* retrieveStoredDataSaga({ payload }) {
    yield delay(100) // debounce rapid calls
    
    const returnVal = yield call([localForage, 'getItem'], payload.storeParam)
    
    if (!returnVal || isEmpty(JSON.parse(returnVal))) {
        // fetch from network...
    }
    
    if (storeName !== '') {
        yield call([localForage, 'setItem'], storeName, returnVal) // await the write
    }
}
```

---

## Bug #3: No Error Handling on External Service Calls

**Severity:** 🟡 Medium  
**Component:** eztrac-reporting-services  
**File:** `src/api/getSpendingForRange.js`

### Description

`Promise.all()` rejects immediately if ANY of the 7 external calls fail. This means:
- A temporary network blip on one service crashes the entire report
- User gets a generic 500 error with no indication of which service failed
- No retry mechanism

### Current Code

```javascript
const [initiatives, spending, teams, costGroups, engagements, effortEngagements, people] =
    await Promise.all([
        getAllInitiatives(),        // If this fails...
        getAllSpendings(...),       // ...all these results are lost
        getAllTeams(),
        getCostGroups(),
        getAllEngagements(),
        getAllEffortEngagements(...),
        getAllPeople()
    ])
```

### Fix

See `samples/request-timeout.js` for retry wrapper implementation.

---

## Bug #4: Console.log in Production

**Severity:** 🟢 Low  
**Component:** eztrac-reporting-services  
**File:** `src/api/external/vipServices/getAllInitiatives.js`

### Description

Uses `console.log` for timing information instead of the project's structured logger. This:
- Won't appear in log aggregation tools
- Has no log level control
- Can't be filtered in production

### Fix

Replace with project logger:
```javascript
const logger = require('../../../../logger')
logger.info(`time to get initiatives tree in ms: ${diff}`)
```

---

## Bug #5: Stale UI Cache (No Invalidation)

**Severity:** 🟡 Medium  
**Component:** eztrac-reporting  
**File:** `src/client/redux/sagas/retrieveStoredDataSaga.js`

### Description

The UI caches spending data in `localForage` keyed by timeframe range (e.g., `spendingTrees(1/12)`). This cache is only cleared when:
- User clicks "Refresh" button (clears ALL cache)
- User is on localhost and opens a new session

**Problem:** If underlying data changes (new spending entries, team changes, etc.), the user sees stale data until they manually refresh. There's no TTL or background revalidation.

### Fix Options

1. **Add TTL to cached items** - Store timestamp with data, invalidate after X minutes
2. **Stale-while-revalidate** - Show cached data immediately, fetch fresh in background
3. **ETag/Last-Modified** - Server returns hash, client checks if data changed

Recommended: Option 2 (stale-while-revalidate) for best UX.
