# Phase 1: Quick Wins - Bug Fixes & Immediate Latency Improvements

## Objective

Fix critical bugs that affect data accuracy and implement low-effort, high-impact latency improvements.

## Timeline: 1-2 Days

---

## Tasks

### 1.1 Fix Operator Precedence Bug in `recursive()` (CRITICAL)

**File:** `eztrac-reporting-services/src/api/getSpendingForRange.js`

**Problem:** Lines 36 and 40 have operator precedence issues:
```javascript
// BUGGY - Current code:
const childExpenditure = children.reduce(
    (sum, child) => sum + child.totalExpenditure || 0, 0
)
// This evaluates as: (sum + child.totalExpenditure) || 0
// If sum is 100 and child.totalExpenditure is undefined, result is NaN, then || 0 gives 0
// LOSING all previously accumulated sum!

const expenditure = spendItems.reduce((sum, item) => sum + item.spend || 0, 0)
// Same issue here
```

**Fix:**
```javascript
// FIXED:
const childExpenditure = children.reduce(
    (sum, child) => sum + (child.totalExpenditure || 0), 0
)

const expenditure = spendItems.reduce((sum, item) => sum + (item.spend || 0), 0)
```

**Impact:** This bug can cause incorrect expenditure calculations, potentially showing $0 for initiatives that have spending data.

---

### 1.2 Implement Token Caching

**File:** `eztrac-reporting-services/src/util/getToken.js`

**Problem:** `getToken()` is called 7 times per request (once per external service call). Each call makes a network request to the OAuth provider.

**Fix:** Cache the token with TTL (tokens typically expire in 1 hour, cache for 50 minutes).

**See:** `samples/token-caching.js`

---

### 1.3 Add Request Timeouts

**Problem:** External service calls have no timeout. If VIP Services or Core Services are slow/down, the entire request hangs indefinitely.

**Fix:** Add timeout + retry logic to all superagent calls.

**See:** `samples/request-timeout.js`

---

### 1.4 Replace console.log with Logger

**File:** `eztrac-reporting-services/src/api/external/vipServices/getAllInitiatives.js`

**Problem:** Uses `console.log` instead of the project's logger utility.

**Fix:**
```javascript
// Before:
console.log(`time to get initiatives tree in ms: ${diff}`)

// After:
const logger = require('../../../../logger')
logger.info(`time to get initiatives tree in ms: ${diff}`)
```

---

### 1.5 Add Error Handling to External Calls

**Problem:** If any single external call fails, the entire `Promise.all()` rejects and the user gets a 500 error with no useful information.

**Fix:** Wrap each call with error context and implement `Promise.allSettled()` pattern for graceful degradation.

**See:** `samples/request-timeout.js` (includes retry logic)

---

## Acceptance Criteria

- [ ] Expenditure calculations are mathematically correct (operator precedence fixed)
- [ ] Token is cached and reused across parallel calls (1 token fetch per request instead of 7)
- [ ] All external calls have 30-second timeout
- [ ] Failed external calls are retried once before failing
- [ ] No `console.log` in production code
- [ ] All changes have unit tests

## Estimated Impact

- **Token caching**: ~500-1000ms saved per request (eliminates 6 redundant OAuth calls)
- **Timeouts**: Prevents infinite hangs, improves error recovery
- **Bug fix**: Correct financial data (critical for reporting accuracy)
