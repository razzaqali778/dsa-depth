/**
 * Performance Monitoring Middleware
 * 
 * Tracks request-level timing with breakdown of each phase.
 * Logs warnings when performance budgets are exceeded.
 * 
 * Add to: eztrac-reporting-services/src/middleware/performance.js
 * Register in: server.ts (app.use(performanceMiddleware))
 */

const {v4: uuidv4} = require('uuid')
const logger = require('../../logger')

// Performance budgets (in milliseconds)
const BUDGETS = {
    TOTAL_REQUEST_WARN: 5000,    // 5 seconds
    TOTAL_REQUEST_ERROR: 10000,  // 10 seconds
    EXTERNAL_CALL_WARN: 3000,    // 3 seconds per external call
    PROCESSING_WARN: 2000        // 2 seconds for data processing
}

/**
 * Express middleware that tracks request performance
 */
const performanceMiddleware = (req, res, next) => {
    // Generate unique request ID for correlation
    const requestId = req.headers['x-request-id'] || uuidv4()
    req.requestId = requestId
    res.setHeader('X-Request-Id', requestId)

    // Start timing
    const startTime = process.hrtime.bigint()
    req.performanceMetrics = {
        requestId,
        startTime,
        phases: {},
        externalCalls: []
    }

    // Override res.json to capture response timing
    const originalJson = res.json.bind(res)
    res.json = (body) => {
        const endTime = process.hrtime.bigint()
        const totalMs = Number(endTime - startTime) / 1_000_000

        // Log performance summary
        const metrics = {
            requestId,
            method: req.method,
            path: req.path,
            statusCode: res.statusCode,
            totalMs: Math.round(totalMs),
            phases: req.performanceMetrics.phases,
            externalCalls: req.performanceMetrics.externalCalls
        }

        // Check performance budgets
        if (totalMs > BUDGETS.TOTAL_REQUEST_ERROR) {
            logger.error(`🔴 PERFORMANCE BUDGET EXCEEDED: ${req.path} took ${Math.round(totalMs)}ms (budget: ${BUDGETS.TOTAL_REQUEST_ERROR}ms)`, metrics)
        } else if (totalMs > BUDGETS.TOTAL_REQUEST_WARN) {
            logger.warn(`🟡 PERFORMANCE WARNING: ${req.path} took ${Math.round(totalMs)}ms (budget: ${BUDGETS.TOTAL_REQUEST_WARN}ms)`, metrics)
        } else {
            logger.info(`✅ Request completed: ${req.path} in ${Math.round(totalMs)}ms`, metrics)
        }

        // Add timing header
        res.setHeader('X-Response-Time', `${Math.round(totalMs)}ms`)
        res.setHeader('Server-Timing', `total;dur=${Math.round(totalMs)}`)

        return originalJson(body)
    }

    next()
}

/**
 * Helper: Track a phase of request processing
 * 
 * Usage in route handlers:
 *   const endPhase = startPhase(req, 'external-calls')
 *   // ... do work ...
 *   endPhase()
 */
const startPhase = (req, phaseName) => {
    const phaseStart = process.hrtime.bigint()
    return () => {
        const phaseEnd = process.hrtime.bigint()
        const durationMs = Number(phaseEnd - phaseStart) / 1_000_000
        req.performanceMetrics.phases[phaseName] = Math.round(durationMs)

        if (phaseName.includes('external') && durationMs > BUDGETS.EXTERNAL_CALL_WARN) {
            logger.warn(`🟡 External call slow: ${phaseName} took ${Math.round(durationMs)}ms`)
        }
        if (phaseName.includes('processing') && durationMs > BUDGETS.PROCESSING_WARN) {
            logger.warn(`🟡 Processing slow: ${phaseName} took ${Math.round(durationMs)}ms`)
        }
    }
}

/**
 * Helper: Track an external service call
 * 
 * Usage:
 *   const result = await trackExternalCall(req, 'CoreServices:getAllSpendings', () => getAllSpendings())
 */
const trackExternalCall = async (req, serviceName, callFn) => {
    const callStart = process.hrtime.bigint()
    try {
        const result = await callFn()
        const callEnd = process.hrtime.bigint()
        const durationMs = Number(callEnd - callStart) / 1_000_000

        req.performanceMetrics.externalCalls.push({
            service: serviceName,
            durationMs: Math.round(durationMs),
            status: 'success'
        })

        if (durationMs > BUDGETS.EXTERNAL_CALL_WARN) {
            logger.warn(`🟡 Slow external call: ${serviceName} took ${Math.round(durationMs)}ms`)
        }

        return result
    } catch (error) {
        const callEnd = process.hrtime.bigint()
        const durationMs = Number(callEnd - callStart) / 1_000_000

        req.performanceMetrics.externalCalls.push({
            service: serviceName,
            durationMs: Math.round(durationMs),
            status: 'error',
            error: error.message
        })

        throw error
    }
}

/**
 * Health Check Endpoint
 * 
 * Add to routes: router.get('/health', healthCheck)
 */
const healthCheck = async (req, res) => {
    const cache = require('../../util/cacheService')
    const memUsage = process.memoryUsage()

    const health = {
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: Math.round(process.uptime()),
        memory: {
            heapUsed: `${Math.round(memUsage.heapUsed / 1024 / 1024)}MB`,
            heapTotal: `${Math.round(memUsage.heapTotal / 1024 / 1024)}MB`,
            rss: `${Math.round(memUsage.rss / 1024 / 1024)}MB`
        },
        cache: cache.getStats(),
        version: process.env.npm_package_version || 'unknown'
    }

    res.json(health)
}

module.exports = {
    performanceMiddleware,
    startPhase,
    trackExternalCall,
    healthCheck,
    BUDGETS
}
