# EzTrac Reporting - Latency & Bug Fix Plan

## Overview

This document outlines the comprehensive plan to address latency issues and bugs in the **eztrac-reporting** (UI) and **eztrac-reporting-services** (backend API) applications.

## Problem Statement

The reporting module experiences significant latency when fetching and rendering data. The backend service aggregates data from 3 external services (Core Services, Costing Services, VIP Services) via 7 parallel API calls, performs heavy in-memory processing, and returns large payloads to the UI.

## Architecture Flow

```
┌─────────────────────┐
│  eztrac-reporting   │  (React/Redux UI)
│  (Frontend)         │
└─────────┬───────────┘
          │ HTTP GET /v2/spending/startTimeFrame/{id}/endTimeFrame/{id}
          ▼
┌─────────────────────────────┐
│  eztrac-reporting-services  │  (Express.js Backend)
│  (API Aggregator)           │
└─────────┬───────────────────┘
          │ Promise.all([7 parallel calls])
          ▼
┌─────────────────────────────────────────────────────────┐
│                    External Services                      │
├──────────────────┬──────────────────┬───────────────────┤
│  VIP Services    │  Core Services   │  Costing Services │
│  - Initiatives   │  - Spendings     │  - Cost Groups    │
│    Tree          │  - Teams         │  - Engagements    │
│                  │  - Effort        │  - People         │
│                  │    Engagements   │                   │
└──────────────────┴──────────────────┴───────────────────┘
```

## Identified Issues

### Latency Issues
1. No caching on server-side (static data fetched every request)
2. OAuth token fetched 7 times per request (no token caching)
3. No request timeouts on external service calls
4. No pagination - fetches ALL records every time
5. O(n²) algorithm in EffortSpendingMap (`.find()` inside nested loops)
6. No response compression on outgoing requests
7. Large JSON payloads with no streaming

### Bugs
1. Operator precedence bug in `recursive()` function (affects expenditure calculations)
2. localForage race condition in UI
3. No error handling/retry on external service calls
4. Console.log in production code
5. Stale cache in UI (no invalidation strategy)

## Phases

| Phase | Focus | Impact | Effort | Status |
|-------|-------|--------|--------|--------|
| [Phase 1](./phase-1-quick-wins/PLAN.md) | Bug fixes + Quick wins | High | 1-2 days | 🔴 Not Started |
| [Phase 2](./phase-2-caching-layer/PLAN.md) | Server-side caching | Very High | 3-5 days | 🔴 Not Started |
| [Phase 3](./phase-3-performance-optimization/PLAN.md) | Algorithm optimization | High | 3-5 days | 🔴 Not Started |
| [Phase 4](./phase-4-monitoring-observability/PLAN.md) | Monitoring & Observability | Medium | 2-3 days | 🔴 Not Started |

## Expected Outcome

- **Phase 1**: Immediate bug fixes + 20-30% latency reduction
- **Phase 2**: 50-70% latency reduction for repeated requests
- **Phase 3**: 30-40% reduction in processing time for large datasets
- **Phase 4**: Full visibility into performance bottlenecks for ongoing optimization

## Getting Started

Start with Phase 1 as it contains critical bug fixes and low-effort high-impact improvements.
