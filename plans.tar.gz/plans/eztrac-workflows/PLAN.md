# eztrac-workflows — Issues & Fix Plan

> React (redux-first-router) app with no DB of its own. Orchestrates multi-step
> actions across core-services, costing-services, qc, and suggestion: **add a
> person**, **deactivate a person**, admin actions (lockdown, recost, health check).

Source: code-level audit [Analyze eztrac-workflows](f6388dbc-050e-4cce-9f3e-c61dde7e346b).

**Core problem:** none of the multi-service workflows have a compensation/rollback
pattern. On partial failure, the app posts a Teams link for **manual** undo
instead of automatically keeping core/costing/QC consistent.

---

## 1. Bugs — orchestration & partial-failure consistency (top priority)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| B1 | Critical | Add-person: effort writes proceed even if costing failed | `src/client/redux/sagas/activate/addPerson.js:111-124` | Short-circuit effort calls on `costingResult.error`, or compensate |
| B2 | Critical | Add-person: partial success (costing ok, some efforts fail) leaves inconsistent cross-service state, no rollback | `addPerson.js:111-158` | Compensating saga (delete/deactivate person in costing) or workflow-transaction log |
| B3 | Critical | Deactivate: QC reason / costing deactivate / effort save always run regardless of prior step failure | `src/client/redux/sagas/deactivate/deactivatePerson.js:95-98` | Gate each step on prior success or add rollback |
| B4 | Critical | Deactivate error handler **never fires** — `response.deactivate`/`.reason`/`.efforts` are objects, always truthy, so `!response.deactivate` is always false | `deactivatePerson.js:117-126,30-37` | Check `.hasError` field explicitly |
| B5 | Critical | `removeFutureEfforts` races `deactivatePerson` (`takeLatest` on same action, results never merged/awaited/rolled back) | `src/client/redux/sagas/deactivate/removeFutureEfforts.js:26-29`, `sagas/index.js:36` | Call from inside `deactivatePerson` after current-effort save |
| B6 | Critical | Lockdown: no rollback if QC archive/recost fails after core lockdown succeeds | `src/client/actions/admin/lockdownAction.js:19-36` | Patch lockdown back to `false` on downstream failure |
| B7 | High | Review task sent even when effort writes failed (only checks costing) | `addPerson.js:156-158` | Only dispatch `sendTask()` when person **and** efforts succeed |
| B8 | High | `saveEfforts` misaligns undo metadata when some calls are skipped (filtered array indexed against full array) | `src/client/redux/sagas/common/saveEfforts.js:10-36` | Track original index before filtering |
| B9 | High | `removeFutureEfforts` may send `NaN` (`newPercent` unset on fetched future efforts) | `removeFutureEfforts.js:10-18` | `effort.newPercent ?? effort.percent ?? 0` |
| B10 | High | `takeLatest` lets a double-click cancel in-flight orchestration mid-write | `addPerson.js:165-167`, `deactivatePerson.js:136-138` | `takeLeading` + disable confirm while in progress |
| B11 | High | No in-flight loading guard on deactivate confirm — button stays clickable during multi-service calls | `containers/Common/NavButtons.jsx:38-50`, `selectors/common/getIsLoading.js:6-14` | Add `deactivateInProgress`/`addPersonInProgress` flags |
| B12 | High | `fetchDeactivateReasons` dispatches API error objects as the reason dropdown list | `sagas/deactivate/fetchDeactivateReasonsSaga.js:7-13` | Guard on `.error` |
| B13 | High | Lockdown UI can show stale unlocked state after partial backend failure (optimistic local state) | `containers/admin/LockdownContainer.jsx:30-47` | Re-fetch timeframe after any outcome |

## 2. Latency / performance

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| L1 | High | `fetchTimeframes` runs 3 independent GETs sequentially on every boot | `sagas/common/fetchTimeframes.js:22-24` | `yield all([...])` |
| L2 | High | N+1 team lookups per effort during add/deactivate | `sagas/common/fetchEffortForUser.js:14-25,87-88` | Batch team lookup / dedupe |
| L3 | High | Boot fetches entire active people list from costing | `sagas/common/fetchPeopleSaga.js:9-18` | Server-side search/pagination; lazy-load on deactivate route |
| L4 | Medium | QC + costing calls sequential though independent | `deactivatePerson.js:95-96` | Parallelize if business rules allow |
| L5 | Medium | Lockdown refetches timeframe on every toggle | `containers/admin/LockdownContainer.jsx:16-28` | Fetch once on mount |
| L6 | Medium | Health check re-fetched every timeframe selection, no cache | `sagas/common/fetchHealthCheck.js:7-17` | Cache by `timeFrameId` |

## 3. UI / UX (cluttered + not responsive)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| U1 | High | No responsive breakpoints on primary layout — stepper fixed 60%, table 80% width | `Deactivate/DeactivatePersonContainer.jsx:22-28`, `Activate/AddPersonContainer.jsx:19-25` | Stack vertically on mobile; `width:100%` |
| U2 | High | Cluttered two-column multi-step forms | `Deactivate/UpdateEfforts.jsx:25-45`, `Activate/AddPersonEfforts.jsx:29-70` | Single-column mobile layout; sticky nav footer |
| U3 | High | No progress feedback during multi-second orchestration (QC→costing→efforts) | `Deactivate/ConfirmDeactivate.jsx:17-25`, `Common/NavButtons.jsx:38-50` | Step progress indicator + disabled confirm |
| U4 | High | Loading blocker fixed 600px width breaks on mobile | `styles/components/_loadingblocker.scss:9-17` | `max-width:90vw` + centered transform |
| U5 | Medium | Results render below nav buttons — user must scroll to see outcome | `Deactivate/ConfirmDeactivate.jsx:23-24` | Render results above nav; auto-scroll |
| U6 | Medium | Ambiguous destructive-action label ("Okay") | `Common/NavButtons.jsx:42-50` | "Confirm Deactivation" + explicit cancel |
| U7 | Medium | Duplicate effort table implementations (drift risk) | `Common/EffortTable.jsx` vs `Activate/AddPersonEffortsTable.jsx:39` | Consolidate into one parameterized component |
| U8 | Low | Minimal accessibility coverage (no labels on selects, stepper not announced) | app-wide | ARIA labels, MUI `Tooltip` instead of custom balloons |

## Phased priority
- **P0**: B1–B6 (partial-failure consistency + broken error gate) — this is the foundation; fix before any UI polish.
- **P1**: B7–B13 (in-flight guards, progress UI), L1–L3 (parallel boot fetches).
- **P2**: U1–U4 (responsive + progress feedback), L4–L6.
- **P3**: U5–U8, remaining polish.
