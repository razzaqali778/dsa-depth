# eztrac-core-ui — Issues & Fix Plan

> React + Redux-Saga (Vite). The main **planning screen**: pick a team + month,
> edit Initiatives / People / Engagements. No DB of its own — every change is an
> API call to core-services, costing, and VIP.

Source: code-level audit [Analyze eztrac-core-ui](0502c2fd-58da-4265-9072-013648d10ff8).

---

## 1. Bugs (several risk silent data loss)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| B1 | Critical | Inverted `monthHasChanges` — unsaved-changes modal shows when **clean**, navigates away when **dirty** | `src/client/components-containers/initiatives/InitiativeTable.jsx:144-148,277-297` | Invert guard; rename to `hasUnsavedInitiatives` |
| B2 | Critical | People tab guard uses OR → navigate away with unsaved edits | `.../people/PeopleTab.jsx:60-66,145-165` | Use AND with corrected helpers |
| B3 | High | `hasPeopleDataChanged` returns true-when-**equal**, opposite of initiative validator (root of B1/B2) | `src/client/redux/utils/validatorsForPeople.js:3-44` | Rename + align semantics; unit tests |
| B4 | High | Profile hover error dispatches typo action `setUserProfileDetail` (never reaches reducer) | `.../sagas/fetchUserProfileDetailsSaga.js:14-18` | `setUserProfileDetails` |
| B5 | High | Saga deadlock: on fetch error `setPeople`/`setInitiatives` never dispatched → `take()` blocks forever | `sagas/people/fetchAllPeopleSaga.js:15-20`, `takes/getPeople.js:7-10` (+ initiatives) | Dispatch `[]`/error flag; race with timeout |
| B6 | High | Cancelled `fetchTeamData` (takeLatest) can leave global loading stuck | `sagas/fetchTeamDataSaga.js:13-47` | `try/finally` clears loading |
| B7 | High | Copy-forward fires N uncoordinated PATCH saves (last-write-wins, silent failures) | `sagas/initiatives/copyInitiativesForwardSaga.js:9-21` | Single multi-TF API / serialized saga |
| B8 | Medium | `updatePeople`/`updateInitiatives` use `takeEvery` → duplicate saves | `updatePeopleSaga.js:66`, `updateInitiativesSaga.js:64` | `takeLatest` + disable button while saving |
| B9 | Medium | Initiative monthly **cost** input editable when timeframe is read-only | `InitiativeTable.jsx:532-559` | Wrap in `allowEditing` |
| B10 | Medium | Duplicate React keys `key={person.personName}` | `PeopleTable.jsx:256` | `key={person.personId}` |
| B11 | Medium | `fetchTimeFrames` can crash at year boundaries (`undefined.id`) | `sagas/fetchTimeFramesSaga.js:30-46` | Clamp indices |

## 2. Latency / performance

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| L1 | Critical | Bulk team payload — **all active months** fetched on every team change + after every save | `sagas/fetchTeamDataSaga.js:18-24` | Fetch selected month (+adjacent for copy-forward); paginate |
| L2 | Critical | Full **global people list** (`GET /v1/people`) on every app load into every react-select | `handleLocationChange.js:44`, `fetchAllPeopleSaga.js:11-14` | Server-side typeahead `?q=&limit=50` |
| L3 | Critical | Full **allocable initiatives** catalog on load, no server search | `handleLocationChange.js:43`, `fetchInitiativesSaga.js:11-12` | Async searchable select hitting VIP |
| L4 | High | `InitiativeTableContainer` remounts every render via `key={uuid()}` | `initiatives/InitiativeTab.jsx:55` | Stable key (`selectedTimeFrameId`) |
| L5 | High | No list virtualization — all rows in DOM (initiatives/people/forecast/engagements) | `InitiativeTable.jsx:451-573`, `PeopleTable.jsx:255-329`, etc. | `@tanstack/react-virtual` |
| L6 | High | Startup waterfall of 10+ fetches, only `setTimeFrames` awaited | `handleLocationChange.js:36-47` | `yield all([...])`; `appReady` gate |
| L7 | Medium | Expensive selectors re-run; little `React.memo`; O(n²) filter spread | `getInitiativeSelectOptions.js`, `getFilteredEngagements.js:6-25` | Memoize; fix filter reducer |
| L8 | Medium | Global loading blocker serializes whole UI | `LoadingBlocker.jsx`, all sagas | Per-domain loading flags |
| L9 | Medium | Heavy lodash + duplicate select libs, no code splitting | `package.json:67-76`, `vite.config.js:15-18` | `lodash-es`, one select lib, `React.lazy`, `manualChunks` |

## 3. UI / UX (cluttered + not responsive)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| U1 | High | Fixed 90% page width, essentially no `@media` queries | `styles/containers/AppContainerStyles.css:48-52` | Mobile-first `100%` + breakpoints |
| U2 | High | Tables `min-width:40vw`, chart `max-width:35vw`, side-by-side → horizontal overflow | `InitiativeContainer.scss:58,72-76`, `PeopleContainer.scss:47-51` | Stack under 1024px; `overflow-x:auto` |
| U3 | High | Engagement cards fixed 48% width, dense | `styles/containers/EngagementContainer.css:72-78` | Single column < 900px; overflow menu |
| U4 | Medium | Unsaved-data modal is informational only (no Save/Discard) | `teams/UnsavedDataModal.jsx:4-42` | Add Save + Discard actions |
| U5 | Medium | Missing empty/error states on main tables; stale team data kept on fetch error | `InitiativeTable.jsx`, `PeopleTable.jsx`, `fetchTeamDataSaga.js:28` | Empty-state rows; clear slice; inline retry |
| U6 | Medium | A11y gaps (`<a onClick>` no href, unlabeled inputs, hover-only profile) | `FilterButton.jsx:7`, `EngagementTab.jsx:46-53`, `PeopleTable.jsx:258-276` | Use `<button>`, labels, focusable popovers |
| U7 | Medium | Dense initiative rows (3 header rows, many icons/cell) | `InitiativeTable.jsx:417-448` | Single toolbar; metadata in drawer; sticky headers |
| U8 | Low | Month controls duplicated between People and Initiatives tabs | `PeopleTab.jsx` vs `InitiativeTable.jsx` | Shared `MonthNavigator` |

## Phased priority
- **P0** (data-loss bugs): B1, B2, B3, B4, B5.
- **P1** (scale): L1, L2, L3, L4, L5.
- **P2** (reliability): B6, B7, B8, L6, L8.
- **P3** (responsive/UX): U1, U2, U3, U4, U6.
- **P4** (polish): L9, U7, U8, bundle splitting.
