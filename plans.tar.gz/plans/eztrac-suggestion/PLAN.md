# eztrac-suggestion — Issues & Fix Plan

> Express API (port **3600**). Trains two `decision-tree` models on existing
> people (costing + Profile attributes) to predict a new person's **cost group**
> and **rate**. Used by cron (bulk) and the add-person workflow (single).

Source: code-level audit [Analyze eztrac-suggestion](b25d5494-e153-4ed8-8b2f-80661a40f1d0).

**Core problem:** the merged training data is cached (24h), but the **trained
models are not** — every request retrains two trees synchronously on the event
loop, and a cold/expired cache triggers a full dataset rebuild on the request path.

---

## 1. Bugs

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| B1 | Critical | Decision trees retrained on **every** request | `src/services/decisionTree.js:87-98` | Pre-train in `updateCache`; cache `{costTree,rateTree,trainedAt}`; request = predict only |
| B2 | High | Non-deterministic predictions (random shuffle per request) | `decisionTree.js:64-66,91` | Seeded/deterministic split; cache trees |
| B3 | High | In-place `sort()` mutates the **cached** training array | `decisionTree.js:65,90-91` | Copy before shuffle; stop shuffling on request path |
| B4 | High | Profile batch slice overlap (`end+1`) → duplicate IDs | `src/services/getPeople.js:30-33` | `slice(start, Math.min(start+thresh, len))` |
| B5 | High | GraphQL query omits `businessArea` + `company` → features always `'missing'` | `getPeople.js:11-17` used at `decisionTree.js:71-77` | Add fields to query |
| B6 | High | `assign` overwrites costing attrs with Profile `'missing'` | `decisionTree.js:29-30` | Merge only present values (`pickBy`) |
| B7 | Medium | Unknown-label filter uses OR → polluted trees | `decisionTree.js:31-34` | Keep only `cg!==Unknown && rate!==Unknown`; use `filter` |
| B8 | Medium | Error fallback uses `person.personId` but callers pass raw strings → `id: undefined` | `decisionTree.js:107-110`, `src/v1/people/index.js:21` | Handle string vs object |
| B9 | Medium | `getPapiData` catch returns `err` (not array); agent resolves errors instead of rejecting | `getPeople.js:63-66`, `src/util/agent.js:23-28` | Return `[]`/throw; reject on non-2xx |

## 2. Latency / scale

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| L1 | Critical | Synchronous ML training blocks event loop every request | `decisionTree.js:80-84,93-97` | Pre-train in job / worker thread |
| L2 | Critical | Cold/TTL-miss rebuilds full dataset on request path | `decisionTree.js:37-47` | Never build on request; 503 + `Retry-After`; warm at startup |
| L3 | Critical | Thundering herd — no singleflight on cache rebuild | `decisionTree.js:37-47,50-54` | Shared in-flight `rebuildPromise` |
| L4 | High | Unbounded parallel Profile GraphQL batches | `getPeople.js:30-39` | Concurrency limit + retry/backoff |
| L5 | High | No upstream HTTP timeouts | `src/util/agent.js:33-46` | `.timeout({response:30000,deadline:60000})` |
| L6 | Medium | O(n²) merge (`find` in `map`) | `decisionTree.js:29-30` | `keyBy` → O(n) |

## 3. Robustness

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| R1 | Critical | Empty cache + no stale fallback → long hangs / failures if nightly cron fails | `decisionTree.js:37-47,87-90` | Keep `lastGood` snapshot; `/health` with readiness; alert on cron fail |
| R2 | High | Slow Profile degrades all in-flight suggestions | `getPeople.js:39`, `decisionTree.js:89` | Timeouts + circuit breaker; degraded mode |
| R3 | Medium | Routes lack input validation / error handling | `src/v1/people/index.js:12-23` | Validate non-empty ID array + try/catch |
| R4 | Low | Startup `onStartBuild` runs full pipeline on boot vs hardcoded IDs | `src/server.js:26-32` | Gate to dev only |

## Phased priority
- **P0** (stop request-path meltdown): B1, L1, L2, L3, R1 — cache trained trees + singleflight + readiness 503.
- **P1** (data correctness): B4, B5, B6, B7.
- **P2** (resilience): B9, L5, R2, R3.
- **P3** (scale): L4, L6, R4.

Positives already present: nightly warm endpoint `/v1/people/updateCache`, batched Profile fetches, singleton OAuth token cache.
