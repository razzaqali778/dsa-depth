# eztrac-qc — Issues & Fix Plan

> Full app: Express (`Services/` + `routes/`) + React (`public/scripts/`), pg,
> GraphQL, QC DB. Finds bad data: participation QC (<95% / >100%), initiative QC
> (funded % ≠ 100%), placeholder QC. Managers attach reasons; cron emails
> managers; lockdown archives a snapshot. (Note: this repo has no `src/`.)

Source: code-level audit [Analyze eztrac-qc](4fe00ec9-21fa-4c23-8247-20c2de40315c).

---

## Backend

### 1. Bugs
| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| B1 | Critical | **SQL injection** — string-interpolated `deactivatable` | `Services/dao/discrepancyReasonDao.js:16-18` | `WHERE deactivatable = $1` |
| B2 | Critical | **GraphQL injection** — raw person IDs in query string | `Services/Util/fetchPapiMaps.js:47-48` | GraphQL variables / sanitize IDs |
| B3 | High | Cron emails fire-and-forget (no await, errors swallowed) → managers not notified | `Services/Util/MessageUtil.js:53-58` | `await Promise.all`; log/rethrow |
| B4 | High | Undefined effort percent treated as **100%** → under-allocation missed | `Services/Util/findParticipationIssues/findParticipationIssues.js:10-14,37` | Treat undefined as 0 / flag |
| B5 | High | Initiative funded % uses strict float equality `=== 100` → false pos/neg | `Services/Util/findInitiativeIssues/findIssues.js:20-25` | `Math.abs(sum-100) > 0.01` |
| B6 | High | Missing initiative guard → runtime crash on orphan allocations | `findInitiativeIssues/findIssues.js:21-32` | Null-check / flag unknown |
| B7 | High | Inactive-people endpoint always returns `[]` (positional args vs options object) | `Services/Util/PeopleUtil.js:91-95` | Pass single options object |
| B8 | Medium | `uniqBy` key `userId||userId` is a no-op | `.../combineParticipationDiscrepancies.js:38-39` | `(userId||personId||'').toUpperCase()` |
| B9 | Medium | Subordinate % math: `Math.round(ratio)*100` ≈ always 0 | `Services/Util/RateUtil.js:79` | `Math.round(ratio*100)` |
| B10 | Medium | Check-then-act upsert race on discrepancy reason | `Services/PeopleQCService.js:40-47` | `INSERT ... ON CONFLICT DO UPDATE` |
| B11 | Medium | GraphQL batch overlap (`end+1`) duplicates IDs | `fetchPapiMaps.js:26-29` | `slice(start, start+thresh)` |

### 2. Latency / scale
| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| L1 | Critical | **Full QC recompute on every request** — all people + 2 full effort payloads + all timeframes + maps, in memory | `PeopleQCService.js:16-20`, `combineParticipationDiscrepancies.js:15-61`, `RateQCService.js:14-15` | Materialized QC snapshot per timeframe; endpoints read snapshot |
| L2 | High | Fetches entire team catalog for a subset of IDs | `Services/Util/fetchTeamMap.js:6-22` | Batch `?ids=` / cache |
| L3 | High | Manager-map rebuild loads all people + GraphQL for everyone | `Services/Util/ManagerMapCache.js:15-24,79-82` | Persist map; delta sync |
| L4 | High | No OAuth token caching (new token per upstream call) | `Services/Util/AzureTokenUtil.js:4-8` | Cache until `expires_in` |
| L5 | High | Unbounded API responses (no pagination) | `routes/V1Services.js:20`, `PeopleQCService.js:77-81` | Server-side pagination + filters |
| L6 | Medium | DB pool untuned (default max 10, no timeouts), connect-per-query | `Services/db/db.js:7-32`, `config/files/default.js:36-43` | Tune pool; `pool.query`; add indexes on discrepancy table |
| L7 | Medium | Sequential awaits where parallel possible | `.../fetchDataForDiscrepancies.js:55-59` | `Promise.all` |
| L8 | Medium | Archive stores unbounded JSON blob (TOAST) | `ArchivedDataUtil.js:10-12`, `dao/archivedDataDao.js:5-7` | Normalize/compress/partition |

## Frontend

### 1. Bugs
| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| F1 | High | Missing `searchForUnderUser` handler → runtime error | `public/scripts/components/People.jsx:349`, `ShowUnderManagerModal.jsx:26` | Remove/ wire button |
| F2 | High | Reason save sends malformed `isActive` (`{currentDiscrepancy}` object) | `public/scripts/Util/Network/reasonUtil.js:68-75` | `isActive: currentDiscrepancy.isActive` |
| F3 | High | Lockdown defaults to **locked** when TF missing from map | `components/table/cells/ModalCell.jsx:26` | Default `false` |
| F4 | High | Initiative/placeholder UI crash on `.find(...).name` (missing team/rate/costGroup) | `InitiativeQC.jsx:249,256`, `ForecastPeopleQC.jsx:36-40` | Optional chaining + fallback |
| F5 | Medium | Mount error leaves spinner forever (no `loading:false`) | `People.jsx:235-238` | Clear in `finally` |

### 2. Latency
| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| FL1 | High | Full discrepancy list in state; client filter scans all fields; O(n²) manager hierarchy | `People.jsx:120-132`, `Util/tableFilterUtil.js:30-37` | Server-side filters; memoize hierarchy |
| FL2 | High | Cost calc toggle triggers full backend QC recompute | `People.jsx:113-117` → `RateQCService.js:15` | Derive client-side / lightweight endpoint |
| FL3 | Medium | Placeholder "Full Year" fires N parallel requests, no grid paging | `ForecastPeopleQC.jsx:98-117` | Aggregated endpoint + `paginationMode="server"` |
| FL4 | Medium | Async IIFE in `useEffect` — stale response races | `ForecastPeopleQC.jsx:60-135` | AbortController / request id |

### 3. UI / UX (cluttered + not responsive)
| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| U1 | High | Fixed **1170px** layout — not responsive | `public/styles/style.less:8-12,206-212` | Flex/grid, `max-width:100%`, stack < 768px |
| U2 | High | Dense participation table, hidden horizontal scrollbar clips content | `people/PeopleQCTable.jsx:80-87`, `style.less:218-220` | Expandable row detail / card layout |
| U3 | Medium | Mixed UI stacks (Bootstrap 3 + MUI DataGrid + react-virtualized) → cluttered | across components | Standardize one table system + tokens |
| U4 | Medium | Missing a11y labels on search/sort; modal focus gaps | `SearchComponent.jsx:37-44`, `InitiativeQC.jsx:228-233`, `ModalCell.jsx:34-60` | Labels, `aria-label`, focus trap |
| U5 | Medium | Incomplete loading/empty/error states | `InitiativeQC.jsx`, `ForecastPeopleQCTable.jsx`, `reasonUtil.js:27-28` | Empty panels + error banners |

## Phased priority
- **P0**: B1, B2 (injection); L1 (materialized QC + pagination); B3 (manager emails).
- **P1**: QC math (B4, B5, B9); frontend crashes (F1–F4); B7.
- **P2**: responsive + a11y + unified tables (U1–U5); caching (L2, L3, L4).
