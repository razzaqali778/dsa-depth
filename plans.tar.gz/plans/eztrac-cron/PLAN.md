# eztrac-cron — Issues & Fix Plan

> Node app (port **3020**). Nightly jobs (America/Chicago) posting to MS Teams:
> Recost @00:00, Sync people @00:01, Update suggestion cache @00:02, Rebuild VIP
> search @00:00.

Source: code-level audit [Analyze eztrac-cron](e3e517ad-6247-4ff0-b3d8-2f5c40e661b8).

**Cross-cutting root cause:** `src/util/agent.js` **resolves** failed HTTP calls
(returns `{error}`) instead of rejecting. So `try/catch` never fires, and
failures look like success or empty results — the source of several Critical bugs
below. Fix the agent to be the single throw/retry/timeout boundary, and add a
`runJob(name, fn)` wrapper that handles locking, timing, and success/failure
Teams alerts.

---

## 1. Bugs

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| B1 | Critical | Recost reports **false success** — agent swallows error, `reduce(undefined)` → "0 rows" | `src/util/agent.js:23-28`, `src/cron/recost.js:9-15` | Reject in agent / guard `if(result.error) throw`; no success Teams on error |
| B2 | Critical | Costing `/people` failure treated as **"everyone missing"** → mass sync/PUT/tasks | `src/cron/syncPeople.js:81-90,142-143` | Check `results.error`, abort job + alert; distinguish empty vs failure |
| B3 | Critical | Suggestion failure → PUTs people **without** costGroup/rate | `syncPeople.js:126-136,154-159` | Validate `response.error`; require suggestions before any PUT |
| B4 | High | Review tasks fire-and-forget (`sendTask` not awaited) | `syncPeople.js:106-119` | `await Promise.all(...)`; check both results |
| B5 | High | No overlap lock — slow job double-fires | `server.js:32-58,77-80` | Per-job `isRunning` flag / distributed lock |
| B6 | High | Startup runs all jobs immediately + wrong order vs cron (cache before sync) | `server.js:60-64,77-82` | Gate behind `RUN_JOBS_ON_STARTUP`; mirror cron order |
| B7 | High | Unhandled promise rejections; no global handler | `server.js:14-30,55,82` | try/catch + `unhandledRejection`/`uncaughtException` |
| B8 | High | Tick wrappers Teams-alert **success even on failure** (undefined counts) | `server.js:14-29` | Branch on error field |
| B9 | High | Partial PUT failures invisible in sync (Promise.all masks `{error}`) | `syncPeople.js:106-123,159-161` | Inspect each result; report failed personIds |
| B10 | Medium | Recost + VIP rebuild collide at midnight | `server.js:32-37,53-57` | Stagger VIP (e.g. 01:30) |
| B11 | Medium | PAPI count-vs-fetch pagination race drops/duplicates people | `syncPeople.js:19-24,36-45` | Page until short page / cursor pagination |

## 2. Latency / scale

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| L1 | High | Unbounded parallel PUTs for all missing people | `syncPeople.js:106-121` | `p-limit(10)` / chunk 50 |
| L2 | High | Single POST of entire missing-ID list to suggestions | `syncPeople.js:128,151-152` | Chunk 100–200 |
| L3 | High | No pagination loading costing people | `syncPeople.js:83` | Paginated costing API |
| L4 | High | No HTTP timeouts or retries on any call | `src/util/agent.js:37,45` | `.timeout(...)` + backoff retries |
| L5 | Medium | Unbounded parallel GraphQL page fetches per org | `syncPeople.js:38-45` | Limit concurrency |
| L6 | Medium | Long recost/VIP GETs have no client deadline | `recost.js:10`, `rebuildVIPElastic.js:8` | Timeout / async job polling |

## 3. Observability / robustness

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| O1 | High | Failures not alerted to Teams — only successes | all cron modules; `logger.teams` only in success paths | `logger.teamsFailure(job,err,ctx)` in every catch |
| O2 | High | No retries anywhere | all modules + agent | Central retry wrapper for idempotent ops |
| O3 | Medium | No idempotency/dedup on sync (startup+cron / overlap re-PUTs) | `syncPeople.js:138-167` | Track last-run; skip already-synced |
| O4 | Medium | `/ping` exposes no job status | `server.js:66-68` | `/health` with per-job lastRun/status/duration |
| O5 | Medium | Datadog disabled | `fg-deploy-overrides.json:8-9` | Enable + custom job metrics |
| O6 | Medium | No graceful shutdown — deploy kills mid-sync | `server.js:70-82`, `bin/www` | `SIGTERM` drain |

## Phased priority
- **P0** (data-integrity): B1, B2, B3, B8, O1 — refactor `agent.js` first.
- **P1**: B4–B7, B9, L1–L4, O2, O6.
- **P2** (scale): L2, L3, L5, L6, B10, B11, O3–O5.
