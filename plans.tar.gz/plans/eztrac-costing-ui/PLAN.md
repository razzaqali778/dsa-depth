# eztrac-costing-ui — Issues & Fix Plan

> React + Redux-Saga (Webpack). Admin screen to manage **people, rates, cost
> groups, engagements**, with CSV/XLSX export and an audit view.

Source: code-level audit [Analyze eztrac-costing-ui](43160ebf-4480-4dc6-b98b-fb1058b8f978).

---

## 1. Bugs

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| B1 | Critical | Global loading flag reset by **every** action (`default: return false`) → unreliable spinners/disabled flows | `src/client/redux/reducers/asyncReducer.js:6-10` | `default: return state` |
| B2 | Critical | GraphQL injection in people search (raw `searchText` interpolated) | `sagas/getPapiPeopleSaga.js:16-20` | Use GraphQL variables |
| B3 | High | Engagement ID rendered through cost-group lookup (wrong label) | `components/engagements/EngagementItem.jsx:59-62` | Render `engagement.id` |
| B4 | High | Cost group / engagement edit loading wired to wrong Redux slice → no feedback | `CostGroupContainer.jsx:180`+`putCostGroupSaga.js`, `EngagementsContainer.jsx:134`+`putEngagementSaga.js` | Consolidate on `async.isUpdating` |
| B5 | High | Redux state mutation on add rate (`state.push`) | `reducers/ratesReducer.js:27-30` | `return [...state, payload]` |
| B6 | High | Person fetch saga can hang forever on blocking `take()` if prereq fails | `sagas/getPersonDataSaga.js:14-20` | Dispatch prereqs / race with timeout |
| B7 | High | Clearing person search passes `null` → saga reads `payload.value` unguarded | `PeopleContainer.jsx:64-68`, `getPersonDataSaga.js:13-24` | Guard on clear |
| B8 | Medium | Debounce recreated every render (ineffective) | `PeopleContainer.jsx:69` | `useMemo`/module-level |
| B9 | Medium | Missing React keys in audit list | `AuditContainer.jsx:13-14`, `AuditItem.jsx:10-11` | `key={audit.id}` |
| B10 | Medium | Crash filtering engagements with null PO (`.toLowerCase()`) | `selectors/getFilteredEngagements.js:14` | `(po||'').toLowerCase()` |
| B11 | Medium | Uncontrolled toggles via `defaultChecked` show stale state | `EditPerson.jsx:49-51`, `EditRateItem.jsx:117-119` | Controlled `checked` |

## 2. Latency / performance

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| L1 | Critical | Full datasets loaded, **no pagination** (rates/costGroups/engagements/audits/people) | `getAll*Saga.js` | Server-side pagination |
| L2 | Critical | Full-list DOM render — **no virtualization** | `RatesContainer.jsx:51-61`, `CostGroupContainer.jsx:84-93`, etc. | `react-window` |
| L3 | High | Bulk export fetches all active people client-side + PapaParse in browser | `getAllPeopleSaga.js:11-31`, `downloadPeopleDataSaga.js:8-25` | Server-generated CSV/stream |
| L4 | High | Search dispatches on every keystroke (no debounce) | `RatesContainer.jsx:141-145`, etc. | Debounce 300ms |
| L5 | High | Sort/filter recomputed in render path | `RatesContainer.jsx:48-52`, etc. | Move to Reselect + memo |
| L6 | High | Audit search runs `moment().format()` per row per keystroke | `selectors/getFilteredAudits.js:17-20` | Precompute searchable string; debounce |
| L7 | Medium | Per-item `connect()` → cascade re-renders | `RateItem.jsx:127-133`, etc. | `React.memo`, lift edit state |
| L8 | Medium | Index-based list keys force reconciliation | `RatesContainer.jsx:56`, etc. | Use entity id |
| L9 | Medium | Refetch on every route enter, no cache/TTL | `routes/index.jsx:22-57` | Skip if fresh (SWR) |

## 3. UI / UX (cluttered + not responsive)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| U1 | High | **No responsive breakpoints anywhere** (zero `@media` in SCSS) | `src/client/styles/` | Add responsive grid + breakpoints |
| U2 | High | Bootstrap `col-md-*` used without `.row` → overflow/misalignment | `RatesContainer.jsx:136-147`, etc. | Wrap in `.row`; flex-wrap |
| U3 | High | Missing loading states on initial page load (blank lists) | Rates/CostGroup/Audit/People containers | Skeleton/spinner per slice |
| U4 | Medium | Fixed-height modals clip large people lists (250/110/75px) | `styles/utils/filterBar.scss:31-34`, etc. | `max-height:70vh` + flex |
| U5 | Medium | Missing empty states on zero results | container render tails | "No results" component |
| U6 | Medium | Cluttered rows (many actions + metadata per item) | `RateItem.jsx:74-92`, `CostGroupItem.jsx:45-62` | Expandable detail / kebab menu / table |
| U7 | Medium | Audit view `<pre><ul>` in cells, poor readability | `AuditContainer.jsx:29-39`, `AuditItem.jsx:29-35` | Collapsible JSON viewer |
| U8 | Medium | Icon-only buttons lack accessible labels | `RatesContainer.jsx:74-80`, `SaveToXlsxButton.jsx:23-30` | `aria-label` |
| U9 | Low | Invalid CSS `display:'inline'` (quoted) | `styles/containers/auditContainer.scss:1-3` | `display:inline` |

## Phased priority
- **P0** (correctness/security): B1, B2, B3, B5.
- **P1** (scale): L1, L2, L3, L4.
- **P2** (UX foundation): U1, U2, U3, U5.
- **P3** (polish): B8, L7, L8, U6, U7.
