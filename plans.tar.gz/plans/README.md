# EzTrac — Master Remediation Plan (Bugs, Latency, UI)

> One folder per repo, each with a `PLAN.md` (and deeper phase docs where the
> audit was extensive). Every finding cites exact `file:line` so a fix can be
> implemented directly — nothing here is guesswork.
>
> **For how the system works end-to-end, see** [`../EZTRAC_OVERVIEW.md`](../EZTRAC_OVERVIEW.md).

## Why the app "feels slow" and "can't get data" with millions of rows

Three patterns repeat across almost every backend in this system:

1. **Full-table loads on every request** instead of scoped queries — reference
   data (rates, cost groups, people, initiatives) and even transactional data
   get re-fetched in full, every time, with no caching.
2. **O(N²) in-memory joins** — `.find()` inside `.map()`/loops instead of
   building a `Map` once (VIP's inheritance resolution, reporting's
   `EffortSpendingMap`, core-services' effort hydration, costing's cost-calc
   generators, suggestion's people merge).
3. **No pagination, no indexes on hot filter columns, unsized DB pools, no
   HTTP timeouts** — so once row counts climb into the millions, a handful of
   concurrent slow requests exhausts the pool and everything queues.

None of this requires an architecture rewrite — every plan below is a set of
local, incremental, independently-shippable fixes.

## Why the UI "feels cluttered and not responsive"

Every React app in this system (`core-ui`, `costing-ui`, `qc`, `reporting`,
`workflows`) shares the same three UI gaps: **no responsive breakpoints**
(fixed-width layouts, `vw`-based min-widths, side-by-side panels that overflow
on anything narrower than a desktop), **no list virtualization** (full
datasets rendered as DOM rows), and **missing loading/empty/error states**
(blank screens while slow requests run). Each repo's plan has a dedicated UI
section with concrete fixes.

---

## Per-repo plans

| Repo | Role | Plan |
|---|---|---|
| [`eztrac-core-services`](./eztrac-core-services/PLAN.md) | System of record: teams, efforts, spend | Recost data-loss bug, N+1 health check, unbounded reads, missing indexes |
| [`eztrac-core-ui`](./eztrac-core-ui/PLAN.md) | Planning screen (Initiatives/People/Engagements) | **Inverted unsaved-changes guards** (data loss risk), full-catalog loads, no virtualization |
| [`eztrac-costing-services`](./eztrac-costing-services/PLAN.md) | Cost engine (rates, cost groups, people) | Full-table loads on every cost-calc, no auth on hot endpoint, O(n²) generators |
| [`eztrac-costing-ui`](./eztrac-costing-ui/PLAN.md) | Admin: people/rates/cost groups/engagements | Broken loading reducer, GraphQL injection, no pagination/virtualization |
| [`eztrac-vip`](./eztrac-vip/README.md) | Initiative portfolio & budgets | Connection-pool bug (critical, global), O(N²) inheritance/tree build, N+1 lineage |
| [`eztrac-reporting-services`](./eztrac-reporting-services/PLAN.md) | Join layer for spending reports | Operator-precedence $ bug, 7× token fetch, O(n²) join, stale-cache risk |
| [`eztrac-reporting`](./eztrac-reporting/PLAN.md) | Reporting UI (grids, trends, exports) | localForage race + stale cache, needs server paging/virtualization |
| [`eztrac-qc`](./eztrac-qc/PLAN.md) | Data-quality checks | **SQL injection**, full QC recompute every request, several frontend crash bugs |
| [`eztrac-workflows`](./eztrac-workflows/PLAN.md) | Add/deactivate person, admin actions | **No rollback/compensation** on partial cross-service failure; broken error gate |
| [`eztrac-suggestion`](./eztrac-suggestion/PLAN.md) | ML rate/cost-group guesser | Retrains models on every request (no model cache), thundering herd on cold cache |
| [`eztrac-cron`](./eztrac-cron/PLAN.md) | Nightly automation | HTTP-error swallowing → **false-success recost & mass false-positive syncs** |
| [`eztrac-team-overview`](./eztrac-team-overview/PLAN.md) | Python desktop reporting tool | ~840 sequential HTTP calls (fake async), several crash bugs |

---

## Cross-cutting Critical/Highest-risk items (fix first, across all repos)

These are the items most likely to cause **wrong numbers, data loss, or full
outages** — prioritize them ahead of pure latency work:

| Repo | Issue |
|---|---|
| eztrac-core-services | Partial recost leaves **stale breakdowns** for efforts that should go to zero cost |
| eztrac-core-ui | Inverted unsaved-changes guards — users can **navigate away and silently lose edits** |
| eztrac-costing-services | Person upsert is DELETE+INSERT with no transaction — a failed insert **deletes the person** |
| eztrac-qc | SQL injection in reason lookup; GraphQL injection in manager-map fetch |
| eztrac-workflows | No rollback across add/deactivate-person multi-service writes; deactivate error handler **never fires** (always-truthy check) |
| eztrac-cron | HTTP agent swallows errors → recost reports false success; a failed costing/people fetch is treated as "everyone missing" and mass-syncs |
| eztrac-vip | Connection-pool release bug (`.finally(client.release())` calls immediately) — stalls under any concurrency |
| eztrac-reporting-services | Operator-precedence bug silently **under-reports expenditure** when any child total is undefined |
| eztrac-suggestion | Decision trees retrained synchronously on every request; cold cache = full rebuild on the request path |

## Cross-cutting latency levers (the "millions of rows" fix)

1. **Cache reference data** (rates, cost groups, people, initiatives, teams,
   timeframes) with TTL + explicit invalidation — every backend re-fetches full
   tables today.
2. **Replace `.find()`-in-loop with `Map` lookups** everywhere — this alone
   converts several O(N²)/O(N·M) endpoints to O(N).
3. **Add the missing indexes** listed in each plan (mostly `parent_id` /
   `*_id` foreign-key columns used in filters and joins).
4. **Paginate every "get all" endpoint** and stop the UIs from loading full
   catalogs into `react-select` — server-side search instead.
5. **Right-size DB pools + add `statement_timeout` + HTTP timeouts** on all
   outbound calls — several services currently have no timeout at all, so one
   slow dependency can hang everything behind it.
6. **Core's precomputed `team_cost_spend` ledger** (see the
   [spending plan](./eztrac-reporting-services/SPENDING_ZERO_LATENCY_FRESH_DATA_PLAN.md))
   is the strategic fix for reporting: version/event-based cache instead of
   time-based, so reports are fast *and* never stale.

## Cross-cutting UI levers (the "cluttered / not responsive" fix)

1. Add real responsive breakpoints (`@media` queries) — several stylesheets
   have **zero** media queries today.
2. Virtualize every large list/table (`react-window` / `@tanstack/react-virtual`)
   instead of rendering full arrays as DOM rows.
3. Debounce every search input correctly (several are either missing debounce
   or recreate the debounced function on every render, which defeats it).
4. Add consistent loading / empty / error states — several screens show a
   blank list while a slow request is in flight, which reads as "broken."
5. Fix accessibility basics: labeled inputs, `aria-label` on icon-only buttons,
   focus handling in modals.

---

## Suggested execution order across the whole system

1. **Stop the bleeding (data integrity):** core-services recost bug,
   costing-services person-upsert transaction, qc injection fixes, workflows
   rollback/error-gate fixes, cron agent error-swallowing fix, core-ui unsaved
   guards, reporting-services operator-precedence bug.
2. **Unblock latency at the source:** VIP pool bug, DB indexes across all
   services, HTTP/DB timeouts everywhere, reference-data caching.
3. **Kill the quadratic algorithms:** VIP inheritance/tree, reporting's
   EffortSpendingMap, costing's cost-calc generators, core-services' effort
   hydration, suggestion's people merge — all via `Map`-based rewrites.
4. **Pagination + virtualization:** every "get all" API and every large UI list.
5. **UI responsiveness pass:** breakpoints, loading/empty states, a11y —
   repo by repo, using each `PLAN.md`'s UI section.
6. **Verification:** load-test the hottest endpoints (listed in each plan),
   confirm p95/p99 improvement, and confirm no data-freshness regressions.

Each per-repo `PLAN.md` has its own phased priority (P0/P1/P2/P3) — use those
for the detailed backlog once a repo is picked up.
