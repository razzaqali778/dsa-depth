# eztrac-reporting (UI) — Issues & Fix Plan

> React + Redux-Saga + DevExpress grids + d3. Pick a timeframe range, drill the
> initiative tree, filter by team/cost group/tag/person, view Results / Trend /
> Initiative List, save named reports, export CSV.

Most of the reporting latency root-cause lives on the **service** side — see
[`../eztrac-reporting-services/`](../eztrac-reporting-services/PLAN.md) and the
[spending ledger plan](../eztrac-reporting-services/SPENDING_ZERO_LATENCY_FRESH_DATA_PLAN.md).
This file tracks the **UI-specific** issues.

## Bugs

- **localForage race condition** — `src/client/redux/sagas/retrieveStoredDataSaga.js`.
  Rapid timeframe changes can read stale/empty data and overwrite good cache;
  `setItem` is fire-and-forget (not awaited). Fix: `takeLatest` + small debounce +
  `yield call([localForage,'setItem'], …)` (await writes). Detail:
  [`../eztrac-reporting-services/phase-1-quick-wins/BUGS.md`](../eztrac-reporting-services/phase-1-quick-wins/BUGS.md) (Bug #2).
- **Stale UI cache, no invalidation** — same saga. Cached spending trees keyed by
  timeframe range only clear on manual "Refresh". Fix: TTL or
  stale-while-revalidate, ideally ETag/version from the service (Bug #5).

## Latency / performance
- Large DevExpress grids should use **virtual/infinite scrolling + server paging**
  rather than loading the full spend tree client-side (millions of rows upstream).
- Debounce filter/search inputs; memoize derived grid rows; avoid recomputing d3
  trend data on every render.
- Rely on the service-side version cache so repeat clicks are instant.

## UI / UX (cluttered + not responsive)
- DevExpress grids and the initiative tree are dense and fixed-width; add
  responsive breakpoints, column show/hide, and a compact/comfortable density
  toggle.
- Ensure clear loading / empty / error states on every tab (Results / Trend /
  Initiative List) instead of blank grids while the slow request runs.

> Note: the detailed phase docs in `../eztrac-reporting-services/phase-*`
> intentionally cover both the UI and the service since they share the request path.
