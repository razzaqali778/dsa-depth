# Phase 4 — Verification, Benchmarking & Monitoring

Goal: prove the latency wins, catch regressions, and get ongoing visibility. Some of
this should be set up *before* Phase 1 so we have a baseline.

## 4.1 Establish a baseline (do this first)

Capture current latency for the heavy endpoints so improvements are measurable:

- `GET /ez-trac-vip/services/v1/getAllInitiatives`
- `GET /ez-trac-vip/services/v1/getAllInitiatives/heatmapPatch`
- `GET /ez-trac-vip/services/v1/getAllInitiatives/fundingInitiativeView`
- `GET /ez-trac-vip/services/v2/initiatives?fields=...,tags`
- `GET /ez-trac-vip/services/v2/initiatives/tree`
- `GET /ez-trac-vip/services/v1/getInitiativeHierarchy`
- `GET /ez-trac-vip/services/v1/getInitiativeLineage/:id`
- `GET /ez-trac-vip/services/v1/getBudgetsByInitiative/:id`

Record p50/p95/p99 at a fixed concurrency against a dataset that resembles prod
size (or a scaled synthetic set — see 4.3).

## 4.2 Load-test harness

Use a simple, repeatable tool (`autocannon`, `k6`, or `hey`). Example with
`autocannon`:

```bash
npx autocannon -c 50 -d 30 \
  "http://localhost:3300/ez-trac-vip/services/v1/getAllInitiatives"
```

Run the same command before/after each phase and diff p95/p99 + throughput.
Keep results in this folder (e.g. `bench/` with dated JSON) for traceability.

## 4.3 Representative dataset for algorithmic wins

The O(N²) fixes (Phase 3) only show up at scale. Seed a synthetic dataset (e.g.
5k / 10k / 20k initiatives with realistic parent depth, tags, and budgets) in a
test/staging DB and benchmark the transforms directly (unit-level timing) plus the
endpoints (HTTP-level).

## 4.4 Per-request instrumentation

- Add lightweight timing around the DB layer and the heavy transforms (log slow
  requests above a threshold with route + duration + row counts). `loggerMiddleware`
  already exists (`loggerMiddleware.js`) — extend it or add a timing wrapper.
- Log pool stats periodically (`pool.totalCount`, `idleCount`, `waitingCount`) to
  confirm Phase 1 sizing is right and no requests are waiting on connections.

## 4.5 Database-side observability

- Enable/inspect `pg_stat_statements` to find the true top-cost queries in each env.
- Periodically review `EXPLAIN (ANALYZE, BUFFERS)` on the hot queries after Phase 2
  indexes land.

## 4.6 Regression guardrails

- Add the characterization tests from Phase 3 to CI so refactors can't silently
  change output.
- Add a couple of "budget" assertions where practical (e.g. a transform on a fixed
  synthetic dataset must complete under a time bound) to catch reintroduced
  quadratic behavior.

## 4.7 Success metrics

| Endpoint class | Metric | Target |
| --- | --- | --- |
| Heavy list/heatmap/funding | p95 latency | Large reduction vs. baseline; scales ~linearly with N |
| Tree / hierarchy | p95 latency | Large reduction; no event-loop stalls |
| Lineage / budgets-by-initiative | round-trips | 1 DB query (or batched) per request |
| All routes under load | pool `waitingCount` | ~0 at target concurrency |
| Reference data | source | Served from cache within TTL |

## Rollout & safety

- Ship phase-by-phase behind normal review; each phase is independently revertable.
- Phase 2 index creation: use `CREATE INDEX CONCURRENTLY` in prod.
- Phase 3 refactors: land behind characterization tests; if any output diff appears,
  stop and reconcile before merging.
- Keep the `NODE_ENV === 'test'` DB noop path intact so unit tests don't hit a real
  DB.
