# VIP Service — Latency Findings (Root-Cause Analysis)

This is the evidence base for the phased plan. Findings are ordered by impact.
Line references are against the current state of the `feature/node-and-package-upgrade`
branch.

## Route inventory (what "all routes" means)

**v1** (`services/v1/index.js`, mounted at `/ez-trac-vip/services/v1`):
`referenceData/initiativeStatus`, `referenceData/financialTagTypes`,
`initiativeTypes`, `initiatives/*`, `tags/*`, `getInitiativeHierarchy`,
`getAllInitiatives`, `getAllInitiatives/heatmapPatch`,
`getAllInitiatives/fundingInitiativeView`, `getAllTopLevelInitiatives`,
`getChildInitiatives/:parentId`, `getInitiative/:initiativeId`,
`getInitiativeLineage/:initiativeId`, `getInitiativesForSelect`,
`getAllInitiativesWithFundingInitiativeDetails`,
`getInitiativesWithBudgetParentDetails`, `createInitiative`, `updateInitiative`,
`getFundingInitiatives`, budget endpoints, `rebuild-elastic-search`,
`elastic-search`, `audits`.

**v2** (`services/v2/index.js`, mounted at `/ez-trac-vip/services/v2`):
`initiatives/` (`/`, `/tree`, `/get-limited-initiatives-and-parents`,
`/cycle-detection`), `initiative/*`, `budgets/*`, `tags/*`, `request-initiative/*`.

The endpoints that operate over the **whole initiative table** and run heavy JS
transforms are the ones users feel: `getAllInitiatives` (+ heatmap + funding),
`v2 /initiatives`, `v2 /initiatives/tree`, `getInitiativeHierarchy`,
`getAllInitiativesWithFundingInitiativeDetails`,
`getInitiativesWithBudgetParentDetails`.

---

## Finding 1 — Connection-pool release bug + unsized pool (CRITICAL, global)

File: `services/db/db.js`

```js
const queryWithResults = (queryStr, params) =>
  pool.connect().then(client =>
    client
      .query(queryStr, params)
      .then(result => result.rows)
      .catch(error => { throw error })
      .finally(client.release())   // <-- BUG
  )
```

Two problems, and they affect **every route** because all DAOs go through this
`client`:

1. **`.finally(client.release())` invokes `release()` immediately** and passes its
   return value (`undefined`) to `.finally()`. It must be `.finally(() => client.release())`.
   As written, the release timing is wrong; under load this manifests as clients
   not being returned cleanly to the pool → churn and stalls.
2. **Every query calls `pool.connect()`** to check out a dedicated client instead
   of using `pool.query(...)` (which the `pg` pool manages optimally). Combined
   with (1) this amplifies checkout/checkin overhead.

File: `config/files/fargate-prod.js` (lines ~40–46) and `config/files/default.js`

```js
"ez-trac-vip-db": {
  user: "...", password: "...", host: "...", port: "5432", database: "...",
}
```

3. **No pool sizing or timeouts.** No `max`, `idleTimeoutMillis`,
   `connectionTimeoutMillis`, or `statement_timeout`. `pg` defaults `max` to **10**.
   With heavy endpoints holding a connection for the entire slow transform, 10
   concurrent slow requests exhaust the pool and everything else queues → the
   "so much latency" symptom.

**Impact:** global tail-latency and stalls under concurrency.
**Fix:** Phase 1.

---

## Finding 2 — O(N²) in-memory inheritance resolution (HIGH)

Runs on the full initiative list for the hottest endpoints.

### v2 path
File: `services/v2/initiativeUtils/determineInheritableProperties.js`

```js
export default initiatives =>
  map(initiatives, initiative => ({
    ...initiative,
    status:        getInheritableProperty(initiatives, initiative, 'status', 'parent_status'),
    activityId:    getInheritableProperty(initiatives, initiative, 'activityId', 'parent_activity_id'),
    programCode:   getInheritableProperty(initiatives, initiative, 'programCode', 'parent_program_code'),
    portfolioCode: getInheritableProperty(initiatives, initiative, 'portfolioCode', 'parent_portfolio_code'),
  }))
```

`getInheritableProperty` → `findParent` (`services/v2/initiativeUtils/findParent.js`)
does `find(initiatives, ...)` — a **linear scan of the whole array** — and recurses
up the ancestor chain. So for N initiatives × 4 properties × O(N) scan × tree depth:
**≈ O(N² · depth · 4)**.

### v1 path
File: `services/v1/initiativeUtils/getInheritedFundingDetail.js` +
`services/v1/initiativeUtils/findInheritableParent.js`

Same shape: the default export `map`s over all initiatives, each call resolves 5
inherited properties, each doing a `find(...)` linear scan + recursion up the tree.

**Where it's called:** `getAllInitiatives`, `getAllInitiativesWithStatusOverride`
(heatmap), `getAllInitiativesWithParentInheritanceAndBudgets` (funding view) in
`services/initiativeService.js`; `getInitiatives` and `getInitiativesTree` in v2
`services/v2/initiatives/fetch.js` and `getInitiativesTree.js`.

**Impact:** CPU-bound blocking of the Node event loop that grows quadratically with
portfolio size. This is the primary driver of slow list/tree/heatmap responses.
**Fix:** Phase 3 (build an id→node `Map` once + memoize inherited values → O(N)).

---

## Finding 3 — O(N·M) in-memory tag inheritance (HIGH)

File: `services/v2/initiatives/fetchUtil.js`

```js
const getInitiativesWithInheritedTags = async (req, initiatives) => {
  if ( fieldsContains(req.query, 'tags') ) {
    const initiativesWithTags = await getAllInitiativeTags()   // ALL rows
    const initiativesWithInheritedTags = map(initiatives, initiative => {
      const relatedTags = cleanUpTags(findRelatedTags(initiativesWithTags, initiative.id, 0))
      ...
```

`findRelatedTags` does `filter(allInitiativeTags, { initiative_id: id })` — a full
scan of the tag list — **per initiative** and recurses up the parent chain. For N
initiatives and M tag rows: **≈ O(N · M · depth)**.

**Impact:** the `?fields=...,tags` variants of `v2 /initiatives` and
`v2 /initiatives/tree` are especially slow.
**Fix:** Phase 3 (index tags by `initiative_id` into a `Map` once; walk parents via
the initiative map). A SQL recursive CTE already exists for the single-initiative
case (`findInheritableTagsQuery` in `services/dao/tagsDao.js`) and can be
generalized.

---

## Finding 4 — O(N²) tree construction (MEDIUM-HIGH)

File: `services/v2/initiativeUtils/treeHelpers.js`

```js
export const findAllChildren = (initiatives, root) =>
  filter(initiatives, (initiative => initiative.parentId === root.id))

export const buildTree = (initiatives, root) => {
  const children = findAllChildren(initiatives, root)   // O(N) per node → O(N²)
  ...
}
```

`buildTree` scans the entire array to find children of **every** node → O(N²).
Same pattern in v1 `getInitiativeHierarchy` (`services/initiativeService.js`
lines 145–154) which does `filter(allInitiatives, { parent: parentId })` recursively.

**Impact:** `v2 /initiatives/tree` and v1 `getInitiativeHierarchy`.
**Fix:** Phase 3 (group children by `parentId`/`parent` into a `Map` once → O(N)).

---

## Finding 5 — N+1 database round-trips (HIGH on affected routes)

### 5a. Lineage
File: `services/dao/initiativeDao.js` — `getLineage`

```js
export const getLineage = async (initiativeId, lineage, index) => {
  const initiative = await client.one(getInitiativeQuery, [ initiativeId ])
  ...
  const nextLineage = await getLineage(initiative.parent, lineage, index + 1) // one query PER level
}
```

One sequential DB round-trip per ancestor. Route: `getInitiativeLineage/:initiativeId`.
A single recursive CTE returns the whole lineage in one query (the codebase already
uses `WITH RECURSIVE` — see `getAllDescendantsQuery` and `findInheritableTagsQuery`).

### 5b. Budget children
File: `services/util/BudgetUtil.js` — `getChildrenForBudgets`

```js
export const getChildrenForBudgets = (budgets, budgetsWithChildren) => {
  if ( budgets.length === 0 ) return budgetsWithChildren
  const budget = first(budgets)
  return BudgetDao.getBudgetChildren(budget.initiative_id, budget.fiscal_year)   // one query PER budget
    .then(result => { ...; return getChildrenForBudgets(tail(budgets), budgetsWithChildren) })
}
```

Sequential, one DB round-trip per budget (not even parallelized). Route:
`getBudgetsByInitiative/:initiativeId`. Can be a single JOIN/CTE, or at minimum a
`Promise.all` batch.

### 5c. Duplicate-name check on every write
File: `services/initiativeService.js` — `checkInitiativeName` (lines 34–50)

```js
const responseInitiatives = await daoGetAllInitiatives()   // loads ALL initiatives
const siblingInitiatives = filter(responseInitiatives, ...)
```

Every `createInitiative`/`updateInitiative` loads the entire initiative table to
check one name. Replace with a targeted `WHERE parent = $1 AND UPPER(initiative_name) = UPPER($2)`.

**Fix:** Phase 2.

---

## Finding 6 — No caching of (near-)static reference data (MEDIUM)

Files: `services/referenceDataService.js`, `services/dao/tagsDao.js`
(`getTagNames`, `getTagOptions`), plus `getInitiativeTypes` / `getInitiativeStatus`
/ `getFinancialTagTypes` wired in `services/v1/index.js` (lines 29–31).

These are looked up from the DB on every request but change rarely. They are also
frequently fetched by the UI on page load alongside the heavy list calls,
competing for the same small pool.

**Fix:** Phase 3 (in-process TTL cache with explicit invalidation on writes).

---

## Finding 7 — Over-fetching / `SELECT *` on hot paths (MEDIUM)

- `getInitiativesForSelect` (`services/initiativeService.js` lines 299–308) calls
  `daoGetAllInitiatives()` which runs `SELECT c.*, p.initiative_name ... JOIN ...`
  (`services/dao/initiativeDao.js` line 7) but only returns `initiative_id` +
  `initiative_name`. Use a 2-column query (a `getInitiativeMapQuery` already exists).
- `getAllInitiativesAndBudgetsQuery` and `getInitiativesWithParentAndBudgetsQuery`
  use correlated `ARRAY(SELECT ROW_TO_JSON(budget) WHERE initiative_id = i.initiative_id)`
  subqueries — one subquery execution per row. Needs an index on
  `budget(initiative_id)` (Phase 2) or a rewrite to a single grouped JOIN.

**Fix:** Phases 1–2.

---

## Finding 8 — Missing indexes (HIGH leverage, low risk)

The recurring access patterns are: filter by `parent`, join child→parent, filter
tags/budgets by `initiative_id`, filter budgets by `fiscal_year`. Confirm and add:

- `initiative(parent)` — used by `getChildInitiativesQuery`, hierarchy, tree,
  descendants CTE, duplicate-name check.
- `initiative_tags(initiative_id)` — tag joins/scans (`findAllTagsAndParents`,
  `getTagsByInitiativeQuery`, recursive tag CTE).
- `budget(initiative_id)` — budget-by-initiative + the correlated subqueries.
- `budget(fiscal_year)` — `getBudgetsByFiscalYear(s)`, children-by-fiscal-year.

**Fix:** Phase 2.

---

## Finding 9 — Elasticsearch read path (LOW-MEDIUM)

File: `services/elastic/network.js`

- `requestTimeout: 60000` (60s) means a slow audit query can hold the request for a
  full minute. Route: `GET /audits` (`services/v1/index.js` lines 71–76).
- `translateQuery` (`services/elastic/QueryTranslator.js`) should enforce a `size`
  cap / pagination so large audit result sets don't create huge payloads.
- `checkIfDocumentAlreadyAdded` uses `body.hits.total > 0`; in modern OpenSearch
  `hits.total` is an object `{ value, relation }`. Verify this comparison (ingestion
  path, not user-facing latency, but worth noting).

**Fix:** Phase 2/4 (bound result size; lower/segment timeout for read path).

---

## Summary table

| # | Finding | Severity | Routes affected | Phase |
| --- | --- | --- | --- | --- |
| 1 | Pool release bug + unsized pool/timeouts | Critical | all | 1 |
| 2 | O(N²) inheritance resolution (v1 + v2) | High | list, heatmap, funding, tree | 3 |
| 3 | O(N·M) tag inheritance | High | `initiatives?fields=tags`, tree | 3 |
| 4 | O(N²) tree/hierarchy build | Med-High | tree, `getInitiativeHierarchy` | 3 |
| 5 | N+1 round-trips (lineage, budget children, name check) | High | lineage, budgets-by-initiative, writes | 2 |
| 6 | No reference-data cache | Medium | referenceData, initiativeTypes, tags | 3 |
| 7 | Over-fetching / `SELECT *` | Medium | forSelect, budget views | 1–2 |
| 8 | Missing indexes | High | most read routes | 2 |
| 9 | Elastic read timeout / unbounded size | Low-Med | `/audits` | 2/4 |
