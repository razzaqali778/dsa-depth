# Phase 1 — Quick Wins (low risk, global impact)

Goal: fix the connection-pool bug, size the pool, add timeouts, and stop the worst
over-fetching. These changes touch a small number of files and benefit **every**
route. Ship this first.

## 1.1 Fix the pool release bug and use `pool.query`

File: `services/db/db.js`

**Problem:** `.finally(client.release())` calls `release()` immediately (see
Finding 1). Also every call checks out a dedicated client via `pool.connect()`.

**Suggested change** — let the pool manage clients and release correctly:

```js
const queryWithResults = (queryStr, params) =>
  pool.query(queryStr, params).then(result => result.rows)

const queryWithOneResult = (queryStr, params) =>
  pool.query(queryStr, params).then(result => result.rows[0])
```

If a dedicated client must be kept (it does not appear necessary here), then the
release must be deferred:

```js
.finally(() => client.release())   // pass a function, don't invoke it
```

**Why:** correct, prompt connection return to the pool; removes per-query
checkout/checkin overhead. `pool.query()` is the recommended `pg` usage for
single statements.

**Risk:** low. Behavior is equivalent for callers (`client.any` / `client.one`
still return rows / first row). Keep the `NODE_ENV === 'test'` noop branch as-is.

## 1.2 Size the pool and add timeouts

Files: `config/files/fargate-prod.js`, `config/files/fargate-np.js`,
`config/files/production.js`, `config/files/default.js`, `config/files/development.js`
(wherever `ez-trac-vip-db` is defined), consumed in `services/db/db.js`.

**Suggested additions to the pool config object:**

```js
"ez-trac-vip-db": {
  user, password, host, port, database,
  max: 20,                       // tune to DB max_connections / task count
  min: 2,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000, // fail fast instead of hanging
  statement_timeout: 15000,      // kill runaway queries, free the connection
  query_timeout: 15000,
  keepAlive: true,
}
```

**Why:** prevents a handful of slow requests from starving the whole service;
`statement_timeout` guarantees a stuck query can't hold a connection forever.

**Risk:** low-medium. `max` must respect the Postgres `max_connections` budget
across all running tasks — size it with infra. Start conservative (e.g. 20) and
adjust using Phase 4 metrics.

**Note:** confirm whether the `pg` `Pool` receives these keys directly (it does for
`max`, `idleTimeoutMillis`, `connectionTimeoutMillis`; `statement_timeout` and
`query_timeout` are passed through to the client). If the config layer strips
unknown keys, thread them explicitly where `new Pool(dbConfig)` is constructed.

## 1.3 Stop over-fetching on `getInitiativesForSelect`

File: `services/initiativeService.js` (lines 299–308) + `services/dao/initiativeDao.js`

**Problem:** `getInitiativesForSelect` runs the full join query (`SELECT c.*, ...`)
then maps down to `{ initiative_id, initiative_name }`.

**Suggested change:** use the existing `getInitiativeMap()` DAO
(`SELECT initiative_id, initiative_name FROM initiative`) instead of
`daoGetAllInitiatives()`:

```js
export const getInitiativesForSelect = async (req, res) => {
  try {
    const result = await daoGetInitiativeMap()   // 2 columns, no join
    res.json(result)
  } catch ( err ) {
    res.status(500).send(err)
  }
}
```

**Why:** removes a self-join and column bloat on a dropdown-populating endpoint the
UI hits often.

**Risk:** low. Verify the response shape the UI expects (already `{ initiative_id,
initiative_name }`).

## 1.4 Enable/confirm keep-alive & compression are effective

File: `server.js` (line 19 `app.use(compression())`).

- `compression()` is already enabled — good. Confirm large JSON list responses are
  actually being gzipped end-to-end (no upstream proxy stripping it).
- Ensure the process runs with `NODE_ENV=production` in prod so the dev-only webpack
  middleware block (`server.js` lines 36–59) is skipped.

## Phase 1 verification

1. Load test one heavy endpoint (e.g. `GET /ez-trac-vip/services/v1/getAllInitiatives`)
   at, say, 50 concurrent for 30s before/after. Expect large p95/p99 improvement
   purely from the pool fix + sizing (see Phase 4 for the harness).
2. Watch for connection errors/timeouts in logs — should drop to zero under the
   previous load.
3. Confirm no functional regressions on the select/dropdown endpoint.

## Exit criteria

- No connection-pool exhaustion under the target concurrency.
- `getInitiativesForSelect` no longer runs the join query.
- Timeouts configured so no single query can hold a connection > `statement_timeout`.
