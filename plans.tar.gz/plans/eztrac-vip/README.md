# VIP Service — Route Latency Remediation Plan

This folder contains a phased plan to reduce latency across **all routes** in the
`eztrac-vip` service (`/ez-trac-vip/services/v1/*` and `/ez-trac-vip/services/v2/*`).

The plan is based on a code-level audit of the service (routers, service layer,
DAO layer, DB pool, and Elasticsearch client). Every finding cites the exact
file/line so the fix can be implemented directly.

## Documents

| File | Purpose |
| --- | --- |
| [`01-findings.md`](./01-findings.md) | Evidence-based root-cause analysis of the latency hotspots. |
| [`02-phase-1-quick-wins.md`](./02-phase-1-quick-wins.md) | Low-risk, high-impact fixes (pool bug, pool sizing, timeouts, over-fetching). |
| [`03-phase-2-db-and-queries.md`](./03-phase-2-db-and-queries.md) | Indexes and query rewrites (N+1 → single query). |
| [`04-phase-3-algorithms-and-caching.md`](./04-phase-3-algorithms-and-caching.md) | Kill the O(N²) in-memory transforms + add reference-data caching. |
| [`05-phase-4-verification.md`](./05-phase-4-verification.md) | Benchmarking, load testing, and monitoring so we can prove the wins. |

## Executive summary

The VIP service is slow for three compounding reasons:

1. **A connection-pool release bug + an unsized pool** (`services/db/db.js`). Under
   any concurrency, requests queue on a 10-connection default pool and connections
   are released incorrectly, causing tail-latency spikes and occasional stalls.
2. **O(N²) (and worse) in-memory transforms** run on the *entire* initiative table
   for the highest-traffic endpoints (`getAllInitiatives`, `initiatives`, `tree`,
   heatmap, funding views). Inheritance resolution, tag inheritance, and tree
   building all do repeated linear scans over the full dataset.
3. **N+1 database round-trips** in lineage and budget-children resolution, plus
   uncached reference-data lookups on hot paths.

The good news: none of this requires an architecture change. The fixes are local,
incremental, and independently shippable. Expected impact after Phases 1–3 is a
**large reduction in p95/p99 latency** on the list/tree/heatmap endpoints (the
transforms drop from quadratic to linear) and elimination of connection-pool
stalls under load.

## How to use this plan

- Phases are ordered by **risk-adjusted impact**. Ship Phase 1 first — it is almost
  pure win with minimal blast radius.
- Each phase is self-contained: it lists the target files, the change, the reason,
  and a verification step.
- Treat the "Suggested change" code blocks as **direction, not final code** — adapt
  to the existing style/lint rules (`.eslintrc`, `wyze/max-file-length`).

## Scope

In scope: all `eztrac-vip` HTTP routes and their service/DAO/DB dependencies.
Out of scope: UI (`public/scripts`), the audit/Elasticsearch ingestion pipeline
(only the read path `GET /audits` is touched), and cross-service changes.
