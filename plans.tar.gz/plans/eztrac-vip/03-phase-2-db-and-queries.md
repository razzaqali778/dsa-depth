# Phase 2 — Database Indexes & Query Rewrites

Goal: make the SQL do the work the app is currently doing in slow loops, and ensure
the query planner has the indexes it needs. These are high-leverage, low-risk.

## 2.1 Add the missing indexes

Add a migration (match the project's migration mechanism; if none, a reviewed SQL
script applied to each environment). Use `CREATE INDEX CONCURRENTLY` in production
to avoid table locks.

```sql
-- child lookups, hierarchy, tree, descendants CTE, duplicate-name check
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_initiative_parent
  ON initiative (parent);

-- tag joins / scans (findAllTagsAndParents, getTagsByInitiative, recursive tag CTE)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_initiative_tags_initiative_id
  ON initiative_tags (initiative_id);

-- budget-by-initiative + correlated ROW_TO_JSON subqueries
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_budget_initiative_id
  ON budget (initiative_id);

-- budgets by fiscal year + children-by-fiscal-year
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_budget_fiscal_year
  ON budget (fiscal_year);

-- optional: case-insensitive duplicate-name check (see 2.4)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_initiative_parent_uppername
  ON initiative (parent, UPPER(initiative_name));
```

**Verify first:** run `EXPLAIN (ANALYZE, BUFFERS)` on the hot queries to confirm
current seq scans and that these indexes are chosen afterward. Check `pg_indexes`
so we don't duplicate existing indexes/PKs.

**Risk:** very low (additive). Watch write amplification on `initiative_tags` /
`budget` if they're write-heavy (they are not on these paths).

## 2.2 Replace lineage N+1 with a single recursive CTE

Files: `services/dao/initiativeDao.js` (`getLineage`), consumed by
`getInitiativeLineage` in `services/initiativeService.js`.

**Problem:** one `client.one` query per ancestor level (Finding 5a).

**Suggested change:** a single upward-recursive CTE.

```sql
WITH RECURSIVE lineage AS (
  SELECT initiative_id, initiative_name, parent, 0 AS ord
  FROM initiative WHERE initiative_id = $1
  UNION ALL
  SELECT i.initiative_id, i.initiative_name, i.parent, l.ord + 1
  FROM initiative i
  JOIN lineage l ON i.initiative_id = l.parent
)
SELECT initiative_id AS id, initiative_name AS name, ord AS "order"
FROM lineage ORDER BY ord;
```

Return this array directly. Keep the existing response shape
(`{ id, name, order }`).

**Risk:** low. Add a test asserting equivalence with the old recursion (including
the root, where `parent IS NULL`).

## 2.3 Collapse budget-children N+1

Files: `services/util/BudgetUtil.js` (`getChildrenForBudgets`),
`services/dao/BudgetDao.js` (`getBudgetChildren`), route
`getBudgetsByInitiative/:initiativeId`.

**Problem:** one DB round-trip per budget, sequential (Finding 5b).

**Two options (pick one):**

- **Preferred — single query:** fetch all children for the initiative's budgets in
  one statement (join `budget` to child initiatives filtered by the parent set and
  the relevant fiscal years), then attach `children` in memory by
  `(initiative_id, fiscal_year)`.
- **Minimal — batch the round-trips:** replace the sequential recursion with
  `Promise.all(budgets.map(b => BudgetDao.getBudgetChildren(b.initiative_id, b.fiscal_year)))`
  and zip results back. Removes the sequential stall even if it keeps N queries.

**Risk:** low-medium. Preserve the exact `budget.children` output structure the UI
consumes.

## 2.4 Targeted duplicate-name check on writes

Files: `services/initiativeService.js` (`checkInitiativeName`, lines 34–50) + a new
DAO query.

**Problem:** loads the entire initiative table on every create/update (Finding 5c).

**Suggested DAO query:**

```sql
SELECT initiative_id
FROM initiative
WHERE ( ($1::uuid IS NULL AND parent IS NULL) OR parent = $1 )
  AND UPPER(initiative_name) = UPPER($2)
  AND initiative_id <> COALESCE($3, '00000000-0000-0000-0000-000000000000')
LIMIT 1;
```

Return `{ isDuplicate: true, initiative_id }` if a row exists, else
`{ isDuplicate: false }`. Backed by `idx_initiative_parent_uppername` (2.1).

**Risk:** low. Preserve the sibling-scope semantics (null parent = top level).

## 2.5 Bound the Elasticsearch read path

Files: `services/elastic/network.js`, `services/elastic/QueryTranslator.js`, route
`GET /audits`.

- Enforce a default/max `size` (and `from`/`search_after` pagination) in
  `translateQuery` so `/audits` can't return unbounded payloads.
- Consider a lower per-request timeout for the read path than the global
  `requestTimeout: 60000`, so a slow audit query fails fast rather than holding the
  HTTP request for a minute.

**Risk:** low. Confirm consumers of `/audits` can handle pagination.

## Phase 2 verification

- `EXPLAIN (ANALYZE, BUFFERS)` before/after on: child lookup, tag join, budgets by
  initiative, duplicate-name check → confirm index usage and lower cost.
- Functional tests: lineage equivalence (2.2), budget-children output equivalence
  (2.3), duplicate-name behavior incl. top-level scope (2.4).
- `/audits` returns a bounded page and supports pagination.

## Exit criteria

- No route issues more than one DB round-trip per logical read (lineage, budget
  children, name check all single-query or batched).
- Planner uses indexes on all hot filters/joins.
