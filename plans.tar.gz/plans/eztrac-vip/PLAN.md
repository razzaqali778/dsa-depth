# eztrac-vip — Issues & Fix Plan

> Express + React app (port **3300**) backed by the VIP DB + OpenSearch. Owns the
> initiative tree, budgets by fiscal year, tags, and a searchable audit history.

This folder already contains a full, evidence-based, phased plan. This file is
the index; the depth is in:

| Doc | What it covers |
|---|---|
| [`README.md`](./README.md) | Executive summary + how to use the plan. |
| [`01-findings.md`](./01-findings.md) | Root-cause analysis with exact file:line citations. |
| [`02-phase-1-quick-wins.md`](./02-phase-1-quick-wins.md) | Pool release bug, pool sizing, timeouts, over-fetching. |
| [`03-phase-2-db-and-queries.md`](./03-phase-2-db-and-queries.md) | Indexes + N+1 → single-query rewrites. |
| [`04-phase-3-algorithms-and-caching.md`](./04-phase-3-algorithms-and-caching.md) | Kill O(N²) in-memory transforms + reference-data cache. |
| [`05-phase-4-verification.md`](./05-phase-4-verification.md) | Benchmarking, load testing, monitoring. |

## Top issues (summary)

### Bugs
- **CRITICAL — connection-pool release bug** in `services/db/db.js`:
  `.finally(client.release())` calls `release()` immediately (passing `undefined`
  to `.finally`). Must be `.finally(() => client.release())`. Under load this
  churns/stalls the pool for **every route**.

### Latency (millions of rows)
- **Unsized pool / no timeouts** (`pg` default `max=10`) + every query does
  `pool.connect()` instead of `pool.query()` → 10 slow requests exhaust the pool.
- **O(N²) inheritance resolution** (`services/v2/initiativeUtils/determineInheritableProperties.js`
  + `findParent.js`; v1 equivalents) runs a linear scan of the whole initiative
  table per property per node → quadratic, blocks the event loop.
- **O(N·M) tag inheritance** (`services/v2/initiatives/fetchUtil.js`).
- **O(N²) tree/hierarchy build** (`services/v2/initiativeUtils/treeHelpers.js`).
- **N+1 round-trips**: lineage (`services/dao/initiativeDao.js` `getLineage`),
  budget children (`services/util/BudgetUtil.js`), duplicate-name check loads the
  whole table on every write.
- **Missing indexes**: `initiative(parent)`, `initiative_tags(initiative_id)`,
  `budget(initiative_id)`, `budget(fiscal_year)`.
- No reference-data cache; `SELECT *` over-fetching; 60s Elasticsearch read
  timeout + unbounded audit result size.

## Recommended sequence
Ship **Phase 1** first (pool fix + sizing + timeouts — near-pure win, tiny blast
radius), then Phase 2 (indexes + N+1), then Phase 3 (build id→node `Map` once so
the transforms drop from O(N²) to O(N) + cache reference data). Expected result:
large p95/p99 drop on list/tree/heatmap and no more pool stalls under load.
