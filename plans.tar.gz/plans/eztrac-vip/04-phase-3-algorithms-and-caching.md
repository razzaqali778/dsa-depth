# Phase 3 — Kill the O(N²) Transforms & Add Caching

This is where the biggest CPU wins live. The heaviest endpoints spend their time in
quadratic in-memory transforms over the full initiative list. Converting these to
linear (O(N)) passes removes event-loop blocking that grows with portfolio size.

Ship Phase 3 after Phases 1–2. Each change is behind an existing function boundary,
so it can be introduced with characterization tests that assert identical output.

## 3.1 Linear inheritance resolution (v2)

Files: `services/v2/initiativeUtils/determineInheritableProperties.js`,
`getInheritableProperty.js`, `findParent.js`.

**Problem:** `findParent` does a full-array `find` and recurses up the tree, called
N × 4 properties (Finding 2). ≈ O(N² · depth).

**Approach:**
1. Build `byId = new Map(initiatives.map(i => [i.id, i]))` once — O(N).
2. Replace `findParent(initiatives, node)` with `byId.get(node.parentId)` — O(1).
3. Memoize the resolved inherited value per `(nodeId, prop)` while walking up, so
   each node's chain is computed at most once (dynamic programming). Net O(N).

**Sketch:**

```js
const buildIndex = initiatives => new Map(initiatives.map(i => [ i.id, i ]))

const resolveProp = (byId, memo, node, prop, parentProp) => {
  if ( node[prop] ) return node[prop]
  if ( node[parentProp] ) return node[parentProp]
  const key = `${node.id}:${prop}`
  if ( memo.has(key) ) return memo.get(key)
  const parent = byId.get(node.parentId)
  const value = parent ? resolveProp(byId, memo, parent, prop, parentProp) : node[prop]
  memo.set(key, value)
  return value
}
```

Then `determineInheritableProperties` maps once using `byId` + a shared `memo`.

**Risk:** medium (core business logic). Guard with characterization tests: snapshot
current output for a representative dataset, refactor, assert byte-identical.

## 3.2 Linear inheritance resolution (v1)

Files: `services/v1/initiativeUtils/getInheritedFundingDetail.js`,
`findInheritableParent.js`, used by `getAllInitiatives`,
`getAllInitiativesWithStatusOverride` (heatmap),
`getAllInitiativesWithParentInheritanceAndBudgets` (funding view) in
`services/initiativeService.js`.

Same technique as 3.1: build an id→node `Map`, replace the `find(...)` scans in
`findParent` / `findParentWithProperty` with map lookups, memoize per property.
Note v1 resolves 5 properties (funding value/type, portfolio, program, activity,
status), so the quadratic cost is even higher here.

**Risk:** medium. Same characterization-test guard.

## 3.3 Linear tag inheritance

File: `services/v2/initiatives/fetchUtil.js`.

**Problem:** `getAllInitiativeTags()` then per-initiative `filter(...)` + parent
recursion (Finding 3). ≈ O(N · M · depth).

**Approach:**
1. `tagsById = groupBy(allInitiativeTags, 'initiative_id')` once — O(M).
2. Build/receive the id→node `Map` (reuse from 3.1/3.2).
3. For each initiative, walk the parent chain via the map, concatenating
   `tagsById.get(id)` at each level — O(depth) per node, O(N · depth) total.
4. Keep `cleanUpTags` (dedupe by `tag_id`, order by level) as-is.

**Alternative (DB-side):** generalize the existing single-initiative recursive CTE
`findInheritableTagsQuery` (`services/dao/tagsDao.js`) to return inherited tags for
all initiatives in one query, and attach in memory.

**Risk:** medium. Characterization test with a `?fields=...,tags` request.

## 3.4 Linear tree / hierarchy construction

Files: `services/v2/initiativeUtils/treeHelpers.js`,
`services/initiativeService.js` (`getInitiativeHierarchy`, lines 141–158).

**Problem:** `buildTree`/`constructHierarchy` call `filter(...)` per node → O(N²)
(Finding 4).

**Approach:** bucket children by parent once:

```js
const childrenByParent = new Map()
initiatives.forEach(i => {
  const key = i.parentId ?? null
  if ( !childrenByParent.has(key) ) childrenByParent.set(key, [])
  childrenByParent.get(key).push(i)
})

const buildTree = node => ({
  ...node,
  children: (childrenByParent.get(node.id) || []).map(buildTree),
})
```

Roots = `childrenByParent.get(null)`. Net O(N). Mirror the same grouping for v1
`getInitiativeHierarchy` (keyed on `parent`).

**Risk:** low-medium. Output structure must match exactly (children ordering — add
an explicit sort if the current implicit DB order matters to the UI).

## 3.5 Reference-data caching

Files: `services/referenceDataService.js`, `services/dao/tagsDao.js`
(`getTagNames`, `getTagOptions`), wired in `services/v1/index.js`.

**Problem:** near-static lookups hit the DB every request and compete for the pool
(Finding 6).

**Approach:** a tiny in-process TTL cache (no new infra):

```js
const cache = new Map() // key -> { value, expires }
export const cached = (key, ttlMs, loader) => async (...args) => {
  const hit = cache.get(key)
  if ( hit && hit.expires > Date.now() ) return hit.value
  const value = await loader(...args)
  cache.set(key, { value, expires: Date.now() + ttlMs })
  return value
}
```

Wrap `getInitiativeStatus`, `getInitiativeTypes`, `getFinancialTagTypes`,
`getTagNames`, `getTagOptions` with a short TTL (e.g. 5 min). **Invalidate** the
relevant key(s) when the corresponding data is written (tag admin / reference-data
updates), or accept staleness bounded by the TTL.

**Risk:** low. Only for data that changes rarely; keep TTL modest and clear cache on
writes to avoid stale admin edits.

**Scale-out note:** in-process cache is per-task. That's fine for these tiny,
low-churn datasets. If strict cross-task consistency is ever required, move to a
shared cache (e.g. Redis) — not needed now.

## Phase 3 verification

- **Correctness:** characterization tests for 3.1–3.4 — capture current JSON output
  for a representative initiative set, then assert identical output after refactor.
- **Performance:** micro-benchmark each transform on a synthetic large dataset
  (e.g. 5k–20k initiatives) before/after; expect the runtime curve to flatten from
  quadratic to roughly linear.
- **Cache:** confirm reference-data endpoints serve from cache (add a debug
  counter/log) and that writes invalidate as intended.

## Exit criteria

- No request-path transform is worse than O(N log N).
- Heavy list/tree/heatmap endpoints no longer block the event loop proportional to N².
- Reference-data reads are served from cache within the TTL.
