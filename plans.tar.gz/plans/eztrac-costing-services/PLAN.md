# eztrac-costing-services — Issues & Fix Plan

> NestJS API (port **3000**), Kysely + Postgres. The **cost engine**: people,
> rates, cost groups, engagements, calendars. Hot path
> `POST /v1/cost-calc/effort` → `rate × calendar hours × participation %`.

Source: code-level audit [Analyze eztrac-costing-services](84577d57-e879-49de-9e67-da58c119139a).

---

## 1. Bugs (cost correctness / concurrency / security)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| B1 | Critical | Null/undefined `participants` crashes request (`.forEach` unguarded) | `src/costCalc/costCalc.service.ts:30-33` | `(effort.participants ?? []).forEach` |
| B2 | Critical | Person upsert is DELETE+INSERT with **no transaction** → data loss / defaults on failure or concurrent read | `src/person/person.repository.ts:108-123` | `db.transaction()` + `ON CONFLICT` upsert |
| B3 | High | Silent fallback to hard-coded **$16,000/mo** on any missing person/rate/calendar | `src/costCalc/utils.ts:42-51`, `constants.ts:1-4` | Return explicit error / exclude line / 422 |
| B4 | High | Validation errors logged but invalid costs still returned (HTTP 200) | `costCalc.service.ts:73-79`, `specificPeopleCostGenerator.ts:35-47` | Add `errors` to response or 422 |
| B5 | High | **No auth** on `/cost-calc/effort` (other admin routes use `RolesGuard`) | `src/costCalc/costCalc.controller.ts:11-22` | Add guard / service-to-service auth |
| B6 | Medium | No upper bound on participation % (`percent:500` → 5× cost) | `src/costCalc/validators.ts:37-43` | Reject `>100`; `@Max(100)` |
| B7 | Medium | Inactive persons/engagements still fully costed | `validators.ts:101-134`, `engagementCostGenerator.ts:13-21` | Validate `isActive` |
| B8 | Medium | Loose timeframe matching when calendar hours missing → default 160h instead of failing | `utils.ts:25-29,47-50` | Sentinel/omit + hard error |
| B9 | Medium | `Math.floor` truncates cents (systematic under-costing) | `specificPeopleCostGenerator.ts:45`, `genericPeopleCostGenerator.ts:34-36` | Align to business rule (round / integer cents) |
| B10 | Medium | `RolesGuard` crashes if `@Roles` missing | `src/common/roles/roles.guard.ts:30-38` | `if (!requiredRoles?.length) return false` |

## 2. Latency / scale (millions of rows)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| L1 | Critical | **Full-table** loads of rates + cost groups + engagements on **every** request | `costCalc.service.ts:46-48` | Cache reference data (TTL+invalidation) or `WHERE id IN (...)` |
| L2 | High | 5 sequential DB round-trips per request | `costCalc.service.ts:37-48` | `Promise.all([...])` |
| L3 | High | No pagination on list endpoints (person/audit/rate/costGroup/engagement) | `person.repository.ts:38-43`, `audits.repository.ts:13-24` | Add `limit`/cursor |
| L4 | High | Person search leading-wildcard `LIKE %term%` on `lower(col)` → seq scan | `person.repository.ts:46-55` | `pg_trgm` index / prefix search / OpenSearch |
| L5 | High | Missing indexes: `calendar_timeframe_hours(timeframe_id)`, `person(is_active/rate_id/cost_group_id)`, `audit(modified_time)` | `migrations/0000000000000-init.sql:135-140,298-303` | Add targeted indexes |
| L6 | Medium | Pool `max:200`, no `statement_timeout`, 10-min idle | `src/common/db/database-connection.provider.ts:8-22` | Right-size + timeouts |
| L7 | Medium | 50 MB JSON body allows huge effort arrays | `src/main.ts:11` | Lower limit / cap array length |

## 3. Cost-engine hot path (`POST /v1/cost-calc/effort`)

| # | Severity | Issue | Location | Fix |
|---|---|---|---|---|
| H1 | High | `mapMonthlyRates` recomputed per effort (1000 efforts × 12 TFs → 1000×) | `costCalc.service.ts:50-55`, `utils.ts:19-40` | Precompute `Map<timeFrameId, MappedRate[]>` once |
| H2 | High | O(n²) linear `.find()` scans (person/engagement/calendar/rate per participant) | `specificPeopleCostGenerator.ts:24-26`, `engagementCostGenerator.ts:15-16`, `utils.ts:25-28`, `validators.ts:50,60` | Build `Map` indexes once |
| H3 | High | Full engagement/rate/cost-group tables loaded when only a few IDs needed | `costCalc.service.ts:46-48` | Derive unique ID sets → scoped `IN` queries |
| H4 | Medium | Unbounded effort count per request (`ParseArrayPipe`) | `costCalc.controller.ts:17-21` | Cap (e.g. 100) / async queue for bulk |

Target hot-path shape: collect unique ids → `Promise.all` scoped fetches → build Maps → precompute rates-by-timeframe → O(participants) per effort → return typed `EffortCostingResult[]`.

## Phased priority
- **P0**: B1, B2, L1, H1–H3 (crashes, data loss, full-table loads every calc).
- **P1**: B3–B5, L2, L4, L5, H4 (wrong costs, no auth, sequential I/O, indexes).
- **P2**: B6–B10, L3, L6, L7 (validation, list scale, pool tuning).
