// tested with node 4.4.3
// this file is not transpiled using babel
import { securityMiddleware } from './securityMiddleware'
import bodyParser from 'body-parser'
import compression from 'compression'
import cors from 'cors'
import express from 'express'
import loggerMiddleware from './loggerMiddleware'
import proxies from './proxies'
import proxy from 'http-proxy'
import serviceBindings from './serviceBindings'
import setupListener from './services/db/setupListener'
import v1 from './services/v1'
import v2 from './services/v2'

const appBaseUrl = '/ez-trac-vip'

const app = express()
app.use(compression())

const addPingPage = () => {
  const createPingPage = require('@monsantoit/ping-page') // eslint-disable-line global-require
  const pingPage = createPingPage(require('./package.json')) // eslint-disable-line global-require
  app.get('/ping'.pingPage)
  app.get(`${appBaseUrl}/ping`, pingPage)
}

addPingPage()

// app.use(createProfileMiddleware({ localDevProfile }))
app.use(securityMiddleware, loggerMiddleware)

// app.use(`${appBaseUrl}/service-bindings`, serviceBindingsMiddleware)
app.use(`${appBaseUrl}/phoenix/service-bindings`, serviceBindings)

if ( process.env.NODE_ENV !== 'production' ) {
  /* eslint-disable global-require */
  const webpackDevMiddleware = require('webpack-dev-middleware')
  const webpack = require('webpack')
  const config = require('./webpack.config')
  const compiler = webpack(config)
  const middlewareOptions = {
    stats: { colors: true },
    // noInfo: false, // Comment this out for more verbose webpack information
    publicPath: config.output.publicPath,
  }

  const webpackDevMiddlewareInstance = webpackDevMiddleware(compiler, middlewareOptions)
  app.use(webpackDevMiddlewareInstance)

  const webpackHotMiddleware = require('webpack-hot-middleware')

  app.use(webpackHotMiddleware(compiler, { path: `${appBaseUrl}/__webpack_hmr` }))

  const lessMiddleware = require('less-middleware')
  app.use(`${appBaseUrl}/styles`, lessMiddleware('./public/styles'))
  /* eslint-enable */
  app.use(cors())
}
app.use(bodyParser.json())
app.use(`${appBaseUrl}/styles`, express.static('./public/styles'))
app.use(`${appBaseUrl}/scripts`, express.static('./public/scripts'))
app.use(`${appBaseUrl}/services/v1`, v1)
app.use(`${appBaseUrl}/services/v2`, v2)
app.use(`${appBaseUrl}/services/proxies`, proxies)

const secureProxyServer = proxy.createProxyServer() // eslint-disable-line no-unused-vars

app.get('/*', ( req, res ) => {
  res.send(`<!DOCTYPE html>
    <html>
      <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Initiative Portfolio</title>
        <link rel="stylesheet" type="text/css" href="https://phoenix-tools.io/assets/cached/peadmin/styles/navbar.css">
        <link rel="stylesheet" type="text/css" href="https://phoenix-tools.io/assets/cached/peadmin/styles/mat1.1.1.css">
        <link rel="stylesheet" type="text/css" href="https://static-assets.velocity.ag/styles/1.0.1/velocity.css" />
        <link rel="stylesheet" href="${appBaseUrl}/styles/style.css">
        <link rel="stylesheet" href="${appBaseUrl}/styles/toggle.css">
      </head>
      <body>
        <div class="nav"></div>
        <div class="container">
          <div class="contents"></div>
        </div>
        <script type="text/javascript" src="${appBaseUrl}/phoenix/service-bindings"></script>
        <script type="text/javascript" src="${appBaseUrl}/scripts/bundle.js"></script>
      </body>
    </html>
  `)
})

const port = parseInt(process.env.PORT || 3300, 10)

setupListener()
const server = app.listen(port, () => {
  const address = server.address()
  const url = `http://${address.host || 'localhost'}:${port}`
  console.info(`Listening at ${url}`) // eslint-disable-line no-console
})
