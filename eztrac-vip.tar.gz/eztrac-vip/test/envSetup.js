// my-custom-environment
const NodeEnvironment = require('jest-environment-node').default

const config = require('../config')

class CustomEnvironment extends NodeEnvironment {
  async setup() {
    await super.setup()
    await config.init()
  }

  async teardown() {
    await super.teardown()
  }

  runScript(script) {
    return super.runScript(script)
  }
}

module.exports = CustomEnvironment
