import 'sinon-as-promised'

import sinon from 'sinon'

jest.mock('uuid', () => ({ v1: jest.fn(() => 'id') }))

global.sinon = sinon
global.isTesting = true

global.console.error = jest.fn(() => null)

global.phoenix = {
  authHeader: () => {},
  serviceBindings: {
    'phoenix-home': 'phoenix-tools-np.io',
    'home-url': 'https://phoenix-tools-np.io/home',
    'preferences-url': 'https://preferences.phoenix-tools-np.io',
    'messaging-url': 'https://messaging.velocity-np.ag',
    'navigation-url': 'https://navigation.phoenix-tools-np.io',
    'profile-url': 'https://profile.phoenix-tools-np.io',
    'user-feedback-url': 'https://user-feedback.phoenix-tools-np.io',
    'velocity-home': 'velocity-np.ag',
    'peadmin-home': 'peadmin-np.monsanto.net',
    'ez-trac-teams-hook': 'teamsHookUrl',
  },
  urls: {
    ui: {
      'ez-trac-workflows': 'https://peadmin-np.monsanto.net/ez-trac-workflows',
      'ez-trac-costing': 'https://peadmin-np.monsanto.net/ez-trac-costing',
      'ez-trac-qc': 'https://peadmin-np.monsanto.net/ez-trac-qc',
    },
    services: {
      'ez-trac-costing': 'https://ez-trac-costing-services.velocity-np.ag',
      'ez-trac-suggestion': 'https://ez-trac-suggestion.velocity-np.ag',
      'ez-trac-core': 'https://ez-trac-core-services.velocity-np.ag',
      'ez-trac-qc':
        'https://ez-trac-qc-services.velocity-np.ag/ez-trac-qc/services',
    },
  },
}
