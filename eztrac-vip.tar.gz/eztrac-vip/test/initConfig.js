import config from '../config'

async function initConfig() {
  config.init()
}

initConfig()
