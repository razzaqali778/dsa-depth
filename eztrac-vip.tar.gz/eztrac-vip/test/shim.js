const { TextDecoder, TextEncoder } = require('util')

global.TextEncoder = TextEncoder
global.TextDecoder = TextDecoder
global.requestAnimationFrame = callback => setTimeout(callback, 0)
