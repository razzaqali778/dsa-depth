import { isLoading } from '../../../../public/scripts/selectors/loading'

describe('loading selector', () => {
  it('isLoading returns true if loadingCount > 0', () => {
    const mockState = {
      loadingCount: 1,
    }

    const actual = isLoading(mockState)

    expect(actual).toEqual(true)
  })

  it('isLoading returns false if loadingCount is 0', () => {
    const mockState = {
      loadingCount: 0,
    }

    const actual = isLoading(mockState)

    expect(actual).toEqual(false)
  })
})
