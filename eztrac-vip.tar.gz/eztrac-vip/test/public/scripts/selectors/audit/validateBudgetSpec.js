import { validateBudgetMax, validateBudgetMin } from '../../../../../public/scripts/selectors/audit/validateBudget'

describe('validateBudget selector', () => {
  it('returns false when amount_min or amount_max is a string', () => {
    const mockStateMin = {
      filters: {
        amount_min: 'ab0c',
        unimportant_thingy: [],
      },
    }
    const mockStateMax = {
      filters: {
        amount_max: 'fc54g',
        unimportant_thingy: [],
      },
    }
    const actualMin = validateBudgetMin(mockStateMin)
    const actualMax = validateBudgetMax(mockStateMax)
    expect(actualMin).toEqual(false)
    expect(actualMax).toEqual(false)
  })

  it('returns true when amount_min or amount_max is a number', () => {
    const mockStateMin = {
      filters: {
        amount_min: 54,
        unimportant_thingy: [],
      },
    }
    const mockStateMax = {
      filters: {
        amount_max: 42,
        unimportant_thingy: [],
      },
    }
    const actualMin = validateBudgetMin(mockStateMin)
    const actualMax = validateBudgetMax(mockStateMax)
    expect(actualMin).toEqual(true)
    expect(actualMax).toEqual(true)
  })

  it('returns true when amount_min or amount_max is an empty string', () => {
    const mockStateMin = {
      filters: {
        amount_min: '',
        unimportant_thingy: [],
      },
    }
    const mockStateMax = {
      filters: {
        amount_max: '',
        unimportant_thingy: [],
      },
    }
    const actualMin = validateBudgetMin(mockStateMin)
    const actualMax = validateBudgetMax(mockStateMax)
    expect(actualMin).toEqual(true)
    expect(actualMax).toEqual(true)
  })

  it('returns true when amount_min or amount_max is null', () => {
    const mockStateMin = {
      filters: {
        amount_min: null,
        unimportant_thingy: [],
      },
    }
    const mockStateMax = {
      filters: {
        amount_max: null,
        unimportant_thingy: [],
      },
    }
    const actualMin = validateBudgetMin(mockStateMin)
    const actualMax = validateBudgetMax(mockStateMax)
    expect(actualMin).toEqual(true)
    expect(actualMax).toEqual(true)
  })

  it('returns true when amount_min or amount_max is undefined', () => {
    const mockStateMin = {
      filters: {
        amount_min: undefined,
        unimportant_thingy: [],
      },
    }
    const mockStateMax = {
      filters: {
        amount_max: undefined,
        unimportant_thingy: [],
      },
    }
    const actualMin = validateBudgetMin(mockStateMin)
    const actualMax = validateBudgetMax(mockStateMax)
    expect(actualMin).toEqual(false)
    expect(actualMax).toEqual(false)
  })
})

