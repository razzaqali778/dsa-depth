import selector from '../../../../../public/scripts/selectors/audit/getQueryString'

describe('getQueryString selector', () => {
  it('gets query string', () => {
    const mockState = {
      filters: {
        amount_max: null,
        unimportant_thingy: [],
      },
    }

    const actual = selector(mockState)
    expect(actual).toEqual('?')
  })

  it('amount_max is not 0', () => {
    const mockState = {
      filters: {
        amount_max: 70534,
      },
    }

    const actual = selector(mockState)
    expect(actual).toEqual('?amount_max=70534')
  })

  it('encodesURI of a value in state', () => {
    const mockState = {
      filters: {
        amount_max: 1,
        kiwi: [ 'baloo', 'lel zer' ],
      },
    }

    const actual = selector(mockState)
    expect(actual).toEqual('?amount_max=1&kiwi=baloo%2Clel%20zer')
  })
})
