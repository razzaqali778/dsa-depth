/* eslint-disable camelcase, max-len */

import * as InitiativeTypeRules from '../../../../public/scripts/util/InitiativeTypeRules'
import selector from '../../../../public/scripts/selectors/getChangeParentOptions'


describe('getChangeParentOptions', () => {
  const initiatives = [
    { initiative_id: 'id1', initiative_name: 'name1', type_id: 'CAP-EXP-INIT', finance_code_value: '345', is_inheritable: false },
    { initiative_id: 'id2', initiative_name: 'name2', type_id: 'CAP-INIT', finance_code_value: '', is_inheritable: false },
    { initiative_id: 'id3', initiative_name: 'name3', type_id: 'CAP-PROJ', finance_code_value: '789', is_inheritable: false },
    { initiative_id: 'id4', initiative_name: 'name4', type_id: 'CAP-EXP-INIT', finance_code_value: '990', is_inheritable: true },
    { initiative_id: 'id5', initiative_name: 'name5', type_id: 'ENH', finance_code_value: '123', is_inheritable: true },
    { initiative_id: 'id6', initiative_name: 'name6', type_id: 'UNKNOWN', finance_code_value: '116', is_inheritable: true },

  ]
  const descendants = [
    { id: 'id2', initiative_name: 'name2', type_id: 'CAP-INIT' },
    { id: 'id4', initiative_name: 'name4', type_id: 'CAP-EXP-INIT' },
  ]
  const initiativeTypes = [{
    value: 'CAP-INIT',
    label: 'Capital Initiative',
  },
  {
    value: 'CAP-EXP-INIT',
    label: 'Capital Expense Initiative',
  },
  {
    value: 'EXP-INIT',
    label: 'Expense Initiative',
  },
  {
    value: 'CAP-PROJ',
    label: 'Capital Project',
  },
  {
    value: 'SUP',
    label: 'Continuous Run',
  },
  {
    value: 'FRESH',
    label: 'Fresh Run',
  },
  {
    value: 'ENH',
    label: 'Enhancement',
  }]
  const sandbox = sinon.sandbox.create()

  let determineParentTypesStub = null

  beforeEach(() => {
    determineParentTypesStub = sandbox.stub( InitiativeTypeRules, 'determineParentTypes')
    determineParentTypesStub.returns([{
      value: 'CAP-INIT',
      label: 'Capital Initiative',
    },
    {
      value: 'CAP-EXP-INIT',
      label: 'Capital Expense Initiative',
    },
    {
      value: 'EXP-INIT',
      label: 'Expense Initiative',
    },

    ])
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('removes self and all descendants from list of initiatives', () => {
    const id = 'id1'
    const typeId = 'CAP-EXP-INIT'
    const state = { initiatives, initiativeTypes, descendants, id, typeId }
    const expected = [
      { label: '(No Parent)', value: 'null' },
      { value: {
        initiative_id: 'id3',
        initiative_name: 'name3',
        type_id: 'CAP-PROJ',
        finance_code_value: '789',
        is_inheritable: false },
      label: 'name3' },
      { value: {
        initiative_id: 'id5',
        initiative_name: 'name5',
        type_id: 'ENH',
        finance_code_value: '123',
        is_inheritable: true },
      label: 'name5' },

    ]
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })

  it('only returns relevant inheritable parents when child has no finance code value', () => {
    const id = '12'
    const typeId = 'CAP-EXP-INIT'
    const financeCodeValue = null
    const hasParent = true
    const state = { initiatives, id, financeCodeValue, typeId, hasParent }
    const expected = [
      { value: {
        initiative_id: 'id4',
        initiative_name: 'name4',
        type_id: 'CAP-EXP-INIT',
        finance_code_value: '990',
        is_inheritable: true,
      },
      label: 'name4' },
      { value: {
        initiative_id: 'id5',
        initiative_name: 'name5',
        type_id: 'ENH',
        finance_code_value: '123',
        is_inheritable: true },
      label: 'name5' },
    ]
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })

  it('returns all relevant parents when child has finance code value', () => {
    const id = '12'
    const typeId = 'CAP-EXP-INIT'
    const finance_code_value = '54534'
    const hasParent = true
    const state = { initiatives, id, finance_code_value, typeId, hasParent }
    const expected = [
      { value: {
        initiative_id: 'id1',
        initiative_name: 'name1',
        type_id: 'CAP-EXP-INIT',
        finance_code_value: '345',
        is_inheritable: false,
      },
      label: 'name1' },
      { value: {
        initiative_id: 'id2',
        initiative_name: 'name2',
        type_id: 'CAP-INIT',
        finance_code_value: '',
        is_inheritable: false,
      },
      label: 'name2' },
      { value: {
        initiative_id: 'id3',
        initiative_name: 'name3',
        type_id: 'CAP-PROJ',
        finance_code_value: '789',
        is_inheritable: false },
      label: 'name3' },
      { value: {
        initiative_id: 'id4',
        initiative_name: 'name4',
        type_id: 'CAP-EXP-INIT',
        finance_code_value: '990',
        is_inheritable: true,
      },
      label: 'name4' },
      { value: {
        initiative_id: 'id5',
        initiative_name: 'name5',
        type_id: 'ENH',
        finance_code_value: '123',
        is_inheritable: true },
      label: 'name5' },
    ]
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })

  it('excludes no-parent option if initiative is child', () => {
    const id = 'id1'
    const typeId = 'CAP-EXP-INIT'
    const hasParent = true
    const state = { initiatives, initiativeTypes, descendants: [], id, typeId, hasParent }
    const expected = [
      { value: {
        initiative_id: 'id2',
        initiative_name: 'name2',
        type_id: 'CAP-INIT',
        finance_code_value: '',
        is_inheritable: false,
      },
      label: 'name2' },
      { value: {
        initiative_id: 'id3',
        initiative_name: 'name3',
        type_id: 'CAP-PROJ',
        finance_code_value: '789',
        is_inheritable: false },
      label: 'name3' },
      { value: {
        initiative_id: 'id4',
        initiative_name: 'name4',
        type_id: 'CAP-EXP-INIT',
        finance_code_value: '990',
        is_inheritable: true,
      },
      label: 'name4' },
      { value: {
        initiative_id: 'id5',
        initiative_name: 'name5',
        type_id: 'ENH',
        finance_code_value: '123',
        is_inheritable: true },
      label: 'name5' },
    ]
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })

  it('excludes UNKNOWN initiative type from the parent options', () => {
    const id = 'id1'
    const typeId = 'CAP-EXP-INIT'
    const hasParent = false
    const state = { initiatives, initiativeTypes, descendants: [], id, typeId, hasParent }
    const expected = [
      { label: '(No Parent)', value: 'null' },
      { value: {
        initiative_id: 'id2',
        initiative_name: 'name2',
        type_id: 'CAP-INIT',
        finance_code_value: '',
        is_inheritable: false,
      },
      label: 'name2' },
      { value: {
        initiative_id: 'id3',
        initiative_name: 'name3',
        type_id: 'CAP-PROJ',
        finance_code_value: '789',
        is_inheritable: false },
      label: 'name3' },
      { value: {
        initiative_id: 'id4',
        initiative_name: 'name4',
        type_id: 'CAP-EXP-INIT',
        finance_code_value: '990',
        is_inheritable: true,
      },
      label: 'name4' },
      { value: {
        initiative_id: 'id5',
        initiative_name: 'name5',
        type_id: 'ENH',
        finance_code_value: '123',
        is_inheritable: true },
      label: 'name5' },
    ]

    const actual = selector(state)
    expect(actual).toEqual(expected)
  })

  it('adds the grandparent in brackets if it exists', () => {
    const id = 'id1'
    const typeId = 'CAP-EXP-INIT'
    const hasParent = false
    const newInitiative = {
      id: 'myid',
      initiative_name: 'myname',
      type_id: 'CAP-EXP-INIT',
      finance_code_value: '345',
      is_inheritable: true,
      parent: 'parentid',
      parent_name: 'expected',
    }
    const myInitiatives = [ ...initiatives, newInitiative ]
    const state = { initiatives: myInitiatives, initiativeTypes, descendants: [], id, typeId, hasParent }
    const expected = [
      { label: '(No Parent)', value: 'null' },
      {
        label: 'myname [expected]',
        value: {
          id: 'myid',
          initiative_name: 'myname',
          type_id: 'CAP-EXP-INIT',
          finance_code_value: '345',
          is_inheritable: true,
          parent: 'parentid',
          parent_name: 'expected',
        },
      },
      { label: 'name2',
        value: {
          initiative_id: 'id2',
          initiative_name: 'name2',
          type_id: 'CAP-INIT',
          finance_code_value: '',
          is_inheritable: false } },
      { value: {
        initiative_id: 'id3',
        initiative_name: 'name3',
        type_id: 'CAP-PROJ',
        finance_code_value: '789',
        is_inheritable: false },
      label: 'name3' },
      {
        label: 'name4',
        value: {
          initiative_id: 'id4',
          initiative_name: 'name4',
          type_id: 'CAP-EXP-INIT',
          finance_code_value: '990',
          is_inheritable: true },
      },
      { value: {
        initiative_id: 'id5',
        initiative_name: 'name5',
        type_id: 'ENH',
        finance_code_value: '123',
        is_inheritable: true },
      label: 'name5' },
    ]

    const actual = selector(state)
    expect(actual).toEqual(expected)
  })
})
