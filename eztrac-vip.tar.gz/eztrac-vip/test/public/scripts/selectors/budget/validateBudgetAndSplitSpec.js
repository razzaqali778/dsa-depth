import validateBudgetAndSplit from '../../../../../public/scripts/selectors/budget/validateBudgetAndSplit'

describe('validateBudgetAndSplit', () => {
  it('returns error if no community chosen', () => {
    const mockState = {
      budget: {
        amount: 3000,
      },
      budgetSplits: [
        {
          splitValue: '',
        },
      ],
    }
    const actual = validateBudgetAndSplit(mockState)
    expect(actual).toEqual([{ err: 'Community must be chosen', index: 0 }])
  })
  it('returns error if duplicate community chosen', () => {
    const mockState = {
      budget: {
        amount: 3000,
      },
      budgetSplits: [
        {
          splitValue: 'x',
        },
        {
          splitValue: 'x',
        },
      ],
    }
    const actual = validateBudgetAndSplit(mockState)
    expect(actual).toEqual([
      { err: 'Same community can not be chosen multiple times', index: 0 },
      { err: 'Same community can not be chosen multiple times', index: 1 },
    ])
  })
})
