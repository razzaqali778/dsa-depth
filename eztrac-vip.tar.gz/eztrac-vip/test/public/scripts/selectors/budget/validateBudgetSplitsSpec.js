import validateBudgetSplits from '../../../../../public/scripts/selectors/budget/validateBudgetSplits'

describe('validateBudgetSplits', () => {
  it('returns no error if no splits', () => {
    const mockState = {
      budget: {
        amount: 3000,
      },
      budgetSplits: [],
    }
    const actual = validateBudgetSplits(mockState)
    expect(actual).toEqual({ valid: true })
  })
  it('returns error when split amount is negative', () => {
    const mockState = {
      budget: {
        amount: 3000,
      },
      budgetSplits: [{ amount: -1 }],
    }
    const actual = validateBudgetSplits(mockState)
    expect(actual).toEqual({ valid: false, message: 'Split amount cannot be a negative number' })
  })
  it('returns no error when amount is valid', () => {
    const mockState = {
      budget: {
        amount: 3000,
      },
      budgetSplits: [{ amount: 3000 }],
    }
    const actual = validateBudgetSplits(mockState)
    expect(actual).toEqual({ valid: true, message: '' })
  })
  it('returns no error when splits equal total amount', () => {
    const mockState = {
      budget: {
        amount: 3000,
      },
      budgetSplits: [{ amount: 2000 }, { amount: 1000 }],
    }
    const actual = validateBudgetSplits(mockState)
    expect(actual).toEqual({ valid: true, message: '' })
  })
  it('returns an error when splits equal total amount but are not all positive', () => {
    const mockState = {
      budget: {
        amount: 3000,
      },
      budgetSplits: [{ amount: 4000 }, { amount: -1000 }],
    }
    const actual = validateBudgetSplits(mockState)
    expect(actual).toEqual({ valid: false, message: 'Split amount cannot be a negative number' })
  })
  it('returns an error when splits do not equal total amount', () => {
    const mockState = {
      budget: {
        amount: 3000,
      },
      budgetSplits: [{ amount: 1500 }, { amount: 1000 }],
    }
    const actual = validateBudgetSplits(mockState)
    expect(actual).toEqual({ valid: false, message: 'Splits must total $3,000 -- currently $2,500' })
  })
  it('returns an error when splits exceed total amount', () => {
    const mockState = {
      budget: {
        amount: 3000,
      },
      budgetSplits: [{ amount: 1500 }, { amount: 2000 }],
    }
    const actual = validateBudgetSplits(mockState)
    expect(actual).toEqual({ valid: false, message: 'Splits must total $3,000 -- currently $3,500' })
  })
})
