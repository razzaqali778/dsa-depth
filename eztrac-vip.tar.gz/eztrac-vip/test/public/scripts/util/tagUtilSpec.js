import {
  buildTagsToSend,
  fetchTagNameMap,
  fetchTagOptions,
  fetchTagsByInitiative,
  lowestAncestralValues,
} from '../../../../public/scripts/util/tagUtil'
import agent from '../../../../public/agent'

describe('tagUtil', () => {
  const sandbox = sinon.sandbox.create()
  let agentStub = {} // eslint-disable-line

  beforeEach(() => {
    agentStub = {
      get: sandbox.stub(agent, 'get'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })
  describe('fetchTagNameMap', () => {
    it('returns a one to one map of tag codes to readable names', async () => {
      agentStub.get.resolves({
        body: [{ tag_id: 'REGION', tag_name: 'Region' }, { tag_id: 'BUS-UNIT', tag_name: 'Business Unit' }],
      })
      const expected = { REGION: 'Region', 'BUS-UNIT': 'Business Unit' }
      const result = await fetchTagNameMap()
      expect(result).toEqual(expected)
    })
  })
  describe('fetchTagOptions', () => {
    it('returns a grouped object of tag ids and acceptable values', async () => {
      agentStub.get.resolves({
        body: [
          { tag_id: 'REGION', tag_value: 'USA' },
          { tag_id: 'REGION', tag_value: 'Asia' },
          { tag_id: 'BUS-UNIT', tag_value: 'P&E' },
        ],
      })
      const expected = { REGION: [ 'USA', 'Asia' ], 'BUS-UNIT': [ 'P&E' ] }
      const result = await fetchTagOptions()
      expect(result).toEqual(expected)
    })
  })
  describe('fetchTagsByInitiative', () => {
    it('returns a mapped object of tags for a particular initiative', async () => {
      agentStub.get.resolves({
        body: [
          { initiative_id: '123', tag_id: 'REGION', tag_value: 'Asia' },
          { initiative_id: '123', tag_id: 'BUS-UNIT', tag_value: 'P&E' },
        ],
      })
      const expected = { 'BUS-UNIT': { inherited: false, name: 'P&E' }, REGION: { inherited: false, name: 'Asia' } }
      const result = await fetchTagsByInitiative('123')
      expect(result).toEqual(expected)
    })
  })
  describe('buildTagsToSend', () => {
    it('returns an empty object when given no new tags and no ancestral tags', () => {
      const newTags = {}
      const ancestralTags = [
        {
          level: 0,
          tag_id: null,
          tag_value: null,
        },
      ]
      const expected = {}
      const result = buildTagsToSend(newTags, ancestralTags)
      expect(result).toEqual(expected)
    })
    it('returns a BUS-UNIT when given only a BUS-UNIT', () => {
      const newTags = { 'BUS-UNIT': { inherited: false, name: 'P&E' } }
      const ancestralTags = [
        {
          level: 0,
          tag_id: null,
          tag_value: null,
        },
      ]
      const expected = { 'BUS-UNIT': { inherited: false, name: 'P&E' } }
      const result = buildTagsToSend(newTags, ancestralTags)
      expect(result).toEqual(expected)
    })
    it('returns both tags when given both tags in newTags', () => {
      const newTags = { 'BUS-UNIT': { inherited: false, name: 'P&E' }, REGION: { inherited: false, name: 'GLOBAL' } }
      const ancestralTags = [
        {
          level: 0,
          tag_id: null,
          tag_value: null,
        },
      ]
      const expected = { 'BUS-UNIT': { inherited: false, name: 'P&E' }, REGION: { inherited: false, name: 'GLOBAL' } }
      const result = buildTagsToSend(newTags, ancestralTags)
      expect(result).toEqual(expected)
    })
    it('returns its own when current initiative has own tags different from ancestor tags', () => {
      const newTags = { 'BUS-UNIT': { inherited: false, name: 'P&E' }, REGION: { inherited: false, name: 'GLOBAL' } }
      const ancestralTags = [
        {
          level: 0,
          tag_id: 'BUS-UNIT',
          tag_value: 'P&E',
        },
        {
          level: 0,
          tag_id: 'REGION',
          tag_value: 'GLOBAL',
        },
        {
          level: 1,
          tag_id: 'BUS-UNIT',
          tag_value: 'def',
        },
      ]
      const expected = { 'BUS-UNIT': { inherited: false, name: 'P&E' }, REGION: { inherited: false, name: 'GLOBAL' } }
      const result = buildTagsToSend(newTags, ancestralTags)
      expect(result).toEqual(expected)
    })
    it('returns inherited tag(s) if own value for specified tag(s) is null', () => {
      const newTags = { 'BUS-UNIT': { inherited: false, name: null }, REGION: { inherited: false, name: 'GLOBAL' } }
      const ancestralTags = [
        {
          level: 0,
          tag_id: 'REGION',
          tag_value: 'GLOBAL',
        },
        {
          level: 0,
          tag_id: 'BUS-UNIT',
          tag_value: 'IT',
        },
        {
          level: 1,
          tag_id: 'BUS-UNIT',
          tag_value: 'P&E',
        },
      ]
      const expected = { 'BUS-UNIT': { inherited: true, name: 'P&E' }, REGION: { inherited: false, name: 'GLOBAL' } }
      const result = buildTagsToSend(newTags, ancestralTags)
      expect(result).toEqual(expected)
    })
    it('returns inherited tag(s) if all tags in newTags are null', () => {
      const newTags = { 'BUS-UNIT': { inherited: false, name: null }, REGION: { inherited: false, name: null } }
      const ancestralTags = [
        {
          level: 0,
          tag_id: 'REGION',
          tag_value: 'GLOBAL',
        },
        {
          level: 1,
          tag_id: 'BUS-UNIT',
          tag_value: 'P&E',
        },
        {
          level: 2,
          tag_id: 'REGION',
          tag_value: 'Asia-America',
        },
      ]
      const expected = {
        'BUS-UNIT': { inherited: true, name: 'P&E' },
        REGION: { inherited: true, name: 'Asia-America' },
      }
      const result = buildTagsToSend(newTags, ancestralTags)
      expect(result).toEqual(expected)
    })
    it('returns empty object if tags are removed and there are no tags to inherit', () => {
      const newTags = { 'BUS-UNIT': { inherited: false, name: null }, REGION: { inherited: false, name: null } }
      const ancestralTags = [
        {
          level: 0,
          tag_id: 'BUS-UNIT',
          tag_value: 'IT',
        },
        {
          level: 0,
          tag_id: 'REGION',
          tag_value: 'GLOBAL',
        },
        {
          level: 1,
          tag_id: null,
          tag_value: null,
        },
      ]
      const expected = {}
      const result = buildTagsToSend(newTags, ancestralTags)
      expect(result).toEqual(expected)
    })
    it('keeps its one own tag when one is removed and there are none to inherit', () => {
      const newTags = { 'BUS-UNIT': { inherited: false, name: 'IT' }, REGION: { inherited: false, name: null } }

      const ancestralTags = [
        {
          level: 0,
          tag_id: 'REGION',
          tag_value: 'GLOBAL',
        },
        {
          level: 1,
          tag_id: 'BUS-UNIT',
          tag_value: 'P&E',
        },
        {
          level: 2,
          tag_id: null,
          tag_value: null,
        },
      ]
      const expected = {
        'BUS-UNIT': { inherited: false, name: 'IT' },
      }
      const result = buildTagsToSend(newTags, ancestralTags)
      expect(result).toEqual(expected)
    })
    it('returns inherited tag(s) if own value for specified tag(s) is missing', () => {
      const newTags = { 'BUS-UNIT': { inherited: false, name: null } }
      const ancestralTags = [
        {
          level: 1,
          tag_id: 'REGION',
          tag_value: 'GLOBAL',
        },
        {
          level: 0,
          tag_id: 'BUS-UNIT',
          tag_value: 'IT',
        },
        {
          level: 1,
          tag_id: 'BUS-UNIT',
          tag_value: 'P&E',
        },
      ]
      const expected = { 'BUS-UNIT': { inherited: true, name: 'P&E' }, REGION: { inherited: true, name: 'GLOBAL' } }
      const result = buildTagsToSend(newTags, ancestralTags)
      expect(result).toEqual(expected)
    })
  })
})

describe('lowestAncestralValues', () => {
  it('returns first unique tags by level', () => {
    const ancestralTags = [
      {
        level: 0,
        tag_id: null,
        tag_value: null,
      },
      {
        level: 1,
        tag_id: 'BUS-UNIT',
        tag_value: 'Fancy stuff',
      },
      {
        level: 2,
        tag_id: 'BUS-UNIT',
        tag_value: 'P&E',
      },
      {
        level: 2,
        tag_id: 'REGION',
        tag_value: 'Asia-America',
      },
    ]
    const expected = {
      'BUS-UNIT': { inherited: true, name: 'P&E' },
      REGION: { inherited: true, name: 'Asia-America' },
    }
    const result = lowestAncestralValues(ancestralTags)
    expect(result).toEqual(expected)
  })
})
