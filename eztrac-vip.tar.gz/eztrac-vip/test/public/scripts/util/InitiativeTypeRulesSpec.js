import {
  determineChildTypes,
  determineEditTypes,
  determineParentTypes,
  getInitiativeTypeRules,
} from '../../../../public/scripts/util/InitiativeTypeRules'

describe('getInitiativeTypeRules', () => {
  describe('initiativeTypeRules return correct type rules', () => {
    it('for a Capital Project', () => {
      const selectedType = {
        value: 'CAP-PROJ',
        label: 'Capital Project',
      }
      const initiative = {
        is_allocable: true,
      }
      const expected = {
        allocationCheckboxDisabled: true,
        financeCodeTypeLabel: 'SAP Project',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: true,
        initiative: {
          finance_code_type: 'SAP Project',
          type_id: selectedType.value,
          type_name: selectedType.label,
          is_inheritable: false,
          is_allocable: false,
        },
      }

      const result = getInitiativeTypeRules(selectedType, initiative)

      expect(result).toEqual(expected)
    })

    it('for a Capital Initiative', () => {
      const selectedType = {
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      }
      const initiative = {
        is_allocable: true,
      }
      const expected = {
        allocationCheckboxDisabled: false,
        financeCodeTypeLabel: 'WBS Element',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: {
          finance_code_type: 'WBS Element',
          type_id: selectedType.value,
          type_name: selectedType.label,
          is_allocable: true,
          is_inheritable: true,
        },
      }

      const result = getInitiativeTypeRules(selectedType, initiative)

      expect(result).toEqual(expected)
    })
    it('for an Expense Initiative', () => {
      const selectedType = {
        value: 'EXP-INIT',
        label: 'Expense Initiative',
      }
      const initiative = {
        is_allocable: true,
      }
      const expected = {
        allocationCheckboxDisabled: false,
        financeCodeTypeLabel: 'Cost Center',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: {
          finance_code_type: 'Cost Center',
          type_id: selectedType.value,
          type_name: selectedType.label,
          is_allocable: true,
          is_inheritable: true,
        },
      }

      const result = getInitiativeTypeRules(selectedType, initiative)

      expect(result).toEqual(expected)
    })
    it('for a Capital Expense Initiative', () => {
      const selectedType = {
        value: 'CAP-EXP-INIT',
        label: 'Capital Expense',
      }
      const initiative = {
        is_allocable: true,
      }
      const expected = {
        allocationCheckboxDisabled: false,
        financeCodeTypeLabel: 'WBS Element',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: {
          finance_code_type: 'WBS Element',
          type_id: selectedType.value,
          type_name: selectedType.label,
          is_allocable: true,
          is_inheritable: true,
        },
      }

      const result = getInitiativeTypeRules(selectedType, initiative)

      expect(result).toEqual(expected)
    })
    it('for top-level Continuous Run', () => {
      const selectedType = {
        value: 'SUP',
        label: 'Continuous Run',
      }
      const initiative = {
        is_allocable: false,
      }
      const expected = {
        allocationCheckboxDisabled: true,
        financeCodeTypeLabel: 'Cost Center',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: {
          finance_code_type: 'Cost Center',
          type_id: selectedType.value,
          type_name: selectedType.label,
          is_allocable: true,
          is_inheritable: true,
        },
      }


      const result = getInitiativeTypeRules(selectedType, initiative)

      expect(result).toEqual(expected)
    })
    it('for top-level Fresh Run', () => {
      const selectedType = {
        value: 'FRESH',
        label: 'Fresh Run',
      }
      const initiative = {
        is_allocable: false,
      }
      const expected = {
        allocationCheckboxDisabled: true,
        financeCodeTypeLabel: 'Cost Center',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: {
          finance_code_type: 'Cost Center',
          type_id: selectedType.value,
          type_name: selectedType.label,
          is_allocable: true,
          is_inheritable: true,
        },
      }


      const result = getInitiativeTypeRules(selectedType, initiative)

      expect(result).toEqual(expected)
    })
    it('for top-level Enhancement', () => {
      const selectedType = {
        value: 'ENH',
        label: 'Enhancement',
      }
      const initiative = {
        is_allocable: false,
      }
      const expected = {
        allocationCheckboxDisabled: true,
        financeCodeTypeLabel: 'Cost Center',
        hideFinanceCodeInput: true,
        hideFinanceCodeInheritableCheckbox: true,
        initiative: {
          finance_code_type: 'Cost Center',
          type_id: selectedType.value,
          type_name: selectedType.label,
          is_allocable: false,
          is_inheritable: false,
        },
      }


      const result = getInitiativeTypeRules(selectedType, initiative)

      expect(result).toEqual(expected)
    })
    it('for top-level Operations', () => {
      const selectedType = {
        value: 'OPS',
        label: 'Operations',
      }
      const initiative = {
        is_allocable: false,
      }
      const expected = {
        allocationCheckboxDisabled: true,
        financeCodeTypeLabel: 'Cost Center',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: {
          finance_code_type: 'Cost Center',
          type_id: selectedType.value,
          type_name: selectedType.label,
          is_allocable: true,
          is_inheritable: true,
        },
      }


      const result = getInitiativeTypeRules(selectedType, initiative)

      expect(result).toEqual(expected)
    })
  })
  describe('determineChildTypes returns correct child types', () => {
    const initiativeTypes = [{
      value: 'CAP-INIT',
      label: 'Capital Initiative',
    },
    {
      value: 'CAP-EXP-INIT',
      label: 'Capital Expense Initiative',
    },
    {
      value: 'EXP-INIT',
      label: 'Expense Initiative',
    },
    {
      value: 'CAP-PROJ',
      label: 'Capital Project',
    },
    {
      value: 'SUP',
      label: 'Continuous Run',
    },
    {
      value: 'FRESH',
      label: 'Fresh Run',
    },
    {
      value: 'ENH',
      label: 'Enhancement',
    },
    {
      value: 'OPS',
      label: 'Operations',
    }]
    it('returns the correct child types for CAP-PROJ', () => {
      const parentType = 'CAP-PROJ'
      const expected = [{
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      },
      {
        value: 'CAP-EXP-INIT',
        label: 'Capital Expense Initiative',
      }]
      const result = determineChildTypes(parentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct child types for EXP-INIT', () => {
      const parentType = 'EXP-INIT'
      const expected = [{
        value: 'EXP-INIT',
        label: 'Expense Initiative',
      }]
      const result = determineChildTypes(parentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct child types for CAP-EXP-INIT', () => {
      const parentType = 'CAP-EXP-INIT'
      const expected = [{
        value: 'CAP-EXP-INIT',
        label: 'Capital Expense Initiative',
      }]
      const result = determineChildTypes(parentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct child types for CAP-INIT', () => {
      const parentType = 'CAP-INIT'
      const expected = [{
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      },
      {
        value: 'CAP-EXP-INIT',
        label: 'Capital Expense Initiative',
      }]
      const result = determineChildTypes(parentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct child types for Continuous Run', () => {
      const parentType = 'SUP'
      const expected = [{
        value: 'SUP',
        label: 'Continuous Run',
      }]
      const result = determineChildTypes(parentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct child types for Fresh Run', () => {
      const parentType = 'FRESH'
      const expected = [{
        value: 'FRESH',
        label: 'Fresh Run',
      }]
      const result = determineChildTypes(parentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct child types for Enhancement', () => {
      const parentType = 'ENH'
      const expected = [{
        value: 'ENH',
        label: 'Enhancement',
      }]
      const result = determineChildTypes(parentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct child types for Operations', () => {
      const parentType = 'OPS'
      const expected = [{
        value: 'OPS',
        label: 'Operations',
      }]
      const result = determineChildTypes(parentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct child types for Unknown', () => {
      const parentType = 'UNKNOWN'

      const result = determineChildTypes(parentType, initiativeTypes)
      expect(result).toEqual([])
    })
  })
  describe('determineParentTypes returns correct parent types', () => {
    const initiativeTypes = [{
      value: 'CAP-INIT',
      label: 'Capital Initiative',
    },
    {
      value: 'CAP-EXP-INIT',
      label: 'Capital Expense Initiative',
    },
    {
      value: 'EXP-INIT',
      label: 'Expense Initiative',
    },
    {
      value: 'CAP-PROJ',
      label: 'Capital Project',
    },
    {
      value: 'SUP',
      label: 'Continuous Run',
    },
    {
      value: 'FRESH',
      label: 'Fresh Run',
    },
    {
      value: 'ENH',
      label: 'Enhancement',
    },
    {
      value: 'OPS',
      label: 'Operations',
    }]
    it('returns the correct parent types for CAP-PROJ', () => {
      const currentType = 'CAP-PROJ'
      const expected = []
      const result = determineParentTypes(currentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct parent types for EXP-INIT', () => {
      const currentType = 'EXP-INIT'
      const expected = [{
        value: 'EXP-INIT',
        label: 'Expense Initiative',
      }]
      const result = determineParentTypes(currentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct parent types for CAP-EXP-INIT', () => {
      const currentType = 'CAP-EXP-INIT'
      const expected = [{
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      },
      {
        value: 'CAP-EXP-INIT',
        label: 'Capital Expense Initiative',
      },
      {
        value: 'CAP-PROJ',
        label: 'Capital Project',
      }]
      const result = determineParentTypes(currentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct parent types for CAP-INIT', () => {
      const currentType = 'CAP-INIT'
      const expected = [{
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      },
      {
        value: 'CAP-PROJ',
        label: 'Capital Project',
      }]
      const result = determineParentTypes(currentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct parent types for Continuous Run', () => {
      const currentType = 'SUP'
      const expected = [{
        value: 'SUP',
        label: 'Continuous Run',
      }]
      const result = determineParentTypes(currentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct parent types for Fresh Run', () => {
      const currentType = 'FRESH'
      const expected = [{
        value: 'FRESH',
        label: 'Fresh Run',
      }]
      const result = determineParentTypes(currentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct parent types for Enhancement', () => {
      const currentType = 'ENH'
      const expected = [{
        value: 'ENH',
        label: 'Enhancement',
      }]
      const result = determineParentTypes(currentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct parent types for Operations', () => {
      const currentType = 'OPS'
      const expected = [{
        value: 'OPS',
        label: 'Operations',
      }]
      const result = determineParentTypes(currentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns the correct parent types for Unknown', () => {
      const currentType = 'UNKNOWN'
      const expected = []
      const result = determineParentTypes(currentType, initiativeTypes)
      expect(result).toEqual(expected)
    })
  })
  describe('determineEditTypes', () => {
    const initiativeTypes = [{
      value: 'CAP-INIT',
      label: 'Capital Initiative',
    },
    {
      value: 'CAP-EXP-INIT',
      label: 'Capital Expense Initiative',
    },
    {
      value: 'EXP-INIT',
      label: 'Expense Initiative',
    },
    {
      value: 'CAP-PROJ',
      label: 'Capital Project',
    },
    {
      value: 'SUP',
      label: 'Continuous Run',
    },
    {
      value: 'FRESH',
      label: 'Fresh Run',
    },
    {
      value: 'ENH',
      label: 'Enhancement',
    },
    {
      value: 'OPS',
      label: 'Operations',
    }]
    it('returns correct types for initiative with no child types', () => {
      const currentType = 'CAP-INIT'
      const parentType = 'CAP-PROJ'
      const childrenInitiatives = []
      const expected = [{
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      },
      {
        value: 'CAP-EXP-INIT',
        label: 'Capital Expense Initiative',
      }]
      const result = determineEditTypes(currentType, parentType, childrenInitiatives, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns correct types for initiative with one child type', () => {
      const currentType = 'CAP-INIT'
      const parentType = 'CAP-PROJ'
      const childrenInitiatives = [{
        type_id: 'CAP-INIT',
      }]
      const expected = [{
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      }]
      const result = determineEditTypes(currentType, parentType, childrenInitiatives, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns correct types for initiative with multiple child types', () => {
      const currentType = 'CAP-INIT'
      const parentType = 'CAP-PROJ'
      const childrenInitiatives = [{
        type_id: 'CAP-INIT',
      },
      {
        type_id: 'CAP-EXP-INIT',
      }]
      const expected = [{
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      }]
      const result = determineEditTypes(currentType, parentType, childrenInitiatives, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns correct types for top-level initiative with no parent', () => {
      const currentType = 'CAP-PROJ'
      const parentType = undefined
      const childrenInitiatives = [{
        type_id: 'CAP-INIT',
      }]
      const expected = [{
        value: 'CAP-PROJ',
        label: 'Capital Project',
      }]
      const result = determineEditTypes(currentType, parentType, childrenInitiatives, initiativeTypes)
      expect(result).toEqual(expected)
    })

    it('returns correct types when only child is UNKNOWN', () => {
      const currentType = 'CAP-INIT'
      const parentType = 'CAP-PROJ'
      const childrenInitiatives = [{
        type_id: 'UNKNOWN',
      }]
      const expected = [{
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      },
      {
        value: 'CAP-EXP-INIT',
        label: 'Capital Expense Initiative',
      }]
      const result = determineEditTypes(currentType, parentType, childrenInitiatives, initiativeTypes)
      expect(result).toEqual(expected)
    })
    it('returns correct types when children contain some UNKNOWN types', () => {
      const currentType = 'CAP-INIT'
      const parentType = 'CAP-PROJ'
      const childrenInitiatives = [{
        type_id: 'UNKNOWN',
      },
      {
        type_id: 'CAP-INIT',
      },
      {
        type_id: 'CAP-EXP-INIT',
      }]
      const expected = [{
        value: 'CAP-INIT',
        label: 'Capital Initiative',
      }]
      const result = determineEditTypes(currentType, parentType, childrenInitiatives, initiativeTypes)
      expect(result).toEqual(expected)
    })
  })
})
