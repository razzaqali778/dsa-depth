import { sortByMatchingFirst } from '../../../../public/scripts/util/ReactSelectUtil'

describe('reactSelectUtil', () => {
  it('reorders an array of objects beginning with the search string.', () => {
    const mockArray = [
      { label: 'Anger Core' },
      { label: 'Central Core' },
      { label: 'Curiosity Core' },
      { label: 'Intelligence Core' },
      { label: 'Morality Core' },
    ]
    const mockSearchString = 'C'

    const expected = [
      { label: 'Central Core' },
      { label: 'Curiosity Core' },
      { label: 'Anger Core' },
      { label: 'Intelligence Core' },
      { label: 'Morality Core' },
    ]

    const actual = sortByMatchingFirst(mockArray, mockSearchString)

    expect(actual).toEqual(expected)
  })
})
