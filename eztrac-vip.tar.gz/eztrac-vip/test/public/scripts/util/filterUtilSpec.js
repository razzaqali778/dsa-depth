import { modifyFilters } from '../../../../public/scripts/util/filterUtil'

describe('filterUtil', () => {
  describe('modifyFilters', () => {
    it('updates state with new value for filter with no value', async () => {
      const mockState = {
        filters: {
          meme_queen: '',
          oh_snap: 'shouldnt be altered',
        },
      }
      const mockFilterName = 'meme_queen'
      const mockValue = 'Channon'

      const expected = {
        meme_queen: 'Channon',
        oh_snap: 'shouldnt be altered',
      }

      const actual = await modifyFilters(mockState, mockValue, mockFilterName)

      expect(actual).toEqual(expected)
    })

    it('changes the original filter value in state with new value', async () => {
      const mockState = {
        filters: {
          best_sandwich: 'some cafe',
          best_bagels: 'Louis IX of France bread corporation',
        },
      }
      const mockFilterName = 'best_sandwich'
      const mockValue = 'compatriot boulangerie'

      const expected = {
        best_sandwich: 'compatriot boulangerie',
        best_bagels: 'Louis IX of France bread corporation',
      }

      const actual = await modifyFilters(mockState, mockValue, mockFilterName)

      expect(actual).toEqual(expected)
    })

    it('handles arrays, removing value if found', async () => {
      const mockState = {
        filters: {
          dog_sounds: [ 'arf', 'bork', 'woof' ],
          oh_snap: 'shouldnt be altered',
        },
      }
      const mockFilterName = 'dog_sounds'
      const mockValue = 'woof'

      const expected = {
        dog_sounds: [ 'arf', 'bork' ],
        oh_snap: 'shouldnt be altered',
      }

      const actual = await modifyFilters(mockState, mockValue, mockFilterName)

      expect(actual).toEqual(expected)
    })

    it('handles arrays, adding a value that was not previously  there', async () => {
      const mockState = {
        filters: {
          dog_sounds: [ 'arf', 'bork', 'woof' ],
          oh_snap: 'shouldnt be altered',
        },
      }
      const mockFilterName = 'dog_sounds'
      const mockValue = 'oh hai'

      const expected = {
        dog_sounds: [ 'arf', 'bork', 'woof', 'oh hai' ],
        oh_snap: 'shouldnt be altered',
      }

      const actual = await modifyFilters(mockState, mockValue, mockFilterName)

      expect(actual).toEqual(expected)
    })

    it('resets an array filter value', async () => {
      const mockState = {
        filters: {
          blue: [ 'im', 'dabudi' ],
          dabudai: 'dabudidabudai',
        },
      }
      const mockFilterName = 'blue'
      const mockValue = 'dabudi'

      const expected = {
        ...mockState.filters,
        blue: [ 'im' ],
      }

      const actual = await modifyFilters(mockState, mockValue, mockFilterName)

      expect(actual).toEqual(expected)
    })

    it('resets a single filter value', async () => {
      const mockState = {
        filters: {
          blue: [ 'im', 'dabudi' ],
          dabudai: 'dabudidabudai',
        },
      }
      const mockFilterName = 'dabudai'
      const mockValue = 'dabudidabudai'

      const expected = {
        ...mockState.filters,
        dabudai: 'dabudidabudai',
      }

      const actual = await modifyFilters(mockState, mockValue, mockFilterName)

      expect(actual).toEqual(expected)
    })

    it('replaces string values with the new value in the filter', async () => {
      const mockState = {
        filters: {
          blue: 'dabudi',
          dabudai: 'dabudidabudai',
        },
      }
      const mockFilterName = 'blue'
      const mockValue = 'bloop'

      const expected = {
        ...mockState.filters,
        blue: 'bloop',
      }

      const actual = await modifyFilters(mockState, mockValue, mockFilterName)

      expect(actual).toEqual(expected)
    })

    it('doesnt change anything in state and returns false if bad values are passed in', async () => {
      const mockState = {
        filters: {
          weedle: 'deedle',
          leedle: 'lee',
        },
      }

      const mockFilterName = 'nonexistent'
      const mockValue = 'THE VOID'

      const actual = await modifyFilters(mockState, mockValue, mockFilterName)

      expect(actual).toEqual(false)
    })
  })
})
