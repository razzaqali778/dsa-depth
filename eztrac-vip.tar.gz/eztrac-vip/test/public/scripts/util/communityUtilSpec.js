import { getCommunityList } from '../../../../public/scripts/util/communityUtil'
import agent from '../../../../public/agent'

jest.mock('../../../../public/agent')

describe('test community list', () => {
  const sandbox = sinon.sandbox.create()
  let agentStub = {} // eslint-disable-line

  beforeEach(() => {
    agentStub = {
      post: sandbox.stub(agent, 'get'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('returns only active communities', async () => {
    const stuffCommunity = {
      id: 'STUFF-PLATFORM',
      name: 'Stuff Community',
      isActive: true,
      platformId: 'STUFF-PLATFORM',
    }
    const inActiveCommunity = {
      id: 'INACTIVE-PLATFORM',
      name: 'Inactive Community',
      isActive: false,
      platformId: 'INACTIVE-PLATFORM',
    }
    const fakeResults = [ stuffCommunity, inActiveCommunity ]
    agent.get.resolves({ body: fakeResults } )
    const result = await getCommunityList()
    expect(result).toEqual([ stuffCommunity ])
  })
})
