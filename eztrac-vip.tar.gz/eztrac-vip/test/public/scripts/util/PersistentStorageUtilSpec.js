import PersistentStorageUtil from '../../../../public/scripts/util/PersistentStorageUtil'

describe('PersistentStorageUtil', () => {
  beforeEach(() => {
    PersistentStorageUtil.persistentStore = {}
  })
  describe('addField', () => {
    it('stores the input values.', () => {
      const dummyObject = {
        data: 'Hello world',
      }

      PersistentStorageUtil.persistentStore.existingField = 'someString'

      const expected = {
        existingField: 'someString',
        dummyObjectKey: {
          data: 'Hello world',
        },
      }

      PersistentStorageUtil.addField('dummyObjectKey', dummyObject)
      expect(PersistentStorageUtil.persistentStore).toEqual(expected)
    })
    it('overwrites already existing key with new values', () => {
      const expected = {
        dummyObjectKey: 'Goodbye world',
      }
      PersistentStorageUtil.persistentStore.dummyObjectKey = 'Hello World'
      PersistentStorageUtil.addField('dummyObjectKey', 'Goodbye world')
      expect(PersistentStorageUtil.persistentStore).toEqual(expected)
    })
  })
  describe('getField', () => {
    it('obtains value for a given key', () => {
      PersistentStorageUtil.persistentStore.dummyObjectKey = 'Hello World'
      const expected = 'Hello World'
      const returnedVal = PersistentStorageUtil.getField('dummyObjectKey')
      expect(returnedVal).toEqual(expected)
    })
  })
})
