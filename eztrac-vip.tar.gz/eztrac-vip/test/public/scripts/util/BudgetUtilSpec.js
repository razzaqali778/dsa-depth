import {
  applyCurrencyConversion,
  formatAmount,
  formatChildrenForChart,
  formatInitiativesForSelect,
  getFiscalYears,
  getSumOfChildren,
  makePieChartSlicesBySplits,
  orderBudgets,
  unapplyCurrencyConversion,
} from '../../../../public/scripts/util/BudgetUtil'
import { fn as momentProto } from 'moment'
import isUndefined from 'lodash/isUndefined'

describe('BudgetUtil', () => {
  const sandbox = sinon.sandbox.create()
  let momentStub = {}

  beforeEach(() => {
    momentStub = {
      month: sandbox.stub(momentProto, 'month'),
      year: sandbox.stub(momentProto, 'year'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('orderBudgets', () => {
    it('returns a list of initiatives ordered by the provided field', () => {
      const budget1 = { fiscalYear: '2018' }
      const budget2 = { fiscalYear: '2010' }
      const budget3 = { fiscalYear: '2017' }

      const sortedList = orderBudgets([ budget1, budget2, budget3 ], 'fiscalYear')

      expect(sortedList[0]).toEqual(budget2)
      expect(sortedList[1]).toEqual(budget3)
      expect(sortedList[2]).toEqual(budget1)
    })

    it('returns a reversed list of initiatives ordered by the provided field when ordering is provided', () => {
      const budget1 = { fiscalYear: '2018' }
      const budget2 = { fiscalYear: '2010' }
      const budget3 = { fiscalYear: '2017' }

      const sortedList = orderBudgets([ budget1, budget2, budget3 ], 'fiscalYear', [ 'desc' ])

      expect(sortedList[0]).toEqual(budget1)
      expect(sortedList[1]).toEqual(budget3)
      expect(sortedList[2]).toEqual(budget2)
    })
  })

  describe('getFiscalYears', () => {
    it('returns the current and two next years when no budgets exist', () => {
      momentStub.month.returns(0)
      momentStub.year.returns(2017)
      const expected = [
        { value: '2017', label: '2017', id: 'fiscalYear' },
        { value: '2018', label: '2018', id: 'fiscalYear' },
        { value: '2019', label: '2019', id: 'fiscalYear' },
      ]

      const result = getFiscalYears([])

      expect(result).toEqual(expected)
    })

    /*
    it('returns the correct first year when calendar and fiscal dont match', () => {
      momentStub.month.returns(10)
      momentStub.year.returns(2017)
      const expected = [
        { value: '2018', label: '2018', id: 'fiscalYear' },
        { value: '2019', label: '2019', id: 'fiscalYear' },
        { value: '2020', label: '2020', id: 'fiscalYear' },
      ]

      const result = getFiscalYears([])

      expect(result).toEqual(expected)
    })
*/
    it('returns a filtered list of years when budgets have already been created for some of them', () => {
      momentStub.month.returns(0)
      momentStub.year.returns(2017)
      const expected = [
        { value: '2018', label: '2018', id: 'fiscalYear' },
        { value: '2019', label: '2019', id: 'fiscalYear' },
      ]
      const budgets = [{ fiscalYear: '2017' }]

      const result = getFiscalYears(budgets)

      expect(result).toEqual(expected)
    })
  })

  describe('formatInitiativesForSelect', () => {
    it('returns a list of properly formatted initiatives', () => {
      const initiatives = [
        { initiative_id: '123', name: 'test 1' },
        { initiative_id: '456', name: 'test 2' },
      ]
      const expected = [
        { value: '123', label: 'test 1', id: 'initiative_id' },
        { value: '456', label: 'test 2', id: 'initiative_id' },
      ]

      expect(formatInitiativesForSelect(initiatives)).toEqual(expected)
    })
  })

  describe('formatChildrenForChart', () => {
    it('assigns a fill color to each of the children', () => {
      const budget = { amount: 3, children: [{ amount: 1 }, { amount: 2 }] }

      formatChildrenForChart(budget)

      expect(isUndefined(budget.children[0].fill)).toBe(false)
      expect(isUndefined(budget.children[1].fill)).toBe(false)
    })

    it('returns a list of slices for the pie chart', () => {
      const budget = { amount: 3, children: [{ amount: 1 }, { amount: 2 }] }

      const result = formatChildrenForChart(budget)

      expect(result.length).toEqual(2)
      expect(result[0]).toEqual({ color: '#2196F3', value: 1 })
      expect(result[1]).toEqual({ color: '#9C27B0', value: 2 })
    })

    it('adds an additional slice when the sum of the children is less than the total', () => {
      const budget = { amount: 5, children: [{ amount: 1 }, { amount: 2 }] }

      const result = formatChildrenForChart(budget)

      expect(result.length).toEqual(3)
      expect(result[2]).toEqual({ color: '#BDBDBD', value: 2 })
    })

    it('sets a single error slice when the sum of the children is greater than the total', () => {
      const budget = { amount: 1, children: [{ amount: 1 }, { amount: 2 }] }

      const result = formatChildrenForChart(budget)

      expect(result.length).toEqual(1)
      expect(result[0]).toEqual({ color: '#F44336', value: 1 })
    })
  })

  describe('getSumOfChildren', () => {
    it('returns the sum of all of the children amounts', () => {
      const budget = {
        children: [
          { amount: 1000 },
          { amount: 50 },
          { amount: 60000 },
        ],
      }

      expect(getSumOfChildren(budget)).toEqual(61050)
    })
  })

  describe('formatAmount', () => {
    it('returns the amount formatted as american dollars without cents', () => {
      expect(formatAmount(2000000)).toEqual('$2,000,000')
    })
  })

  describe('applyCurrencyConversion', () => {
    it('returns the amount converted into thousands if amount is not undefined', () => {
      const amount = 77000
      const result = applyCurrencyConversion(amount)
      expect(result).toEqual(77)
    })

    it('returns zero if the amount is undefined', () => {
      const result = applyCurrencyConversion(undefined)
      expect(result).toEqual(0)
    })
  })

  describe('unapplyCurrencyConversion', () => {
    it('returns the amount multiplied by 1000 if amount is not undefined', () => {
      const amount = 77
      const result = unapplyCurrencyConversion(amount)
      expect(result).toEqual(77000)
    })

    it('returns zero if the amount is undefined', () => {
      const result = unapplyCurrencyConversion(undefined)
      expect(result).toEqual(0)
    })
  })

  describe('makes pie chart data by splits', () => {
    const budget = {
      splits: [{
        splitField: 'COMMUNITY',
        splitValue: 'BOB-COMMUNITY',
        amount: 500,
      }, {
        splitField: 'COMMUNITY',
        splitValue: 'BILL-COMMUNITY',
        amount: 300,
      }, {
        splitField: 'COMMUNITY',
        splitValue: 'FIELD-MAKE',
        amount: 700,
      }],
    }

    const communityList = [
      { id: 'BOB-COMMUNITY', name: 'Bob Community' },
      { id: 'BILL-COMMUNITY', name: 'Bill community' },
      { id: 'FIELD-MAKE', name: 'Field Make' },
    ]

    const expected = {
      datasets: [{
        backgroundColor: [ '#55ED91', '#F32183', '#4AEF01' ],
        data: [ 500, 300, 700 ],
        label: 'Budget Split',
      }],
      labels: [ 'Bob', 'Bill', 'Field Make' ],
    }

    expect(makePieChartSlicesBySplits(budget, communityList)).toEqual(expected)
  })
})
