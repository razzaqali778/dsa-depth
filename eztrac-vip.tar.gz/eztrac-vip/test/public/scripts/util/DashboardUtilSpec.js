import * as tagUtil from '../../../../public/scripts/util/tagUtil'
import { getInitiatives } from '../../../../public/scripts/util/DashboardUtil'
import agent from '../../../../public/agent'

describe('DashboardUtil', () => {
  const sandbox = sinon.sandbox.create()
  let agentStub = {}

  beforeEach(() => {
    agentStub = {
      get: sandbox.stub(agent, 'get'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('getInitiatives', () => {
    it('retrieves initiatives from api', async () => {
      const initativeResponseMock = { body: [ ] }
      const tagsResponseMock = []
      sinon.stub(tagUtil, 'fetchInitiativeTagsMap')
      tagUtil.fetchInitiativeTagsMap.resolves(tagsResponseMock)
      agentStub.get.resolves(initativeResponseMock)
      const expected = []
      const result = await getInitiatives()
      expect(result).toEqual(expected)
    })

    it('fails gracefully when initiatives are not returned from api', async () => {
      expect.assertions(1)
      const errorMock = { errorType: 'Failed GET', error: '500' }
      agentStub.get.throws(errorMock)
      await expect(getInitiatives()).rejects.toEqual({ errorType: 'Failed GET', error: '500' })
    })
  })
})
