import UserRolesUtil from '../../../../public/scripts/util/UserRolesUtil'
import profileClient from '@monsantoit/profile-client'

const testUserProfile = {
  getCurrentUser: {
    entitlements: [
      { code: 'vip-read-user' },
    ],
  },
}

const testRWUserProfile = {
  getCurrentUser: {
    entitlements: [
      { code: 'vip-read-write-user' },
    ],
  },
}
const testNoRoles = {
  getCurrentUser: {
    entitlements: [
      { code: 'something' },
    ],
  },
}

describe('UserRolesUtil', () => {
  const sandbox = sinon.sandbox.create()
  let profileClientStub = {}

  beforeEach(() => {
    profileClientStub = {
      queryProfile: sandbox.stub(profileClient, 'queryProfile'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('hasEitherRole', () => {
    it('returns true when the user has the read role', async () => {
      profileClientStub.queryProfile.resolves(testUserProfile)

      expect(await UserRolesUtil.hasEitherRole()).toBe(true)
    })

    it('returns true when the user has the write role', async () => {
      profileClientStub.queryProfile.resolves(testUserProfile)

      expect(await UserRolesUtil.hasEitherRole()).toBe(true)
    })

    it('returns false when the user has neither roles', async () => {
      profileClientStub.queryProfile.resolves(testNoRoles)

      expect(await UserRolesUtil.hasEitherRole()).toBe(false)
    })
  })

  describe('hasReadWriteRole', () => {
    it('returns true when the user has the write role', async () => {
      profileClientStub.queryProfile.resolves(testRWUserProfile)

      expect(await UserRolesUtil.hasReadWriteRole()).toBe(true)
    })

    it('returns false when the user does not have the write role', async () => {
      profileClientStub.queryProfile.resolves(testUserProfile)

      expect(await UserRolesUtil.hasReadWriteRole()).toBe(false)
    })
  })
})
