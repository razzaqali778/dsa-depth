import * as InitiativeUtil from '../../../../public/scripts/util/InitiativeUtil'

describe('InitiativeUtil', () => {
  describe('formatInitiativeStatuses', () => {
    it('returns an empty list when no statuses are found', () => {
      const statuses = undefined

      const result = InitiativeUtil.formatInitiativeStatuses(statuses)

      expect(result.length).toEqual(0)
    })

    it('returns a list of status objects when found', () => {
      const statuses = [{ initiative_status_value: 'Funded' }, { initiative_status_value: 'Complete' }]

      const result = InitiativeUtil.formatInitiativeStatuses(statuses)

      expect(result.length).toEqual(2)
      expect(result[0].value).toEqual(statuses[0].initiative_status_value)
      expect(result[0].label).toEqual(statuses[0].initiative_status_value)
      expect(result[1].value).toEqual(statuses[1].initiative_status_value)
      expect(result[1].label).toEqual(statuses[1].initiative_status_value)
    })
  })

  describe('formatFinanceCodeTypes', () => {
    it('returns an empty list when no financeCodeTypes are found', () => {
      const financeCodeTypes = undefined

      const result = InitiativeUtil.formatFinanceCodeTypes(financeCodeTypes)

      expect(result.length).toEqual(0)
    })

    it('returns a list of financeCodeTypes objects when found', () => {
      const financeCodeTypes = [{ financial_tag_type_value: 'Funded' }, { financial_tag_type_value: 'Complete' }]

      const result = InitiativeUtil.formatFinanceCodeTypes(financeCodeTypes)

      expect(result.length).toEqual(2)
      expect(result[0].value).toEqual(financeCodeTypes[0].financial_tag_type_value)
      expect(result[0].label).toEqual(financeCodeTypes[0].financial_tag_type_value)
      expect(result[1].value).toEqual(financeCodeTypes[1].financial_tag_type_value)
      expect(result[1].label).toEqual(financeCodeTypes[1].financial_tag_type_value)
    })
  })

  describe('orderInitiatives', () => {
    it('returns a list of initiatives ordered by the provided field', () => {
      const initiative1 = { initiative_name: 'Zebra', status: '' }
      const initiative2 = { initiative_name: 'zebra', status: '' }
      const initiative3 = { initiative_name: 'Apple', status: '' }
      const initiative4 = { initiative_name: 'apple', status: '' }

      const sortedList = InitiativeUtil.orderInitiatives([ initiative1, initiative2, initiative3, initiative4 ],
        'initiative_name')

      expect(sortedList[0]).toEqual(initiative3)
      expect(sortedList[1]).toEqual(initiative4)
      expect(sortedList[2]).toEqual(initiative1)
      expect(sortedList[3]).toEqual(initiative2)
    })

    it('returns a reversed list of initiatives ordered by the provided field when ordering is provided', () => {
      const initiative1 = { initiative_name: 'Zebra', status: '' }
      const initiative2 = { initiative_name: 'zebra', status: '' }
      const initiative3 = { initiative_name: 'Apple', status: '' }
      const initiative4 = { initiative_name: 'apple', status: '' }

      const sortedList = InitiativeUtil.orderInitiatives([ initiative1, initiative2, initiative3, initiative4 ],
        'initiative_name', [ 'desc' ])

      expect(sortedList[0]).toEqual(initiative1)
      expect(sortedList[1]).toEqual(initiative2)
      expect(sortedList[2]).toEqual(initiative3)
      expect(sortedList[3]).toEqual(initiative4)
    })
  })

  describe('filterInitiatives', () => {
    it('returns only top level initiatives in the default case', () => {
      const initiatives = [
        { initiative_id: '1', parent: null },
        { initiative_id: '2', parent: '1' },
        { initiative_id: '3', parent: '2' },
      ]
      const initiativeCategoryFilterOption = 'topLevel'
      const fundingStatusFilterOptions = { all: { active: true } }
      const filteredList = InitiativeUtil.filterInitiatives(
        initiatives, '', initiativeCategoryFilterOption, fundingStatusFilterOptions)
      expect(filteredList.length).toEqual(1)
      expect(filteredList[0]).toEqual(initiatives[0])
    })
    it('returns only initiatives with status of funded or planning in the default case', () => {
      const initiatives = [
        { initiative_id: '1', parent: null, status: 'Completed' },
        { initiative_id: '3', parent: null, status: 'Planning' },
        { initiative_id: '4', parent: null, status: 'Funded' },
      ]
      const initiativeCategoryFilterOption = 'topLevel'
      const fundingStatusFilterOptions = {
        all: { active: false, label: 'all' },
        completed: { active: false, label: 'completed' },
        planning: { active: true, label: 'planning' },
        funded: { active: true, label: 'funded' } }
      const filteredList = InitiativeUtil.filterInitiatives(
        initiatives, '', initiativeCategoryFilterOption, fundingStatusFilterOptions)
      expect(filteredList.length).toEqual(2)
      expect(filteredList).toEqual([ initiatives[1], initiatives[2] ])
    })

    it('returns the filtered list of initiatives when a search is input', () => {
      const initiatives = [
        { initiative_id: '1', initiative_name: '1', parent: null, status: 'Completed' },
        { initiative_id: '3', initiative_name: 'test 3', parent: null, status: 'Planning' },
        { initiative_id: '4', initiative_name: '4', parent: null, status: 'Funded' },
      ]

      const fundingStatusFilterOptions = { all: { active: true } }
      const initiativeCategoryFilterOption = 'topLevel'

      const searchText = 'test'

      const filteredList = InitiativeUtil.filterInitiatives(initiatives, searchText,
        initiativeCategoryFilterOption, fundingStatusFilterOptions)

      expect(filteredList.length).toEqual(1)
      expect(filteredList[0].initiative_id).toEqual('3')
    })

    describe('filters on types', () => {
      it('filters based on the selected type', () => {
        const initiatives = [
          {
            initiative_id: '1',
            initiative_name: '1',
            parent: null,
            status: 'Completed',
            tags: [{ tagValue: 'abc' }],
            type_id: 1,
          },
          {
            initiative_id: '3',
            initiative_name: '3',
            parent: null,
            status: 'Planning',
            tags: [{ tagValue: 'def' }],
            type_id: 1,
          },
          {
            initiative_id: '4',
            initiative_name: '4',
            parent: null,
            status: 'Funded',
            tags: [{ tagValue: 'cba' }],
            type_id: 1,
          },
        ]

        const expectedInitiatives = [
          {
            initiative_id: '1',
            initiative_name: '1',
            parent: null,
            status: 'Completed',
            tags: [{ tagValue: 'abc' }],
            type_id: 1,
          },
        ]

        const initiativeCategory = {
          active: true,
          id: 'topLevel',
        }

        const actual = InitiativeUtil.narrowInitiatives(initiatives, 'abc', [ initiativeCategory ], { all: { active: true } }, 1) // eslint-disable-line max-len

        expect(actual).toEqual(expectedInitiatives)
      })
    })

    describe('filters on tags', () => {
      it('works', () => {
        const initiatives = [
          { initiative_id: '1', initiative_name: '1', parent: null, status: 'Completed', tags: [{ tagValue: 'abc' }] },
          { initiative_id: '3', initiative_name: '3', parent: null, status: 'Planning', tags: [{ tagValue: 'def' }] },
          { initiative_id: '4', initiative_name: '4', parent: null, status: 'Funded', tags: [{ tagValue: 'cba' }] },
        ]

        const expected = [
          { initiative_id: '1', initiative_name: '1', parent: null, status: 'Completed', tags: [{ tagValue: 'abc' }] },
        ]

        const actual = InitiativeUtil.filterInitiatives(initiatives, 'abc', 'topLevel', { all: { active: true } })

        expect(actual).toEqual(expected)
      })
      it('works across array', () => {
        const initiatives = [
          { initiative_id: '1', initiative_name: '1', parent: null, status: 'Completed', tags: [{ tagValue: 'cba' }, { tagValue: 'abc' }] }, // eslint-disable-line max-len
          { initiative_id: '3', initiative_name: '3', parent: null, status: 'Planning', tags: [{ tagValue: 'def' }] },
          { initiative_id: '4', initiative_name: '4', parent: null, status: 'Funded', tags: [] },
          { initiative_id: '5', initiative_name: '5', parent: null, status: 'Funded' },
          { initiative_id: '6', initiative_name: '6', parent: null, status: 'Funded', tags: [{ tagV: 'abc' }, { notTagValue: 'abc' }] }, // eslint-disable-line max-len
        ]

        const expected = [
          { initiative_id: '1', initiative_name: '1', parent: null, status: 'Completed', tags: [{ tagValue: 'cba' }, { tagValue: 'abc' }] }, // eslint-disable-line max-len
        ]

        const actual = InitiativeUtil.filterInitiatives(initiatives, 'abc', 'topLevel', { all: { active: true } })

        expect(actual).toEqual(expected)
      })
    })

    it('returns an empty list when the initiative list does not exist', () => {
      const initiatives = undefined
      const searchText = 'search'

      const filteredList = InitiativeUtil.filterInitiatives(initiatives, searchText)

      expect(filteredList).toEqual([])
    })

    it('returns an empty list when the initiative list is empty', () => {
      const initiatives = []
      const searchText = 'search'

      const filteredList = InitiativeUtil.filterInitiatives(initiatives, searchText)

      expect(filteredList).toEqual([])
    })
  })

  describe('getInheritableAncestors', () => {
    it('returns ancestors that allow inheritance including current when not in edit mode', () => {
      const lineage = [{
        id: 'tester',
        name: 'test',
        order: 0,
      },
      {
        id: '123',
        name: 'Test',
        order: 1,
      }]

      const initiatives = [{
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '1001',
        is_inheritable: true,
      },
      {
        initiative_id: 'tester',
        initiative_name: 'test',
        parent: 'tester',
        finance_code_value: '100',
        is_inheritable: true,
      }]

      const expected = [{
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '1001',
        is_inheritable: true,
      },
      {
        initiative_id: 'tester',
        initiative_name: 'test',
        parent: 'tester',
        finance_code_value: '100',
        is_inheritable: true,
      }]

      const result = InitiativeUtil.getInheritableAncestors(lineage, initiatives, false)
      expect(result).toEqual(expected)
    })
    it('returns ancestors that allow inheritance excluding current when in edit mode', () => {
      const lineage = [{
        id: 'tester',
        name: 'test',
        order: 0,
      },
      {
        id: '123',
        name: 'Test',
        order: 1,
      }]

      const initiatives = [{
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '1001',
        is_inheritable: true,
      },
      {
        initiative_id: 'tester',
        initiative_name: 'test',
        parent: 'tester',
        finance_code_value: '100',
        is_inheritable: true,
      }]

      const expected = [{
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '1001',
        is_inheritable: true,
      }]

      const result = InitiativeUtil.getInheritableAncestors(lineage, initiatives, true)
      expect(result).toEqual(expected)
    })
    it('returns an empty array when no ancestors can return a finance code value', () => {
      const lineage = [{
        id: 'tester',
        name: 'test',
        order: 0,
      },
      {
        id: '123',
        name: 'Test',
        order: 1,
      }]

      const initiatives = [{
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '100',
        is_inheritable: false,
      },
      {
        initiative_id: 'tester',
        initiative_name: 'test',
        parent: 'tester',
        finance_code_value: '100',
        is_inheritable: true,
      }]

      const expected = []

      const result = InitiativeUtil.getInheritableAncestors(lineage, initiatives, true)
      expect(result).toEqual(expected)
    })
  })

  describe('getInheritedFinanceCodeValue', () => {
    const sandbox = sinon.sandbox.create()
    let getInheritableAncestorsStub = null

    beforeEach(() => {
      getInheritableAncestorsStub = sandbox.stub( InitiativeUtil, 'getInheritableAncestors')
    })

    afterEach(() => {
      sandbox.restore()
    })

    it('returns the correct finance code value placeholder', () => {
      getInheritableAncestorsStub.returns([{
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '100',
        is_inheritable: true,
      }])

      const lineage = [{
        id: 'tester',
        name: 'test',
        order: 0,
      },
      {
        id: '123',
        name: 'Test',
        order: 1,
      }]

      const initiatives = [{
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '100',
        is_inheritable: true,
      },
      {
        initiative_id: 'tester',
        initiative_name: 'test',
        parent: 'tester',
        finance_code_value: null,
        is_inheritable: true,
      }]

      const expected = '100'

      const result = InitiativeUtil.getInheritedFinanceCodeValue(lineage, initiatives, true)
      expect(result).toEqual(expected)
    })
    it('When there are no relevant ancestors, returns null', () => {
      getInheritableAncestorsStub.returns([])

      const lineage = [{
        id: 'tester',
        name: 'test',
        order: 0,
      },
      {
        id: '123',
        name: 'Test',
        order: 1,
      }]

      const initiatives = [{
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '100',
        is_inheritable: false,
      },
      {
        initiative_id: 'tester',
        initiative_name: 'test',
        parent: 'tester',
        finance_code_value: null,
        is_inheritable: true,
      }]

      const expected = null

      const result = InitiativeUtil.getInheritedFinanceCodeValue(lineage, initiatives, true)
      expect(result).toEqual(expected)
    })
  })

  describe('initiativeIsLeaf', () => {
    it('returns true is the initiative is a leaf', () => {
      const initiativeId = '456'
      const initiatives = [
        {
          initiative_id: '123',
          initiative_name: 'daddy',
          parent: null,
        },
        {
          initiative_id: '456',
          initiative_name: 'sonny',
          parent: '123',
        },
      ]
      expect(InitiativeUtil.initiativeIsLeaf(initiativeId, initiatives)).toEqual(true)
    })
    it('returns false if the initiative is not a leaf', () => {
      const initiativeId = '123'
      const initiatives = [
        {
          initiative_id: '123',
          initiative_name: 'daddy',
          parent: null,
        },
        {
          initiative_id: '456',
          initiative_name: 'sonny',
          parent: '123',
        },
      ]
      expect(InitiativeUtil.initiativeIsLeaf(initiativeId, initiatives)).toEqual(false)
    })
  })
})
