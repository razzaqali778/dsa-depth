import {
  getInitiatives,
  validateAllFields,
  validateFinanceCodeValue,
  validateName,
  validateStatus,
} from '../../../../public/scripts/util/InitiativeValidator'
import agent from '../../../../public/agent'

describe('InitiativeValidator', () => {
  const sandbox = sinon.sandbox.create()
  let agentStub = {}

  beforeEach(() => {
    agentStub = {
      get: sandbox.stub(agent, 'get'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('validateName', () => {
    const initiatives = [{ initiative_id: '123', initiative_name: 'Test', parent: null }]

    it('returns an error if the name is empty', () => {
      const name = ''

      const result = validateName(name, '', '', initiatives)

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Initiative Name must be non-empty.')
    })


    it('returns an error the name contains invalid characters', () => {
      const name = 'Test_Name'

      const result = validateName(name, '', '', initiatives)

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual(`Only letters, numbers, spaces, and these special characters: ( ) / - + : . & [ ]
      are allowed. (Max: 44 Characters)`)
    })

    it('returns error when a name for a top level initiative is a duplicate of existing top level initiative', () => {
      const name = 'Test'

      const result = validateName(name, '', null, initiatives)

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('This name already exists')
    })

    it('returns error when a name for a child initiative is a duplicate with an existing sibling initiative', () => {
      const name = 'Test'
      const relevantInitiatives = [{ initiative_id: '123', initiative_name: 'Test', parent: 'A' }]

      const result = validateName(name, '', 'A', relevantInitiatives)

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('This name already exists')
    })

    it('returns no error when the name is a duplicate of its self', () => {
      const name = 'Test'

      const result = validateName(name, '123', '', initiatives)

      expect(result.hasError).toBe(false)
      expect(result.message).toEqual('')
    })

    it('returns no error when the name is valid', () => {
      const name = 'Test Name'

      const result = validateName(name, '', '', initiatives)

      expect(result.hasError).toBe(false)
      expect(result.message).toEqual('')
    })
  })

  describe('validateStatus', () => {
    it('returns an error if the status is empty', () => {
      const status = ''
      const parent = null

      const result = validateStatus(status, parent)

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Initiative Status must be selected.')
    })

    it('returns no error if the status is valid', () => {
      const status = 'test'
      const parent = null

      const result = validateStatus(status, parent)

      expect(result.hasError).toBe(false)
      expect(result.message).toEqual('')
    })
    it('returns no error if the status is empty and the initiative has a parent', () => {
      const status = 'test'
      const parent = 'parent'

      const result = validateStatus(status, parent)

      expect(result.hasError).toBe(false)
      expect(result.message).toEqual('')
    })
  })

  describe('validateFinanceCodeValue', () => {
    it('returns an error if no finance code value, not inheriting, is funded, and is allocable', () => {
      const currentInitiative = {
        finance_code_value: null,
        is_allocable: true,
        status: 'Funded',
      }
      const result = validateFinanceCodeValue(currentInitiative)

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Finance Code Value must be entered.')
    })
    it('does not return an error if the initiative has a finance code value', () => {
      const currentInitiative = {
        finance_code_value: 100,
        is_allocable: true,
        status: 'Completed',
      }
      const result = validateFinanceCodeValue(currentInitiative)

      expect(result.hasError).toBe(false)
      expect(result.message).toEqual('')
    })
    it('does not return an error if the initiative has an inheritable value', () => {
      const currentInitiative = {
        inherited_fin_code_value: 100,
        is_allocable: true,
        status: 'Funded',
      }
      const result = validateFinanceCodeValue(currentInitiative)

      expect(result.hasError).toBe(false)
      expect(result.message).toEqual('')
    })
    it('does not return an error if initiative is grouping only (aka not allocable) and not inheriting', () => {
      const currentInitiative = {
        finance_code_value: null,
        is_allocable: false,
        status: 'Funded',
      }
      const result = validateFinanceCodeValue(currentInitiative)

      expect(result.hasError).toBe(false)
      expect(result.message).toEqual('')
    })
  })

  describe('validateAllFields', () => {
    it('pushes no errors into the errorsArray when there are no validation errors', () => {
      const initiative = {
        initiative_name: 'Orphan',
        status: 'Funded',
        finance_code_type: 'WBS Element',
        finance_code_value: 'abc12345',
        parent: '',
        type_id: 'Capital Project',
      }

      const resultantErrorsArray = validateAllFields( initiative, [ initiative ] )

      expect(resultantErrorsArray.length).toEqual(0)
    })

    it('pushes the correct number of errors into the errorsArray when validation errors are present', () => {
      const initiative = {
        initiative_name: '',
        status: 'Funded',
        finance_code_type: 'WBS Element',
        finance_code_value: 'abc12345',
        parent: '',
        type_id: 'Expense Initiative',
      }

      const resultantErrorsArray = validateAllFields( initiative, [ initiative ] )

      expect(resultantErrorsArray.length).toEqual(1)
      expect(resultantErrorsArray[0]).toEqual({
        errorType: 'initiative_name',
        errorMessage: 'Initiative Name must be non-empty.',
      })
    })
  })

  describe('getInitiatives', () => {
    it('returns the initiatives', async () => {
      const initiatives = [{ initiative_id: '123' }]
      const res = { body: initiatives }

      agentStub.get.resolves(res)
      const result = await getInitiatives()

      expect(result).toEqual(initiatives)
    })
    it('returns an error if initiatives cannot be retrieved', async () => {
      agentStub.get.rejects({ message: 'Failed to fetch initiatives' })

      try {
        await getInitiatives()
      } catch ( error ) {
        expect(error).toEqual({ message: 'Failed to fetch initiatives' })
      }
    })
  })
})
