import AlertUtil from '../../../../public/scripts/util/AlertUtil'

describe('AlertUtil', () => {
  describe('setAlert', () => {
    let component = {}

    beforeEach(() => {
      component = {
        state: { alerts: [] },
        setState: newState => {
          component.state = { ...newState }
        },
      }
    })

    it('sets a success alert', () => {
      const type = 'success'
      const message = 'you did it!'
      AlertUtil.setAlert(component, type, message)
      expect(component.state.alerts).toBeDefined()
      expect(component.state.alerts[0].message).toEqual(message)
      expect(component.state.alerts[0].type).toEqual(type)
    })

    it('sets two alerts!!!!', () => {
      const type = 'success'
      const type2 = 'warning'
      const message = 'you did it!'
      const message2 = 'that was so wrong'
      AlertUtil.setAlert(component, type, message)
      AlertUtil.setAlert(component, type2, message2)
      expect(component.state.alerts).toBeDefined()
      expect(component.state.alerts[1].message).toEqual(message2)
      expect(component.state.alerts[1].type).toEqual(type2)
    })

    it('changes errors to dangers', () => {
      const type = 'error'
      const message = 'you are in danger'
      const dangerType = 'danger'
      AlertUtil.setAlert(component, type, message)
      expect(component.state.alerts[0].type).toEqual(dangerType)
    })
  })
})
