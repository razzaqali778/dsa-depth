import * as BreadcrumbUtil from '../../../../public/scripts/util/BreadcrumbUtil'
import agent from '../../../../public/agent'

describe('BreadcrumbUtil', () => {
  const sandbox = sinon.sandbox.create()
  let agentStub = {} // eslint-disable-line

  beforeEach(() => {
    agentStub = {
      get: sandbox.stub(agent, 'get'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('getLineageForBreadcrumbs', () => {
    let lineage = []
    beforeEach(() => {
      lineage = [{ name: 'First', id: '123', order: 0 }]
    })

    it('returns an error if lineage cannot be retrieved', () => {
      const errorMock = 'Test Error'
      agent.get.rejects(errorMock)

      return BreadcrumbUtil.getLineageForBreadcrumbs('123')
        .then(error => {
          expect(error.hasError).toBe(true)
          expect(error.message.toString()).toEqual(`Error: ${errorMock}`)
        })
    })

    it('returns the updated breadcrumbs when the lineage is retrieved', () => {
      const responseMock = { body: lineage }
      agent.get.resolves(responseMock)

      return BreadcrumbUtil.getLineageForBreadcrumbs('123')
        .then(response => {
          expect(response.breadcrumbs).toEqual(lineage)
        })
    })

    it('returns no error when lineage is retrieved', () => {
      const responseMock = { body: lineage }
      agent.get.resolves(responseMock)

      return BreadcrumbUtil.getLineageForBreadcrumbs('123')
        .then(result => {
          expect(result.hasError).toBe(false)
        })
    })
  })
})
