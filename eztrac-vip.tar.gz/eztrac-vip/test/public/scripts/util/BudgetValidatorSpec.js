import BudgetValidator from '../../../../public/scripts/util/BudgetValidator'

describe('BudgetValidator', () => {
  describe('validateAmount', () => {
    it('returns an error when amount is not a number', () => {
      const result = BudgetValidator.validateAmount('not a number')

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Amount must be a number')
    })

    it('returns an error when no amount is specified', () => {
      const result = BudgetValidator.validateAmount()

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Amount is required')
    })

    it('returns an error when an empty amount is specified', () => {
      const result = BudgetValidator.validateAmount('')

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Amount is required')
    })

    it('allows a zero amount', () => {
      const result = BudgetValidator.validateAmount('0')

      expect(result.hasError).toBe(false)
    })

    it('returns an error when negative numbers are given', () => {
      const result = BudgetValidator.validateAmount('-10')

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Amount must be a positive number')
    })

    it('returns an error when a number with a decimal is given', () => {
      const result = BudgetValidator.validateAmount('1.1')

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Amount must be a whole number')
    })

    it('returns success when a valid number is given', () => {
      const result = BudgetValidator.validateAmount('10')

      expect(result.hasError).toBe(false)
      expect(result.message).toEqual('')
    })
    describe('validateAgainstParent', () => {
      it('returns no error if there is no parent budget', () => {
        const amount = 1
        const fiscalYear = '2017'
        const parentBudget = []
        const result = BudgetValidator.validateAmount(
          amount,
          parentBudget,
          fiscalYear
        )

        expect(result.hasError).toEqual(false)
        expect(result.message).toEqual('')
      })

      it('returns error if budget exceeds parent budget', () => {
        const amount = 20
        const fiscalYear = '2018'
        const parentBudget = [
          {
            amount: 15,
            fiscalYear: '2018',
          },
        ]
        const result = BudgetValidator.validateAmount(
          amount,
          parentBudget,
          fiscalYear
        )

        expect(result.hasError).toBe(true)
        expect(result.message).toEqual('Amount cannot exceed parent budget')
      })

      it('does not return error if budget equals parent budget', () => {
        const amount = 20
        const fiscalYear = '2018'
        const parentBudget = [
          {
            amount: 20,
            fiscalYear: '2018',
          },
        ]
        const result = BudgetValidator.validateAmount(
          amount,
          parentBudget,
          fiscalYear
        )

        expect(result.hasError).toBe(false)
        expect(result.message).toEqual('')
      })

      it('does not return error if the parent does not have that fiscal year', () => {
        const amount = 150
        const fiscalYear = '2019'
        const parentBudget = [
          {
            amount: 20,
            fiscalYear: '2018',
          },
        ]
        const result = BudgetValidator.validateAmount(
          amount,
          parentBudget,
          fiscalYear
        )

        expect(result.hasError).toBe(false)
        expect(result.message).toEqual('')
      })
    })
  })

  describe('validateSelect', () => {
    it('returns an error when no value is sent', () => {
      const result = BudgetValidator.validateSelect(undefined, 'initiative_id')

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Initiative id is required')
    })

    it('returns an error when an empty value is sent', () => {
      const result = BudgetValidator.validateSelect('', 'fiscal_year')

      expect(result.hasError).toBe(true)
      expect(result.message).toEqual('Fiscal year is required')
    })

    it('returns success when a valid value is sent', () => {
      const result = BudgetValidator.validateSelect('value', 'fiscal_year')

      expect(result.hasError).toBe(false)
      expect(result.message).toEqual('')
    })
  })
})
