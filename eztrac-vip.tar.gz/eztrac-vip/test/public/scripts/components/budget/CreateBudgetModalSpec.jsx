import { shallow } from 'enzyme'
import BreadcrumbsComponent from '../../../../../public/scripts/components/BreadcrumbsComponent'
import BudgetFormComponent from '../../../../../public/scripts/components/budget/BudgetFormComponent'
import CreateBudgetModal from '../../../../../public/scripts/components/budget/CreateBudgetModal'
import React from 'react'

describe('CreateBudgetModal', () => {
  const sandbox = sinon.sandbox.create()

  afterEach(() => {
    sandbox.restore()
  })

  describe('when initialized', () => {
    it('renders a blank budgetFormComponent', () => {
      const wrapper = shallow(<CreateBudgetModal initiative={{ initiative_name: 'name' }} />)
      expect(wrapper.find(BudgetFormComponent).length).toEqual(1)
    })

    it('displays the breadcrumbs component with the appropriate properties', () => {
      const wrapper = shallow(<CreateBudgetModal initiative={{ initiative_name: 'name' }} lineage={[]} />)

      expect(wrapper.find(BreadcrumbsComponent).length).toEqual(1)
      expect(wrapper.find(BreadcrumbsComponent).prop('lineage')).toEqual([])
      expect(wrapper.find(BreadcrumbsComponent).prop('optionalClass')).toEqual('disabled')
    })
  })

  describe('on save', () => {
    it('calls save', () => {
      const saveStub = sandbox.stub()
      const wrapper = shallow(<CreateBudgetModal
        initiative={{ initiative_name: 'name' }}
        saveBudget={saveStub}
      />)

      wrapper.find(BudgetFormComponent).prop('saveBudget')()

      expect(saveStub.called).toBe(true)
    })
  })

  describe('on cancel', () => {
    it('calls close', () => {
      const closeStub = sandbox.stub()
      const wrapper = shallow(<CreateBudgetModal close={closeStub} initiative={{ initiative_name: 'name' }} />)

      wrapper.find(BudgetFormComponent).prop('cancelAction')()

      expect(closeStub.called).toBe(true)
    })
  })

  describe('componentWillReceiveProps', () => {
    it('sets the fiscal years', () => {
      const wrapper = shallow(<CreateBudgetModal initiative={{ initiative_name: 'name' }} />)
      const fiscalYears = [{ value: '2017', label: '2017' }]

      wrapper.instance().componentWillReceiveProps({ fiscalYears })
      wrapper.update()

      expect(wrapper.find(BudgetFormComponent).prop('fiscalYears')).toEqual(fiscalYears)
    })
  })
})
