import * as BudgetUtil from '../../../../../public/scripts/util/BudgetUtil'
import { shallow } from 'enzyme'
import BudgetAmountComponent from '../../../../../public/scripts/components/budget/BudgetAmountComponent'
import BudgetCardComponent from '../../../../../public/scripts/components/budget/BudgetCardComponent'
import PieChart from '../../../../../public/scripts/components/budget/PieChart'
import React from 'react'

describe('BudgetCardComponent', () => {
  const sandbox = sinon.sandbox.create()
  let budgetUtilStub = {}

  beforeEach(() => {
    budgetUtilStub = {
      formatChildrenForChart: sandbox.stub(BudgetUtil, 'formatChildrenForChart'),
      getSumOfChildren: sandbox.stub(BudgetUtil, 'getSumOfChildren'),
      formatAmount: sandbox.stub(BudgetUtil, 'formatAmount'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })


  describe('on initialization', () => {
    it('sets the title to the fiscal year when initiative is read only', () => {
      const budget = { fiscalYear: '2017', children: [], splits: [] }
      const wrapper = shallow(<BudgetCardComponent budget={budget} initiativeReadOnly />)
      wrapper.setState({ budget })

      expect(wrapper.find('.card-title').text()).toEqual('2017')
    })

    it('displays the amount', () => {
      const budget = { amount: 20000, children: [], splits: [] }
      budgetUtilStub.formatAmount.returns('$20,000')
      const wrapper = shallow(<BudgetCardComponent budget={budget} />)
      wrapper.setState({ budget })

      expect(wrapper.find(BudgetAmountComponent).length).toEqual(1)
    })

    it('renders a pie chart', () => {
      const wrapper = shallow(<BudgetCardComponent budget={{ splits: [] }} />)

      expect(wrapper.find(PieChart).length).toEqual(1)
    })
  })
})
