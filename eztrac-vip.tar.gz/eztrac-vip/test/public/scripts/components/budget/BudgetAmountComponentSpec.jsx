import * as BudgetUtil from '../../../../../public/scripts/util/BudgetUtil'
import { shallow } from 'enzyme'
import BudgetAmountComponent from '../../../../../public/scripts/components/budget/BudgetAmountComponent'
import React from 'react'
import UserRolesUtil from '../../../../../public/scripts/util/UserRolesUtil'

describe('BudgetAmountComponent', () => {
  const sandbox = sinon.sandbox.create()
  let budgetUtilStub = {}
  let userRolesUtilStub = {}

  beforeEach(() => {
    budgetUtilStub = {
      formatAmount: sandbox.stub(BudgetUtil, 'formatAmount'),
    }

    userRolesUtilStub = {
      hasReadWriteRole: sandbox.stub(UserRolesUtil, 'hasReadWriteRole'),
    }
    userRolesUtilStub.hasReadWriteRole.returns(true)
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('on initialization', () => {
    it('displays the read only budget amount', () => {
      budgetUtilStub.formatAmount.returns('$2000')

      const wrapper = shallow(<BudgetAmountComponent />)

      expect(wrapper.find('#readOnlyAmount').length).toEqual(1)
      expect(wrapper.find('#readOnlyAmount').text().includes('Amount: $2000')).toBe(true)
    })
  })
})
