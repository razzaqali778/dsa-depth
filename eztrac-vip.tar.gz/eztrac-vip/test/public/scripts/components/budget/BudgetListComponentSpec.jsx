import * as BudgetUtil from '../../../../../public/scripts/util/BudgetUtil'
import * as CommunityUtil from '../../../../../public/scripts/util/communityUtil'
import { shallow } from 'enzyme'
import BudgetCardComponent from '../../../../../public/scripts/components/budget/BudgetCardComponent'
import BudgetListComponent from '../../../../../public/scripts/components/budget/BudgetListComponent'
import CreateBudgetModal from '../../../../../public/scripts/components/budget/CreateBudgetModal'
import React from 'react'
import UserRolesUtil from '../../../../../public/scripts/util/UserRolesUtil'

describe('BudgetListComponent', () => {
  const sandbox = sinon.sandbox.create()
  let budgetUtilStub = {}
  let userRolesUtilStub = {}
  let communityUtilStub = {}

  beforeEach(() => {
    budgetUtilStub = {
      getFiscalYears: sandbox.stub(BudgetUtil, 'getFiscalYears'),
      orderBudgets: sandbox.stub(BudgetUtil, 'orderBudgets'),
    }

    communityUtilStub = {
      getCommunityList: sandbox.stub(CommunityUtil, 'getCommunityList'),
    }

    userRolesUtilStub = {
      hasReadWriteRole: sandbox.stub(UserRolesUtil, 'hasReadWriteRole'),
    }
    userRolesUtilStub.hasReadWriteRole.returns(true)
    communityUtilStub.getCommunityList.returns([])
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('on initialization', () => {
    it('renders a message when no budgets are present', () => {
      const wrapper = shallow(<BudgetListComponent budgets={[]} />)

      expect(wrapper.find('#noBudgetMessage').length).toEqual(1)
      expect(wrapper.find('#noBudgetMessage').text()).toEqual('There are no budgets to display.')
    })

    it('renders the create button with the appropriate properties when no budgets are present', () => {
      const wrapper = shallow(<BudgetListComponent budgets={[]} />)

      expect(wrapper.find('#budgetButton').length).toEqual(1)
      expect(wrapper.find('#budgetButton').getElement().props.children).toEqual('Create Budget')
    })

    it('disables the create button when no fiscal years are available', () => {
      const wrapper = shallow(<BudgetListComponent budgets={[]} />)

      expect(wrapper.find('#budgetButton').prop('disabled')).toBe(true)
    })
  })

  describe('componentWillReceiveProps', () => {
    it('updates the available budgets', () => {
      const budget = {}
      const budgets = [ budget ]
      const fiscalYears = [ '2017' ]
      budgetUtilStub.getFiscalYears.returns(fiscalYears)
      budgetUtilStub.orderBudgets.returns(budgets)
      const wrapper = shallow(<BudgetListComponent />)

      wrapper.instance().componentWillReceiveProps({ budgets })
      wrapper.update()

      expect(wrapper.find(BudgetCardComponent).prop('budget')).toEqual(budget)
    })

    it('updates the available fiscalYears', () => {
      const fiscalYears = [ '2017' ]
      budgetUtilStub.getFiscalYears.returns(fiscalYears)
      budgetUtilStub.orderBudgets.returns([{}])
      const wrapper = shallow(<BudgetListComponent />)

      wrapper.instance().componentWillReceiveProps({ budgets: [{}] })
      wrapper.update()

      expect(wrapper.find(CreateBudgetModal).prop('fiscalYears')).toEqual(fiscalYears)
    })

    it('orders the budgets', () => {
      const fiscalYears = [ '2017' ]
      budgetUtilStub.getFiscalYears.returns(fiscalYears)
      budgetUtilStub.orderBudgets.returns([{}])
      const wrapper = shallow(<BudgetListComponent />)

      wrapper.instance().componentWillReceiveProps({ budgets: [{}] })
      wrapper.update()

      expect(budgetUtilStub.orderBudgets.called).toBe(true)
    })
  })

  describe('closeBudgetModal', () => {
    it('sets the modal state to closed', () => {
      const wrapper = shallow(<BudgetListComponent budgets={[]} />)
      wrapper.setState({ showBudgetModal: true })

      wrapper.instance().closeBudgetModal()
      wrapper.update()

      expect(wrapper.find(CreateBudgetModal).prop('show')).toBe(false)
    })
  })
})
