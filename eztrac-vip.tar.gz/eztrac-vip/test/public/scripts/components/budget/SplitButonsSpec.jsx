import {
  AddSplitButton,
  RemoveSplitButton,
} from '../../../../../public/scripts/components/budget/SplitButtons'
import React from 'react'
import renderer from 'react-test-renderer'

it('renders correctly', () => {
  const buttons = renderer.create(
    <AddSplitButton
      budget={{ budgetId: 123 }}
      budgetSplits={[{ splitValue: 'community 1', amount: 1000 }]}
      setBudgetSplits={jest.fn()}
    />
  ).toJSON()
  expect(buttons).toMatchSnapshot()
})
it('renders correctly', () => {
  const removeButton = renderer.create(
    <RemoveSplitButton
      budgetSplits={[{ splitValue: 'community 1', amount: 1000 }]}
      index={0}
      setBudgetSplits={jest.fn()}
    />
  ).toJSON()
  expect(removeButton).toMatchSnapshot()
})
