import * as BudgetUtil from '../../../../../public/scripts/util/BudgetUtil'
import { shallow } from 'enzyme'
import BudgetFormComponent from '../../../../../public/scripts/components/budget/BudgetFormComponent'
import BudgetValidator from '../../../../../public/scripts/util/BudgetValidator'
import React from 'react'

describe('BudgetFormComponent', () => {
  const sandbox = sinon.sandbox.create()
  let validationStub = {}
  let budgetUtilStub = {}

  beforeEach(() => {
    validationStub = {
      validateAmount: sandbox.stub(BudgetValidator, 'validateAmount'),
      validateSelect: sandbox.stub(BudgetValidator, 'validateSelect'),
    }

    budgetUtilStub = {
      getParentBudgets: sandbox.stub(BudgetUtil, 'getParentBudgets'),
    }
    budgetUtilStub.getParentBudgets.resolves([])
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('when initialized', () => {
    it('disables the save button', () => {
      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)

      const saveBtn = wrapper.find('#saveButton')
      expect(saveBtn.prop('disabled')).toBe(true)
    })

    it('sets the cancelAction', () => {
      const cancelAction = sandbox.stub()

      const wrapper =
        shallow(<BudgetFormComponent cancelAction={cancelAction} initiative={{ initiative_name: 'blah' }} />)

      expect(wrapper.find('#cancelButton').prop('onClick')).toEqual(cancelAction)
    })

    it('displays the input fields', () => {
      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)

      expect(wrapper.find('#fiscalYear').length).toEqual(1)
      expect(wrapper.find('#amount').length).toEqual(1)
    })

    it('shows no errors', () => {
      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)
      const fiscalYearClass = wrapper.find('#fiscalYearField').prop('className')
      expect(fiscalYearClass.includes('col-md-6')).toBe(true)
      expect(fiscalYearClass.includes('has-error')).toBe(false)
      expect(wrapper.find('#fiscalYearErrorMessage').text()).toEqual(' ')
      const amountClass = wrapper.find('#amountField').prop('className')
      expect(amountClass.includes('col-md-6')).toBe(true)
      expect(amountClass.includes('has-error')).toBe(false)
      expect(wrapper.find('#amountErrorMessage').text()).toEqual(' ')
    })
  })

  describe('on close', () => {
    it('performs the appropriate close action', () => {
      const closeStub = sandbox.stub()
      const wrapper = shallow(<BudgetFormComponent cancelAction={closeStub} initiative={{ initiative_name: 'blah' }} />)

      wrapper.find('#cancelButton').simulate('click')

      expect(closeStub.called).toBe(true)
    })
  })

  describe('on number field change', () => {
    it('sets an error if the amount field is invalid', () => {
      const validationError = { hasError: true, message: 'Bad input' }
      validationStub.validateAmount.returns(validationError)
      validationStub.validateSelect.returns({})

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)
      wrapper.find('#amount').simulate('change', { target: { value: 'not a number', id: 'amount' } })

      expect(
        wrapper.find('#amountField').prop('className').includes('col-md-6 has-error')
      ).toBe(true)
      expect(wrapper.find('#amountErrorMessage').text()).toEqual('Bad input')
    })

    it('deactivates the save button if the amount field is invalid', () => {
      const validationError = { hasError: true, message: 'Bad input' }
      validationStub.validateAmount.returns(validationError)
      validationStub.validateSelect.returns({})

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)
      wrapper.setState({ saveDisabled: false })

      wrapper.find('#amount').simulate('change', { target: { value: 'not a number', id: 'amount' } })

      expect(wrapper.find('#saveButton').prop('disabled')).toBe(true)
    })


    it('activates the save button if the name field and others are valid', () => {
      const validationResponse = { hasError: false }
      validationStub.validateAmount.returns(validationResponse)
      validationStub.validateSelect.returns(validationResponse)

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)

      wrapper.find('#amount').simulate('change', { target: { value: 123, id: 'amount' } })

      expect(wrapper.find('#saveButton').prop('disabled')).toBe(false)
    })

    it('deactivates the save button if the amount field is valid but others are not', () => {
      const validationResponseWithNoError = { hasError: false }
      const validationResponseWithError = { hasError: true }
      validationStub.validateAmount.returns(validationResponseWithNoError)
      validationStub.validateSelect.returns(validationResponseWithError)

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)
      wrapper.setState({ saveDisabled: false })

      wrapper.find('#amount').simulate('change', { target: { value: 123, id: 'amount' } })

      expect(wrapper.find('#saveButton').prop('disabled')).toBe(true)
    })

    it('removes any amount field errors if the amount field is valid', () => {
      const validationResponse = { hasError: false }
      validationStub.validateAmount.returns(validationResponse)
      validationStub.validateSelect.returns(validationResponse)

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)
      wrapper.setState({ amountErrorMessage: 'name error', amountFieldClass: 'name error' })

      wrapper.find('#amount').simulate('change', { target: { value: 123, id: 'amount' } })

      const amountClass = wrapper.find('#amountField').prop('className')

      expect(amountClass.includes('col-md-6')).toBe(true)
      expect(amountClass.includes('has-error')).toBe(false)
      expect(wrapper.find('#amountErrorMessage').text()).toEqual('')
    })

    it('validateAmount and validateSelect are called with the appropriate arguments', () => {
      const validationResponse = { hasError: false }
      validationStub.validateAmount.returns(validationResponse)
      validationStub.validateSelect.returns(validationResponse)

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)
      wrapper.setState({ budget: { initiative_id: '123', fiscalYear: '2017', amount: 12 } })

      wrapper.find('#amount').simulate('change', { target: { value: 13, id: 'amount' } })

      expect(validationStub.validateAmount.args[0][0]).toEqual(13000)
      expect(validationStub.validateSelect.args[0]).toEqual([ '2017', 'fiscalYear' ])
    })
  })

  describe('on select field change', () => {
    it('validateAmount and validateSelect are called with the appropriate arguments', () => {
      const validationResponse = { hasError: false }
      validationStub.validateAmount.returns(validationResponse)
      validationStub.validateSelect.returns(validationResponse)

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)
      wrapper.setState({ budget: { initiative_id: '123', fiscalYear: '2017', amount: 123 } })

      wrapper.find('#fiscalYear').simulate('change', { value: '123', label: 'Test', id: 'initiative_id' })
      expect(validationStub.validateAmount.args[0][0]).toEqual(123)
      expect(validationStub.validateSelect.args[0]).toEqual([ '2017', 'fiscalYear' ])
    })
    it('sets an error if the year select field is invalid', () => {
      const validationError = { hasError: true, message: 'Bad input' }
      const validationSuccess = { hasError: false }
      validationStub.validateSelect.returns(validationError)
      validationStub.validateAmount.returns(validationSuccess)

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)
      wrapper.find('#fiscalYear').simulate('change', { value: '', id: 'fiscalYear' })

      const statusClass = wrapper.find('#fiscalYearField').prop('className')
      expect(statusClass.includes('col-md-6 has-error')).toBe(true)
      expect(wrapper.find('#fiscalYearErrorMessage').text()).toEqual('Bad input')
    })

    it('activates the save button if the year select field and others are valid', () => {
      const validationResponse = { hasError: false }
      validationStub.validateSelect.returns(validationResponse)
      validationStub.validateAmount.returns(validationResponse)

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)

      wrapper.find('#fiscalYear').simulate('change', { value: '2017', id: 'fiscalYear' })

      expect(wrapper.find('#saveButton').prop('disabled')).toBe(false)
    })

    it('removes any errors if the year select field is valid', () => {
      const validationSuccess = { hasError: false }
      validationStub.validateSelect.returns(validationSuccess)
      validationStub.validateAmount.returns(validationSuccess)

      const wrapper = shallow(<BudgetFormComponent initiative={{ initiative_name: 'blah' }} />)
      wrapper.setState({ fiscalYearErrorMessage: 'status error', fiscalYearFieldClass: 'name error' })

      wrapper.find('#fiscalYear').simulate('change', { value: '2017', id: 'fiscalYear' })

      const statusClass = wrapper.find('#fiscalYearField').prop('className')
      expect(statusClass.includes('col-md-6')).toBe(true)
      expect(statusClass.includes('has-error')).toBe(false)
      expect(wrapper.find('#fiscalYearErrorMessage').text()).toEqual('')
    })
  })

  describe('on save budget', () => {
    it('sends the new budget to be created', () => {
      const saveStub = sandbox.stub()
      const initiative = { initiative_id: '456' }
      const budgetSplits = [
        { budgetId: 123, splitValue: 'abc', amount: 10000 },
        { budgetId: 123, splitValue: 'def', amount: 10000 },
      ]
      const budget = { initiativeId: '123', fiscalYear: '2017', amount: 20000, splits: budgetSplits }
      const wrapper = shallow(
        <BudgetFormComponent
          initiative={initiative}
          saveBudget={saveStub}
        />)
      wrapper.setState({ budget, saveDisabled: false, budgetSplits })

      wrapper.find('#saveButton').simulate('click')
      expect(saveStub.args[0][0]).toEqual(budget)
    })
  })
})
