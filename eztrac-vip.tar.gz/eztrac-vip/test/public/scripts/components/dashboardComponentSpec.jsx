import * as InitiativeUtil from '../../../../public/scripts/util/InitiativeUtil'
import { shallow } from 'enzyme'
import AlertUtil from '../../../../public/scripts/util/AlertUtil'
import CreateInitiativeModal from '../../../../public/scripts/components/initiative/CreateInitiativeModal'
import DashboardComponent from '../../../../public/scripts/components/dashboardComponent'
import InitiativeCardsComponent from '../../../../public/scripts/components/initiative/InitiativeCardsComponent'
import React from 'react'
import UserRolesUtil from '../../../../public/scripts/util/UserRolesUtil'
import agent from '../../../../public/agent'

describe('DashboardComponent', () => {
  const sandbox = sinon.sandbox.create()
  let agentStub = {}
  let alertUtilStub = {}
  let initiativeUtilStub = {} // eslint-disable-line
  let userRolesUtilStub = {}

  beforeEach(() => {
    agentStub = {
      get: sandbox.stub(agent, 'get'),
      post: sandbox.stub(agent, 'post'),
    }

    alertUtilStub = {
      setAlert: sandbox.stub(AlertUtil, 'setAlert'),
    }

    initiativeUtilStub = {
      formatInitiativeStatuses: sandbox.stub(InitiativeUtil, 'formatInitiativeStatuses'),
      formatFinanceCodeTypes: sandbox.stub(InitiativeUtil, 'formatFinanceCodeTypes'),
    }

    userRolesUtilStub = {
      hasEitherRole: sandbox.stub(UserRolesUtil, 'hasEitherRole'),
    }
    userRolesUtilStub.hasEitherRole.resolves(true)
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('on initialization', () => {
    it('displays the dashboard when user does have access', () => {
      const wrapper = shallow(<DashboardComponent />)

      expect(wrapper.find('#dashboardBody').length).toEqual(1)
    })

    it('passes the appropriate properties to the InitiativeCardsComponent', () => {
      const wrapper = shallow(<DashboardComponent />)

      expect(wrapper.find(InitiativeCardsComponent).prop('initiatives')).toEqual([])
      expect(wrapper.find(InitiativeCardsComponent).prop('buttonText')).toEqual('Create Top Level Initiative')
    })

    it('renders the CreateInitiativeModalComponent with the appropriate properties', () => {
      const wrapper = shallow(<DashboardComponent />)

      expect(wrapper.find(CreateInitiativeModal).prop('initiativeStatuses')).toEqual([])
      expect(wrapper.find(CreateInitiativeModal).prop('show')).toBe(false)
      expect(wrapper.find(CreateInitiativeModal).prop('title')).toEqual('Create Top Level Initiative')
      expect(typeof wrapper.find(CreateInitiativeModal).prop('close')).toEqual('function')
      expect(typeof wrapper.find(CreateInitiativeModal).prop('save')).toEqual('function')
    })
  })

  describe('openCreateModal', () => {
    it('updates the modals open state', () => {
      const wrapper = shallow(<DashboardComponent />)

      wrapper.instance().openCreateModal()
      wrapper.update()

      expect(wrapper.find(CreateInitiativeModal).prop('show')).toBe(true)
    })
  })

  describe('closeCreateModal', () => {
    it('updates the modals open state and makes sure the initiatives data is saved', async () => {
      const wrapper = shallow(<DashboardComponent />)
      wrapper.setState({ showCreateInitiativeModal: true })
      wrapper.update()
      await wrapper.instance().closeCreateModal()
      wrapper.update()
      expect(wrapper.find(CreateInitiativeModal).prop('show')).toBe(false)
    })
  })

  describe('createInitiative', () => {
    it('creates a single initiative', async () => {
      const initiative = { initiative_name: 'Test', status: 'Test' }
      const responseMock = { body: { initiative_id: '123' } }
      agentStub.post.resolves(responseMock)
      const wrapper = shallow(<DashboardComponent />)
      const expectedInitiativeList = [{ initiative_name: 'Test', status: 'Test', initiative_id: '123', parent: null }]
      await wrapper.instance().createInitiative({ initiative, createAnotherInitiative: false })
      expect(wrapper.instance().state.initiatives).toEqual(expectedInitiativeList)
    })

    it('confirms that the create modal is still open when create another is checked', async () => {
      const initiative = { initiative_name: 'Test', status: 'Test' }
      const responseMock = { body: { initiative_id: '123' } }
      agentStub.post.resolves(responseMock)
      const wrapper = shallow(<DashboardComponent />)
      await wrapper.instance().createInitiative({ initiative, createAnotherInitiative: true } )
      expect(wrapper.instance().state.showCreateInitiativeModal).toEqual(true)
    })

    it('confirms that the create modal is not open when create another is not checked', async () => {
      const initiative = { initiative_name: 'Test', status: 'Test', createAnotherInitiative: false }
      const responseMock = { body: { initiative_id: '123' } }
      agentStub.post.resolves(responseMock)
      const wrapper = shallow(<DashboardComponent />)
      await wrapper.instance().createInitiative(initiative)
      expect(wrapper.instance().state.showCreateInitiativeModal).toEqual(false)
    })
    it('fails gracefully when the POST to create initiative fails', async () => {
      const initiative = { initiative_name: 'Failed Test', status: 'Fail', createAnotherInitiative: false }
      const errorMock = { errorType: 'Failed POST', error: '500' }
      agentStub.post.throws(errorMock)
      const wrapper = shallow(<DashboardComponent />)
      await wrapper.instance().createInitiative(initiative)
      expect(alertUtilStub.setAlert.called).toBe(true)
    })
  })
})
