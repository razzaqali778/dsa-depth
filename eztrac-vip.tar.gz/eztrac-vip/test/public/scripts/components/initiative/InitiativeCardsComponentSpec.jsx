import * as InitiativeUtil from '../../../../../public/scripts/util/InitiativeUtil'
import { shallow } from 'enzyme'
import Constants from '../../../../../common/constants'
import InitiativeCardsComponent from '../../../../../public/scripts/components/initiative/InitiativeCardsComponent'
import PersistentStorageUtil from '../../../../../public/scripts/util/PersistentStorageUtil'
import React from 'react'
import SearchComponent from '../../../../../public/scripts/components/SearchComponent'
import UserRolesUtil from '../../../../../public/scripts/util/UserRolesUtil'

describe('InitiativeCardsComponent', () => {
  const sandbox = sinon.sandbox.create()
  let initiativeUtilStub = {}
  let userRolesUtilStub = {}
  let persistentStorageUtilStub = {}

  beforeEach(() => {
    initiativeUtilStub = {
      orderInitiatives: sandbox.stub(InitiativeUtil, 'orderInitiatives'),
      narrowInitiatives: sandbox.stub(InitiativeUtil, 'narrowInitiatives'),
    }

    userRolesUtilStub = {
      hasReadWriteRole: sandbox.stub(UserRolesUtil, 'hasReadWriteRole'),
    }
    userRolesUtilStub.hasReadWriteRole.returns(true)

    persistentStorageUtilStub = {
      addField: sandbox.stub(PersistentStorageUtil, 'addField'),
      getField: sandbox.stub(PersistentStorageUtil, 'getField'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('renders a button with the appropriate text when the user has write access', () => {
    const buttonText = 'Test Button'
    const buttonAction = sandbox.stub()

    const wrapper = shallow(<InitiativeCardsComponent
      buttonAction={buttonAction}
      buttonText={buttonText}
      initiatives={[{}]}
    />)

    expect(wrapper.find('#initiativeButton').length).toEqual(1)
    expect(wrapper.find('#initiativeButton').prop('onClick')).toEqual(buttonAction)
    expect(wrapper.find('#initiativeButton').getElement().props.children).toEqual(buttonText)
  })


  it('displays a message when there are no initiatives returned from the database', () => {
    const initiatives = []
    const wrapper = shallow(<InitiativeCardsComponent initiatives={initiatives} />)

    expect(wrapper.find('.card').length).toEqual(0)
    expect(wrapper.find('.bs-callout').length).toEqual(1)
    expect(wrapper.find('.bs-callout').text()).toEqual('There are no initiatives to display. Add an initiative!')
  })

  it('orders the initiatives when received', () => {
    const initiatives = [
      { initiative_name: 'Zebra', status: '' },
      { initiative_name: 'zebra', status: '' },
      { initiative_name: 'Apple', status: '' },
      { initiative_name: 'apple', status: '' },
    ]
    initiativeUtilStub.orderInitiatives.returns(initiatives)
    initiativeUtilStub.narrowInitiatives.returns(initiatives)


    const wrapper = shallow(<InitiativeCardsComponent initiatives={[]} />)

    wrapper.instance().componentWillReceiveProps({ initiatives })

    expect(initiativeUtilStub.orderInitiatives.called).toBe(true)
  })

  it('Verifying narrowInitiatives is being called with the proper arguments', () => {
    const wrapper = shallow(<InitiativeCardsComponent initiatives={[]} />)

    const initiatives = [
      { initiative_name: 'Zebra', status: '' },
      { initiative_name: 'zebra', status: '' },
      { initiative_name: 'Apple', status: '' },
      { initiative_name: 'apple', status: '' },
    ]

    // const initiativeCategoryFilterOptions = { topLevel: { label: 'topLevel', active: true, id: 'topLevel' } }
    // const fundingStatusFilterOptions = {
    //   all: false,
    //   funded: true,
    //   planning: true,
    //   completed: false,
    // }

    initiativeUtilStub.orderInitiatives.returns(initiatives)
    initiativeUtilStub.narrowInitiatives.returns(initiatives)

    wrapper.instance().componentWillReceiveProps({ initiatives, isTopLevel: true })

    expect(initiativeUtilStub.narrowInitiatives.calledWith(initiatives, '')).toBe(true)
  })

  it('Verify that its not filtering on children', () => {
    const wrapper = shallow(<InitiativeCardsComponent initiatives={[]} />)

    const initiatives = [
      { initiative_name: 'Zebra', status: '' },
      { initiative_name: 'zebra', status: '' },
      { initiative_name: 'Apple', status: '' },
      { initiative_name: 'apple', status: '' },
    ]

    initiativeUtilStub.orderInitiatives.returns(initiatives)

    wrapper.instance().componentWillReceiveProps({ initiatives, isTopLevel: false })

    expect(initiativeUtilStub.narrowInitiatives.called).toBe(false)
  })

  describe('search box', () => {
    let wrapper = {}

    beforeEach(() => {
      wrapper = shallow(<InitiativeCardsComponent isTopLevel />)
      wrapper.setState({ initiatives: [{}] })

      initiativeUtilStub.narrowInitiatives.returns([])
    })

    it('renders a search component with the appropriate properties', () => {
      wrapper.setState({ searchText: 'test search' })

      expect(wrapper.find(SearchComponent).length).toEqual(1)
      expect(typeof wrapper.find(SearchComponent).prop('searchAction')).toEqual('function')
      expect(wrapper.find(SearchComponent).prop('searchText')).toEqual('test search')
    })

    it('allows changes to the search box', () => {
      wrapper.instance().handleInputChange('testSearch')
      wrapper.update()

      expect(wrapper.find(SearchComponent).prop('searchText')).toEqual('testSearch')
    })

    it('calls narrowInitiatives when the searchBox changes', () => {
      wrapper.instance().handleInputChange('testSearch')
      wrapper.update()

      expect(initiativeUtilStub.narrowInitiatives.called).toBe(true)
    })

    it('calls PersistentStorageUtil when the searchBox changes', () => {
      wrapper.instance().handleInputChange('testSearch')
      wrapper.update()

      expect(persistentStorageUtilStub.addField.calledWith('searchText', 'testSearch')).toBe(true)
    })
  })

  describe('initiative type radio buttons', () => {
    let wrapper = {}

    beforeEach(() => {
      wrapper = shallow(<InitiativeCardsComponent isTopLevel />)
    })

    it('When initiative button is chosen addField() stores the selected value', () => {
      wrapper.instance().toggleRadioFilterOption('topLevel')
      wrapper.update()
      const expectedOptions = Constants.INITIATIVE_TYPE_OPTIONS
      expect(
        persistentStorageUtilStub.addField.calledWith('initiativeCategoryFilterOptions', expectedOptions)
      ).toBe(true)
    })
    it('When initiative type button is selected it changes InitiativeType FilterOptions', () => {
      wrapper.instance().toggleRadioFilterOption('children')
      wrapper.update()

      const expected = Constants.INITIATIVE_TYPE_OPTIONS
      expected.topLevel.active = false
      expected.children.active = true

      expect(wrapper.instance().state.initiativeCategoryFilterOptions).toEqual(expected)
    })
  })

  describe('funding status checkboxes', () => {
    let wrapper = {}


    beforeEach(() => {
      wrapper = shallow(<InitiativeCardsComponent isTopLevel />)
    })

    it('When a checkbox is chosen, addField() stores the selected values', () => {
      wrapper.instance().toggleCheckboxFilterOption('completed')
      wrapper.update()
      const expectedOptions = Constants.FUNDING_STATUS_OPTIONS
      expect(
        persistentStorageUtilStub.addField.calledWith('fundingStatusFilterOptions', expectedOptions)
      ).toBe(true)
    })
    it('When a checkbox is chosen, correctly updates fundingStatusFilterOptions', () => {
      wrapper.instance().toggleCheckboxFilterOption('completed')
      wrapper.update()
      const expected = Constants.FUNDING_STATUS_OPTIONS
      expected.completed.active = false

      expect(wrapper.instance().state.fundingStatusFilterOptions).toEqual(expected)
    })
  })
  describe('constructor', () => {
    beforeEach(() => {
      shallow(<InitiativeCardsComponent isTopLevel />)
    })

    it('calls getField() when the page is loaded', () => {
      expect(persistentStorageUtilStub.getField.calledWith('searchText')).toBe(true)
      expect(
        persistentStorageUtilStub.getField.calledWith('initiativeCategoryFilterOptions')
      ).toBe(true)
      expect(
        persistentStorageUtilStub.getField.calledWith('fundingStatusFilterOptions')
      ).toBe(true)
    })
    it('calls constructor() and has no value in persistent storage', () => {
      const expected = {
        isTopLevel: true,
        initiatives: [],
        searchText: '',
        filteredInitiatives: [],
        initiativeCategoryFilterOptions: Constants.INITIATIVE_TYPE_OPTIONS,
        fundingStatusFilterOptions: Constants.FUNDING_STATUS_OPTIONS,
        selectedInitiativeType: '',
        userHasReadWriteRole: true,
      }
      const freshWrapper = shallow(<InitiativeCardsComponent isTopLevel />)
      expect(freshWrapper.instance().state).toEqual(expected)
    })
  })
})
