import * as InitiativeValidator from '../../../../../public/scripts/util/InitiativeValidator'
import { shallow } from 'enzyme'
import InitiativeFormComponent from '../../../../../public/scripts/components/initiative/InitiativeFormComponent'
import React from 'react'

describe('InitiativeFormComponent', () => {
  const sandbox = sinon.sandbox.create()
  let validationStub = {}

  beforeEach(() => {
    validationStub = {
      validateAllFields: sandbox.stub(InitiativeValidator, 'validateAllFields'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('when initialized', () => {
    it('disables the save button', () => {
      const wrapper = shallow(<InitiativeFormComponent />)

      const saveBtn = wrapper.find('#saveButton')
      expect(saveBtn.prop('disabled')).toBe(true)
    })

    // TODO update to include other fields (or just refactor test)
    it('shows no errors', () => {
      const wrapper = shallow(<InitiativeFormComponent />)

      const nameClass = wrapper.find('#nameField').prop('className')
      expect(nameClass.includes('col-md-6')).toBe(true)
      expect(nameClass.includes('has-error')).toBe(false)
      expect(wrapper.find('#initiativeNameErrorMessage').text()).toEqual(' ')
      const typeClass = wrapper.find('#typeField').prop('className')
      expect(typeClass.includes('col-md-6')).toBe(true)
      expect(typeClass.includes('has-error')).toBe(false)
      expect(wrapper.find('#initiativeTypeErrorMessage').text()).toEqual(' ')
      const statusClass = wrapper.find('#statusField').prop('className')
      expect(statusClass.includes('col-md-6')).toBe(true)
      expect(statusClass.includes('has-error')).toBe(false)
      expect(wrapper.find('#statusErrorMessage').text()).toEqual(' ')
    })
  })

  describe('on close', () => {
    it('performs the appropriate close action', () => {
      const closeStub = sandbox.stub()
      const wrapper = shallow(<InitiativeFormComponent cancelAction={closeStub} />)

      wrapper.find('#cancelButton').simulate('click')

      expect(closeStub.called).toBe(true)
    })
  })

  describe('on text field change', () => {
    it('sets an error if a field is invalid', () => {
      const validationError = [{ errorType: 'initiative_name', errorMessage: 'Bad input' }]
      validationStub.validateAllFields.returns(validationError)

      const wrapper = shallow(<InitiativeFormComponent />)

      wrapper.find('#initiative_name').simulate('change', { target: { value: 'Bad_Test', id: 'name' } })
      expect(wrapper.find('#nameField').prop('className').includes('col-md-6 has-error')).toBe(true)
      expect(wrapper.find('#initiativeNameErrorMessage').text()).toEqual('Bad input')
    })

    it('deactivates the save button if a field is invalid', () => {
      const validationError = [{ errorType: 'initiative_name', errorMessage: 'Bad input' }]
      validationStub.validateAllFields.returns(validationError)

      const wrapper = shallow(<InitiativeFormComponent />)
      wrapper.setState({ saveDisabled: false })

      wrapper.find('#initiative_name').simulate('change', { target: { value: 'Bad_Test', id: 'name' } })

      expect(wrapper.find('#saveButton').prop('disabled')).toBe(true)
    })


    it('activates the save button if a field and others are valid', () => {
      validationStub.validateAllFields.returns([])

      const wrapper = shallow(<InitiativeFormComponent />)

      wrapper.find('#initiative_name').simulate('change', { target: { value: 'Test', id: 'name' } })

      expect(wrapper.find('#saveButton').prop('disabled')).toBe(false)
    })

    it('deactivates the save button if a field is valid but others are not', () => {
      const validationError = [{ errorType: 'status', errorMessage: 'Bad input' }]
      validationStub.validateAllFields.returns(validationError)

      const wrapper = shallow(<InitiativeFormComponent />)

      wrapper.find('#initiative_name').simulate('change', { target: { value: 'Test', id: 'name' } })

      expect(wrapper.find('#saveButton').prop('disabled')).toBe(true)
    })

    it('removes any field errors if a field is valid', () => {
      validationStub.validateAllFields.returns([])

      const wrapper = shallow(<InitiativeFormComponent />)
      wrapper.setState({ nameErrorMessage: 'name error', nameFieldClass: 'name error' })

      wrapper.find('#initiative_name').simulate('change', { target: { value: 'Test', id: 'name' } })

      const nameClass = wrapper.find('#nameField').prop('className')

      expect(nameClass.includes('col-md-6')).toBe(true)
      expect(nameClass.includes('has-error')).toBe(false)
      expect(wrapper.find('#initiativeNameErrorMessage').text()).toEqual('')
    })
  })


  describe('on save initiative', () => {
    it('sends the new initiative to be created', () => {
      const saveStub = sandbox.stub()
      const wrapper = shallow(<InitiativeFormComponent saveInitiative={saveStub} />)
      wrapper.setState({ saveDisabled: false })
      wrapper.find('#saveButton').simulate('click')
      expect(saveStub.called).toBe(true)
    })
  })
})
