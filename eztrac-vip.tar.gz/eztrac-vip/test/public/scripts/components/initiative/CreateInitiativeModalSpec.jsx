import { Modal } from 'react-bootstrap'
import { shallow } from 'enzyme'
import BreadcrumbsComponent from '../../../../../public/scripts/components/BreadcrumbsComponent'
import CreateInitiativeModal from '../../../../../public/scripts/components/initiative/CreateInitiativeModal'
import InitiativeFormComponent from '../../../../../public/scripts/components/initiative/InitiativeFormComponent'
import React from 'react'

describe('CreateInitiativeModal', () => {
  const sandbox = sinon.sandbox.create()

  afterEach(() => {
    sandbox.restore()
  })

  describe('when initialized', () => {
    it('renders a blank initiativeFormComponent', () => {
      const wrapper = shallow(<CreateInitiativeModal initiative={{}} />)
      expect(wrapper.find(InitiativeFormComponent).length).toEqual(1)
      expect(wrapper.find(InitiativeFormComponent).prop('initiative')).toEqual({})
    })

    it('displays the title for modal', () => {
      const wrapper = shallow(<CreateInitiativeModal title="test title" />)

      expect(wrapper.find(Modal.Title).prop('children')).toEqual('test title')
    })

    it('displays the breadcrumbs component with the appropriate properties', () => {
      const wrapper = shallow(<CreateInitiativeModal lineage={[]} />)

      expect(wrapper.find(BreadcrumbsComponent).length).toEqual(1)
      expect(wrapper.find(BreadcrumbsComponent).prop('lineage')).toEqual([])
      expect(wrapper.find(BreadcrumbsComponent).prop('optionalClass')).toEqual('disabled')
    })
  })

  describe('on prop change', () => {
    it('sends InitiativeFormComponent appropriate initiative when editing', () => {
      const mockInitiative =
            {
              initiative_name: 'testName',
              status: 'testStatus',
              finance_code_type: 'testCodeType',
            }
      const wrapper = shallow(<CreateInitiativeModal
        close={() => {}}
        financeCodeTypes={[]}
        initiative={mockInitiative}
        initiativeStatuses={[]}
        show
        title="title"
      />)
      wrapper.update()

      expect(wrapper.find(InitiativeFormComponent).prop('initiative')).toEqual(mockInitiative)
    })

    it('defaults to an empty initiative when sent initiative is undefined', () => {
      const wrapper = shallow(<CreateInitiativeModal initiative={{}} />)
      wrapper.update()
      expect(wrapper.find(InitiativeFormComponent).prop('initiative')).toEqual({})
    })
  })

  describe('on save', () => {
    it('calls save', () => {
      const saveStub = sandbox.stub()
      saveStub.resolves()
      const wrapper = shallow(<CreateInitiativeModal isInEditMode={false} save={saveStub} />)
      wrapper.find(InitiativeFormComponent).prop('saveInitiative')('testString', false)
      expect(saveStub.calledWith({ initiative: 'testString', isInEditMode: false, createAnotherInitiative: false })).toBe(true) // eslint-disable-line max-len
    })
  })

  describe('on cancel', () => {
    it('calls close', () => {
      const closeStub = sandbox.stub()
      const wrapper = shallow(<CreateInitiativeModal close={closeStub} />)
      wrapper.find(InitiativeFormComponent).prop('cancelAction')()
      expect(closeStub.called).toBe(true)
    })
  })
})
