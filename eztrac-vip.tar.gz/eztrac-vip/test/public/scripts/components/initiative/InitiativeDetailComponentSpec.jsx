import { shallow } from 'enzyme'
import InitiativeDetailComponent from '../../../../../public/scripts/components/initiative/InitiativeDetailComponent'
import React from 'react'

describe('InitiativeDetailComponent', () => {
  it('displays the initiative name', () => {
    const mockInitiative = { initiative_name: 'test name', status: '' }
    const wrapper = shallow(<InitiativeDetailComponent initiative={mockInitiative} />)

    expect(wrapper.find('#initiativeName').text()).toEqual('test name')
  })
  it('displays the initiative status', () => {
    const mockInitiative = { status: 'test status' }
    const wrapper = shallow(<InitiativeDetailComponent initiative={mockInitiative} />)

    expect(wrapper.find('#initiativeStatus').text()).toEqual('test status')
  })
  it('displays the initiative finance code type and value', () => {
    const mockInitiative = { finance_code_type: 'testType', finance_code_value: 'testValue' }
    const wrapper = shallow(<InitiativeDetailComponent initiative={mockInitiative} />)

    expect(wrapper.find('#financeCodeType').text()).toEqual('testType')
    expect(wrapper.find('#financeCodeValue').text()).toEqual('testValue')
  })
})
