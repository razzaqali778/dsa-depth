import * as BreadcrumbUtil from '../../../../public/scripts/util/BreadcrumbUtil'
import { Tab, Tabs } from 'react-bootstrap'
import { shallow } from 'enzyme'
import AlertUtil from '../../../../public/scripts/util/AlertUtil'
import BreadcrumbsComponent from '../../../../public/scripts/components/BreadcrumbsComponent'
import BudgetListComponent from '../../../../public/scripts/components/budget/BudgetListComponent'
import CreateInitiativeModal from '../../../../public/scripts/components/initiative/CreateInitiativeModal'
import InitiativeCardsComponent from '../../../../public/scripts/components/initiative/InitiativeCardsComponent'
import InitiativeDetailComponent from '../../../../public/scripts/components/initiative/InitiativeDetailComponent'
import React from 'react'
import UserRolesUtil from '../../../../public/scripts/util/UserRolesUtil'
import ViewInitiativeComponent from '../../../../public/scripts/components/ViewInitiativeComponent'

import agent from '../../../../public/agent'

describe('ViewInitiativeComponent', () => { // eslint-disable-line max-statements
  const sandbox = sinon.sandbox.create()
  let agentStub = {}
  let alertUtilStub = {}
  let breadcrumbUtilStub = {}
  let userRolesUtilStub = {}


  beforeEach(() => {
    agentStub = {
      get: sandbox.stub(agent, 'get'),
      post: sandbox.stub(agent, 'post'),
      put: sandbox.stub(agent, 'put'),
    }

    breadcrumbUtilStub = {
      getLineageForBreadcrumbs: sandbox.stub(BreadcrumbUtil, 'getLineageForBreadcrumbs'),
    }

    alertUtilStub = {
      setAlert: sandbox.stub(AlertUtil, 'setAlert'),
    }

    userRolesUtilStub = {
      hasEitherRole: sandbox.stub(UserRolesUtil, 'hasEitherRole'),
      hasReadWriteRole: sandbox.stub(UserRolesUtil, 'hasReadWriteRole'),
    }
    userRolesUtilStub.hasEitherRole.resolves(true)
    userRolesUtilStub.hasReadWriteRole.resolves(true)
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('on initialization', () => {
    it('displays the dashboard when user does have access', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)

      expect(wrapper.find('#viewInitiativeBody').length).toEqual(1)
    })

    it('sets up the list of initiatives with the appropriate properties', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)

      expect(wrapper.find(InitiativeCardsComponent).prop('initiatives')).toEqual([])
      expect(wrapper.find(InitiativeCardsComponent).prop('buttonText')).toEqual('Create Child')
    })

    it('renders the CreateInitiativeModalComponent with the appropriate properties', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)
      wrapper.setState({ lineage: [], initiative: { initiative_id: 'testId', parent: 'testParent' } })

      expect(wrapper.find(CreateInitiativeModal).prop('initiative')).toEqual( {
        inherited_fin_code_type: null,
        inherited_fin_code_value: null,
        inherited_activity_id: undefined,
        inherited_portfolio_code: undefined,
        inherited_program_code: undefined,
        inherited_status: undefined,
        parent: 'testId' })
      expect(wrapper.find(CreateInitiativeModal).prop('lineage')).toEqual([])
      expect(wrapper.find(CreateInitiativeModal).prop('initiativeStatuses')).toEqual([])
      expect(wrapper.find(CreateInitiativeModal).prop('financeCodeTypes')).toEqual([])
      expect(wrapper.find(CreateInitiativeModal).prop('show')).toBe(false)
      expect(wrapper.find(CreateInitiativeModal).prop('isInEditMode')).toBe(false)
      expect(wrapper.find(CreateInitiativeModal).prop('title')).toEqual('Create Child Initiative')
      expect(typeof wrapper.find(CreateInitiativeModal).prop('close')).toEqual('function')
      expect(typeof wrapper.find(CreateInitiativeModal).prop('save')).toEqual('function')
    })

    it('renders the InitiativeDetailComponent with the appropriate props', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)

      expect(wrapper.find(InitiativeDetailComponent).length).toEqual(1)
      expect(wrapper.find(InitiativeDetailComponent).prop('initiative')).toEqual({})
    })

    it('renders the Breadcrumbs component with correct props', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)

      wrapper.setState({ lineage: [], initiative: { initiative_id: 'testId' } })

      expect(wrapper.find(BreadcrumbsComponent).length).toEqual(1)
      expect(wrapper.find(BreadcrumbsComponent).prop('lineage')).toEqual([])
    })

    it('renders tabs for the children and budgets', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)

      expect(wrapper.find(Tab).getElements()[0].props.title).toEqual('Child Initiatives')
      expect(wrapper.find(Tab).getElements()[1].props.title).toEqual('Budgets')
    })

    it('the children tab should be active by default', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)

      expect(wrapper.find(Tabs).prop('activeKey')).toEqual(1)
    })

    it('renders the BudgetListComponent with the correct properties', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)

      expect(wrapper.find(BudgetListComponent).length).toEqual(1)
      expect(wrapper.find(BudgetListComponent).prop('budgets')).toEqual([])
      expect(wrapper.find(BudgetListComponent).prop('initiative')).toEqual({})
    })
  })

  describe('getBudgets', () => {
    it('sets a message if the initiative id is not defined', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)

      wrapper.instance().getBudgets()

      wrapper.update()

      expect(alertUtilStub.setAlert
        .calledWith(wrapper.instance(), 'error', 'Error: Unable to retrieve Budgets')).toBe(true)
    })

    it('sets an error when the query fails', () => {
      const errorMock = 'Unable to retrieve Budgets'
      agentStub.get.rejects(errorMock)
      const wrapper = shallow(<ViewInitiativeComponent />)

      return wrapper.instance().getBudgets('123')
        .then(() => {
          expect(alertUtilStub.setAlert.calledWith(wrapper.instance(), 'error')).toBe(true)
          expect(
            alertUtilStub.setAlert.getCall(0).args[2].toString()
          ).toEqual(
            'Error: Unable to retrieve Budgets'
          )
        })
    })
  })

  describe('getChildren', () => {
    it('sets an error if the query fails', () => {
      agentStub.get.rejects()

      const wrapper = shallow(<ViewInitiativeComponent />)
      wrapper.setState({ initiative: { initiative_id: '123' } })
      wrapper.update()

      return wrapper.instance().getChildren()
        .then(() => {
          wrapper.update()
          expect(alertUtilStub.setAlert
            .calledWith(wrapper.instance(), 'error', 'Error: Unable to retrieve Child Initiatives')).toBe(true)
        })
    })
  })

  describe('getLineage', () => {
    it('sets an error if the lineage retrieval fails', () => {
      breadcrumbUtilStub.getLineageForBreadcrumbs.resolves({ hasError: true, message: 'Error: Bad Input' })
      const wrapper = shallow(<ViewInitiativeComponent />)

      return wrapper.instance().getLineage('123')
        .then(() => {
          wrapper.update()
          expect(
            alertUtilStub.setAlert.calledWith(wrapper.instance(), 'error', 'Error: Bad Input')
          ).toBe(true)
        })
    })
  })

  describe('getInitiative', () => {
    it('sets an error if the id is not found', () => {
      const wrapper = shallow(<ViewInitiativeComponent />)

      wrapper.instance().getInitiative()

      wrapper.update()
      expect(alertUtilStub.setAlert
        .calledWith(wrapper.instance(), 'error', 'Error: Unable to retrieve Initiative')).toBe(true)
    })
  })

  describe('createInitiative', () => {
    let wrapper = {}

    beforeEach(() => {
      wrapper = shallow(<ViewInitiativeComponent params={{ initiativeId: '123' }} />)
      wrapper.instance().getLineage = sandbox.stub()
    })

    it('does not change the parent when saving the current initiative', () => {
      const initiative = { parent: '456', initiative_name: 'Test', status: 'Test' }
      agentStub.put.rejects()

      wrapper.setState({ initiativeId: '123' })

      wrapper.instance().createInitiative(initiative, true)

      expect(initiative.parent).toEqual('456')
    })

    it('sets an error when the create fails', () => {
      const initiative = { initiative_name: 'Test', status: 'Test' }
      agentStub.post.rejects()

      wrapper.setState({ initiativeId: '123' })

      return wrapper.instance().createInitiative(initiative)
        .then(() => {
          wrapper.update()
          expect(alertUtilStub.setAlert
            .calledWith(wrapper.instance(), 'error', 'Error: Unable to save Initiative')).toBe(true)
        })
    })

    it('sets an error when the update fails', () => {
      const initiative = { initiative_name: 'Test', status: 'Test' }
      agentStub.put.rejects()

      wrapper.setState({ initiativeId: '123' })

      return wrapper.instance().createInitiative(initiative, true)
        .then(() => {
          wrapper.update()
          expect(alertUtilStub.setAlert
            .calledWith(wrapper.instance(), 'error', 'Error: Unable to save Initiative')).toBe(true)
        })
    })

    it('sets the id of the newly created initiative on success', () => {
      const initiative = { initiative_name: 'Test', status: 'Test' }
      const responseMock = { body: { initiative_id: '456' } }
      agentStub.post.resolves(responseMock)

      wrapper.setState({ initiativeId: '123' })

      return wrapper.instance().createInitiative(initiative)
        .then(() => {
          wrapper.update()
          expect(wrapper.state('children')[0].initiative_id).toEqual(responseMock.body.initiative_id)
        })
    })

    it('confirms that the create modal is still open when create another is checked', async () => {
      const initiative = { initiative_name: 'Test', status: 'Test' }
      const responseMock = { body: { initiative_id: '123' } }
      agentStub.post.resolves(responseMock)
      await wrapper.instance().createInitiative({ initiative, createAnotherInitiative: true } )
      expect(wrapper.instance().state.showCreateInitiativeModal).toEqual(true)
    })

    it('confirms that the create modal is not open when create another is not checked', async () => {
      const initiative = { initiative_name: 'Test', status: 'Test', createAnotherInitiative: false }
      const responseMock = { body: { initiative_id: '123' } }
      agentStub.post.resolves(responseMock)
      await wrapper.instance().createInitiative(initiative)
      expect(wrapper.instance().state.showCreateInitiativeModal).toEqual(false)
    })
  })

  describe('the edit button', () => {
    it('onClick triggers the edit initiative modal with the appropriate props', () => {
      const mockInitiative = { initiative_name: 'testName', status: 'testStatus' }
      const wrapper = shallow(<ViewInitiativeComponent />)
      wrapper.setState({ initiative: mockInitiative })

      wrapper.find('#editButton').simulate('click')

      wrapper.update()

      expect(wrapper.find(CreateInitiativeModal).prop('title')).toEqual('Edit Initiative')
      expect(wrapper.find(CreateInitiativeModal).prop('show')).toBe(true)
      expect(wrapper.find(CreateInitiativeModal).prop('initiative')).toEqual(mockInitiative)
    })
  })
})
