
import * as RequestInitiativeUtil from '../../../../public/scripts/util/RequestInitiativeUtil'
import { shallow } from 'enzyme'
import AlertUtil from '../../../../public/scripts/util/AlertUtil'
import React from 'react'
import RequestInitiativeComponent from '../../../../public/scripts/components/RequestInitiativeComponent'

describe('RequestInitiativeComponent', () => {
  const sandbox = sinon.sandbox.create()
  let sendRequestedInitiativeStub = {}
  let alertUtilStub = {}

  beforeEach(() => {
    sendRequestedInitiativeStub = {
      sendRequestedInitiative: sandbox.stub(RequestInitiativeUtil, 'sendRequestedInitiative'),
    }

    alertUtilStub = {
      setAlert: sandbox.stub(AlertUtil, 'setAlert'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('submitRequest', () => {
    it('Successfully notifies the user', async () => {
      sendRequestedInitiativeStub.sendRequestedInitiative.resolves()
      const wrapper = shallow(<RequestInitiativeComponent />)
      await wrapper.instance().submitRequest()
      expect(alertUtilStub.setAlert.called).toBe(true)
    })
    it('fails gracefully when the POST to create initiative fails', async () => {
      const errorMock = { errorType: 'Failed POST', error: '500' }
      sendRequestedInitiativeStub.sendRequestedInitiative.throws(errorMock)
      const wrapper = shallow(<RequestInitiativeComponent />)
      await wrapper.instance().submitRequest()
      expect(alertUtilStub.setAlert.called).toBe(true)
    })
  })
})
