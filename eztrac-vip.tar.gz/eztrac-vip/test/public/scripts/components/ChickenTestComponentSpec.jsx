import { shallow } from 'enzyme'
import ChickenTestComponent from '../../../../public/scripts/components/ChickenTestComponent'
import React from 'react'

describe('ChickenTestComponent', () => {
  describe('on no selection', () => {
    it('closes the modal', () => {
      const close = sinon.stub()
      const wrapper = shallow(<ChickenTestComponent close={close} yesDestination="/" />)

      wrapper.find('#noButton').simulate('click')

      expect(close.called).toBe(true)
    })
  })
})
