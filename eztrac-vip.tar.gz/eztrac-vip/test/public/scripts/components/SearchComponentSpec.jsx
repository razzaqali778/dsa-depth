import { shallow } from 'enzyme'
import React from 'react'
import SearchComponent from '../../../../public/scripts/components/SearchComponent'

describe('SearchComponent', () => {
  it('renders a search box with an icon', () => {
    const wrapper = shallow(<SearchComponent />)

    expect(wrapper.find('#searchBox').length).toEqual(1)
    expect(wrapper.find('.glyphicon-search').length).toEqual(1)
  })

  it('displays the search text', () => {
    const searchText = 'test'

    const wrapper = shallow(<SearchComponent searchText={searchText} />)

    expect(wrapper.find('#searchBox').prop('value')).toEqual('test')
  })
})
