import { validateAllFormFields } from '../../public/scripts/util/CreateInitiativeValidator'

describe('CreateInitiativeValidator util tests', () => {
  it('Returns all form fields as true', () => {
    const testInitative = {
      name: 'A test initative name',
      typeId: 'CAP-PROJ',
      status: 'Funded',
      budget: '250000',
      fiscalYear: '2018',
      financialCode: 'TES77357',
      portfolioId: '57489',
      activityId: '123456789',
    }
    expect(validateAllFormFields(testInitative)).toBe(true)
  })
  it('Returns validation as false', () => {
    const testInitiative = {
      name: 'Another test initiative',
      typeId: 'Cookie',
      status: 'Baked',
      budget: 'Milk',
      fiscalYear: 'now',
      financialCode: 'CHO5674',
      portfolioId: '',
      activityId: '',
    }
    expect(validateAllFormFields(testInitiative)).toBe(false)
  })
})
