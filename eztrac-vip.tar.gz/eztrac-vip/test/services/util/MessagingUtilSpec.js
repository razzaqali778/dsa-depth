/**
 * @jest-environment ./test/envSetup
 */

import {
  completeTask,
  createTask,
  sendMessage,
} from '../../../services/util/MessagingUtil'
import agent from '../../../services/agent'
import azureTokenUtil from '../../../services/util/AzureTokenUtil'

describe('Messaging Util', () => {
  const sandbox = sinon.sandbox.create()

  let agentStub = {}
  let azureTokenUtilStub = {}

  beforeEach(() => {
    agentStub = {
      post: sandbox.stub(agent, 'post'),
      put: sandbox.stub(agent, 'put'),
    }

    azureTokenUtilStub = {
      getAzureToken: sandbox.stub(azureTokenUtil, 'getAzureToken'),
    }
    azureTokenUtilStub.getAzureToken.resolves('token')
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('create task', () => {
    it('returns an error when the task is malformed', () => {
      const errorMessage = 'Task is malformed'
      agentStub.post.rejects(errorMessage)

      return createTask({ title: 'testTask', sender: 'Test User' })
        .catch(error => {
          expect(error.toString()).toEqual(`Error: ${errorMessage}`)
        })
    })

    it('returns a success message when the task is created', () => {
      const task = { taskId: '1234', ok: true }
      agentStub.post.resolves({ body: task })

      return createTask({ title: 'testTask', sender: 'Test User' })
        .then(result => { expect(result).toEqual(task) })
    })
  })

  describe('complete task', () => {
    it('returns an error when the task cannot be found', () => {
      const errorMessage = 'Task does not exist'
      agentStub.put.rejects(errorMessage)

      return completeTask('1234')
        .catch(error => {
          expect(error.toString()).toEqual(`Error: ${errorMessage}`)
        })
    })

    it('returns a success message when the task is completed', () => {
      const task = { taskId: '1234', ok: true }
      agentStub.put.resolves({ body: task })

      return completeTask('1234')
        .then(result => { expect(result).toEqual(task) })
    })
  })

  describe('send message', () => {
    it('returns an error when the message is malformed', () => {
      const errorMessage = 'Message is malformed'
      agentStub.post.rejects(errorMessage)

      return sendMessage({ title: 'Test message' })
        .catch(error => {
          expect(error.toString()).toEqual(`Error: ${errorMessage}`)
        })
    })

    it('returns a success message when the message is sent', () => {
      const message = { messageId: '1234', ok: true }
      agentStub.post.resolves({ body: message })

      return sendMessage({ title: 'Test message' })
        .then(result => { expect(result).toEqual(message) })
    })
  })
})
