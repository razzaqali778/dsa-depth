/**
 * @jest-environment ./test/envSetup
 */

import { CoreServicesClient } from '../../../services/util/CoreServicesClient'
import { getFiscalYears } from '../../../services/util/BudgetUtil'
import sinon from 'sinon'

describe('BudgetUtil', () => {
  describe('getFiscalYears', () => {
    let getAllTimeFramesStub

    beforeEach(() => {
      getAllTimeFramesStub = sinon.stub(CoreServicesClient, 'getAllTimeFrames')
    })

    afterEach(() => {
      getAllTimeFramesStub.restore()
    })

    it('should return fiscal years grouped by year', async () => {
      const timeframes = [
        { startDate: '2021-01-01', endDate: '2021-01-31', isActive: true },
        { startDate: '2022-01-01', endDate: '2022-01-31', isActive: true },
        { startDate: '2021-07-01', endDate: '2021-07-31', isActive: true },
        { startDate: '2021-12-01', endDate: '2021-12-31', isActive: true },
        { startDate: '2022-06-01', endDate: '2022-06-30', isActive: true },
        { startDate: '2022-12-01', endDate: '2022-12-31', isActive: true },
      ]
      getAllTimeFramesStub.resolves(timeframes)

      const result = await getFiscalYears()

      expect(result).toEqual([
        {
          id: 2021,
          startDate: new Date('2021-01-01'),
          endDate: new Date('2021-12-31'),
          name: '2021',
        },
        {
          id: 2022,
          startDate: new Date('2022-01-01'),
          endDate: new Date('2022-12-31'),
          name: '2022',
        },
      ])
    })

    it('should return an empty array if no active timeframes', async () => {
      const timeframes = [
        { startDate: '2021-01-01', endDate: '2021-01-31', isActive: false },
        { startDate: '2021-12-01', endDate: '2021-12-31', isActive: false },
      ]
      getAllTimeFramesStub.resolves(timeframes)

      const result = await getFiscalYears()

      expect(result).toEqual([])
    })
  })
})
