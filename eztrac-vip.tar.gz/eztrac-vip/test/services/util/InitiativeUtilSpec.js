/**
 * @jest-environment ./test/envSetup
 */

import { setFinancialAttributes } from '../../../services/util/InitiativeUtil'

describe('Initiative Util', () => {
  it('updates all parents/initiatives with finance code', () => {
    const initiatives = [
      {
        initiative_id: 'child id',
        initiative_name: 'child name',
        finance_code_type: 'child type',
        finance_code_value: 'child value',
        parent: 'parent id',
      }, {
        initiative_id: 'parent id',
        initiative_name: 'parent name',
        finance_code_type: 'parent type',
        finance_code_value: 'parent value',
        parent: null,
      },
    ]
    const expected = [
      {
        initiative_id: 'parent id',
        initiative_name: 'parent name',
        finance_code_type: 'parent type',
        finance_code_value: 'parent value',
        parent: null,
        funding_initiative_name: 'parent name',
        funding_initiative_id: 'parent id',
      }, {
        initiative_id: 'child id',
        initiative_name: 'child name',
        finance_code_type: 'child type',
        finance_code_value: 'child value',
        parent: 'parent id',
        funding_initiative_name: 'child name',
        funding_initiative_id: 'child id',
      },
    ]
    expect(
      setFinancialAttributes(initiatives, { initiative_id: null })
    ).toEqual(expected)
  })
  it('It initiates the childs finance code to the parent if the child does ' +
        ' not have a finance code or funding initiative', () => {
    const initiatives = [
      {
        initiative_id: 'child id',
        initiative_name: 'child name',
        finance_code_type: null,
        finance_code_value: null,
        parent: 'parent id',
      }, {
        initiative_id: 'parent id',
        initiative_name: 'parent name',
        finance_code_type: 'parent type',
        finance_code_value: 'parent value',
        parent: null,
      },
    ]
    const expected = [
      {
        initiative_id: 'parent id',
        initiative_name: 'parent name',
        finance_code_type: 'parent type',
        finance_code_value: 'parent value',
        parent: null,
        funding_initiative_name: 'parent name',
        funding_initiative_id: 'parent id',
      }, {
        initiative_id: 'child id',
        initiative_name: 'child name',
        finance_code_type: 'parent type',
        finance_code_value: 'parent value',
        parent: 'parent id',
        funding_initiative_name: 'parent name',
        funding_initiative_id: 'parent id',
      },
    ]
    expect(
      setFinancialAttributes(initiatives, { initiative_id: null })
    ).toEqual(expected)
  })
})
