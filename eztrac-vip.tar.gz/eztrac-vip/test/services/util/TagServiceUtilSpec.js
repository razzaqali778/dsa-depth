import { parseAncestralTags } from '../../../services/util/TagServiceUtil'

describe('parseAncestralTags', () => {
  it('returns empty array when given empty array', () => {
    const expected = []
    const result = parseAncestralTags([], '')

    expect(result).toEqual(expected)
  })
  it('returns its own information', () => {
    const input = [
      {
        initiative_id: 'parent',
        level: 1,
        tag_id: 'REGION',
        tag_value: 'North America',
        parent_id: null,
      },
    ]
    const expected = [
      {
        initiative_id: 'parent',
        tag_id: 'REGION',
        tag_value: 'North America',
        level: 1,
      },
    ]

    const result = parseAncestralTags(input, 'parent')

    expect(result).toEqual(expected)
  })
  it('returns child with parent tag information', () => {
    const input = [
      {
        initiative_id: 'child',
        level: 0,
        tag_id: null,
        tag_value: null,
        parent_id: 'parent',
      },
      {
        initiative_id: 'parent',
        level: 1,
        tag_id: 'REGION',
        tag_value: 'North America',
        parent_id: null,
      },
    ]
    const expected = [
      {
        initiative_id: 'child',
        tag_id: 'REGION',
        tag_value: 'North America',
        level: 1,
      },
    ]
    const initId = 'child'
    const result = parseAncestralTags(input, initId)

    expect(result).toEqual(expected)
  })
  it('returns parent information', () => {
    const input = [
      {
        initiative_id: 'child',
        level: 0,
        tag_id: null,
        tag_value: null,
        parent_id: 'parent',
      },
      {
        initiative_id: 'parent',
        level: 1,
        tag_id: 'REGION',
        tag_value: 'North America',
        parent_id: null,
      },
    ]
    const expected = [
      {
        initiative_id: 'child',
        tag_id: 'REGION',
        tag_value: 'North America',
        level: 1,
      },
    ]

    const initId = 'child'

    const actual = parseAncestralTags(input, initId)

    expect(actual).toEqual(expected)
  })

  it('returns information for various ancestors for more than one tag', () => {
    const input = [
      {
        initiative_id: 'child',
        level: 0,
        tag_id: null,
        tag_value: null,
        parent_id: 'parent',
      },
      {
        initiative_id: 'parent',
        level: 1,
        tag_id: null,
        tag_value: null,
        parent_id: 'grandpa joe',
      },
      {
        initiative_id: 'grandpa joe',
        level: 2,
        tag_id: 'REGION',
        tag_value: 'North America',
        parent_id: 'great grandpa',
      },
      {
        initiative_id: 'great grandpa',
        level: 3,
        tag_id: 'other tag',
        tag_value: 'this gets returned',
        parent_id: null,
      },
    ]
    const expected = [
      {
        initiative_id: 'child',
        tag_id: 'REGION',
        tag_value: 'North America',
        level: 2,
      },
      {
        initiative_id: 'child',
        tag_id: 'other tag',
        tag_value: 'this gets returned',
        level: 3,
      },
    ]

    const initId = 'child'

    const actual = parseAncestralTags(input, initId)

    expect(actual).toEqual(expected)
  })
})
