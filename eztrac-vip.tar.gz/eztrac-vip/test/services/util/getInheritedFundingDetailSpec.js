import * as findInheritableParent from '../../../services/v1/initiativeUtils/findInheritableParent'
import {
  addInheritedProperty,
  getInheritedFundingDetail,
} from '../../../services/v1/initiativeUtils/getInheritedFundingDetail' // eslint-disable-line max-len

describe('getInheritedFundingDetail', () => {
  const sandbox = sinon.sandbox.create()
  let findParentStub = null

  beforeEach(() => {
    findParentStub = sandbox.stub(findInheritableParent, 'findParent')
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('getInheritedFundingDetail', () => {
    it('returns correct details when current initiative has them', () => {
      findParentStub.returns(null)

      const initiatives = [
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: null,
          finance_code_value: '1001',
          finance_code_type: 'SAP Project',
          is_inheritable: false,
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test',
          parent: '123',
          finance_code_value: '100',
          finance_code_type: 'Cost Center',
          is_inheritable: true,
        },
      ]

      const expected = {
        finance_code_value: '100',
        finance_code_type: 'Cost Center',
      }

      const result = getInheritedFundingDetail(initiatives, initiatives[1])
      expect(result).toEqual(expected)
    })
    it('returns correct details from parent', () => {
      findParentStub.returns({
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '1001',
        finance_code_type: 'SAP Project',
        is_inheritable: true,
      })

      const initiatives = [
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: null,
          finance_code_value: '1001',
          finance_code_type: 'SAP Project',
          is_inheritable: true,
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test',
          parent: '123',
          finance_code_value: null,
          finance_code_type: 'Cost Center',
          is_inheritable: true,
        },
      ]

      const expected = {
        finance_code_type: 'Cost Center',
        finance_code_value: null,
        inherited_fin_code_type: 'SAP Project',
        inherited_fin_code_value: '1001',
      }

      const result = getInheritedFundingDetail(initiatives, initiatives[1])
      expect(result).toEqual(expected)
    })
    it('returns correct details from grandparent', () => {
      findParentStub.returns({
        initiative_id: 'grandparent',
        initiative_name: 'grandparent',
        parent: null,
        finance_code_value: '10012',
        finance_code_type: 'SAP Project',
        is_inheritable: true,
      })

      const initiatives = [
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: 'grandparent',
          finance_code_value: '1001',
          finance_code_type: 'SAP Project',
          is_inheritable: false,
        },
        {
          initiative_id: 'grandparent',
          initiative_name: 'grandparent',
          parent: null,
          finance_code_value: '10012',
          finance_code_type: 'SAP Project',
          is_inheritable: true,
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test',
          parent: '123',
          finance_code_value: null,
          finance_code_type: 'Cost Center',
          is_inheritable: true,
        },
      ]

      const expected = {
        finance_code_type: 'Cost Center',
        finance_code_value: null,
        inherited_fin_code_type: 'SAP Project',
        inherited_fin_code_value: '10012',
      }

      const result = getInheritedFundingDetail(initiatives, initiatives[2])
      expect(result).toEqual(expected)
    })
    it('returns current initiatives details when no ancestors have inheritable finance code value', () => {
      findParentStub.returns(null)

      const initiatives = [
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: 'grandparent',
          finance_code_value: '1001',
          finance_code_type: 'SAP Project',
          is_inheritable: false,
        },
        {
          initiative_id: 'grandparent',
          initiative_name: 'grandparent',
          parent: null,
          finance_code_value: '10012',
          finance_code_type: 'SAP Project',
          is_inheritable: false,
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test',
          parent: '123',
          finance_code_value: null,
          finance_code_type: 'Cost Center',
          is_inheritable: true,
        },
      ]

      const expected = {
        finance_code_value: null,
        finance_code_type: 'Cost Center',
      }

      const result = getInheritedFundingDetail(initiatives, initiatives[2])
      expect(result).toEqual(expected)
    })
  })
  describe('getParentProperty with argument "status"', () => {
    it('returns status of parent', () => {
      findParentStub.returns(null)

      const initiatives = [
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: null,
          status: 'funded',
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test1',
          parent: '123',
          status: 'planning',
        },
      ]

      const expected = {
        inherited_status: 'funded',
        status: 'planning',
      }

      const result = addInheritedProperty(initiatives, initiatives[1], 'status', 'inherited_status')
      expect(result).toEqual(expected)
    })
    it('returns status of grandparent', () => {
      findParentStub.returns(null)

      const initiatives = [
        {
          initiative_id: '1234',
          initiative_name: 'Test',
          parent: null,
          status: 'completed',
        },
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: '1234',
          status: null,
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test1',
          parent: '123',
          status: null,
        },
      ]

      const expected = {
        inherited_status: 'completed',
        status: null,
      }

      const result = addInheritedProperty(initiatives, initiatives[2], 'status', 'inherited_status')
      expect(result).toEqual(expected)
    })
  })

  describe('getParentProperty with property "program_code"', () => {
    it('returns program code of parent', () => {
      findParentStub.returns(null)

      const initiatives = [
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: null,
          program_code: 'testParentPC',
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test1',
          parent: '123',
          program_code: 'testPC',
        },
      ]

      const expected = {
        inherited_program_code: 'testParentPC',
        program_code: 'testPC',
      }

      const result = addInheritedProperty(initiatives, initiatives[1], 'program_code', 'inherited_program_code')
      expect(result).toEqual(expected)
    })

    it('returns program code of grandparent', () => {
      findParentStub.returns(null)

      const initiatives = [
        {
          initiative_id: '1234',
          initiative_name: 'Test',
          parent: null,
          program_code: 'testGrandparentPC',
        },
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: '1234',
          program_code: null,
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test1',
          parent: '123',
          program_code: null,
        },
      ]

      const expected = {
        inherited_program_code: 'testGrandparentPC',
        program_code: null,
      }

      const result = addInheritedProperty(initiatives, initiatives[2], 'program_code', 'inherited_program_code')
      expect(result).toEqual(expected)
    })
  })

  describe('getParentProperty with property "portfolio_code"', () => {
    it('returns portfolio code of parent', () => {
      findParentStub.returns(null)

      const initiatives = [
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: null,
          portfolio_code: 'testParentPC',
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test1',
          parent: '123',
          portfolio_code: 'testPC',
        },
      ]

      const expected = {
        inherited_portfolio_code: 'testParentPC',
        portfolio_code: 'testPC',
      }

      const result = addInheritedProperty(initiatives, initiatives[1], 'portfolio_code', 'inherited_portfolio_code')
      expect(result).toEqual(expected)
    })

    it('returns portfolio code of grandparent', () => {
      findParentStub.returns(null)

      const initiatives = [
        {
          initiative_id: '1234',
          initiative_name: 'Test',
          parent: null,
          portfolio_code: 'testGrandparentPC',
        },
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: '1234',
          portfolio_code: null,
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test1',
          parent: '123',
          portfolio_code: null,
        },
      ]

      const expected = {
        inherited_portfolio_code: 'testGrandparentPC',
        portfolio_code: null,
      }

      const result = addInheritedProperty(initiatives, initiatives[2], 'portfolio_code', 'inherited_portfolio_code')
      expect(result).toEqual(expected)
    })
  })
})
