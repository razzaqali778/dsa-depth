import { findPreviousAudit } from '../../../services/util/audit'


export const makeBudgetAuditDB = num => ({
  table_type: 'budget',
  modified_by: 'person',
  modified_time: 10 * num,
  entity: {
    initiative_id: num,
    amount: 500,
    fiscal_year: 2017,
  },
})
export const makeBudgetAudit = num => ({
  table_type: 'budget',
  modified_by: 'person',
  modified_time: 10 * num,
  initiative_id: num,
  amount: 500,
})

export const makeInitiativeAuditDB = num => ({
  table_type: 'initiative',
  modified_by: 'person',
  modified_time: 10 * num,
  entity: {
    initiative_id: num,
    initiative_name: `some initiative name ${num}`,
    finance_code_type: 'abc',
  },
})
export const makeInitiativeAudit = num => ({
  table_type: 'initiative',
  modified_by: 'person',
  modified_time: 10 * num,
  initiative_id: num,
  initiative_name: `some initiative name ${num}`,
  finance_code_type: 'abc',
})
describe('findPreviousAudit', () => {
  it('finds last entry for initiatives from most recent', () => {
    const initiativeAudit1 = makeInitiativeAuditDB(1)
    const initiativeAudit2 = {
      ...initiativeAudit1,
      entity: {
        ...initiativeAudit1.entity,
        initative_name: 'yoyoyo',
      },
      modified_time: 30,
    }

    const audits = [
      makeBudgetAuditDB(1),
      makeBudgetAuditDB(2),
      initiativeAudit1,
      makeBudgetAuditDB(3),
      makeInitiativeAuditDB(3),
      initiativeAudit2,
    ]

    const expected = initiativeAudit1

    const actual = findPreviousAudit(audits, initiativeAudit2)

    expect(actual).toEqual(expected)
  })

  it('finds last entry for budgets from most recent', () => {
    const budgetAudit1 = makeBudgetAuditDB(1)
    const budgetAudit2 = {
      ...budgetAudit1,
      entity: {
        ...budgetAudit1.entity,
        amount: 9000,
      },
      modified_time: 20,
    }
    const budgetAudit3 = { // same budget as initiative for budget 1, but diff fiscal year
      ...budgetAudit1,
      entity: {
        ...budgetAudit1.entity,
        fiscal_year: 2019,
      },
    }

    const audits = [
      makeInitiativeAuditDB(1),
      makeInitiativeAuditDB(2),
      budgetAudit1,
      makeBudgetAuditDB(5),
      budgetAudit3,
      makeInitiativeAuditDB(3),
      budgetAudit2,
    ]

    const actual = findPreviousAudit(audits, budgetAudit2)
    expect(actual).toEqual(budgetAudit1)
  })

  it('returns undefined if last audit doesnt exist', () => {
    const initiativeAudit1 = makeInitiativeAuditDB(1)
    const initiativeAudit2 = { ...initiativeAudit1, modified_time: 20 }
    const audits = [
      makeBudgetAuditDB(1),
      makeBudgetAuditDB(2),
      initiativeAudit1,
      makeBudgetAuditDB(3),
      makeInitiativeAuditDB(3),
      initiativeAudit2,
    ]

    const actual = findPreviousAudit(audits, initiativeAudit1)
    expect(actual).toBe(undefined) // eslint-disable-line no-undef
  })
})
