import { findParent, findParentWithProperty } from '../../../services/v1/initiativeUtils/findInheritableParent'

describe('findParent', () => {
  it('returns null when no ancestors can return a finance code value', () => {
    const initiatives = [
      {
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '100',
        is_inheritable: false,
      },
      {
        // current initiative
        initiative_id: 'tester',
        initiative_name: 'test',
        parent: '123',
        finance_code_value: '100',
        is_inheritable: true,
      },
    ]

    const expected = null

    const result = findParent(initiatives, initiatives[1])
    expect(result).toEqual(expected)
  })
  it('returns nearest ancestor that allows inheritance and finance code', () => {
    const initiatives = [
      {
        initiative_id: '123',
        initiative_name: 'Test',
        parent: null,
        finance_code_value: '1001',
        is_inheritable: true,
      },
      {
        // current initiative
        initiative_id: 'tester',
        initiative_name: 'test',
        parent: '123',
        finance_code_value: '100',
        is_inheritable: true,
      },
    ]

    const expected = {
      initiative_id: '123',
      initiative_name: 'Test',
      parent: null,
      finance_code_value: '1001',
      is_inheritable: true,
    }

    const result = findParent(initiatives, initiatives[1])
    expect(result).toEqual(expected)
  })
  it('returns nearest ancestor that allows inheritance and finance code from multiple ancestors', () => {
    const initiatives = [
      {
        initiative_id: 'grandparent',
        initiative_name: 'grandparent',
        parent: null,
        finance_code_value: '100',
        is_inheritable: true,
      },
      {
        initiative_id: '123',
        initiative_name: 'Test',
        parent: 'grandparent',
        finance_code_value: '1001',
        is_inheritable: false,
      },
      {
        // current initiative
        initiative_id: 'tester',
        initiative_name: 'test',
        parent: '123',
        finance_code_value: null,
        is_inheritable: true,
      },
    ]

    const expected = {
      initiative_id: 'grandparent',
      initiative_name: 'grandparent',
      parent: null,
      finance_code_value: '100',
      is_inheritable: true,
    }

    const result = findParent(initiatives, initiatives[1])
    expect(result).toEqual(expected)
  })
  it('returns null if current initiative is top level', () => {
    const initiatives = [
      {
        initiative_id: 'toplevel',
        initiative_name: 'toplevel',
        parent: null,
        finance_code_value: null,
        is_inheritable: true,
      },
    ]

    const result = findParent(initiatives, initiatives[0])
    expect(result).toEqual(null)
  })
  describe('findParentWithProperty', () => {
    it('returns nearest ancestor that has a status', () => {
      const initiatives = [
        {
          initiative_id: 'grandparent',
          initiative_name: 'grandparent',
          parent: null,
          status: 'yup',
        },
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: 'grandparent',
          status: '',
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test',
          parent: '123',
          status: '',
        },
      ]

      const expected = {
        initiative_id: 'grandparent',
        initiative_name: 'grandparent',
        parent: null,
        status: 'yup',
      }

      const result = findParentWithProperty(initiatives, initiatives[2], 'status')
      expect(result).toEqual(expected)
    })
    it('returns null if no ancestor has a status', () => {
      const initiatives = [
        {
          initiative_id: 'grandparent',
          initiative_name: 'grandparent',
          parent: null,
          status: '',
        },
        {
          initiative_id: '123',
          initiative_name: 'Test',
          parent: 'grandparent',
          status: '',
        },
        {
          // current initiative
          initiative_id: 'tester',
          initiative_name: 'test',
          parent: '123',
          status: '',
        },
      ]

      const expected = null

      const result = findParentWithProperty(initiatives, initiatives[2], 'status')
      expect(result).toEqual(expected)
    })
  })
})
