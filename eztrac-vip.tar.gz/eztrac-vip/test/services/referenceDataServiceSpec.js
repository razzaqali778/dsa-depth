/**
 * @jest-environment ./test/envSetup
 */

import { getFinancialTagTypes, getInitiativeStatus, getInitiativeTypes } from '../../services/referenceDataService'
import ReferenceDataDao from '../../services/dao/referenceDataDao'

describe('reference data service tests', () => {
  const sandbox = sinon.sandbox.create()

  let resStub = {}
  let ReferenceDataDaoStub = {}

  beforeEach( () => {
    ReferenceDataDaoStub = {
      getAllInitiativeStatus: sandbox.stub(ReferenceDataDao, 'getAllInitiativeStatus'),
      getAllFinancialTagTypes: sandbox.stub(ReferenceDataDao, 'getAllFinancialTagTypes'),
      getAllInitiativeTypes: sandbox.stub(ReferenceDataDao, 'getAllInitiativeTypes'),
    }

    resStub = {
      json: sandbox.stub(),
      status: sandbox.stub(),
      send: sandbox.stub(),
    }
    resStub.status.returns(resStub)
  })

  afterEach( () => {
    sandbox.restore()
  })

  describe('getInitiativeStatus', () => {
    it('returns all initiative status on success', async () => {
      const initiativeStatus = [{ initiative_status_id: '123' }]
      ReferenceDataDaoStub.getAllInitiativeStatus.resolves(initiativeStatus)
      await getInitiativeStatus({}, resStub)
      expect(resStub.json.calledWith(initiativeStatus)).toBe(true)
    })

    it('returns an error on failure', async () => {
      const errorMock = { message: 'Bad Input' }
      ReferenceDataDaoStub.getAllInitiativeStatus.rejects(errorMock)
      try {
        await getInitiativeStatus({}, resStub)
      } catch ( error ) {
        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(errorMock.message)).toBe(true)
      }
    })
  })

  describe('getFinancialTagTypes', () => {
    it('returns all financial tag types on success', async () => {
      const financialTagTypes = [{ financial_tag_type_id: '123' }]
      ReferenceDataDaoStub.getAllFinancialTagTypes.resolves(financialTagTypes)
      await getFinancialTagTypes({}, resStub)
      expect(resStub.json.calledWith(financialTagTypes)).toBe(true)
    })

    it('returns an error on failure', async () => {
      const errorMock = { message: 'Bad Input' }
      ReferenceDataDaoStub.getAllFinancialTagTypes.rejects(errorMock)
      try {
        await getFinancialTagTypes({}, resStub)
      } catch ( error ) {
        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(errorMock.message)).toBe(true)
      }
    })
  })

  describe('getInitiativeTypes', () => {
    it('returns all initiative types', async () => {
      const initiativeTypes = [{ id: 1, value: 'Capital Project' }]
      ReferenceDataDaoStub.getAllInitiativeTypes.resolves(initiativeTypes)
      await getInitiativeTypes({}, resStub)
      expect(resStub.json.calledWith(initiativeTypes)).toBe(true)
    })
  })
})
