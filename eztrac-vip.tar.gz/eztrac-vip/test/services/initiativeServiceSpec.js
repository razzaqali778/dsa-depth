/**
 * @jest-environment ./test/envSetup
 */

import * as InitiativeDao from '../../services/dao/initiativeDao'
import * as InitiativeUtil from '../../services/util/InitiativeUtil'
import {
  createInitiative,
  getAllInitiatives,
  getAllInitiativesWithFundingInitiativeDetails,
  getAllInitiativesWithParentInheritanceAndBudgets,
  getAllInitiativesWithStatusOverride,
  getAllTopLevelInitiatives,
  getChildInitiatives,
  getFundingInitiatives,
  getInitiative,
  getInitiativeHierarchy,
  getInitiativeLineage,
  getInitiativesForSelect,
  getInitiativesWithBudgetParentDetails,
  updateInitiative,
} from '../../services/initiativeService'
import getInheritedFundingDetail from '../../services/v1/initiativeUtils/getInheritedFundingDetail'

const createValidInitiative = () => ({
  initiative_name: 'Francklen Initiative',
  status: 'Funded',
  finance_code_type: 'WBS Element',
  finance_code_value: 'Test Code Value',
  parent: null,
})

describe('initiativeService', () => {
  // eslint-disable-line max-statements
  const sandbox = sinon.sandbox.create()

  let reqMock = {}
  let resStub = {}
  let initiativeDaoStub = {}
  let initiativeUtilStub = {}

  beforeEach(() => {
    initiativeDaoStub = {
      getAllInitiatives: sandbox.stub(InitiativeDao, 'getAllInitiatives'),
      getTopLevelInitiatives: sandbox.stub(InitiativeDao, 'getTopLevelInitiatives'),
      getInitiativesByParent: sandbox.stub(InitiativeDao, 'getInitiativesByParent'),
      getInitiative: sandbox.stub(InitiativeDao, 'getInitiative'),
      getLineage: sandbox.stub(InitiativeDao, 'getLineage'),
      getAllFundingInitiatives: sandbox.stub(InitiativeDao, 'getAllFundingInitiatives'),
      createInitiative: sandbox.stub(InitiativeDao, 'createInitiative'),
      updateInitiative: sandbox.stub(InitiativeDao, 'updateInitiative'),
      getAllInitiativesAndBudgets: sandbox.stub(InitiativeDao, 'getAllInitiativesAndBudgets'),
      getAllInitiativesWithParentAndBudgets: sandbox.stub(InitiativeDao, 'getAllInitiativesWithParentAndBudgets'),
    }

    initiativeUtilStub = {
      setFinancialAttributes: sandbox.stub(InitiativeUtil, 'setFinancialAttributes'),
      constructInitiativeHierarchy: sandbox.stub(InitiativeUtil, 'constructInitiativeHierarchy'),
      createInitiative: sandbox.stub(InitiativeUtil, 'createInitiative'),
      updateInitiative: sandbox.stub(InitiativeUtil, 'updateInitiative'),
    }

    resStub = {
      json: sandbox.stub(),
      status: sandbox.stub(),
      send: sandbox.stub(),
    }
    resStub.status.returns(resStub)

    reqMock = { userProfile: { entitlements: {} } }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('getAllInitiativesWithFundingInitiativeDetails', () => {
    it('returns all initiatives with inherited finance code, funding initiative name and id', async () => {
      const initiatives = [
        {
          initiative_id: 'fake child id',
          initiative_name: 'fake name 2',
          finance_code_type: null,
          finance_code_value: null,
          parent: 'fake id',
        },
        {
          initiative_id: 'fake grandchild id',
          initiative_name: 'fake name 3',
          finance_code_type: null,
          finance_code_value: null,
          parent: 'fake child id',
        },
        {
          initiative_id: 'fake id',
          initiative_name: 'fake name',
          finance_code_type: 'fake type',
          finance_code_value: 'fake value',
          parent: null,
        },
      ]

      const expectedInitiativeList = [
        {
          initiative_id: 'fake id',
          initiative_name: 'fake name',
          funding_initiative_name: 'fake name',
          funding_initiative_id: 'fake id',
          finance_code_type: 'fake type',
          finance_code_value: 'fake value',
          parent: null,
        },
        {
          initiative_id: 'fake child id',
          initiative_name: 'fake name 2',
          funding_initiative_name: 'fake name',
          funding_initiative_id: 'fake id',
          finance_code_type: 'fake type',
          finance_code_value: 'fake value',
          parent: 'fake id',
        },
        {
          initiative_id: 'fake grandchild id',
          initiative_name: 'fake name 3',
          funding_initiative_name: 'fake name',
          funding_initiative_id: 'fake id',
          finance_code_type: 'fake type',
          finance_code_value: 'fake value',
          parent: 'fake child id',
        },
      ]

      initiativeDaoStub.getAllInitiatives.resolves(initiatives)

      initiativeUtilStub.setFinancialAttributes.returns(expectedInitiativeList)
      await getAllInitiativesWithFundingInitiativeDetails({ userProfile: { entitlements: {} } }, resStub)

      expect(resStub.json.calledWith(expectedInitiativeList)).toBe(true)
    })
  })

  describe('getInitiativesWithBudgetParentDetails', () => {
    let mockReq = {}
    beforeEach(() => {
      mockReq = { userProfile: { entitlements: {} }, params: { fiscalYears: '2016,2017' } }
    })

    it('when an initiative retrieval fails an error is sent', () => {
      const errorMock = { message: '500 failed', statusCode: 500 }

      initiativeDaoStub.getAllInitiativesAndBudgets.rejects(errorMock)

      return getInitiativesWithBudgetParentDetails(mockReq, resStub).then(() => {
        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(errorMock)).toBe(true)
      })
    })
    it('Verify calls setFinancialAttributes and returns JSON object', () => {
      const initiatives = []

      initiativeDaoStub.getAllInitiativesAndBudgets.resolves(initiatives)

      initiativeUtilStub.setFinancialAttributes.returns(initiatives)

      return getInitiativesWithBudgetParentDetails(mockReq, resStub).then(() => {
        expect(resStub.json.calledWith(initiatives)).toBe(true)
        expect(initiativeUtilStub.setFinancialAttributes.calledWith(initiatives, { initiative_id: null })).toBe(true)
      })
    })
  })

  describe('getAllTopLevelInitiatives', () => {
    it('returns all initiatives on success', () => {
      const initiatives = [{ initiative_id: '123' }]
      initiativeDaoStub.getTopLevelInitiatives.resolves(initiatives)

      return getAllTopLevelInitiatives(reqMock, resStub).then(() => {
        expect(resStub.json.calledWith(initiatives)).toBe(true)
      })
    })

    it('returns an error on failure', () => {
      const errorMock = { message: 'Bad Input', statusCode: 500 }
      initiativeDaoStub.getTopLevelInitiatives.rejects(errorMock)

      return getAllTopLevelInitiatives(reqMock, resStub).then(() => {
        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(errorMock)).toBe(true)
      })
    })
  })

  describe('getInitiativeHierarchy', () => {
    it.skip('generates the initiative hierarchy', async () => {
      // Currently still used in old Ez-trac project, keeping around for that purpose
      const allInitiatives = [
        { initiative_id: '1', initiative_name: 'TopLevel', parent: null },
        { initiative_id: '2', initiative_name: 'Child1', parent: '1' },
        { initiative_id: '3', initiative_name: 'Child2', parent: '1' },
        { initiative_id: '4', initiative_name: 'Grandchild1', parent: '3' },
      ]

      initiativeDaoStub.getAllInitiatives.resolves(allInitiatives)

      await getInitiativeHierarchy(reqMock, resStub)
      expect(initiativeUtilStub.constructInitiativeHierarchy.calledWith(null, allInitiatives)).toBe(true)
    })

    it('returns an error on failure', () => {
      const errorMock = { message: 'Cannot construct initiative hierarchy', statusCode: 500 }
      initiativeDaoStub.getAllInitiatives.rejects(errorMock)

      return getInitiativeHierarchy(reqMock, resStub).then(() => {
        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(errorMock)).toBe(true)
      })
    })
  })

  describe('getInitiativeLineage', () => {
    it('returns a list of lineage objects on success', () => {
      const request = { params: { initiativeId: '123' }, userProfile: { entitlements: {} } }
      const responseMock = [{ id: '123', name: 'Parent' }]
      initiativeDaoStub.getLineage.resolves(responseMock)

      return getInitiativeLineage(request, resStub).then(() => {
        expect(resStub.json.calledWith(responseMock)).toBe(true)
      })
    })

    it('returns an error on failure', () => {
      const request = { params: { initiativeId: '123' }, userProfile: { entitlements: {} } }
      const errorMock = { message: 'Error: Bad Input', statusCode: 500 }
      initiativeDaoStub.getLineage.rejects(errorMock)

      return getInitiativeLineage(request, resStub).then(() => {
        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(errorMock)).toBe(true)
      })
    })
  })

  describe('getChildInitiatives', () => {
    it('returns all child initiatives on success', () => {
      const childInitiatives = [{ initiative_id: '456', parent_id: '123' }]
      initiativeDaoStub.getInitiativesByParent.resolves(childInitiatives)

      return getChildInitiatives({ params: { parentId: '123' }, userProfile: { entitlements: {} } }, resStub).then(
        () => {
          expect(resStub.json.calledWith(childInitiatives)).toBe(true)
        }
      )
    })

    it('returns an error on failure', () => {
      const errorMock = { message: 'Bad Input', statusCode: 500 }
      initiativeDaoStub.getInitiativesByParent.rejects(errorMock)

      return getChildInitiatives({ params: { parentId: '123' }, userProfile: { entitlements: {} } }, resStub).then(
        () => {
          expect(resStub.status.calledWith(500)).toBe(true)
          expect(resStub.send.calledWith(errorMock)).toBe(true)
        }
      )
    })
  })

  describe('getInitiative', () => {
    it('returns the initiative on success', () => {
      const initiative = { initiative_id: '456', parent_id: '123' }
      initiativeDaoStub.getInitiative.resolves(initiative)

      return getInitiative({ params: { initiativeId: '123' }, userProfile: { entitlements: {} } }, resStub).then(() => {
        expect(resStub.json.calledWith(initiative)).toBe(true)
      })
    })

    it('returns an error on failure', () => {
      const errorMock = { message: 'Bad Input', statusCode: 500 }
      initiativeDaoStub.getInitiative.rejects(errorMock)

      return getInitiative({ params: { initiativeId: '123' }, userProfile: { entitlements: {} } }, resStub).then(() => {
        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(errorMock)).toBe(true)
      })
    })
  })

  describe('getAllInitiatives', () => {
    it('returns the initiatives on success', async () => {
      const initiatives = [{ initiative_id: '456', parent_id: '123' }]
      initiativeDaoStub.getAllInitiatives.resolves(initiatives)

      await getAllInitiatives(reqMock, resStub)
      expect(resStub.json.calledWith(getInheritedFundingDetail(initiatives))).toBe(true)
    })

    it('returns an error on failure', async () => {
      const errMock = { message: 'Error: Initiatives could not be retrieved', statusCode: 500 }
      initiativeDaoStub.getAllInitiatives.rejects(errMock)

      await getAllInitiatives(reqMock, resStub)
      expect(resStub.status.calledWith(500)).toBe(true)
      expect(resStub.send.calledWith(errMock)).toBe(true)
    })

    it('returns the initiatives with status overridden', async () => {
      const initiatives = [
        { initiative_id: '456', parent_id: '123', inherited_status: 'blah1' },
        { initiative_id: '457', parent_id: '124', status: '', inherited_status: 'blah' },
        { initiative_id: '458', parent_id: '125', status: 'done' },
        { initiative_id: '459', parent_id: '126', status: null, inherited_status: 'blah2' },
        { initiative_id: '450', parent_id: '127', status: null },
      ]
      const expected = [
        {
          initiative_id: '456',
          parent_id: '123',
          status: 'blah1',
          inherited_status: 'blah1',
          finance_code_value: undefined,
          finance_code_type: undefined,
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
        {
          initiative_id: '457',
          parent_id: '124',
          status: 'blah',
          inherited_status: 'blah',
          finance_code_value: undefined,
          finance_code_type: undefined,
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
        {
          initiative_id: '458',
          parent_id: '125',
          status: 'done',
          finance_code_value: undefined,
          finance_code_type: undefined,
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
        {
          initiative_id: '459',
          parent_id: '126',
          status: 'blah2',
          inherited_status: 'blah2',
          finance_code_value: undefined,
          finance_code_type: undefined,
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
        {
          initiative_id: '450',
          parent_id: '127',
          status: '',
          finance_code_value: undefined,
          finance_code_type: undefined,
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
      ]
      initiativeDaoStub.getAllInitiatives.resolves(initiatives)

      await getAllInitiativesWithStatusOverride(reqMock, resStub)
      expect(resStub.json.calledWithMatch(expected)).toBe(true)
    })
  })

  describe('getAllInitiativesWithParentInheritanceAndBudgets', () => {
    it('gets the initiatives', async () => {
      const initiatives = [
        {
          initiative_id: '1000',
          parent_id: '2000',
          status: null,
          inherited_status: 'boop',
          finance_code_type: 'type',
          finance_code_value: 'value',
        },
        {
          initiative_id: '1001',
          parent_id: '2001',
          status: null,
          inherited_status: 'boop',
          finance_code_type: null,
          finance_code_value: null,
          inherited_fin_code_type: 'type',
          inherited_fin_code_value: 'value',
        },
        {
          initiative_id: '1002',
          parent_id: '2002',
          status: 'code',
          inherited_status: 'boop',
          finance_code_type: 'type',
          finance_code_value: 'value',
        },
        {
          initiative_id: '1003',
          parent_id: '2003',
          status: 'code',
          inherited_status: 'boop',
          finance_code_type: null,
          finance_code_value: null,
          inherited_fin_code_type: 'type',
          inherited_fin_code_value: 'value',
        },
        {
          initiative_id: '1004',
          parent_id: null,
          status: 'code',
          inherited_status: 'planning',
          finance_code_type: null,
          finance_code_value: null,
        },
      ]

      const expected = [
        {
          initiative_id: '1000',
          parent_id: '2000',
          status: 'boop',
          inherited_status: 'boop',
          finance_code_type: 'type',
          finance_code_value: 'value',
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
        {
          initiative_id: '1001',
          parent_id: '2001',
          status: 'boop',
          inherited_status: 'boop',
          finance_code_type: 'type',
          finance_code_value: 'value',
          inherited_fin_code_type: 'type',
          inherited_fin_code_value: 'value',
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
        {
          initiative_id: '1002',
          parent_id: '2002',
          status: 'code',
          inherited_status: 'boop',
          finance_code_type: 'type',
          finance_code_value: 'value',
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
        {
          initiative_id: '1003',
          parent_id: '2003',
          status: 'code',
          inherited_status: 'boop',
          finance_code_type: 'type',
          finance_code_value: 'value',
          inherited_fin_code_type: 'type',
          inherited_fin_code_value: 'value',
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
        {
          initiative_id: '1004',
          parent_id: null,
          status: 'code',
          inherited_status: 'planning',
          finance_code_type: null,
          finance_code_value: null,
          portfolio_code: undefined,
          activity_id: undefined,
          program_code: undefined,
        },
      ]

      initiativeDaoStub.getAllInitiativesWithParentAndBudgets.resolves(initiatives)

      await getAllInitiativesWithParentInheritanceAndBudgets(reqMock, resStub)
      expect(resStub.json.calledWithMatch(expected)).toBe(true)
    })
  })

  describe('getFundingInitiatives', () => {
    it('gets the funding initiatives when the user has access', () => {
      initiativeDaoStub.getAllFundingInitiatives.rejects({ message: 'Error', statusCode: 500 })

      getFundingInitiatives(reqMock, resStub)

      expect(initiativeDaoStub.getAllFundingInitiatives.called).toBe(true)
    })

    it('returns an error when the query fails', async () => {
      const errMock = { message: 'Error', statusCode: 500 }
      initiativeDaoStub.getAllFundingInitiatives.rejects(errMock)

      await getFundingInitiatives(reqMock, resStub)
      expect(resStub.status.calledWith(500)).toBe(true)
      resStub.send.calledWith(errMock)
    })

    it('returns a list of all the funding initiatives when the query succeeds', () => {
      const fundingInitiatives = [{ initiative_id: '123', finance_code_value: 'finance code value' }]
      initiativeDaoStub.getAllFundingInitiatives.resolves(fundingInitiatives)

      return getFundingInitiatives(reqMock, resStub).then(() => {
        expect(resStub.json.calledWith(fundingInitiatives)).toBe(true)
      })
    })
  })

  describe('getInitiativesForSelect', () => {
    it('returns a list of name id pairs on success', async () => {
      const initiatives = [
        { initiative_id: '123', initiative_name: 'test 1', other: 'stuff' },
        { initiative_id: '456', initiative_name: 'test 2', other: 'stuff' },
      ]
      const expected = [
        { initiative_id: '123', initiative_name: 'test 1' },
        { initiative_id: '456', initiative_name: 'test 2' },
      ]
      initiativeDaoStub.getAllInitiatives.resolves(initiatives)

      await getInitiativesForSelect(reqMock, resStub)
      expect(resStub.json.calledWith(expected)).toBe(true)
    })

    it('returns an error on failure', () => {
      const errMock = { message: 'Error: Initiatives could not be retrieved', statusCode: 500 }
      initiativeDaoStub.getAllInitiatives.rejects(errMock)

      return getInitiativesForSelect(reqMock, resStub).then(() => {
        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(errMock)).toBe(true)
      })
    })
  })
  describe('update/create initiatives', () => {
    describe('create', () => {
      it('returns error response when document creation fails', async () => {
        const error = { message: 'error', statusCode: 500 }
        InitiativeDao.createInitiative.rejects(error)
        initiativeDaoStub.getAllInitiatives.resolves([])

        await createInitiative({ body: createValidInitiative(), userProfile: { entitlements: {} } }, resStub)

        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(error)).toBe(true)
      })
      it('returns an error when name already exists in a different initiative', async () => {
        const body = createValidInitiative()
        const id = 'id'
        const initiative = { ...body, modified_by: 'mskemm', initiative_id: id }
        const otherInitiative = { ...body, modified_by: 'someone-else', initiative_id: 'id2' }

        InitiativeDao.createInitiative.resolves()
        initiativeDaoStub.getAllInitiatives.resolves([{ ...initiative }, { ...otherInitiative }])

        await createInitiative({ body, userProfile: { id: 'mskemm', entitlements: {} } }, resStub)
        const expectedError = {
          dataPath: '.initiative_name',
          params: '',
          message: 'name already exists in database',
        }
        expect(resStub.status.args[0][0]).toEqual(400)
        expect(resStub.send.args[0][0]).toEqual(expectedError)
      })
      it('happy path', async () => {
        const id = 'id'
        InitiativeDao.createInitiative.resolves({ initiative_id: id })
        initiativeDaoStub.getAllInitiatives.resolves([])

        const body = createValidInitiative()
        const initiative = { ...body, modified_by: 'MSKEMM', initiative_id: id }

        await createInitiative({ body, userProfile: { id: 'mskemm', entitlements: {} } }, resStub)
        expect(initiativeDaoStub.updateInitiative.called).toBe(false)
        expect(initiativeDaoStub.createInitiative.called).toBe(true)
        expect(resStub.json.firstCall.args[0]).toEqual(initiative)
      })
    })

    describe('update', () => {
      it('rejects on put error and sends error message', async () => {
        const errorObject = { message: 'error', statusCode: 500 }

        initiativeDaoStub.updateInitiative.rejects(errorObject)
        initiativeDaoStub.getAllInitiatives.resolves([])

        const body = { ...createValidInitiative(), initiative_id: 'id' }
        await updateInitiative({ body, userProfile: { id: 'mskemm', entitlements: {} } }, resStub)

        expect(resStub.status.calledWith(500)).toBe(true)
        expect(resStub.send.calledWith(errorObject)).toBe(true)
      })
      it('returns an error when name already exists in a different initiative', async () => {
        const body = createValidInitiative()
        const id = 'id'
        const initiative = { ...body, modified_by: 'mskemm', initiative_id: id }
        const otherInitiative = { ...body, modified_by: 'someone-else', initiative_id: 'id2' }

        InitiativeDao.createInitiative.resolves()
        initiativeDaoStub.getAllInitiatives.resolves([{ ...initiative }, { ...otherInitiative }])

        await updateInitiative({ body, userProfile: { id: 'mskemm', entitlements: {} } }, resStub)
        const expectedError = {
          dataPath: '.initiative_name',
          params: '',
          message: 'name already exists in database',
        }
        expect(resStub.status.args[0][0]).toEqual(400)
        expect(resStub.send.args[0][0]).toEqual(expectedError)
      })
      it('does not error when initiative name is used by the initiative being updated', async () => {
        initiativeDaoStub.updateInitiative.resolves()

        const body = { ...createValidInitiative(), initiative_id: 'id', initiative_name: 'new name' }
        const initiative = { ...body, modified_by: 'MSKEMM' }
        initiativeDaoStub.getAllInitiatives.resolves([ initiative ])

        await updateInitiative({ body, userProfile: { id: 'mskemm', entitlements: {} } }, resStub)
        expect(initiativeDaoStub.createInitiative.called).toBe(false)
        expect(initiativeDaoStub.updateInitiative.called).toBe(true)
        expect(resStub.json.args[0][0]).toEqual(initiative)
      })
      it('happy path', async () => {
        initiativeDaoStub.updateInitiative.resolves()
        initiativeDaoStub.getAllInitiatives.resolves([])

        const body = { ...createValidInitiative(), initiative_id: 'id', initiative_name: 'new name' }
        const initiative = { ...body, modified_by: 'MSKEMM' }

        await updateInitiative({ body, userProfile: { id: 'mskemm', entitlements: {} } }, resStub)
        expect(initiativeDaoStub.createInitiative.called).toBe(false)
        expect(initiativeDaoStub.updateInitiative.called).toBe(true)
        expect(resStub.json.args[0][0]).toEqual(initiative)
      })
    })
  })
})
