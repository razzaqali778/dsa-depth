/**
 * @jest-environment ./test/envSetup
 */

/* eslint-disable max-len */
import { buildMessageBody } from '../../../../services/v2/request-initiative/update'

describe('buildMessageBody', () => {
  it('adds the included fields to the initiative request', () => {
    const requestedInitiative = { name: 'Fake Initiative', fiscalYear: '2019' }
    const startMessage = '**User ID**: testID\n\n**User Name**: testName\n\n'

    const expected = '**User ID**: testID\n\n**User Name**: testName\n\n**Name**: Fake Initiative\n\n**Fiscal Year**: 2019\n\n'

    const result = buildMessageBody(requestedInitiative, startMessage)

    expect(result).toEqual(expect.stringContaining(expected))
  })

  it('only includes relevant fields', () => {
    const requestedInitiative = { fakeOutKey: 'Fake Data' }
    const startMessage = '**User ID**: testID\n\n**User Name**: testName\n\n'

    const expected = '**User ID**: testID\n\n**User Name**: testName\n\n'

    const result = buildMessageBody(requestedInitiative, startMessage)

    expect(result).toEqual(expect.stringContaining(expected))
  })
})

