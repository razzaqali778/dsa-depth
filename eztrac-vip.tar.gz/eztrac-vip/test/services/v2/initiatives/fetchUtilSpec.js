/**
 * @jest-environment ./test/envSetup
 */

import * as tagsDao from '../../../../services/dao/tagsDao'
import getInitiativesWithInheritedTags from '../../../../services/v2/initiatives/fetchUtil'

describe('get inherited tags for initiatives', () => {
  const sampleInitiatives = [
    { id: '1a-2' },
    { id: '1b-3' },
  ]
  const validReq = { query: { fields: 'tags' } }

  it('returns the same initiatives if no tags query', async () => {
    const req = {}
    const result = await getInitiativesWithInheritedTags(req, sampleInitiatives)
    const expectedResults = [
      { id: '1a-2' },
      { id: '1b-3' },
    ]
    expect(result).toEqual(expectedResults)
  })
  it('returns empty object if sent no initiatives', async () => {
    const result = await getInitiativesWithInheritedTags(validReq, [])

    expect(result).toEqual([])
  })
  it('returns initiatives with its tags', async () => {
    const expectedResults = [
      { id: '1a-2', tags: [{ tagId: 'BUS-UNIT', tagValue: 'R&D' }] },
      { id: '1b-3', tags: [] },
    ]
    const sampleTags = [
      { initiative_id: '1a-2', parent_id: null, tag_id: 'BUS-UNIT', tag_value: 'R&D' },
    ]
    tagsDao.getAllInitiativeTags = jest.fn(() => Promise.resolve(sampleTags))
    const result = await getInitiativesWithInheritedTags(validReq, sampleInitiatives)

    expect(result).toEqual(expectedResults)
  })
  it('returns initiatives with their multiple tags', async () => {
    const expectedResults = [
      { id: '1a-2', tags: [{ tagId: 'BUS-UNIT', tagValue: 'R&D' }, { tagId: 'REGION', tagValue: 'North America' }] },
      { id: '1b-3', tags: [] },
    ]
    const sampleTags = [
      { initiative_id: '1a-2', parent_id: null, tag_id: 'BUS-UNIT', tag_value: 'R&D' },
      { initiative_id: '1a-2', parent_id: null, tag_id: 'REGION', tag_value: 'North America' },
    ]
    tagsDao.getAllInitiativeTags = jest.fn(() => Promise.resolve(sampleTags))
    const result = await getInitiativesWithInheritedTags(validReq, sampleInitiatives)

    expect(result).toEqual(expectedResults)
  })
  it('returns initiatives with their parent tags', async () => {
    const expectedResults = [
      { id: '1a-2', tags: [{ tagId: 'BUS-UNIT', tagValue: 'R&D' }, { tagId: 'REGION', tagValue: 'North America' }] },
      { id: '1b-3', tags: [] },
    ]
    const sampleTags = [
      { initiative_id: '1a-2', parent_id: '2b-4', tag_id: 'BUS-UNIT', tag_value: 'R&D' },
      { initiative_id: '2b-4', parent_id: null, tag_id: 'REGION', tag_value: 'North America' },
    ]
    tagsDao.getAllInitiativeTags = jest.fn(() => Promise.resolve(sampleTags))
    const result = await getInitiativesWithInheritedTags(validReq, sampleInitiatives)

    expect(result).toEqual(expectedResults)
  })
  it('returns initiatives with their parent and grand parent tags', async () => {
    const expectedResults = [
      { id: '1a-2',
        tags: [
          { tagId: 'BUS-UNIT', tagValue: 'R&D' },
          { tagId: 'REGION', tagValue: 'North America' },
          { tagId: 'EXTRA', tagValue: 'Stuff' },
        ] },
      { id: '1b-3', tags: [] },
    ]
    const sampleTags = [
      { initiative_id: '1a-2', parent_id: '2b-4', tag_id: 'BUS-UNIT', tag_value: 'R&D' },
      { initiative_id: '2b-4', parent_id: '3c-5', tag_id: 'REGION', tag_value: 'North America' },
      { initiative_id: '3c-5', parent_id: null, tag_id: 'EXTRA', tag_value: 'Stuff' },
    ]
    tagsDao.getAllInitiativeTags = jest.fn(() => Promise.resolve(sampleTags))
    const result = await getInitiativesWithInheritedTags(validReq, sampleInitiatives)

    expect(result).toEqual(expectedResults)
  })
  it('returns initiatives with their parent and grand parent tags but will not override an earlier tag', async () => {
    const expectedResults = [
      { id: '1a-2',
        tags: [
          { tagId: 'BUS-UNIT', tagValue: 'R&D' },
          { tagId: 'REGION', tagValue: 'North America' },
        ] },
      { id: '1b-3', tags: [] },
    ]
    const sampleTags = [
      { initiative_id: '1a-2', parent_id: '2b-4', tag_id: 'BUS-UNIT', tag_value: 'R&D' },
      { initiative_id: '2b-4', parent_id: '3c-5', tag_id: 'REGION', tag_value: 'North America' },
      { initiative_id: '3c-5', parent_id: null, tag_id: 'REGION', tag_value: 'South America' },
    ]
    tagsDao.getAllInitiativeTags = jest.fn(() => Promise.resolve(sampleTags))
    const result = await getInitiativesWithInheritedTags(validReq, sampleInitiatives)

    expect(result).toEqual(expectedResults)
  })
})

