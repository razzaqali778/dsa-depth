import addActivityId from '../../../../services/v2/initiativeUtils/addActivityId'

describe('add activity id', () => {
  it('does nothing when activity id is present', () => {
    const init1 = {
      id: 1,
      initiativeName: 'abc',
      status: 'Funded',
      financeCodeValue: 'abc',
      financeCodeType: 'cba',
      portfolioCode: 'boop',
      activityId: 'boop',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      financeCodeValue: 'ddd',
      financeCodeType: 'fff',
      portfolioCode: 'boop2',
      activityId: 'boop2',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }

    const initiatives = [ init1, init2 ]
    const expected = [ init1, init2 ]

    expect(addActivityId(initiatives)).toEqual(expected)
  })

  it('inherits from parent when it needs to', () => {
    const init1 = {
      id: 1,
      initiativeName: 'abc',
      status: 'Funded',
      financeCodeValue: 'abc',
      financeCodeType: 'cba',
      portfolioCode: 'boop',
      activityId: 'boop',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      financeCodeValue: null,
      financeCodeType: null,
      portfolioCode: null,
      activityId: null,
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
    }

    const expected2 = {
      ...init2,
      activityId: init1.activityId,
    }

    const initiatives = [ init1, init2 ]
    const expected = [ init1, expected2 ]

    expect(addActivityId(initiatives)).toEqual(expected)
  })
})
