import addFundingDetails from '../../../../services/v2/initiativeUtils/addFundingDetails'

describe('add funding details', () => {
  it('does nothing when funding details present', () => {
    const init1 = {
      id: 1,
      initiativeName: 'abc',
      status: 'Funded',
      financeCodeValue: 'abc',
      financeCodeType: 'cba',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      financeCodeValue: 'ddd',
      financeCodeType: 'fff',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }

    const expected1 = {
      ...init1,
      fundingInitiativeId: 1,
      fundingInitiativeName: 'abc',
    }
    const expected2 = {
      ...init2,
      fundingInitiativeId: 2,
      fundingInitiativeName: 'abc2',
    }

    const initiatives = [ init1, init2 ]
    const expected = [ expected1, expected2 ]

    expect(addFundingDetails(initiatives)).toEqual(expected)
  })
  it('works when parent has values', () => {
    const init1 = {
      id: 1,
      initiativeName: 'abc',
      status: 'Funded',
      financeCodeValue: 'abc',
      financeCodeType: 'cba',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      financeCodeValue: null,
      financeCodeType: null,
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
    }

    const expected1 = {
      ...init1,
      fundingInitiativeId: 1,
      fundingInitiativeName: 'abc',
    }

    const expected2 = {
      ...init2,
      financeCodeValue: init1.financeCodeValue,
      financeCodeType: init1.financeCodeType,
      fundingInitiativeId: init1.id,
      fundingInitiativeName: init1.initiativeName,
    }

    const initiatives = [ init1, init2 ]
    const expected = [ expected1, expected2 ]

    expect(addFundingDetails(initiatives)).toEqual(expected)
  })
  it('works when parent does not have values', () => {
    const init1 = {
      id: 1,
      initiativeName: 'abc',
      status: 'Funded',
      financeCodeValue: null,
      financeCodeType: null,
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      financeCodeValue: null,
      financeCodeType: null,
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
    }
    const init3 = {
      id: 3,
      initiativeName: 'abc3',
      status: 'Funded',
      financeCodeValue: 'some value',
      financeCodeType: 'some type',
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
    }

    const expected1 = {
      ...init1,
      fundingInitiativeId: 1,
      fundingInitiativeName: 'abc',
    }

    const expected2 = {
      ...init2,
      fundingInitiativeId: 1,
      fundingInitiativeName: 'abc',
    }

    const expected3 = {
      ...init3,
      fundingInitiativeId: 3,
      fundingInitiativeName: 'abc3',
    }

    const initiatives = [ init1, init2, init3 ]
    const expected = [ expected1, expected2, expected3 ]

    expect(addFundingDetails(initiatives)).toEqual(expected)
  })
  it('works when parent does not have values but grandparent does', () => {
    const init0 = {
      id: 0,
      initiativeName: 'abc0',
      status: 'Funded',
      financeCodeValue: 'grandparent value',
      financeCodeType: 'grandparent type',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const init1 = {
      id: 1,
      initiativeName: 'abc1',
      status: 'Funded',
      financeCodeValue: null,
      financeCodeType: null,
      parentId: 0,
      parentName: 'grandparent',
      budgets: [],
      tags: [],
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      financeCodeValue: null,
      financeCodeType: null,
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
    }
    const init3 = {
      id: 3,
      initiativeName: 'abc3',
      status: 'Funded',
      financeCodeValue: 'some value',
      financeCodeType: 'some type',
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
    }
    const expected0 = {
      ...init0,
      fundingInitiativeId: 0,
      fundingInitiativeName: 'abc0',
    }
    const expected1 = {
      ...init1,
      financeCodeValue: 'grandparent value',
      financeCodeType: 'grandparent type',
      fundingInitiativeId: 0,
      fundingInitiativeName: 'abc0',
    }
    const expected2 = {
      ...init2,
      financeCodeValue: 'grandparent value',
      financeCodeType: 'grandparent type',
      fundingInitiativeId: 0,
      fundingInitiativeName: 'abc0',
    }
    const expected3 = {
      ...init3,
      fundingInitiativeId: 3,
      fundingInitiativeName: 'abc3',
    }
    const initiatives = [ init0, init1, init2, init3 ]
    const expected = [ expected0, expected1, expected2, expected3 ]

    const result = addFundingDetails(initiatives)
    expect(result).toEqual(expected)
  })
})
