import getInheritableProperty from '../../../../services/v2/initiativeUtils/getInheritableProperty'

describe('getInheritableProperty', () => {
  it('returns status when passing "status" argument and status is present', () => {
    const init1 = {
      id: 1,
      initiativeName: 'abc',
      status: 'Completed',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const result = getInheritableProperty(
      [ init1, init2 ],
      init1,
      'status',
      'parent_status'
    )
    expect(result).toEqual(`${init1.status}`)
  })

  it(`returns parent status when passing "status" argument
    and current initiative status is null`, () => {
    const parentInit = {
      id: 1,
      initiativeName: 'abc',
      status: 'Completed',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const childInit = {
      id: 2,
      initiativeName: 'abc2',
      status: null,
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
    }
    const result = getInheritableProperty(
      [ parentInit, childInit ],
      childInit,
      'status',
      'parent_status'
    )
    expect(result).toEqual(`${parentInit.status}`)
  })

  it(`returns grandparent status when passing "status" argument
    and current initiative status as well as parent status are null`, () => {
    const grandparentInit = {
      id: 1,
      initiativeName: 'abc',
      status: 'Completed',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const parentInit = {
      id: 2,
      initiativeName: 'abc2',
      status: null,
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
    }
    const childInit = {
      id: 3,
      initiativeName: 'abc3',
      status: null,
      parentId: 2,
      parentName: 'abc2',
      budgets: [],
      tags: [],
    }
    const result = getInheritableProperty(
      [ grandparentInit, parentInit, childInit ],
      childInit,
      'status',
      'parent_status'
    )
    expect(result).toEqual(`${grandparentInit.status}`)
  })

  it('returns programCode when passing "programCode" argument and programCode is present', () => {
    const init1 = {
      id: 1,
      initiativeName: 'abc',
      status: 'Completed',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
      programCode: '00001',
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const result = getInheritableProperty(
      [ init1, init2 ],
      init1,
      'programCode',
      'parent_program_code'
    )
    expect(result).toEqual(`${init1.programCode}`)
  })

  it(`returns parent programCode when passing "programCode" argument 
    and current initiative programCode is null`, () => {
    const parentInit = {
      id: 1,
      initiativeName: 'abc',
      status: 'Completed',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
      programCode: '1234',
    }
    const childInit = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
      programCode: null,
    }
    const result = getInheritableProperty(
      [ parentInit, childInit ],
      childInit,
      'programCode',
      'parent_program_code'
    )
    expect(result).toEqual(`${parentInit.programCode}`)
  })

  it('returns portfolioCode when passing "portfolioCode" argument and portfolioCode is present', () => {
    const init1 = {
      id: 1,
      initiativeName: 'abc',
      status: 'Completed',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
      portfolioCode: '00001',
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const result = getInheritableProperty(
      [ init1, init2 ],
      init1,
      'portfolioCode',
      'parent_portfolio_code'
    )
    expect(result).toEqual(`${init1.portfolioCode}`)
  })

  it(`returns parent portfolioCode when passing "portfolioCode" argument 
    and current initiative portfolioCode is null`, () => {
    const parentInit = {
      id: 1,
      initiativeName: 'abc',
      status: 'Completed',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
      portfolioCode: '1234',
    }
    const childInit = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      parentId: 1,
      parentName: 'abc',
      budgets: [],
      tags: [],
      portfolioCode: null,
    }
    const result = getInheritableProperty(
      [ parentInit, childInit ],
      childInit,
      'portfolioCode',
      'parent_portfolio_code'
    )
    expect(result).toEqual(`${parentInit.portfolioCode}`)
  })
})
