import cycleCheck from '../../../../services/v2/initiativeUtils/cycleCheck'

describe('cycleCheck', () => {
  it('returns an empty array when no cycles', () => {
    const initiatives = [
      { id: 1, parentId: null },
      { id: 2, parentId: 1 },
      { id: 3, parentId: 1 },
      { id: 4, parentId: 3 },
      { id: 5, parentId: 4 },
    ]
    const expected = []
    const actual = cycleCheck(initiatives)

    expect(actual).toEqual(expected)
  })
  it('finds cycles in initiatives', () => {
    const initiatives = [
      { id: 1, parentId: null },
      { id: 2, parentId: 1 },
      { id: 3, parentId: 7 },
      { id: 4, parentId: 3 },
      { id: 5, parentId: 4 },
      { id: 6, parentId: 5 },
      { id: 7, parentId: 6 },
    ]

    const expected = [ [ 3, 4, 5, 6, 7 ] ]
    const actual = cycleCheck(initiatives)

    expect(actual).toEqual(expected)
  })
  it('finds multiple cycles in initiatives', () => {
    const initiatives = [
      { id: 1, parentId: null },
      { id: 2, parentId: 4 },
      { id: 3, parentId: 2 },
      { id: 4, parentId: 3 },
      { id: 5, parentId: 9 },
      { id: 6, parentId: 5 },
      { id: 7, parentId: 6 },
      { id: 8, parentId: 6 },
      { id: 9, parentId: 8 },
    ]

    const expected = [ [ 2, 3, 4 ], [ 5, 6, 8, 9 ] ]
    const actual = cycleCheck(initiatives)

    expect(actual).toEqual(expected)
  })

  it('does not return nodes that arent part of the cycle', () => {
    const initiatives = [
      { id: 9, parentId: 11 },
      { id: 2, parentId: 3 },
      { id: 3, parentId: 4 },
      { id: 4, parentId: 11 },
      { id: 11, parentId: 2 },
    ]

    const expected = [ [ 2, 3, 4, 11 ] ]
    const actual = cycleCheck(initiatives)

    expect(actual).toEqual(expected)
  })
})
