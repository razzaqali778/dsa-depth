import {
  buildTree,
  findAllChildren,
  getRootNodes,
  reduceTree,
} from '../../../../services/v2/initiativeUtils/treeHelpers'


const initiatives = [
  { id: 1, parentId: null },
  { id: 2, parentId: 1 },
  { id: 3, parentId: 1 },
  { id: 4, parentId: null },
  { id: 5, parentId: 4 },
  { id: 6, parentId: 1 },
  { id: 7, parentId: 2 },
  { id: 8, parentId: 2 },
  { id: 9, parentId: null },
  { id: 10, parentId: 1 },
]


describe('Reduces tree', () => {
  it('Builds array of trees from entirety of initiatives', () => {
    const expectedResult = [{
      id: 1,
      children: [
        { id: 2,
          children: [
            { id: 7, parentId: 2, children: [] },
            { id: 8, parentId: 2, children: [] },
          ],
          parentId: 1,
        },
        { id: 3, parentId: 1, children: [] },
        { id: 6, parentId: 1, children: [] },
        { id: 10, parentId: 1, children: [] },
      ],
      parentId: null,
    },
    { id: 4,
      children: [
        { id: 5, parentId: 4, children: [] },
      ],
      parentId: null,
    },
    { id: 9, parentId: null, children: [] },
    ]

    const actualResult = reduceTree(initiatives)

    expect(actualResult).toEqual(expectedResult)
  })
})

describe('Gets rood nodes from initiative list', () => {
  it('Searches for initiatives with no parents', () => {
    const expectedReturn = [
      { id: 1, parentId: null },
      { id: 4, parentId: null },
      { id: 9, parentId: null },
    ]

    const actualReturn = getRootNodes(initiatives)

    expect(actualReturn).toEqual(expectedReturn)
  })
})

describe('Builds tree from root node', () => {
  it('Returns root if no children.', () => {
    const root = { id: 10, parentId: null }
    const expectedResult = {
      ...root,
      children: [],
    }

    const actualResult = buildTree( initiatives, root )

    expect(actualResult).toEqual(expectedResult)
  })


  it('Recursively builds tree', () => {
    const root = { id: 1, parentId: null }

    const expectedResult = {
      id: 1,
      children: [
        { id: 2,
          children: [
            { id: 7, parentId: 2, children: [] },
            { id: 8, parentId: 2, children: [] },
          ],
          parentId: 1,
        },
        { id: 3, parentId: 1, children: [] },
        { id: 6, parentId: 1, children: [] },
        { id: 10, parentId: 1, children: [] },
      ],
      parentId: null,
    }

    const actualResult = buildTree( initiatives, root )

    expect(actualResult).toEqual(expectedResult)
  })
})

describe('Finds all children of a particular node', () => {
  it('Finds tree', () => {
    const rootNode = { id: 1, parentId: null }

    const expectedReturn = [
      { id: 2, parentId: 1 },
      { id: 3, parentId: 1 },
      { id: 6, parentId: 1 },
      { id: 10, parentId: 1 },
    ]

    const actualReturn = findAllChildren(initiatives, rootNode)

    expect(actualReturn).toEqual(expectedReturn)
  })
})
