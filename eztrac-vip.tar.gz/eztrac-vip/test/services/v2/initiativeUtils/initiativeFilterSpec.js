import {
  filterAllocable,
  filterStatus,
} from '../../../../services/v2/initiativeUtils/initiativeFilter'

describe('initiativeFilter', () => {
  it('returns the same object if isAllocable is NOT in the request query', () => {
    const request = { query: {} }
    const initiatives = [
      { id: 1, initiativeName: 'a', isAllocable: false },
      { id: 2, initiativeName: 'b', isAllocable: true },
    ]
    const result = filterAllocable(request, initiatives)

    expect(result).toEqual(initiatives)
  })

  it('returns only allocable initiative if isAllocable is true in the request query', () => {
    const request = { query: { isAllocable: true } }
    const initiatives = [
      { id: 1, initiativeName: 'a', isAllocable: false },
      { id: 2, initiativeName: 'b', isAllocable: true },
    ]
    const expected = [
      { id: 2, initiativeName: 'b', isAllocable: true },
    ]
    const result = filterAllocable(request, initiatives)

    expect(result).toEqual(expected)
  })
  it('returns only unallocable initiatives if isAllocable is false in the request query', () => {
    const request = { query: { isAllocable: false } }
    const initiatives = [
      { id: 1, initiativeName: 'a', isAllocable: false },
      { id: 2, initiativeName: 'b', isAllocable: true },
    ]
    const expected = [
      { id: 1, initiativeName: 'a', isAllocable: false },
    ]
    const result = filterAllocable(request, initiatives)

    expect(result).toEqual(expected)
  })
  it('returns only funded initiatives when specifying that as the status', () => {
    const request = { query: { status: 'Funded' } }
    const initiatives = [
      { id: 1, initiativeName: 'a', status: 'Funded' },
      { id: 2, initiativeName: 'b', status: null },
    ]
    const expected = [
      { id: 1, initiativeName: 'a', status: 'Funded' },
    ]
    const result = filterStatus(request, initiatives)

    expect(result).toEqual(expected)
  })
})
