import {
  getAllTranslator,
  getByIdTranslator,
  getChildrenByIdTranslator,
} from '../../../../services/v2/initiativeUtils/initiativeQueryTranslator'

const strip = s => s.replace(/\s+/g, ' ').replace(/\s,/g, ',')

const assert = (actual, expected) => expect(strip(actual)).toEqual(strip(expected))

const queryFields = `i.initiative_id as id
    , i.initiative_name as "initiativeName"
    , i.status
    , i.finance_code_value as "financeCodeValue"
    , i.finance_code_type as "financeCodeType"
    , i.portfolio_code as "portfolioCode"
    , i.activity_id as "activityId"
    , i.is_allocable as "isAllocable"
    , i.type_id as "typeId"
    , i.is_inheritable as "isInheritable"
    , i.parent as "parentId"
    , i.program_code as "programCode"
    `

describe('initiative query translator for getting all', () => {
  it('returns base SELECT statement for no query', () => {
    const req = {
      query: {},
    }

    const expected = `SELECT
      ${queryFields}
      FROM initiative i`

    const actual = getAllTranslator(req)

    assert(actual, expected)
  })

  it('returns budgetRows in query', () => {
    const req = {
      query: { fields: [ 'budgets' ] },
    }

    const expected = `SELECT
    ${queryFields}, ARRAY(
    SELECT ROW_TO_JSON(budgetRow)
    FROM (
      SELECT fiscal_year as "fiscalYear", amount
      FROM budget
      WHERE initiative_id = i.initiative_id
      ) as budgetRow
    ) as budgets
    FROM initiative i`

    const actual = getAllTranslator(req)

    assert(actual, expected)
  })

  it('returns tags in query', () => {
    const req = {
      query: { fields: [ 'tags' ] },
    }

    const expected = `SELECT
    ${queryFields}, ARRAY(
    SELECT ROW_TO_JSON(tagRow)
    FROM (
      SELECT tag_id as "tagId", tag_value as "tagValue"
      FROM initiative_tags
      WHERE initiative_id = i.initiative_id
      ) as tagRow
    ) as tags
    FROM initiative i`

    const actual = getAllTranslator(req)

    assert(actual, expected)
  })

  it('returns types in query', () => {
    const req = {
      query: { fields: [ 'types' ] },
    }

    const expected = `SELECT
    ${queryFields}, (SELECT value as "typeValue"
      FROM initiative_type
      WHERE id = i.type_id)
      FROM initiative i`

    const actual = getAllTranslator(req)

    assert(actual, expected)
  })

  it('includes parents in query', () => {
    const req = { query: { fields: [ 'parent' ] } }

    const expected = `SELECT
    ${queryFields}
    , p.initiative_id as "parentId"
    , p.initiative_name as "parentName"
    , p.status as "parent_status"
    , p.program_code as "parent_program_code"
    , p.portfolio_code as "parent_portfolio_code"
    , p.activity_id as "parent_activity_id"
    FROM initiative i
    LEFT JOIN initiative p ON p.initiative_id = i.parent`
    const actual = getAllTranslator(req)

    assert(actual, expected)
  })
  it('includes parents in query by default if includeFundingDetails is true', () => {
    const req = { query: { fields: [ 'fundingDetails' ] } }

    const expected = `SELECT
    ${queryFields}
    , p.initiative_id as "parentId"
    , p.initiative_name as "parentName"
    , p.status as "parent_status"
    , p.program_code as "parent_program_code"
    , p.portfolio_code as "parent_portfolio_code"
    , p.activity_id as "parent_activity_id"
    FROM initiative i
    LEFT JOIN initiative p ON p.initiative_id = i.parent`
    const actual = getAllTranslator(req)

    assert(actual, expected)
  })

  // it('adds filter on is_allocable = true', () => {
  //   const req = { query: { isAllocable: true } }

  //   const expected = `SELECT
  //   ${queryFields}
  //   FROM initiative i
  //   WHERE i.is_allocable = TRUE`

  //   const actual = getAllTranslator(req)

  //   assert(actual, expected)
  // })

  // it('adds filter on is_allocable = false', () => {
  //   const req = { query: { isAllocable: false } }

  //   const expected = `SELECT
  //   ${queryFields}
  //   FROM initiative i
  //   WHERE i.is_allocable = FALSE`

  //   const actual = getAllTranslator(req)

  //   assert(actual, expected)
  // })

  it('puts them all together', () => {
    const req = { query: {
      fields: [ 'parent', 'tags', 'budgets', 'types' ],
      isAllocable: false,
    } }

    const expected = `SELECT
      i.initiative_id as id
      , i.initiative_name as "initiativeName"
      , i.status
      , i.finance_code_value as "financeCodeValue"
      , i.finance_code_type as "financeCodeType"
      , i.portfolio_code as "portfolioCode"
      , i.activity_id as "activityId"
      , i.is_allocable as "isAllocable"
      , i.type_id as "typeId"
      , i.is_inheritable as "isInheritable"
      , i.parent as "parentId"
      , i.program_code as "programCode"
      , p.initiative_id as "parentId"
      , p.initiative_name as "parentName"
      , p.status as "parent_status"
      , p.program_code as "parent_program_code"
      , p.portfolio_code as "parent_portfolio_code"
      , p.activity_id as "parent_activity_id"
      , ARRAY(
          SELECT ROW_TO_JSON(budgetRow)
          FROM (
            SELECT fiscal_year as "fiscalYear", amount
            FROM budget
            WHERE initiative_id = i.initiative_id
        ) as budgetRow
      ) as budgets
      , ARRAY(
          SELECT ROW_TO_JSON(tagRow)
          FROM (
            SELECT tag_id as "tagId", tag_value as "tagValue"
            FROM initiative_tags
              WHERE initiative_id = i.initiative_id
          ) as tagRow
      ) as tags
      , (SELECT value as "typeValue"
        FROM initiative_type
          WHERE id = i.type_id)
      FROM initiative i
      LEFT JOIN initiative p ON p.initiative_id = i.parent`
    const actual = getAllTranslator(req)

    assert(actual, expected)
  })
})

describe('initiative query translator for individual initiative', () => {
  it('works for base case', () => {
    const req = {
      query: {},
      params: { id: '123' },
    }

    const expected = `SELECT
      ${queryFields}
      FROM initiative i
      WHERE i.initiative_id = '123'`

    const actual = getByIdTranslator(req)

    assert(actual, expected)
  })
})

describe('initiative query translator for initiative children', () => {
  it('works for base case', () => {
    const req = {
      query: {},
      params: { id: '123' },
    }

    const expected = `SELECT
      ${queryFields}
      FROM initiative i
      WHERE i.parent = '123'`

    const actual = getChildrenByIdTranslator(req)

    assert(actual, expected)
  })
})
