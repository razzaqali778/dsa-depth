import determineInheritableProperties from '../../../../services/v2/initiativeUtils/determineInheritableProperties'

describe('determines initiative inheritable properties', () => {
  it('returns properties when properties is present', () => {
    const init1 = {
      id: 1,
      initiativeName: 'abc',
      status: 'Completed',
      portfolioCode: 'portfolioCode',
      programCode: 'pCode',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const init2 = {
      id: 2,
      initiativeName: 'abc2',
      status: 'Funded',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const result = determineInheritableProperties([ init1, init2 ])
    expect(result).toContainEqual(init1)
    expect(result).toContainEqual(init2)
  })
  it('provide properties from the parent when child initiative properties are empty', () => {
    const init1 = {
      id: '1',
      initiativeName: 'abc',
      status: '',
      parentId: '2',
      parentName: 'abc2',
      budgets: [],
      tags: [],
    }
    const init2 = {
      id: '2',
      initiativeName: 'abc2',
      portfolioCode: 'portfolioCode',
      programCode: 'pCode',
      status: 'Funded',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const initResult = {
      id: '1',
      initiativeName: 'abc',
      portfolioCode: 'portfolioCode',
      programCode: 'pCode',
      status: 'Funded',
      parentId: '2',
      parentName: 'abc2',
      budgets: [],
      tags: [],
    }

    const result = determineInheritableProperties([ init1, init2 ])
    expect(result).toContainEqual(initResult)
    expect(result).toContainEqual(init2)
  })
  it('provide properties from nearest ancestor when child inheritable properties are empty', () => {
    const child = {
      id: '1',
      initiativeName: 'abc',
      status: '',
      parentId: '2',
      parentName: 'abc2',
      programCode: 'childProgramCode',
      budgets: [],
      tags: [],
    }
    const parent = {
      id: '2',
      initiativeName: 'abc2',
      status: '',
      parentId: '3',
      portfolioCode: 'portfolioCodeParent',
      parentName: 'abc3',
      budgets: [],
      tags: [],
    }
    const grandparent = {
      id: '3',
      initiativeName: 'abc3',
      portfolioCode: 'portfolioCodeGrandParent',
      programCode: 'pCode',
      status: 'Planning',
      parentId: null,
      parentName: null,
      budgets: [],
      tags: [],
    }
    const childResult = {
      id: '1',
      initiativeName: 'abc',
      portfolioCode: 'portfolioCodeParent',
      programCode: 'childProgramCode',
      status: 'Planning',
      parentId: '2',
      parentName: 'abc2',
      budgets: [],
      tags: [],
    }
    const parentResult = {
      id: '2',
      initiativeName: 'abc2',
      portfolioCode: 'portfolioCodeParent',
      programCode: 'pCode',
      status: 'Planning',
      parentId: '3',
      parentName: 'abc3',
      budgets: [],
      tags: [],
    }
    const result = determineInheritableProperties([ grandparent, child, parent ])

    expect(result).toContainEqual(grandparent)
    expect(result).toContainEqual(parentResult)
    expect(result).toContainEqual(childResult)
  })
})
