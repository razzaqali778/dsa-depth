/**
 * @jest-environment ./test/envSetup
 */

import * as InitiativeDaoV2 from '../../../../services/dao/initiativeDaoV2'
import { postInitiative, putInitiative } from '../../../../services/v2/initiative/update'

describe('initiative update', () => {
  it('POSTs a new initiative', async () => {
    const initiative = {
      id: '1234',
      name: 'init1',
      status: 'stat',
      financeCodeType: 'type',
      financeCodeValue: 'val',
      parent: null,
      modifiedBy: 'mktess',
      typeId: 1,
      isAllocable: true,
    }

    InitiativeDaoV2.createInitiative = jest.fn(() => Promise.resolve(initiative))

    const req = {
      body: initiative,
      userProfile: { id: 'someone' },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await postInitiative(req, res)
    expect(InitiativeDaoV2.createInitiative).toBeCalledWith({ ...initiative, modifiedBy: 'SOMEONE' })
    expect(res.json).toBeCalledWith(initiative)
  })

  it('PUTs an update to an initiative', async () => {
    const initiative = {
      id: '1234',
      name: 'init1',
      status: 'stat',
      financeCodeType: 'type',
      financeCodeValue: 'val',
      parent: null,
      modifiedBy: 'mktess',
      typeId: 1,
      isAllocable: true,
    }

    InitiativeDaoV2.updateInitiative = jest.fn(() => Promise.resolve(initiative))

    const req = {
      body: initiative,
      userProfile: { id: 'someone' },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await putInitiative(req, res)
    expect(InitiativeDaoV2.updateInitiative).toBeCalledWith({ ...initiative, modifiedBy: 'SOMEONE' })
    expect(res.json).toBeCalledWith(initiative)
  })
})
