/**
 * @jest-environment ./test/envSetup
 */

import * as dao from '../../../../services/dao/initiativeDao'
import * as getInheritedDetailsForSingle from '../../../../services/v2/initiativeUtils/getInheritedDetailsForSingle'
import * as tagsDao from '../../../../services/dao/tagsDao'
import { fetchFundingDetails, fetchInheritedTags, getChildren } from '../../../../services/v2/initiative/fetchUtils'
import map from 'lodash/map'

describe('get children', () => {
  const makeChild = num => ({
    id: num,
    initiativeName: `init${num}`,
  })
  const makeChildren = () => [ makeChild(1), makeChild(2), makeChild(3) ]

  beforeEach(() => {
    dao.executeQuery = jest.fn(() => Promise.resolve({}))
  })
  it('returns empty object if req.query.includeChildren is false', async () => {
    const req = { query: {} }
    const result = await getChildren(req)

    expect(result).toEqual({})
  })

  it('returns children unmodified if fundingDetails parent provided', async () => {
    const req = { query: { includeChildren: true }, params: { id: '123' } }
    const children = makeChildren()
    dao.executeQuery = jest.fn(() => Promise.resolve(children))
    const result = await getChildren(req)

    expect(result).toEqual({ children })
  })

  it('adds funding details to children if given', async () => {
    const req = { query: { includeChildren: true }, params: { id: '123' } }
    const fundingDetails = { financeCodeValue: 'abc', financeCodeType: 'def' }
    const children = makeChildren()
    const expected = map(children, child => ({
      ...child,
      ...fundingDetails,
    }))
    dao.executeQuery = jest.fn(() => Promise.resolve(children))
    const result = await getChildren(req, fundingDetails)

    expect(result).toEqual({ children: expected })
  })

  it('adds funding details to children if given without overwriting present values', async () => {
    const req = { query: { includeChildren: true }, params: { id: '123' } }
    const fundingDetails = { financeCodeValue: 'abc', financeCodeType: 'def' }
    const unmodifiedChild = { ...makeChild(100),
      financeCodeValue: 'presentValue',
      financeCodeType: 'presentType',
      portfolioCode: 'presentCode',
      activityId: 'presentId',
      programCode: 'presentProgramCode',
    }

    const children = [ ...makeChildren(), unmodifiedChild ]
    const expectedChildren = [ ...map(makeChildren(), child => ({ ...child, ...fundingDetails })), unmodifiedChild ]

    dao.executeQuery = jest.fn(() => Promise.resolve(children))
    const result = await getChildren(req, fundingDetails)

    expect(result).toEqual({ children: expectedChildren })
  })
})

describe('fetch funding details', () => {
  beforeEach(() => {
    getInheritedDetailsForSingle.default = jest.fn(() => {})
  })
  it('calls getInheritedDetailsForSingle', async () => {
    const req = { query: {}, params: { id: '123' } }
    const expectedDetails = {
      financeCodeValue: 'presentValue',
      financeCodeType: 'presentType',
      portfolioCode: 'presentCode',
      activityId: 'presentId',
      programCode: 'presentProgramCode',
    }
    getInheritedDetailsForSingle.default = jest.fn(() => expectedDetails)
    const result = await fetchFundingDetails(req, {})

    expect(result).toEqual(expectedDetails)
  })
})

describe('fetchInheritedTags', () => {
  it('returns nothing if tags parameter is not present', async () => {
    const req = { query: {} }
    const result = await fetchInheritedTags(req)

    expect(result).toEqual({ tags: [] })
  })
  it('returns relevant tags if tags parameter is present', async () => {
    const expectedId = '123'
    const ancestralTags = [
      { level: 1, tag_id: 'BUS-UNIT', tag_value: 'Enterprise' },
      { level: 2, tag_id: 'REGION', tag_value: 'North America' },
    ]
    tagsDao.getAncestralTags = jest.fn(id => {
      expect(id).toEqual(expectedId)

      return Promise.resolve(ancestralTags)
    })
    const req = { query: { fields: 'tags' }, params: { id: expectedId } }
    const expected = {
      tags: [{ tagId: 'BUS-UNIT', tagValue: 'Enterprise' }, { tagId: 'REGION', tagValue: 'North America' }],
    }
    const result = await fetchInheritedTags(req)

    expect(result).toEqual(expected)
  })
  it('returns most recent tags if tags parameter is present and there are multiple ancestral tags', async () => {
    const expectedId = '123'
    const ancestralTags = [
      { level: 0, tag_id: 'BUS-UNIT', tag_value: 'blah' },
      { level: 1, tag_id: 'BUS-UNIT', tag_value: 'Enterprise' },
      { level: 2, tag_id: 'REGION', tag_value: 'North America' },
      { level: 3, tag_id: 'REGION', tag_value: 'South America' },
    ]
    tagsDao.getAncestralTags = jest.fn(id => {
      expect(id).toEqual(expectedId)

      return Promise.resolve(ancestralTags)
    })
    const req = { query: { fields: 'tags' }, params: { id: expectedId } }
    const expected = {
      tags: [{ tagId: 'BUS-UNIT', tagValue: 'blah' }, { tagId: 'REGION', tagValue: 'North America' }],
    }
    const result = await fetchInheritedTags(req)

    expect(result).toEqual(expected)
  })
})
