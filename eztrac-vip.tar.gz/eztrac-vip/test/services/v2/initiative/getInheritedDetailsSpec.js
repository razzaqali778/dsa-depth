/**
 * @jest-environment ./test/envSetup
 */

import * as dao from '../../../../services/dao/initiativeDao'
import findInheritedDetailsForSingle from '../../../../services/v2/initiativeUtils/getInheritedDetailsForSingle'
// import map from 'lodash/map'

describe('return inherited details for single initiative', () => {
  it('returns the four fields if present', async () => {
    const expectedResult = {
      status: 'Funded',
      financeCodeValue: '234',
      financeCodeType: '123',
      portfolioCode: 'Yes',
      activityId: 'Yes',
      programCode: 'Yes',
    }

    const result = await findInheritedDetailsForSingle(
      'Funded',
      '234',
      '123',
      'Yes',
      'Yes',
      'Yes',
      'f7a9bb40-47c7-11e8-9bb7-8faa32298608'
    )
    expect(result).toEqual(expectedResult)
  })
  it('gets the fields from a parent if not present in current initiative', async () => {
    const expectedResult = {
      status: 'Funded',
      financeCodeValue: '123',
      financeCodeType: '234',
      portfolioCode: 'Yes',
      activityId: 'Yes',
      programCode: 'Yes',
    }
    const parent = {
      status: 'Funded',
      finance_code_value: '123',
      finance_code_type: '234',
      portfolio_code: 'Yes',
      activityId: 'Yes',
      programCode: 'Yes',
      id: '4',
    }
    dao.getInitiative = jest.fn(() => Promise.resolve(parent))

    const result = await findInheritedDetailsForSingle('', '', '', '', '', '', '4')
    expect(result).toEqual(expectedResult)
  })
  it('gets only the fields needed from a parent if not present in current initiative', async () => {
    const expectedResult = {
      status: 'AArrrgh',
      financeCodeValue: '5',
      financeCodeType: '234',
      portfolioCode: 'Yes',
      activityId: 'Yes',
      programCode: 'Yes',
    }
    const parent = {
      status: 'Funded',
      finance_code_value: '123',
      finance_code_type: '234',
      portfolio_code: 'Yes',
      activityId: 'Yes',
      programCode: 'Yes',
      id: '4',
    }
    dao.getInitiative = jest.fn(() => Promise.resolve(parent))

    const result = await findInheritedDetailsForSingle('AArrrgh', '5', '', '', '', '', '4')
    expect(result).toEqual(expectedResult)
  })
  it('gets only the fields needed from a grandparent if not present in current initiative or parent', async () => {
    const expectedResult = {
      status: 'GPstatus',
      financeCodeValue: 'childValue',
      financeCodeType: '234',
      portfolioCode: 'Yes',
      activityId: 'Yes',
      programCode: 'Yes',
    }
    const parent = {
      status: '',
      finance_code_value: '',
      finance_code_type: '234',
      portfolio_code: '',
      activityId: '',
      programCode: '',
      id: '4',
      parent: '6',
    }
    const grandparent = {
      status: 'GPstatus',
      finance_code_value: '123',
      finance_code_type: '234',
      portfolio_code: 'Yes',
      activityId: 'Yes',
      programCode: 'Yes',
      id: '6',
    }

    dao.getInitiative = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(parent))
      .mockImplementationOnce(() => Promise.resolve(grandparent))

    const result = await findInheritedDetailsForSingle('', 'childValue', '', '', '', '', '4')
    expect(result).toEqual(expectedResult)
  })
  it('get correct info w/null and undefined fields', async () => {
    const expectedResult = {
      status: 'GPstatus',
      financeCodeValue: '123',
      financeCodeType: '234',
      portfolioCode: 'Yes',
      activityId: 'Yes',
      programCode: 'Yes',
    }
    const parent = {
      status: '',
      finance_code_value: '',
      finance_code_type: '234',
      portfolio_code: 'Yes',
      activityId: 'Yes',
      programCode: 'Yes',
      id: '4',
      parent: '6',
    }
    const grandparent = {
      status: 'GPstatus',
      finance_code_value: '123',
      finance_code_type: '234',
      portfolio_code: 'No',
      activityId: 'No',
      programCode: 'No',
      id: '6',
    }

    dao.getInitiative = jest
      .fn()
      .mockImplementationOnce(() => Promise.resolve(parent))
      .mockImplementationOnce(() => Promise.resolve(grandparent))

    const result = await findInheritedDetailsForSingle(null, undefined, undefined, undefined, undefined, undefined, '4')
    expect(result).toEqual(expectedResult)
  })
})
