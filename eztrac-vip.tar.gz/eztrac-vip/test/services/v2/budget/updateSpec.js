/**
 * @jest-environment ./test/envSetup
 */

import * as BudgetSplitDAO from '../../../../services/dao/budgetSplitDao'
import * as V2BudgetDao from '../../../../services/dao/budgetDaoV2'
import { postBudget, putBudget } from '../../../../services/v2/budgets/update'

describe('v2 budget update', () => {
  it('POSTs a new budget with no splits', async () => {
    const budget = {
      fiscalYear: 2019,
      initiativeId: 123,
      amount: 500,
      splits: [],
    }
    V2BudgetDao.createBudget = jest.fn(() => Promise.resolve({ budgetId: 1 }))
    BudgetSplitDAO.insertBudgetSplits = jest.fn(() => Promise.resolve('hi'))
    const req = {
      body: budget,
      userProfile: { id: 'someone' },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await postBudget(req, res)
    expect(V2BudgetDao.createBudget).toBeCalledWith({ ...budget, modifiedBy: 'SOMEONE' })
    expect(BudgetSplitDAO.insertBudgetSplits).toHaveBeenCalledTimes(0)
    expect(res.json).toBeCalledWith({ budgetId: 1 })
  })
  it('POSTs a new budget with splits', async () => {
    const splits = [{
      splitValue: 'Some Community',
      splitField: 'COMMUNITY',
      amount: 500,
    }]
    const budget = {
      fiscalYear: 2019,
      initiativeId: 123,
      amount: 500,
      splits,
    }
    V2BudgetDao.createBudget = jest.fn(() => Promise.resolve({ budgetId: 1 }))
    BudgetSplitDAO.insertBudgetSplits = jest.fn(() => Promise.resolve('hi'))
    const req = {
      body: budget,
      userProfile: { id: 'someone' },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await postBudget(req, res)
    expect(V2BudgetDao.createBudget).toBeCalledWith({ ...budget, modifiedBy: 'SOMEONE' })
    expect(BudgetSplitDAO.insertBudgetSplits).toBeCalledWith(1, splits)
    expect(res.json).toBeCalledWith({ budgetId: 1 })
  })

  it('PUTs an update to a budget when all split budget IDs match', async () => {
    const splits = [{
      splitValue: 'Some Community',
      splitField: 'COMMUNITY',
      amount: 500,
      budgetId: 1,
    }, {
      splitValue: 'Some Community2',
      splitField: 'COMMUNITY',
      amount: 500,
      budgetId: 1,
    }]
    const budget = {
      fiscalYear: 2019,
      initiativeId: 123,
      amount: 500,
      splits,
      budgetId: 1,
    }
    V2BudgetDao.updateBudget = jest.fn(() => Promise.resolve({ budgetId: 1, return: 'data' }))
    BudgetSplitDAO.insertBudgetSplits = jest.fn(() => Promise.resolve('hi'))
    const req = {
      body: budget,
      userProfile: { id: 'someone' },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await putBudget(req, res)

    expect(V2BudgetDao.updateBudget).toBeCalledWith({ ...budget, modifiedBy: 'SOMEONE' })
    expect(BudgetSplitDAO.insertBudgetSplits).toBeCalledWith(1, splits)
    expect(res.json).toBeCalledWith({ return: 'data' })
  })
})
