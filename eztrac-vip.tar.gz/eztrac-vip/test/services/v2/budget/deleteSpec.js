/**
 * @jest-environment ./test/envSetup
 */

// TODO: IMPELEMENT THESE TESTS
import * as BudgetSplitDAO from '../../../../services/dao/budgetSplitDao'
import { deleteByBudgetId } from '../../../../services/v2/budgets/delete'

describe('v2 budget delete', () => {
  it('deletes splits by budget ID', async () => {
    BudgetSplitDAO.deleteSplitsByBudgetId = jest.fn(() => Promise.resolve('hi'))
    const req = {
      params: { id: '123' },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await deleteByBudgetId(req, res)

    expect(BudgetSplitDAO.deleteSplitsByBudgetId).toBeCalledWith('123')
    expect(res.json).toBeCalledWith('hi')
  })
  it('fails to delete splits by budget ID', async () => {
    BudgetSplitDAO.deleteSplitsByBudgetId = jest.fn(() => Promise.reject('error'))
    const req = {
      params: { id: '123' },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await deleteByBudgetId(req, res)

    expect(BudgetSplitDAO.deleteSplitsByBudgetId).toBeCalledWith('123')
    expect(res.status).toBeCalledWith(500)
    expect(res.json).toBeCalledWith('error')
  })
})
