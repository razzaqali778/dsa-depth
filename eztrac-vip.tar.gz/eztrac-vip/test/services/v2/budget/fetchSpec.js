/**
 * @jest-environment ./test/envSetup
 */

// TODO: IMPELEMENT THESE TESTS
import * as BudgetSplitDAO from '../../../../services/dao/budgetSplitDao'
import * as V2BudgetDao from '../../../../services/dao/budgetDaoV2'
import { getBudgetsByInitiativeId,
  getParentBudgetByInitiativeId,
  getSplitsById } from '../../../../services/v2/budgets/fetch'

describe('v2 budget fetch', () => {
  it('fetches budget splits by initiative id', async () => {
    BudgetSplitDAO.fetchSplitsByBudgetId = jest.fn(() => Promise.resolve('hi'))
    const req = {
      params: { id: '123' },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await getSplitsById(req, res)

    expect(BudgetSplitDAO.fetchSplitsByBudgetId).toBeCalledWith('123')
    expect(res.json).toBeCalledWith('hi')
  })

  it('fetches budgets by initiative id including splits', async () => {
    const budgets = [
      { fiscalYear: 2017, amount: 1000, initiativeId: '123', budgetId: 1 },
      { fiscalYear: 2018, amount: 1500, initiativeId: '123', budgetId: 2 },
      { fiscalYear: 2019, amount: 2000, initiativeId: '123', budgetId: 3 },
    ]
    V2BudgetDao.fetchBudgetsByInitiativeId = jest.fn(() => Promise.resolve(budgets))

    const req = {
      params: { id: '123' },
      query: {},
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await getBudgetsByInitiativeId(req, res)
    expect(V2BudgetDao.fetchBudgetsByInitiativeId).toBeCalledWith('123')
    expect(res.json).toBeCalledWith(budgets)
  })
  it('fetches budgets by initiative id including splits', async () => {
    const budgets = [
      { fiscalYear: 2017, amount: 1000, initiativeId: '123', budgetId: 1 },
      { fiscalYear: 2018, amount: 1500, initiativeId: '123', budgetId: 2 },
      { fiscalYear: 2019, amount: 2000, initiativeId: '123', budgetId: 3 },
    ]

    const b1Splits = [
      { budgetId: 1, splitAmount: 500, splitValue: 'Some Community', splitField: 'COMMUNITY' },
      { budgetId: 1, splitAmount: 400, splitValue: 'Some Community2', splitField: 'COMMUNITY' },
      { budgetId: 1, splitAmount: 100, splitValue: 'Some Community3', splitField: 'COMMUNITY' },
    ]
    const b2Splits = [
      { budgetId: 2, splitAmount: 500, splitValue: 'Some Community', splitField: 'COMMUNITY' },
      { budgetId: 2, splitAmount: 500, splitValue: 'Some Community2', splitField: 'COMMUNITY' },
      { budgetId: 2, splitAmount: 500, splitValue: 'Some Community3', splitField: 'COMMUNITY' },
    ]
    const b3Splits = [
      { budgetId: 3, splitAmount: 1000, splitValue: 'Some Community', splitField: 'COMMUNITY' },
      { budgetId: 3, splitAmount: 1000, splitValue: 'Some Community3', splitField: 'COMMUNITY' },
    ]

    const expected = [
      { fiscalYear: 2017, amount: 1000, initiativeId: '123', budgetId: 1, splits: b1Splits },
      { fiscalYear: 2018, amount: 1500, initiativeId: '123', budgetId: 2, splits: b2Splits },
      { fiscalYear: 2019, amount: 2000, initiativeId: '123', budgetId: 3, splits: b3Splits },
    ]

    V2BudgetDao.fetchBudgetsByInitiativeId = jest.fn(() => Promise.resolve(budgets))
    BudgetSplitDAO.fetchSplitsByBudgetId = jest.fn(budgetId => {
      switch ( budgetId ) {
        case 1: return Promise.resolve(b1Splits)
        case 2: return Promise.resolve(b2Splits)
        case 3: return Promise.resolve(b3Splits)
        default: return Promise.reject
      }
    })
    const req = {
      params: { id: '123' },
      query: { includeSplits: true },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await getBudgetsByInitiativeId(req, res)
    expect(V2BudgetDao.fetchBudgetsByInitiativeId).toBeCalledWith('123')
    expect(BudgetSplitDAO.fetchSplitsByBudgetId).toBeCalledWith(1)
    expect(BudgetSplitDAO.fetchSplitsByBudgetId).toBeCalledWith(2)
    expect(BudgetSplitDAO.fetchSplitsByBudgetId).toBeCalledWith(3)
    expect(res.json).toBeCalledWith(expected)
  })
  it('returns parent budget amount', async () => {
    V2BudgetDao.fetchParentBudget = jest.fn(() => Promise.resolve())
    const req = {
      params: { id: '123' },
      query: { includeSplits: true },
    }
    const res = {
      json: jest.fn(),
      status: jest.fn(() => res),
    }

    await getParentBudgetByInitiativeId(req, res)
    expect(V2BudgetDao.fetchParentBudget).toBeCalledWith('123')
  })
})
