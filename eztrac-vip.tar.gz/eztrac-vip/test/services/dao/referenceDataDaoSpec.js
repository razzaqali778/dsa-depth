/**
 * @jest-environment ./test/envSetup
 */

import ReferenceDataDao from '../../../services/dao/referenceDataDao'
import client from '../../../services/db/db'

describe('ReferenceDataDao', () => {
  const sandbox = sinon.sandbox.create()
  let clientStub = {}

  beforeEach(() => {
    clientStub = {
      any: sandbox.stub(client, 'any'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('get all objects', () => {
    it('returns an error when the query fails', () => {
      const errorMock = 'Bad Request'
      const query = 'testQuery'
      clientStub.any.rejects(errorMock)

      return ReferenceDataDao.getAllObjects(query)
        .catch(error => {
          expect(clientStub.any.calledWith(query, [])).toBe(true)
          expect(error.toString()).toEqual(`Error: ${errorMock}`)
        })
    })

    it('returns a list of initiatives when the query is successful', () => {
      const responseMock = [{ id: '123' }]
      const query = 'testQuery'
      clientStub.any.resolves(responseMock)

      return ReferenceDataDao.getAllObjects(query)
        .then(results => {
          expect(clientStub.any.calledWith(query, [])).toBe(true)
          expect(results).toEqual(responseMock)
        })
    })
  })

  describe('getAllInitiativeStatus', () => {
    beforeEach(() => {
      ReferenceDataDao.getAllObjects = sandbox.stub(ReferenceDataDao, 'getAllObjects')
    })

    it('calls the get all method with the appropriate query', () => {
      ReferenceDataDao.getAllInitiativeStatus()

      expect(
        ReferenceDataDao.getAllObjects.calledWith('SELECT * FROM initiative_status;')
      ).toBe(true)
    })
  })

  describe('getAllFinancialTagTypes', () => {
    beforeEach(() => {
      ReferenceDataDao.getAllObjects = sandbox.stub(ReferenceDataDao, 'getAllObjects')
    })

    it('calls the get all method with the appropriate query', () => {
      ReferenceDataDao.getAllFinancialTagTypes()

      expect(
        ReferenceDataDao.getAllObjects.calledWith('SELECT * FROM financial_tag_type;')
      ).toBe(true)
    })
  })

  describe('getAllInitiativeTypes', () => {
    beforeEach(() => {
      ReferenceDataDao.getAllObjects = sandbox.stub(ReferenceDataDao, 'getAllObjects')
    })

    it('calls the get all method for initiative types', () => {
      ReferenceDataDao.getAllInitiativeTypes()

      expect(
        ReferenceDataDao.getAllObjects.calledWith('SELECT * FROM initiative_type;')
      ).toBe(true)
    })
  })
})
