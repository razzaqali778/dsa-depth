/**
 * @jest-environment ./test/envSetup
 */

import { getAllAudits } from '../../../services/dao/AuditDao'
import client from '../../../services/db/db'

describe('AuditDao', () => {
  const sandbox = sinon.sandbox.create()
  let clientStub = {}

  beforeEach(() => {
    clientStub = {
      any: sandbox.stub(client, 'any'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  it('gets audits directly from database', async () => {
    const getAllAuditsQuery = 'SELECT * FROM audits ORDER BY modified_time DESC'
    const auditMock = [
      {
        entity: { thing: 'wee', amount: 4000 },
        modified_by: 'crgood',
        modified_time: 'some time in the future',
      },
      {
        entity: { thingy5: 'wee', amount: 40560 },
        modified_by: 'crgood',
        modified_time: 'some timmememem',
      },
    ]
    clientStub.any.resolves(auditMock)
    await getAllAudits()
    expect(clientStub.any.firstCall.args).toEqual([ getAllAuditsQuery, [] ])
  })

  it('errors if unable to retrieve audits', async () => {
    clientStub.any.rejects(false)

    return getAllAudits('hwhehe').catch(error => {
      expect(error).toEqual({ message: 'Error retrieving audits', statusCode: 500 })
    })
  })
})
