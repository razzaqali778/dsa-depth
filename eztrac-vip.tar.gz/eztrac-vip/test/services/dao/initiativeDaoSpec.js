/**
 * @jest-environment ./test/envSetup
 */

import * as InitiativeDao from '../../../services/dao/initiativeDao'
import client from '../../../services/db/db'

describe('InitiativeDao', () => {
  const sandbox = sinon.sandbox.create()
  let clientStub = {}

  beforeEach(() => {
    clientStub = {
      any: sandbox.stub(client, 'any'),
      one: sandbox.stub(client, 'one'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('getAllInitiatives', () => {
    it('returns an error when the query fails', async () => {
      clientStub.any.rejects()
      try {
        await InitiativeDao.getAllInitiatives()
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving initiatives', statusCode: 500 })
      }
    })

    it('requests a list of initiatives from the client when successful', async () => {
      const getAllInitiativesQuery = `SELECT c.*, p.initiative_name AS parent_name
                                FROM initiative c
                                LEFT JOIN initiative p ON p.initiative_id = c.parent;`
      clientStub.any.resolves()
      await InitiativeDao.getAllInitiatives()
      expect(clientStub.any.firstCall.args).toEqual([ getAllInitiativesQuery, [] ])
    })
  })

  describe('getTopLevelInitiatives', () => {
    it('returns an error when the query fails', async () => {
      clientStub.any.rejects()
      try {
        await InitiativeDao.getTopLevelInitiatives()
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving top level initiatives', statusCode: 500 })
      }
    })

    it('calls the client requesting a list of initiatives when successful', async () => {
      const responseMock = [{ initiative_id: '123' }]
      const getTopLevelInitiativesQuery = 'SELECT * FROM initiative WHERE parent is null;'
      clientStub.any.resolves(responseMock)
      await InitiativeDao.getTopLevelInitiatives()
      expect(clientStub.any.firstCall.args).toEqual([ getTopLevelInitiativesQuery, [] ])
    })
  })

  describe('getChildinitiatives', () => {
    it('returns an error when the query fails', async () => {
      clientStub.any.rejects()
      try {
        await InitiativeDao.getInitiativesByParent('123')
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving initiatives by parent', statusCode: 500 })
      }
    })

    it('calls the client to request a list of initiatives when successful', async () => {
      const getChildInitiativesQuery = 'SELECT * FROM initiative WHERE parent = $1;'
      clientStub.any.resolves()
      await InitiativeDao.getInitiativesByParent('parent123')
      expect(clientStub.any.firstCall.args).toEqual([ getChildInitiativesQuery, [ 'parent123' ] ])
    })
  })

  describe('getAllDescendants', () => {
    it('returns an error when the query fails', async () => {
      clientStub.any.rejects()
      try {
        await InitiativeDao.getAllDescendants('123')
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving all descendants by parent', statusCode: 500 })
      }
    })

    it('calls the client to request a list of initiatives when successful', async () => {
      const getAllDescendantsQuery = `WITH RECURSIVE family AS (
        SELECT initiative_id as id, parent, initiative_name as "initiativeName" FROM initiative WHERE parent = $1
            UNION
        SELECT i.initiative_id as id, i.parent, i.initiative_name as "initiativeName" FROM initiative i
        INNER JOIN family f ON f.id = i.parent
      ) SELECT * FROM family;`
      clientStub.any.resolves()
      await InitiativeDao.getAllDescendants('parent123')
      expect(clientStub.any.firstCall.args).toEqual([ getAllDescendantsQuery, [ 'parent123' ] ])
    })
  })

  describe('getInitiative', () => {
    it('returns an error when the query fails', async () => {
      clientStub.one.rejects({ received: 0 })
      try {
        await InitiativeDao.getInitiative('123')
      } catch ( error ) {
        expect(error).toEqual({ message: 'No initiative found for given id', statusCode: 404 })
      }
    })

    it('calls the pg client to get the initiative when successful', async () => {
      const getInitiativeQuery = 'SELECT * FROM initiative WHERE initiative_id = $1;'
      clientStub.one.resolves()
      await InitiativeDao.getInitiative('init123')
      expect(clientStub.one.firstCall.args).toEqual([ getInitiativeQuery, [ 'init123' ] ])
    })
  })

  describe('getAllFundingInitiatives', () => {
    it('returns an error when the query fails', async () => {
      clientStub.any.rejects({ received: 0 })
      try {
        await InitiativeDao.getAllFundingInitiatives()
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving funding initiatives', statusCode: 500 })
      }
    })

    it('returns a list of funding initiatives when the query succeeds', async () => {
      const getFundingInitiativesQuery =
        'SELECT * FROM initiative WHERE finance_code_type IS NOT NULL AND finance_code_value IS NOT NULL;'
      clientStub.any.resolves()
      await InitiativeDao.getAllFundingInitiatives()
      expect(clientStub.any.firstCall.args).toEqual([ getFundingInitiativesQuery, [] ])
    })
  })

  describe('createInitiative', () => {
    it('returns an error when the query fails', async () => {
      clientStub.one.rejects({ message: 'Bad Request' })
      try {
        await InitiativeDao.createInitiative({ initiative_id: '123', parent: null })
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error creating initiative: Bad Request', statusCode: 500 })
      }
    })

    it('makes an insert call to postgres with the initiative information when the query is successful', async () => {
      clientStub.one.resolves()
      const createInitiativeQuery = `INSERT INTO initiative(
                                  initiative_id,
                                  initiative_name,
                                  status,
                                  finance_code_type,
                                  finance_code_value,
                                  parent,
                                  modified_by,
                                  type_id,
                                  is_allocable,
                                  is_inheritable,
                                  portfolio_code,
                                  activity_id,
                                  program_code )
                                VALUES ($1, trim($2), $3, $4, trim($5), $6, $7, $8, $9, $10, trim($11), trim($12), 
                                  trim($13))
                                RETURNING initiative_id;`
      const initiative = {
        initiative_id: '1234',
        initiative_name: 'init1',
        status: 'stat',
        finance_code_type: 'type',
        finance_code_value: 'val',
        parent: null,
        modified_by: 'mktess',
        type_id: 1,
        is_allocable: true,
        is_inheritable: true,
        portfolio_code: 'portfolioD',
        activity_id: '123456789',
        program_code: '0001',
      }
      await InitiativeDao.createInitiative(initiative)
      expect(clientStub.one.firstCall.args)
        .toEqual([ createInitiativeQuery, [ '1234', 'init1', 'stat', 'type', 'val', null, 'mktess',
          1, true, true, 'portfolioD', '123456789', '0001' ] ])
    })
  })

  describe('updateInitiative', () => {
    it('returns an error when the query fails', async () => {
      clientStub.one.rejects({ received: 0 })
      try {
        await InitiativeDao.updateInitiative({ initiative_id: '123', parent: null })
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error updating initiative', statusCode: 500 })
      }
    })

    it('makes the call to postgres to update the given initiative when successful', async () => {
      clientStub.one.resolves()
      const updateInitiativeQuery = `UPDATE initiative
                                SET initiative_name = trim($1),
                                    status = $2,
                                    finance_code_type = $3,
                                    finance_code_value = trim($4),
                                    modified_by = $5,
                                    type_id = $6,
                                    is_allocable = $7,
                                    is_inheritable = $8,
                                    portfolio_code = trim($9),
                                    activity_id = trim($10),
                                    program_code = trim($11)
                                WHERE initiative_id = $12
                                RETURNING initiative_id;`
      const initiative = {
        initiative_id: '12345',
        initiative_name: 'init1',
        status: 'stat',
        finance_code_type: 'type',
        finance_code_value: 'val',
        modified_by: 'mktess',
        type_id: 1,
        is_allocable: true,
        is_inheritable: true,
        parent: null,
        portfolio_code: 'portfolioC',
        activity_id: '123456789',
        program_code: '00001',
      }
      await InitiativeDao.updateInitiative(initiative)
      expect(clientStub.one.firstCall.args)
        .toEqual([ updateInitiativeQuery, [ 'init1', 'stat', 'type', 'val', 'mktess', 1, true,
          true, 'portfolioC', '123456789', '00001', '12345' ] ])
    })
  })
  describe('patchInitiative', () => {
    it('returns an error when the query fails', async () => {
      clientStub.one.rejects({ message: 'Bad Request' })
      try {
        await InitiativeDao.patchInitiative('some_id', 'parent-id-123')
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error patching initiative: Bad Request', statusCode: 500 })
      }
    })

    it('makes the call to postgres to update the initiative', async () => {
      clientStub.one.resolves()
      const patchInitiativeQuery =
        'UPDATE initiative SET parent = $1, otherthing = $2 WHERE initiative_id = $3 RETURNING initiative_id;'
      const initiativeId = '23456'

      const parameters = {
        parent: 'newParent',
        otherthing: 'stuff',
      }
      await InitiativeDao.patchInitiative(initiativeId, parameters)
      expect(clientStub.one.firstCall.args)
        .toEqual([ patchInitiativeQuery, [ 'newParent', 'stuff', '23456' ] ])
    })
    it('handles null values', async () => {
      clientStub.one.resolves()
      const patchInitiativeQuery =
        'UPDATE initiative SET parent = $1, otherthing = $2 WHERE initiative_id = $3 RETURNING initiative_id;'
      const initiativeId = '23456'

      const parameters = {
        parent: null,
        otherthing: 'stuff',
      }
      await InitiativeDao.patchInitiative(initiativeId, parameters)
      expect(clientStub.one.firstCall.args)
        .toEqual([ patchInitiativeQuery, [ null, 'stuff', '23456' ] ])
    })
  })

  describe('getLineage', () => {
    it('returns an error when the query fails initially', async () => {
      clientStub.one.rejects()
      try {
        await InitiativeDao.getLineage('123', [], 0)
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving initiative lineage', statusCode: 500 })
      }
    })

    it('returns an error when the query fails after first pass', async () => {
      clientStub.one.onCall(0).resolves()
      clientStub.one.onCall(1).rejects()
      const getInitiativeQuery = 'SELECT * FROM initiative WHERE initiative_id = $1;'


      try {
        await InitiativeDao.getLineage('4567', [], 0)
      } catch ( error ) {
        expect(clientStub.one.firstCall.args).toEqual([ getInitiativeQuery, [ '4567' ] ])
        expect(error).toEqual({ message: 'Error retrieving initiative lineage', statusCode: 500 })
      }
    })

    it('returns a list of lineage objects when the query is successful', async () => {
      const response1Mock = { initiative_id: '123', parent: '456', initiative_name: 'Child' }
      const response2Mock = { initiative_id: '456', parent: null, initiative_name: 'Parent' }
      const getInitiativeQuery = 'SELECT * FROM initiative WHERE initiative_id = $1;'
      clientStub.one.onCall(0).resolves(response1Mock)
      clientStub.one.onCall(1).resolves(response2Mock)
      const result = await InitiativeDao.getLineage('123', [], 0)
      expect(result.length).toEqual(2)
      expect(result[0].order).toEqual(0)
      expect(result[1].order).toEqual(1)
      expect(clientStub.one.firstCall.args).toEqual([ getInitiativeQuery, [ '123' ] ])
      expect(clientStub.one.secondCall.args).toEqual([ getInitiativeQuery, [ '456' ] ])
    })
  })

  describe('getAllInitiativesAndBudgets', () => {
    it('returns an error when the query fails', async () => {
      clientStub.any.rejects()
      try {
        await InitiativeDao.getAllInitiativesAndBudgets()
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving initiatives with budgets', statusCode: 500 })
      }
    })

    it('makes a call to get a list of initiatives when successful', async () => {
      clientStub.any.resolves()
      const getAllInitiativesAndBudgetsQuery = `SELECT i.*, ARRAY(SELECT ROW_TO_JSON(budget)
                                            FROM budget
                                            WHERE initiative_id = i.initiative_id) as budgets
                                            FROM initiative i;`
      await InitiativeDao.getAllInitiativesAndBudgets()
      expect(clientStub.any.firstCall.args).toEqual([ getAllInitiativesAndBudgetsQuery ])
    })
  })

  describe('getInitiativeMap', () => {
    it('returns an error when the query fails', async () => {
      clientStub.any.rejects()
      try {
        await InitiativeDao.getInitiativeMap()
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving initiative map', statusCode: 500 })
      }
    })

    it('makes a db call to get names and ids when the query is successful', async () => {
      const getInitiativeMapQuery = 'SELECT initiative_id, initiative_name FROM initiative'
      clientStub.any.resolves()
      await InitiativeDao.getInitiativeMap()
      expect(clientStub.any.firstCall.args).toEqual([ getInitiativeMapQuery ])
    })
  })

  describe('getAllInitiativesWithParentAndBudgets', () => {
    it('returns initiatives', async () => {
      const getInitiativesWithParentAndBudgetsQuery = `SELECT i.*,
        p.initiative_id as "parent_id", p.initiative_name as "parent_name",
        ARRAY(SELECT ROW_TO_JSON(budget) FROM budget WHERE initiative_id = i.initiative_id) as budgets from initiative i
        LEFT JOIN initiative p on p.initiative_id = i.parent;`
      clientStub.any.resolves()
      await InitiativeDao.getAllInitiativesWithParentAndBudgets()
      expect(clientStub.any.firstCall.args).toEqual([ getInitiativesWithParentAndBudgetsQuery, [] ])
    })
  })
})
