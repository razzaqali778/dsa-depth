/**
 * @jest-environment ./test/envSetup
 */

import * as Common from '../../../services/dao/common'
import {
  createBudget,
  createBudgetQuery,
  fetchBudgets,
  fetchBudgetsByInitiativeId,
  fetchParentBudget,
  getBudgetsByInitiativeIdQuery,
  getBudgetsQuery,
  getParentBudgetQuery,
  updateBudget,
  updateBudgetQuery,
} from '../../../services/dao/budgetDaoV2'

describe('Budget DAO V2 Spec', () => {
  it('fetches budgets', async () => {
    Common.executeQuery = jest.fn(() => Promise.resolve({}))
    await fetchBudgets(123)
    expect(Common.executeQuery).toBeCalledWith(getBudgetsQuery, 'any')
  })
  it('fetches budgets by initiative Id', async () => {
    Common.executeQuery = jest.fn(() => Promise.resolve({}))
    await fetchBudgetsByInitiativeId(123)
    expect(Common.executeQuery).toBeCalledWith(getBudgetsByInitiativeIdQuery, 'any', [ 123 ])
  })
  it('creates a budget', async () => {
    Common.executeQuery = jest.fn(() => Promise.resolve({}))
    const mockBudget = {
      initiativeId: 123,
      fiscalYear: 2012,
      amount: 100,
      modifiedBy: 'someone',
    }
    await createBudget(mockBudget)
    expect(Common.executeQuery).toBeCalledWith(createBudgetQuery, 'one', [ 123, 2012, 100, 'someone' ])
  })
  it('updates a budget', async () => {
    Common.executeQuery = jest.fn(() => Promise.resolve({}))
    const mockBudget = {
      initiativeId: 123,
      fiscalYear: 2012,
      amount: 100,
      modifiedBy: 'someone',
    }
    await updateBudget(mockBudget)
    expect(Common.executeQuery).toBeCalledWith(updateBudgetQuery, 'one', [ 100, 'someone', 123, 2012 ])
  })
  it('gets the parent budget amount', async () => {
    Common.executeQuery = jest.fn(() => Promise.resolve({}))
    const initiativeId = 123
    await fetchParentBudget(initiativeId)
    expect(Common.executeQuery).toBeCalledWith(getParentBudgetQuery, 'any', [ initiativeId ])
  })
})
