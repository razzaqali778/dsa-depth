/**
 * @jest-environment ./test/envSetup
 */

import * as Common from '../../../services/dao/common'
import {
  createInitiative,
  createInitiativeQuery,
  updateInitiative,
  updateInitiativeQuery,
} from '../../../services/dao/initiativeDaoV2'

describe('InitiativeDaoV2', () => {
  it('creates an initiative', async () => {
    Common.executeQuery = jest.fn(() => Promise.resolve({}))
    const initiative = {
      id: '1234',
      name: 'init1',
      status: 'stat',
      financeCodeType: 'type',
      financeCodeValue: 'val',
      parent: null,
      modifiedBy: 'mktess',
      typeId: 1,
      isAllocable: true,
      portfolioCode: 'portfolioB',
      activityId: 'activityB',
      programCode: 'programB',
    }

    await createInitiative(initiative)
    expect(Common.executeQuery).toBeCalledWith(createInitiativeQuery, 'one',
      [ '1234', 'init1', 'stat', 'type', 'val', null, 'mktess', 1, true, 'portfolioB', 'activityB', 'programB' ])
  })

  it('updates an initiative', async () => {
    Common.executeQuery = jest.fn(() => Promise.resolve({}))
    const initiative = {
      id: '1234',
      name: 'init1',
      status: 'stat',
      financeCodeType: 'type',
      financeCodeValue: 'val',
      parent: null,
      modifiedBy: 'mktess',
      typeId: 1,
      isAllocable: true,
      portfolioCode: 'portfolioA',
      activityId: 'activityA',
      programCode: 'programA',
    }

    await updateInitiative(initiative)
    expect(Common.executeQuery).toBeCalledWith(updateInitiativeQuery, 'one',
      [ '1234', 'init1', 'stat', 'type', 'val', null, 'mktess', 1, true, 'portfolioA', 'activityA', 'programA' ])
  })
})
