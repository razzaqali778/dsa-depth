/**
 * @jest-environment ./test/envSetup
 */

import {
  deleteInitiativeTag,
  getAllInitiativeTags,
  getTagNames,
  getTagOptions,
  getTags,
  tagInitiative,
} from '../../../services/dao/tagsDao'
import client from '../../../services/db/db'

describe('tagsDao', () => {
  const sandbox = sinon.sandbox.create()
  let clientStub = {}

  beforeEach(() => {
    clientStub = {
      any: sandbox.stub(client, 'any'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('getTagNames', () => {
    it('makes a call to the db client to find all tag names', async () => {
      const getTagNamesQuery = 'SELECT * FROM tag_names'
      clientStub.any.resolves()
      await getTagNames()
      expect(clientStub.any.firstCall.args).toEqual([ getTagNamesQuery, [] ])
    })
    it('returns an error when the call fails', async () => {
      clientStub.any.rejects({ message: 'Bad Request' })
      try {
        await getTagNames()
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving tag names: Bad Request', statusCode: 500 })
      }
    })
  })
  describe('getTagOptions', () => {
    it('makes a call to the db client to find all tag options', async () => {
      const getTagOptionsQuery = 'SELECT * FROM tag_options'
      clientStub.any.resolves()
      await getTagOptions()
      expect(clientStub.any.firstCall.args).toEqual([ getTagOptionsQuery, [] ])
    })
    it('returns an error when the call fails', async () => {
      clientStub.any.rejects({ message: 'Bad Request' })
      try {
        await getTagOptions()
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving tag options: Bad Request', statusCode: 500 })
      }
    })
  })
  describe('getTags', () => {
    it('makes a call to the db client to return all tags if not provided an id', async () => {
      const getAllTagsQuery = 'SELECT * FROM initiative_tags'
      clientStub.any.resolves()
      await getTags()
      expect(clientStub.any.firstCall.args).toEqual([ getAllTagsQuery ])
    })
    it('makes a call to the db client to return tags based on an initiative passed in', async () => {
      const getTagsByInitiativeQuery = 'SELECT * FROM initiative_tags WHERE initiative_id = $1 ORDER BY tag_id'
      clientStub.any.resolves()
      await getTags('12345abcde')
      expect(clientStub.any.firstCall.args).toEqual([ getTagsByInitiativeQuery, [ '12345abcde' ] ])
    })
    it('returns an error when the call for all ids fails', async () => {
      clientStub.any.rejects({ message: 'Bad Request' })
      try {
        await getTags()
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving all tags: Bad Request', statusCode: 500 })
      }
    })
    it('returns an error when the call for a single id fails', async () => {
      clientStub.any.rejects({ message: 'Bad Request' })
      try {
        await getTags('12345abcde')
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error retrieving tags by ID: Bad Request', statusCode: 500 })
      }
    })
  })

  describe('tagInitiative', () => {
    it('inserts a tag record into the database when given initiativeId, tagId and value', async () => {
      const tagInitiativeQuery =
        'DELETE FROM initiative_tags WHERE initiative_id = $1 AND tag_id = $2;'
      const insertTagInitiativeQuery =
        'INSERT INTO initiative_tags (initiative_id, tag_id, tag_value) VALUES ($1, $2, $3);'
      clientStub.any.resolves()
      await tagInitiative('12345abcde', 'REGIONS', 'USA')
      expect(clientStub.any.firstCall.args).toEqual([ tagInitiativeQuery, [ '12345abcde', 'REGIONS' ] ])
      expect(clientStub.any.secondCall.args).toEqual([ insertTagInitiativeQuery, [ '12345abcde', 'REGIONS', 'USA' ] ])
    })
    it('returns an error when the call fails', async () => {
      clientStub.any.onCall(0).resolves({})
      clientStub.any.onCall(1).rejects({ message: 'Bad Request' })
      try {
        await tagInitiative('12345abcde', 'REGIONS', 'USA')
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error inserting tags into database: Bad Request', statusCode: 500 })
      }
    })
  })

  describe('deleteInitiativeTag', () => {
    it('deletes a tag record from the database when given initiativeId, tagId and value', async () => {
      const deleteTagQuery = 'DELETE FROM initiative_tags WHERE initiative_id = $1 AND tag_id = $2;'
      clientStub.any.resolves()
      await deleteInitiativeTag('12345abcde', 'REGIONS')
      expect(clientStub.any.firstCall.args).toEqual([ deleteTagQuery, [ '12345abcde', 'REGIONS' ] ])
    })
    it('returns an error when the call fails', async () => {
      clientStub.any.rejects({ message: 'Bad Request' })
      try {
        await deleteInitiativeTag('12345abcde', 'REGIONS')
      } catch ( error ) {
        expect(error).toEqual({ message: 'Error deleting tags from the database: Bad Request', statusCode: 500 })
      }
    })
  })

  describe('getAllInitiativeTags', () => {
    it('returns tags for and parent info for each initiative', async () => {
      const findAllTagsAndParents = `SELECT i.initiative_id,
  i.parent AS "parent_id",
  tags.tag_id,
  tags.tag_value
  FROM initiative i
  left outer join initiative_tags tags on i.initiative_id = tags.initiative_id`
      clientStub.any.resolves()
      await getAllInitiativeTags()
      expect(clientStub.any.firstCall.args).toEqual([ findAllTagsAndParents ])
    })
  })
})

