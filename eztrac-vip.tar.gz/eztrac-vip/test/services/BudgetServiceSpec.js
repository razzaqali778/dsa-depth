/**
 * @jest-environment ./test/envSetup
 */

import * as BudgetUtil from '../../services/util/BudgetUtil'
import BudgetDao from '../../services/dao/BudgetDao'
import BudgetService from '../../services/BudgetService'
import moment from 'moment'

const createMockBudget = () => {
  const formatString = 'YYYY-MM-DDTHH:mm:ss.SSSSZ'
  const budget = {
    initiative_id: '123',
    fiscal_year: '2017',
    amount: 250000,
    created_by_user_id: 'test',
    created_by_user_name: 'Test',
    create_time: moment().format(formatString),
    updated_by_user_id: 'test',
    updated_by_user_name: 'test',
    update_time: moment().format(formatString),
  }

  return budget
}

describe('BudgetService', () => {
  const sandbox = sinon.sandbox.create()

  let resStub = {}
  let budgetDaoStub = {}
  let budgetUtilStub = {}

  beforeEach( () => {
    budgetDaoStub = {
      getBudgetsByInitiative: sandbox.stub(BudgetDao, 'getBudgetsByInitiative'),
      getBudgetsByFiscalYear: sandbox.stub(BudgetDao, 'getBudgetsByFiscalYear'),
      getAllBudgets: sandbox.stub(BudgetDao, 'getAllBudgets'),
      getBudgetChildren: sandbox.stub(BudgetDao, 'getBudgetChildren'),
      createBudget: sandbox.stub(BudgetDao, 'createBudget'),
      updateBudget: sandbox.stub(BudgetDao, 'updateBudget'),
      getAllFiscalYears: sandbox.stub(BudgetDao, 'getAllFiscalYears'),
      getBudgetsByFiscalYears: sandbox.stub(BudgetDao, 'getBudgetsByFiscalYears'),
    }

    budgetUtilStub = {
      getChildrenForBudgets: sandbox.stub(BudgetUtil, 'getChildrenForBudgets'),
      createBudget: sandbox.stub(BudgetUtil, 'createBudget'),
      updateBudget: sandbox.stub(BudgetUtil, 'updateBudget'),
      getFiscalYearForDate: sandbox.stub(BudgetUtil, 'getFiscalYearForDate'),
      getFiscalYears: sandbox.stub(BudgetUtil, 'getFiscalYears'),
    }

    resStub = {
      json: sandbox.stub(),
      status: sandbox.stub(),
      send: sandbox.stub(),
    }
    resStub.status.returns(resStub)
  })

  afterEach( () => {
    sandbox.restore()
  })

  describe('getBudgetsByInitiativeId', () => {
    it('gets the children of the budgets on success', () => {
      const request = { params: { initiativeId: '123' }, userProfile: { entitlements: {} } }
      const budgets = [{ initiative_id: '123', fiscal_year: '2017' }]
      budgetDaoStub.getBudgetsByInitiative.resolves(budgets)
      budgetUtilStub.getChildrenForBudgets.resolves(budgets)

      return BudgetService.getBudgetsByInitiativeId(request, resStub)
        .then(() => {
          expect(budgetUtilStub.getChildrenForBudgets.calledWith(budgets)).toBe(true)
        })
    })

    it('returns an error on failure', () => {
      const request = { params: { initiativeId: '123' }, userProfile: { entitlements: {} } }
      const errorMock = { message: 'Bad Input', statusCode: 500 }
      budgetDaoStub.getBudgetsByInitiative.rejects(errorMock)

      return BudgetService.getBudgetsByInitiativeId(request, resStub)
        .then(() => {
          expect(resStub.status.calledWith(500)).toBe(true)
          expect(resStub.send.calledWith(errorMock.message)).toBe(true)
        })
    })
  })

  describe('getBudgetsByFiscalYear', () => {
    it('returns the list of budgets on success', () => {
      const request = { params: { fiscalYear: '2017' }, userProfile: { entitlements: {} } }
      const budgets = [{ initiative_id: '123', fiscal_year: '2017' }]
      budgetDaoStub.getBudgetsByFiscalYear.resolves(budgets)

      return BudgetService.getBudgetsByFiscalYear(request, resStub)
        .then(() => {
          expect(resStub.json.calledWith(budgets)).toBe(true)
        })
    })

    it('returns an error on failure', () => {
      const request = { params: { fiscalYear: '2017' }, userProfile: { entitlements: {} } }
      const errorMock = { message: 'Bad Input', statusCode: 500 }
      budgetDaoStub.getBudgetsByFiscalYear.rejects(errorMock)

      return BudgetService.getBudgetsByFiscalYear(request, resStub)
        .then(() => {
          expect(resStub.status.calledWith(500)).toBe(true)
          expect(resStub.send.calledWith(errorMock.message)).toBe(true)
        })
    })
  })

  describe('getBudgetsByFiscalYears', () => {
    it('passes a list of fiscal years to the query', () => {
      const request = { params: { fiscalYears: '2017,2018,2019' }, userProfile: { entitlements: {} } }
      const budgets = [{ initiative_id: '123', fiscal_year: '2017' }]
      budgetDaoStub.getBudgetsByFiscalYears.resolves(budgets)

      BudgetService.getBudgetsByFiscalYears(request, resStub)

      expect(
        budgetDaoStub.getBudgetsByFiscalYears.calledWith([ '2017', '2018', '2019' ])
      ).toBe(true)
    })

    it('returns the list of budgets on success', () => {
      const request = { params: { fiscalYears: '2017,2018,2019' }, userProfile: { entitlements: {} } }
      const budgets = [{ initiative_id: '123', fiscal_year: '2017' }]
      budgetDaoStub.getBudgetsByFiscalYears.resolves(budgets)

      return BudgetService.getBudgetsByFiscalYears(request, resStub)
        .then(() => {
          expect(resStub.json.calledWith(budgets)).toBe(true)
        })
    })

    it('returns an error on failure', () => {
      const request = { params: { fiscalYears: '2017,2018,2019' }, userProfile: { entitlements: {} } }
      const errorMock = { message: 'Bad Input', statusCode: 500 }
      budgetDaoStub.getBudgetsByFiscalYears.rejects(errorMock)

      return BudgetService.getBudgetsByFiscalYears(request, resStub)
        .then(() => {
          expect(resStub.status.calledWith(500)).toBe(true)
          expect(resStub.send.calledWith(errorMock.message)).toBe(true)
        })
    })
  })

  describe('getAllBudgets', () => {
    it('returns the list of budgets on success', () => {
      const budgets = [{ initiative_id: '123', fiscal_year: '2017' }]
      budgetDaoStub.getAllBudgets.resolves(budgets)

      return BudgetService.getAllBudgets({ userProfile: { entitlements: {} } }, resStub)
        .then(() => {
          expect(resStub.json.calledWith(budgets)).toBe(true)
        })
    })

    it('returns an error on failure', () => {
      const errorMock = { message: 'Bad Input', statusCode: 500 }
      budgetDaoStub.getAllBudgets.rejects(errorMock)

      return BudgetService.getAllBudgets({ userProfile: { entitlements: {} } }, resStub)
        .then(() => {
          expect(resStub.status.calledWith(500)).toBe(true)
          expect(resStub.send.calledWith(errorMock.message)).toBe(true)
        })
    })
  })

  describe('getAllFiscalYears', () => {
    it('returns all fiscals years for which budgets exist', () => {
      const request = { userProfile: { entitlements: {} } }
      const fiscalYears = [{ fiscal_year: '2016' }, { fiscal_year: '2017' }]

      budgetUtilStub.getFiscalYears.resolves(fiscalYears)

      return BudgetService.getAllFiscalYears(request, resStub)
        .then(() => {
          expect(resStub.json.calledWith(fiscalYears)).toBe(true)
        })
    })

    it('returns an error on failure', () => {
      const request = { userProfile: { entitlements: {} } }
      const errorMock = { message: 'Internal Servor Error', statusCode: 500 }
      budgetUtilStub.getFiscalYears.rejects(errorMock)

      return BudgetService.getAllFiscalYears(request, resStub)
        .then(() => {
          expect(resStub.status.calledWith(500)).toBe(true)
          expect(resStub.send.calledWith(errorMock.message)).toBe(true)
        })
    })
  })

  describe('findFiscalYearForDate', () => {
    it('calls to find fiscal year', () => {
      const request = {
        userProfile:
                {
                  entitlements: {},
                },
        params:
                {
                  date: new Date(2016, 8, 1),
                },
      }

      BudgetService.findFiscalYearForDate(request, resStub)
      expect(budgetUtilStub.getFiscalYearForDate.called).toBe(true)
    })
  })

  describe('createBudget', () => {
    it('returns an error when budget creation fails', () => {
      const errorMock = { messsage: 'Bad Input', statusCode: 500 }
      budgetUtilStub.createBudget.rejects(errorMock)
      const budget = createMockBudget()

      return BudgetService.createBudget({ body: budget, userProfile: { entitlements: {} } }, resStub)
        .then(() => {
          expect(resStub.status.calledWith(500)).toBe(true)
          expect(resStub.send.calledWith(errorMock.message)).toBe(true)
        })
    })
  })

  describe('updateBudget', () => {
    it('returns an error when budget update fails', () => {
      const errorMock = { message: 'Bad Input', statusCode: 500 }
      budgetUtilStub.updateBudget.rejects(errorMock)
      const budget = createMockBudget()

      return BudgetService.updateBudget({ body: budget, userProfile: { entitlements: {} } }, resStub)
        .then(() => {
          expect(resStub.status.calledWith(500)).toBe(true)
          expect(resStub.send.calledWith(errorMock.message)).toBe(true)
        })
    })
  })
})
