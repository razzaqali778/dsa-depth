import { makeInitiativeAudit, makeInitiativeAuditDB } from '../util/auditSpec'
import { mapElasticResults, translateAudit } from '../../../services/elastic/helpers'
import map from 'lodash/map'

describe('map elastic results', () => {
  const makeMockSource = num => ({
    data: num,
    data2: num * 100,
    data3: `num${num}`,
  })

  const makeMockDoc = num => ({
    _index: 'someIndex',
    _type: 'someType',
    _source: makeMockSource(num),
  })

  const makeAggs = () => ({
    k1: {
      buckets: [
        { key: 'stuff', doc_count: 1 },
        { key: 'stuff2', doc_count: 2 },
        { key: 'stuff3', doc_count: 3 },
      ],
    },
    k2: {
      buckets: [
        { key: 'stuff', doc_count: 1 },
        { key: 'stuff2', doc_count: 2 },
        { key: 'stuff3', doc_count: 3 },
      ],
    },
  })

  it('maps elastic hits', () => {
    const mockResults = {
      hits: {
        hits: [
          makeMockDoc(1),
          makeMockDoc(2),
          makeMockDoc(3),
        ],
      },
      aggregations: {},
    }

    const expected = {
      hits: [
        makeMockSource(1),
        makeMockSource(2),
        makeMockSource(3),
      ],
      aggs: {},
    }

    const actual = mapElasticResults(mockResults)

    expect(actual).toEqual(expected)
  })
  it('maps elastic aggs', () => {
    const mockResults = {
      hits: [],
      aggregations: makeAggs(),
    }

    const expected = {
      hits: [],
      aggs: {
        k1: { stuff: 1, stuff2: 2, stuff3: 3 },
        k2: { stuff: 1, stuff2: 2, stuff3: 3 },
      },
    }

    const actual = mapElasticResults(mockResults)

    expect(actual).toEqual(expected)
  })

  it('maps hits and aggs', () => {
    const mockResults = {
      hits: {
        hits: [
          makeMockDoc(1),
          makeMockDoc(2),
          makeMockDoc(3),
        ],
      },
      aggregations: makeAggs(),
    }

    const expected = {
      hits: [
        makeMockSource(1),
        makeMockSource(2),
        makeMockSource(3),
      ],
      aggs: {
        k1: { stuff: 1, stuff2: 2, stuff3: 3 },
        k2: { stuff: 1, stuff2: 2, stuff3: 3 },
      },
    }

    const actual = mapElasticResults(mockResults)

    expect(actual).toEqual(expected)
  })
})

describe('translates audits prior to adding to elastic', () => {
  it('translates audits', () => {
    const initiativeAudit1 = makeInitiativeAuditDB(1)
    const initiativeAudit2 = {
      ...initiativeAudit1,
      modified_time: 20,
      entity: {
        ...initiativeAudit1.entity,
        finance_code_type: 'cba',
      },
    }

    const audits = [
      initiativeAudit1,
      initiativeAudit2,
    ]

    const expected = [
      {
        ...initiativeAudit1.entity,
        table_type: initiativeAudit1.table_type,
        modified_time: initiativeAudit1.modified_time,
        modified_by: initiativeAudit1.modified_by,
      },
      {
        ...initiativeAudit1.entity,
        table_type: initiativeAudit2.table_type,
        modified_time: initiativeAudit2.modified_time,
        modified_by: initiativeAudit2.modified_by,
        finance_code_type: 'cba',
        finance_code_type_prev: 'abc',
      },
    ]

    const actual = map(audits, translateAudit(audits))

    expect(actual).toEqual(expected)
  })

  it('returns the original audit if nothing has changed', () => {
    const dbAudits = [
      makeInitiativeAuditDB(1),
      makeInitiativeAuditDB(2),
    ]

    const translatedAudits = [
      makeInitiativeAudit(1),
      makeInitiativeAudit(2),
    ]

    const actual = map(dbAudits, translateAudit(dbAudits))

    expect(actual).toEqual(translatedAudits)
  })
})
