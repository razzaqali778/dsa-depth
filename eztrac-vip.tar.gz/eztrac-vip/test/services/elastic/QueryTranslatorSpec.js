import { aggs, intFields, strFields, translateQuery }
  from '../../../services/elastic/QueryTranslator'

const createExpectedQuery = argsArray => {
  const query = {
    size: 500,
    query: {
      bool: {
        must: argsArray,
      },
    },
    sort: [
      { modified_time: { order: 'desc' } },
    ],
  }

  return { ...query, ...aggs }
}

it('translates query parameter', () => {
  // /v1/prices?q=DK
  const query = {
    q: 'DK',
  }
  const expectedMustArray = [
    { query_string: { query: 'DK OR *DK*', fields: strFields } },
  ]
  const actual = translateQuery(query)
  expect(actual).toEqual(createExpectedQuery(expectedMustArray))
})

it('translates query parameter as number', () => {
  const query = {
    q: '123',
  }
  const expectedMustArray = [
    { query_string: { query: '123 OR *123*', fields: intFields } },
  ]

  const actual = translateQuery(query)
  expect(actual).toEqual(createExpectedQuery(expectedMustArray))
})

it('translates modified_by and table_type query', () => {
  const query = {
    modified_by: 'DonkeyKong123', table_type: 'budget',
  }

  const expectedMustArray = [
    { query_string: { query: 'DonkeyKong123', fields: [ 'modified_by' ] } },
    { query_string: { query: 'budget', fields: [ 'table_type' ] } },
  ]

  const actual = translateQuery(query)
  expect(actual).toEqual(createExpectedQuery(expectedMustArray))
})

it('translates modified_by and table_type query with multiple values', () => {
  const query = {
    modified_by: 'DonkeyKong123,DonkeyKong321', table_type: 'budget,initiative',
  }

  const expectedMustArray = [
    { query_string: { query: 'DonkeyKong123 OR DonkeyKong321', fields: [ 'modified_by' ] } },
    { query_string: { query: 'budget OR initiative', fields: [ 'table_type' ] } },
  ]

  const actual = translateQuery(query)
  expect(actual).toEqual(createExpectedQuery(expectedMustArray))
})

it('translates amount query', () => {
  const query = {
    amount: 1,
  }

  const expectedMustArray = [
    { match: { amount: 1 } },
  ]

  const actual = translateQuery(query)
  expect(actual).toEqual(createExpectedQuery(expectedMustArray))
})

it('escapes spaces in query_string', () => {
  const query = {
    modified_by: 'Donkey Kong 123', table_type: 'budget 1',
  }

  const expectedMustArray = [
    { query_string: { query: 'Donkey\\ Kong\\ 123', fields: [ 'modified_by' ] } },
    { query_string: { query: 'budget\\ 1', fields: [ 'table_type' ] } },
  ]

  const actual = translateQuery(query)
  expect(actual).toEqual(createExpectedQuery(expectedMustArray))
})

it('translates date query with max and min values', () => {
  const query = {
    modified_time_min: 123, modified_time_max: 234,
  }

  const expectedMustArray = [
    { range: { modified_time: { gte: 123, lte: 234 } } },
  ]
  const actual = translateQuery(query)
  expect(actual).toEqual(createExpectedQuery(expectedMustArray))
})
