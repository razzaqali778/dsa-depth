import ReferenceDataDao from './dao/referenceDataDao'

export const getInitiativeStatus = async (req, res) => {
  try {
    const result = await ReferenceDataDao.getAllInitiativeStatus()
    res.json(result)
  } catch ( error ) {
    res.status(500).send(error.message)
  }
}
export const getFinancialTagTypes = async (req, res) => {
  try {
    const result = await ReferenceDataDao.getAllFinancialTagTypes()
    res.json(result)
  } catch ( error ) {
    res.status(500).send(error.message)
  }
}
export const getInitiativeTypes = async (req, res) => {
  try {
    const result = await ReferenceDataDao.getAllInitiativeTypes()
    res.json(result)
  } catch ( error ) {
    res.status(500).send(error.message)
  }
}
