/* eslint-disable wyze/max-file-length */
import { createBudget as daoCreateBudget } from './dao/budgetDaoV2'
import {
  createInitiative as daoCreateInitiative,
  getAllDescendants as daoGetAllDescendants,
  getAllInitiatives as daoGetAllInitiatives,
  getInitiative as daoGetInitiative,
  getInitiativeMap as daoGetInitiativeMap,
  patchInitiative as daoPatchInitiative,
  updateInitiative as daoUpdateInitiative,
  getAllFundingInitiatives,
  getAllInitiativesAndBudgets,
  getAllInitiativesWithParentAndBudgets,
  getInitiativesByParent,
  getLineage,
  getTopLevelInitiatives,
} from './dao/initiativeDao'
import { tagInitiative as daoTagInitiative } from './dao/tagsDao'
import { setBudgetParentAttribute, setFinancialAttributes } from './util/InitiativeUtil'
import { v1 as uuid } from 'uuid'
import filter from 'lodash/filter'
import find from 'lodash/find'
import getInitiatives from './v1/initiativeUtils/getInheritedFundingDetail'
import getOrElse from 'lodash/get'
import isEmpty from 'lodash/isEmpty'
import isNull from 'lodash/isNull'
import isUndefined from 'lodash/isUndefined'
import map from 'lodash/map'
import toUpper from 'lodash/toUpper'
import trim from 'lodash/trim'

const INITIATIVE_REGEX = /^[a-zA-Z0-9\s()/\-+:.&]{1,44}$/

const checkInitiativeName = async ({ initiative_id: id, initiative_name: name }, initiativeParent) => {
  const responseInitiatives = await daoGetAllInitiatives()
  const siblingInitiatives = filter(responseInitiatives, initiative => {
    if ( isUndefined(initiativeParent) ) {
      return isNull(initiative.parent)
    }

    return initiative.parent === initiativeParent
  })
  const matchedInitiative = find(siblingInitiatives, initiative =>
    toUpper(initiative.initiative_name) === toUpper(name) && initiative.initiative_id !== id )
  if ( isUndefined(matchedInitiative) ) {
    return { isDuplicate: false }
  }

  return { initiative_id: matchedInitiative.initiative_id, isDuplicate: true }
}

// eslint-disable-next-line max-statements
const createOrUpdateInitiative = action => async (req, res) => {
  const modifiedBy = getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase()
  try {
    const initiative = {
      ...req.body,
      initiative_name: trim(req.body.initiative_name),
      modified_by: modifiedBy,
      initiative_id: getOrElse(req, 'body.initiative_id', uuid()),
    }

    const { isDuplicate } = await checkInitiativeName(initiative, initiative.parent)
    if ( isDuplicate ) {
      const errors = {
        dataPath: '.initiative_name',
        params: '',
        message: 'name already exists in database',
      }

      return res.status(400).send(errors)
    }

    if ( !INITIATIVE_REGEX.test(initiative.initiative_name) ) {
      const errors = {
        dataPath: '.initiative_name',
        params: '',
        message: `Illegal initiative name (must be under 44 characters and contain only letters, numbers,
 spaces, and these special characters: ( ) / - + : . & [ ])`,
      }

      return res.status(400).send(errors)
    }

    if ( action === 'create' ) {
      try {
        const { initiative_id: initiativeId } = await daoCreateInitiative(initiative)

        if ( initiative.budget ) {
          const budget = {
            initiativeId,
            fiscalYear: initiative.fiscal_year,
            amount: initiative.budget,
            modifiedBy,
          }
          try {
            await daoCreateBudget(budget)
          } catch ( err ) {
            return res.status(500).send(err)
          }
        }
        try {
          await Promise.all(map(initiative.tags, async (value, tagId) =>
            daoTagInitiative(initiativeId, tagId, value)
          ))
        } catch ( err ) {
          return res.status(500).send(err)
        }
      } catch ( err ) {
        return res.status(500).send(err)
      }
    } else if ( action === 'update' ) {
      await daoUpdateInitiative(initiative)
    }

    return res.json(initiative)
  } catch ( err ) {
    return res.status(500).send(err)
  }
}

export const patchInitiative = async (req, res) => {
  try {
    const initiativeId = req.params.initiativeId
    const changedValues =
      { ...req.body,
        modified_by: getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase() }

    if ( !req.body || !initiativeId ) {
      return res.status(400).send('Data not sent')
    }

    const result = await daoPatchInitiative(initiativeId, changedValues)

    return res.json(result)
  } catch ( err ) {
    return res.status(500).send(err)
  }
}

export const getInitiativeHierarchy = async (req, res) => {
  try {
    const allInitiatives = await daoGetAllInitiatives()

    const constructHierarchy = parentId => {
      const initiativesWithParent = filter(allInitiatives, { parent: parentId })

      return map(initiativesWithParent, initiative => ({
        ...initiative,
        children: constructHierarchy(initiative.initiative_id),
      }))
    }

    res.json(constructHierarchy(null))
  } catch ( err ) {
    res.status(500).send(err)
  }
}

export const getAllInitiativesWithFundingInitiativeDetails = async (req, res) => {
  try {
    const allInitiatives = await daoGetAllInitiatives()
    const newInitiativesList = setFinancialAttributes(allInitiatives, { initiative_id: null })

    // return the full list of initiatives with their details
    res.json(newInitiativesList)
  } catch ( err ) {
    res.status(500).send(err)
  }
}

export const getInitiativesWithBudgetParentDetails = async (req, res) => {
  try {
    const allInitiatives = await getAllInitiativesAndBudgets()
    const newInitiativesList = setFinancialAttributes(allInitiatives, { initiative_id: null })

    res.json(setBudgetParentAttribute(newInitiativesList, { initiative_id: null }))
  } catch ( err ) {
    res.status(500).send(err)
  }
}

export const getAllTopLevelInitiatives = async (req, res) => {
  try {
    const result = await getTopLevelInitiatives()
    res.json(result)
  } catch ( err ) {
    res.status(500).send(err)
  }
}

export const getInitiativeLineage = async (req, res) => {
  try {
    const initiativeId = req.params.initiativeId
    const result = await getLineage(initiativeId, [], 0)

    res.json(result)
  } catch ( err ) {
    res.status(500).send(err)
  }
}
export const getChildInitiatives = async (req, res) => {
  try {
    const parentId = req.params.parentId

    const result = await getInitiativesByParent(parentId)
    res.json(result)
  } catch ( err ) {
    res.status(500).send(err)
  }
}
export const getAllDescendants = async (req, res) => {
  try {
    const parentId = req.params.parentId

    const result = await daoGetAllDescendants(parentId)
    res.json(result)
  } catch ( error ) {
    res.status(500).send(error)
  }
}
export const getInitiative = async (req, res) => {
  try {
    const initiativeId = req.params.initiativeId

    const result = await daoGetInitiative(initiativeId)
    res.json(result)
  } catch ( err ) {
    res.status(500).send(err)
  }
}

export const getAllInitiatives = async (req, res) => {
  try {
    const initiatives = await daoGetAllInitiatives()

    res.json(getInitiatives(initiatives))
  } catch ( err ) {
    res.status(500).send(err)
  }
}

export const getAllInitiativesWithStatusOverride = async (req, res) => {
  try {
    const initiatives = getInitiatives(await daoGetAllInitiatives())
    const initiativesWithStatusOverride = initiatives.map( initiative => {
      if ( isEmpty(initiative.status) ) {
        return { ...initiative, status: initiative.inherited_status ? initiative.inherited_status : '' }
      }

      return initiative
    })
    res.json(initiativesWithStatusOverride)
  } catch ( err ) {
    res.status(500).send(err)
  }
}

const getInitiativeWithFundingInfo = initiative => {
  if ( isEmpty(initiative.finance_code_type) || isNull(initiative.finance_code_type)
    || isEmpty(initiative.finance_code_value) || isNull(initiative.finance_code_value) ) {
    return { ...initiative,
      finance_code_type: initiative.inherited_fin_code_type ? initiative.inherited_fin_code_type : null,
      finance_code_value: initiative.inherited_fin_code_value ? initiative.inherited_fin_code_value : null,
    }
  }

  return initiative
}

export const getAllInitiativesWithParentInheritanceAndBudgets = async (req, res) => {
  try {
    const initiatives = getInitiatives(await getAllInitiativesWithParentAndBudgets())
    const initiativesWithStatusOverride = initiatives.map( initiative => {
      if ( isEmpty(initiative.status) ) {
        const init = getInitiativeWithFundingInfo(initiative)

        return { ...init, status: initiative.inherited_status ? initiative.inherited_status : '' }
      }

      return getInitiativeWithFundingInfo(initiative)
    })
    res.json(initiativesWithStatusOverride)
  } catch ( err ) {
    res.status(500).send(err)
  }
}

export const getFundingInitiatives = async (req, res) => {
  try {
    const result = await getAllFundingInitiatives()

    res.json(result)
  } catch ( err ) {
    res.status(500).send(err)
  }
}

export const getInitiativesForSelect = async (req, res) => {
  try {
    const result = await daoGetAllInitiatives()
    const response = map(result, initiative =>
      ({ initiative_id: initiative.initiative_id, initiative_name: initiative.initiative_name }))
    res.json(response)
  } catch ( err ) {
    res.status(500).send(err)
  }
}

export const getInitiativeMap = async (req, res) => {
  try {
    const result = await daoGetInitiativeMap()
    const response = map(result, ({ initiative_id, initiative_name }) => ({ initiative_id, initiative_name }))
    res.json(response)
  } catch ( err ) {
    res.status(500).send( err )
  }
}

export const createInitiative = async (req, res) => createOrUpdateInitiative('create')(req, res)
export const updateInitiative = async (req, res) => createOrUpdateInitiative('update')(req, res)
