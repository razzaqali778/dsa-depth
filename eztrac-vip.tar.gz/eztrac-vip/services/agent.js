const http = require('superagent-promise')(require('superagent'), Promise)
const _ = require('lodash')

const handleSuccess = response => response
const handleError = error => { throw error }

const Agent = {
  setHeaders: (request, headers) => {
    request.set('Accepts', 'application/json')
    request.set('Content-Type', 'application/json')
    if ( headers ) {
      _.each(headers, (value, key) => {
        request.set(key, value)
      })
    }

    return request
  },
  get: (url, headers) => Agent.setHeaders(http.get(url), headers)
    .then(handleSuccess)
    .catch(handleError),
  patch: (url, body, headers) => Agent.setHeaders(http.patch(url, body), headers)
    .then(handleSuccess)
    .catch(handleError),
  post: (url, body, headers) => Agent.setHeaders(http.post(url, body), headers)
    .then(handleSuccess)
    .catch(handleError),
  put: (url, body, headers) => Agent.setHeaders(http.put(url, body), headers)
    .then(handleSuccess)
    .catch(handleError),
  delete: (url, headers) => Agent.setHeaders(http.del(url), headers)
    .then(handleSuccess)
    .catch(handleError),
}

module.exports = Agent
