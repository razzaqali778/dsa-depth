import { executeQuery } from './common'

export const getBudgetsQuery =
  'SELECT initiative_id as "initiativeId", fiscal_year as "fiscalYear", amount, modified_by as "modifiedBy", budget_id as "budgetId" from budget' // eslint-disable-line max-len

export const getBudgetsByInitiativeIdQuery = `${getBudgetsQuery} WHERE initiative_id = $1;`

export const createBudgetQuery = `INSERT INTO budget(initiative_id, fiscal_year, amount, modified_by)
                            VALUES($1, $2, $3, $4 )
                            RETURNING initiative_id as "intiativeId", fiscal_year as "fiscalYear", budget_id as "budgetId";` // eslint-disable-line max-len

export const updateBudgetQuery = `UPDATE budget
                            SET amount = $1, modified_by = $2
                            WHERE initiative_id = $3 AND fiscal_year = $4
                            RETURNING initiative_id as "intiativeId", fiscal_year as "fiscalYear", budget_id as "budgetId";` // eslint-disable-line max-len

export const getParentBudgetQuery = `SELECT b.initiative_id as "parentInitiativeId", fiscal_year as "fiscalYear",
                            amount, b.modified_by as "modifiedBy", budget_id as "budgetId"
                            FROM initiative i
                            LEFT OUTER JOIN budget b ON i.parent = b.initiative_id
                            WHERE i.initiative_id = $1`

export const fetchBudgetsByInitiativeId = async initiativeId =>
  executeQuery(getBudgetsByInitiativeIdQuery, 'any', [ initiativeId ])

export const fetchBudgets = async () => executeQuery(getBudgetsQuery, 'any')

export const createBudget = ({ initiativeId, fiscalYear, amount, modifiedBy }) =>
  executeQuery(createBudgetQuery, 'one', [ initiativeId, fiscalYear, amount, modifiedBy ])

export const updateBudget = ({ amount, modifiedBy, initiativeId, fiscalYear }) =>
  executeQuery(updateBudgetQuery, 'one', [ amount, modifiedBy, initiativeId, fiscalYear ])

export const fetchParentBudget = async initiativeId =>
  executeQuery(getParentBudgetQuery, 'any', [ initiativeId ])

