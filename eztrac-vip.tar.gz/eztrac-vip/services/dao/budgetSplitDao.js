import client from '../db/db'
import map from 'lodash/map'

const fetchSplitsQuery =
  'SELECT split_id as id, budget_id as "budgetId", amount, split_value as "splitValue", split_field as "splitField" FROM budget_split' // eslint-disable-line max-len

const fetchSplitsByIdQuery =
  `${fetchSplitsQuery} WHERE budget_id = $1;`

const addBudgetSplitQuery = `
  INSERT INTO budget_split ( budget_id, amount, split_value, split_field ) VALUES ($1,$2,$3,$4);
`

const updateBudgetSplitQuery = `
  DELETE FROM budget_split WHERE split_id = $1;
  INSERT INTO budget_split (split_id, budget_id, amount, split_value, split_field) VALUES ($1, $2, $3, $4, $5);
`

const deleteSplitsByBudgetIdQuery = `
  DELETE FROM budget_split WHERE budget_id = $1;
`

const deleteBudgetSplitQuery =
  'DELETE FROM budget_split WHERE split_id = $1;'

export const executeQuery = async (query, func = 'any', args = []) => {
  try {
    const result = await client[func](query, args)

    return result
  } catch ( err ) {
    console.error(`Error executing query ${query} -- `, err) // eslint-disable-line no-console
    throw { message: 'Error', statusCode: 500 }
  }
}

export const executeAnyQuery = async query => executeQuery(query, 'any')
export const executeOneQuery = async query => executeQuery(query, 'one')

export const fetchSplits = async () => executeQuery(fetchSplitsQuery, 'any')
export const fetchSplitsByBudgetId = async budgetId => executeQuery(fetchSplitsByIdQuery, 'any', [ budgetId ])
export const deleteSplitsByBudgetId = async budgetId => executeQuery(deleteSplitsByBudgetIdQuery, 'any', [ budgetId ])

export const deleteBudgetSplit = async splitId => executeQuery(deleteBudgetSplitQuery, 'any', [ splitId ])

export const addNewBudgetSplit = async ( budgetId, amount, splitValue, splitField) =>
  executeQuery(addBudgetSplitQuery, 'any', [ budgetId, amount, splitValue, splitField ])

export const updateBudgetSplit = async ( splitId, budgetId, amount, splitValue, splitField) =>
  executeQuery(updateBudgetSplitQuery, 'any', [ splitId, budgetId, amount, splitValue, splitField ])


export const insertBudgetSplits = async ( budgetId, splits ) => {
  await deleteSplitsByBudgetId(budgetId)
  const promises = map(splits, ({ splitId, amount, splitValue, splitField }) =>
    splitId
      ? updateBudgetSplit(splitId, budgetId, amount, splitValue, splitField)
      : addNewBudgetSplit(budgetId, amount, splitValue, splitField)
  )

  return Promise.all(promises)
}
