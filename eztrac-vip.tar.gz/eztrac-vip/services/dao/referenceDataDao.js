import client from '../db/db'

const getAllInitiativeStatusQuery = 'SELECT * FROM initiative_status;'
const getAllFinancialTagTypesQuery = 'SELECT * FROM financial_tag_type;'
const getAllInitiativeTypesQuery = 'SELECT * FROM initiative_type;'

const ReferenceDataDao = {
  getAllInitiativeStatus: () => ReferenceDataDao.getAllObjects(getAllInitiativeStatusQuery),
  getAllFinancialTagTypes: () => ReferenceDataDao.getAllObjects(getAllFinancialTagTypesQuery),
  getAllInitiativeTypes: () => ReferenceDataDao.getAllObjects(getAllInitiativeTypesQuery),
  getAllObjects: query => client.any(query, [])
    .then(result => result)
    .catch(error => {
      throw error
    }),
}

module.exports = ReferenceDataDao
