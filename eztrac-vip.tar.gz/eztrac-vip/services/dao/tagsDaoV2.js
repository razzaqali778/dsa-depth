import { executeQuery } from './common'

const getTagNamesQuery = 'SELECT tag_id as "tagId", tag_name as "tagName" FROM tag_names'

export const getTagNames = () => executeQuery(getTagNamesQuery)
