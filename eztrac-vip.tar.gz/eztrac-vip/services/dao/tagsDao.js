import client from '../db/db'

const getTagNamesQuery = 'SELECT * FROM tag_names'

const getTagOptionsQuery = 'SELECT * FROM tag_options'

const getAllTagsQuery = 'SELECT * FROM initiative_tags'

const getTagsByInitiativeQuery = 'SELECT * FROM initiative_tags WHERE initiative_id = $1 ORDER BY tag_id'

const tagInitiativeQuery = 'INSERT INTO initiative_tags (initiative_id, tag_id, tag_value) VALUES ($1, $2, $3);'

const deleteTagQuery = 'DELETE FROM initiative_tags WHERE initiative_id = $1 AND tag_id = $2;'

const findAllTagsAndParents = `SELECT i.initiative_id,
  i.parent AS "parent_id",
  tags.tag_id,
  tags.tag_value
  FROM initiative i
  left outer join initiative_tags tags on i.initiative_id = tags.initiative_id`

const findInheritableTagsQuery = `WITH RECURSIVE
  recursive_query AS (
  SELECT i.initiative_id,
    i.parent AS "parent_id",
    0 AS level,
    tags.tag_id,
    tags.tag_value
  FROM initiative i
  left outer join initiative_tags tags on i.initiative_id = tags.initiative_id
  WHERE i.initiative_id = $1
  UNION ALL
  SELECT parent.initiative_id,
    parent.parent as "parent_id",
    child.level +1 as "level",
    tags.tag_id,
    tags.tag_value
  FROM initiative parent
  left outer join initiative_tags tags on parent.initiative_id = tags.initiative_id
  JOIN recursive_query AS child ON parent.initiative_id = child.parent_id
    )
  SELECT DISTINCT initiative_id, parent_id, level, tag_id, tag_value
  FROM recursive_query
  order by level ASC;`

export const getTagNames = async () => {
  try {
    const tagNames = await client.any(getTagNamesQuery, [])

    return tagNames
  } catch ( error ) {
    console.error(`Error retrieving tag names: ${error}`) // eslint-disable-line no-console
    throw { message: `Error retrieving tag names: ${error.message}`, statusCode: 500 }
  }
}
export const getTagOptions = async () => {
  try {
    const tagOpts = await client.any(getTagOptionsQuery, [])

    return tagOpts
  } catch ( error ) {
    console.error(`Error retrieving tag options: ${error}`) // eslint-disable-line no-console
    throw { message: `Error retrieving tag options: ${error.message}`, statusCode: 500 }
  }
}
export const getTags = async (initiativeId = null) => {
  if ( initiativeId ) {
    try {
      const tags = await client.any(getTagsByInitiativeQuery, [ initiativeId ])

      return tags
    } catch ( error ) {
      console.error(`Error retrieving tags by ID: ${error}`) // eslint-disable-line no-console
      throw { message: `Error retrieving tags by ID: ${error.message}`, statusCode: 500 }
    }
  } else {
    try {
      const tags = await client.any(getAllTagsQuery)

      return tags
    } catch ( error ) {
      console.error(`Error retrieving all tags: ${error}`) // eslint-disable-line no-console
      throw { message: `Error retrieving all tags: ${error.message}`, statusCode: 500 }
    }
  }
}

export const deleteInitiativeTag = async (initiativeId, tagId) => {
  try {
    const tags = await client.any(deleteTagQuery, [ initiativeId, tagId ])

    return tags
  } catch ( error ) {
    console.error(`Error deleting tags from the database: ${error}`) // eslint-disable-line no-console
    throw { message: `Error deleting tags from the database: ${error.message}`, statusCode: 500 }
  }
}

export const tagInitiative = async (initiativeId, tagId, value) => {
  await deleteInitiativeTag(initiativeId, tagId)
  try {
    const tags = await client.any(tagInitiativeQuery, [ initiativeId, tagId, value ])

    return tags
  } catch ( error ) {
    console.log(`Error with tag ${tagId}`) // eslint-disable-line no-console
    console.error(`Error inserting tags into database: ${error}`) // eslint-disable-line no-console
    throw { message: `Error inserting tags into database: ${error.message}`, statusCode: 500 }
  }
}

export const getAncestralTags = async initiativeId => {
  try {
    const inheritedTags = await client.any(findInheritableTagsQuery, [ initiativeId ])

    return inheritedTags
  } catch ( error ) {
    console.error(`Error finding inheritable tags: ${error}`) // eslint-disable-line no-console
    throw { message: `error finding tags: ${error.message}`, statusCode: 500 }
  }
}

export const getAllInitiativeTags = async () => {
  try {
    return await client.any(findAllTagsAndParents)
  } catch ( error ) {
    console.error(`Error getting all inheritable tags: ${error}`) // eslint-disable-line no-console
    throw { message: `error getting all inheritable tags: ${error.message}`, statusCode: 500 }
  }
}
