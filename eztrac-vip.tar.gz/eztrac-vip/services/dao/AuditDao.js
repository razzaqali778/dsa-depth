import client from '../db/db'

const getAllAuditsQuery = 'SELECT * FROM audits ORDER BY modified_time DESC'

export const getAllAudits = async () => {
  try {
    const audits = await client.any(getAllAuditsQuery, [])

    return audits
  } catch ( error ) {
    console.error(`Error retrieving audits: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error retrieving audits', statusCode: 500 }
  }
}
