import client from '../db/db' // eslint-disable-line wyze/max-file-length

export const executeQuery = async (query, func = 'any', args = []) => {
  try {
    const result = await client[func](query, args)

    return result
  } catch ( err ) {
    console.error(`Error executing query ${query} -- ${err}`) // eslint-disable-line no-console
    throw { message: 'Error', statusCode: 500 }
  }
}

export const executeAnyQuery = async query => executeQuery(query, 'any')
export const executeOneQuery = async query => executeQuery(query, 'one')
