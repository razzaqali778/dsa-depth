import client from '../db/db' // eslint-disable-line wyze/max-file-length
import isNull from 'lodash/isNull'
import keys from 'lodash/keys'
import map from 'lodash/map'
import values from 'lodash/values'

const getAllInitiativesQuery = `SELECT c.*, p.initiative_name AS parent_name
                                FROM initiative c
                                LEFT JOIN initiative p ON p.initiative_id = c.parent;`

const getTopLevelInitiativesQuery = 'SELECT * FROM initiative WHERE parent is null;'

const getChildInitiativesQuery = 'SELECT * FROM initiative WHERE parent = $1;'

const getAllDescendantsQuery = `WITH RECURSIVE family AS (
        SELECT initiative_id as id, parent, initiative_name as "initiativeName" FROM initiative WHERE parent = $1
            UNION
        SELECT i.initiative_id as id, i.parent, i.initiative_name as "initiativeName" FROM initiative i
        INNER JOIN family f ON f.id = i.parent
      ) SELECT * FROM family;`

const getInitiativeQuery = 'SELECT * FROM initiative WHERE initiative_id = $1;'

const getFundingInitiativesQuery =
  'SELECT * FROM initiative WHERE finance_code_type IS NOT NULL AND finance_code_value IS NOT NULL;'

const createInitiativeQuery = `INSERT INTO initiative(
                                  initiative_id,
                                  initiative_name,
                                  status,
                                  finance_code_type,
                                  finance_code_value,
                                  parent,
                                  modified_by,
                                  type_id,
                                  is_allocable,
                                  is_inheritable,
                                  portfolio_code,
                                  activity_id,
                                  program_code )
                                VALUES ($1, trim($2), $3, $4, trim($5), $6, $7, $8, $9, $10, trim($11), trim($12), 
                                  trim($13))
                                RETURNING initiative_id;`

const updateInitiativeQuery = `UPDATE initiative
                                SET initiative_name = trim($1),
                                    status = $2,
                                    finance_code_type = $3,
                                    finance_code_value = trim($4),
                                    modified_by = $5,
                                    type_id = $6,
                                    is_allocable = $7,
                                    is_inheritable = $8,
                                    portfolio_code = trim($9),
                                    activity_id = trim($10),
                                    program_code = trim($11)
                                WHERE initiative_id = $12
                                RETURNING initiative_id;`

const getAllInitiativesAndBudgetsQuery = `SELECT i.*, ARRAY(SELECT ROW_TO_JSON(budget)
                                            FROM budget
                                            WHERE initiative_id = i.initiative_id) as budgets
                                            FROM initiative i;`

const getInitiativeMapQuery = 'SELECT initiative_id, initiative_name FROM initiative'

const getInitiativesWithParentAndBudgetsQuery = `SELECT i.*,
        p.initiative_id as "parent_id", p.initiative_name as "parent_name",
        ARRAY(SELECT ROW_TO_JSON(budget) FROM budget WHERE initiative_id = i.initiative_id) as budgets from initiative i
        LEFT JOIN initiative p on p.initiative_id = i.parent;`

export const getAllInitiativesWithParentAndBudgets = async () => {
  try {
    const initiatives = await client.any(getInitiativesWithParentAndBudgetsQuery, [])

    return initiatives
  } catch ( error ) {
    console.error(`Error retrieving initiatives: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error retrieving initiatives', statusCode: 500 }
  }
}

export const getAllInitiatives = async () => {
  try {
    const initiatives = await client.any(getAllInitiativesQuery, [])

    return initiatives
  } catch ( error ) {
    console.error(`Error retrieving initiatives: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error retrieving initiatives', statusCode: 500 }
  }
}

export const getInitiativesByParent = async parent => {
  try {
    if ( parent ) {
      const children = await client.any(getChildInitiativesQuery, [ parent ])

      return children
    }
    const toplevel = await client.any(getTopLevelInitiativesQuery, [])

    return toplevel
  } catch ( error ) {
    console.error(`Error retrieving initiatives by parent: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error retrieving initiatives by parent', statusCode: 500 }
  }
}

export const getTopLevelInitiatives = async () => {
  try {
    const topLevel = await client.any(getTopLevelInitiativesQuery, [])

    return topLevel
  } catch ( error ) {
    console.error(`Error retrieving top level initiatives: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error retrieving top level initiatives', statusCode: 500 }
  }
}

export const getInitiative = async initiativeId => {
  try {
    const initiative = await client.one(getInitiativeQuery, [ initiativeId ])

    return initiative
  } catch ( error ) {
    console.error(`Error retrieving initiative: ${error}`) // eslint-disable-line no-console
    if ( error.received === 0 ) {
      throw { message: 'No initiative found for given id', statusCode: 404 }
    } else {
      throw { message: 'Error retrieving top level initiatives', statusCode: 500 }
    }
  }
}

export const getAllFundingInitiatives = async () => {
  try {
    const fundingInitiatives = await client.any(getFundingInitiativesQuery, [])

    return fundingInitiatives
  } catch ( error ) {
    console.error(`Error retrieving funding initiatives: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error retrieving funding initiatives', statusCode: 500 }
  }
}

export const createInitiative = async initiative => {
  try {
    const initiativeId = await client.one(createInitiativeQuery, [
      initiative.initiative_id,
      initiative.initiative_name,
      initiative.status,
      initiative.finance_code_type,
      initiative.finance_code_value,
      initiative.parent,
      initiative.modified_by,
      initiative.type_id,
      initiative.is_allocable,
      initiative.is_inheritable,
      initiative.portfolio_code,
      initiative.activity_id,
      initiative.program_code,
    ])

    return initiativeId
  } catch ( error ) {
    console.error(`Error creating initiative: ${error}`) // eslint-disable-line no-console
    throw { message: `Error creating initiative: ${error.message}`, statusCode: 500 }
  }
}

export const updateInitiative = async initiative => {
  try {
    const initiativeId = await client.one(updateInitiativeQuery, [
      initiative.initiative_name,
      initiative.status,
      initiative.finance_code_type,
      initiative.finance_code_value,
      initiative.modified_by,
      initiative.type_id,
      initiative.is_allocable,
      initiative.is_inheritable,
      initiative.portfolio_code,
      initiative.activity_id,
      initiative.program_code,
      initiative.initiative_id,
    ])

    return initiativeId
  } catch ( error ) {
    console.error(`Error updating initiative: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error updating initiative', statusCode: 500 }
  }
}

export const patchInitiative = async (initiativeId, changedValues) => {
  try {
    const columns = keys(changedValues)
    const setStmnts = map(columns, (column, i) => `${column} = $${i + 1}`).join(', ')

    const queryStr =
      `UPDATE initiative SET ${setStmnts} WHERE initiative_id = $${columns.length + 1} RETURNING initiative_id;`

    const queryParams = [
      ...values(changedValues),
      initiativeId,
    ]

    const id = await client.one(queryStr, queryParams)

    return id
  } catch ( error ) {
    console.error(`Error patching initiative: ${error}`) // eslint-disable-line no-console
    throw { message: `Error patching initiative: ${error.message}`, statusCode: 500 }
  }
}

export const getLineage = async (initiativeId, lineage, index) => {
  try {
    const initiative = await client.one(getInitiativeQuery, [ initiativeId ])
    lineage.push({ id: initiative.initiative_id, name: initiative.initiative_name, order: index })
    if ( isNull(initiative.parent) ) {
      return lineage
    }
    const nextLineage = await getLineage(initiative.parent, lineage, index + 1)

    return nextLineage
  } catch ( error ) {
    console.error(`Error retrieving initiative lineage: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error retrieving initiative lineage', statusCode: 500 }
  }
}

export const getAllInitiativesAndBudgets = async () => {
  try {
    const initiatives = await client.any(getAllInitiativesAndBudgetsQuery)

    return initiatives
  } catch ( error ) {
    console.error(`Error retrieving initiatives with budgets: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error retrieving initiatives with budgets', statusCode: 500 }
  }
}

export const getInitiativeMap = async () => {
  try {
    const initiativeMap = await client.any(getInitiativeMapQuery)

    return initiativeMap
  } catch ( error ) {
    console.error(`Error retrieving initiative map: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error retrieving initiative map', statusCode: 500 }
  }
}

export const executeQuery = async (query, func = 'any') => {
  try {
    const result = await client[func](query)

    return result
  } catch ( err ) {
    console.error(`Error executing query ${query} -- ${err}`) // eslint-disable-line no-console
    throw { message: 'Error', statusCode: 500 }
  }
}

export const getAllDescendants = async initiative => {
  try {
    const descendants = await client.any(getAllDescendantsQuery, [ initiative ])

    return descendants
  } catch ( error ) {
    console.error(`Error retrieving all descendants by parent: ${error}`)// eslint-disable-line no-console
    throw { message: 'Error retrieving all descendants by parent', statusCode: 500 }
  }
}

export const executeAnyQuery = async query => executeQuery(query, 'any')
export const executeOneQuery = async query => executeQuery(query, 'one')
export const getAll = async () => executeQuery('SELECT * FROM initiative', 'any')
export const getAllForCycleCheck = async () =>
  executeQuery('SELECT initiative_id as id, parent as "parentId" from initiative', 'any')

export default {
  getAllInitiatives,
  getInitiativesByParent,
  getAllDescendants,
  getTopLevelInitiatives,
  getInitiative,
  getAllFundingInitiatives,
  createInitiative,
  updateInitiative,
  patchInitiative,
  getLineage,
  getAllInitiativesAndBudgets,
  getInitiativeMap,
}
