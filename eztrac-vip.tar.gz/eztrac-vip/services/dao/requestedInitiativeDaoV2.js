/* eslint-disable max-len */
import { camelCase, reduce } from 'lodash'
import { executeQuery } from './common'

const createRequestedInitiativeQuery = `INSERT INTO requested_initiative(initiative_id, initiative_name, parent_name, type, status, financial_code, budget, fiscal_year, portfolio_id, business_unit, region, comment, cap_proj_radio, parent_name_radio, requested_by, parent_id, activity_id)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17);`

const getRequestedInitiativeQuery = 'SELECT * FROM requested_initiative WHERE initiative_id = $1 LIMIT 1'

const updateRequestQuery = `UPDATE requested_initiative SET initiative_name = $2, parent_name = $3, type = $4, status = $5, financial_code = $6, budget = $7, fiscal_year = $8, portfolio_id = $9, business_unit = $10,
  region = $11, comment = $12, cap_proj_radio = $13, parent_name_radio = $14, approved = $15, requested_by = $16, parent_id = $17, activity_id = $18 WHERE initiative_id = $1;`

const requestedInitiativeGetter = requestedInitiative => attr => requestedInitiative[attr] || null

export const createInitiativeRequest = async requestedInitiative => {
  const getOrNull = requestedInitiativeGetter(requestedInitiative)
  try {
    executeQuery(createRequestedInitiativeQuery, 'one', [
      requestedInitiative.id,
      requestedInitiative.name,
      getOrNull('parentName'),
      getOrNull('type'),
      getOrNull('status'),
      getOrNull('financialCode'),
      getOrNull('budget'),
      getOrNull('fiscalYear'),
      getOrNull('portfolioId'),
      getOrNull('businessUnit'),
      getOrNull('region'),
      getOrNull('comment'),
      requestedInitiative.capProjRadio,
      requestedInitiative.parentNameRadio,
      requestedInitiative.requestedBy,
      getOrNull('parentId'),
      getOrNull('activityId') ])
  } catch ( error ) {
    console.log(`Error saving requested initiative: ${error}`)// eslint-disable-line no-console
    throw { message: 'Error creating requested initiative', statusCode: 500 }
  }
}

export const updateRequest = async (id, requestedInitiative) => {
  const getOrNull = requestedInitiativeGetter(requestedInitiative)
  try {
    executeQuery(updateRequestQuery, 'one', [
      id,
      requestedInitiative.name,
      getOrNull('parentName'),
      getOrNull('type'),
      getOrNull('status'),
      getOrNull('financialCode'),
      getOrNull('budget'),
      getOrNull('fiscalYear'),
      getOrNull('portfolioId'),
      getOrNull('businessUnit'),
      getOrNull('region'),
      getOrNull('comment'),
      requestedInitiative.capProjRadio,
      requestedInitiative.parentNameRadio,
      requestedInitiative.approved,
      requestedInitiative.requestedBy,
      getOrNull('parentId'),
      getOrNull('activityId') ])
  } catch ( error ) {
    console.log(`Error updating requested initiative: ${error}`)// eslint-disable-line no-console
    throw { message: 'Error updating requested initiative', statusCode: 500 }
  }
}

const fixKey = key => {
  let myKey = key
  if ( myKey.startsWith('initiative_') ) {
    myKey = myKey.slice(11)
  }
  myKey = camelCase(myKey)

  return myKey
}

const fixVal = val => {
  if ( val === null ) {
    return ''
  }

  return val
}

const massageKeyVals = initiativeRequest =>
  reduce(initiativeRequest, (accum, val, key) =>
    ({ ...accum, [fixKey(key)]: fixVal(val) }), {})

export const getInitiativeRequest = async id => {
  try {
    const [ initiativeRequest ] = await executeQuery(getRequestedInitiativeQuery, 'any', [ id ])

    return massageKeyVals(initiativeRequest)
  } catch ( err ) {
    console.err(err)// eslint-disable-line no-console
    throw { message: 'Error getting initiative' }
  }
}
