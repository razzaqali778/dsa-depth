import { executeAnyQuery, executeQuery } from './common'
import client from '../db/db' // eslint-disable-line wyze/max-file-length

const getAllDescendantsQuery = `WITH RECURSIVE family AS (
        SELECT initiative_id as id, parent, initiative_name as "initiativeName" FROM initiative WHERE parent = $1
            UNION
        SELECT i.initiative_id as id, i.parent, i.initiative_name as "initiativeName" FROM initiative i
        INNER JOIN family f ON f.id = i.parent
      ) SELECT * FROM family;`

const baseFields = `i.initiative_id as id
      , i.initiative_name as "initiativeName"
      , i.status
      , i.finance_code_value as "financeCodeValue"
      , i.finance_code_type as "financeCodeType"
      , i.is_allocable as "isAllocable"
      , i.portfolio_code as portfolioCode
      , i.activity_id as activityId
      , i.program_code as programCode`

const parentFields = 'p.initiative_id as "parentId", p.initiative_name as "parentName"'

const getAllInitiativesQuery = `SELECT ${baseFields}, ${parentFields} FROM initiative i
  LEFT JOIN initiative p ON p.initiative_id = i.parent;`

export const updateInitiativeQuery = `UPDATE initiative SET initiative_name = $1, status = $2, finance_code_type = $3,
  finance_code_value = $4, modified_by = $5, type_id = $6, is_allocable = $7, portfolio_code = $8, activity_id = $9, 
  program_code = $10
  WHERE initiative_id = $8
  RETURNING initiative_id as "id", initiative_name as "name", status, finance_code_type as "financeCodeType",
  finance_code_value as "financeCodeValue", parent, modified_by as "modifiedBy", type_id as "typeId",
  is_allocable as "isAllocable", portfolio_code as "portfolioCode", activity_id as "activityId", 
  program_code as "programCode";`

export const createInitiativeQuery = `INSERT INTO initiative(initiative_id, initiative_name, status,
  finance_code_type, finance_code_value, parent, modified_by, type_id, is_allocable, portfolio_code, activity_id, 
  program_code )
  VALUES ($1, trim($2), $3, $4, trim($5), $6, $7, $8, $9, trim($10), trim($11), trim($12))
  RETURNING initiative_id as "id", initiative_name as "name", status, finance_code_type as "financeCodeType",
  finance_code_value as "financeCodeValue", parent, modified_by as "modifiedBy", type_id as "typeId",
  is_allocable as "isAllocable", portfolio_code as "portfolioCode", activity_id as "activityId", 
  program_code as "programCode";`

export const getLimitedInitiativesAndParentQuery = `SELECT
  i.initiative_id AS id,
  i.initiative_name AS "initiativeName",
  i.finance_code_value AS "financialCode",
  i.type_id AS "typeId",
  p.initiative_id AS "parentId",
  p.initiative_name AS "parentName"
  FROM initiative i
  LEFT JOIN initiative p ON p.initiative_id = i.parent
  WHERE i.type_id NOT LIKE 'UNKNOWN'
  AND (i.status LIKE 'Funded' OR
  i.status LIKE 'Planning' OR
  i.status IS NULL);`

export const createInitiative = async initiative => {
  try {
    executeQuery(createInitiativeQuery, 'one', [ initiative.id, initiative.name,
      initiative.status, initiative.financeCodeType, initiative.financeCodeValue,
      initiative.parent, initiative.modifiedBy, initiative.typeId, initiative.isAllocable,
      initiative.portfolioCode, initiative.activityId, initiative.programCode ])
  } catch ( error ) {
    console.error(`Error creating initiative: ${error}`)// eslint-disable-line no-console
    throw { message: 'Error creating initiative', statusCode: 500 }
  }
}

export const getAllDescendants = async initiative => {
  try {
    const descendants = await client.any(getAllDescendantsQuery, [ initiative ])

    return descendants
  } catch ( error ) {
    console.error(`Error retrieving all descendants by parent: ${error}`)// eslint-disable-line no-console
    throw { message: 'Error retrieving all descendants by parent', statusCode: 500 }
  }
}

export const getAll = async () => executeQuery('SELECT * FROM initiative', 'any')
export const getAllForCycleCheck = async () =>
  executeQuery('SELECT initiative_id as id, parent as "parentId" from initiative', 'any')

export const getAllInitiatives = async () => executeAnyQuery(getAllInitiativesQuery)

export const updateInitiative = async initiative => {
  try {
    executeQuery(updateInitiativeQuery, 'one', [ initiative.id, initiative.name,
      initiative.status, initiative.financeCodeType, initiative.financeCodeValue,
      initiative.parent, initiative.modifiedBy, initiative.typeId, initiative.isAllocable,
      initiative.portfolioCode, initiative.activityId, initiative.programCode ])
  } catch ( error ) {
    console.error(`Error updating initiative: ${error}`)// eslint-disable-line no-console
    throw { message: 'Error updating initiative', statusCode: 500 }
  }
}

export const getLimitedInitiativesAndParent = async () => executeQuery(getLimitedInitiativesAndParentQuery)
