/* eslint-disable wyze/max-file-length */
import client from '../db/db'

const getBudgetsByInitiativeQuery = `SELECT b.budget_id as "budgetId", b.initiative_id,
                                    i.initiative_name, b.fiscal_year, b.amount FROM budget b
                                        JOIN initiative i USING (initiative_id)
                                        WHERE initiative_id = $1;`

const getChildrenBudgetsQuery = `SELECT b.initiative_id, i.initiative_name, b.fiscal_year, b.amount FROM budget b
                                  JOIN initiative i USING (initiative_id)
                                  WHERE fiscal_year = $1
                                  AND initiative_id IN
                                  (SELECT initiative_id FROM initiative WHERE parent = $2);`

const getBudgetsByFiscalYearQuery = 'SELECT * FROM budget WHERE fiscal_year = $1;'

const getBudgetsByFiscalYearsQuery = 'SELECT * FROM budget WHERE fiscal_year = ANY($1);'

const getAllBudgetsQuery = 'SELECT * FROM budget ORDER BY initiative_id, fiscal_year;'

const createBudgetQuery = `INSERT INTO budget(initiative_id, fiscal_year, amount, modified_by)
                            VALUES($1, $2, $3, $4 )
                            RETURNING initiative_id, fiscal_year;`

const updateBudgetQuery = `UPDATE budget
                            SET amount = $1, modified_by = $2
                            WHERE initiative_id = $3 AND fiscal_year = $4
                            RETURNING initiative_id, fiscal_year;`

const getAllFiscalYearsQuery = 'SELECT DISTINCT fiscal_year FROM budget ORDER BY fiscal_year'

const BudgetDao = {
  async getBudgetsByInitiative(initiativeId) {
    try {
      const budgets = await client.any(getBudgetsByInitiativeQuery, [ initiativeId ])

      return budgets
    } catch ( error ) {
      console.error(`Error retrieving budgets by initiative: ${error}`) // eslint-disable-line no-console
      throw { message: 'Error retrieving budgets by initiative', statusCode: 500 }
    }
  },
  async getBudgetChildren(parentInitiative, fiscalYear) {
    try {
      const budgetChildren = await client.any(getChildrenBudgetsQuery, [ fiscalYear, parentInitiative ])

      return budgetChildren
    } catch ( error ) {
      console.error(`Error retrieving budgets by parent: ${error}`) // eslint-disable-line no-console
      throw { message: 'Error retrieving budgets by parent', statusCode: 500 }
    }
  },
  async getBudgetsByFiscalYear(fiscalYear) {
    try {
      const budgets = await client.any(getBudgetsByFiscalYearQuery, [ fiscalYear ])

      return budgets
    } catch ( error ) {
      console.error(`Error retrieving budgets by fiscal year: ${error}`) // eslint-disable-line no-console
      throw { message: 'Error retrieving budgets by fiscal year', statusCode: 500 }
    }
  },
  async getBudgetsByFiscalYears(fiscalYears) {
    try {
      const budgets = await client.any(getBudgetsByFiscalYearsQuery, [ fiscalYears ])

      return budgets
    } catch ( error ) {
      console.error(`Error retrieving budgets by fiscal years: ${error}`) // eslint-disable-line no-console
      throw { message: 'Error retrieving budgets by fiscal years', statusCode: 500 }
    }
  },
  async getAllBudgets() {
    try {
      const budgets = await client.any(getAllBudgetsQuery, [])

      return budgets
    } catch ( error ) {
      console.error(`Error retrieving budgets: ${error}`) // eslint-disable-line no-console
      throw { message: 'Error retrieving budgets', statusCode: 500 }
    }
  },

  async createBudget(budget) {
    try {
      const budgetId = await client.one(createBudgetQuery, [
        budget.initiative_id,
        budget.fiscal_year,
        budget.amount,
        budget.modified_by,
      ])

      return budgetId
    } catch ( error ) {
      console.error(`Error creating budget: ${error}`) // eslint-disable-line no-console
      throw { message: 'Error creating budget', statusCode: 500 }
    }
  },
  async updateBudget(budget) {
    try {
      const budgetId = await client.one(updateBudgetQuery, [
        budget.amount,
        budget.modified_by,
        budget.initiative_id,
        budget.fiscal_year,
      ])

      return budgetId
    } catch ( error ) {
      console.error(`Error updating budget: ${error}`) // eslint-disable-line no-console
      throw { message: 'Error updating budget', statusCode: 500 }
    }
  },
  async getAllFiscalYears() {
    try {
      const fiscalYears = await client.any(getAllFiscalYearsQuery, [])

      return fiscalYears
    } catch ( error ) {
      console.error(`Error getting fiscal years: ${error}`) // eslint-disable-line no-console
      throw { message: 'Error getting fiscal years', statusCode: 500 }
    }
  },
}

export default BudgetDao
