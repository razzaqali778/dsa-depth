import {
  addInitTag,
  deleteInitTag,
  fetchAncestralTags,
  fetchInitTags,
  fetchTagNames,
  fetchTagOptions,
} from '../../tagsService'
import express from 'express'

const router = express.Router()

router.get('/names', fetchTagNames)
router.get('/options', fetchTagOptions)
router.get('/initiatives', fetchInitTags)
router.get('/inheritedtags', fetchAncestralTags)
router.put('/initiatives', addInitTag)
router.delete('/initiatives', deleteInitTag)

export default router
