import find from 'lodash/find'

export const findParent = (initiatives, { parent }) => {
  const ancestor = find(initiatives, ({ initiative_id }) => parent === initiative_id ) // eslint-disable-line camelcase

  if ( ancestor ) {
    if ( ancestor.is_inheritable && ancestor.finance_code_value ) {
      return ancestor
    }
    if ( ancestor.parent ) {
      return findParent(initiatives, ancestor)
    }
  }

  return null
}

export const findParentWithProperty = (initiatives, { parent }, property) => {
  const ancestor = find(initiatives, ({ initiative_id }) => parent === initiative_id ) // eslint-disable-line camelcase

  if ( ancestor ) {
    if ( ancestor[property] ) {
      return ancestor
    }
    if ( ancestor.parent ) {
      return findParentWithProperty(initiatives, ancestor, property)
    }
  }

  return null
}
