import {
  findParent,
  findParentWithProperty,
} from './findInheritableParent'
import map from 'lodash/map'

export const getInheritedFundingDetail = (initiatives, current) => {
  const { finance_code_value, finance_code_type } = current

  const parent = findParent(initiatives, current)

  if ( parent ) {
    return {
      inherited_fin_code_value: parent.finance_code_value,
      inherited_fin_code_type: parent.finance_code_type,
      finance_code_value,
      finance_code_type,
    }
  }

  return { finance_code_value, finance_code_type }
}

export const addInheritedProperty = (initiatives, current, property, inheritedProperty) => {
  const parent = findParentWithProperty(initiatives, current, property)

  if ( parent ) {
    return {
      [inheritedProperty]: parent[property],
      [property]: current[property],
    }
  }

  return {
    [property]: current[property],
  }
}

export const getInitiativeInheritedDetails = (currentInitiative, initiatives) => ({
  ...currentInitiative,
  ...getInheritedFundingDetail(initiatives, currentInitiative),
  ...addInheritedProperty(initiatives, currentInitiative, 'portfolio_code', 'inherited_portfolio_code'),
  ...addInheritedProperty(initiatives, currentInitiative, 'program_code', 'inherited_program_code'),
  ...addInheritedProperty(initiatives, currentInitiative, 'activity_id', 'inherited_activity_id'),
  ...addInheritedProperty(initiatives, currentInitiative, 'status', 'inherited_status'),
})

export default initiatives =>
  map(initiatives, i => getInitiativeInheritedDetails(i, initiatives))
