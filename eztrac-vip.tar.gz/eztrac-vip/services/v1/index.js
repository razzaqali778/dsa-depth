import {
  createInitiative,
  getAllInitiatives,
  getAllInitiativesWithFundingInitiativeDetails,
  getAllInitiativesWithParentInheritanceAndBudgets,
  getAllInitiativesWithStatusOverride,
  getAllTopLevelInitiatives,
  getChildInitiatives,
  getFundingInitiatives,
  getInitiative,
  getInitiativeHierarchy,
  getInitiativeLineage,
  getInitiativesForSelect,
  getInitiativesWithBudgetParentDetails,
  updateInitiative,
} from '../initiativeService'
import { elasticSearch } from '../elastic/network'
import { getFinancialTagTypes, getInitiativeStatus, getInitiativeTypes } from '../referenceDataService'
import { mapElasticResults } from '../elastic/helpers'
import { translateQuery } from '../elastic/QueryTranslator'
import budgetService from '../BudgetService'
import elasticReset from '../elastic/reset'
import express from 'express'
import initiatives from './initiatives'
import tags from './tags'

const router = express.Router()

router.get('/referenceData/initiativeStatus', getInitiativeStatus)
router.get('/referenceData/financialTagTypes', getFinancialTagTypes)
router.get('/initiativeTypes', getInitiativeTypes)
router.use('/initiatives', initiatives)
router.use('/tags', tags)
router.get('/getInitiativeHierarchy', getInitiativeHierarchy)
router.get('/getAllInitiatives', getAllInitiatives)
router.get('/getAllInitiatives/heatmapPatch', getAllInitiativesWithStatusOverride)
router.get('/getAllInitiatives/fundingInitiativeView', getAllInitiativesWithParentInheritanceAndBudgets)
router.get('/getAllTopLevelInitiatives', getAllTopLevelInitiatives)
router.get('/getChildInitiatives/:parentId', getChildInitiatives)
router.get('/getInitiative/:initiativeId', getInitiative)
router.get('/getInitiativeLineage/:initiativeId', getInitiativeLineage)
router.get('/getInitiativesForSelect', getInitiativesForSelect)
router.get('/getAllInitiativesWithFundingInitiativeDetails', getAllInitiativesWithFundingInitiativeDetails)
router.get('/getInitiativesWithBudgetParentDetails', getInitiativesWithBudgetParentDetails)
router.post('/createInitiative', createInitiative)
router.put('/updateInitiative', updateInitiative)
router.get('/getFundingInitiatives', getFundingInitiatives)

router.get('/getBudgetsByInitiative/:initiativeId', budgetService.getBudgetsByInitiativeId)
router.get('/getBudgetsByFiscalYear/:fiscalYear', budgetService.getBudgetsByFiscalYear)
router.get('/getBudgetsByFiscalYears/:fiscalYears', budgetService.getBudgetsByFiscalYears)
router.get('/getAllBudgets', budgetService.getAllBudgets)
router.post('/createBudget', budgetService.createBudget)
router.put('/updateBudget', budgetService.updateBudget)

router.get('/getAllFiscalYears', budgetService.getAllFiscalYears)
router.get('/findFiscalYearForDate/:date', budgetService.findFiscalYearForDate)

router.get('/rebuild-elastic-search', async (req, res) => {
  await elasticReset()

  res.json('OK')
})

router.post('/elastic-search', async (req, res) => {
  const result = await elasticSearch(req.body)

  res.json(result)
})

router.get('/audits', async (req, res) => {
  const query = translateQuery(req.query)
  const results = await elasticSearch(query)

  return res.json(mapElasticResults(results))
})

export default router
