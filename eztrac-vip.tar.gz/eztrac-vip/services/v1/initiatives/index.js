import {
  getInitiativeMap,
  patchInitiative,
} from '../../initiativeService'
import express from 'express'
import includes from 'lodash/includes'

const router = express.Router()

router.get('/', (req, res) => {
  if ( req.query ) {
    if ( req.query.fields ) {
      if ( includes(req.query.fields, [ 'id', 'name' ]) ) {
        return getInitiativeMap(req, res)
      }
    }
  }

  return res.status(400).json('Bad Request')
})

router.patch('/:initiativeId', (req, res) => {
  if ( req.body ) {
    return patchInitiative(req, res)
  }

  return res.status(400).json('Bad Request')
})

export default router
