import {
  deleteInitiativeTag,
  getAncestralTags,
  getTagNames,
  getTagOptions,
  getTags,
  tagInitiative,
} from './dao/tagsDao'
import { parseAncestralTags } from './util/TagServiceUtil'
import isEmpty from 'lodash/isEmpty'

export const fetchTagNames = async (req, res) => {
  try {
    const result = await getTagNames()

    return res.json(result)
  } catch ( error ) {
    return res.status(500).send(error)
  }
}

export const fetchTagOptions = async (req, res) => {
  try {
    const result = await getTagOptions()

    return res.json(result)
  } catch ( error ) {
    return res.status(500).send(error)
  }
}

export const fetchInitTags = async (req, res) => {
  if ( req.query && req.query.initiativeId ) {
    try {
      const tags = await getAncestralTags(req.query.initiativeId)
      const initTags = parseAncestralTags(tags, req.query.initiativeId)

      return res.json(initTags)
    } catch ( error ) {
      return res.status(500).send(error)
    }
  }
  if ( isEmpty(req.query) ) {
    try {
      const tags = await getTags()

      return res.json(tags)
    } catch ( error ) {
      return res.status(500).send(error)
    }
  }

  return res.status(400).send('Optional query string should contain initiativeId field')
}

export const fetchAncestralTags = async (req, res) => {
  if ( req.query && req.query.initiativeId ) {
    try {
      const inheritedTags = await getAncestralTags(req.query.initiativeId)

      return res.json(inheritedTags)
    } catch ( error ) {
      return res.status(500).send(error)
    }
  }

  return res.status(400).send('Query must contain Initiative ID')
}

export const addInitTag = async (req, res) => {
  if ( req.body && req.body.initiativeId && req.body.tagId && req.body.tagValue ) {
    try {
      await tagInitiative(req.body.initiativeId, req.body.tagId, req.body.tagValue)

      return res.json('Successfully Tagged')
    } catch ( error ) {
      return res.status(500).json(error)
    }
  }

  return res.status(400).send('Body must contain initiativeId, tagId, and tagValue')
}

export const deleteInitTag = async (req, res) => {
  if ( req.body && req.query.initiativeId && req.query.tagId ) {
    try {
      await deleteInitiativeTag(req.query.initiativeId, req.query.tagId)

      return res.json('Successfully Deleted')
    } catch ( error ) {
      return res.status(500).json(error)
    }
  }

  return res.status(400).send('Query must contain initiativeId and tagId fields')
}
