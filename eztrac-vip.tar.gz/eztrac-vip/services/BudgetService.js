import { createBudget, getChildrenForBudgets, getFiscalYearForDate, getFiscalYears, updateBudget }
  from './util/BudgetUtil'
import BudgetDao from './dao/BudgetDao'
import getOrElse from 'lodash/get'

const BudgetService = {
  async getBudgetsByInitiativeId(req, res) {
    try {
      const budgets = await BudgetDao.getBudgetsByInitiative(req.params.initiativeId)
      const budgetsWithChildren = await getChildrenForBudgets(budgets, [])
      res.json(budgetsWithChildren)
    } catch ( error ) {
      res.status(error.statusCode).send(error.message)
    }
  },
  async getBudgetsByFiscalYear(req, res) {
    try {
      const budgets = await BudgetDao.getBudgetsByFiscalYear(req.params.fiscalYear)
      res.json(budgets)
    } catch ( error ) {
      res.status(error.statusCode).send(error.message)
    }
  },
  async getBudgetsByFiscalYears(req, res) {
    try {
      const budgets = await BudgetDao.getBudgetsByFiscalYears(req.params.fiscalYears.split(','))
      res.json(budgets)
    } catch ( error ) {
      res.status(error.statusCode).send(error.message)
    }
  },
  async getAllBudgets(req, res) {
    try {
      const budgets = await BudgetDao.getAllBudgets()
      res.json(budgets)
    } catch ( error ) {
      res.status(error.statusCode).send(error.message)
    }
  },
  async createBudget(req, res) {
    try {
      const budget = {
        ...req.body,
        modified_by: getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase(),
      }

      const budgetDetails = await createBudget(budget)
      res.json(budgetDetails)
    } catch ( error ) {
      res.status(error.statusCode).send(error.message)
    }
  },
  async updateBudget(req, res) {
    try {
      const budget = {
        ...req.body,
        modified_by: getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase(),
      }

      const budgetDetails = await updateBudget(budget, req.userProfile)
      res.json(budgetDetails)
    } catch ( error ) {
      res.status(error.statusCode).send(error.message)
    }
  },

  async getAllFiscalYears(req, res) {
    try {
      const fiscalYears = await getFiscalYears()
      res.json(fiscalYears)
    } catch ( error ) {
      res.status(error.statusCode).send(error.message)
    }
  },
  async findFiscalYearForDate(req, res) {
    try {
      res.json(getFiscalYearForDate(new Date(req.params.date)))
    } catch ( error ) {
      res.status(error.statusCode).send(error.message)
    }
  },

}

module.exports = BudgetService
