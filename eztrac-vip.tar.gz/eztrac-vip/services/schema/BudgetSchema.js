const BudgetSchema = {
  definitions: {
    createBudget: {
      type: 'object',
      properties: {
        initiative_id: { type: 'string', minLength: 1 },
        fiscal_year: { type: 'string', minLength: 4 },
        amount: { type: 'integer', minLength: 1 },
        create_time: { type: 'string', format: 'date-time' },
        modified_by: { type: 'string', minLength: 1 },
        update_time: { type: 'string', format: 'date-time' },
      },
      additionalProperties: false,
      required: [ 'initiative_id', 'fiscal_year', 'amount', 'update_time', 'modified_by' ],
    },
  },
  $ref: '#/definitions/createBudget',
}

module.exports = BudgetSchema
