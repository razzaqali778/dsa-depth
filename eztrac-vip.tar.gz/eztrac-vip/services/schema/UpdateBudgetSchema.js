const BudgetSchema = {
  definitions: {
    createBudget: {
      type: 'object',
      properties: {
        initiative_id: { type: 'string', minLength: 1 },
        fiscal_year: { type: 'string', minLength: 4 },
        amount: { type: 'integer', minLength: 1 },
        modified_by: { type: 'string', minLength: 1 },
      },
      additionalProperties: false,
      required: [
        'initiative_id',
        'fiscal_year',
        'amount',
        'modified_by',
      ],
    },
  },
  $ref: '#/definitions/createBudget',
}

module.exports = BudgetSchema
