const NewInitiativeSchema = {
  definitions: {
    newInitiative: {
      type: 'object',
      properties: {
        initiative_name: { type: 'string', minLength: 1 },
        status: { type: 'string', minLength: 1 },
        finance_code_type: { type: [ 'string', 'null' ], minLength: 1 },
        finance_code_value: { type: [ 'string', 'null' ], minLength: 1 },
        parent: { type: [ 'string', 'null' ], minLength: 1 },
      },
      additionalProperties: true,
      required: [ 'initiative_name', 'status' ],
    },
  },
  $ref: '#/definitions/newInitiative',
}

module.exports = NewInitiativeSchema
