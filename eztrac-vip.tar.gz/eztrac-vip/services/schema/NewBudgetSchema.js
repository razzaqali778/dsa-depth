const NewBudgetSchema = {
  definitions: {
    createNewBudget: {
      type: 'object',
      properties: {
        fiscal_year: { type: 'string', minLength: 4 },
        amount: { type: 'integer', minLength: 1 },
      },
      additionalProperties: true,
      required: [ 'fiscal_year', 'amount' ],
    },
  },
  $ref: '#/definitions/createNewBudget',
}

module.exports = NewBudgetSchema
