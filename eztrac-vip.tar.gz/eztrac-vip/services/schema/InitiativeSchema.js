const InitiativeSchema = {
  definitions: {
    createInitiative: {
      type: 'object',
      properties: {
        initiative_id: { type: 'string', minLength: 1 },
        initiative_name: { type: 'string', minLength: 1 },
        status: { type: 'string', minLength: 1 },
        finance_code_type: { type: [ 'string', 'null' ], minLength: 1 },
        finance_code_value: { type: [ 'string', 'null' ], minLength: 1 },
        parent: { type: [ 'string', 'null' ], minLength: 1 },
        legacy_tag: { type: [ 'string', 'null' ], minLength: 1 },
        modified_by: { type: [ 'string', 'null' ], minLength: 1 },
      },
      additionalProperties: true,
      required: [
        'initiative_id',
        'initiative_name',
        'parent',
        'status',
      ],
    },
  },
  $ref: '#/definitions/createInitiative',
}

module.exports = InitiativeSchema
