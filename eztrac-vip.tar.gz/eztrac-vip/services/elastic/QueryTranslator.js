import getOrElse from 'lodash/get'
import includes from 'lodash/includes'
import keys from 'lodash/keys'
import map from 'lodash/map'
import uniq from 'lodash/uniq'

const size = 500

export const aggs = {
  aggs: {
    modified_by: { terms: { field: 'modified_by', size } },
    year: { terms: { field: 'fiscal_year', size } },
    finance_code_value: { terms: { field: 'finance_code_value', size } },
    initiative: { terms: { field: 'initiative_id', size } },
    type_id: { terms: { field: 'type_id', size } },
    // max_budget: { max: { field: 'amount' } },
    // min_budget: { min: { field: 'amount' } },
    // month_changed: { date_histogram: { field: 'fiscal_year', interval: 'month', size: 50 } },
  },
}

export const intFields = [
  // 'fiscal_year',
  'amount',
]

export const dateFields = [
  'modified_time',
]

export const strFields = [
  '_id',
  'table_type',
  'fiscal_year',
  'modified_by',
  'initiative_name',
  'finance_code_type',
  'finance_code_value',
  'parent',
  'type_id',
]
const isNum = val => !isNaN(parseInt(val, 10))

// const escapeSpace = str => replace(str, ' ', '\\ ')
const escapeSpace = str => str.replace(/ /ig, '\\ ')
const setQuery = (key, value) => {
  if ( key === 'q' ) {
    return `${value} OR *${value}*`
  }

  return escapeSpace(value).split(',').join(' OR ')
}

const setFields = (key, value) => {
  if ( key === 'q' && isNum(value) ) {
    return intFields
  } else if ( key === 'q' ) {
    return strFields
  }

  return [ `${key}` ]
}
const queryStringGenerator = (key, value) => {
  const fields = setFields(key, value)
  const query = setQuery(key, value)

  return ({
    query_string: {
      query,
      fields,
    },
  })
}


const rangeGenerator = (key, query) => {
  const min = getOrElse(query, `${key}_min`, false)
  const max = getOrElse(query, `${key}_max`, false)

  if ( min && max ) {
    return { range: { [key]: { gte: min, lte: max } } }
  } else if ( min ) {
    return { range: { [key]: { gte: min } } }
  } else if ( max ) {
    return { range: { [key]: { lte: max } } }
  }

  return { match: { [key]: query[key] } }
}

export const translateQuery = function func(query) {
  const rangeKeys = [ 'amount', 'modified_time' ]

  const queryKeys = uniq(map(keys(query), k => k.replace('_max', '').replace('_min', '')))

  const mustArray = map(queryKeys, k => {
    if ( includes(rangeKeys, k) ) { return rangeGenerator(k, query) }

    return queryStringGenerator(k, query[k])
  })

  const elasticQuery = {
    size,
    query: {
      bool: {
        must: mustArray,
      },
    },
    sort: [
      { modified_time: { order: 'desc' } },
    ],
  }

  console.log('query is', JSON.stringify(elasticQuery)) // eslint-disable-line no-console

  return { ...elasticQuery, ...aggs }
}
