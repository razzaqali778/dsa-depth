// initiative

// const mappings = {
//   row: {
//     properties: {
//       initiative_id: '',
//       initiative_name: '',
//       finance_code_type: '',
//       finance_code_value: '',
//       parent: '',
//       modified_by: '',
//     },
//   },
// }

// budget
// const mappings = {
//   row: {
//     properties: {
//       initiative_id: '',
//       fiscal_year: '',
//       amount: '',
//       modified_by: '',
//     },
//   },
// }

const STRING_TYPE = { type: 'keyword' }

const INT_TYPE = { type: 'integer' }

const mappings = {
  _doc: {
    properties: {
      table_type: STRING_TYPE,
      initiative_id: STRING_TYPE,
      fiscal_year: STRING_TYPE,
      amount: INT_TYPE,
      modified_by: STRING_TYPE,
      initiative_name: STRING_TYPE,
      finance_code_type: STRING_TYPE,
      finance_code_value: STRING_TYPE,
      parent: STRING_TYPE,
      type_id: STRING_TYPE,
      modified_time: { type: 'date', format: "yyyy-MM-dd'T'HH:mm:ss.SSSZ||epoch_millis" },
    },
  },
}

export default mappings
