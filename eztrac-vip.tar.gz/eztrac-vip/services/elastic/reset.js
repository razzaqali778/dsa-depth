import { bulkAdd, deleteIndex, initializeIndex } from './network'
import { getAllAudits } from '../dao/AuditDao'
import { translateAudit } from './helpers'
import map from 'lodash/map'

const log = str => process.stdout.write(str)

const reset = async function reset() {
  log('Deleting index...')
  await deleteIndex()
  log('Index deleted, initializing index...')
  await initializeIndex()
  log('Initialized\n')
  const audits = await getAllAudits()
  const transformedAudits = map(audits, translateAudit(audits))

  return bulkAdd(transformedAudits)
}


export default reset
