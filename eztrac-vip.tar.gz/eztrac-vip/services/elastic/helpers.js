import { findPreviousAudit } from '../util/audit'
import entriesIn from 'lodash/entriesIn'
import flow from 'lodash/flow'
import getOr from 'lodash/fp/getOr'
import getOrElse from 'lodash/get'
import map from 'lodash/fp/map'
import mapValues from 'lodash/fp/mapValues'
import reduce from 'lodash/reduce'


export const translateAudit = auditList => audit => {
  const lastAudit = findPreviousAudit(auditList, audit)

  const entity = lastAudit ? reduce(entriesIn(audit.entity), (memo, [ key, value ]) => {
    const previousValue = getOrElse(lastAudit, `entity.${key}`, '')
    memo[key] = value // eslint-disable-line no-param-reassign
    if ( previousValue !== value ) {
      memo[`${key}_prev`] = previousValue // eslint-disable-line no-param-reassign
    }

    return memo
  }, {}) : audit.entity

  const obj = {
    modified_by: audit.modified_by,
    table_type: audit.table_type,
    modified_time: audit.modified_time,
    ...entity,
  }

  return obj
}
export const mapElasticResults = results => {
  const hits = flow(
    getOr([], 'hits.hits'),
    map(v => v._source) // eslint-disable-line no-underscore-dangle
  )(results)

  const aggs = flow(
    getOr({}, 'aggregations'),
    mapValues(({ buckets }) => reduce(buckets, (memo, val) => {
      memo[val.key] = val.doc_count // eslint-disable-line no-param-reassign

      return memo
    }, {})),
  )(results)

  return { hits, aggs }
}
