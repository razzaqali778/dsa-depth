import { Client } from '@opensearch-project/opensearch'
import { defaultProvider } from '@aws-sdk/credential-provider-node'
import config from '../../config'
import logger from '../util/logger'
import mappings from './searchmappings'

const { AwsSigv4Signer } = require('@opensearch-project/opensearch/aws')

const { url } = config.get('elastic-search')
const index = process.env.NODE_ENV === 'development' ? 'vip-audits-local' : 'vip-audits'

const client = new Client({
  ...AwsSigv4Signer({
    region: 'us-east-1',
    service: 'es',
    getCredentials: () => {
      const credentialsProvider = defaultProvider()

      return credentialsProvider()
    },
  }),
  requestTimeout: 60000,
  node: `https://${url}`,
})

export const checkIfDocumentAlreadyAdded = async doc => {
  const mustClauses = []

  Object.keys(doc).forEach(property => {
    if ( property !== 'modified_time' && doc[property] !== null ) {
      mustClauses.push({
        match: {
          [property]: doc[property],
        },
      })
    }
  })

  const timeDifferenceTolerance = 2000
  const cutoffTime = new Date(doc.modified_time)
  cutoffTime.setTime(cutoffTime.getTime() - timeDifferenceTolerance)
  mustClauses.push({
    range: {
      modified_time: {
        gte: cutoffTime.toISOString(),
      },
    },
  })

  const query = {
    index,
    body: {
      query: {
        bool: {
          must: mustClauses,
        },
      },
    },
  }

  try {
    const { body } = await client.search(query)

    return body.hits.total > 0
  } catch ( error ) {
    logger.error('Error searching for document:', error)

    return []
  }
}

export const addTranslatedDoc = async doc => {
  try {
    const result = await client.index({
      index,
      body: doc,
    })

    return result
  } catch ( err ) {
    logger.error(`Error adding document: ${JSON.stringify(err)}`)

    return { error: 'broke it' }
  }
}

const processErrors = res => {
  const commands = [ 'create', 'update', 'delete' ]

  if ( res.errors === true ) {
    res.items.forEach( item => {
      commands.forEach( command => {
        const subItem = item[command]

        if ( subItem && subItem.error ) {
          console.log(`ES Bulkadd Error -- ${subItem._id}: ${JSON.stringify(subItem.error)}`) // eslint-disable-line no-console
        }
      })
    })
  }
}

export const bulkAdd = async docs => {
  try {
    const result = await client.helpers.bulk({
      datasource: docs,
      onDocument() {
        return { index: { _index: index, _type: '_doc' } }
      },
    })

    return processErrors(result)
  } catch ( err ) {
    logger.error('Error bulk adding: ', JSON.stringify(err)) // eslint-disable-line no-console

    return err
  }
}

export const elasticSearch = async searchDoc => {
  try {
    const results = await client.search({
      index,
      body: searchDoc,
    })

    return results.body
  } catch ( err ) {
    logger.error(JSON.stringify(err))

    return err
  }
}

export const deleteIndex = async () => {
  try {
    await client.indices.delete({ index })
  } catch ( err ) {
    console.log(`Error deleting ${index}: ${JSON.stringify(err)}`) // eslint-disable-line no-console

    return false
  }

  return true
}

export const initializeIndex = async () => {
  const settings = {}
  try {
    await client.indices.create({
      index,
      body: {
        settings,
        mappings,
      },
    })
  } catch ( err ) {
    console.log(`Error initializing ${index}: ${JSON.stringify(err)}`) // eslint-disable-line no-console
  }
}
