import { createInitiativeRequest as daoCreateInitiativeRequest,
  updateRequest as daoUpdateRequest,
} from '../../dao/requestedInitiativeDaoV2'
import { sendMessage } from '../../util/MessagingUtil'
import { v1 as uuid } from 'uuid'
import config from '../../../config'
import flow from 'lodash/flow'
import forEach from 'lodash/forEach'
import getOrElse from 'lodash/get'
import map from 'lodash/map'
import reduce from 'lodash/reduce'
import some from 'lodash/some'

const { papiGroup: velocityInitiativeRequest } = config.get('vip-request-initiative')
const { ui: ezTracUIUrl } = config.get('ez-trac-vip-url')

export const buildMessageBody = (requestedInitiative, startMessage) => {
  const addToMessageIfExists = (key, label) => (
    message => requestedInitiative[key] ? `${message}**${label}**: ${requestedInitiative[key]}\n\n` : message
  )

  const addToMessageIfExistsMoney = (key, label) => (
    message => requestedInitiative[key] ? `${message}**${label}**: $${requestedInitiative[key]}\n\n` : message
  )

  const message = flow(
    addToMessageIfExists('name', 'Name'),
    addToMessageIfExists('parentName', 'Parent Initiative'),
    addToMessageIfExists('type', 'Initiative Type'),
    addToMessageIfExists('status', 'Status'),
    addToMessageIfExists('financialCode', 'Financial Code'),
    addToMessageIfExistsMoney('budget', 'Budget'),
    addToMessageIfExists('fiscalYear', 'Fiscal Year'),
    addToMessageIfExists('portfolioId', 'Portfolio ID'),
    addToMessageIfExists('activityId', 'Activity ID'),
    addToMessageIfExists('businessUnit', 'Business Unit'),
    addToMessageIfExists('region', 'Region'),
    addToMessageIfExists('comment', 'Comments'),
    addToMessageIfExists('programCode', 'Program Code'),
  )(startMessage)

  return `${message}**Link**: ${ezTracUIUrl}/request-initiative/${requestedInitiative.id}\n\n`
}

const createInitiativeRequest = async (initiativeRequest, requestedBy) => {
  await daoCreateInitiativeRequest({ ...initiativeRequest,
    requestedBy,
  })
}

export const postInitiativeRequest = async (req, res) => {
  const { body: requestedInitiatives } = req

  if ( some(requestedInitiatives, initiative => !initiative.name ) ) {
    return res.json('BAD_REQUEST')
  }

  const requestedInitiativesWithID = map(requestedInitiatives, requestedInitiative => (
    { ...requestedInitiative, id: uuid() }
  ))

  const userInfo = JSON.parse(getOrElse(req, 'headers.user-profile', '{ "id": "UNKNOWN", "fullName": "UNKNOWN" }'))
  const startMessage = `**User ID**: ${userInfo.id}\n\n**User Name**: ${userInfo.fullName}\n\n`

  const requestMessage = reduce(
    requestedInitiativesWithID,
    (messageSoFar, initiative) => buildMessageBody(initiative, `${messageSoFar}\n\n---\n\n`),
    startMessage
  )
  const title = requestedInitiativesWithID.length === 1 ?
    `Initiative Request "${requestedInitiativesWithID[0].name}"` :
    'Multiple Initiatives'

  const messageBody = {
    title,
    body: {
      text: requestMessage,
      markdown: requestMessage,
    },
    recipients: [
      userInfo.id,
    ],
    userGroups: [
      velocityInitiativeRequest,
    ],
    tags: [
      'VIP-REQUEST-INITIATIVE',
    ],
  }

  try {
    forEach(requestedInitiativesWithID, async requestedInitiative => {
      await createInitiativeRequest(requestedInitiative, userInfo.id)
    })

    const requestMessageResponse = await sendMessage(messageBody)
    console.log(requestMessageResponse)// eslint-disable-line no-console

    return res.json('OK')
  } catch ( err ) {
    console.log(err)// eslint-disable-line no-console

    return res.json('BAD_REQUEST')
  }
}

export const updateInitiative = async (req, res) => {
  try {
    const id = req.params.id
    const body = req.body
    const result = await daoUpdateRequest(id, body)

    return res.json(result)
  } catch ( error ) {
    return res.status(500).send(error)
  }
}
