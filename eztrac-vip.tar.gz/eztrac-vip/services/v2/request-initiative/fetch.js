import { getInitiativeRequest as daoGetInitiativeRequest } from '../../dao/requestedInitiativeDaoV2'

export const getInitiativeRequest = async (req, res) => {
  const { params: { id } } = req
  try {
    const requestedInitiative = await daoGetInitiativeRequest(id)

    return res.json(requestedInitiative)
  } catch ( err ) {
    return res.status(err.statusCode || 500).json(err)
  }
}
