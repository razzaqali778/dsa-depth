import { getInitiativeRequest } from './fetch'
import { postInitiativeRequest, updateInitiative } from './update'
import express from 'express'

const router = express.Router()

router.post('/', postInitiativeRequest)
router.get('/:id', getInitiativeRequest)
router.patch('/:id', updateInitiative)

export default router
