
import { fieldsContains } from '../initiativeUtils/initiativeQueryTranslator'
import { getAllInitiativeTags } from '../../dao/tagsDao'
import filter from 'lodash/filter'
import isNull from 'lodash/isNull'
import map from 'lodash/map'
import orderBy from 'lodash/orderBy'
import pickBy from 'lodash/pickBy'
import uniqBy from 'lodash/uniqBy'

const findRelatedTags = (allInitiativeTags, id, level) => {
  const relatedInitiativeTags = filter(allInitiativeTags, { initiative_id: id })
  const parentTags = (relatedInitiativeTags[0] && relatedInitiativeTags[0].parent_id)
    ? findRelatedTags(allInitiativeTags, relatedInitiativeTags[0].parent_id, level + 1)
    : []

  return relatedInitiativeTags.concat(parentTags)
}

const cleanUpTags = initiativeTags => {
  const filteredOutNulls = pickBy(initiativeTags, tag => !isNull(tag.tag_id))
  const orderedTags = orderBy(filteredOutNulls, [ 'level' ], [ 'asc' ])
  const uniqTags = uniqBy(orderedTags, 'tag_id')

  return uniqTags.map(tag => ({
    tagId: tag.tag_id,
    tagValue: tag.tag_value,
  }))
}

const getInitiativesWithInheritedTags = async (req, initiatives) => {
  if ( fieldsContains(req.query, 'tags') ) {
    const initiativesWithTags = await getAllInitiativeTags()
    const initiativesWithInheritedTags = map(initiatives, initiative => {
      const relatedTags = cleanUpTags(findRelatedTags(initiativesWithTags, initiative.id, 0))

      return { ...initiative, tags: [ ...relatedTags ] }
    })

    return initiativesWithInheritedTags
  }

  return initiatives
}

export default getInitiativesWithInheritedTags

