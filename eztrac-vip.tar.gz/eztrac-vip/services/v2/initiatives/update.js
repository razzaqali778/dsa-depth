import {
  patchInitiative as daoPatchInitiative,
} from '../../dao/initiativeDao'
import getOrElse from 'lodash/get'

export const patchInitiative = async (req, res) => {
  try {
    const id = req.params.id
    const changedValues =
      { ...req.body,
        modified_by: getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase() }

    if ( !req.body || !id ) {
      return res.status(400).send('Missing body')
    }

    const result = await daoPatchInitiative(id, changedValues)

    return res.json(result)
  } catch ( err ) {
    return res.status(500).send(err)
  }
}
