import {
  executeQuery,
  getAllForCycleCheck,
} from '../../dao/initiativeDao'
import {
  filterAllocable,
  filterStatus,
} from '../initiativeUtils/initiativeFilter'
import { getAllTranslator } from '../initiativeUtils/initiativeQueryTranslator'
import { getLimitedInitiativesAndParent } from '../../dao/initiativeDaoV2'
import addFundingDetails from '../initiativeUtils/addFundingDetails'
import cycleCheck from '../initiativeUtils/cycleCheck'
import determineInheritableProperties from '../initiativeUtils/determineInheritableProperties'
import getInitiativesFinalTags from './fetchUtil'
import log from '../../util/logger'

export const getLimitedInitiatives = async (req, res) => {
  const initiatives = await getLimitedInitiativesAndParent()

  res.json(initiatives)
}

export const getInitiatives = async (req, res) => {
  try {
    const query = getAllTranslator(req)
    const initiatives = await executeQuery(query)
    const initiativesWithInheritableProperties = determineInheritableProperties(initiatives)
    const filteredAllocableInitiatives = filterAllocable(req, initiativesWithInheritableProperties)
    const filteredStatusInitiatives = filterStatus(req, filteredAllocableInitiatives)
    const initsWithTags = await getInitiativesFinalTags(req, filteredStatusInitiatives)

    if ( req.query.includeFundingDetails ) {
      return res.json(addFundingDetails(initsWithTags))
    }

    return res.json(initsWithTags)
  } catch ( err ) {
    log.error('Error fetching all initiatives:', err)

    return res.status(err.statusCode || 500).json(err)
  }
}

export const checkForCycles = async (req, res) => {
  const initiatives = await getAllForCycleCheck()

  res.json(cycleCheck(initiatives))
}
