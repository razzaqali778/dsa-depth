import {
  executeQuery,
} from '../../dao/initiativeDao'
import { filterAllocable } from '../initiativeUtils/initiativeFilter'
import { getAllTranslator } from '../initiativeUtils/initiativeQueryTranslator'
import { reduceTree } from '../initiativeUtils/treeHelpers'
import addActivityId from '../initiativeUtils/addActivityId'
import addFundingDetails from '../initiativeUtils/addFundingDetails'
import determineInheritableProperties from '../initiativeUtils/determineInheritableProperties'
import getInitiativesFinalTags from './fetchUtil'
import includes from 'lodash/includes'
import log from '../../util/logger'

export default async (req, res) => {
  try {
    const queryParams = {
      query: {
        ...req.query,
        fields: `${req.query.fields}${includes(req.query.fields, 'parent') ? '' : ',parent'}`, // make sure we're include parent in the query
      },
    }

    const query = getAllTranslator(queryParams)
    const initiatives = await executeQuery(query)
    const initiativesWithActivityId = addActivityId(initiatives)
    const list = addFundingDetails(initiativesWithActivityId)
    const allocableFilteredList = filterAllocable(req, determineInheritableProperties(list))
    const taggedList = await getInitiativesFinalTags(req, allocableFilteredList)
    const tree = reduceTree(taggedList)

    return res.json(tree)
  } catch ( err ) {
    log.error('Error fetching all initiatives:', err)

    return res.status(err.statusCode || 500).json(err)
  }
}
