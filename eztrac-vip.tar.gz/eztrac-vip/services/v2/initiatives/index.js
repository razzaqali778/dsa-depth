import {
  checkForCycles,
  getInitiatives,
  getLimitedInitiatives,
} from './fetch'
import express from 'express'
import getInitiativesTree from './getInitiativesTree'


const router = express.Router()

router.get('/get-limited-initiatives-and-parents', getLimitedInitiatives)
router.get('/', getInitiatives)
router.get('/cycle-detection', checkForCycles)
router.get('/tree', getInitiativesTree)

export default router
