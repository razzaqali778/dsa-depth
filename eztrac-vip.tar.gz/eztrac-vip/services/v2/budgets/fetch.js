import { fetchBudgetsByInitiativeId, fetchParentBudget } from '../../dao/budgetDaoV2.js'
import { fetchSplitsByBudgetId } from '../../dao/budgetSplitDao'

export const getSplitsById = async (req, res) => {
  try {
    const splits = await fetchSplitsByBudgetId(req.params.id)

    return res.json(splits)
  } catch ( err ) {
    return res.status(500).json(err)
  }
}

export const getBudgetsByInitiativeId = async (req, res) => {
  try {
    const budgets = await fetchBudgetsByInitiativeId(req.params.id)
    if ( req.query.includeSplits ) {
      const promises = budgets.map(({ budgetId }) => fetchSplitsByBudgetId(budgetId))
      const splits = await Promise.all(promises)

      const splitMap = splits.reduce((memo, val) => {
        if ( val.length > 0 ) {
          const id = val[0].budgetId
          memo[id] = val // eslint-disable-line no-param-reassign

          return memo
        }

        return memo
      }, {})

      const budgetsWithSplits = budgets.map(budget => ({
        ...budget,
        splits: splitMap[budget.budgetId] || [],
      }))

      return res.json(budgetsWithSplits)
    }

    return res.json(budgets)
  } catch ( err ) {
    return res.status(500).json(err)
  }
}

export const getParentBudgetByInitiativeId = async (req, res) => {
  try {
    const parentBudget = await fetchParentBudget(req.params.id)

    return res.json(parentBudget)
  } catch ( error ) {
    return res.status(500).json(error)
  }
}
