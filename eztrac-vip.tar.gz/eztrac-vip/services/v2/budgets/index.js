import {
  deleteByBudgetId,
} from './delete'
import {
  getBudgetsByInitiativeId,
  getParentBudgetByInitiativeId,
  getSplitsById,
} from './fetch'
import {
  postBudget,
  putBudget,
  putSplits,
  saveSplit,
} from './update'


import express from 'express'

const router = express.Router()

router.post('/', postBudget)
router.put('/', putBudget)

router.get('/:id', getBudgetsByInitiativeId)
router.get('/:id/parent', getParentBudgetByInitiativeId)

router.get('/splits/:id', getSplitsById)
router.delete('/splits/:id', deleteByBudgetId)
router.post('/splits', saveSplit)
router.put('/splits', putSplits)

export default router
