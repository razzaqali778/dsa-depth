import {
  createBudget,
  updateBudget,
} from '../../dao/budgetDaoV2'
import { insertBudgetSplits } from '../../dao/budgetSplitDao'
import getOrElse from 'lodash/get'
import isArray from 'lodash/isArray'
import uniqBy from 'lodash/uniqBy'

export const saveSplit = async (req, res) => res.json('NYI')

const validateIds = budgets =>
  budgets.length > 0 && uniqBy(({ budgetId }) => budgetId).length === 1

export const putSplits = async (req, res) => {
  const { body: splits } = req
  if ( isArray(splits) && validateIds(splits) ) {
    const { budgetId } = splits[0]
    await insertBudgetSplits(budgetId, splits)

    return res.json('OK')
  }

  return res.status(400).json('Payload should be array and each item should correspond to the same budgetId')
}

export const putBudget = async (req, res) => {
  try {
    const { budgetId, ...rest } = await updateBudget({
      ...req.body,
      modifiedBy: getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase(),
    })
    await insertBudgetSplits(budgetId, req.body.splits)

    res.json(rest)
  } catch ( err ) {
    res.status(500).json('Error updating budget: ', err)
  }
}

export const postBudget = async (req, res) => {
  try {
    const result = await createBudget({
      ...req.body,
      modifiedBy: getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase(),
    })
    if ( req.body.splits && req.body.splits.length ) {
      await insertBudgetSplits(result.budgetId, req.body.splits)
    }

    res.json(result)
  } catch ( err ) {
    res.status(500).json('Error creating budget: ', err)
  }
}
