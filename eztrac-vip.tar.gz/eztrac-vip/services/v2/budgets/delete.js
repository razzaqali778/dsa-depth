import { deleteSplitsByBudgetId } from '../../dao/budgetSplitDao'

export const deleteByBudgetId = async (req, res) => {
  try {
    const splits = await deleteSplitsByBudgetId(req.params.id)

    return res.json(splits)
  } catch ( err ) {
    return res.status(500).json(err)
  }
}
