import {
  createInitiative,
  updateInitiative,
} from '../../dao/initiativeDaoV2'
import {
  patchInitiative as daoPatchInitiative,
} from '../../dao/initiativeDao'
import getOrElse from 'lodash/get'

export const patchInitiative = async (req, res) => {
  try {
    const id = req.params.id
    const changedValues =
      { ...req.body,
        modified_by: getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase() }

    if ( !req.body || !id ) {
      return res.status(400).send('Missing body')
    }

    const result = await daoPatchInitiative(id, changedValues)

    return res.json(result)
  } catch ( err ) {
    return res.status(500).send(err)
  }
}

export const postInitiative = async (req, res) => {
  try {
    const result = await createInitiative({
      ...req.body,
      modifiedBy: getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase(),
    })

    res.json(result)
  } catch ( error ) {
    res.status(500).json('Error creating initiative', error)
  }
}

export const putInitiative = async (req, res) => {
  try {
    const result = await updateInitiative({
      ...req.body,
      modifiedBy: getOrElse(req, 'userProfile.id', process.env.USER || 'UNKNOWN').toUpperCase(),
    })

    res.json(result)
  } catch ( error ) {
    res.status(500).json('Error updating initiative', error)
  }
}
