import { executeQuery } from '../../dao/initiativeDao'
import { fieldsContains, getChildrenByIdTranslator } from '../initiativeUtils/initiativeQueryTranslator'
import { getAncestralTags } from '../../dao/tagsDao'
import getInheritedDetailsForSingle from '../initiativeUtils/getInheritedDetailsForSingle'
import isNull from 'lodash/isNull'
import map from 'lodash/map'
import orderBy from 'lodash/orderBy'
import pickBy from 'lodash/pickBy'
import uniqBy from 'lodash/uniqBy'

export const getChildren = async (req, fundingDetails) => {
  if ( req.query.includeChildren ) {
    const childrenQuery = getChildrenByIdTranslator(req)
    const children = await executeQuery(childrenQuery, 'any')
    if ( fundingDetails !== {} ) {
      return { children: map(children, child => ({ ...child, ...(child.financeCodeValue ? {} : fundingDetails) })) }
    }

    return { children }
  }

  return {}
}

export const fetchFundingDetails = async initiative => {
  const fundingDetails = await getInheritedDetailsForSingle(
    initiative.status,
    initiative.financeCodeValue,
    initiative.financeCodeType,
    initiative.portfolioCode,
    initiative.activityId,
    initiative.programCode,
    initiative.parentId
  )

  return fundingDetails
}

export const fetchInheritedTags = async req => {
  if ( fieldsContains(req.query, 'tags') ) {
    const ancestralTags = await getAncestralTags(req.params.id)
    const filteredOutNulls = pickBy(ancestralTags, tag => !isNull(tag.tag_id))
    const orderedTags = orderBy(filteredOutNulls, [ 'level' ], [ 'asc' ])
    const uniqTags = uniqBy(orderedTags, 'tag_id')
    const mapTags = uniqTags.map(tag => ({
      tagId: tag.tag_id,
      tagValue: tag.tag_value,
    }))

    return { tags: mapTags }
  }

  return { tags: [] }
}
