
import {
  getAllDescendants as daoGetAllDescendants,
  executeQuery,
} from '../../dao/initiativeDao'
import { fetchFundingDetails, fetchInheritedTags, getChildren } from './fetchUtils'
import {
  getByIdTranslator,
} from '../initiativeUtils/initiativeQueryTranslator'

export const getInitiativeById = async (req, res) => {
  try {
    const query = getByIdTranslator(req)
    const initiative = await executeQuery(query, 'one')
    const fundingDetails = await fetchFundingDetails(initiative)
    const children = await getChildren(req, fundingDetails)
    const tags = await fetchInheritedTags(req)

    const updated = {
      ...initiative,
      ...fundingDetails,
      ...children,
      ...tags,
    }

    res.json(updated)
  } catch ( err ) {
    res.status(err.statusCode || 500).json(err)
  }
}

export const getDescendantsById = async (req, res) => {
  try {
    const result = await daoGetAllDescendants(req.params.id)

    res.json(result)
  } catch ( err ) {
    res.status(err.statusCode || 500).json(err)
  }
}
