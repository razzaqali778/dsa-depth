import {
  getDescendantsById,
  getInitiativeById,
} from './fetch'
import {
  patchInitiative,
  postInitiative,
  putInitiative,
} from './update'

import express from 'express'

const router = express.Router()

router.get('/:id', getInitiativeById)
router.get('/:id/descendants', getDescendantsById)
router.post('/', postInitiative)
router.put('/', putInitiative)
router.patch('/:id', patchInitiative)

export default router
