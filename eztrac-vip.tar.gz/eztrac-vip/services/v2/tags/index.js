import { fetchTagNames } from './fetch'
import express from 'express'

const router = express.Router()

router.get('/names', fetchTagNames)

export default router
