import { getTagNames as daoGetTagNames } from '../../dao/tagsDaoV2'

export const fetchTagNames = async (req, res) => {
  const tags = await daoGetTagNames()

  res.json(tags)
}
