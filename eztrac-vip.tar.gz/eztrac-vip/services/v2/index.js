import budgets from './budgets'
import express from 'express'
import initiative from './initiative'
import initiatives from './initiatives'
import requestInitiative from './request-initiative'
import tags from './tags'

const router = express.Router()

router.use('/initiatives', initiatives)
router.use('/initiative', initiative)
router.use('/budgets', budgets)
router.use('/tags', tags)
router.use('/request-initiative', requestInitiative)

export default router
