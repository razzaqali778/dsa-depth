import filter from 'lodash/filter'
import map from 'lodash/map'


export const getRootNodes = initiatives => filter(initiatives, ({ parentId }) => parentId === null )


export const findAllChildren = ( initiatives, root ) =>
  filter(initiatives, ( initiative => initiative.parentId === root.id ))


export const buildTree = ( initiatives, root ) => {
  const children = findAllChildren(initiatives, root)

  const childrenArray = map(children, child => buildTree(initiatives, child))

  return {
    ...root,
    children: childrenArray,
  }
}

export const reduceTree = initiatives => {
  const rootNodes = getRootNodes(initiatives)

  return map( rootNodes, rootNode => buildTree(initiatives, rootNode))
}
