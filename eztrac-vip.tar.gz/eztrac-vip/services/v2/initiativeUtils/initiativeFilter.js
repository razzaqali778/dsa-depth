
export const filterAllocable = (req, initiatives) => {
  if ( req && req.query && req.query.isAllocable !== undefined ) {
    const isAllocable = Boolean(req.query.isAllocable)

    return initiatives.filter(initiative => initiative.isAllocable === isAllocable)
  }

  return initiatives
}

export const filterStatus = (req, initiatives) => {
  if ( req && req.query && req.query.status !== undefined ) {
    const status = req.query.status

    return initiatives.filter(initiative => initiative.status === status)
  }

  return initiatives
}
