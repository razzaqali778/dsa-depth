import getInheritableProperty from './getInheritableProperty'
import map from 'lodash/map'

export default initiatives =>
  map(initiatives, initiative => ({
    ...initiative,
    status: getInheritableProperty(initiatives, initiative, 'status', 'parent_status'),
    activityId: getInheritableProperty(initiatives, initiative, 'activityId', 'parent_activity_id'),
    programCode: getInheritableProperty(
      initiatives,
      initiative,
      'programCode',
      'parent_program_code'
    ),
    portfolioCode: getInheritableProperty(
      initiatives,
      initiative,
      'portfolioCode',
      'parent_portfolio_code'
    ),
  }))
