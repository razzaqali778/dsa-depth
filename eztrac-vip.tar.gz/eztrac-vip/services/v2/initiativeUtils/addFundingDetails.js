import findParent from './findParent'
import map from 'lodash/map'

const findFundingDetails = (initiatives, current, start = 0) => {
  const { financeCodeValue, financeCodeType, id, initiativeName } = current
  if ( (financeCodeValue && financeCodeType ) || start > 10 ) {
    return {
      financeCodeValue,
      financeCodeType,
      fundingInitiativeId: id,
      fundingInitiativeName: initiativeName,
    }
  }

  const parent = findParent(initiatives, current)

  if ( parent ) {
    return findFundingDetails(initiatives, parent, start + 1)
  }

  return {
    financeCodeValue,
    financeCodeType,
    fundingInitiativeId: id,
    fundingInitiativeName: initiativeName,
  }
}
export default initiatives =>
  map(initiatives, i => ({
    ...i,
    ...findFundingDetails(initiatives, i),
  }))
