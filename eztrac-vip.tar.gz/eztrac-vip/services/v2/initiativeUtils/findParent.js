import find from 'lodash/find'

export default (initiatives, { parentId }) => find(initiatives, ({ id }) => parentId === id )
