import find from 'lodash/find'
import findIndex from 'lodash/findIndex'
import findParent from './findParent'
import forEach from 'lodash/forEach'
import includes from 'lodash/includes'
import isArray from 'lodash/isArray'
import isEmpty from 'lodash/isEmpty'
import sortBy from 'lodash/sortBy'
import uniq from 'lodash/uniq'

const floyd = (f, x0) => {
  const starter = x0.id
  const list = [ starter ]
  let tortoise = f(x0)

  if ( !tortoise ) { return [] }
  while ( !includes(list, tortoise.id) ) {
    list.push(tortoise.id)
    tortoise = f(tortoise)
    if ( !tortoise ) { return [] }
  }

  const cycleStartIndex = findIndex(list, v => v === tortoise.id)

  return list.slice(cycleStartIndex, list.length)
}

export default initiatives => {
  const f = x => x ? findParent(initiatives, x) : null
  const cycles = []
  const check = ({ id, parentId }) => {
    if ( !parentId ) { return false }

    return find(cycles, c => {
      if ( includes(c, id) ) {
        return true
      }

      return false
    })
  }

  const newCycle = cycle => {
    const stringCycle = JSON.stringify(cycle)

    return !find(cycles, c => JSON.stringify(c) === stringCycle)
  }
  forEach(initiatives, i => {
    if ( !check(i) ) {
      const cycle = sortBy(floyd(f, i))
      if ( isArray(cycle) && !isEmpty(cycle) ) {
        console.log('found a cycle')// eslint-disable-line no-console
      }

      if ( isArray(cycle) && !isEmpty(cycle) && newCycle(cycle) ) {
        cycles.push(cycle)
      }
    }
  })

  return uniq(cycles)
}
