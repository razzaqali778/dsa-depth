import { getInitiative } from '../../dao/initiativeDao'

const findInheritedDetailsForSingle = async (status, financeCodeValue, financeCodeType,
  portfolioCode, activityId, programCode, parentId) => {
  // TODO allow portfolio code inheritance differently? - Yes, I believe this is what is being done
  if ( status && financeCodeValue && portfolioCode && activityId && programCode ) {
    return { status, financeCodeValue, financeCodeType, portfolioCode, activityId, programCode }
  }

  if ( parentId ) {
    const parent = await getInitiative(parentId)

    return findInheritedDetailsForSingle(
      status || parent.status,
      financeCodeValue || parent.finance_code_value,
      financeCodeType || parent.finance_code_type,
      portfolioCode || parent.portfolio_code,
      activityId || parent.activityId,
      programCode || parent.programCode,
      parent.parent
    )
  }

  return { status, financeCodeValue, financeCodeType, portfolioCode, activityId, programCode }
}

export default async (status, financeCodeValue, financeCodeType, portfolioCode, activityId, programCode, parentId) =>
  findInheritedDetailsForSingle(
    status,
    financeCodeValue,
    financeCodeType,
    portfolioCode,
    activityId,
    programCode,
    parentId
  )
