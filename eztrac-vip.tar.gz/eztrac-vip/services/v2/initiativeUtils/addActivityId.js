import findParent from './findParent'
import map from 'lodash/map'

const findActivityId = (initiatives, current, start = 0) => {
  const { activityId } = current
  if ( activityId || start > 10 ) {
    return { activityId }
  }
  const parent = findParent(initiatives, current)

  if ( parent ) {
    return findActivityId(initiatives, parent, start + 1)
  }

  return { activityId }
}

export default initiatives =>
  map(initiatives, i => ({
    ...i,
    ...findActivityId(initiatives, i),
  }))
