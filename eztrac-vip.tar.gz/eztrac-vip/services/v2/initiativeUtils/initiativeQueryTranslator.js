import getOrElse from 'lodash/get'
import includes from 'lodash/includes'

export const fieldsContains = (query, value) => {
  const fields = getOrElse(query, 'fields', [])

  return includes(fields, value)
}
const buildFields = query => {
  const baseFields = `i.initiative_id as id
  , i.initiative_name as "initiativeName"
  , i.status
  , i.finance_code_value as "financeCodeValue"
  , i.finance_code_type as "financeCodeType"
  , i.portfolio_code as "portfolioCode"
  , i.activity_id as "activityId"
  , i.is_allocable as "isAllocable"
  , i.type_id as "typeId"
  , i.is_inheritable as "isInheritable"
  , i.parent as "parentId"
  , i.program_code as "programCode"`

  const parentFields = fieldsContains(query, 'parent') || fieldsContains(query, 'fundingDetails')
    ? `, p.initiative_id as "parentId"
    , p.initiative_name as "parentName"
    , p.status as "parent_status"
    , p.program_code as "parent_program_code"
    , p.portfolio_code as "parent_portfolio_code"
    , p.activity_id as "parent_activity_id"`
    : ''

  const budgetFields = fieldsContains(query, 'budgets')
    ? `, ARRAY(
    SELECT ROW_TO_JSON(budgetRow)
    FROM (
      SELECT fiscal_year as "fiscalYear", amount
      FROM budget
      WHERE initiative_id = i.initiative_id
      ) as budgetRow
    ) as budgets`
    : ''

  const typeFields = fieldsContains(query, 'types')
    ? `, (SELECT value as "typeValue"
      FROM initiative_type
      WHERE id = i.type_id)`
    : ''

  const tagFields = fieldsContains(query, 'tags')
    ? `, ARRAY(
    SELECT ROW_TO_JSON(tagRow)
    FROM (
      SELECT tag_id as "tagId", tag_value as "tagValue"
      FROM initiative_tags
      WHERE initiative_id = i.initiative_id
    ) as tagRow
  ) as tags`
    : ''

  return `${baseFields}${parentFields}${budgetFields}${tagFields}${typeFields}`
}

const buildJoins = query => {
  const parentJoin = fieldsContains(query, 'parent') || fieldsContains(query, 'fundingDetails')
    ? ' LEFT JOIN initiative p ON p.initiative_id = i.parent'
    : ''

  return parentJoin
}

const buildByIdWhere = (query, params) => {
  if ( params.id ) {
    return ` WHERE i.initiative_id = '${params.id}'`
  }

  return ''
}

const buildByParentIdWhere = (query, params) => {
  if ( params.id ) {
    return ` WHERE i.parent = '${params.id}'`
  }

  return ''
}

const from = ' FROM initiative i'

const translator = query => `SELECT ${buildFields(query)}${from}${buildJoins(query)}`

export const getAllTranslator = ({ query }) =>
  `${translator(query)}`

export const getByIdTranslator = ({ query, params }) =>
  `${translator(query)}${buildByIdWhere(query, params)}`

export const getChildrenByIdTranslator = ({ query, params }) =>
  `${translator(query)}${buildByParentIdWhere(query, params)}`
