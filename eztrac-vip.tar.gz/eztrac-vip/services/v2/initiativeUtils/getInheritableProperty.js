import findParent from './findParent'
import isEmpty from 'lodash/isEmpty'

const getInheritableProperty = (initiatives, initiative, prop, parentProp) => {
  if ( initiative[prop] ) {
    return initiative[prop]
  }
  if ( initiative[parentProp] ) {
    return initiative[parentProp]
  }
  const parent = findParent(initiatives, initiative)
  if ( parent ) {
    if ( isEmpty(parent[prop]) ) {
      return getInheritableProperty(initiatives, parent, prop, parentProp)
    }

    return parent[prop]
  }

  return initiative[prop]
}

export default getInheritableProperty
