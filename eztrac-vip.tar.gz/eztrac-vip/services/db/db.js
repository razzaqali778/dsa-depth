import config from '../../config'
import crypto from 'crypto'

const dbConfig = config.get('ez-trac-vip-db')

const { Pool, Client } = require('pg')

const pool = process.env.NODE_ENV === 'test' ? undefined : new Pool(dbConfig)
const listenerClient =
  process.env.NODE_ENV === 'test' ? undefined : new Client(dbConfig)

const queryWithResults = (queryStr, params) =>
  pool.connect().then(client =>
    client
      .query(queryStr, params)
      .then(result => result.rows)
      .catch(error => {
        throw error
      })
      .finally(client.release())
  )

const queryWithOneResult = (queryStr, params) =>
  pool.connect().then(client =>
    client
      .query(queryStr, params)
      .then(result => result.rows[0])
      .catch(error => {
        throw error
      })
      .finally(client.release())
  )

const noop = () => null

function getLockKey(str) {
  const hash = crypto.createHash('sha256').update(str).digest('hex')

  // hash.slice(0, 15) is used to avoid getting number outside of the range of Postgres BigInt
  return BigInt(`0x${hash.slice(0, 15)}`)
}

const acquireLockForDocument = async doc => {
  const lockQuery = 'SELECT pg_try_advisory_lock($1)'
  const lockResult = await listenerClient.query(lockQuery, [
    getLockKey(doc.modified_by + doc.initiative_id),
  ])
  const lockAcquired = lockResult.rows[0].pg_try_advisory_lock

  return lockAcquired
}

const releaseLock = async doc => {
  const unlockQuery = 'SELECT pg_advisory_unlock($1)'
  await listenerClient.query(unlockQuery, [
    getLockKey(doc.modified_by + doc.initiative_id),
  ])
}

const client =
  process.env.NODE_ENV === 'test'
    ? {
      any: noop,
      one: noop,
      listenerClient: noop,
      acquireLockForDocument: noop,
      releaseLock: noop,
    }
    : {
      any: queryWithResults,
      one: queryWithOneResult,
      listenerClient,
      acquireLockForDocument,
      releaseLock,
    }

module.exports = client
