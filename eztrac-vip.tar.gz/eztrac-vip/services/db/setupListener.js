// This is the stuff that is using node-pg
import { listenerClient } from './db'
import handleAuditNotification from './handleAuditNotification'

export default async () => { // eslint-disable-line consistent-return
  if ( process.env.NODE_ENV !== 'test' ) {
    await listenerClient.connect()
    listenerClient.on('notification', handleAuditNotification)
    await listenerClient.query('LISTEN audits')
  }
}
