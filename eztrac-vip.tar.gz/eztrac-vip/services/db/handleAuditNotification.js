import {
  addTranslatedDoc,
  checkIfDocumentAlreadyAdded,
} from '../elastic/network'
import { translateAudit } from '../elastic/helpers'
import Moment from 'moment'
import client from './db'
import getOrElse from 'lodash/get'
import logger from '../util/logger'

const buildBudgetQuery = ({
  table_type: table,
  entity: { initiative_id: id, fiscal_year: year },
}) =>
  `SELECT * FROM audits WHERE table_type = '${table}' AND entity->>'initiative_id' = '${id}' AND entity->>'fiscal_year' = '${year}' ORDER BY modified_time desc limit 1 offset 1` // eslint-disable-line max-len

const buildInitiativeQuery = ({
  table_type: table,
  entity: { initiative_id: id },
}) =>
  `SELECT * FROM audits WHERE table_type = '${table}' AND entity->>'initiative_id' = '${id}' ORDER BY modified_time desc limit 1 offset 1` // eslint-disable-line max-len

const buildQuery = audit => {
  const { table_type: table } = audit

  if ( table === 'budget' ) {
    return buildBudgetQuery(audit)
  }

  return buildInitiativeQuery(audit)
}

const getTranslatedAudit = async data => {
  try {
    const payload = getOrElse(data, 'payload', '{}')
    const audit = JSON.parse(payload)
    const query = buildQuery(audit)
    const previous = await client.one(query)

    const audits = previous ? [ audit, previous ] : [ audit ]
    const translatedAudit = translateAudit(audits)(audit)
    const time = `${new Moment(translateAudit.modified_time)
      .utc()
      .format('YYYY-MM-DDTHH:mm:ss.SSS')}Z`

    const fixedTimeDoc = {
      ...translatedAudit,
      modified_time: time,
    }

    return fixedTimeDoc
  } catch ( error ) {
    logger.error(error)

    return error
  }
}

const handleNotification = async data => {
  const translatedAudit = await getTranslatedAudit(data)
  try {
    // acquire postgres advisory lock to make sure that two tasks won't be processing the same doc at the same time
    const lockAcquired = await client.acquireLockForDocument(translatedAudit)
    if ( !lockAcquired ) {
      logger.info('Lock not acquired, another task is processing the event')

      return
    }

    // check if second task created the same document in the last 2 seconds
    const documentAlreadyAdded = await checkIfDocumentAlreadyAdded(
      translatedAudit
    )
    if ( documentAlreadyAdded ) {
      logger.info('Document already added by another task')

      return
    }

    await addTranslatedDoc(translatedAudit)

    logger.info('Added audit document to elastic')
  } catch ( err ) {
    logger.error(err)
  } finally {
    await client.releaseLock(translatedAudit)
  }
}

export default handleNotification
