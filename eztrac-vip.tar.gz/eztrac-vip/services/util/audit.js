import filter from 'lodash/filter'
import findIndex from 'lodash/findIndex'
import orderBy from 'lodash/orderBy'


const getSingleAuditHistory = (auditList, audit) => {
  const {
    table_type: tableType,
    entity: { fiscal_year: fy, initiative_id: id },
  } = audit

  const filterFunc = tableType === 'budget'
    ? ({ table_type, entity: { initiative_id, fiscal_year } }) =>
      table_type === tableType && initiative_id === id && fiscal_year === fy // eslint-disable-line camelcase
    : ({ table_type, entity: { initiative_id } }) =>
      table_type === tableType && initiative_id === id // eslint-disable-line camelcase

  const allHistory = filter(auditList, filterFunc)

  return orderBy(allHistory, [ 'modified_time' ], [ 'desc' ])
}

export const findPreviousAudit = (auditList, currentAudit) => {
  const auditHistory = getSingleAuditHistory(auditList, currentAudit)

  const index = findIndex(auditHistory, currentAudit)

  return auditHistory.length === index ? undefined : auditHistory[index + 1]
}
