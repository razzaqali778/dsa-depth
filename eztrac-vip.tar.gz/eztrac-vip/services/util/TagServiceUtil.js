import forEach from 'lodash/forEach'

export const parseAncestralTags = (initiativeAncestralTags, initiativeId) => {
  const finalTags = []
  forEach(initiativeAncestralTags, tag => {
    if ( tag.tag_id && !finalTags.find(finalTag => finalTag.tag_id === tag.tag_id) ) {
      finalTags.push({
        initiative_id: initiativeId,
        tag_id: tag.tag_id,
        tag_value: tag.tag_value,
        level: tag.level,
      })
    }
  })

  return finalTags
}
