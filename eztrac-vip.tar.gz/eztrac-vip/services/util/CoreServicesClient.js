import AzureTokenUtil from './AzureTokenUtil'
import agent from '../agent'
import config from '../../config'

const { services: servicesUrls } = config.get('ez-trac-urls')

const getAllTimeFrames = async () => {
  const url = `${servicesUrls['ez-trac-core']}/v2/timeframes`
  const azureToken = await AzureTokenUtil.getAzureToken()

  const response = await agent.get(url, { Authorization: `Bearer ${azureToken}` })

  return response.body
}

export const CoreServicesClient = {
  getAllTimeFrames,
}
