import agent from '../agent'
import azureTokenUtil from './AzureTokenUtil'
import config from '../../config'

const messagingUrl = config.get('messaging-url')
const sendMessageUrl = `${messagingUrl}/v5/messages`
const createTaskUrl = `${messagingUrl}/v4/tasks`
const completeTaskUrl = `${messagingUrl}/v4/tasks/complete`


export const createTask = async task => {
  try {
    const azureToken = await azureTokenUtil.getAzureToken()
    const createdTask = await agent.post(createTaskUrl, task, { Authorization: `Bearer ${azureToken}` })

    return createdTask.body
  } catch ( error ) {
    throw error
  }
}
export const completeTask = async taskId => {
  try {
    const azureToken = await azureTokenUtil.getAzureToken()
    const completedTask = await agent.put(
      `${completeTaskUrl}/${taskId}`,
      {},
      { Authorization: `Bearer ${azureToken}` })

    return completedTask.body
  } catch ( error ) {
    throw error
  }
}
export const sendMessage = async message => {
  try {
    const azureToken = await azureTokenUtil.getAzureToken()
    const sentMessage = await agent.post(sendMessageUrl, message, { Authorization: `Bearer ${azureToken}` })

    return sentMessage.body
  } catch ( error ) {
    throw error
  }
}
