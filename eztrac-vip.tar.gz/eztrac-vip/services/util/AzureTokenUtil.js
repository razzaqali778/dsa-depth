import { httpGetToken } from '@monsantoit/oauth-azure'
import config from '../../config'

const { clientId, clientSecret } = config.get('vip-services-oauth-client')

const AzureTokenUtil = {
  getAzureToken: httpGetToken({ clientId, clientSecret }),
}

module.exports = AzureTokenUtil
