import { CoreServicesClient } from './CoreServicesClient'
import AJV from 'ajv'
import BudgetDao from '../dao/BudgetDao'
import first from 'lodash/first'
import map from 'lodash/map'
import tail from 'lodash/tail'

export const validateBudget = (budget, schema) => {
  const ajv = new AJV({ allErrors: true })
  const validate = ajv.compile(schema)
  const isValid = validate(budget)
  if ( !isValid ) {
    const errors = map(validate.errors, ({ message }) => {
      console.error('Error validating budget -- ', message) // eslint-disable-line no-console

      return message
    })
    throw { statusCode: 400, message: errors }; // eslint-disable-line
  }
}
export const createBudget = async budget => {
  // await validateBudget(budget, newBudgetSchema)
  const budgetData = await BudgetDao.createBudget(budget)

  return budgetData
}

export const updateBudget = async budget => {
  // await validateBudget(budget, updateBudgetSchema)
  const budgetData = await BudgetDao.updateBudget(budget)

  return budgetData
}

export const getFiscalYears = async () => {
  const timeframes = await CoreServicesClient.getAllTimeFrames()

  const activeTimeFrames = timeframes.filter(timeframe => timeframe.isActive)
  const groupedByYear = activeTimeFrames.reduce((acc, frame) => {
    const year = new Date(frame.startDate).getFullYear()

    const startDate = new Date(frame.startDate).getTime()
    const endDate = new Date(frame.endDate).getTime()

    if ( !acc[year] ) {
      acc[year] = { startDate, endDate }
    } else {
      acc[year].startDate = Math.min(acc[year].startDate, startDate)
      acc[year].endDate = Math.max(acc[year].endDate, endDate)
    }

    return acc
  }, {})

  const result = Object.entries(groupedByYear).map(
    ([ year, { startDate, endDate }]) => ({
      id: parseInt(year, 10),
      startDate: new Date(startDate),
      endDate: new Date(endDate),
      name: year,
    })
  )

  return result
}

export const getFiscalYearForDate = date => {
  const year = date.getFullYear()
  const month = date.getMonth()

  /* const fiscalYear = month < 8 ?
{
  id: year,
  startDate: new Date(year - 1, 8, 1),
  endDate: new Date(year, 7, 31),
  name: year.toString(),
} :
{
  id: year + 1,
  startDate: new Date(year, 8, 1),
  endDate: new Date(year + 1, 7, 31),
  name: (year + 1).toString(),
}
*/
  if ( year > 2018 ) {
    return {
      id: year,
      startDate: new Date(year, 0, 1, 0, 0, 0, 0),
      endDate: new Date(year, 11, 31, 23, 59, 59, 999),
      name: year.toString(),
    }
  } else if ( year === 2018 || (year === 2017 && month > 7) ) {
    return {
      id: 2018,
      startDate: new Date(2017, 8, 1, 0, 0, 0, 0),
      endDate: new Date(2018, 11, 31, 23, 59, 59, 999),
      name: year.toString(),
    }
  } else if ( month < 8 ) {
    return {
      id: year,
      startDate: new Date(year - 1, 8, 1, 0, 0, 0, 0),
      endDate: new Date(year, 7, 31, 23, 59, 59, 999),
      name: year.toString(),
    }
  }

  return {
    id: year + 1,
    startDate: new Date(year, 8, 1, 0, 0, 0, 0),
    endDate: new Date(year + 1, 7, 31, 23, 59, 59, 999),
    name: (year + 1).toString(),
  }
}

export const getChildrenForBudgets = (budgets, budgetsWithChildren) => {
  if ( budgets.length === 0 ) {
    return budgetsWithChildren
  }
  const budget = first(budgets)

  return BudgetDao.getBudgetChildren(budget.initiative_id, budget.fiscal_year)
    .then(result => {
      budget.children = result
      budgetsWithChildren.push(budget)

      return getChildrenForBudgets(tail(budgets), budgetsWithChildren)
    })
    .catch(error => {
      console.error(error) // eslint-disable-line no-console
      throw { statusCode: 500, message: 'Error calculating buget information' }
    })
}
