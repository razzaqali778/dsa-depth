import { constructHierarchy } from '../initiativeService'
import {
  createInitiative as daoCreateInitiative,
  updateInitiative as daoUpdateInitiative,
  getInitiativesByParent,
} from '../dao/initiativeDao'
import { v1 as uuid } from 'uuid'
import Ajv from 'ajv'
import filter from 'lodash/filter'
import find from 'lodash/find'
import flatten from 'lodash/flatten'
import initiativeSchema from '../schema/InitiativeSchema'
import isUndefined from 'lodash/isUndefined'
import map from 'lodash/map'
import newInitiativeSchema from '../schema/NewInitiative.schema'
import toUpper from 'lodash/toUpper'
import union from 'lodash/union'

export const checkInitiativeName = async (name, parent, id) => {
  try {
    const siblingInitiatives = await getInitiativesByParent(parent)
    const matchedInitiative = find(siblingInitiatives, initiative =>
      toUpper(initiative.initiative_name) === toUpper(name) && initiative.initiative_id !== id
    )

    return !!isUndefined(matchedInitiative)
  } catch ( error ) {
    console.error(`Error checking for duplicate Initiative Name: ${error}`) // eslint-disable-line no-console
    throw { message: 'Error checking for duplicate Initiative Name', statusCode: 500 }
  }
}

export const validateInitiative = async (initiative, schema) => {
  const ajv = new Ajv({ allErrors: true })
  const validate = ajv.compile(schema)
  const isValid = validate(initiative)
  if ( !isValid ) {
    throw { statusCode: 409, message: map(validate.errors, ({ message }) => message) }
  } else {
    const checkName = await checkInitiativeName(initiative.initiative_name,
      initiative.parent, initiative.initiative_id)
    if ( !checkName ) {
      throw {
        dataPath: '.initiative_name',
        params: '',
        message: 'This initiative name already exists',
        statusCode: 409,
      }
    }
  }
}

export const createInitiative = async initiative => {
  await validateInitiative(initiative, newInitiativeSchema)
  const newInitiative = { ...initiative, initiative_id: uuid() }
  await daoCreateInitiative(newInitiative)

  return initiative.id
}

export const updateInitiative = async initiative => {
  await validateInitiative(initiative, initiativeSchema)
  await daoUpdateInitiative(initiative)

  return initiative.id
}


export const constructInitiativeHierarchy = (parentId, allInitiatives) => {
  const initiativesWithParent = filter(allInitiatives, { parent: parentId })

  return map(initiativesWithParent, initiative =>
    ({ ...initiative, children: constructHierarchy(initiative.initiative_id, allInitiatives) })
  )
}

export const setFinancialAttributes = (allInitiatives, parentInitiative) => {
  const initiativesWithParent =
          filter(allInitiatives, { parent: parentInitiative.initiative_id })

  const newInitiativesList = map(initiativesWithParent, initiative => {
    const editInitiative = initiative
    if ( !initiative.parent || initiative.finance_code_value ) {
      editInitiative.funding_initiative_name = initiative.initiative_name
      editInitiative.funding_initiative_id = initiative.initiative_id
    } else {
      editInitiative.funding_initiative_name = parentInitiative.funding_initiative_name
      editInitiative.funding_initiative_id = parentInitiative.funding_initiative_id
      editInitiative.finance_code_type = parentInitiative.finance_code_type
      editInitiative.finance_code_value = parentInitiative.finance_code_value
    }

    return union([ initiative ], setFinancialAttributes(allInitiatives, initiative))
  })

  return flatten(newInitiativesList)
}

export const setBudgetParentAttribute = (allInitiatives, parentInitiative) => {
  const initiativesWithParent =
          filter(allInitiatives, { parent: parentInitiative.initiative_id })

  const newInitiativesList = map(initiativesWithParent, initiative => {
    const editInitiative = initiative
    if ( !initiative.parent || initiative.budgets.length > 0 ) {
      editInitiative.budget_parent_name = initiative.initiative_name
      editInitiative.budget_parent_id = initiative.initiative_id
    } else {
      editInitiative.budget_parent_name = parentInitiative.initiative_name
      editInitiative.budget_parent_id = parentInitiative.initiative_id
    }

    return union([ initiative ], setBudgetParentAttribute(allInitiatives, initiative))
  })

  return flatten(newInitiativesList)
}
