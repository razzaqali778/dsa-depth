import getOrElse from 'lodash/get'


export const extractUserId = req => {
  if ( process.env.NODE_ENV === 'production' ) {
    return getOrElse(req, 'headers["user-id"]', 'none')
  }

  return process.env.USER || 'none'
}

export const extractRequestData = req => ({
  userId: extractUserId(req),
  data: req && req.body,
})

export const extractUserEntitlements = req => {
  if ( process.env.NODE_ENV === 'production' ) {
    try {
      const userProfile = req.headers['user-profile']
      const entitlements = getOrElse(JSON.parse(userProfile), 'entitlements.vip', 'none')

      return entitlements
    } catch ( e ) { return 'none' }
  }

  return ''
}
export default { extractUserId, extractRequestData }
