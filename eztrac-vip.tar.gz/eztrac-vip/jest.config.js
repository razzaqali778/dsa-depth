module.exports = {
  setupFiles: [
    './test/shim.js',
    './test/enzyme-setup.js',
    './test/_jestsetup',
    './test/initConfig'
  ],
  roots: [
    './test',
    './services',
    './public',
  ],
  testRegex: '(/test/.*|(\\.|/)(test|spec))\\.jsx?$',
  transformIgnorePatterns: [
    'node_modules/.*',
  ],
  testPathIgnorePatterns: [
    './test/shim.js',
    './test/enzyme-setup.js',
    '.*_jestsetup.js',
    './test/initConfig.js',
    './test/envSetup.js',
    './test/test-utils',
    '.*json',
    '.eslintrc',
  ],
  collectCoverageFrom: [
    'services/**',
    'public/scripts/selectors/**',
    'public/scripts/util/**',
  ],
  coverageDirectory: '.jest-coverage',
  testEnvironment: 'jsdom',
  testEnvironmentOptions: {
    url: 'http://localhost',
  },
}
