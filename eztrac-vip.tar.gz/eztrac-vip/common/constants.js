module.exports = {
  CURRENCY_UNIT: 1000,
  INITIATIVE_TYPE_OPTIONS: {
    all: { id: 'all', label: 'All', active: false },
    topLevel: { id: 'topLevel', label: 'Top Level', active: true },
    children: { id: 'children', label: 'Children', active: false },
    fundingInitiative: { id: 'fundingInitiative', label: 'Funding Initiative', active: false },
  },
  FUNDING_STATUS_OPTIONS: {
    all: { id: 'all', label: 'All', active: false },
    funded: { id: 'funded', label: 'Funded', active: true },
    planning: { id: 'planning', label: 'Planning', active: true },
    completed: { id: 'completed', label: 'Completed', active: false },
  },
  INHERITED: '(inherited)',
}
