import { extractUserEntitlements } from './services/util/extractRequestData'
import includes from 'lodash/includes'
import logger from './services/util/logger'
import toUpper from 'lodash/toUpper'

const { createRedirectToRestrictedPageAction, createProfileMiddleware } = require('@monsantoit/profile-middleware')

// I don't think it is needed anymore, doesn't ocelot take care of whitelisting clients? Repo of this package is also archived
// RouteClientValidator.configure({ routes })

// const clientSecurityMiddleware = validator

const READ_ROLE = 'vip-read-user'
const READ_WRITE_ROLE = 'vip-read-write-user'

export const localDevProfile = {
  id: process.env.USER || 'local_user',
  entitlements: {
    vip: [ READ_ROLE, READ_WRITE_ROLE ],
  },
}

const unauthorizedRedirect =
  createRedirectToRestrictedPageAction(`ez-trac-vip&roles=${READ_ROLE} or ${READ_WRITE_ROLE}`)
const unauthorizedResponse = (req, res) =>
  res.status(403).json(`Not authorized to perform method ${req.method}`)
const unauthorizedAction = (req, res, next) => {
  if ( req.path.includes('services') ) {
    return unauthorizedResponse(req, res, next)
  }

  return unauthorizedRedirect(req, res, next)
}

const writeSecurityMiddleware = createProfileMiddleware({
  localDevProfile,
  entitlements: [ READ_WRITE_ROLE ],
  unauthorizedAction,
})

const readSecurityMiddleware = createProfileMiddleware({
  localDevProfile,
  entitlements: [ READ_ROLE, READ_WRITE_ROLE ],
  unauthorizedAction,
})

export const securityMiddleware = (req, res, next) => {
  if ( process.env.NODE_ENV === 'development' ) { return next() }
  const method = toUpper(req.method)
  const isWriteRequest = includes([ 'PUT', 'POST', 'DELETE', 'PATCH' ], method)
  const isReadRequest = method === 'GET'
  const hasEntitlements = extractUserEntitlements(req) !== 'none'
  const isRequestInitiative = includes(req.path, 'v2/request-initiative')

  if ( hasEntitlements && (isReadRequest || isRequestInitiative ) ) {
    logger.info('routing to read security middleware')

    return readSecurityMiddleware(req, res, next )
  }
  if ( hasEntitlements && isWriteRequest ) {
    logger.info('routing to write security middleware')

    return writeSecurityMiddleware(req, res, next)
  }
  if ( isReadRequest ) {
    return next()
  }

  return unauthorizedAction(req, res, next)
}

