
import { AppContainer } from 'react-hot-loader'
import React from 'react'
import ReactDOM from 'react-dom'
import RootContainer from './RootContainer'
import es6Promise from 'es6-promise'
import navbar from '@monsantoit/phoenix-navbar'

es6Promise.polyfill()

const render = Container => {
  console.log('rendering') // eslint-disable-line no-console
  const rootElement = (
    <AppContainer>
      <Container />
    </AppContainer>
  )
  ReactDOM.render(rootElement, document.querySelector('.contents'))
}

navbar.install({
  element: document.querySelector('.nav'),
  suiteId: 'P&E Administration', // get your suiteId and productId from
  productId: 'ez-trac', // http://devtools.monsanto.net/navigation
})
  .then(() => {
  // Once installed, auth token support will be enabled by the navbar.
  // Don't make any calls to remote services until this point.
    console.log('navbar installed') // eslint-disable-line no-console
    render(RootContainer)
  })
  .catch(err => {
    // Errors thrown as part of installation will likely be from invalid
    // auth tokens. Be sure to run a local ocelot instance to avoid this.
    console.error(err) // eslint-disable-line no-console
  })

if ( process.env.NODE_ENV !== 'production' ) {
  module.hot.accept()
}
