import { fetchInitiativeTagsMap } from '../util/tagUtil'
import { formatFinanceCodeTypes, formatInitiativeStatuses, formatInitiativeTypes } from './InitiativeUtil'
import { localVipServicesUrl } from '../../consts'
import agent from '../../agent'
import filter from 'lodash/filter'
import getOrElse from 'lodash/get'
import map from 'lodash/map'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)
const getInitiativeStatusUrl = `${vipApiUrl}/v1/referenceData/initiativeStatus`
const getFinanceCodeTypeUrl = `${vipApiUrl}/v1/referenceData/financialTagTypes`
// TODO use v2, rename snake case values to camel case
const getInitiativeTypesUrl = `${vipApiUrl}/v1/initiativeTypes`
const getInitiativesUrl = `${vipApiUrl}/v1/getAllInitiatives`
// const getInitiativesUrl = `${vipApiUrl}/v2/initiatives`

export const getDataForDashboard = async () => {
  try {
    const financeCodeTypeRequest = agent.get(getFinanceCodeTypeUrl)
    const initiativeStatusRequest = agent.get(getInitiativeStatusUrl)
    const initiativeTypesRequest = agent.get(getInitiativeTypesUrl)
    const initiativeRequest = agent.get(getInitiativesUrl)
    const tagsRequest = fetchInitiativeTagsMap()

    const financeCodeTypesResponse = await financeCodeTypeRequest
    const initiativeStatusResponse = await initiativeStatusRequest
    const initiativeResponse = await initiativeRequest
    const initiativeTypesResponse = await initiativeTypesRequest
    const tags = await tagsRequest


    const financeCodeTypes = formatFinanceCodeTypes(financeCodeTypesResponse.body)
    const initiativeStatuses = formatInitiativeStatuses(initiativeStatusResponse.body)
    const initiatives = map(initiativeResponse.body, initiative => ({
      ...initiative,
      tags: tags[initiative.initiative_id],
    }))
    const activeInitiativeTypes = formatInitiativeTypes(filter(initiativeTypesResponse.body, type => type.is_active))

    const initiativeTypes = formatInitiativeTypes(initiativeTypesResponse.body)

    return { financeCodeTypes, initiativeStatuses, initiatives, initiativeTypes, activeInitiativeTypes }
  } catch ( error ) {
    throw error
  }
}

export const getInitiatives = async () => {
  try {
    const initiativeRequest = agent.get(getInitiativesUrl)
    const tagsRequest = fetchInitiativeTagsMap()

    const initiativeResponse = await initiativeRequest
    const tags = await tagsRequest

    const initiatives = map(initiativeResponse.body, initiative => ({
      ...initiative,
      tags: tags[initiative.initiative_id],
    }))

    return initiatives
  } catch ( error ) {
    throw error
  }
}
