import { getFilters } from '../selectors/audit'
import Moment from 'moment'
import isArray from 'lodash/isArray'
import isUndefined from 'lodash/isUndefined'
import xor from 'lodash/xor'

const getVal = (filter, val) => {
  if ( filter === 'modified_time_max' ) { // datepicker returns a moment @ midnight, set it to 1 second before the day ends
    return new Moment(val).hour(23).minute(59).second(59)
  }

  return val
}
export const modifyFilters = async (state, newVal, filterName) => {
  const filters = getFilters(state)
  const previousValue = filters[filterName]
  const val = getVal(filterName, newVal)

  if ( !isUndefined(previousValue) ) {
    if ( isArray(previousValue) && !isArray(val) ) {
      const newArray = xor(previousValue, [ val ] )

      return { ...filters, ...{ [filterName]: newArray } }
    }

    return { ...filters, [filterName]: val }
  }

  return false
}
