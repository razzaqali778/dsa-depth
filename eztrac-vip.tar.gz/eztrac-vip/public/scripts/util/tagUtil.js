import { localVipServicesUrl } from '../../consts'
import agent from '../../agent'
import concat from 'lodash/concat'
import find from 'lodash/find'
import forEach from 'lodash/forEach'
import getOrElse from 'lodash/get'
import isEmpty from 'lodash/isEmpty'
import isNull from 'lodash/isNull'
import map from 'lodash/map'
import merge from 'lodash/merge'
import pickBy from 'lodash/pickBy'
import reduce from 'lodash/reduce'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

export const fetchAllInitiativeTags = async () => {
  const { body: tags } = await agent.get(`${vipApiUrl}/v1/tags/initiatives`)

  return tags
}

export const fetchAncestralTags = async initiativeId => {
  const { body: tags } = await agent.get(`${vipApiUrl}/v1/tags/inheritedtags?initiativeId=${initiativeId}`)

  return tags
}

export const fetchInitiativeTagsMap = async () => {
  const tags = await fetchAllInitiativeTags()

  return reduce(
    tags,
    (memo, { initiative_id: initiativeId, tag_id: tagId, tag_value: tagValue }) => {
      const o = { tagId, tagValue }

      memo[initiativeId] = memo[initiativeId] ? concat(memo[initiativeId], o) : [ o ] // eslint-disable-line no-param-reassign

      return memo
    },
    {}
  )
}
export const fetchTagNameMap = async () => {
  const { body: nameArray } = await agent.get(`${vipApiUrl}/v1/tags/names`)

  return reduce(
    nameArray,
    (nameMap, nameObject) => {
      nameMap[nameObject.tag_id] = nameObject.tag_name // eslint-disable-line no-param-reassign

      return nameMap
    },
    {}
  )
}

export const fetchTagOptions = async () => {
  const { body: tagsArray } = await agent.get(`${vipApiUrl}/v1/tags/options`)

  return reduce(
    tagsArray,
    (memo, { tag_id: tagId, tag_value: tagValue }) => {
      memo[tagId] = memo[tagId] ? concat(memo[tagId], tagValue) : [ tagValue ] // eslint-disable-line no-param-reassign

      return memo
    },
    {}
  )
}

export const fetchTagsByInitiative = async initiativeId => {
  const { body: tags } = await agent.get(`${vipApiUrl}/v1/tags/initiatives?initiativeId=${initiativeId}`)

  return reduce(
    tags,
    (memo, { tag_id: tagId, tag_value: tagValue, level }) => {
      memo[tagId] = { name: tagValue, inherited: level > 0 } // eslint-disable-line no-param-reassign

      return memo
    },
    {}
  )
}

export const saveTags = async (initiativeId, tags) => {
  map(tags, async (newValue, key) => {
    if ( newValue.name ) {
      const tagRequest = {
        initiativeId,
        tagId: key,
        tagValue: newValue.name,
      }
      try {
        await agent.put(`${vipApiUrl}/v1/tags/initiatives`, tagRequest)
      } catch ( error ) {
        throw error
      }
    } else {
      try {
        await agent.delete(`${vipApiUrl}/v1/tags/initiatives?initiativeId=${initiativeId}&tagId=${key}`)
      } catch ( error ) {
        throw error
      }
    }
  })
}

export const lowestAncestralValues = ancestralTags => {
  const lowestTags = {}
  forEach(ancestralTags, tag => {
    if (
      tag.level !== 0 &&
      tag.tag_id &&
      tag.tag_value &&
      !find(lowestTags, finalTag => finalTag.tag_id === tag.tag_id)
    ) {
      lowestTags[tag.tag_id] = {
        inherited: true,
        name: tag.tag_value,
      }
    }
  })

  return lowestTags
}

export const buildTagsToSend = (newTags, ancestralTags) => {
  const fullAncestorInfo = lowestAncestralValues(ancestralTags)
  const filteredNewTags = pickBy(newTags, tag => !isEmpty(tag) && !isNull(tag.name))
  const tagsToSend = merge(fullAncestorInfo, filteredNewTags)

  return tagsToSend
}
