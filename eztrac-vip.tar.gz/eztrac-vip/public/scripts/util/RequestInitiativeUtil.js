import { get as getOrElse, map } from 'lodash'
import { localVipServicesUrl } from '../../consts.js'
import agent from '../../agent.js'

const vipApiURL = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

const requestedInitiativesUrl = `${vipApiURL}/v2/request-initiative`
const getLimitedInitiativeUrl = `${vipApiURL}/v2/initiatives/get-limited-initiatives-and-parents`

export const makeLabels = (...items) =>
  map(items, item => ({ label: item, value: item }))

export const generateValueLabel = value => value ?
  { label: value, value } : null


export const getLimitedInitiativesAndParents = async () => {
  try {
    const result = await agent.get(getLimitedInitiativeUrl)

    return result.body
  } catch ( error ) {
    throw error
  }
}

export const sendRequestedInitiative = async requestedInitiatives =>

  agent.post(requestedInitiativesUrl, requestedInitiatives)

export const getRequestedInitiative = async requestedInitiativeId => {
  const { body } = await agent.get(`${vipApiURL}/v2/request-initiative/${requestedInitiativeId}`)

  return body
}
