import agent from '../../agent'
import filter from 'lodash/filter'
import getOrElse from 'lodash/get'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-core',
  'https://ez-trac-core-services.velocity-np.ag'
)

const communitiesUrl = `${vipApiUrl}/v2/communities?isActive=true`

export const getCommunityList = async () => {
  const { body } = await agent.get(communitiesUrl)

  return filter(body, [ 'isActive', true ])
}

