/* eslint-disable wyze/max-file-length */
import filter from 'lodash/filter'
import intersection from 'lodash/intersection'
import isEmpty from 'lodash/isEmpty'
import map from 'lodash/map'

export const getInitiativeTypeRules = (selectedType, initiative) => {
  switch ( selectedType.value ) {
    case 'EXP-INIT': {
      const ourInitiative = {
        ...initiative,
        finance_code_type: 'Cost Center',
        type_id: selectedType.value,
        type_name: selectedType.label,
        is_allocable: true,
        is_inheritable: true,
      }
      const rules = {
        allocationCheckboxDisabled: false,
        financeCodeTypeLabel: 'Cost Center',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: ourInitiative,
      }

      return rules
    }
    case 'CAP-PROJ': {
      const ourInitiative = {
        ...initiative,
        finance_code_type: 'SAP Project',
        type_id: selectedType.value,
        type_name: selectedType.label,
        is_allocable: false,
        is_inheritable: false,
      }
      const rules = {
        allocationCheckboxDisabled: true,
        financeCodeTypeLabel: 'SAP Project',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: true,
        initiative: ourInitiative,
      }

      return rules
    }
    case 'CAP-INIT':
    case 'CAP-EXP-INIT': {
      const ourInitiative = {
        ...initiative,
        finance_code_type: 'WBS Element',
        type_id: selectedType.value,
        type_name: selectedType.label,
        is_allocable: true,
        is_inheritable: true,
      }
      const rules = {
        allocationCheckboxDisabled: false,
        financeCodeTypeLabel: 'WBS Element',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: ourInitiative,
      }

      return rules
    }
    case 'ENH': {
      const ourInitiative = {
        ...initiative,
        finance_code_type: 'Cost Center',
        type_id: selectedType.value,
        type_name: selectedType.label,
        is_allocable: initiative.parent != null,
        is_inheritable: initiative.parent != null,
      }
      const rules = {
        allocationCheckboxDisabled: initiative.parent == null,
        financeCodeTypeLabel: 'Cost Center',
        hideFinanceCodeInput: initiative.parent == null,
        hideFinanceCodeInheritableCheckbox: initiative.parent == null,
        initiative: ourInitiative,
      }

      return rules
    }
    case 'FRESH':
    case 'SUP':
    case 'OPS': {
      const ourInitiative = {
        ...initiative,
        finance_code_type: 'Cost Center',
        type_id: selectedType.value,
        type_name: selectedType.label,
        is_allocable: true,
        is_inheritable: true,
      }
      const rules = {
        allocationCheckboxDisabled: !initiative.parent,
        financeCodeTypeLabel: 'Cost Center',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: ourInitiative,
      }

      return rules
    }
    default: {
      const ourInitiative = { ...initiative, finance_code_type: '' }
      const rules = {
        allocationCheckboxDisabled: false,
        financeCodeTypeLabel: 'Finance Code ',
        hideFinanceCodeInput: false,
        hideFinanceCodeInheritableCheckbox: false,
        initiative: ourInitiative,
      }

      return rules
    }
  }
}

export const determineChildTypes = (parentType, initiativeTypes) => {
  switch ( parentType ) {
    case 'CAP-PROJ':
    case 'CAP-INIT':
      return filter(
        initiativeTypes,
        type => type.value === 'CAP-INIT' || type.value === 'CAP-EXP-INIT'
      )
    case 'CAP-EXP-INIT':
      return filter(initiativeTypes, type => type.value === 'CAP-EXP-INIT')
    case 'EXP-INIT':
      return filter(initiativeTypes, type => type.value === 'EXP-INIT')
    case 'SUP':
      return filter(initiativeTypes, type => type.value === 'SUP')
    case 'FRESH':
      return filter(initiativeTypes, type => type.value === 'FRESH')
    case 'ENH':
      return filter(initiativeTypes, type => type.value === 'ENH')
    case 'OPS':
      return filter(initiativeTypes, type => type.value === 'OPS')
    case 'UNKNOWN':
      return []
    default:
      return []
  }
}

export const determineParentTypes = (currentType, initiativeTypes) => {
  switch ( currentType ) {
    case 'CAP-PROJ':
      return []
    case 'CAP-INIT':
      return filter(
        initiativeTypes,
        type => type.value === 'CAP-INIT' || type.value === 'CAP-PROJ'
      )
    case 'CAP-EXP-INIT':
      return filter(
        initiativeTypes,
        type =>
          type.value === 'CAP-EXP-INIT' ||
          type.value === 'CAP-INIT' ||
          type.value === 'CAP-PROJ'
      )
    case 'EXP-INIT':
      return filter(initiativeTypes, type => type.value === 'EXP-INIT')
    case 'SUP':
      return filter(initiativeTypes, type => type.value === 'SUP')
    case 'FRESH':
      return filter(initiativeTypes, type => type.value === 'FRESH')
    case 'ENH':
      return filter(initiativeTypes, type => type.value === 'ENH')
    case 'OPS':
      return filter(initiativeTypes, type => type.value === 'OPS')
    case 'UNKNOWN':
      return []
    default:
      return []
  }
}

export const determineEditTypes = (
  currentType,
  parentType,
  childrenInitiatives,
  initiativeTypes
) => {
  const typeOptions = !parentType
    ? filter(
      initiativeTypes,
      type => type.value === 'CAP-PROJ' || type.value === 'EXP-INIT'
    )
    : determineChildTypes(parentType, initiativeTypes)

  const children = filter(
    childrenInitiatives,
    child => child.type_id !== 'UNKNOWN'
  )
  if ( !isEmpty(children) ) {
    const parentOptions = map(children, child =>
      determineParentTypes(child.type_id, initiativeTypes)
    )

    const result = intersection(typeOptions, ...parentOptions)

    return result
  }

  return typeOptions
}
