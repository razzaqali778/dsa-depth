
import { queries, queryProfile } from '@monsantoit/profile-client'
import includes from 'lodash/includes'
import map from 'lodash/map'

const getUserEntitlements = async () => {
  try {
    const userProfile = await queryProfile(queries.currentUserWithEntitlements('vip'))
    const userEntitlements = userProfile ? userProfile.getCurrentUser.entitlements : []
    const entitlementsMap = map(userEntitlements, ({ code }) => code)

    return entitlementsMap
  } catch ( error ) {
    throw error
  }
}

const hasEitherRole = async () => {
  const userEntitlements = await getUserEntitlements()

  return includes(userEntitlements, 'vip-read-user') || includes(userEntitlements, 'vip-read-write-user')
}

const hasReadWriteRole = async () => {
  const userEntitlements = await getUserEntitlements()

  return includes(userEntitlements, 'vip-read-write-user')
}

export default { hasEitherRole, hasReadWriteRole }

