import { localVipServicesUrl } from '../../consts'
import agent from '../../agent'
import filter from 'lodash/filter'
import find from 'lodash/find'
import getOrElse from 'lodash/get'
import isNil from 'lodash/isNil'
import isNull from 'lodash/isNull'
import isUndefined from 'lodash/isUndefined'
import toUpper from 'lodash/toUpper'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

const getAllInitiativesUrl = `${vipApiUrl}/v1/getAllInitiatives`

const containsInvalidCharacters = name => {
  const lighterRegex = /^[a-zA-Z0-9\s()/\-+:.&]{1,44}$/

  return !lighterRegex.test(name)
}

const setMessage = (messageIsEmpty, hasInvalidCharacters, isDuplicate) => {
  if ( messageIsEmpty ) {
    return 'Initiative Name must be non-empty.'
  } else if ( hasInvalidCharacters ) {
    return `Only letters, numbers, spaces, and these special characters: ( ) / - + : . & [ ]
      are allowed. (Max: 44 Characters)`
  } else if ( isDuplicate ) {
    return 'This name already exists'
  }

  return ''
}

const nameIsDuplicate = (name, id, parent, initiativesForValidation) => {
  if ( initiativesForValidation.length === 0 ) {
    return false
  }
  const siblingInitiatives = filter(initiativesForValidation, initiative => {
    if ( isUndefined(parent) ) {
      return isNull(initiative.parent)
    }

    return initiative.parent === parent
  })
  const duplicate = find(
    siblingInitiatives,
    initiative => toUpper(initiative.initiative_name) === toUpper(name) && initiative.initiative_id !== id
  )

  return !isUndefined(duplicate)
}

export const isFieldEmpty = value => isUndefined(value) || isNull(value) || value.length === 0

export const getInitiatives = async () => {
  try {
    const result = await agent.get(getAllInitiativesUrl)

    return result.body
  } catch ( error ) {
    throw error
  }
}

export const validateName = (name, id, parent, initiatives) => {
  const isInitiativeNameEmpty = isUndefined(name) || name.trim().length === 0
  const hasInvalidCharacters = containsInvalidCharacters(name)
  const parentToFind = parent === 'None' ? null : parent
  const isDuplicate = nameIsDuplicate(name, id, parentToFind, initiatives)

  return {
    hasError: isInitiativeNameEmpty || hasInvalidCharacters || isDuplicate,
    message: setMessage(isInitiativeNameEmpty, hasInvalidCharacters, isDuplicate),
  }
}

export const validateStatus = (status, parent) => {
  if ( !isNil(parent) ) {
    return {
      hasError: false,
      message: '',
    }
  }
  const isStatusEmpty = isUndefined(status) || status.length === 0

  return {
    hasError: isStatusEmpty,
    message: isStatusEmpty ? 'Initiative Status must be selected.' : '',
  }
}

export const validateFinanceCodeValue = currentInitiative => {
  const error =
    isFieldEmpty(currentInitiative.finance_code_value) &&
    !currentInitiative.inherited_fin_code_value &&
    currentInitiative.is_allocable &&
    currentInitiative.status === 'Funded'

  return {
    hasError: error,
    message: error ? 'Finance Code Value must be entered.' : '',
  }
}

export const validType = initiativeType => {
  const isTypeEmpty = isUndefined(initiativeType) || initiativeType.length === 0

  return {
    hasError: isTypeEmpty,
    message: isTypeEmpty ? 'Initiative Type must be selected.' : '',
  }
}

export const validateAllFields = (initiative, initiatives) => {
  const errorsArray = []
  const validatedName = validateName(
    initiative.initiative_name,
    initiative.initiative_id,
    initiative.parent,
    initiatives
  ) // eslint-disable-line max-len
  const validatedStatus = validateStatus(initiative.status, initiative.parent)
  const validatedFinanceCodeValue = validateFinanceCodeValue(initiative)
  const validatedType = validType(initiative.type_id)

  if ( validatedName.hasError ) {
    errorsArray.push({ errorType: 'initiative_name', errorMessage: validatedName.message })
  }

  if ( validatedStatus.hasError ) {
    errorsArray.push({ errorType: 'status', errorMessage: validatedStatus.message })
  }

  if ( validatedFinanceCodeValue.hasError ) {
    errorsArray.push({ errorType: 'finance_code_value', errorMessage: validatedFinanceCodeValue.message })
  }

  if ( validatedType.hasError ) {
    errorsArray.push({ errorType: 'type_id', errorMessage: validatedType.message })
  }

  return errorsArray
}
