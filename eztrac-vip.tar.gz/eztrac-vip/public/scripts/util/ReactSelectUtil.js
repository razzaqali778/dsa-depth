import filter from 'lodash/filter'
import flatten from 'lodash/flatten'
import negate from 'lodash/negate'
import toLower from 'lodash/toLower'
import trim from 'lodash/trim'

const sortByMatchingFirst = (options, searchString) => {
  const forwardMatch = option => trim(toLower(option.label)).startsWith(trim(toLower(searchString)))
  const matchingOptions = filter(options, forwardMatch)
  const nonMatchingOptions = filter(options, negate(forwardMatch))
  const reorderedOptions = flatten([ matchingOptions, nonMatchingOptions ])

  return reorderedOptions
}

export { sortByMatchingFirst }
