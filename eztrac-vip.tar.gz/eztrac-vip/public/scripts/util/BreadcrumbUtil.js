import { localVipServicesUrl } from '../../consts'
import agent from '../../agent'
import getOrElse from 'lodash/get'
import sortBy from 'lodash/sortBy'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

const getInitiativeLineageUrl = `${vipApiUrl}/v1/getInitiativeLineage`
const sortLineage = lineage => sortBy(lineage, 'order').reverse()
export const getLineageForBreadcrumbs = async initiativeId => {
  try {
    const { body } = await agent.get(`${getInitiativeLineageUrl}/${initiativeId}`)

    return { hasError: false, breadcrumbs: sortLineage(body) }
  } catch ( error ) {
    return { hasError: true, message: error }
  }
}
