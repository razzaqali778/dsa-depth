import { filter, includes, some, toNumber } from 'lodash'

export const validateName = ({ name }) =>
  /^[a-zA-Z0-9\s()\-+:.&]{1,44}$/.test(name)

export const validateParentChildren = ({ name, parentId }, initiatives) => {
  const childInitiatives = filter(initiatives, initiative => initiative.parentId === parentId)

  return !some(childInitiatives, initiative => initiative.initiativeName === name)
}

export const validateType = ({ typeId }) =>
  includes([ 'CAP-PROJ', 'CAP-INIT', 'CAP-EXP-INIT', 'EXP-INIT', 'ENH', 'SUP', 'FRESH', 'OPS', 'FRESH' ], typeId)

export const validateStatus = ({ status }) =>
  includes([ 'Funded', 'Planning', 'Completed' ], status)

export const validateBudget = ({ budget }) =>
  /^\d*$/.test( toNumber( budget ) )

export const validateFiscalYear = ({ budget, fiscalYear }) =>
  !budget || /^[0-9]{4}$/.test( toNumber( fiscalYear ) )

// return true if we CAN submit to create
export const validateAllFormFields = (initiative, initiatives) =>
  !some([ validateName, validateType, validateStatus, validateBudget,
    validateFiscalYear, validateParentChildren ], validator => !validator(initiative, initiatives))

