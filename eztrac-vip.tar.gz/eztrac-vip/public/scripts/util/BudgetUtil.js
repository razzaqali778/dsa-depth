/* eslint-disable wyze/max-file-length */

import { CURRENCY_UNIT } from '../../../common/constants'
import { localVipServicesUrl } from '../../consts'
import agent from '../../agent'
import difference from 'lodash/difference'
import getOrElse from 'lodash/get'
import isUndefined from 'lodash/isUndefined'
import map from 'lodash/map'
import moment from 'moment'
import omit from 'lodash/omit'
import orderBy from 'lodash/orderBy'
import reduce from 'lodash/reduce'
import sumBy from 'lodash/sumBy'

const colors = [
  '#2196F3',
  '#9C27B0',
  '#009688',
  '#4CAF50',
  '#FFEB3B',
  '#FF9800',
]

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

export const getSumOfChildren = budget => sumBy(budget.children, 'amount')
const fetchBudgetSplitsUrl = `${vipApiUrl}/v2/budgets/splits`

export const formatAmount = amount =>
  amount.toLocaleString('en', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
    minimumFractionDigits: 0,
  })
export const applyCurrencyConversion = amount => {
  if ( amount === '' ) {
    return ''
  }

  return !isUndefined(amount) ? amount / CURRENCY_UNIT : 0
}
export const unapplyCurrencyConversion = amount =>
  !isUndefined(amount) ? amount * CURRENCY_UNIT : 0
export const orderBudgets = (budgetsToBeSorted, sortByAttribute, order) =>
  orderBy(
    budgetsToBeSorted,
    [ budget => budget[sortByAttribute].toLowerCase() ],
    order
  )
export const getFiscalYears = budgets => {
  const usedYears = map(budgets, budget => budget.fiscalYear)
  const currentDate = moment()
  const firstYear = currentDate.year()
  // currentDate.month() > 7 ? currentDate.year() + 1 : currentDate.year()

  const years = [
    firstYear.toString(),
    (firstYear + 1).toString(),
    (firstYear + 2).toString(),
  ]
  const yearsToUse = difference(years, usedYears)

  return map(yearsToUse, fiscalYear => ({
    value: fiscalYear,
    label: fiscalYear,
    id: 'fiscalYear',
  }))
}
export const formatInitiativesForSelect = initiativesForSelect =>
  map(initiativesForSelect, initiative => ({
    value: initiative.initiative_id,
    label: initiative.name,
    id: 'initiative_id',
  }))
export const formatChildrenForChart = budget => {
  const total = sumBy(budget.children, 'amount')
  let slices = map(budget.children, (child, index) => {
    child.fill = colors[index] // eslint-disable-line no-param-reassign

    return { color: colors[index] || '#795548', value: child.amount }
  })

  if ( total < budget.amount ) {
    slices.push({ color: '#BDBDBD', value: budget.amount - total })
  } else if ( total > budget.amount ) {
    slices = [{ color: '#F44336', value: 1 }]
  }

  return slices
}

const hashCode = str => {
  let hash = 0

  for ( let i = 0; i < str.length; i += 1 ) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash) // eslint-disable-line no-bitwise
  }

  return hash
}

const intToRGB = i => {
  const c = (i & 0x00ffffff) // eslint-disable-line no-bitwise
    .toString(16)
    .toUpperCase()

  return '00000'.substring(0, 6 - c.length) + c
}

const stringToRGB = str => {
  const hashed = hashCode(str)

  return `#${intToRGB(hashed)}`
}

const trimName = name => name.replace(/ (?:[c|C]ommunity)+$/, '')
const makeColorsFromCommunityList = communityList => {
  const defaultColor = '#795548'
  const list = reduce(
    communityList,
    (memo, { id, name }) => {
      // memo[id] = '#2196F3' // eslint-disable-line no-param-reassign
      memo[id] = { color: stringToRGB(id), name: trimName(name) } // eslint-disable-line no-param-reassign

      return memo
    },
    {}
  )

  const colorList = {
    default: defaultColor,
    COMMUNITY: { ...list, default: defaultColor },
  }

  return colorList
}

export const makePieChartSlicesBySplits = (budget, communityList) => {
  const colorList = makeColorsFromCommunityList(communityList)

  const { splits } = budget
  if ( splits.length === 0 ) {
    return [
      {
        value: 100,
        color: colorList.default,
      },
    ]
  }

  const datasets = [
    {
      label: 'Budget Split',
      data: map(splits, ({ amount }) => amount),
      backgroundColor: map(splits, ({ splitField, splitValue }) =>
        getOrElse(colorList, `${splitField}.${splitValue}.color`, '')
      ),
    },
  ]

  const labels = map(splits, ({ splitField, splitValue }) =>
    getOrElse(colorList, `${splitField}.${splitValue}.name`, '')
  )

  return { datasets, labels }
}

export const createBudget = async budget => {
  const createBudgetUrl = `${vipApiUrl}/v2/budgets`

  try {
    return agent.post(createBudgetUrl, budget)
  } catch ( error ) {
    throw error
  }
}

export const updateBudget = async budget => {
  const updateBudgetUrl = `${vipApiUrl}/v2/budgets`
  try {
    return agent.put(
      updateBudgetUrl,
      omit(budget, [ 'children', 'initiativeName' ])
    )
  } catch ( error ) {
    throw error
  }
}

export const fetchBudgetSplitsById = async budgetId => {
  try {
    const { body: splits } = await agent.get(
      `${fetchBudgetSplitsUrl}/${budgetId}`
    )

    return splits
  } catch ( err ) {
    console.log(`Error fetching budget splits -- ${err}`)// eslint-disable-line no-console

    return err
  }
}

export const deleteBudgetSplitsByBudgetId = async budgetId => {
  try {
    return agent.delete(`${fetchBudgetSplitsUrl}/${budgetId}`)
  } catch ( err ) {
    console.log(`Error deleting splits by id ${budgetId} -- ${err}`)// eslint-disable-line no-console

    return err
  }
}
export const getParentBudgets = async initiativeId => {
  try {
    const { body: parentBudget } = await agent.get(
      `${vipApiUrl}/v2/budgets/${initiativeId}/parent`
    )

    return parentBudget
  } catch ( err ) {
    console.log('Error encountered whilst retrieving parent budget', err)// eslint-disable-line no-console

    return err
  }
}
