import { localVipServicesUrl } from '../../consts'
import agent from '../../agent'
import getOrElse from 'lodash/get'


const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

const coreApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-core',
  localVipServicesUrl
)

const getAllTimeFramesUrl = `${coreApiUrl}/v2/timeframes`
const getFiscalYearsUrl = `${vipApiUrl}/v1/getAllFiscalYears/`

const fetchWithCatch = async function f(url) {
  try {
    const result = await agent.get(url)

    return result.body
  } catch ( error ) {
    console.error(error) // eslint-disable-line no-console

    return []
  }
}

export const getAllTimeFrames = () => fetchWithCatch(getAllTimeFramesUrl)
export const getFiscalYears = () => fetchWithCatch(getFiscalYearsUrl)
