

const PersistentStorageUtil = {

  persistentStore: {},

  addField: (keyName, fieldValue) => {
    PersistentStorageUtil.persistentStore[keyName] = fieldValue
  },
  getField: keyName => PersistentStorageUtil.persistentStore[keyName],
}

module.exports = PersistentStorageUtil
