export const formatDateToday = () => {
  const today = new Date()
  const formattedDate = new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
  }).format(today)

  return `${formattedDate}`
}
