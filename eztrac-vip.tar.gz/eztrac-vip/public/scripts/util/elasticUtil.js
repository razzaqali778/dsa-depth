import { localVipServicesUrl } from '../../consts'
import agent from '../../agent'
import getOrElse from 'lodash/get'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)
export const callElasticSearch = async queryString => {
  try {
    const queryUrl = `${vipApiUrl}/v1/audits/${queryString}`

    const response = await agent.get(queryUrl)

    return response.body
  } catch ( error ) {
    console.error(error) // eslint-disable-line no-console

    return false
  }
}
