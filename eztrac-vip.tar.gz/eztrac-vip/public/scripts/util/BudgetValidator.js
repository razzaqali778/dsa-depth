import isFinite from 'lodash/isFinite'
import isUndefined from 'lodash/isUndefined'
import toNumber from 'lodash/toNumber'
import toString from 'lodash/toString'

const camelToReadable = field => {
  const result = field.replace(/([a-z\d])([A-Z])/g, '$1 $2')

  return (result.charAt(0).toUpperCase() + result.slice(1)).replace(
    new RegExp('_', 'g'),
    ' '
  )
}

const validateAgainstParent = (amount, parentBudget, fiscalYear) => {
  const yearBudget = parentBudget.find(
    budget => budget.fiscalYear === fiscalYear
  )
  if ( yearBudget && amount > yearBudget.amount ) {
    return true
  }

  return false
}

const setMessage = (
  field,
  isEmpty,
  isNotNum,
  isNonPos,
  isFraction,
  isGreaterThanParent
) => {
  if ( isEmpty ) {
    return `${camelToReadable(field)} is required`
  } else if ( isNotNum ) {
    return `${camelToReadable(field)} must be a number`
  } else if ( isNonPos ) {
    return `${camelToReadable(field)} must be a positive number`
  } else if ( isFraction ) {
    return `${camelToReadable(field)} must be a whole number`
  } else if ( isGreaterThanParent ) {
    return `${camelToReadable(field)} cannot exceed parent budget`
  }

  return ''
}

const BudgetValidator = {
  validateAmount: (amount, parentBudgets, fiscalYear) => {
    const isEmpty = isUndefined(amount) || toString(amount).trim().length === 0
    const isNotNum = !isFinite(toNumber(amount))
    const isNonPos = toNumber(amount) < 0
    const isFraction = !Number.isInteger(toNumber(amount))
    const isGreaterThanParent = parentBudgets
      ? validateAgainstParent(amount, parentBudgets, fiscalYear)
      : false

    return {
      hasError:
        isEmpty || isNotNum || isNonPos || isFraction || isGreaterThanParent,
      message: setMessage(
        'amount',
        isEmpty,
        isNotNum,
        isNonPos,
        isFraction,
        isGreaterThanParent
      ),
    }
  },
  validateSelect: (value, field) => {
    const isEmpty = isUndefined(value) || value.trim().length === 0

    return {
      hasError: isEmpty,
      message: setMessage(field, isEmpty),
    }
  },
}

module.exports = BudgetValidator
