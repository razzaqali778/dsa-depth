import { get } from '../../agent'
import { localVipServicesUrl } from '../../consts'
import getOrElse from 'lodash/get'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

export const fetchInitiatives = async () => {
  const { body: initiatives } = await get(`${vipApiUrl}/v2/initiatives`)

  return initiatives
}

export const fetchDescendants = async initiativeId => {
  const { body: descendants } = await get(`${vipApiUrl}/v2/initiative/${initiativeId}/descendants`)

  return descendants
}
