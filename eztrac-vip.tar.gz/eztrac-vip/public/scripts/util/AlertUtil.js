const AlertUtil = {
  setAlert: (component, type, messageText) => {
    const alertType = type === 'error' ? 'danger' : type
    const timeoutTime = type === 'error' ? null : 3000
    const newAlert = {
      id: (new Date()).getTime(),
      type: alertType,
      message: messageText,
      timeout: timeoutTime,
    }
    component.setState({ alerts: [ ...component.state.alerts, newAlert ] })
  },
}

module.exports = AlertUtil
