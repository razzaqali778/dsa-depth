import { appBaseUrl, localVipServicesUrl } from '../../consts'
import agent from '../../agent'
import getOrElse from 'lodash/get'
import map from 'lodash/map'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

const velocityUrl = window.phoenix.serviceBindings['phoenix-home']

export const getFiscalYears = async () => {
  try {
    const getFiscalYearsUrl = `${vipApiUrl}/getAllFiscalYears`
    const { body: fiscalYears } = await agent.get(getFiscalYearsUrl)
    const yearIds = map(fiscalYears, year => year.id )

    return yearIds
  } catch ( error ) {
    console.error(error) // eslint-disable-line no-console
    throw error
  }
}

export const getProfileLink = userId => {
  const url = `http://${velocityUrl}/profile/users/${userId}`

  return url
}
export const getInitiativeLink = initId => {
  const url = `${appBaseUrl}/initiative/${initId}`

  return url
}
