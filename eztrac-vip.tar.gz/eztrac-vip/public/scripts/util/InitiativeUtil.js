import { isFieldEmpty } from './InitiativeValidator'
import { localVipServicesUrl } from '../../consts'
import agent from '../../agent'
import concat from 'lodash/concat'
import filter from 'lodash/filter'
import find from 'lodash/find'
import getOrElse from 'lodash/get'
import getValues from 'lodash/values'
import hasProperty from 'lodash/has'
import includes from 'lodash/includes'
import isArray from 'lodash/isArray'
import isEmpty from 'lodash/isEmpty'
import isUndefined from 'lodash/isUndefined'
import map from 'lodash/map'
import orderBy from 'lodash/orderBy'
import pickBy from 'lodash/pickBy'
import reduce from 'lodash/reduce'
import reject from 'lodash/reject'
import some from 'lodash/some'
import sortBy from 'lodash/sortBy'
import toUpper from 'lodash/toUpper'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

const initiativeUrl = `${vipApiUrl}/v1/initiatives`

const filterInitiativesBySearchText = (text, initiatives) => {
  if ( isUndefined(text) || text.length === 0 ) {
    return initiatives
  }

  const searchText = text.toLowerCase()

  return filter(initiatives, initiative => {
    const values = getValues(initiative)
    const foundValue = find(values, value => {
      if ( value ) {
        if ( isArray(value) && hasProperty(value[0], 'tagValue') ) {
          const tagValueList = map(value, tag => tag.tagValue ? tag.tagValue.toLowerCase() : '')

          return includes(tagValueList.join(' '), searchText)
        }

        return includes(value.toString().toLowerCase(), searchText)
      }

      return false
    })

    return !isUndefined(foundValue)
  })
}
const filterInitiativesByInitiativeCategory = (filteredInitiatives, initiativeCategoryFilterOption) => {
  if ( initiativeCategoryFilterOption === 'topLevel' ) {
    return filter(filteredInitiatives, { parent: null })
  } else if ( initiativeCategoryFilterOption === 'children' ) {
    return reject(filteredInitiatives, { parent: null })
  } else if ( initiativeCategoryFilterOption === 'fundingInitiative' ) {
    return reject(filteredInitiatives, { finance_code_value: null })
  }

  return filteredInitiatives
}

const filterInitiativesByFundingStatus = (filteredInitiatives, fundingStatusFilterOptions) => {
  if ( !fundingStatusFilterOptions.all.active ) {
    const statusesToInclude = pickBy(fundingStatusFilterOptions, filterOption => filterOption.active)

    return reduce(statusesToInclude,
      (memo, status) => concat(memo, filter(filteredInitiatives, initiative => {
        if ( initiative.status ) {
          return toUpper(initiative.status) === toUpper(status.label)
        }

        return toUpper(initiative.inherited_status) === toUpper(status.label)
      }
      )),
      []
    )
  }

  return filteredInitiatives
}

const filterInitiativesByType = (filteredInitiatives, initiativeTypeFilterOption) => {
  if ( initiativeTypeFilterOption ) {
    const filteredInits = filter(filteredInitiatives, initiative => // es-lint-disable-arrow-body-style
      initiative.type_id === initiativeTypeFilterOption
    )

    return filteredInits
  }

  return filteredInitiatives
}

export const orderInitiatives = (initiativesToBeSorted, sortByAttribute, order = 'asc') => orderBy(
  initiativesToBeSorted,
  initiative => initiative[sortByAttribute].toLowerCase().trim(),
  order
)
export const formatInitiativeStatuses = statuses =>
  isUndefined(statuses)
    ? []
    : reduce(statuses, (memo, { initiative_status_value: val }) =>
      concat(memo, { value: val, label: val }), [])

export const formatInitiativeTypes = initiativeTypes =>
  map(initiativeTypes, ({ id: type_id, value: val }) => ({ value: type_id, label: val }))

export const formatFinanceCodeTypes = financeCodeTypes =>
  isUndefined(financeCodeTypes)
    ? []
    : reduce(financeCodeTypes,
      (memo, { financial_tag_type_value: val }) => concat(memo, { value: val, label: val }),
      [])

export const filterInitiatives = (initiatives, searchText, initiativeTypeFilterOption, fundingStatusFilterOptions) => {
  if ( isUndefined(initiatives) || isEmpty(initiatives) ) {
    return []
  }

  let filteredInitiatives = filterInitiativesBySearchText(searchText, initiatives)
  if ( initiativeTypeFilterOption ) {
    filteredInitiatives = filterInitiativesByInitiativeCategory(filteredInitiatives, initiativeTypeFilterOption)
  }

  if ( !fundingStatusFilterOptions.all.active ) {
    filteredInitiatives = filterInitiativesByFundingStatus(filteredInitiatives, fundingStatusFilterOptions)
  }

  return filteredInitiatives
}

export const narrowInitiatives = (initiatives, searchText, initiativeCategoryOptions,
  fundingStatusOptions, initiativeTypeOption) => {
  if ( isUndefined(initiatives) || isEmpty(initiatives) ) {
    return []
  }

  const searchFiltered = filterInitiativesBySearchText(searchText, initiatives)
  const initiativeCategory = find(initiativeCategoryOptions, { active: true })
  const categoryFiltered = filterInitiativesByInitiativeCategory(searchFiltered, initiativeCategory.id)
  const statusFiltered = filterInitiativesByFundingStatus(categoryFiltered, fundingStatusOptions)
  const typeFiltered = filterInitiativesByType(statusFiltered, initiativeTypeOption)

  return orderInitiatives(typeFiltered, 'initiative_name')
}
export const getInitiativeNames = async () => {
  const response = await agent.get(`${initiativeUrl}?fields=id,name`)

  return response.body
}

export const patchInitiative = async (initiativeId, newFields) => {
  const { body: responseId } = await agent.patch(`${initiativeUrl}/${initiativeId}`, newFields)

  return responseId
}

export const getInheritableAncestors = (lineage, initiatives, isInEditMode) => {
  const relevantLineage = isInEditMode ? reject(lineage, initiative => initiative.order === 0) : lineage
  const lineageIds = map(relevantLineage, 'id')

  const ancestors = filter(initiatives,
    initiative => includes(lineageIds, initiative.initiative_id) && initiative.is_inheritable )

  return reject(ancestors, initiative => isFieldEmpty(initiative.finance_code_value))
}
export const getInheritedFinanceCodeValue = (lineage, initiatives, isInEditMode) => {
  const ancestors = getInheritableAncestors(lineage, initiatives, isInEditMode)
  const ancestorIds = map(ancestors, 'initiative_id')

  const relevantLineage = sortBy(filter(lineage,
    member => includes(ancestorIds, member.id)), 'order').shift()
  const relevantAncestor = find(ancestors, ancestor => ancestor.initiative_id === relevantLineage.id)

  return relevantAncestor ? relevantAncestor.finance_code_value : null
}
export const initiativeIsLeaf = (initiativeId, initiatives) =>
  !some(initiatives, initiative => initiative.parent === initiativeId)
