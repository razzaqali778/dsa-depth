export const getLoadingCount = state => state.loadingCount
