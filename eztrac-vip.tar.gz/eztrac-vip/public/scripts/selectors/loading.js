import { createSelector } from 'reselect'
import { getLoadingCount } from './index'

export const isLoading = createSelector(getLoadingCount, loadingCount => loadingCount > 0 )
