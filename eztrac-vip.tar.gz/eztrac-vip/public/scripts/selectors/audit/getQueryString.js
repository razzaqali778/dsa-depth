import { createSelector } from 'reselect'
import { getFilters } from './'
import Moment from 'moment'
import flow from 'lodash/flow'
import isArray from 'lodash/isArray'
import isEmpty from 'lodash/isEmpty'
import isNull from 'lodash/isNull'
import keys from 'lodash/fp/keys'
import reduce from 'lodash/fp/reduce'
import trimEnd from 'lodash/trimEnd'

const isEmptyArray = arr => isArray(arr) && isEmpty(arr)

const selector = createSelector(getFilters, filters =>
  flow(
    keys,
    reduce((memo, key) => {
      const val = filters[key]

      if ( isEmptyArray(val) || isNull(val) ) {
        return memo
      }

      if ( (key === 'amount_min' || key === 'amount_max') && isNaN(filters[key]) ) {
        return memo
      }

      if ( key.includes('modified_time') ) {
        const timestamp = new Moment(val).format('x')

        return `${memo}${key}=${encodeURIComponent(timestamp)}&`
      }

      return `${memo}${key}=${encodeURIComponent(val.toString())}&`
    }, '?'),
    str => trimEnd(str, '&')
  )(filters)
)

export default selector
