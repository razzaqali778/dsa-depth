import { createSelector } from 'reselect'
import { getFilters } from './'

export const validateBudgetMin = createSelector(getFilters, filters => !isNaN(filters.amount_min))
export const validateBudgetMax = createSelector(getFilters, filters => !isNaN(filters.amount_max))
