import { createSelector } from 'reselect'
import filter from 'lodash/fp/filter'
import flow from 'lodash/flow'
import getOrElse from 'lodash/get'
import includes from 'lodash/includes'
import map from 'lodash/fp/map'
import mapper from 'lodash/map'
import sortBy from 'lodash/sortBy'

const getInitiatives = state => state.initiatives
const getTypeId = state => state.formFields.typeId
const getCapProjRadio = state => state.formFields.capProjRadio

const possibleParentTypes = {
  'CAP-PROJ': [],
  'CAP-INIT': [ 'CAP-INIT', 'CAP-PROJ' ],
  'CAP-EXP-INIT': [ 'CAP-INIT', 'CAP-EXP-INIT', 'CAP-PROJ' ],
  'EXP-INIT': [ 'EXP-INIT' ],
  SUP: [ 'SUP' ],
  FRESH: [ 'FRESH' ],
  ENH: [ 'ENH' ],
  OPS: [ 'OPS' ],
  UNKNOWN: [],
}

const determineParentTypes = (currentType, capProjRadio) =>
  getOrElse(possibleParentTypes, currentType, capProjRadio ?
    ([ 'CAP-PROJ', 'CAP-INIT', 'CAP-EXP-INIT' ]) : ([ 'EXP-INIT', 'SUP', 'FRESH', 'ENH', 'OPS' ]))

export default createSelector(
  getInitiatives,
  getTypeId,
  getCapProjRadio,
  (initiatives, thisTypeId, capProjRadio) => {
    const relevantTypes = mapper(determineParentTypes(thisTypeId, capProjRadio))
    const list = flow(
      filter(({ typeId } ) => (includes(relevantTypes, typeId))),
      map(initiative => {
        const label = initiative.parent ?
          `${initiative.initiativeName} [${initiative.parentName}]` :
          `${initiative.initiativeName}`

        return { value: initiative.id, label }
      })
    )(initiatives)

    return sortBy([ ...list ], 'label')
  })
