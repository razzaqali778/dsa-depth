import { createSelector } from 'reselect'
import find from 'lodash/find'
import reduce from 'lodash/reduce'
import toInteger from 'lodash/toInteger'

const getBudgetAmount = state => toInteger(state.budget.amount)
const getBudgetSplits = state => state.budgetSplits

const numToString = num => toInteger(num).toLocaleString(undefined, { minimumFractionDigits: 0 })
export default createSelector(
  getBudgetAmount, getBudgetSplits,
  (amount, budgetSplits) => {
    if ( budgetSplits.length === 0 ) { return { valid: true } }
    if ( find(budgetSplits, split => (split.amount < 0)) ) {
      return { valid: false, message: 'Split amount cannot be a negative number' }
    }
    const total = reduce(budgetSplits, (tot, { amount: splitAmount }) => tot + splitAmount, 0)
    const valid = total === amount
    const message = valid ? '' : `Splits must total $${numToString(amount)} -- currently $${numToString(total)}`

    return { valid, message }
  }
)
