import { createSelector } from 'reselect'
import filter from 'lodash/filter'
import findIndex from 'lodash/findIndex'
import map from 'lodash/map'

const getBudgetSplits = state => state.budgetSplits

export default createSelector(
  getBudgetSplits,
  budgetSplits => {
    const splitErrors = map(budgetSplits, (split, index) => {
      if ( !split.splitValue ) {
        return { err: 'Community must be chosen', index }
      }

      const repeatedIndex = findIndex(budgetSplits, (s, i) => s.splitValue === split.splitValue && i !== index)

      if ( repeatedIndex !== -1 ) {
        return { err: 'Same community can not be chosen multiple times', index }
      }

      return null
    })

    return filter(splitErrors, d => d)
  }
)
