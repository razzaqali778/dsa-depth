/* eslint-disable no-mixed-operators, camelcase */
// TODO move to api v2
import { createSelector } from 'reselect'
import filter from 'lodash/fp/filter'
import find from 'lodash/find'
import flow from 'lodash/flow'
import map from 'lodash/fp/map'
import sortBy from 'lodash/sortBy'


const getInitiatives = state => state.initiatives
const getDescendants = state => state.descendants
const getId = state => state.id
const getCurrentInitiativeFinanceCodeValue = state => state.financeCodeValue
const getHasParent = state => state.hasParent

export default createSelector(
  getInitiatives,
  getDescendants,
  getId,
  getCurrentInitiativeFinanceCodeValue,
  getHasParent,
  (initiatives, descendants, thisId, thisFinanceCodeValue, hasParent) => {
    const none = { label: '(No Parent)', value: 'null' }
    const list = flow(
      filter(initiative => {
        const { initiative_id, finance_code_value, is_inheritable } = initiative

        return (
          initiative_id !== thisId
          && initiative.type_id !== 'UNKNOWN'
          && !find(descendants, ({ id: descendantId }) => descendantId === initiative_id)
          && (thisFinanceCodeValue === null ? (finance_code_value && is_inheritable) : true)
        )
      }),
      map(initiative => {
        const label = initiative.parent ?
          `${initiative.initiative_name} [${initiative.parent_name}]` :
          `${initiative.initiative_name}`

        return { value: initiative, label }
      })
    )(initiatives)
    if ( hasParent ) {
      return sortBy([ ...list ], 'label')
    }

    return sortBy([ none, ...list ], 'label')
  })
