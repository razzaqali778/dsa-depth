import React from 'react'
import shouldPureComponentUpdate from 'react-pure-render/function'

class SearchComponent extends React.Component {
  constructor(props) {
    super(props)
    this.timer = null
    this.state = {
      searchText: props.searchText,
    }
  }

  componentWillReceiveProps(nextProps) {
    this.setState({ searchText: nextProps.searchText })
  }

  shouldComponentUpdate = shouldPureComponentUpdate

  search = event => {
    clearTimeout(this.timer)
    this.setState({ searchText: event.target.value })
    this.timer = setTimeout(() => { this.props.searchAction(this.state.searchText) }, 500)
  }

  render() {
    return (
      <div className="filter-search-options col-md-3">
        <label htmlFor="Search">Search: </label>
        <div className="input-group search">
          <div className="input-group-addon">
            <span aria-hidden="true" className="glyphicon glyphicon-search" />
          </div>
          <input
            className="form-control"
            id="searchBox"
            onChange={this.search}
            placeholder="Search..."
            type="search"
            value={this.state.searchText}
          />
        </div>
      </div>
    )
  }
}

export default SearchComponent
