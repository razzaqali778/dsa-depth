import React from 'react'

const RootComponent = ({ children }) =>
  (<div style={{ marginTop: '-75px' }}>
    {children}
  </div>)

RootComponent.displayName = 'RootComponent'

export default RootComponent
