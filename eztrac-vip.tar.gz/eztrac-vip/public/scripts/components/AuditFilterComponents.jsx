import {
  Checkbox,
  ControlLabel,
  FormControl,
  FormGroup,
  Nav,
  NavItem,
} from 'react-bootstrap'
import { validateBudgetMax, validateBudgetMin } from '../selectors/audit/validateBudget'
import DatePicker from 'react-datepicker'
import React from 'react'
import Select from 'react-select'
import find from 'lodash/find'
import map from 'lodash/map'
import upperFirst from 'lodash/upperFirst'
import words from 'lodash/words'

export const YearFilter = ({ years, setFilter }) => (
  <FormGroup>
    {
      map(years, (num, year) => (
        <Checkbox
          id={`${year}`}
          key={`${year}`}
          name="yearGroup"
          onClick={({ target }) => setFilter(target.id, 'fiscal_year')}
        >{year} ({num})
        </Checkbox>)
      )}
  </FormGroup>
)

export const AuditTypeFilter = ({ selectedType, setFilter }) => (
  <div>
    <p><b>Audit Type</b></p>
    <Nav bsStyle="tabs" onSelect={val => setFilter(val, 'table_type')}>
      <NavItem
        active={selectedType === 'initiative'}
        eventKey="initiative"
      >
         Initiative
      </NavItem>
      <NavItem
        active={selectedType === 'budget'}
        eventKey="budget"
      > Budget
      </NavItem>
    </Nav>
  </div>
)

export const BudgetFilter = ({ state, setFilter }) => (
  <div style={{ display: 'inline' }}>
    <p><b>Budget Range</b></p>
    <FormGroup id="amount_min" validationState={validateBudgetMin(state) ? 'success' : 'error'} >
      <FormControl
        id="amount_min"
        onBlur={({ target }) => setFilter(target.value || null, target.id)}
        placeholder="$ Min"
        type="text"
      />
    </FormGroup>
    <ControlLabel>to</ControlLabel>
    <FormGroup id="amount_max" validationState={validateBudgetMax(state) ? 'success' : 'error'} >
      <FormControl
        id="amount_max"
        onBlur={({ target }) => setFilter(target.value || null, target.id)}
        placeholder="$ Max"
        type="text"
      />
    </FormGroup>
  </div>
)

// TODO: R E F A C T O R. It's a bit better, but needs more cleanup.

export const MultiSelectFilter = ({
  aggs,
  setFilter,
  selectedFilter,
  filterName,
  initiativePairs = null,
}) => {
  const options = initiativePairs
    ? map(aggs, (v, k) => {
      const matchedInitiative = find(initiativePairs, ini => ini.initiative_id === k) || {}

      return ({ label: matchedInitiative.initiative_name, value: k })
    })
    : map(aggs, (v, k) => ({ label: `${k} (${v})`, value: k }))

  return (
    <div>
      <Select
        className="multi-select"
        multi
        onChange={target => setFilter(map(target, i => i.value), filterName)}
        options={options}
        placeholder={`${upperFirst(words(filterName).join(' '))}`} // nope
        value={selectedFilter}
      />
    </div>
  )
}


export const DateFilter = ({ minTime, maxTime, setFilter }) => (
  <div>
    <br />
    <p><b>Modified Time: Start</b></p>
    <DatePicker
      className="lesser-z"
      id="modified_time_min"
      onSelect={value => setFilter(value, 'modified_time_min')}
      selected={minTime}
      showTodayButton
    />

    <p className="filter-margin"><b>Modified Time: End</b></p>
    <DatePicker
      className="lesser-z"
      id="modified_time_max"
      onSelect={value => setFilter(value, 'modified_time_max')}
      selected={maxTime}
      showTodayButton
    />
  </div>
)
