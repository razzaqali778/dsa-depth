import { formatAmount } from '../../util/BudgetUtil'
import React from 'react'
import getOrElse from 'lodash/get'

const getAmount = budget => getOrElse(budget, 'amount', 0)

export default class BudgetAmountComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      budget: {},
      amountFieldClass: 'col-md-9',
      amountErrorMessage: ' ',
      saveDisabled: false,
    }
  }

  componentDidMount() {
    this.setState({budget: this.props.budget || {}, oldAmount: getAmount(this.props.budget) }) // eslint-disable-line
  }

  componentWillReceiveProps(nextProps) {
    this.setState({ budget: nextProps.budget, oldAmount: getAmount(nextProps.budget) })
  }


  render() {
    const amount = formatAmount(getAmount(this.state.budget))

    return (
      <div className="row">
        <div className="col-md-12 budget-total">
          <p className="card-text" id="readOnlyAmount"><b>Amount:</b> {amount}</p>
        </div>
      </div>
    )
  }
}
