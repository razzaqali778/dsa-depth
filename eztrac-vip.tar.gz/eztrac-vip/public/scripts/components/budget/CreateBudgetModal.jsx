import { Modal } from 'react-bootstrap'
import BreadcrumbsComponent from '../BreadcrumbsComponent'
import BudgetFormComponent from './BudgetFormComponent'
import React from 'react'
import getOrElse from 'lodash/get'

export default class CreateBudgetModal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      fiscalYears: props.fiscalYears || [],
    }
  }

  componentWillReceiveProps(nextProps) {
    this.setState({ fiscalYears: nextProps.fiscalYears })
  }

  render() {
    return (
      <Modal backdrop="static" onHide={this.props.close} show={this.props.show}>
        <Modal.Header closeButton>
          <Modal.Title>
            {this.props.isInEditMode
              ? <span> Edit Budget for: <b>{getOrElse(this.props, 'initiative.initiative_name', '')}</b> </span>
              : <span> Create Budget for: <b>{getOrElse(this.props, 'initiative.initiative_name', '')}</b> </span>
            }
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col-md-12">
              <BreadcrumbsComponent lineage={this.props.lineage} optionalClass="disabled" />
            </div>
          </div>
          <BudgetFormComponent
            budget={this.props.budget}
            cancelAction={this.props.close}
            communityList={this.props.communityList}
            fiscalYears={this.state.fiscalYears}
            initiative={this.props.initiative}
            isInEditMode={this.props.isInEditMode}
            saveBudget={this.props.saveBudget}
          />
        </Modal.Body>
      </Modal>
    )
  }
}
