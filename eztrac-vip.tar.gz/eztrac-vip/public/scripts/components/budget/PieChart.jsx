import Chart from 'chart.js'
import React from 'react'
import getOrElse from 'lodash/get'

export default class PieChart extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      chart: {},
    }
  }

  componentDidMount() {
    const chartCanvas = this.chart

    const chart = new Chart(chartCanvas, {
      type: 'pie',
      data: this.props.data,
      options: {
        title: {
          display: false,
          text: 'Budget Splits',
        },
        legend: {
          display: true,
          position: 'right',
        },
        tooltips: {
          callbacks: {
            label: (tooltipItem, data) => {
              const { datasetIndex, index } = tooltipItem
              const value = getOrElse(data, `datasets[${datasetIndex}].data[${index}`, 0)

              const thousands = parseFloat(value, 10) / 1000.0

              const commaString = thousands.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')

              return `$${commaString}k`
            },
          },
        },
      },
    })

    this.setState({ chart }) // eslint-disable-line react/no-did-mount-set-state
  }

  componentDidUpdate() {
    if ( this.props.data && this.props.data.datasets && this.props.data.datasets.length ) {
      const chart = this.state.chart
      const data = this.props.data

      chart.data = data

      chart.update()
    }
  }
  setRef = c => {
    this.chart = c
  }

  render() {
    return (
      <canvas
        height={this.props.dimensions ? this.props.dimensions.height : 0}
        ref={this.setRef}
        style={{ ...this.props.dimensions }}
        width={this.props.dimensions ? this.props.dimensions.width : 0}
      />
    )
  }
}
