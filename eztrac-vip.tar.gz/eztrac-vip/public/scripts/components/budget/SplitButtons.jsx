import { Button } from 'react-bootstrap' // eslint-disable-line wyze/max-file-length
import React from 'react'
import filter from 'lodash/filter'
import map from 'lodash/map'

export const AddSplitButton = ({ budget: { budgetId }, budgetSplits, setBudgetSplits, splitField }) =>
  (<div
    id="addSplitBudget"
    style={{
      display: 'inline',
    }}
  >
    <Button
      className="glyphicon glyphicon-plus"
      onClick={() => {
        const newBudgetSplits = [
          ...budgetSplits,
          { budgetId, amount: 0, splitValue: '', splitField },
        ]

        setBudgetSplits(newBudgetSplits)
      }}
      style={{ color: '#000000' }}
    />
  </div>)

export const RemoveSplitButton = ({ budgetSplits, index, setBudgetSplits }) =>
  (<div className="col-md-1" id="addSplitBudget">
    <Button
      className="glyphicon glyphicon-minus"
      onClick={() => {
        const newBudgetSplits = filter(map(budgetSplits, (split, idx) => idx === index ? null : split), d => d)
        setBudgetSplits(newBudgetSplits)
      }}
      style={{ color: '#000000' }}
    />
  </div>)
