import { // eslint-disable-line wyze/max-file-length
  AddSplitButton,
  RemoveSplitButton,
} from './SplitButtons'
import { Panel } from 'react-bootstrap'
import React from 'react'
import SplitBudgetComponent from './SplitBudgetComponent'
import find from 'lodash/find'
import map from 'lodash/map'

const SplitWarningMessage = ({ error }) => error
  ? <div
    style={{
      display: 'inline-block',
      color: 'orange',
      paddingLeft: '10px',
    }}
  >
    {error}
  </div>
  : null

const SplitErrorMessage = ({ error }) => error
  ? <div
    style={{
      display: 'inline-block',
      color: 'red',
      paddingLeft: '10px',
    }}
  >
    {error}
  </div>
  : null

export default ({
  budget,
  budgetSplits,
  dropdownOptions,
  setBudgetSplits,
  splitTotalError,
  budgetSplitErrors,
  splitField,
  splitPanelExpanded,
  toggleSplitPanelExpanded,
}) => (
  <Panel
    collapsible
    expanded={splitPanelExpanded}
    header={'Split Budget by Community'}
    onSelect={toggleSplitPanelExpanded}
  >
    {map(budgetSplits, (split, index) => {
      const errorMessage = (find(budgetSplitErrors, err => err.index === index) || { err: '' }).err

      return (
        <Panel
          className="panel-borderless"
          key={`budget-split${index + 1}`}
        >
          <SplitBudgetComponent
            dropdownOptions={dropdownOptions}
            id="split_budget1"
            setValue={({ amount, splitValue }) => {
              const newSplit = {
                ...budgetSplits[index],
                ...amount !== undefined ? { amount } : {},
                ...splitValue !== undefined ? { splitValue } : {},
              }

              const newBudgetSplits = map(budgetSplits, (budgetSplit, idx) => {
                if ( idx === index ) {
                  return newSplit
                }

                return budgetSplit
              })

              setBudgetSplits(newBudgetSplits)
            }}
            value={budgetSplits[index]}
          >
            <RemoveSplitButton
              budgetSplits={budgetSplits}
              index={index}
              setBudgetSplits={setBudgetSplits}
            />
          </SplitBudgetComponent>
          <SplitErrorMessage error={errorMessage} />
        </Panel>)
    }
    )}
    <Panel className="panel-borderless">
      <div className="col-md-12" id="splitBudgetType">
        <div className="col-md-11">
          <SplitWarningMessage error={splitTotalError} />
        </div>
        <div className="col-md-1">
          <AddSplitButton
            budget={budget}
            budgetSplits={budgetSplits}
            setBudgetSplits={setBudgetSplits}
            splitField={splitField}
          />
        </div>
      </div>
    </Panel>
  </Panel>
)
