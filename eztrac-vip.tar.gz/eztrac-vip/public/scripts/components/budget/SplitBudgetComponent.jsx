import React from 'react'
import Select from 'react-select'
import getOrElse from 'lodash/get'
import toInteger from 'lodash/toInteger'

export default class SplitBudgetComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      split_budget_typeErrorMessage: ' ',
      split_budget_amountErrorMessage: ' ',
      dropdownOptions: props.dropdownOptions,
    }
  }

  componentWillReceiveProps(nextProps) {
    if ( nextProps.dropdownOptions ) {
      this.setState({ dropdownOptions: nextProps.dropdownOptions })
    }
  }

  render() {
    const formatValue = value =>
      value ? value / 1000 : value

    return (
      <div className="col-md-12">
        <div className="col-md-6" id="splitBudgetType">
          <Select
            id="split_type"
            name="split_type_select"
            onChange={({ value }) => {
              this.props.setValue({ splitValue: value })
            }}
            options={this.state.dropdownOptions}
            placeholder="Choose community split"
            resetValue={{ value: '', label: '' }}
            value={this.props.value.splitValue}
          />
          <p className="text-danger" id="statusErrorMessage">{this.state.statusErrorMessage}</p>
        </div>

        <div className="col-md-5" id="splitBudgetAmount">
          <div className="input-group">
            <div className="input-group-addon">$</div>
            <input
              className="form-control"
              id="splitBudgetValue"
              onChange={evt => {
                const val = getOrElse(evt, 'target.value', 0)

                const amount = val ? toInteger(val) * 1000 : ''
                this.props.setValue({ amount })
              }}
              type="number"
              value={formatValue(this.props.value.amount)}
            />
            <div className="input-group-addon">,000</div>
          </div>
        </div>
        {this.props.children}
      </div>
    )
  }
}
