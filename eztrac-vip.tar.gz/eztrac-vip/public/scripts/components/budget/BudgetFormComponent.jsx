import { Button } from 'react-bootstrap' // eslint-disable-line wyze/max-file-length
import {
  applyCurrencyConversion,
  getParentBudgets,
  unapplyCurrencyConversion,
} from '../../util/BudgetUtil'
import BudgetSplits from './BudgetSplits'
import BudgetValidator from '../../util/BudgetValidator'
import React from 'react'
import Select from 'react-select'
import getOrElse from 'lodash/get'
import map from 'lodash/map'
import toInteger from 'lodash/toInteger'
import validateBudgetAndSplit from '../../selectors/budget/validateBudgetAndSplit'
import validateSplitAmounts from '../../selectors/budget/validateBudgetSplits'

export default class BudgetFormComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      budget: props.budget || {},
      fiscalYearFieldClass: 'col-md-6',
      fiscalYearErrorMessage: ' ',
      amountFieldClass: 'col-md-6',
      amountErrorMessage: ' ',
      saveDisabled: true,
      dropdownOptions: map(props.communityList, ({ name, id }) =>
        ({ value: id, label: name })),
      budgetSplits: [],
      budgetSplitErrors: [],
      splitTotalError: '',
      splitPanelExpanded: false,
      parentBudgets: [],
    }
  }

  async componentWillMount() {
    const budgetSplits = getOrElse(this.props, 'budget.splits', [])
    const parentBudgets = await getParentBudgets(this.props.initiative.initiative_id)

    this.setState({
      budgetSplits,
      splitPanelExpanded: budgetSplits.length > 0,
      parentBudgets,
    })
  }

  setBudgetSplits = budgetSplits => {
    this.setState({ budgetSplits }, () => this.validateFields())
  }

  async handleSplitPanelCollapse() {
    this.setState({ splitPanelExpanded: !this.state.splitPanelExpanded })
  }
  updateAmount = ({ target }) => {
    const val = target.value === '' ? '' : unapplyCurrencyConversion(target.value)
    this.setState({ budget: { ...this.state.budget, [target.id]: val } }, () => this.validateFields())
  }
  updateSelectField = select => {
    this.setState({ budget: { ...this.state.budget, [select.id]: select.value } }, () => this.validateFields())
  }

  resetErrors = target => {
    const newState = {}
    newState[`${target}FieldClass`] = 'col-md-6'
    newState[`${target}ErrorMessage`] = ''
    if ( target === 'finance_code_type' && (target.value === '' || target.value === undefined) ) {
      newState.finance_code_valueFieldClass = 'col-md-6'
      newState.finance_code_valueErrorMessage = ''
    }
    this.setState(newState)
  }

  validateFields = () => {
    const { hasError: amountNotValid, message: amountErrorMessage } =
      BudgetValidator.validateAmount(this.state.budget.amount, this.state.parentBudgets, this.state.budget.fiscalYear)
    const { valid: splitValid, message: splitTotalError } = validateSplitAmounts(this.state)
    const { hasError: fyNotValid, message: fiscalYearErrorMessage } = BudgetValidator.validateSelect(
      this.state.budget.fiscalYear, 'fiscalYear')

    const budgetSplitErrors = validateBudgetAndSplit(this.state)

    this.setState({
      amountFieldClass: `col-md-6 ${amountNotValid ? 'has-error' : ''}`,
      fiscalYearFieldClass: `col-md-6 ${fyNotValid ? 'has-error' : ''}`,
      fiscalYearErrorMessage,
      amountErrorMessage,
      splitTotalError,
      budgetSplitErrors,
    })

    if ( amountNotValid || fyNotValid || !splitValid || budgetSplitErrors.length > 0 ) {
      this.setState({
        saveDisabled: true,
      })
    } else {
      this.setState({
        saveDisabled: false,
      })
    }
  }

  saveBudget = () => {
    const budget = {
      ...this.state.budget,
      amount: toInteger(this.state.budget.amount),
      splits: this.state.budgetSplits,
    }

    this.props.saveBudget(budget)
  }

  renderYearDropdown = () => !this.props.isInEditMode
    ? <div>
      <Select
        id="fiscalYear"
        name="fiscalYearSelect"
        onChange={this.updateSelectField}
        options={this.props.fiscalYears}
        placeholder="Select a Fiscal Year"
        resetValue={{ value: '', label: '', id: 'fiscalYear' }}
        value={this.state.budget.fiscalYear || null}
      />
      <p className="text-danger" id="fiscalYearErrorMessage">{this.state.fiscalYearErrorMessage}</p>
    </div>
    : <p> {this.props.budget.fiscalYear} </p>


  render() {
    return (
      <div>
        <div className="row form-group" id="budgetQuestions">
          <div className={this.state.fiscalYearFieldClass} id="fiscalYearField">
            <label className="control-label" htmlFor="fiscalYear">Fiscal Year</label>
            { this.renderYearDropdown() }
          </div>
          <div className={this.state.amountFieldClass} id="amountField">
            <label className="control-label" htmlFor="budget-amount">Amount</label>
            <div className="input-group">
              <div className="input-group-addon">$</div>
              <input
                className="form-control"
                id="amount"
                onChange={this.updateAmount}
                type="number"
                value={applyCurrencyConversion(this.state.budget.amount)}
              />
              <div className="input-group-addon">,000</div>
            </div>
            <p className="text-danger" id="amountErrorMessage">{this.state.amountErrorMessage}</p>
          </div>
        </div>
        <BudgetSplits
          budget={this.state.budget}
          budgetSplitErrors={this.state.budgetSplitErrors}
          budgetSplits={this.state.budgetSplits}
          dropdownOptions={this.state.dropdownOptions}
          setBudgetSplits={this.setBudgetSplits}
          splitField="COMMUNITY" // todo -- replace this with selectable field
          splitPanelExpanded={this.state.splitPanelExpanded}
          splitTotalError={this.state.splitTotalError}
          toggleSplitPanelExpanded={() => this.handleSplitPanelCollapse()}
        />
        <div className="row">
          <div className="col-md-4 col-md-offset-8">
            <div className="pull-right">
              <Button
                className="btn-margin-right"
                id="cancelButton"
                onClick={this.props.cancelAction}
              >
                Cancel
              </Button>
              <Button
                bsStyle="primary"
                disabled={this.state.saveDisabled}
                id="saveButton"
                onClick={this.saveBudget}
              >
                Save
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
