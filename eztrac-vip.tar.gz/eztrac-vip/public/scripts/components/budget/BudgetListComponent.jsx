/* eslint-disable wyze/max-file-length */
import { AlertList } from 'react-bs-notifier'
import { Button } from 'react-bootstrap'
import { createBudget, getFiscalYears, orderBudgets, updateBudget } from '../../util/BudgetUtil'
import { getCommunityList } from '../../util/communityUtil'
import AlertUtil from '../../util/AlertUtil'
import BudgetCardComponent from './BudgetCardComponent'
import CreateBudgetModal from './CreateBudgetModal'
import React from 'react'
import UserRolesUtil from '../../util/UserRolesUtil'
import map from 'lodash/map'
import reject from 'lodash/reject'

export default class BudgetListComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      budgets: [],
      fiscalYears: [],
      showBudgetModal: false,
      budgetInEditMode: false,
      communityList: [],
      alerts: [],
      userHasReadWriteRole: true,
    }
    this.createOrUpdateBudget = this.createOrUpdateBudget.bind(this)
  }

  async componentWillMount() {
    const communityList = await getCommunityList()
    const userHasReadWriteRole = await UserRolesUtil.hasReadWriteRole()
    this.setState({ communityList, userHasReadWriteRole })
  }

  componentWillReceiveProps(nextProps) {
    const budgets = orderBudgets(nextProps.budgets, 'fiscalYear')
    const fiscalYears = getFiscalYears(budgets)
    this.setState({ budgets, fiscalYears })
  }

  onAlertDismissed(alert) {
    const alerts = this.state.alerts
    const idx = alerts.indexOf(alert)

    if ( idx >= 0 ) {
      this.setState({
        alerts: [ ...alerts.slice(0, idx), ...alerts.slice(idx + 1) ],
      })
    }
  }

  closeBudgetModal = () => this.setState({ showBudgetModal: false, budgetInEditMode: false, activeBudget: {} })

  async createOrUpdateBudget(budget) {
    this.closeBudgetModal()
    if ( this.state.budgetInEditMode ) {
      try {
        await updateBudget(budget)
        const newBudget = {
          ...budget,
          initiativeId: this.props.initiative.initiative_id,
          initiativeName: 'test',
          children: [],
        }
        const newBudgetList = [
          ...reject(this.state.budgets, ({ fiscalYear: year }) => year === newBudget.fiscalYear),
          newBudget,
        ]
        const orderedBudgets = orderBudgets(newBudgetList, 'fiscalYear')
        this.setState({ budgets: orderedBudgets })
        AlertUtil.setAlert(this, 'success', 'Budget modified successfully')
      } catch ( error ) {
        AlertUtil.setAlert(this, 'error', error.message)
      }
    } else {
      try {
        const { body: { budgetId } } = await createBudget({
          ...budget,
          initiativeId: this.props.initiative.initiative_id,
        })
        const newBudget = {
          ...budget,
          initiativeId: this.props.initiative.initiative_id,
          initiativeName: 'test',
          children: [],
          splits: budget.splits.map(split => ({ ...split, budgetId })),
        }
        const orderedBudgets = orderBudgets([ ...this.state.budgets, newBudget ], 'fiscalYear')
        const fiscalYears = getFiscalYears(orderedBudgets)
        this.props.updateBudgetState(orderedBudgets)
        this.setState({ budgets: orderedBudgets, fiscalYears })
        AlertUtil.setAlert(this, 'success', 'Budget created successfully')
      } catch ( error ) {
        AlertUtil.setAlert(this, 'error', error.message)
      }
    }
  }

  renderBudgetModal = () => (
    <CreateBudgetModal
      budget={this.state.activeBudget}
      close={this.closeBudgetModal}
      communityList={this.state.communityList}
      fiscalYears={this.state.fiscalYears}
      initiative={this.props.initiative}
      isInEditMode={this.state.budgetInEditMode}
      lineage={this.props.lineage}
      saveBudget={this.createOrUpdateBudget}
      show={this.state.showBudgetModal}
    />
  )

  renderCards = () => (
    <div className="row budget-cards">
      {map(this.state.budgets, budget => (
        <BudgetCardComponent
          budget={budget}
          communityList={this.state.communityList}
          key={`${budget.initiativeId}_${budget.fiscalYear}}`}
          openBudgetModal={() => this.setState({ showBudgetModal: true, budgetInEditMode: true, activeBudget: budget })}
          setMessage={(type, message) => {
            AlertUtil.setAlert(this, type, message)
          }}
        />
      ))}
    </div>
  )


  renderNoBudgets = () => (
    <div>
      {this.renderCreateButton()}
      <div className="row">
        <div className="col-md-12">
          <div className="bs-callout bs-callout-info" id="noBudgetMessage">
            There are no budgets to display.
          </div>
        </div>
      </div>
    </div>
  )

  renderCreateButton = () =>
    this.state.userHasReadWriteRole ? (
      <div className="row row-padding">
        <div className="col-md-2 col-md-offset-10">
          <Button
            bsStyle="success"
            className="pull-right"
            disabled={this.state.fiscalYears.length === 0}
            id="budgetButton"
            onClick={() => this.setState({ showBudgetModal: true })}
          >
            Create Budget
          </Button>
        </div>
      </div>
    ) : null

  render() {
    return (
      <div>
        {this.renderBudgetModal()}
        {this.state.budgets.length === 0 ? (
          this.renderNoBudgets()
        ) : (
          <div>
            <AlertList
              alerts={this.state.alerts}
              onDismiss={this.onAlertDismissed.bind(this)} // eslint-disable-line react/jsx-no-bind
              position="top-right"
            />
            {this.renderCreateButton()}
            {this.renderCards()}
          </div>
        )}
      </div>
    )
  }
}
