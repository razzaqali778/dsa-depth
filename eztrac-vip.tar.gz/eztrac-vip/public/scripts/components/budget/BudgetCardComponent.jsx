import { Button } from 'react-bootstrap'
import { formatAmount, getSumOfChildren, makePieChartSlicesBySplits } from '../../util/BudgetUtil'
import BudgetAmountComponent from './BudgetAmountComponent'
import PieChart from './PieChart'
import React from 'react'
import UserRolesUtil from '../../util/UserRolesUtil'
import getOrElse from 'lodash/get'
import map from 'lodash/map'

const cardStyle = {
  height: 'fit-content',
  width: 400,
}

const cardBodyStyle = {
  height: 'fit-content',
  width: 400,
}
export default class BudgetCardComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      pieChartData: [],
      budget: { children: [] },
      total: 0,
      userHasReadWriteRole: true,
    }
  }

  async componentDidMount() {
    const userHasReadWriteRole = await UserRolesUtil.hasReadWriteRole()
    this.formatBudget(this.props.budget, this.props.communityList)

    this.setState({ userHasReadWriteRole }) // eslint-disable-line react/no-did-mount-set-state
  }

  componentWillReceiveProps(nextProps) {
    this.formatBudget(nextProps.budget, nextProps.communityList)
  }

  getTitle = () => getOrElse(this.state, 'budget.fiscalYear', 2000)

  getBudgetAmount = () => getOrElse(this.state, 'budget.amount', 0)
  getBudgetChildren = () => getOrElse(this.state, 'budget.children', [])
  formatBudget = (budget, communityList) => {
    const pieChartData = makePieChartSlicesBySplits(budget, communityList)

    const total = getSumOfChildren(budget)

    this.setState({ pieChartData, budget, total })
  }

  renderLegend = () =>
    map(this.getBudgetChildren(), child => {
      const style = { backgroundColor: child.fill }
      if ( this.state.total > this.getBudgetAmount() ) {
        style.backgroundColor = '#F44336'
      }

      return (
        <div className="row" key={child.initiative_id}>
          <div className="col-md-1">
            <div className="legend-element" style={style} />
          </div>
          <div className="col-md-10">
            <b>{child.initiative_name}:</b> {formatAmount(child.amount || 0)}
          </div>
        </div>
      )
    })

  // this has been intentionally disabled
  renderAvailableFunds = () => {
    if ( this.state.total < this.getBudgetAmount() ) {
      const style = { backgroundColor: '#BDBDBD' }
      const amount = formatAmount(this.getBudgetAmount() - this.state.total)

      return (
        <div className="row" id="availableFundsLegendItem">
          <div className="col-md-1">
            <div className="legend-element" style={style} />
          </div>
          <div className="col-md-10">
            <b>Unassigned Funds:</b> {amount}
          </div>
        </div>
      )
    }

    return null
  }

  renderEditButton = () =>
    this.state.userHasReadWriteRole ? (
      <div style={{ width: '100%', textAlign: 'center' }}>
        <Button bsStyle="success" id="budgetButton" onClick={this.props.openBudgetModal}>
          {' '}
          Edit Budget{' '}
        </Button>
      </div>
    ) : null

  renderAmount = () => <BudgetAmountComponent budget={this.state.budget} setMessage={this.props.setMessage} />

  render() {
    const pieChartArea =
      this.state.pieChartData.length !== 1 ? (
        <PieChart data={this.state.pieChartData} dimensions={cardStyle} />
      ) : (
        <div />
      )

    return (
      <div className="element-item" style={cardStyle}>
        <div className="budget-card" style={cardBodyStyle}>
          <div className="card-header">
            <h4 className="card-title">{this.getTitle()}</h4>
          </div>
          <div className="card-body">
            <div className="card-block">{this.renderAmount()}</div>
            <div className="card-block">{pieChartArea}</div>
            <div className="card-block">{this.renderLegend()}</div>
            {this.renderEditButton()}
          </div>
        </div>
      </div>
    )
  }
}
