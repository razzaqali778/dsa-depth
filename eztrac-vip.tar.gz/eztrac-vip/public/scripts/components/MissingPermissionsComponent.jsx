import React from 'react'

const MissingPermissionsComponent = () => {
  const entitlementUrl = window.phoenix.serviceBindings['vip-entitlements']

  return (
    <div>
      <div className="row">
        <div className="col-md-10 col-md-offset-1">
          <h1>You do not have access to Velocity Initiative Portfolio</h1>
        </div>
      </div>
      <div className="row">
        <div className="col-md-4 col-md-offset-4">
          <h4>Please <a href={entitlementUrl}>request</a> the proper entitlements.</h4>
        </div>
      </div>
    </div>
  )
}

export default MissingPermissionsComponent
