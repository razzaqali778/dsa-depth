import { ButtonToolbar, ToggleButton, ToggleButtonGroup } from 'react-bootstrap'
import React from 'react'
import map from 'lodash/map'

export const FilterComponent = ({ changeAction, options, type }) => (
  <div className="filter">
    <ButtonToolbar>
      <ToggleButtonGroup name="options" type={type} >
        {
          map(options, (option, index) => (
            <ToggleButton
              className={option.active ? 'btn-primary' : 'btn-default'}
              key={index}
              onChange={() => changeAction(option.id)}
              value={index}
            >
              {option.label}
            </ToggleButton>
          ))
        }
      </ToggleButtonGroup>
    </ButtonToolbar>
  </div>
)

export default FilterComponent
