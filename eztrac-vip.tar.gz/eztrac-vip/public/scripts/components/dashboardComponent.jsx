import { AlertList } from 'react-bs-notifier'
import { appBaseUrl, localVipServicesUrl } from '../../consts'
import { getDataForDashboard } from '../util/DashboardUtil'
import AlertUtil from '../util/AlertUtil'
import CreateInitiativeModal from './initiative/CreateInitiativeModal'
import InitiativeCardsComponent from './initiative/InitiativeCardsComponent'
import LoadingBlocker from './LoadingBlocker'
import MissingPermissionsComponent from './MissingPermissionsComponent'
import React from 'react'
import UserRolesUtil from '../util/UserRolesUtil'
import agent from '../../agent'
import getOrElse from 'lodash/get'
import reduce from 'lodash/reduce'
import shouldPureComponentUpdate from 'react-pure-render/function'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)
const createInitiativeUrl = `${vipApiUrl}/v1/createInitiative`

class DashboardComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      initiatives: [],
      initiativeStatuses: [],
      activeInitiativeTypes: [],
      initiativeTypes: [],
      financeCodeTypes: [],
      showCreateInitiativeModal: false,
      loading: true,
      initiativeTypesMap: {},
      alerts: [],
      userHasEitherRole: true,
      createAnotherInitiative: false,
    }

    this.createInitiative = this.createInitiative.bind(this)
    this.redirectToRequestInitiative = this.redirectToRequestInitiative.bind(this)
  }

  async componentDidMount() {
    try {
      console.log('Dashboard mounting') // eslint-disable-line no-console
      const userHasEitherRole = await UserRolesUtil.hasEitherRole()
      const data = await getDataForDashboard()
      const initiativeTypesMap = reduce(
        data.initiativeTypes,
        (memo, { value, label }) => {
          memo[value] = label // eslint-disable-line no-param-reassign

          return memo
        },
        {}
      )
      this.setState({ // eslint-disable-line react/no-did-mount-set-state
        initiatives: data.initiatives,
        initiativeStatuses: data.initiativeStatuses,
        financeCodeTypes: data.financeCodeTypes,
        initiativeTypes: data.initiativeTypes,
        activeInitiativeTypes: data.activeInitiativeTypes,
        initiativeTypesMap,
        loading: false,
        userHasEitherRole,
      })

      if ( this.props.location.query.error === 'invalid_initiative_id' ) {
        AlertUtil.setAlert(this, 'error', 'Invalid link')
      }
    } catch ( error ) {
      AlertUtil.setAlert(this, 'error', error.toString())
      this.setState({ loading: false }) // eslint-disable-line react/no-did-mount-set-state
    }
  }

  shouldComponentUpdate = shouldPureComponentUpdate

  onAlertDismissed(alert) {
    const alerts = this.state.alerts
    const idx = alerts.indexOf(alert)

    if ( idx >= 0 ) {
      this.setState({
        alerts: [ ...alerts.slice(0, idx), ...alerts.slice(idx + 1) ],
      })
    }
  }

  async createInitiative({ initiative, createAnotherInitiative }) {
    this.setState({ showCreateInitiativeModal: false, loading: true })
    try {
      const response = await agent.post(createInitiativeUrl, initiative)
      const newInitiative = { ...initiative, parent: null, initiative_id: response.body.initiative_id }
      this.setState({ loading: false, initiatives: [ ...this.state.initiatives, newInitiative ] })

      AlertUtil.setAlert(this, 'success', 'Created initiative successfully.')
      if ( !createAnotherInitiative ) {
        window.location = `${appBaseUrl}/initiative/${response.body.initiative_id}`
      } else {
        this.setState({ createAnotherInitiative: true })
        this.renderCreateInitiativeModal()
        this.setState({ showCreateInitiativeModal: true })
      }
    } catch ( error ) {
      this.setState({ loading: false })
      AlertUtil.setAlert(this, 'error', error.toString())
    }
  }

  openCreateModal = () => this.setState({ showCreateInitiativeModal: true })

  closeCreateModal = () => this.setState({ showCreateInitiativeModal: false, createAnotherInitiative: false })

  closeMessage = () =>
    this.setState({
      message: {
        hasMessage: false,
        messageType: '',
        messageText: '',
      },
    })

    redirectToRequestInitiative = () => {
      window.location = `${appBaseUrl}/request-initiative/`
    }

  renderCreateInitiativeModal = () => (
    <CreateInitiativeModal
      close={this.closeCreateModal}
      createAnotherInitiative={this.state.createAnotherInitiative}
      financeCodeTypes={this.state.financeCodeTypes}
      initiativeStatuses={this.state.initiativeStatuses}
      initiativeTypes={this.state.activeInitiativeTypes}
      initiatives={this.state.initiatives}
      isTopLevel
      save={this.createInitiative}
      show={this.state.showCreateInitiativeModal}
      title="Create Top Level Initiative"
    />
  )

  renderInitiativeCardsComponent = () => (
    <InitiativeCardsComponent
      buttonAction={this.openCreateModal}
      buttonText="Create Top Level Initiative"
      initiativeTypes={this.state.initiativeTypes}
      initiativeTypesMap={this.state.initiativeTypesMap}
      initiatives={this.state.initiatives}
      isTopLevel
    />
  )


  render() {
    console.log('Dashboard rendering') // eslint-disable-line no-console

    return this.state.userHasEitherRole ? (
      <div id="dashboardBody">
        <LoadingBlocker isLoading={this.state.loading} />
        <div className="row">
          <div className="col-md-12">
            <h1>Initiative Portfolio</h1>
            <br />
            <button
              onClick={this.redirectToRequestInitiative}
              style={{ padding: 0, border: 'none', background: 'none' }}
            >
              <a>Request New Initiative </a>
            </button>
          </div>
        </div>
        {this.renderCreateInitiativeModal()}
        <AlertList
          alerts={this.state.alerts}
          onDismiss={this.onAlertDismissed.bind(this)} // eslint-disable-line react/jsx-no-bind
          position="top-right"
        />
        {this.renderInitiativeCardsComponent()}
      </div>
    ) : (
      <MissingPermissionsComponent />
    )
  }
}

export default DashboardComponent
