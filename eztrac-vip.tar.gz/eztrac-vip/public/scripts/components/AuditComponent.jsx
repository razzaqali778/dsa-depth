import {
  AuditTypeFilter,
  BudgetFilter,
  DateFilter,
  MultiSelectFilter,
  YearFilter,
} from './AuditFilterComponents'
import { callElasticSearch } from '../util/elasticUtil'
import { getFiscalYears } from '../util/AuditUtil'
import { getInitiativeNames } from '../util/InitiativeUtil'
import { modifyFilters } from '../util/filterUtil'
import AuditCards from './AuditCardsComponent'
import LoadingBlocker from './LoadingBlocker'
import React from 'react'
import getQueryString from '../selectors/audit/getQueryString'

const defaultFilters = {
  fiscal_year: [],
  modified_by: [],
  amount_min: null,
  amount_max: null,
  initiative_id: [],
  type_id: [],
  finance_code_value: [],
  modified_time_min: null,
  modified_time_max: null,
}

export default class AuditComponent extends React.Component {
  constructor( props ) {
    super(props)
    this.state = {
      value: '',
      loading: true,
      audits: [],
      auditHistory: [],
      filters: {
        ...defaultFilters,
        table_type: 'initiative',
      },
      fiscalYears: [],
      filterOpts: {
        year: {},
        modified_by: {},
        finance_code_value: {},
        initiative: {},
        type_id: {},
      },
      filterUrl: '',
      initiativePairs: [],
    }
    this.setElasticResults = this.setElasticResults.bind(this)
    this.setFilter = this.setFilter.bind(this)
  }

  async componentDidMount() {
    try {
      const query = getQueryString(this.state)
      const { hits: audits, aggs: filterOpts } = await callElasticSearch(query)
      const fiscalYears = await getFiscalYears()
      const initiativePairs = await getInitiativeNames()

      this.setState({ // eslint-disable-line react/no-did-mount-set-state
        audits,
        loading: false,
        fiscalYears,
        filterOpts,
        initiativePairs,
      })
    } catch ( error ) {
      console.error(error) // eslint-disable-line no-console
      throw error
    }
  }

  async setElasticResults(modifiedFilters = null, filterName = null) {
    this.setState({ loading: true })

    try {
      if ( modifiedFilters ) {
        this.setState({ filters: modifiedFilters })
      }
      const queryString = getQueryString(this.state)
      const { hits: audits, aggs: filterOpts } = await callElasticSearch(queryString)
      const newFilterOpts = ( filterName === 'table_type' )
        ? { ...this.state.filterOpts, ...filterOpts }
        : { ...this.state.filterOpts }
      this.setState({
        audits,
        filterOpts: newFilterOpts,
        loading: false,
      })
    } catch ( error ) {
      console.error(error) // eslint-disable-line no-console
      this.setState({ loading: false })
    }
  }

  async setFilter( target, name ) {
    const newFilters = name === 'table_type'
      ? { ...(await modifyFilters(this.state, target, name)), ...defaultFilters }
      : await modifyFilters(this.state, target, name)
    this.setElasticResults(newFilters, name)
  }

  render() {
    return (
      <div className="container">
        <LoadingBlocker isLoading={this.state.loading} />
        <div className="col-md-3 filter-column">
          <h4><b>Search Filters</b></h4>
          <br />
          <AuditTypeFilter
            selectedType={this.state.filters.table_type}
            setFilter={this.setFilter}
          />

          <MultiSelectFilter
            aggs={this.state.filterOpts.modified_by}
            filterName="modified_by"
            selectedFilter={this.state.filters.modified_by}
            setFilter={this.setFilter}
          />

          <MultiSelectFilter
            aggs={this.state.filterOpts.initiative}
            filterName="initiative_id"
            initiativePairs={this.state.initiativePairs}
            selectedFilter={this.state.filters.initiative_id}
            setFilter={this.setFilter}
          />

          { this.state.filters.table_type === 'budget'
            ? <div>
              <YearFilter
                setFilter={this.setFilter}
                years={this.state.filterOpts.year}
              />

              <BudgetFilter
                setFilter={this.setFilter}
                state={this.state}
              />

            </div>
            : <div>
              <MultiSelectFilter
                aggs={this.state.filterOpts.finance_code_value}
                filterName="finance_code_value"
                selectedFilter={this.state.filters.finance_code_value}
                setFilter={this.setFilter}
              />
              <MultiSelectFilter
                aggs={this.state.filterOpts.type_id}
                filterName="type_id"
                selectedFilter={this.state.filters.type_id}
                setFilter={this.setFilter}
              />
            </div>
          }

          <DateFilter
            maxTime={this.state.filters.modified_time_max}
            minTime={this.state.filters.modified_time_min}
            setFilter={this.setFilter}
          />
        </div>
        <div className="col-md-9 audits">
          <div className="row audit-header-row">
            <h4 className="col-md-6 audit-header"><b>Search Results</b></h4>
          </div>
          <AuditCards audits={this.state.audits} />
        </div>
      </div>
    )
  }
}
