/* eslint-disable wyze/max-file-length */
import { AlertList } from 'react-bs-notifier'
import { Button, Form } from 'react-bootstrap'
import { appBaseUrl, localVipServicesUrl } from '../../consts'
import { debounce, get as getOrElse, isEmpty, some, trim, trimEnd } from 'lodash'
import { getInitiativeTypeRules } from '../../scripts/util/InitiativeTypeRules'
import {
  getLimitedInitiativesAndParents,
  getRequestedInitiative,
  sendRequestedInitiative,
} from '../util/RequestInitiativeUtil'
import { validateAllFormFields, validateBudget } from '../util/CreateInitiativeValidator'
import AlertUtil from '../util/AlertUtil'
import CommonFlowComponent from './request-initiative/CommonFlowComponent'
import MissingPermissionsComponent from './MissingPermissionsComponent'
import ParentFlowComponent from './request-initiative/ParentFlowComponent'
import React from 'react'
import UserRolesUtil from '../util/UserRolesUtil'
import agent from '../../agent'


const defaultState = {
  approved: false,
  budget: '',
  businessUnit: '',
  comment: '',
  financialCode: '',
  fiscalYear: '',
  name: '',
  parentName: '',
  parentId: null,
  portfolioId: '',
  region: '',
  status: null,
  type: null,
  typeId: null,
  capProjRadio: true,
  parentNameRadio: true,
  activityId: '',
  programCode: '',
}

const typeToTypeId = {
  'Capital Initiative': 'CAP-INIT',
  'Capital OpEx Initiative': 'CAP-EXP-INIT',
  Support: 'SUP',
  'OpEx Only Project': 'ENH',
  'Special Item': 'EXP-INIT',
}

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)

const createInitiativeUrl = `${vipApiUrl}/v1/createInitiative`
const updateInitiativeRequestUrl = `${vipApiUrl}/v2/request-initiative`

export default class RequestInitiativeComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      formFields: defaultState,
      userHasEitherRole: true,
      userHasReadWriteRole: false,
      alerts: [],
      invalidName: false,
      requestedInitiativeId: null,
    }
  }

  componentDidMount = async () => {
    try {
      const initiatives = await getLimitedInitiativesAndParents()
      this.setState({ initiatives })
    } catch ( error ) {
      console.error(error) // eslint-disable-line no-console
      this.setState({ loading: false }) // eslint-disable-line
    }
    const userHasEitherRole = await UserRolesUtil.hasEitherRole()
    this.setState({ userHasEitherRole })
    const userHasReadWriteRole = await UserRolesUtil.hasReadWriteRole()
    this.setState({ userHasReadWriteRole })

    const { requestedInitiativeId } = this.props.params
    if ( requestedInitiativeId ) {
      const requestedInitiative = await getRequestedInitiative(requestedInitiativeId)
      const thisParentName = requestedInitiative.parentName.indexOf('[') >= 0 ?
        trim(requestedInitiative.parentName.split('[')[0]) : requestedInitiative.parentName
      const thisGrandParentName = requestedInitiative.parentName.indexOf('[') >= 0 ?
        trim(trimEnd(requestedInitiative.parentName.split('[')[1], ']')) : null
      const dropDownInit = this.state.initiatives.find(initiative =>
        initiative.initiativeName === thisParentName && initiative.parentName === thisGrandParentName)
      requestedInitiative.parentId = dropDownInit ? dropDownInit.id : null

      if ( !isEmpty(requestedInitiative) ) {
        requestedInitiative.typeId = getOrElse(typeToTypeId, requestedInitiative.type, null)
        this.setState({
          formFields: requestedInitiative,
          requestedInitiativeId: this.props.params.requestedInitiativeId,
        })
      } else {
        this.props.router.push(`${appBaseUrl}/request-initiative`)
      }
    }
  }

  onAlertDismissed = alert => {
    const alerts = this.state.alerts
    const idx = alerts.indexOf(alert)

    if ( idx >= 0 ) {
      this.setState({
        alerts: [ ...alerts.slice(0, idx), ...alerts.slice(idx + 1) ],
      })
    }
  }

  setFormFields = newFields => {
    this.setState({ formFields: { ...this.state.formFields, ...newFields } })
  }

  submitRequest = async () => {
    try {
      await sendRequestedInitiative([ this.state.formFields ])
      AlertUtil.setAlert(this, 'success', 'Your initiative request was successful.')
      this.setState({ formFields: defaultState })
    } catch ( error ) {
      AlertUtil.setAlert(this, 'error', error.toString())
    }
  }

  createInitiative = async () => {
    try {
      const initiative = {
        initiative_id: this.props.params.requestedInitiativeId,
        initiative_name: this.state.formFields.name,
        status: this.state.formFields.status,
        finance_code_value: this.state.formFields.financialCode,
        type_id: this.state.formFields.typeId,
        portfolio_code: this.state.formFields.portfolioId,
        parent: this.state.formFields.parentId,
        activity_id: this.state.formFields.activityId,
        tags: {},
        program_code: this.state.formFields.programCode,
      }
      if ( this.state.formFields.budget && this.state.formFields.fiscalYear ) {
        initiative.budget = this.state.formFields.budget
        initiative.fiscal_year = this.state.formFields.fiscalYear
      }

      if ( this.state.formFields.region ) {
        // eslint-disable-next-line dot-notation
        initiative.tags['REGION'] = this.state.formFields.region
      }

      if ( this.state.formFields.businessUnit ) {
        initiative.tags['BUS-UNIT'] = this.state.formFields.businessUnit
      }

      const selectedType = {
        value: this.state.formFields.typeId,
      }
      const rules = getInitiativeTypeRules(selectedType, initiative)
      await agent.post(createInitiativeUrl, rules.initiative)
      this.setFormFields({ approved: true })
      await this.updateRequest()
      AlertUtil.setAlert(this, 'success', 'Initiative created successfully')
    } catch ( error ) {
      AlertUtil.setAlert(this, 'error', error.toString())
    }
  }

  updateRequest = async () => {
    try {
      await agent.patch(`${updateInitiativeRequestUrl}/${this.props.params.requestedInitiativeId}`,
        this.state.formFields)
      if ( !this.state.formFields.approved ) {
        AlertUtil.setAlert(this, 'success', 'Your update was successful.')
      }
    } catch ( error ) {
      AlertUtil.setAlert(this, 'error', 'Your update could not be completed at this time')
    }
  }

  isValidFormRequest = () => (
    this.state.formFields.name &&
    this.state.formFields.portfolioId
    && validateBudget(this.state.formFields)
  )

  isValidFormCreate = () =>
    this.state.requestedInitiativeId &&
    !some(this.state.initiatives, initiative =>
      initiative.initiative_id === this.props.params.requestedInitiativeId)


  updateState = (evt, formName = null) => {
    const newFields = {}
    if ( evt === null ) {
      newFields[formName] = null
      if ( formName === 'type' ) {
        newFields.typeId = null
      }
    } else if ( evt.target ) {
      newFields[evt.target.name] = evt.target.value
      if ( evt.target.name === 'parentName' ) {
        newFields.parentId = null
      } else if ( !this.state.formFields.status && evt.target.name === 'financialCode' && evt.target.value ) {
        newFields.status = 'Funded'
      }
    } else {
      const value = evt.value
      newFields[formName] = value
      if ( formName === 'type' ) {
        newFields.typeId = getOrElse(typeToTypeId, value, null)
        if ( !this.state.formFields.capProjRadio ) {
          newFields.parentName = ''
          newFields.parentId = ''
        }
      }
    }
    this.setFormFields(newFields)
  }

  render() {
    return this.state.userHasEitherRole ?
      (
        <div>
          <h1>Request Initiative</h1>
          <p>Please fill out this form to the best of your ability.
            <br />The more complete the information the faster your initiatives can be created.
          </p>
          {this.state.formFields.approved && <span style={{ color: 'red' }}>
            This initiative has been created.
          </span>}
          {this.isValidFormCreate() && this.state.userHasReadWriteRole ? <p>
            This initiative was requested by: {this.state.formFields.requestedBy}
          </p> : null}
          <Form id="form-request">
            <CommonFlowComponent
              formFields={this.state.formFields}
              initiatives={this.state.initiatives}
              setFormFields={this.setFormFields}
              updateState={this.updateState}
            >
              <ParentFlowComponent
                formFields={this.state.formFields}
                initiatives={this.state.initiatives}
                setFormFields={this.setFormFields}
                updateState={this.updateState}
              />
            </CommonFlowComponent>


            {!this.state.requestedInitiativeId ? (
              <Button
                disabled={!this.isValidFormRequest()}
                onClick={debounce(this.submitRequest, 300, { leading: true })}
                style={{ marginTop: '20px' }}
              > Submit </Button>
            ) : null}
            { this.state.requestedInitiativeId && this.state.userHasEitherRole && !this.state.formFields.approved ? (
              <Button
                disabled={false}
                onClick={debounce(this.updateRequest, 300, { leading: true })}
                style={{ marginTop: '20px' }}
              > Update </Button>) : null
            }
          &nbsp;
            {this.state.userHasReadWriteRole && this.isValidFormCreate() && !this.state.formFields.approved ? (
              <Button
                disabled={!validateAllFormFields(this.state.formFields, this.state.initiatives)}
                onClick={debounce(this.createInitiative, 300, { leading: true })}
                style={{ marginTop: '20px' }}
              >Create</Button>) : null
            }
          </Form>
          <AlertList
            alerts={this.state.alerts}
            onDismiss={this.onAlertDismissed} // eslint-disable-line react/jsx-no-bind
            position="top-right"
          />
          <footer style={{ height: '20px' }} />
        </div>
      ) : (
        <MissingPermissionsComponent />
      )
  }
}
