import { InitiativeTagLabel } from './InitiativeTagLabel'
import { OverlayTrigger, Tooltip } from 'react-bootstrap'
import { appBaseUrl } from '../../../consts'
import {
  displayActivityIdInformation,
  displayFinanceCodeInformation,
  displayStatusInformation,
} from './InitiativeCardDisplay'
import Link from 'react-router/lib/Link'
import React from 'react'
import map from 'lodash/map'
import shouldPureComponentUpdate from 'react-pure-render/function'

class InitiativeCardComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      initiative: props.initiative,
      longestWordLength: props.longestWordLength || 0,
    }
  }

  componentWillReceiveProps(nextProps) {
    this.setState({ initiative: nextProps.initiative })
  }

  shouldComponentUpdate = shouldPureComponentUpdate

  render() {
    const initiative = this.state.initiative
    const initiativeName = initiative.initiative_name
    const tooltipText = <Tooltip id={initiativeName}>{initiativeName}</Tooltip>
    const additionalTextLength = initiativeName && this.props.longestWordLength ?
      (this.props.longestWordLength - initiative.initiative_name.length) : 0
    const additionalText = new Array(additionalTextLength).fill(' ').join(' ')
    const initiativeNameExtended = `${initiative.initiative_name}${additionalText}`

    return (
      <div className="element-item">
        <div className="card">
          <div className="card-header">
            <OverlayTrigger overlay={tooltipText} placement="top">
              <Link to={`${appBaseUrl}/initiative/${initiative.initiative_id}`}>
                <h4 className="card-title">{initiativeNameExtended}</h4>
              </Link>
            </OverlayTrigger>
          </div>
          <div className="card-body">
            <div className="card-block">
              <span style={{ float: 'right' }}>
                {!initiative.is_allocable ? <span style={{ fontStyle: 'italic' }}> Grouping Only </span> : ''}
              </span>
              {displayStatusInformation(this.state)}
            </div>
            <div>
              <p className="card-text">{this.props.initiativeTypesMap[initiative.type_id]}</p>
            </div>
            {displayFinanceCodeInformation(this.state)}
            {displayActivityIdInformation(this.state)}
            <div className="card-block">
              <div>
                {map(initiative.tags, tag => (
                  <div
                    key={tag.tagId || tag}
                    style={{
                      display: 'inline-block',
                      marginBottom: '0.5rem',
                    }}
                  >
                    <InitiativeTagLabel key={`${initiative.initiative_id}`} tagText={tag.tagValue || tag} />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default InitiativeCardComponent
