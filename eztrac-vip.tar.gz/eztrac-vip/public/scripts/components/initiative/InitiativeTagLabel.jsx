import { Label } from 'react-bootstrap'
import React from 'react'

export const InitiativeTagLabel = ({ tagText }) => (
  <Label key={`${tagText}`} style={{ marginRight: '3px', fontWeight: 'normal', fontSize: '85%' }}>
    {tagText}
  </Label>
)
