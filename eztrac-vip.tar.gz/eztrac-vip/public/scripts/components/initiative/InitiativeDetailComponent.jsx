import { InitiativeTagLabel } from './InitiativeTagLabel'
import {
  displayActivityIdInformation,
  displayFinanceCodeInformation,
  displayPortfolioCodeInformation,
  displayProgramCodeInformation,
  displayStatusInformation,
} from './InitiativeDetailDisplay'
import React from 'react'
import map from 'lodash/map'

const InitiativeDetailComponent = ({ initiative, tags, tagNameMap, typeName }) => {
  const renderGroupingOnly = () => {
    if ( !initiative.is_allocable ) {
      return (
        <span>
          <label htmlFor="init-detail-groupOnly" style={{ fontStyle: 'italic', fontWeight: 'normal' }}>
            Grouping Only
          </label>
        </span>
      )
    }

    return ''
  }

  return (
    <div>
      <div>
        <div className="row form-group">
          <span className="col-sm-3">
            <label htmlFor="init-detail-name">Initiative Name</label>
            <p id="initiativeName">{initiative.initiative_name}</p>
          </span>
          <span className="col-sm-1">
            <label htmlFor="init-detail-type">Type</label>
            <p id="initiativeType">{typeName}</p>
          </span>
          {displayStatusInformation(initiative)}
          {displayFinanceCodeInformation(initiative)}
          {displayPortfolioCodeInformation(initiative)}
          {displayActivityIdInformation(initiative)}
          {renderGroupingOnly()}
        </div>
        <div className="row form-group">
          <span className="col-sm-3" />
          {displayProgramCodeInformation(initiative)}
        </div>
      </div>
      <div>
        <span className="col-sm-5" style={{ paddingTop: '15px' }}>
          <p>
            {map(
              tags,
              (tag, type) =>
                tag ? <InitiativeTagLabel key={type} tagText={`${tagNameMap[type]}: ${tag.name}`} /> : null
            )}
          </p>
        </span>
      </div>
    </div>
  )
}

export default InitiativeDetailComponent
