import { Button, Modal } from 'react-bootstrap'
import { determineChildTypes } from '../../util/InitiativeTypeRules'
import { patchInitiative } from '../../util/InitiativeUtil'
import { sortByMatchingFirst } from '../../util/ReactSelectUtil'
import React from 'react'
import Select from 'react-select'
import forEach from 'lodash/forEach'
import getChangeParentOptions from '../../selectors/getChangeParentOptions'
import getOrElse from 'lodash/get'
import isEmpty from 'lodash/isEmpty'

const ModalButtons = ({
  saveDisabled,
  updateInitiative,
  closeModal,
}) => (
  <div className="row">
    <div className="col-md-4 col-md-offset-8">
      <div className="pull-right" style={{ marginTop: '5px' }}>
        <Button className="btn-margin-right" id="cancelButton" onClick={closeModal}>
          Cancel
        </Button>
        <Button
          bsStyle="primary"
          disabled={saveDisabled}
          id="saveButton"
          onClick={updateInitiative}
        >
          Save
        </Button>
      </div>
    </div>
  </div>
)

const ModalBody = ({
  setSelectedParent,
  parentOptions,
  initiative,
  selectedParent,
  selectedType,
  setSelectedType,
  updateInitiative,
  closeModal,
  typeOptions,
  setSearchString,
}) => (
  <Modal.Body>
    <label htmlFor="init-name">
      {`Changing Parent For: ${getOrElse(initiative, 'initiative_name', '')}`}
    </label>
    <Select
      className="form-group"
      id="newParent"
      name="newParentSelect"
      onChange={setSelectedParent}
      onInputChange={setSearchString}
      options={parentOptions}
      placeholder="Select a new parent"
      value={selectedParent}
    />
    <Select
      className="form-group"
      id="newType"
      name="newTypeSelect"
      onChange={setSelectedType}
      options={typeOptions}
      placeholder="Select a new type"
      value={selectedType}
    />
    <ModalButtons
      closeModal={closeModal}
      saveDisabled={!(selectedType && selectedParent)}
      updateInitiative={updateInitiative}
    />
  </Modal.Body>
)

export default class ChangeParentModal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      parentOptions: null,
      typeOptions: [],
      newParent: null,
      descendants: [],
      id: '',
      financeCodeValue: null,
      typeId: '',
      hasParent: false,
      selectedType: '',
      searchString: '',
    }
    this.updateInitiative = this.updateInitiative.bind(this)
    this.setDescendants = this.setDescendants.bind(this)
    this.unsetDescendants = this.unsetDescendants.bind(this)
  }

  async componentWillReceiveProps(nextProps) {
    if ( nextProps.show ) {
      this.setDescendants()
    } else if ( !nextProps.show ) {
      this.unsetDescendants()
    }
  }

  setSearchString = searchString => this.setState({ searchString })

  async setDescendants() {
    this.setState({
      initiativeTypes: this.props.initiativeTypes,
      descendants: this.props.descendants,
      id: this.props.initiative.initiative_id,
      financeCodeValue: this.props.initiative.finance_code_value,
      typeId: this.props.initiative.type_id,
      hasParent: !isEmpty(this.props.initiative.parent),
    })
  }

  setSelectedParent = target => {
    if ( !target ) {
      this.unsetDescendants()

      return
    }
    const selectedParent = target.value
    const typeOptions = determineChildTypes(selectedParent.type_id, this.props.initiativeTypes)
    const selectedType = typeOptions.length === 1 ? typeOptions[0] : ''
    this.setState({
      newParent: { label: selectedParent.initiative_name, value: selectedParent },
      typeOptions,
      selectedType })
  }

  unsetDescendants = () => {
    this.setState({ selectedType: '', newParent: null })
  }

  async updateInitiative() {
    forEach(this.props.descendants, child => {
      patchInitiative(child.id, { type_id: this.state.selectedType.value })
    })
    await patchInitiative(this.props.initiative.initiative_id, {
      parent: this.state.newParent.value.initiative_id,
      type_id: this.state.selectedType.value,
    })
    this.props.save({ ...this.props.initiative, type_id: this.state.selectedType.value })
  }

  render() {
    return (
      <Modal onHide={this.props.close} show={this.props.show}>
        <Modal.Header closeButton>
          <Modal.Title>{'Change Parent'}</Modal.Title>
        </Modal.Header>
        <ModalBody
          closeModal={this.props.close}
          initiative={this.props.initiative}
          parentOptions={sortByMatchingFirst(
            getChangeParentOptions({ ...this.props, ...this.state }), this.state.searchString)}

          selectedParent={this.state.newParent}
          selectedType={this.state.selectedType}
          setSearchString={this.setSearchString}
          setSelectedParent={target => { this.setSelectedParent(target) }}
          setSelectedType={selectedType => { this.setState({ selectedType }) }}
          typeOptions={this.state.typeOptions}
          updateInitiative={this.updateInitiative}
        />
      </Modal>
    )
  }
}
