import { CSVLink } from 'react-csv'
import { Glyphicon } from 'react-bootstrap'
import React from 'react'

const CSVDownloadButton = ({ allInitiatives, csvFileName, filteredInitiatives }) => {
  const INHERITED = '(inherited)'

  const getInheritedValue = property => {
    if ( property === null || property === undefined ) {
      return ''
    }

    return `${property} ${INHERITED}`
  }

  const getParent = parentId => {
    const parentInitiative = allInitiatives.find(i => i.initiative_id === parentId) || {}

    return {
      parent_id: parentInitiative.initiative_id,
      parent_name: parentInitiative.initiative_name,
      parent_finance_code_value: parentInitiative.finance_code_value ?
        parentInitiative.finance_code_value : getInheritedValue(parentInitiative.inherited_fin_code_value),
      parent_finance_code_type: parentInitiative.finance_code_type ?
        parentInitiative.finance_code_type : getInheritedValue(parentInitiative.inherited_fin_code_type),
      parent_portfolio_code: parentInitiative.portfolio_code ?
        parentInitiative.portfolio_code : getInheritedValue(parentInitiative.inherited_portfolio_code),
      parent_activity_id: parentInitiative.activity_id ?
        parentInitiative.activity_id : getInheritedValue(parentInitiative.inherited_activity_id),
      parent_status: parentInitiative.status ?
        parentInitiative.status : getInheritedValue(parentInitiative.inherited_status),
    }
  }

  const data = filteredInitiatives.map(i => ({
    initiative_id: i.initiative_id,
    initiative_name: i.initiative_name,
    status: i.status ? i.status : getInheritedValue(i.inherited_status),
    parent: i.parent,
    finance_code_type: i.finance_code_type ? i.finance_code_type : getInheritedValue(i.inherited_fin_code_type),
    finance_code_value: i.finance_code_value ? i.finance_code_value : getInheritedValue(i.inherited_fin_code_value),
    legacy_tag: i.legacy_tag,
    modified_by: i.modified_by,
    is_allocable: i.is_allocable,
    type_id: i.type_id,
    is_inheritable: i.is_inheritable,
    portfolio_code: i.portfolio_code ? i.portfolio_code : getInheritedValue(i.inherited_portfolio_code),
    activity_id: i.activity_id ? i.activity_id : getInheritedValue(i.inherited_activity_id),
    program_code: i.program_code ? i.program_code : getInheritedValue(i.inherited_program_code),
    ...getParent(i.parent),
  }))

  const keys = Object.keys(data[0])
  const headers = keys.map(key => ({ label: key, key }))

  return (
    <CSVLink
      className="btn btn-default btn-margin-right pull-right"
      data={data}
      filename={csvFileName}
      headers={headers}
      target="_blank"
    >
      <Glyphicon glyph="glyphicon glyphicon-download-alt" />
    </CSVLink>
  )
}

export default CSVDownloadButton
