import { INHERITED } from '../../../../common/constants'
import React from 'react'

export const displayFinanceCodeInformation = initiative => {
  if ( initiative.finance_code_value ) {
    return (
      <span className="col-sm-2">
        <label htmlFor="finance-code-type" id="financeCodeType">
          {initiative.finance_code_type || initiative.inherited_fin_code_type}
        </label>
        <p className="finance-code-value" id="financeCodeValue">{initiative.finance_code_value}</p>
      </span>
    )
  }

  const inheritedFinCodeValue = initiative.inherited_fin_code_value
  const inheritedFinCodeType = initiative.inherited_fin_code_type

  if ( inheritedFinCodeValue ) {
    return (
      <span className="col-sm-2">
        <label htmlFor="finance-code-type" id="financeCodeType">{inheritedFinCodeType}</label>
        <p className="inherited-text" id="financeCodeValue">{inheritedFinCodeValue} {INHERITED}</p>
      </span>
    )
  }

  return (
    <span className="col-sm-2">
      <label htmlFor="finance-code-type" id="financeCodeType">Finance Code</label>
      <p className="inherited-text" id="financeCodeValue">No Code</p>
    </span>
  )
}

export const displayStatusInformation = initiative => {
  const inheritedStatus = initiative.inherited_status

  if ( initiative.status ) {
    return (
      <span className="col-sm-1">
        <label htmlFor="init-detail-status">Status</label>
        <p id="initiativeStatus">{initiative.status}</p>
      </span>
    )
  }

  return (
    <span className="col-sm-1">
      <label htmlFor="init-detail-status">Status</label>
      <p className="inherited-text" id="initiativeStatus">
        {inheritedStatus} {INHERITED}
      </p>
    </span>
  )
}

export const displayPortfolioCodeInformation = initiative => {
  const inheritedPortfolioCode = initiative.inherited_portfolio_code

  if ( initiative.portfolio_code ) {
    return (
      <span className="col-sm-2">
        <label htmlFor="init-detail-portfolio-code">Portfolio Code</label>
        <p id="initiativePortfolioCode">{initiative.portfolio_code}</p>
      </span>
    )
  }

  if ( inheritedPortfolioCode ) {
    return (
      <span className="col-sm-2">
        <label htmlFor="init-detail-portfolio-code">Portfolio Code</label>
        <p className="inherited-text" id="initiativePortfolioCode">
          {inheritedPortfolioCode} {INHERITED}
        </p>
      </span>
    )
  }

  return (
    <span className="col-sm-2">
      <label htmlFor="init-detail-portfolio-code">Portfolio Code</label>
      <p className="inherited-text" id="initiativePortfolioCode">
          No Code
      </p>
    </span>
  )
}

export const displayActivityIdInformation = initiative => {
  const inheritedActivityId = initiative.inherited_activity_id

  if ( initiative.activity_id ) {
    return (
      <span className="col-sm-2">
        <label htmlFor="init-detail-activity-id">GET Activity Id</label>
        <p id="initiativeActivityId">{initiative.activity_id}</p>
      </span>
    )
  }

  if ( inheritedActivityId ) {
    return (
      <span className="col-sm-2">
        <label htmlFor="init-detail-activity-id">GET Activity Id</label>
        <p className="inherited-text" id="initiativeActivityId">
          {inheritedActivityId} {INHERITED}
        </p>
      </span>
    )
  }

  return (
    <span className="col-sm-2">
      <label htmlFor="init-detail-activity-id">GET Activity Id</label>
      <p className="inherited-text" id="initiativeActivityId">
          No Id
      </p>
    </span>
  )
}

export const displayProgramCodeInformation = initiative => {
  const inheritedProgramCode = initiative.inherited_program_code

  if ( initiative.program_code ) {
    return (
      <span className="col-sm-2">
        <label htmlFor="init-detail-program-code">Program Code</label>
        <p id="initiativeProgramCode">{initiative.program_code}</p>
      </span>
    )
  }

  if ( inheritedProgramCode ) {
    return (
      <span className="col-sm-2">
        <label htmlFor="init-detail-program-code">Program Code</label>
        <p className="inherited-text" id="initiativeProgramCode">
          {inheritedProgramCode} {INHERITED}
        </p>
      </span>
    )
  }

  return (
    <span className="col-sm-2">
      <label htmlFor="init-detail-program-code">Program Code</label>
      <p className="inherited-text" id="initiativeProgramCode">
          No Code
      </p>
    </span>
  )
}
