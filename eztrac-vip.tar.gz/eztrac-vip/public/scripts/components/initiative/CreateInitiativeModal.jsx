import { Modal } from 'react-bootstrap'
import BreadcrumbsComponent from '../BreadcrumbsComponent'
import InitiativeFormComponent from './InitiativeFormComponent'
import React from 'react'


export default class CreateInitiativeModal extends React.Component {
  closeModal = () => {
    this.props.close()
  }

  saveInitiative = async (initiative, createAnotherInitiative) => {
    await this.props.save({ initiative, isInEditMode: this.props.isInEditMode, createAnotherInitiative } )
  }

  render() {
    return (
      <Modal onHide={this.props.close} show={this.props.show}>
        <Modal.Header closeButton>
          <Modal.Title>{this.props.title}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="row">
            <div className="col-md-12">
              <BreadcrumbsComponent lineage={this.props.lineage} optionalClass="disabled" />
            </div>
          </div>
          <InitiativeFormComponent
            cancelAction={this.closeModal}
            childrenInitiatives={this.props.childrenInitiatives}
            createAnotherInitiative={this.props.createAnotherInitiative}
            financeCodeTypes={this.props.financeCodeTypes}
            initiative={this.props.initiative}
            initiativeStatuses={this.props.initiativeStatuses}
            initiativeTypes={this.props.initiativeTypes}
            initiatives={this.props.initiatives}
            isInEditMode={this.props.isInEditMode}
            isTopLevel={this.props.isTopLevel}
            lineage={this.props.lineage}
            parentTypeId={this.props.parentTypeId}
            saveInitiative={this.saveInitiative}
          />
        </Modal.Body>
      </Modal>
    )
  }
}
