import { INHERITED } from '../../../../common/constants'
import React from 'react'

export const displayFinanceCodeInformation = state => {
  if ( state.initiative.finance_code_value ) {
    return (
      <div className="card-block">
        <label htmlFor="finance-code-type">{state.initiative.finance_code_type}</label>
        <p className="card-text">{state.initiative.finance_code_value}</p>
      </div>
    )
  }

  const inheritedFinCodeValue = state.initiative.inherited_fin_code_value
  const inheritedFinCodeType = state.initiative.inherited_fin_code_type

  if ( inheritedFinCodeValue ) {
    return (
      <div className="card-block">
        <label htmlFor="finance-code-type">{inheritedFinCodeType}</label>
        <p className="card-text inherited-text">{inheritedFinCodeValue} {INHERITED}</p>
      </div>
    )
  }

  return (
    <div className="card-block">
      <label htmlFor="finance-code-type">{state.initiative.finance_code_type}</label>
      <p className="card-text inherited-text">Edit to enter fin code value</p>
    </div>
  )
}

export const displayActivityIdInformation = state => {
  if ( state.initiative.activity_id ) {
    return (
      <div className="card-block">
        <label htmlFor="finance-code-type">GET Activity ID</label>
        <p className="card-text">{state.initiative.activity_id}</p>
      </div>
    )
  }

  const inheritedActivityId = state.initiative.inherited_activity_id

  if ( inheritedActivityId ) {
    return (
      <div className="card-block">
        <label htmlFor="finance-code-type">GET Activity ID</label>
        <p className="card-text inherited-text">{inheritedActivityId} {INHERITED}</p>
      </div>
    )
  }

  return (
    <div className="card-block">
      <label htmlFor="finance-code-type">GET Activity ID</label>
      <p className="card-text inherited-text">Edit to enter GET ID</p>
    </div>
  )
}

export const displayStatusInformation = state => {
  const inheritedStatus = state.initiative.inherited_status
  if ( state.initiative.status ) {
    return <p className="card-text">{state.initiative.status}</p>
  }

  return <p className="card-text-inherited">{inheritedStatus} {INHERITED}</p>
}
