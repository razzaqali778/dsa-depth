/* eslint-disable wyze/max-file-length */
import { formatDateToday } from '../../util/formattedDateUtil'
import { narrowInitiatives, orderInitiatives } from '../../util/InitiativeUtil' // eslint-disable-line wyze/max-file-length
import Button from 'react-bootstrap/lib/Button'
import CSVDownloadButton from './CSVDownloadButton'
import Constants from '../../../../common/constants'
import Filter from '../FilterComponent'
import InitiativeCardComponent from './InitiativeCardComponent'
import PersistentStorageUtil from '../../util/PersistentStorageUtil'
import React from 'react'
import SearchComponent from '../SearchComponent'
import Select from 'react-select'
import UserRolesUtil from '../../util/UserRolesUtil'
import chunk from 'lodash/chunk'
import each from 'lodash/each'
import map from 'lodash/map'
import shouldPureComponentUpdate from 'react-pure-render/function'
import sortBy from 'lodash/sortBy'

class InitiativeCardsComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      initiatives: props.initiatives || [],
      searchText: PersistentStorageUtil.getField('searchText') || '',
      filteredInitiatives: props.initiatives || [],
      initiativeCategoryFilterOptions:
        (PersistentStorageUtil.getField('initiativeCategoryFilterOptions') || Constants.INITIATIVE_TYPE_OPTIONS),
      fundingStatusFilterOptions:
        (PersistentStorageUtil.getField('fundingStatusFilterOptions') || Constants.FUNDING_STATUS_OPTIONS),
      isTopLevel: props.isTopLevel,
      selectedInitiativeType: PersistentStorageUtil.getField('selectedInitiativeType') || '',
      userHasReadWriteRole: true,
    }
  }

  async componentDidMount() {
    const userHasReadWriteRole = await UserRolesUtil.hasReadWriteRole()
    this.setState({ userHasReadWriteRole }) // eslint-disable-line react/no-did-mount-set-state
  }

  componentWillReceiveProps(nextProps) {
    const sortedInitiatives = orderInitiatives(nextProps.initiatives, 'initiative_name')
    // const userHasReadWriteRole = await UserRolesUtil.hasReadWriteRole()
    if ( nextProps.isTopLevel ) {
      const filteredInitiatives = narrowInitiatives(
        nextProps.initiatives,
        this.state.searchText,
        this.state.initiativeCategoryFilterOptions,
        this.state.fundingStatusFilterOptions,
        this.state.selectedInitiativeType.value,
      )
      this.setState({ filteredInitiatives, initiatives: sortedInitiatives })
    } else {
      this.setState({ initiatives: sortedInitiatives, filteredInitiatives: sortedInitiatives })
    }
  }

  shouldComponentUpdate = shouldPureComponentUpdate

  getCSVFileName = () => {
    const formattedToday = formatDateToday()
    if ( this.state.filteredInitiatives.length !== this.state.initiatives.length ) {
      return `Initiative Portfolio (filtered) ${formattedToday}`
    }

    return `Initiative Portfolio ${formattedToday}`
  }

  handleInputChange = value => {
    this.setState({
      searchText: value,
      filteredInitiatives: narrowInitiatives(
        this.state.initiatives,
        value,
        this.state.initiativeCategoryFilterOptions,
        this.state.fundingStatusFilterOptions,
        this.state.selectedInitiativeType.value,
      ),
    })

    PersistentStorageUtil.addField('searchText', value)
  }

  handleInitiativeTypeSelect = selectedType => {
    this.setState({
      selectedInitiativeType: selectedType,
      filteredInitiatives: narrowInitiatives(
        this.state.initiatives,
        this.state.searchText,
        this.state.initiativeCategoryFilterOptions,
        this.state.fundingStatusFilterOptions,
        selectedType.value,
      ),
    })

    PersistentStorageUtil.addField('selectedInitiativeType', selectedType)
  }

  toggleRadioFilterOption = selectedOption => {
    const initiativeCategoryFilterOptions = this.state.initiativeCategoryFilterOptions
    each(initiativeCategoryFilterOptions, option => {
      option.active = false // eslint-disable-line no-param-reassign
    })
    initiativeCategoryFilterOptions[selectedOption].active = true
    this.setState({
      initiativeCategoryFilterOptions,
      filteredInitiatives: narrowInitiatives(
        this.state.initiatives,
        this.state.searchText,
        initiativeCategoryFilterOptions,
        this.state.fundingStatusFilterOptions,
        this.state.selectedInitiativeType.value
      ),
    })
    PersistentStorageUtil.addField('initiativeCategoryFilterOptions', initiativeCategoryFilterOptions)
  }

  toggleCheckboxFilterOption = optionId => {
    const fundingStatusFilterOptions = this.state.fundingStatusFilterOptions
    const selectedOption = fundingStatusFilterOptions[optionId]

    if ( optionId !== 'all' && fundingStatusFilterOptions.all.active ) {
      fundingStatusFilterOptions.all.active = false
      selectedOption.active = !selectedOption.active
    } else if ( optionId === 'all' && !fundingStatusFilterOptions.all.active ) {
      each(fundingStatusFilterOptions, option => {
        option.active = true // eslint-disable-line no-param-reassign
      })
    } else {
      selectedOption.active = !selectedOption.active
    }

    const filteredInitiatives = narrowInitiatives(
      this.state.initiatives,
      this.state.searchText,
      this.state.initiativeCategoryFilterOptions,
      fundingStatusFilterOptions,
      this.state.selectedInitiativeType.value,
    )
    this.setState({ filteredInitiatives, fundingStatusFilterOptions })
    PersistentStorageUtil.addField('fundingStatusFilterOptions', fundingStatusFilterOptions)
  }


  renderCards = () => {
    const chunksAmount = Math.floor(Math.min(window.innerWidth, 1195) / 220)
    const initiatives = chunk(this.state.filteredInitiatives, chunksAmount)

    return (<div className="row full-screen list-container">
      {(initiatives).map(initiativeChunk => {
        const longestWord = Math.max(...(initiativeChunk.map(el =>
          el.initiative_name ? el.initiative_name.length : 0)))

        return map(initiativeChunk, (initiative, index) => (<InitiativeCardComponent
          initiative={initiative}
          initiativeTypesMap={this.props.initiativeTypesMap}
          key={`card${index}`}
          longestWordLength={longestWord}
        />)
        )
      })}
    </div>)
  }

  renderNoInitiatives = () => (
    <div>
      <div className="row">
        <div className="col-md-2 col-md-offset-10">
          {this.renderCreateButton()}
        </div>
      </div>
      <div className="row">
        <div className="col-md-12">
          <div className="bs-callout bs-callout-info">
            There are no initiatives to display. Add an initiative!
          </div>
        </div>
      </div>
    </div>
  )

  renderCreateButton = () => (
    this.state.userHasReadWriteRole
      ? (
        <Button
          bsStyle="success"
          className="pull-right"
          disabled={this.props.typeId === 'UNKNOWN'}
          id="initiativeButton"
          onClick={this.props.buttonAction}
        >
          {this.props.buttonText}
        </Button>
      )
      : null
  )

  renderCSVDownloadComponent = () => (
    this.state.filteredInitiatives.length > 0 ? (
      <CSVDownloadButton
        allInitiatives={this.state.initiatives}
        csvFileName={this.getCSVFileName()}
        filteredInitiatives={this.state.filteredInitiatives}
      />
    ) : null
  )

  renderInitiativeCategoryFilterOptions = () => (
    <Filter
      changeAction={arg => { this.toggleRadioFilterOption(arg) }}
      options={this.state.initiativeCategoryFilterOptions}
      type="radio"
    />
  )

  renderFundingStatusFilterOptions = () => (
    <Filter
      changeAction={arg => { this.toggleCheckboxFilterOption(arg) }}
      options={this.state.fundingStatusFilterOptions}
      type="checkbox"
    />
  )

  renderFilterOptions = () =>
    this.props.isTopLevel
      ? (
        <div>
          <div className="filter-search-options">
            <label htmlFor="funding-status">Filter By Funding Status: </label>
            {this.renderFundingStatusFilterOptions()}
          </div>
          <div className="filter-search-options">
            <label htmlFor="initiative">Filter By Initiative Category: </label>
            {this.renderInitiativeCategoryFilterOptions()}
          </div>
        </div>
      )
      : null

  renderSearchComponent = () =>
    this.props.isTopLevel
      ? <SearchComponent searchAction={this.handleInputChange} searchText={this.state.searchText} />
      : null

  renderNumberOfInitiativesFound = () => (
    <div className="row">
      <div className="col-md-3">
        <div className="number-of-initiatives">
          Initiatives Found: {this.state.filteredInitiatives.length} of {this.state.initiatives.length}
        </div>
      </div>
    </div>
  )

  renderInitiativeTypeComponent = () =>
    this.props.isTopLevel
      ? (
        <div className="filter-initiative-type col-md-4">
          <label htmlFor="initiative-type">Filter By Initiative Type: </label>
          <Select
            id="initiative_type"
            name="initiative_type_select"
            onChange={event => {
              this.handleInitiativeTypeSelect(event)
            }}
            options={sortBy(this.props.initiativeTypes, 'label')}
            placeholder="Choose Initiative Type"
            resetValue={{ value: '', label: '' }}
            value={this.state.selectedInitiativeType.value}
          />
        </div>
      )
      : null

  render() {
    return this.state.initiatives.length === 0
      ? (
        <div className="full-screen">
          {this.renderNoInitiatives()}
        </div>
      )
      : (
        <div className="full-screen">
          <div className="row">
            <div className="col-md-12">
              {this.renderCreateButton()}
              {this.renderCSVDownloadComponent()}
            </div>
          </div>
          <div className="row">
            <div className="col-md-12">
              {this.renderFilterOptions()}
            </div>
          </div>
          <div className="row type-dropdown">
            <div>
              {this.renderSearchComponent()}
              {this.renderInitiativeTypeComponent()}
            </div>
          </div>
          {this.renderNumberOfInitiativesFound()}
          {this.renderCards()}
        </div>
      )
  }
}

export default InitiativeCardsComponent
