import { Button, Checkbox } from 'react-bootstrap' // eslint-disable-line wyze/max-file-length
import { INHERITED } from '../../../../common/constants'
import { determineChildTypes, determineEditTypes, getInitiativeTypeRules } from '../../util/InitiativeTypeRules'
import { isFieldEmpty, validateAllFields } from '../../util/InitiativeValidator'
import React from 'react'
import Select from 'react-select'
import filter from 'lodash/filter'
import find from 'lodash/find'
import forEach from 'lodash/forEach'
import isEqual from 'lodash/isEqual'

const errorTargets = [
  'initiative_name',
  'type_id',
  'finance_code_value',
  'initiative_allocation_value',
  'status' ]

const allowedTopLevelInitiatives = [ 'CAP-PROJ', 'EXP-INIT', 'ENH' ]

export default class InitiativeFormComponent extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      initiative: { is_allocable: true, is_inheritable: true, ...props.initiative } || {
        is_allocable: true,
        is_inheritable: true,
      },
      createAnotherInitiative: props.createAnotherInitiative,
      initiative_name_field_class: 'col-md-6',
      initiative_name_error_message: ' ',
      status_field_class: 'col-md-6',
      status_error_message: ' ',
      type_id_field_class: 'col-md-6',
      type_id_error_message: ' ',
      financeCodeTypeLabel: props.initiative ? props.initiative.finance_code_type : 'Finance Code',
      finance_code_value_field_class: 'col-md-6',
      finance_code_value_error_message: ' ',
      initiative_allocation_value_field_class: 'col-md-6',
      initiative_allocation_value_error_message: ' ',
      saveDisabled: true,
      allocationCheckboxDisabled: false,
      hideFinanceCodeInheritableCheckbox: false,
      hideFinanceCodeInput: false,
    }

    this.saveInitiative = this.saveInitiative.bind(this)
  }

  componentWillMount() {
    const childTypes = this.determineTypeOptions()
    if ( childTypes.length === 1 && !this.props.isInEditMode ) {
      this.handleTypeSelection(childTypes[0])
    }
  }

  componentDidMount() {
    if ( this.props.initiative && !this.state.initiative.type_id ) {
      const errorsArray = validateAllFields(
        this.props.initiative,
        this.props.initiatives
      ) || []

      this.displayErrors(errorsArray)
    }
  }

  componentWillReceiveProps(nextProps) {
    if ( nextProps.initiative ) {
      this.setState({ initiative: nextProps.initiative })
    }
  }

  setCompletedStatus = evt => {
    const getValue = () => {
      if ( evt.target.checked ) {
        return 'Completed'
      }

      return null
    }

    const initiative = {
      ...this.state.initiative,
      status: getValue(),
    }

    this.handleValidation(initiative, 'status')
  }

  determineFinanceCodeLabel() {
    if ( this.props.initiative ) {
      if ( this.props.initiative.finance_code_type ) {
        return this.props.initiative.finance_code_type
      } else if ( this.props.initiative.inherited_fin_code_type ) {
        return this.props.initiative.inherited_fin_code_type
      }
    }

    return 'Finance Code'
  }

  displayFinanceCodeValueLabel() {
    if ( this.state.initiative.type_id && !this.state.hideFinanceCodeInput ) {
      return (
        <div className={this.state.finance_code_value_field_class} id="financeCodeValueField">
          <label className="control-label" htmlFor="finance-code-val">
            {' '}
            {this.determineFinanceCodeLabel()}{' '}
          </label>
          <input
            className="form-control"
            id="financeCodeValue"
            onChange={evt => this.updateField('finance_code_value', evt)}
            placeholder={
              this.state.initiative.finance_code_value ||
              (this.state.initiative.inherited_fin_code_value
                ? `${this.state.initiative.inherited_fin_code_value} ${INHERITED}`
                : 'Enter the finance code value')
            }
            type="text"
            value={this.state.initiative.finance_code_value || ''}
          />
          <p className="text-danger" id="financeCodeValueErrorMessage">
            {this.state.finance_code_value_error_message}
          </p>
        </div>
      )
    }

    return ''
  }

  handleTypeSelection(selectedType) {
    if ( selectedType && selectedType.value !== '' ) {
      const rules = getInitiativeTypeRules(selectedType, this.state.initiative)
      this.setState(rules)
      if ( selectedType.id === 'finance_code_value' ) {
        this.handleValidation(rules.initiative, 'finance_code_value')
      } else {
        this.handleValidation(rules.initiative, 'type_id')
      }
    } else {
      const ourInitiative = {
        ...this.state.initiative,
        finance_code_type: '',
        type_id: selectedType.value,
        type_name: selectedType.label,
        is_allocable: true,
      }
      this.setState({
        allocationCheckboxDisabled: false,
        financeCodeTypeLabel: ' ',
        initiative: ourInitiative,
      })
      if ( selectedType.id === 'financeCodeValue' ) {
        this.handleValidation(ourInitiative, 'finance_code_value')
      } else {
        this.handleValidation(ourInitiative, 'type_id')
      }
    }
  }

  resetErrors = target => {
    const newState = {
      [`${target}_field_class`]: 'col-md-6',
      [`${target}_error_message`]: '',
    }
    if ( target === 'finance_code_value' ) {
      newState.finance_code_value_field_class = 'col-md-6'
      newState.finance_code_value_error_message = ''
    }

    this.setState(newState)
  }

  displayErrors = errors => {
    const newState = {}
    forEach(errorTargets, target => {
      const error = find(errors, { errorType: target })
      if ( error ) {
        const errorMessage = error.errorMessage
        newState[`${target}_field_class`] = 'col-md-6 has-error'
        newState[`${target}_error_message`] = errorMessage
      }
    })
    this.setState(newState)
  }

  saveInitiative = async () => {
    const valEmpty = isFieldEmpty(this.state.initiative.finance_code_value)
    const typeEmpty = isFieldEmpty(this.state.initiative.finance_code_type)
    if ( !valEmpty && typeEmpty ) {
      const saveInit = getInitiativeTypeRules({ value: this.state.initiative.type_id }, this.state.initiative)
        .initiative // eslint-disable-line max-len
      await this.props.saveInitiative(saveInit, this.state.createAnotherInitiative)
    } else if ( valEmpty ) {
      const saveInit = { ...this.state.initiative, finance_code_type: null }
      await this.props.saveInitiative(saveInit, this.state.createAnotherInitiative)
    } else {
      await this.props.saveInitiative(this.state.initiative, this.state.createAnotherInitiative)
    }
  }

  updateField = (id, evt) => {
    const getValue = () => {
      if ( evt.target ) {
        if ( evt.target.type === 'checkbox' ) {
          if ( evt.target.id === 'allocationCheckbox' || evt.target.id === 'isInheritableCheckbox' ) {
            return id === 'is_allocable' ? !evt.target.checked : evt.target.checked
          }

          return evt.target.checked
        }

        return evt.target.value
      }

      return evt.value
    }

    const initiative = {
      ...this.state.initiative,
      [id]: getValue(),
    }

    if ( id === 'status' || id === 'is_allocable' ) {
      this.handleValidation(initiative, 'finance_code_value')
    }

    this.handleValidation(initiative, id)
  }

  handleValidation = (initiative, id) => {
    const errorsArray =
      validateAllFields(
        initiative,
        this.props.initiatives
      ) || []
    const hasErrors = errorsArray.length > 0
    const notChanged = isEqual(this.props.initiative, initiative)
    this.setState({ saveDisabled: hasErrors || notChanged, initiative })
    this.resetErrors(id)

    this.displayErrors(errorsArray)
  }

  determineTypeOptions() {
    if ( this.props.isInEditMode ) {
      return determineEditTypes(
        this.state.initiative.type_id,
        this.props.parentTypeId,
        this.props.childrenInitiatives,
        this.props.initiativeTypes
      )
    }

    if ( this.props.isTopLevel ) {
      const availableTypes = filter(
        this.props.initiativeTypes,
        type => allowedTopLevelInitiatives.includes(type.value)
      )

      return availableTypes
    }

    if ( this.props.parentTypeId ) {
      return determineChildTypes(this.props.parentTypeId, this.props.initiativeTypes)
    }

    return []
  }

  renderPortfolioCodeInformation() {
    return (
      <div className="control-label" id="portfolioCodeField">
        <label className="control-label" htmlFor="portfolio_code">
          Portfolio Code
        </label>
        <input
          className="form-control"
          id="portfolioCode"
          onChange={evt => this.updateField('portfolio_code', evt)}
          placeholder={
            this.state.initiative.portfolio_code ||
            (this.state.initiative.inherited_portfolio_code
              ? `${this.state.initiative.inherited_portfolio_code} ${INHERITED}`
              : 'Enter the portfolio code')
          }
          type="text"
          value={this.state.initiative.portfolio_code || ''}
        />
        <p className="text-danger" id="portfolioCodeErrorMessage">
          {this.state.portfolio_code_error_message}
        </p>
      </div>
    )
  }

  renderActivityIdInformation() {
    return (
      <div className="control-label" id="activityIdField">
        <label className="control-label" htmlFor="activity_id">
          GET Activity ID
        </label>
        <input
          className="form-control"
          id="activityId"
          onChange={evt => this.updateField('activity_id', evt)}
          placeholder={
            this.state.initiative.activity_id ||
            (this.state.initiative.inherited_activity_id
              ? `${this.state.initiative.inherited_activity_id} ${INHERITED}`
              : 'Enter the GET activity id')
          }
          type="text"
          value={this.state.initiative.activity_id || ''}
        />
        <p className="text-danger" id="activityIdErrorMessage">
          {this.state.activity_id_error_message}
        </p>
      </div>
    )
  }

  renderProgramCodeInformation() {
    return (
      <div className="control-label" id="programCodeField">
        <label className="control-label" htmlFor="program_code">
          Program Code
        </label>
        <input
          className="form-control"
          id="programCode"
          onChange={evt => this.updateField('program_code', evt)}
          placeholder={
            this.state.initiative.program_code ||
            (this.state.initiative.inherited_program_code
              ? `${this.state.initiative.inherited_program_code} ${INHERITED}`
              : 'Enter the program code')
          }
          type="text"
          value={this.state.initiative.program_code || ''}
        />
        <p className="text-danger" id="programCodeErrorMessage">
          {this.state.program_code_error_message}
        </p>
      </div>
    )
  }

  renderInheritedStatus() {
    if ( this.state.initiative.inherited_status === 'Completed' ) {
      return <div>Completed</div>
    }
    if ( this.state.initiative.status === 'Completed' ) {
      return (
        <div>
          <Checkbox
            checked={this.state.initiative.status === 'Completed'}
            id="isStatusInformation"
            onChange={evt => this.setCompletedStatus(evt)}
            style={{ marginLeft: '2px' }}
          >
            Completed
          </Checkbox>
        </div>
      )
    }

    return (
      <div>
        <span className="inherited-text">{this.state.initiative.inherited_status} {INHERITED}</span>
        <div>
          <Checkbox
            checked={this.state.initiative.status === 'Completed'}
            id="isStatusInformation"
            onChange={evt => this.setCompletedStatus(evt)}
            style={{ marginLeft: '2px' }}
          >
            Completed
          </Checkbox>
        </div>
      </div>
    )
  }

  renderStatusInformation() {
    return (
      <div>
        <Select
          id="status"
          name="statusSelect"
          onChange={evt => this.updateField('status', evt)}
          options={this.props.initiativeStatuses}
          placeholder="Select a status"
          resetValue={{ value: '', label: '' }}
          value={this.state.initiative.status || ''}
        />
        <p className="text-danger" id="statusErrorMessage">
          {this.state.status_error_message}
        </p>
      </div>
    )
  }

  renderInheritableCheckBox() {
    const groupingOnly = !this.state.initiative.is_allocable
    if ( this.state.hideFinanceCodeInheritableCheckbox ) {
      return null
    }

    if ( groupingOnly ) {
      return (
        <div className={this.state.initiative_allocation_value_field_class} id="initiativeIsInheritableValueField">
          <Checkbox
            checked={
              Object.prototype.hasOwnProperty.call(this.state.initiative, 'is_inheritable')
                ? this.state.initiative.is_inheritable
                : false
            }
            id="isInheritableCheckbox"
            onChange={evt => this.updateField('is_inheritable', evt)}
            style={{ marginLeft: '2px', float: 'left' }}
          >
            Finance code value is inheritable
          </Checkbox>
        </div>
      )
    }

    return null
  }

  render() {
    return (
      <div>
        <div className="row form-group">
          <div className={this.state.initiative_name_field_class} id="nameField">
            <label className="control-label" htmlFor="initiative-name">
              Initiative Name
            </label>
            <input
              className="form-control"
              id="initiative_name"
              onChange={evt => this.updateField('initiative_name', evt)}
              placeholder="Enter initiative name"
              type="text"
              value={this.state.initiative.initiative_name || ''}
            />
            <p className="text-danger" id="initiativeNameErrorMessage">
              {this.state.initiative_name_error_message}
            </p>
          </div>

          <div className={this.state.type_id_field_class} id="typeField">
            <label className="control-label" htmlFor="initiative-type-val">
              Initiative Type
            </label>
            <Select
              id="type_id"
              name="initiativeTypeSelect"
              onChange={event => {
                this.handleTypeSelection(event)
              }}
              options={this.determineTypeOptions()}
              placeholder="Select an Initiative Type"
              resetValue={{ value: '', label: '' }}
              value={this.state.initiative.type_id}
            />
            <p className="text-danger" id="initiativeTypeErrorMessage">
              {this.state.type_id_error_message}
            </p>
          </div>
        </div>
        <div className="row form-group">
          <div className={this.state.status_field_class} id="statusField">
            <label className="control-label" htmlFor="initiative-status">
              Status
            </label>
            {this.state.initiative.parent ? this.renderInheritedStatus() : this.renderStatusInformation()}
          </div>
          {this.displayFinanceCodeValueLabel()}
        </div>
        <div className="row form-group">
          <div className="col-md-6" id="activityIdField">
            {this.renderActivityIdInformation()}
          </div>
          <div className="col-md-6" id="portfolioCodeField">
            {this.renderPortfolioCodeInformation()}
          </div>
          <div />
        </div>
        <div className="row form-group">
          <div className="col-md-6" id="programCodeField">
            {this.renderProgramCodeInformation()}
          </div>
        </div>
        <div className="row form-group">
          <div className={this.state.initiative_allocation_value_field_class} id="initiativeAllocationValueField">
            <Checkbox
              checked={
                Object.prototype.hasOwnProperty.call(this.state.initiative, 'is_allocable')
                  ? !this.state.initiative.is_allocable
                  : false
              }
              disabled={this.state.allocationCheckboxDisabled}
              id="allocationCheckbox"
              onChange={evt => this.updateField('is_allocable', evt)}
              style={{ marginLeft: '2px', float: 'left' }}
            >
              Grouping Only
            </Checkbox>
            <p className="text-danger" id="initiativeAllocationValueErrorMessage">
              {this.state.initiative_allocation_value_error_message}
            </p>
          </div>
          {this.renderInheritableCheckBox()}
        </div>

        <div className="row">
          <div className="pull-right" style={{ marginRight: '15px' }}>

            <span hidden={this.props.isInEditMode} >
              <Checkbox
                checked={this.state.createAnotherInitiative}
                id="createAnotherInitiativeCheckbox"
                onChange={() => this.setState({ createAnotherInitiative: !this.state.createAnotherInitiative })}
                style={{ marginRight: '17px' }}
              >
                    Create Another
              </Checkbox>
            </span>
            <Button className="btn-margin-right" id="cancelButton" onClick={this.props.cancelAction}>
                Cancel
            </Button>
            <Button
              bsStyle="primary"
              disabled={this.state.saveDisabled}
              id="saveButton"
              onClick={this.saveInitiative}
            >
                Save
            </Button>

          </div>
        </div>
      </div>
    )
  }
}
