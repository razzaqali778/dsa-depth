import { Button, Modal } from 'react-bootstrap'
import { INHERITED } from '../../../../common/constants'
import { buildTagsToSend, fetchAncestralTags, fetchTagOptions, saveTags } from '../../util/tagUtil'
import React from 'react'
import Select from 'react-select'
import getOrElse from 'lodash/get'
import map from 'lodash/map'
import pickBy from 'lodash/pickBy'

export default class ChangeTagsModal extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      saveDisabled: false,
      tagOptions: {},
      newTags: { REGION: { name: null }, 'BUS-UNIT': { name: null } },
      ancestralTags: [],
    }
    this.updateTags = this.updateTags.bind(this)
  }
  async componentDidMount() {
    const tagOptions = await fetchTagOptions()
    this.setState({ tagOptions }) // eslint-disable-line react/no-did-mount-set-state
  }

  async componentWillReceiveProps(nextProps) {
    if ( nextProps.tags && this.props.tags !== nextProps.tags ) {
      this.setState({ newTags: nextProps.tags })
    }

    if ( nextProps.initiative && this.props.initiative !== nextProps.initiative ) {
      const ancestralTags = await fetchAncestralTags(nextProps.initiative.initiative_id)
      this.setState({ ancestralTags })
    }
  }

  async updateTags() {
    const tagsToUpdate = pickBy(this.state.newTags, (val, key) => val.name !== this.props.tags[key])
    await saveTags(this.props.initiative.initiative_id, tagsToUpdate)
    const tagsToSend = buildTagsToSend(this.state.newTags, this.state.ancestralTags)

    this.props.updateTags(tagsToSend)
  }

  cancel = () => {
    this.setState({ newTags: this.props.tags })
    this.props.close()
  }

  defineTagPlaceholder = type => {
    if ( this.props.initiative.parent ) {
      const inheritedTag = this.state.ancestralTags.find(
        ancestorTag => ancestorTag.level !== 0 && ancestorTag.tag_id && ancestorTag.tag_id === type
      )
      if ( inheritedTag ) {
        return `${inheritedTag.tag_value} ${INHERITED}`
      }
    }

    return 'No Tag'
  }
  renderSaveButtons = () => (
    <div className="row">
      <div className="col-md-4 col-md-offset-8">
        <div className="pull-right" style={{ marginTop: '5px' }}>
          <Button className="btn-margin-right" id="cancelButton" onClick={this.cancel}>
            Cancel
          </Button>
          <Button bsStyle="primary" disabled={this.state.saveDisabled} id="saveButton" onClick={this.updateTags}>
            Save
          </Button>
        </div>
      </div>
    </div>
  )

  render() {
    return (
      <Modal onHide={this.cancel} show={this.props.show}>
        <Modal.Header closeButton>
          <Modal.Title>{`Change Tags For: ${getOrElse(this.props.initiative, 'initiative_name', '')}`}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {map(this.state.tagOptions, (optsArray, type) => {
            const selectOpts = map(optsArray, opt => ({ label: opt, value: opt }))
            const defaultTagValue = getOrElse(this.props.tags, type, { name: null })
            const tagObject = getOrElse(this.state.newTags, type, defaultTagValue)

            return (
              <div className="col-md-12" key={type}>
                <label className="col-md-3" htmlFor={type} style={{ lineHeight: '34px', padding: 0 }}>
                  {getOrElse(this.props.tagNameMap, type, type)} :
                </label>
                <Select
                  className="form-group col-md-9"
                  id={`${type}Select`}
                  name={`${type}Select`}
                  onChange={target =>
                    this.setState({
                      newTags: {
                        ...this.state.newTags,
                        [type]: { name: getOrElse(target, 'value', null), inherited: false },
                      },
                    })
                  }
                  options={selectOpts}
                  placeholder={this.defineTagPlaceholder(type)}
                  value={tagObject.inherited ? null : tagObject.name}
                />
              </div>
            )
          })}
          {this.renderSaveButtons()}
        </Modal.Body>
      </Modal>
    )
  }
}
