import { getInitiativeLink, getProfileLink } from '../util/AuditUtil'
import AutoSizer from 'react-virtualized/dist/commonjs/AutoSizer'
import List from 'react-virtualized/dist/commonjs/List'
import Moment from 'moment'
import React from 'react'
import capitalize from 'lodash/capitalize'
import filter from 'lodash/filter'
import keys from 'lodash/keys'
import map from 'lodash/map'
import toString from 'lodash/toString'

const Diff = ({ previous, changed }) => (
  <span>
    { previous && previous !== '' ? <span className="previous-audit">{previous}</span> : null }
    { changed && changed !== '' ? <span className="changed-audit">{changed}</span> : null }
  </span>
)

const isDefined = val => val !== null || val !== undefined

const AuditCards = ({ audits }) => {
  const calcRowHeight = () => ({ index }) => {
    const elemHeight = 20
    const audit = audits[index]
    const count = keys(audit).length

    return elemHeight * ( count + 2 )
  }
  const makeRowRenderer = () => ({
    index,
    key,
    style,
  }) => {
    const audit = audits[index]
    const getRowStyle = () => index % 2 === 0
      ? { ...style, backgroundColor: '#f5f5f5', maxHeight: (style.height - 10) }
      : { ...style, backgroundColor: '#fff', maxHeight: (style.height - 10) }
    const renderVal = k => {
      const v = audit[k]
      const prev = isDefined(audit[`${k}_prev`]) ? toString(audit[`${k}_prev`]) : null

      if ( k === 'modified_time' ) {
        const time = new Moment(v)

        return `${time.format('dddd, MMMM Do YYYY')} -- ${time.fromNow()}`
      } else if ( k === 'modified_by' ) {
        return <a href={getProfileLink(v)} target="_blank" >{v}</a>
      } else if ( k === 'initiative_id' || ( k === 'parent' && !prev ) ) {
        return <a href={getInitiativeLink(v)} target="_blank" >{v}</a>
      } else if ( k === 'parent' ) {
        const changed = v ? <a href={getInitiativeLink(v)} target="_blank" >{v}</a> : 'none'

        return <Diff changed={changed} previous={prev || 'none'} />
      }

      if ( prev ) {
        return <Diff changed={toString(v)} previous={toString(prev)} />
      } else if ( isDefined(v) ) {
        return toString(v)
      }

      return '-'
    }
    const renderKey = k => capitalize(k.replace(/[_]+/g, ' '))
    const keysToRender = filter(keys(audit), k => !k.includes('_prev'))

    return (
      <div className="audit-row" key={key} style={getRowStyle()}>
        {
          map(keysToRender, k => (
            <div key={`${key}:${k}`}>
              <dd><b>{renderKey(k)}:</b> {renderVal(k)}</dd>
            </div>
          ))
        }
      </div>
    )
  }

  return (
    audits.length > 0
      ? <AutoSizer>
        {
          ({ width, height }) =>
            (<List
              height={height < 400 ? 400 : height}
              rowCount={audits.length}
              rowHeight={calcRowHeight()}
              rowRenderer={makeRowRenderer()}
              width={width}
            />)
        }
      </AutoSizer>
      : <h3> There are no audits to show </h3>
  )
}

export default AuditCards
