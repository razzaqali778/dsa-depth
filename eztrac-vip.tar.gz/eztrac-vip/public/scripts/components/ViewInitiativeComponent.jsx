/* eslint-disable wyze/max-file-length */
import { AlertList } from 'react-bs-notifier'
import { Button, Tab, Tabs } from 'react-bootstrap'
import { appBaseUrl, localVipServicesUrl } from '../../consts'
import { fetchDescendants } from '../util/changeParentUtils'
import { fetchTagNameMap, fetchTagsByInitiative } from '../util/tagUtil'
import { formatFinanceCodeTypes, formatInitiativeStatuses, formatInitiativeTypes } from '../util/InitiativeUtil'
import { getAllTimeFrames, getFiscalYears } from '../util/TimeFramesYearsUtil'
import { getInitiativeInheritedDetails } from '../../../services/v1/initiativeUtils/getInheritedFundingDetail'
import { getInitiatives } from '../util/InitiativeValidator'
import { getLineageForBreadcrumbs } from '../util/BreadcrumbUtil'
import AlertUtil from '../util/AlertUtil'
import BreadcrumbsComponent from './BreadcrumbsComponent'
import BudgetListComponent from './budget/BudgetListComponent'
import ChangeParentModal from './initiative/ChangeParentModal'
import ChangeTagsModal from './initiative/ChangeTagsModal'
import CreateInitiativeModal from './initiative/CreateInitiativeModal'
import InitiativeCardsComponent from './initiative/InitiativeCardsComponent'
import InitiativeDetailComponent from './initiative/InitiativeDetailComponent'
import LoadingBlocker from './LoadingBlocker'
import MissingPermissionsComponent from './MissingPermissionsComponent'
import React from 'react'
import UserRolesUtil from '../util/UserRolesUtil'
import agent from '../../agent'
import cloneDeep from 'lodash/cloneDeep'
import filter from 'lodash/filter'
import find from 'lodash/find'
import getOrElse from 'lodash/get'
import isEmpty from 'lodash/isEmpty'
import isUndefined from 'lodash/isUndefined'
import map from 'lodash/map'
import reduce from 'lodash/reduce'

const vipApiUrl = getOrElse(
  window,
  'phoenix.urls.services.ez-trac-vip',
  localVipServicesUrl
)
const getInitiativeStatusUrl = `${vipApiUrl}/v1/referenceData/initiativeStatus`
const getFinanceCodeTypeUrl = `${vipApiUrl}/v1/referenceData/financialTagTypes`
const getInitiativeUrl = `${vipApiUrl}/v1/getInitiative`
const getChildInitiativesUrl = `${vipApiUrl}/v1/getChildInitiatives`
const createInitiativeUrl = `${vipApiUrl}/v1/createInitiative`
const updateInitiativeUrl = `${vipApiUrl}/v1/updateInitiative`
const getBudgetsByInitiativeUrl = initiativeId => `${vipApiUrl}/v2/budgets/${initiativeId}?includeSplits=true`
const getInitiativeTypesUrl = `${vipApiUrl}/v1/initiativeTypes`

const millisecondsPerHour = 3600000

const enhancementInitiativeId = getOrElse(window, 'phoenix.enhancementInitiativeId', '')

class ViewInitiativeComponent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      initiative: {},
      initiatives: [],
      children: [],
      budgets: [],
      lineage: [],
      initiativeStatuses: [],
      initiativeTypes: [],
      financeCodeTypes: [],
      showChangeParentModal: false,
      showChangeTagsModal: false,
      showCreateInitiativeModal: false,
      isInEditMode: false,
      loading: true,
      key: 1,
      tagNameMap: null,
      initiativeTypesMap: {},
      parentTypeId: null,
      alerts: [],
      userHasEitherRole: true,
      userHasReadWriteRole: true,
      createAnotherInitiative: false,
      descendants: [],
      timeFrames: [],
      fiscalYears: [],
    }
    this.changeParent = this.changeParent.bind(this)
    this.getBudgets = this.getBudgets.bind(this)
    this.getChildren = this.getChildren.bind(this)
    this.getFinanceCodeTypes = this.getFinanceCodeTypes.bind(this)
    this.getInitiative = this.getInitiative.bind(this)
    this.getInitiativeStatuses = this.getInitiativeStatuses.bind(this)
    this.getInitiativeTypes = this.getInitiativeTypes.bind(this)
    this.getLineage = this.getLineage.bind(this)
    this.updateTags = this.updateTags.bind(this)
    this.getParentType = this.getParentType.bind(this)
    this.onAlertDismissed = this.onAlertDismissed.bind(this)
  }

  async componentDidMount() {
    try {
      this.loadTimeFrames()
      this.loadFiscalYears()
      const initiatives = await getInitiatives()
      const userHasEitherRole = await UserRolesUtil.hasEitherRole()
      const userHasReadWriteRole = await UserRolesUtil.hasReadWriteRole()
      const initiative = await this.getInitiative(this.props.params.initiativeId, initiatives)

      const promises = [
        this.getInitiativeStatuses(),
        this.getFinanceCodeTypes(),
        this.getInitiativeTypes(),
        this.getChildren(this.props.params.initiativeId, initiatives),
        this.getLineage(this.props.params.initiativeId),
        this.getBudgets(this.props.params.initiativeId),
        fetchTagsByInitiative(this.props.params.initiativeId),
        fetchDescendants(this.props.params.initiativeId),
        fetchTagNameMap(),
      ]

      const [
        initiativeStatuses,
        financeCodeTypes,
        initiativeTypes,
        children,
        lineage,
        budgets,
        tags,
        descendants,
        tagNameMap,
      ] = await Promise.all(promises)

      this.setState({ // eslint-disable-line
        loading: false,
        initiativeStatuses,
        initiativeTypes,
        budgets,
        lineage,
        ...initiative,
        initiatives,
        parentTypeId: initiative.parentTypeId,
        children,
        financeCodeTypes,
        tags,
        tagNameMap,
        userHasEitherRole,
        userHasReadWriteRole,
        descendants,
      })
    } catch ( error ) {
      console.error(error) // eslint-disable-line no-console
      this.setState({ loading: false }) // eslint-disable-line
    }
  }

  async componentWillReceiveProps(nextProps) {
    this.setState({ loading: true })
    const initiatives = await getInitiatives()

    const initiativePromise = this.getInitiative(nextProps.params.initiativeId, initiatives)
    const lineagePromise = this.getLineage(nextProps.params.initiativeId)
    const budgetsPromise = this.getBudgets(nextProps.params.initiativeId)
    const childrenPromise = this.getChildren(nextProps.params.initiativeId, initiatives)
    const tagsPromise = fetchTagsByInitiative(this.props.params.initiativeId)
    const descendantsPromise = fetchDescendants(nextProps.params.initiativeId)

    const [
      initiative,
      lineage,
      budgets,
      children,
      tags,
      descendants,
    ] = await Promise.all([
      initiativePromise,
      lineagePromise,
      budgetsPromise,
      childrenPromise,
      tagsPromise,
      descendantsPromise,
    ])

    this.setState({
      key: 1,
      ...initiative,
      initiatives,
      children,
      lineage,
      budgets,
      tags,
      parentTypeId: initiative.parentTypeId,
      loading: false,
      descendants,
    })
  }


  onAlertDismissed(alert) {
    const alerts = this.state.alerts
    const idx = alerts.indexOf(alert)

    if ( idx >= 0 ) {
      this.setState({
        alerts: [ ...alerts.slice(0, idx), ...alerts.slice(idx + 1) ],
      })
    }
  }

  async getInitiativeStatuses() {
    try {
      const statuses = await agent.get(getInitiativeStatusUrl)
      if ( isEmpty(statuses.body) ) {
        AlertUtil.setAlert(this, 'error', 'Failed to retrieve statuses.')

        return null
      }

      const formattedStatuses = formatInitiativeStatuses(statuses.body)

      return formattedStatuses
    } catch ( error ) {
      console.error(error) // eslint-disable-line no-console
      AlertUtil.setAlert(this, 'error', 'Error: Unable to retrieve Initiative Statuses')

      return null
    }
  }

  async getBudgets(initiativeId) {
    if ( isUndefined(initiativeId) ) {
      AlertUtil.setAlert(this, 'error', 'Error: Unable to retrieve Budgets')
    } else {
      try {
        const { body: budgets } = await agent.get(getBudgetsByInitiativeUrl(initiativeId))

        return budgets
      } catch ( error ) {
        AlertUtil.setAlert(this, 'error', error)

        return null
      }
    }

    return null
  }

  async getInitiative(initiativeId, initiatives) {
    if ( isUndefined(initiativeId) ) {
      AlertUtil.setAlert(this, 'error', 'Error: Unable to retrieve Initiative')

      return null
    }
    try {
      const result = await agent.get(`${getInitiativeUrl}/${initiativeId}`)
      const relevantInitiative = find(initiatives, i => i.initiative_id === initiativeId)
      const initiativeWithInheritedDetails = getInitiativeInheritedDetails(relevantInitiative, initiatives)

      if ( result.body.parent ) {
        const parentTypeId = await this.getParentType(result.body.parent)

        return { initiative: initiativeWithInheritedDetails, parentTypeId, initiativeId }
      }

      return { initiative: initiativeWithInheritedDetails, initiativeId }
    } catch ( error ) {
      window.location = `${appBaseUrl}/?error=invalid_initiative_id`
      throw error
    }
  }

  async getChildren(parentId, initiatives) {
    try {
      const { body: children } = await agent.get(`${getChildInitiativesUrl}/${parentId}`)

      const tagged = map(children, async child => {
        const tagsPromise = await fetchTagsByInitiative(child.initiative_id)

        const relevantInitiative = find(
          initiatives,
          i => i.initiative_id === child.initiative_id
        )
        const initiativeWithInheritedDetails = getInitiativeInheritedDetails(relevantInitiative, initiatives)
        let returnInitiative = { ...child, tags: map(tagsPromise, 'name') }

        if (
          initiativeWithInheritedDetails &&
          initiativeWithInheritedDetails.inherited_fin_code_value &&
          initiativeWithInheritedDetails.inherited_fin_code_type
        ) {
          returnInitiative = {
            ...returnInitiative,
            inherited_fin_code_value: initiativeWithInheritedDetails.inherited_fin_code_value,
            inherited_fin_code_type: initiativeWithInheritedDetails.inherited_fin_code_type,
          }
        }
        if ( initiativeWithInheritedDetails && initiativeWithInheritedDetails.inherited_status ) {
          returnInitiative = {
            ...returnInitiative,
            inherited_status: initiativeWithInheritedDetails.inherited_status,
          }
        }
        if ( initiativeWithInheritedDetails && initiativeWithInheritedDetails.inherited_portfolio_code ) {
          returnInitiative = {
            ...returnInitiative,
            inherited_portfolio_code: initiativeWithInheritedDetails.inherited_portfolio_code,
          }
        }
        if ( initiativeWithInheritedDetails && initiativeWithInheritedDetails.inherited_program_code ) {
          returnInitiative = {
            ...returnInitiative,
            inherited_program_code: initiativeWithInheritedDetails.inherited_program_code,
          }
        }
        if ( initiativeWithInheritedDetails && initiativeWithInheritedDetails.inherited_activity_id ) {
          returnInitiative = {
            ...returnInitiative,
            inherited_activity_id: initiativeWithInheritedDetails.inherited_activity_id,
          }
        }

        return returnInitiative
      })

      return await Promise.all(tagged)
    } catch ( error ) {
      console.error(error) // eslint-disable-line no-console

      AlertUtil.setAlert(this, 'error', 'Error: Unable to retrieve Child Initiatives')

      return null
    }
  }

  async getFinanceCodeTypes() {
    try {
      const result = await agent.get(getFinanceCodeTypeUrl)
      const tagTypes = result.body
      if ( isEmpty(tagTypes) ) {
        AlertUtil.setAlert(this, 'error', 'There were no finance code types to retrieve.')

        return null
      }

      return formatFinanceCodeTypes(tagTypes)
    } catch ( error ) {
      AlertUtil.setAlert(this, 'error', error)

      return null
    }
  }

  async getInitiativeTypes() {
    try {
      const result = await agent.get(getInitiativeTypesUrl)
      const initiativeTypes = result.body
      if ( isEmpty(initiativeTypes) ) {
        AlertUtil.setAlert(this, 'error', 'Error: There were no initiative types.')

        return null
      }
      const activeTypes = filter(initiativeTypes, type => type.is_active)
      const initiativeTypesMap = reduce(
        activeTypes,
        (memo, { id, value }) => {
          memo[id] = value // eslint-disable-line no-param-reassign

          return memo
        },
        {}
      )

      this.setState({ initiativeTypesMap })

      return formatInitiativeTypes(activeTypes)
    } catch ( error ) {
      AlertUtil.setAlert(this, 'error', error)

      return null
    }
  }

  async getLineage(initiativeId) {
    try {
      const response = await getLineageForBreadcrumbs(initiativeId)
      if ( response.hasError ) {
        AlertUtil.setAlert(this, 'error', response.message)

        return null
      }

      return response.breadcrumbs
    } catch ( error ) {
      AlertUtil.setAlert(this, 'error', error)
      console.error(error) // eslint-disable-line no-console

      return null
    }
  }

  getInitiativeTypeName = () => {
    const relevantType = find(this.state.initiativeTypes, ({ value }) => this.state.initiative.type_id === value)

    return relevantType ? relevantType.label : this.state.initiative.type_id
  }

  async getParentType(parentId) {
    try {
      const result = await agent.get(`${getInitiativeUrl}/${parentId}`)

      return result.body.type_id
    } catch ( error ) {
      console.error(error) // eslint-disable-line no-console
      AlertUtil.setAlert(this, 'error', 'Error: Unable to retrieve Parent Initiative')

      return null
    }
  }

  getParentInformation = () => {
    const current = {
      parent: this.state.initiative.initiative_id,
      inherited_status: this.state.initiative.status || this.state.initiative.inherited_status,
      inherited_fin_code_type: this.state.initiative.is_inheritable
        ? this.state.initiative.finance_code_type || this.state.initiative.inherited_fin_code_type
        : null,
      inherited_fin_code_value: this.state.initiative.is_inheritable
        ? this.state.initiative.finance_code_value || this.state.initiative.inherited_fin_code_value
        : null,
      inherited_portfolio_code: this.state.initiative.portfolio_code || this.state.initiative.inherited_portfolio_code,
      inherited_program_code: this.state.initiative.program_code || this.state.initiative.inherited_program_code,
      inherited_activity_id: this.state.initiative.activity_id || this.state.initiative.inherited_activity_id,
    }

    return current
  }

  openCreateModal = () => this.setState({ showCreateInitiativeModal: true, isInEditMode: false })

  closeModals = () =>
    this.setState({ showCreateInitiativeModal: false, showChangeParentModal: false, showChangeTagsModal: false })

  successCallback = (response, initiativeToSave) => {
    this.closeModals()
    initiativeToSave.initiative_id = response.body.initiative_id // eslint-disable-line
    this.setState({ children: { ...this.state.children, initiativeToSave } })
  }

  errorCallback = err => {
    console.error(err) // eslint-disable-line no-console
    this.closeModals()
    AlertUtil.setAlert(this, 'error', 'Error: Unable to save Initiative')
  }

  // eslint-disable-next-line max-statements
  createInitiative = async ({ initiative: initiativeToSave, isInEditMode, createAnotherInitiative }) => {
    this.closeModals()

    const updatedLineage = map(this.state.lineage, lineage => {
      if ( lineage.id === initiativeToSave.initiative_id ) {
        return { ...lineage, name: initiativeToSave.initiative_name } // TODO: TEMPORARY WORKAROUND, MAKE LESS BAD
      }

      return lineage
    })

    this.setState({ lineage: updatedLineage })
    if ( isInEditMode ) {
      try {
        await agent.put(updateInitiativeUrl, initiativeToSave)
        AlertUtil.setAlert(this, 'success', 'Initiative Updated Successfully')

        const initiatives = await getInitiatives()
        const children = await this.getChildren(initiativeToSave.initiative_id, initiatives)
        this.setState({
          saveDisabled: true,
          initiative: initiativeToSave,
          initiatives,
          children,
        })
        this.getLineage(this.props.params.initiativeId)
      } catch ( error ) {
        AlertUtil.setAlert(this, 'error', 'Error: Unable to save Initiative')
      }
    } else {
      try {
        const response = await agent.post(createInitiativeUrl, initiativeToSave)
        AlertUtil.setAlert(this, 'success', 'Initiative created successfully')

        const newInitiative = {
          ...initiativeToSave,
          initiative_id: response.body.initiative_id,
        }
        this.setState({ children: [ ...this.state.children, newInitiative ] })
        if ( !createAnotherInitiative ) {
          window.location = `${appBaseUrl}/initiative/${response.body.initiative_id}`
        } else {
          this.setState({ createAnotherInitiative: true })
          this.renderCreateInitiativeModal()
          this.setState({ showCreateInitiativeModal: true })
        }
      } catch ( error ) {
        AlertUtil.setAlert(this, 'error', 'Error: Unable to save Initiative')
      }
    }
  }

  editInitiative = () => {
    this.setState({ showCreateInitiativeModal: true, isInEditMode: true })
  }
  editParent = () => {
    this.setState({ showChangeParentModal: true })
  }
  editTags = () => {
    this.setState({ showChangeTagsModal: true })
  }

  async changeParent(initiative) {
    this.closeModals()
    const lineage = await this.getLineage(this.state.initiativeId)
    const children = map(this.state.children, child => ({ ...child, type_id: initiative.type_id }))
    this.setState({ lineage, initiative, children })
  }

  async updateTags(tags) {
    this.closeModals()
    const children = await this.getChildren(this.state.initiativeId, this.state.initiatives)
    this.setState({ tags, children })
  }

  isTopLevelSupportOrEnhancement() {
    return (
      !this.state.initiative.parent &&
      (this.state.initiative.type_id === 'SUP' ||
        this.state.initiative.type_id === 'FRESH' ||
        (this.state.initiative.type_id === 'ENH' && this.state.initiative.initiative_id === enhancementInitiativeId) ||
        this.state.initiative.type_id === 'OPS')
    )
  }

  updateBudgetState = orderedBudgets => {
    this.setState({ budgets: orderedBudgets })
  }

  async loadFiscalYears() {
    const fiscalYears = await getFiscalYears()
    this.setState({ fiscalYears })
  }

  async loadTimeFrames() {
    const timeFrames = await getAllTimeFrames()
    this.setState({ timeFrames })
  }

  renderBudgetTab = () => {
    if ( !this.isTopLevelSupportOrEnhancement() ) {
      return (
        <Tab eventKey={2} title="Budgets">
          <h3>Budgets</h3>
          <BudgetListComponent
            budgets={this.state.budgets}
            initiative={this.state.initiative}
            lineage={this.state.lineage}
            updateBudgetState={this.updateBudgetState}
          />
        </Tab>
      )
    }

    return ''
  }

  renderCreateInitiativeModal = () => {
    const title = this.state.isInEditMode ? 'Edit Initiative' : 'Create Child Initiative'
    const isTopLevel = this.state.isInEditMode && !this.state.initiative.parent
    const parentType = this.state.isInEditMode ? this.state.parentTypeId : this.state.initiative.type_id
    const theInitiative = this.state.isInEditMode
      ? { ...cloneDeep(this.state.initiative) }
      : this.getParentInformation()

    return (
      <CreateInitiativeModal
        childrenInitiatives={this.state.children}
        close={this.closeModals}
        createAnotherInitiative={this.state.createAnotherInitiative}
        financeCodeTypes={this.state.financeCodeTypes}
        initiative={theInitiative}
        initiativeStatuses={this.state.initiativeStatuses}
        initiativeTypes={this.state.initiativeTypes}
        initiatives={this.state.initiatives}
        isInEditMode={this.state.isInEditMode}
        isTopLevel={isTopLevel}
        lineage={this.state.lineage}
        parentTypeId={parentType}
        save={this.createInitiative}
        show={this.state.showCreateInitiativeModal}
        title={title}
      />
    )
  }

  renderChangeParentModal() {
    return (
      <ChangeParentModal
        close={this.closeModals}
        descendants={this.state.descendants}
        initiative={this.state.initiative}
        initiativeTypes={this.state.initiativeTypes}
        initiatives={this.state.initiatives}
        parentList={[{ label: 'one', value: '1' }, { label: 'two', value: '2' }]}
        save={this.changeParent}
        show={this.state.showChangeParentModal}
      />
    )
  }

  renderChangeTagsModal = () => (
    <ChangeTagsModal
      close={this.closeModals}
      initiative={this.state.initiative}
      show={this.state.showChangeTagsModal}
      tagNameMap={this.state.tagNameMap}
      tags={this.state.tags}
      updateTags={this.updateTags}
    />
  )

  renderErrorMessage = () => {
    if ( this.isTopLevelSupportOrEnhancement() ) {
      return <div className="button-notice">Unable to modify this {this.getInitiativeTypeName()} initiative.</div>
    } else if ( this.state.initiative.type_id === 'UNKNOWN' ) {
      return (
        <div className="button-notice">Unable to modify the parent or create a child of an Unknown initiative.</div>
      )
    }

    return null
  }

  renderInitiativeCardsComponent = () => (
    <InitiativeCardsComponent
      buttonAction={this.openCreateModal}
      buttonText="Create Child"
      initiativeTypesMap={this.state.initiativeTypesMap}
      initiatives={this.state.children}
      isTopLevel={false}
      typeId={this.state.initiative.type_id}
    />
  )

  renderInitiativeDetailComponent = () => (
    <div className="row" style={{ margin: '1em 0' }}>
      <InitiativeDetailComponent
        initiative={this.state.initiative}
        tagNameMap={this.state.tagNameMap}
        tags={this.state.tags}
        typeName={this.getInitiativeTypeName()}
      />
    </div>
  )

  renderEditButtons = () => ( this.state.userHasReadWriteRole ? (
    <div className="row row-padding">
      <div className="col-md-8">
        <Button
          disabled={this.isTopLevelSupportOrEnhancement()}
          id="editButton"
          onClick={this.editInitiative}
          style={{ marginRight: '0.5em' }}
        >
            Edit
        </Button>
        <Button
          disabled={
            this.isTopLevelSupportOrEnhancement() ||
              this.state.initiative.type_id === 'UNKNOWN' ||
              this.state.initiative.type_id === 'CAP-PROJ'
          }
          id="changeParentButton"
          onClick={this.editParent}
        >
            Change Parent
        </Button>
        <Button
          disabled={this.isTopLevelSupportOrEnhancement()}
          id="changeTagsButton"
          onClick={this.editTags}
          style={{ marginLeft: '0.5em' }}
        >
            Change Tags
        </Button>
        {this.renderErrorMessage()}
      </div>
      <div className="col-md-4 rpt-link">{this.renderReportLink()}</div>
    </div>
  ) : null)

  renderReportLink = () => {
    const timeFrames = this.state.timeFrames
    const fiscalYears = this.state.fiscalYears
    const currentDate = new Date()
    const currentDateString = currentDate.toISOString().split('T')[0]

    const findFY = find(fiscalYears, ({ startDate, endDate }) =>
      currentDateString > startDate && currentDateString < endDate)

    if ( findFY ) {
      const startDate = Date.parse(findFY.startDate)
      const endDate = Date.parse(findFY.endDate)
      const startFY = getOrElse(
        find(timeFrames, tf => Math.abs(tf.startDate - startDate) <= millisecondsPerHour), 'id', 0
      )
      const endFY = getOrElse(
        find(timeFrames, tf => Math.abs(tf.endDate - endDate) <= millisecondsPerHour), 'id', 0
      )

      if ( startFY !== 0 && endFY !== 0 ) {
        const reportLink = `${window.phoenix.urls.ui['ez-trac-reporting']}/initiatives?endTimeFrame=${
          endFY}&startTimeFrame=${startFY}&selectedInitiative=${this.state.initiativeId}`

        return <a href={reportLink}>View Spending Report</a>
      }
    }

    return <span />
  }

  render() {
    if ( this.state.userHasEitherRole ) {
      return (
        <div id="viewInitiativeBody">
          <LoadingBlocker isLoading={this.state.loading} />
          <div className="row row-padding vertical-align">
            <div className="col-md-12">
              <h1>Initiative Details: {this.state.initiative.initiative_name}</h1>
            </div>
          </div>
          {this.renderCreateInitiativeModal()}
          {this.renderChangeParentModal()}
          {this.renderChangeTagsModal()}
          <BreadcrumbsComponent lineage={this.state.lineage} />
          <AlertList alerts={this.state.alerts} onDismiss={this.onAlertDismissed} position="top-right" />
          {this.renderEditButtons()}
          {this.renderInitiativeDetailComponent()}
          <Tabs activeKey={this.state.key} id="tabs" onSelect={key => this.setState({ key })}>
            <Tab eventKey={1} title="Child Initiatives">
              <h3>Child Initiatives</h3>
              {this.renderInitiativeCardsComponent()}
            </Tab>
            {this.renderBudgetTab()}
          </Tabs>
        </div>
      )
    }

    return <MissingPermissionsComponent />
  }
}

export default ViewInitiativeComponent
