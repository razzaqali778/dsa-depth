import { Button, Modal } from 'react-bootstrap'
import { Link } from 'react-router'
import React from 'react'

/* eslint-disable */
export default class ChickenTestComponent extends React.Component {
  // shouldComponentUpdate = shouldPureComponentUpdate

/*
  ,~.
  ,-'__ `-,
  {,-'  `. }              ,')
  ,( a )   `-.__         ,',')~,
  <=.) (         `-.__,==' ' ' '}
  (   )                      /)
  `-'\   ,                    )
   |  \        `~.        /
   \   `._        \      /
    \     `._____,'    ,'
     `-.             ,'
        `-._     _,-'
            77jj'
           //_||
        __//--'/`
      ,--'/`  '

*/

  render() {
    return (
      <Modal onHide={this.props.close} show={this.props.show}>
        <Modal.Body>
          {this.props.message}
        </Modal.Body>
        <Modal.Footer>
          <Button
            className="btn-margin-right"
            id="noButton"
            onClick={this.props.close}
          >
            {this.props.noText}
          </Button>

          <Link to={this.props.yesDestination}>
            <Button
              bsStyle="primary"
              id="yesButton"
            >
              {this.props.yesText}
            </Button>
          </Link>
        </Modal.Footer>
      </Modal>
    )
  }
}
