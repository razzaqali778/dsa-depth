import { generateValueLabel, makeLabels } from '../../util/RequestInitiativeUtil'
import { sortByMatchingFirst } from '../../util/ReactSelectUtil'
import React from 'react'
import Select from 'react-select'

class RequestInitiativeSelector extends React.Component {
  constructor(props) {
    super(props)
    this.state = { searchString: '' }
  }

  render() {
    const { updateState, placeholder, formName, items, formFields } = this.props
    const { searchString } = this.state

    return (
      <Select
        onChange={evt => updateState(evt, formName)}
        onInputChange={newSearchString => this.setState({ newSearchString })}
        options={sortByMatchingFirst(makeLabels(...items), searchString)}
        placeholder={placeholder}
        value={generateValueLabel(formFields[formName])}
      />
    )
  }
}

export default RequestInitiativeSelector
