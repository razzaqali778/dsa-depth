/* eslint-disable */
import { ControlLabel, FormControl, FormGroup, Radio } from 'react-bootstrap'
import { filter } from 'lodash'
import { validateBudget, validateName, validateParentChildren } from '../../util/CreateInitiativeValidator'
import React from 'react'
import RequestInitiativeSelector from './RequestInitiativeSelector'

const currentYear = new Date().getFullYear()

const renderParentSuggestion = (initiatives, formFinancialCode, capProjRadio) => {
  const filteredInits = filter(initiatives, initiative =>
    initiative.typeId === 'CAP-PROJ' && initiative.financialCode)
  if ( formFinancialCode.length > 0 && capProjRadio ) {
    const prefix = formFinancialCode.indexOf('.') >= 0 ? formFinancialCode.split('.')[0] : null
    const matchingInit = filteredInits.find(initiative => initiative.financialCode === formFinancialCode
        || initiative.financialCode === prefix)

    return (matchingInit ?
      <ControlLabel> Is this the parent you are looking for? {matchingInit.initiativeName}</ControlLabel>
      : null)
  }

  return null
}

const CommonFlowComponent = ({ initiatives, formFields, updateState, children, setFormFields }) => {
  const setFieldsCapProjRadio = capProjRadio => {
    setFormFields({ type: null, typeId: null, capProjRadio, parentId: null, parentName: '' })
  }

  return (
    <div>
      <FormGroup validationState={(validateName(formFields) || formFields.name === '') && validateParentChildren(formFields, initiatives) ? null : 'error'}>
        <ControlLabel>Initiative Name: <span style={{ color: 'red' }}>*</span></ControlLabel>
        <FormControl
          maxLength="44"
          name="name"
          onChange={updateState}
          placeholder="Enter Name"
          type="text"
          value={formFields.name}
        />
        <p hidden={validateName(formFields) || formFields.name === ''}>
          <span style={{ color: 'red' }}>
                  Illegal initiative name (must be under 44 characters
                  and contain only letters, numbers,
                  spaces, and these special characters: ( ) / - + : . & [ ])
          </span>
        </p>
        <p hidden={validateParentChildren(formFields, initiatives)}>
          <span style={{ color: 'red' }}>
              Name must not be the same as another child initiative under this parent.
          </span>
        </p>
      </FormGroup>

      <ControlLabel>Is this part of a capital project?</ControlLabel>
      <br />
      <Radio
        checked={formFields.capProjRadio}
        inline
        name="radioGroupCapProj"
        onChange={() => setFieldsCapProjRadio(!formFields.capProjRadio)}
      >
        Yes
      </Radio>
      <Radio
        checked={!formFields.capProjRadio}
        inline
        name="radioGroupCapProj"
        onChange={() => setFieldsCapProjRadio(!formFields.capProjRadio)}
      >
        No
      </Radio>
      <br />

      <ControlLabel>Select Initiative Type: </ControlLabel>
      <RequestInitiativeSelector
        formFields={formFields}
        formName="type"
        items={formFields.capProjRadio ? [ 'Capital Initiative', 'Capital OpEx Initiative' ] :
        [ 'Special Item', 'OpEx Only Project', 'Support' ]}
        placeholder="Type"
        updateState={updateState}
      />
      <br />

      {formFields.type &&
        children
      }
      <br />

      <ControlLabel>Status: </ControlLabel>
      <RequestInitiativeSelector
        formFields={formFields}
        formName="status"
        items={[ 'Funded', 'Planning' ]}
        placeholder="Status"
        updateState={updateState}
      />
      <br />

      <ControlLabel>Financial Code:</ControlLabel>
      <FormControl
        name="financialCode"
        onChange={updateState}
        placeholder="Enter Financial Code"
        type="text"
        value={formFields.financialCode}
      />

      {renderParentSuggestion(initiatives, formFields.financialCode, formFields.capProjRadio)}
      <br />

      <ControlLabel>Portfolio ID from Plan/View: <span style={{ color: 'red' }}>*</span></ControlLabel>
      <FormControl
        name="portfolioId"
        onChange={updateState}
        placeholder="Enter Portfolio ID"
        type="text"
        value={formFields.portfolioId}
      />
      <br />

      <ControlLabel>GET Activity ID:</ControlLabel>
      <FormControl
        name="activityId"
        onChange={updateState}
        placeholder="Enter GET Activity ID"
        type="text"
        value={formFields.activityId}
      />
      <br />

      <ControlLabel>Program Code:</ControlLabel>
      <FormControl
        name="programCode"
        onChange={updateState}
        placeholder="Enter Program Code"
        type="text"
        value={formFields.programCode}
      />
      <br />

      <FormGroup validationState={validateBudget(formFields) ? null : 'error'}>
        <ControlLabel>Budget Amount: </ControlLabel>
        <FormControl
          name="budget"
          onChange={updateState}
          placeholder="Enter Budget Amount"
          type="text"
          value={formFields.budget}
        />
        <p hidden={validateBudget(formFields)}>
          <span style={{ color: 'red' }}>
                Budget should only contain digits
          </span>
        </p>
      </FormGroup>

      <ControlLabel>Fiscal Year (Should Match Budget Year):</ControlLabel>
      <RequestInitiativeSelector
        formFields={formFields}
        formName="fiscalYear"
        items={[ currentYear, currentYear + 1, currentYear + 2 ]}
        placeholder="Fiscal Year"
        updateState={updateState}
      />
      <br />

      <ControlLabel>Business Unit:</ControlLabel>
      <RequestInitiativeSelector
        formFields={formFields}
        formName="businessUnit"
        items={[ 'Commercial', 'Enabling', 'Enterprise', 'Global Supply Chain', 'IT', 'R&D', 'Climate' ]}
        placeholder="Business Unit"
        updateState={updateState}
      />

      <ControlLabel>Region:</ControlLabel>
      <RequestInitiativeSelector
        formFields={formFields}
        formName="region"
        items={[ 'Asia-Africa', 'Europe-Middle East', 'Global', 'North America',
          'South America', 'Veg', 'Australia-New Zealand' ]}
        placeholder="Region"
        updateState={updateState}
      />
      <br />

      <ControlLabel>Comments:</ControlLabel>
      <FormControl
        componentClass="textarea"
        name="comment"
        onChange={updateState}
        value={formFields.comment}
      />
    </div>
  )
}

export default CommonFlowComponent
