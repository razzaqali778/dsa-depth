import { ControlLabel, FormControl, Radio } from 'react-bootstrap'
import { appBaseUrl } from '../../../consts'
import { sortByMatchingFirst } from '../../util/ReactSelectUtil'
import Link from 'react-router/lib/Link'
import React from 'react'
import Select from 'react-select'
import getSelectParentOptions from '../../selectors/getSelectParentOptions'

const ParentFlowComponent = ({ initiatives, formFields, setFormFields, updateState }) => (
  <div>
    { formFields.capProjRadio ?
      <ControlLabel>Do you know the capital project name?</ControlLabel> :
      <ControlLabel>If applicable, do you know the parent name?</ControlLabel>
    }
    <br />
    <Radio
      checked={formFields.parentNameRadio}
      inline
      name="radioGroupParentName"
      onChange={() => setFormFields({
        parentNameRadio: !formFields.parentNameRadio,
      })
      }
    >
      Yes
    </Radio>
    <Radio
      checked={!formFields.parentNameRadio}
      inline
      name="radioGroupParentName"
      onChange={() => setFormFields({
        parentName: '',
        parentId: null,
        parentNameRadio: !formFields.parentNameRadio,
      })}
    >
      {formFields.capProjRadio ? 'No' : 'No or N/A'}
    </Radio>
    <br />
    {formFields.parentNameRadio &&
    <div>
      <ControlLabel>Find Parent:</ControlLabel>
      <Select
        onChange={item => {
          if ( item ) {
            const { value, label } = item
            setFormFields({ parentName: label, parentId: value || null })
          } else {
            setFormFields({ parentName: '', parentId: null })
          }
        }}
        options={sortByMatchingFirst(getSelectParentOptions({ initiatives, formFields }))}
        placeholder="Select Parent"
        value={formFields.parentId ?
          ({ value: formFields.parentId, label: formFields.parentName }) : null}
      />

      <p hidden={!formFields.parentId}>
        <Link to={`${appBaseUrl}/initiative/${formFields.parentId}`}>
          View Initiative Details: {formFields.parentName}
        </Link>
        <br />
          Clicking this link before saving will clear the form.
      </p>
      <ControlLabel>-OR-</ControlLabel>
      <br />
      <ControlLabel>Create Parent Name:</ControlLabel>
      <FormControl
        name="parentName"
        onChange={updateState}
        placeholder="Enter Parent Name"
        type="text"
        value={!formFields.parentId ? formFields.parentName : ''}
      />
    </div> }
  </div>
)

export default ParentFlowComponent
