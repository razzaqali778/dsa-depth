import { IndexRoute, Route } from 'react-router'
import { appBaseUrl } from '../../consts'
import AuditComponent from './AuditComponent'
import DashboardComponent from './dashboardComponent'
import React from 'react'
import RequestInitiativeComponent from './RequestInitiativeComponent'
import RootComponent from './RootComponent'
import ViewInitiativeComponent from './ViewInitiativeComponent'

const routes = (
  <Route component={RootComponent} path={appBaseUrl}>
    <IndexRoute component={DashboardComponent} />
    <Route component={ViewInitiativeComponent} path="initiative/:initiativeId" />
    <Route component={AuditComponent} path="audit-page" />
    <Route component={RequestInitiativeComponent} path="request-initiative(/:requestedInitiativeId)" />
  </Route>
)

export default routes
