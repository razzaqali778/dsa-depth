import { Breadcrumb } from 'react-bootstrap'
import { Link } from 'react-router'
import React from 'react'
import isUndefined from 'lodash/isUndefined'
import map from 'lodash/map'

export default class BreadcrumbsComponent extends React.Component {
  renderHomeLink() {
    return ( isUndefined(this.props.optionalClass) || !this.props.optionalClass.includes('disabled') )
      ? (
        <Link className={this.props.optionalClass || ''} id="homeLink" to="/ez-trac-vip" >
          Home
        </Link>
      )
      : null
  }

  render() {
    return ( this.props.lineage && this.props.lineage.length > 0 )
      ? (
        <Breadcrumb>
          {this.renderHomeLink()}
          {
            map(this.props.lineage, link => (
              <span key={`span ${link.id} key`}>
                <span> / </span>
                <Link
                  activeClassName="disabled"
                  className={this.props.optionalClass || ''}
                  key={`link${link.order}`}
                  to={`/ez-trac-vip/initiative/${link.id}`}
                >
                  {`${link.name}`}
                </Link>
              </span>
            ))
          }
        </Breadcrumb>
      )
      : null
  }
}
