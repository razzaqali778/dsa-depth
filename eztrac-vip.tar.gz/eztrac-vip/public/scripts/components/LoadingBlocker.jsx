import React from 'react'

const LoadingBlocker = ({ isLoading }) =>
  isLoading
    ? (
      <div className="blocker">
        <div className="block-message">
          <span className="inner-text">
            <i className="velocity-spinner-inline" />
            Loading....
          </span>
        </div>
      </div>
    )
    : null

export default LoadingBlocker
