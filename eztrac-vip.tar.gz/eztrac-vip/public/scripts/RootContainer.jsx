import { Router, browserHistory } from 'react-router'
import React from 'react'
import routes from './components/routes'


const RootContainer = ({ children }) => (
  <div>
    <div>
      <Router history={browserHistory} routes={routes} />
      {children}
    </div>
  </div>
)


export default RootContainer

