export const appBaseUrl = '/ez-trac-vip'
export const localVipServicesUrl = `http://localhost:3300${appBaseUrl}/services`
