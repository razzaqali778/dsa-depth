const _ = require("lodash");
const defaultConfig = require("./default");

module.exports = _.merge(defaultConfig, {
  "ez-trac-vip-db": {
    user: "vault://secret/ez-trac/vip-services/np/db/app-user-name",
    password: "vault://secret/ez-trac/vip-services/np/db/app-user-password",
    host: "localhost",
    port: "5435",
    database: "vault://secret/ez-trac/vip-services/np/db/db-name",
  },
  "ez-trac-vip-url": {
    ui: "localhost:3300/ez-trac-vip",
  },
  "ez-trac-urls": {
    services: {
      "ez-trac-core": "https://ez-trac-core-services.velocity-np.ag",
      "ez-trac-costing": "https://ez-trac-costing-services.velocity-np.ag",
      "ez-trac-qc": "https://ez-trac-qc-services.velocity-np.ag",
      "ez-trac-suggestion": "https://ez-trac-suggestion.velocity-np.ag",
      "ez-trac-vip":
        "http://localhost:3300/ez-trac-vip/services",
      "peadmin-home": "peadmin-np.monsanto.net",
    },
    ui: {
      "ez-trac-costing": "https://peadmin-np.monsanto.net/ez-trac-costing",
      "ez-trac-qc": "https://peadmin-np.monsanto.net/ez-trac-qc",
      "ez-trac-reporting": "https://peadmin-np.monsanto.net/ez-trac-reporting",
      "ez-trac-vip": "https://peadmin-np.monsanto.net/ez-trac-vip",
      "ez-trac-workflows": "https://peadmin-np.monsanto.net/ez-trac-workflows",
    },
  },
});
