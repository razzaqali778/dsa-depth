const _ = require("lodash");
const defaultConfig = require("./default");

module.exports = _.merge(defaultConfig, {
  "ez-trac-vip-url": {
    ui: "https://peadmin.monsanto.net/ez-trac-vip",
    vipEntitlements: "https://velocity.ag/entitlements/vip",
  },
  "ez-trac-urls": {
    services: {
      "ez-trac-core": "https://ez-trac-core-services.velocity.ag",
      "ez-trac-costing": "https://ez-trac-costing-services.velocity.ag",
      "ez-trac-qc": "https://ez-trac-qc-services.velocity.ag",
      "ez-trac-reporting": "https://ez-trac-reporting-services.velocity.ag",
      "ez-trac-suggestion": "https://ez-trac-suggestion.velocity.ag",
      "ez-trac-vip":
        "https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services",
      "peadmin-home": "peadmin.monsanto.net",
    },
    ui: {
      "ez-trac-costing": "https://peadmin.monsanto.net/ez-trac-costing",
      "ez-trac-qc": "https://peadmin.monsanto.net/ez-trac-qc",
      "ez-trac-reporting": "https://peadmin.monsanto.net/ez-trac-reporting",
      "ez-trac-vip": "https://peadmin.monsanto.net/ez-trac-vip",
      "ez-trac-workflows": "https://peadmin.monsanto.net/ez-trac-workflows",
    },
  },
  "vip-services-oauth-client": {
    clientId:
      "vault://secret/ez-trac/vip-services/prod/oauth-azure/client-id",
    clientSecret:
      "vault://secret/ez-trac/vip-services/prod/oauth-azure/client-secret",
  },
  "profile-url": "https://profile.velocity.ag",
  "velocity-home": "velocity.ag",
  "workforce-approle": {
    role_name: "workforce-dev-admins-eztrac-prod",
  },
  "messaging-url": "https://messaging.velocity.ag",
  "ez-trac-vip-db": {
    user: "vault://secret/ez-trac/vip-services/prod/db/app-user-name",
    password: "vault://secret/ez-trac/vip-services/prod/db/app-user-password",
    host: "vault://secret/ez-trac/prod/db/new-host",
    port: "5432",
    database: "vault://secret/ez-trac/vip-services/prod/db/db-name",
  },
  "elastic-search": {
    url: "vpc-ez-trac-es-dmcma2hhlvvcbs5eawjbazl4mq.us-east-1.es.amazonaws.com",
  },
  "vip-request-initiative": {
    papiGroup: "EZ-TRAC-INITIATIVE-CREATORS",
  },
  'phoenix-home': {value: 'phoenix-tools.io', env: 'Prod'},
  'enhancement-initiative-id': '280a2960-a1fa-11e7-95c2-f3e864cd7c94'
});
