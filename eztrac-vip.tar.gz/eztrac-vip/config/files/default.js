const config = {
  "ez-trac-vip-url": {
    ui: "https://peadmin-np.monsanto.net/ez-trac-vip",
    vipEntitlements: "https://velocity-np.ag/entitlements/vip",
  },
  "ez-trac-urls": {
    services: {
      "ez-trac-core": "https://ez-trac-core-services.velocity-np.ag",
      "ez-trac-costing": "https://ez-trac-costing-services.velocity-np.ag",
      "ez-trac-qc": "https://ez-trac-qc-services.velocity-np.ag",
      "ez-trac-suggestion": "https://ez-trac-suggestion.velocity-np.ag",
      "ez-trac-vip":
        "https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services",
      "peadmin-home": "peadmin-np.monsanto.net",
    },
    ui: {
      "ez-trac-costing": "https://peadmin-np.monsanto.net/ez-trac-costing",
      "ez-trac-qc": "https://peadmin-np.monsanto.net/ez-trac-qc",
      "ez-trac-reporting": "https://peadmin-np.monsanto.net/ez-trac-reporting",
      "ez-trac-vip": "https://peadmin-np.monsanto.net/ez-trac-vip",
      "ez-trac-workflows": "https://peadmin-np.monsanto.net/ez-trac-workflows",
    },
  },
  "vip-services-oauth-client": {
    clientId:
      "vault://secret/ez-trac/vip-services/np/oauth-azure/client-id",
    clientSecret:
      "vault://secret/ez-trac/vip-services/np/oauth-azure/client-secret",
  },
  "profile-url": "https://profile.velocity-np.ag",
  "velocity-home": "velocity-np.ag",
  "workforce-approle": {
    role_name: '',
  },
  "messaging-url": "https://messaging.velocity-np.ag",
  "ez-trac-vip-db": {
    user: "vault://secret/ez-trac/vip-services/np/db/app-user-name",
    password: "vault://secret/ez-trac/vip-services/np/db/app-user-password",
    host: "vault://secret/ez-trac/np/db/new-host",
    port: "5432",
    database: "vault://secret/ez-trac/vip-services/np/db/db-name",
    ssl: {rejectUnauthorized: false}
  },
  "elastic-search": {
    url: "vpc-ez-trac-es-ch7mrcjki6dmjpdp6256bzkdta.us-east-1.es.amazonaws.com"
  },
  "vip-request-initiative": {
    papiGroup: "EZ-TRAC-VIP-TEST-GROUP",
  },
  'phoenix-home': {value: 'phoenix-tools-np.io', env: 'NonProd'},
  'enhancement-initiative-id': '280a2960-a1fa-11e7-95c2-f3e864cd7c94'
};

module.exports = config;
