import config from './config'

const isEmpty = require('lodash/isEmpty')
const bindingsMiddleware = require('@monsantoit/phoenix-service-bindings-middleware')
const defaultClientBindings = config.config

const defaultUrls = {
  ui: {},
  services: {
    'ez-trac-reporting': 'https://localhost:9092',
    'ez-trac-core': 'https://localhost:9091',
  },
}

const ezTracUrls = config.get('ez-trac-urls')
const enhancementInitiativeId = config.get('enhancement-initiative-id')

const customBindings = {
  localOcelot: process.env.NODE_ENV !== 'production',
  localDevelopment: process.env.NODE_ENV !== 'production',
  urls: !isEmpty(ezTracUrls) ? ezTracUrls : defaultUrls,
  enhancementInitiativeId: enhancementInitiativeId
}

console.log({ customBindings }) // eslint-disable-line no-console

module.exports = bindingsMiddleware( { 'phoenix-home': defaultClientBindings['phoenix-home']}, customBindings)
