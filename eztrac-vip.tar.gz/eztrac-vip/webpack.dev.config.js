const _ = require('lodash');

module.exports = _(require('./webpack.config'))
.chain()
.clone()
.extend({
    output: {
        path: '/',
        filename: '/ez-trac-vip/scripts/bundle.js'
    },
    devtool: 'cheap-module-inline-source-map',
    plugins: []
})
.value();
