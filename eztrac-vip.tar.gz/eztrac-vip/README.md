# EZ-Trac VIP

## Fargate App Name
  `eztrac-vip`

## Description
  Node server that serves up UI and contains express server for handling Initiatives

## Dependencies
  * VIP postgres -- RDS Instance in AWS
  * ez-trac elastic -- Elasticsearch in AWS
  * papi

## Kibana logging
  This app has requests logged in a way that kibana can pick them up through the syslog drain.

  * [Non Prod Logs][kibana-nonprod]

  * [Prod Logs][kibana-prod]

## Vault

### Paths
  * `/secret/ez-trac/vip-services/np` -- non prod server values
  * `/secret/ez-trac/vip-services/prod` -- prod server values
  * `/secret/ez-trac/vip-ui/np` -- non prod UI values
  * `/secret/ez-trac/vip-ui/prod` -- prod UI values
### Values
  * `oauth` -- Contains `client-id` and `client-secret`. Present in all paths
  * `db` -- Contains `db-user` and `db-password` as well as `default-db` for the RDS instance. Present only in `vip-services` paths.

Ex:
  `vault read secret/ez-trac/vip-services/np/oauth` -- Would show you `client-id` and `client-secret` for this app's server

### Local Ocelot Route
  This project has been converted to the Phoenix Navbar.  It requires local Ocelot to be configured and running with this route:

  '''
    {
    "route": "localhost/ez-trac-vip",
    "hosts": ["http://localhost:3300"],
    "cookie-name": "ez-trac-vip-local",
    "client-id": "PD-EZ-TRAC-VIP-UI",
    "client-secret": "<<ENTER SECRET FROM VAULT>>",
    "require-auth": true,
    "user-header": "user-id",
    "client-header": "client-id",
    "user-profile-enabled": false
    }
  '''

[kibana-nonprod]: https://awskibana.velocity.ag/_plugin/kibana/#/discover?_g=()&_a=(columns:!(_source),index:%5Bcf_app-%5DYYYY.MM.DD,interval:auto,query:(query_string:(analyze_wildcard:!t,query:'app:%vip%22%20AND%20NonProd')),sort:!('@timestamp',desc))
[kibana-prod]: https://awskibana.velocity.ag/_plugin/kibana/#/discover?_g=()&_a=(columns:!(_source),index:%5Bcf_app-%5DYYYY.MM.DD,interval:auto,query:(query_string:(analyze_wildcard:!t,query:'app:%22vip%22%20AND%20Prod')),sort:!('@timestamp',desc))
