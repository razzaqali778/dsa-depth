if (typeof globalThis.crypto === 'undefined') {
  globalThis.crypto = require('crypto').webcrypto
}

const webpack = require('webpack')
const CompressionPlugin = require('compression-webpack-plugin')
const TerserPlugin = require('terser-webpack-plugin')
const path = require('path')

const isProd = process.env.NODE_ENV === 'production'

const getPlugins = () => {
  const plugins = []

  if (isProd) {
    plugins.push(new webpack.DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify('production'),
    }))

    plugins.push(new webpack.IgnorePlugin({
      resourceRegExp: /regenerator|nodent|js-beautify/,
      contextRegExp: /ajv/,
    }))

    plugins.push(new CompressionPlugin({
      algorithm: 'gzip',
      filename: '[path][base].gz',
      test: /\.jsx?$|\.css$|\.html$/,
    }))
  } else {
    plugins.push(new webpack.HotModuleReplacementPlugin())
  }

  return plugins
}

const getDevTool = () => (isProd ? 'source-map' : 'cheap-module-source-map')

const getEntry = () => {
  const entry = []

  if (!isProd) {
    entry.push('webpack-hot-middleware/client?path=/ez-trac-vip/__webpack_hmr')
  }

  entry.push('core-js/stable')
  entry.push('regenerator-runtime/runtime')
  entry.push('./public/scripts/main')

  return entry
}

module.exports = {
  mode: isProd ? 'production' : 'development',
  devtool: getDevTool(),
  entry: getEntry(),
  module: {
    rules: [
      { test: /\.json$/, type: 'json' },
      {
        test: /\.jsx?$/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              ['@babel/preset-env', { targets: { browsers: ['> 1%', 'last 2 versions', 'ie >= 11'] } }],
              '@babel/preset-react',
            ],
            plugins: [
              '@babel/plugin-proposal-class-properties',
              'react-hot-loader/babel',
            ],
          },
        },
        exclude: /node_modules/,
      },
    ],
  },
  optimization: isProd ? {
    minimize: true,
    minimizer: [new TerserPlugin()],
  } : {},
  output: {
    filename: 'bundle.js',
    path: path.resolve(__dirname, 'public/scripts'),
    publicPath: '/ez-trac-vip/scripts',
  },
  plugins: getPlugins(),
  resolve: {
    extensions: [
      '.js',
      '.json',
      '.jsx',
      '.css',
      '.less',
    ],
  },
}
