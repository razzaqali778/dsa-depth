import config from './config'

const express = require('express')
const proxy = require('express-http-proxy')
const { getAzureToken } = require('./services/util/AzureTokenUtil')

const router = express.Router()

const urlParser = require('url')

const proxyReqOptDecorator = async req => {
  try {
    if ( process.env.NODE_ENV !== 'production' ) {
      req.headers['user-id'] = process.env.USER
    }
    const token = await getAzureToken()
    req.headers.Authorization = `Bearer ${token}`

    return req
  } catch ( err ) {
    console.log('Error settings headers: ', err.error || err)
  }
}
const proxyReqPathResolver = req => {
  const path = urlParser.parse(req.url).path

  return path
}

const velocityHome = config.get('velocity-home')
router.use('/papi', proxy(`https://profile.${velocityHome}`, {
  proxyReqPathResolver,
  proxyReqOptDecorator,
}))
// router.use('/messaging', proxy('https://messaging.velocity-np.ag/v5/messages', {
//   proxyReqPathResolver,
//   proxyReqOptDecorator,
// }))

/* eslint-enable */

export default router
