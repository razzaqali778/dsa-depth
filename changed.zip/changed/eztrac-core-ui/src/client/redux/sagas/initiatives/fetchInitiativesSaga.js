import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import forEach from 'lodash/forEach'
import map from 'lodash/map'
import omit from 'lodash/omit'
import toastr from 'toastr'
import actions from '../../actions'
import {get} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'

export function* fetchInitiatives() {
    const {payload, error} = yield call(get, {
        url: `${serviceBindings.vipServices}/v2/initiatives?isAllocable=true&fields=parent,tags`
    })

    if (error) {
        toastr.error(payload, 'Failed to fetch initiatives')
        yield dispatch(actions.setInitiatives([]))
    } else {
        const updatedTagsPayload = map(payload, (initiative) => {
            const newTags = {region: null, businessUnit: null}
            forEach(initiative.tags, (tag) => {
                if (tag.tagId === 'REGION') {
                    newTags.region = tag.tagValue
                } else if (tag.tagId === 'BUS-UNIT') {
                    newTags.businessUnit = tag.tagValue
                }
            })

            return omit(
                {...initiative, region: newTags.region, businessUnit: newTags.businessUnit},
                ['tags']
            )
        })
        yield dispatch(actions.setInitiatives(updatedTagsPayload))
    }
}

export default function* () {
    yield takeLatest([actions.fetchInitiatives().type], fetchInitiatives)
}
