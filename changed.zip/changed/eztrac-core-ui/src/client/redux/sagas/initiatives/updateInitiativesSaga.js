import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import find from 'lodash/find'
import map from 'lodash/map'
import toastr from 'toastr'
import {getSelectedTeam, getTimeFrames} from '../../selectors'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import {patch} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

const buildUpdateRequest = (teamId, initiativeData) => ({
    verb: patch,
    url: `${coreServicesUrl}/v2/efforts/allocations/team/${teamId}`,
    body: initiativeData,
    headers: {Accept: '*/*'}
})

export function* updateInitiatives({payload: updatePayload}) {
    yield dispatch(actions.setIsLoading(true))
    try {
        const {selectedTimeFrameId, selectedTimeFrameInitiatives, copyForwardToTimeFrame} =
            updatePayload
        const selectedTeam = yield select(getSelectedTeam)
        const timeFrameIdsToUpdate = copyForwardToTimeFrame
            ? map(copyForwardToTimeFrame, 'id')
            : [selectedTimeFrameId]

        const allocations = map(selectedTimeFrameInitiatives, (initiative) => {
            const {id, teamCostPct} = initiative

            return {initiativeId: id, percentageOfTeamCost: teamCostPct}
        })

        const initiativeData = map(timeFrameIdsToUpdate, (timeFrameId) => ({
            timeFrameId,
            allocations
        }))

        const {body, verb, url, headers} = buildUpdateRequest(selectedTeam.id, initiativeData)

        const {payload, error} = yield call(verb, {
            url,
            body,
            headers
        })

        if (error) {
            const timeFrames = yield select(getTimeFrames)
            const currentSelectedTimeFrame = find(
                timeFrames,
                (timeframe) => selectedTimeFrameId === timeframe.id
            )
            const copyForwardNames = map(copyForwardToTimeFrame || [], 'name')
                .filter(Boolean)
                .join(', ')
            const copyForwardIds = map(copyForwardToTimeFrame || [], 'id')
                .filter(Boolean)
                .join(', ')
            const timeFrameName =
                currentSelectedTimeFrame?.name ||
                copyForwardNames ||
                copyForwardIds ||
                selectedTimeFrameId
            toastr.error(
                makeErrorMsgUserFriendly(payload),
                `Failed to save initiatives for ${timeFrameName}`
            )
        } else {
            yield dispatch(actions.fetchTeamData())
            toastr.success('Successfully saved initiatives')
        }
    } finally {
        yield dispatch(actions.setIsLoading(false))
    }
}

export default function* () {
    yield takeLatest([actions.updateInitiatives().type], updateInitiatives)
}
