import {put as dispatch, select, takeEvery} from 'redux-saga/effects'
import {getSelectedTimeFrameTeamInitiatives} from '../../selectors/initiatives'
import actions from '../../actions'

export function* copyInitiativesForward({payload}) {
    const selectedTimeFrameInitiatives = yield select(getSelectedTimeFrameTeamInitiatives)
    const {copyForwardToTimeFrame} = payload

    yield dispatch({
        payload: {
            copyForwardToTimeFrame,
            selectedTimeFrameInitiatives
        },
        type: actions.updateInitiatives().type
    })
    yield dispatch(actions.clearCopyForwardTimeFrame())
}
export default function* () {
    yield takeEvery([actions.copyInitiativesForward().type], copyInitiativesForward)
}

// TODO: Here we want to call a new update function that makes a single service call for all time frames passed in.
// This will require changes to the backend as a multi timeframe update endpoint has not yet been defined.
