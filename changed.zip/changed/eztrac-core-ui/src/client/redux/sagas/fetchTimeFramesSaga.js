import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import findIndex from 'lodash/findIndex'
import first from 'lodash/first'
import last from 'lodash/last'
import toastr from 'toastr'
import {get} from './helpers/makeFetchCall'
import {getTimeFrames} from '../selectors'
import {serviceBindings} from './helpers/getServiceBindings'
import actions from '../actions'
import getCurrentMonthTimeFrame from '../selectors/getCurrentMonthTimeFrame'

const coreServicesUrl = serviceBindings.coreServices

export function* fetchTimeFrames() {
    const {payload, error} = yield call(get, {
        url: `${coreServicesUrl}/v2/timeframes`
    })

    if (error) {
        toastr.error(payload, 'Failed to fetch timeframes')
    } else {
        yield dispatch(actions.setTimeFrames(payload))
        const currentMonthTimeFrame = yield select(getCurrentMonthTimeFrame)

        if (!currentMonthTimeFrame) {
            toastr.error('Failed to fetch current month timeframe')
            return
        }

        yield dispatch(actions.setSelectedTimeFrameId(currentMonthTimeFrame?.id))
        const timeFrames = yield select(getTimeFrames)
        const currentIndex = findIndex(
            timeFrames,
            (timeFrame) => timeFrame.id === currentMonthTimeFrame.id
        )

        if (!timeFrames.length || currentIndex === -1) {
            toastr.error('Failed to match current month timeframe')
            return
        }

        const getTimeFrameObject = (num) => {
            const requestedTimeFrame = timeFrames[currentIndex + num]
            return requestedTimeFrame || (num < 0 ? first(timeFrames) : last(timeFrames))
        }

        yield dispatch(
            actions.setStartTimeFrame({
                id: getTimeFrameObject(-1).id,
                startCode: getTimeFrameObject(-1).startDate
            })
        )
        yield dispatch(
            actions.setEndTimeFrame({
                id: getTimeFrameObject(2).id,
                startCode: getTimeFrameObject(2).startDate
            })
        )
    }
}

export default function* () {
    yield takeLatest([actions.fetchTimeFrames().type], fetchTimeFrames)
}
