import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import filter from 'lodash/filter'
import toastr from 'toastr'
import uniqBy from 'lodash/uniqBy'
import {get} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const costingServicesUrl = serviceBindings.costingServices

export function* fetchAllPeople() {
    const {payload, error} = yield call(get, {
        url: `${costingServicesUrl}/v1/people`
    })
    if (error) {
        toastr.error(payload, 'Failed to fetch people')
        yield dispatch(actions.setPeople([]))
        yield dispatch(actions.setActivePeople([]))
    } else {
        yield dispatch(actions.setPeople(uniqBy(payload, 'personId')))
        yield dispatch(actions.setActivePeople(uniqBy(filter(payload, 'isActive'), 'personId')))
    }
}

export default function* () {
    yield takeLatest([actions.fetchPeople().type], fetchAllPeople)
}
