import {filter, find, isEmpty, isEqual, map, pick, sortBy} from 'lodash'

const normalizeNumber = (value) => Number(value)

export function hasPeopleDataChanged(teamPeople, changedPeople, selectedTimeFrameId) {
    const filteredTeamPeople = filter(
        teamPeople,
        (person) => person.timeFrameId === selectedTimeFrameId
    )
    const comparableTeamPeople = map(filteredTeamPeople, (i) => ({
        ...pick(i, ['personId']),
        participationPct: normalizeNumber(i.participationPct)
    }))
    const comparableChangedPeople = map(changedPeople, (i) => ({
        ...pick(i, ['personId']),
        participationPct: normalizeNumber(i.participationPct)
    }))
    const sortedComparableTeamPeople = sortBy(comparableTeamPeople, ['personId'])
    const sortedComparableChangedPeople = sortBy(comparableChangedPeople, ['personId'])

    return !isEqual(sortedComparableTeamPeople, sortedComparableChangedPeople)
}

export function hasForecastedPeopleDataChanged(
    teamForecastedPeople,
    forecastedChangedPeople,
    selectedTimeFrameId
) {
    const filteredForecastedTeamPeople = filter(
        teamForecastedPeople,
        (person) => person.timeFrameId === selectedTimeFrameId
    )
    const comparableForecastedTeamPeople = map(filteredForecastedTeamPeople, (i) => ({
        ...pick(i, ['rateId', 'costGroupId']),
        numberOfPeople: normalizeNumber(i.numberOfPeople)
    }))
    const comparableForecastedChangedPeople = map(forecastedChangedPeople, (i) => ({
        ...pick(i, ['rateId', 'costGroupId']),
        numberOfPeople: normalizeNumber(i.numberOfPeople)
    }))
    const sortedForecastedComparableTeamPeople = sortBy(
        comparableForecastedTeamPeople,
        (person) => person.rateId + person.costGroupId
    )
    const sortedForecastedComparableChangedPeople = sortBy(
        comparableForecastedChangedPeople,
        (person) => person.rateId + person.costGroupId
    )

    return !isEqual(sortedForecastedComparableTeamPeople, sortedForecastedComparableChangedPeople)
}
export function validateNumberOfPeople(numberOfPeople) {
    return numberOfPeople === '' || /^\d*\.?\d{0,2}$/.test(numberOfPeople)
}

export function validateNewForecastedPerson(
    newForecastedPersonData,
    selectedTimeFrameForecastedPeople
) {
    return (
        isEmpty(newForecastedPersonData.costGroupId) ||
        isEmpty(newForecastedPersonData.rateId) ||
        find(
            selectedTimeFrameForecastedPeople,
            (forecastedPerson) =>
                forecastedPerson.costGroupId === newForecastedPersonData.costGroupId &&
                forecastedPerson.rateId === newForecastedPersonData.rateId
        )
    )
}
