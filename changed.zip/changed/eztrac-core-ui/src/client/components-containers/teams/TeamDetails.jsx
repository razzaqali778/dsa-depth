import '../../styles/containers/AppContainerStyles.css'
import {Grid, GridCell, GridInner} from '@rmwc/grid'
import {Icon} from '@rmwc/icon'
import {Tab, TabBar} from '@rmwc/tabs'
import {includes, isEmpty, size} from 'lodash'
import React from 'react'
import Select from 'react-select-plus'
import {getActiveEngagements} from '../../redux/utils/getActiveEngagements'
import {
    hasForecastedPeopleDataChanged,
    hasPeopleDataChanged
} from '../../redux/utils/validatorsForPeople'
import {hasInitiativeDataChanged} from '../../redux/utils/validatorsForInitiatives'
import EngagementTabContainer from '../engagements/engagementTab/EngagementTabContainer'
import InitiativeTabContainer from '../initiatives/InitiativeTabContainer'
import PeopleTabContainer from '../people/PeopleTabContainer'
import SaveLockedTimeFrameWarningContainer from './SaveLockedTimeFrameWarningContainer'
import UnsavedDataModalContainer from './UnsavedDataModalContainer'
import TeamFilters from './TeamFilters'

const tabKeyToIndex = (teamTab) => {
    switch (teamTab.toLowerCase()) {
        case 'engagements':
            return 2
        case 'people':
            return 1
        case 'initiatives':
            return 0
        default:
            return 2
    }
}

const indexToTabKey = (tabIndex) => {
    switch (tabIndex) {
        case 2:
            return 'engagements'
        case 1:
            return 'people'
        case 0:
            return 'initiatives'
        default:
            return 'engagements'
    }
}

const renderTeamTabs = (
    setSelectedTeamTab,
    selectedTeamTab,
    selectedTeam,
    selectedTimeFrameInitiatives,
    groupedAndSortedEngagements,
    isShowingHistoricEngagements,
    setUnsavedDataModalBool,
    teamPeople,
    selectedTimeFrameTeamPeople,
    selectedTimeFrameId,
    teamForecastedPeople,
    selectedTimeFrameForecastedPeople,
    unsavedDataModalBool,
    teamInitiatives
) => {
    const numberOfEngagements = isShowingHistoricEngagements
        ? Object.keys(groupedAndSortedEngagements).length
        : Object.keys(getActiveEngagements(groupedAndSortedEngagements)).length
    const numberOfInitiatives = size(selectedTimeFrameInitiatives)

    const numberOfPeople =
        size(selectedTimeFrameTeamPeople) + size(selectedTimeFrameForecastedPeople)

    if (!isEmpty(selectedTeam) && selectedTeam.id) {
        return (
            <TabBar
                activeTabIndex={tabKeyToIndex(selectedTeamTab)}
                className="tabs-margin"
                onActivate={(evt) =>
                    hasPeopleDataChanged(
                        teamPeople,
                        selectedTimeFrameTeamPeople,
                        selectedTimeFrameId
                    ) ||
                    hasForecastedPeopleDataChanged(
                        teamForecastedPeople,
                        selectedTimeFrameForecastedPeople,
                        selectedTimeFrameId
                    ) ||
                    hasInitiativeDataChanged(
                        teamInitiatives,
                        selectedTimeFrameInitiatives,
                        selectedTimeFrameId
                    )
                        ? setUnsavedDataModalBool(true)
                        : setSelectedTeamTab(indexToTabKey(evt.detail.index))
                }
            >
                <span className="tab-divider" />
                <Tab>
                    <h4>Initiatives </h4>
                    <div className="flex-container">
                        <span className="initiativesBadge">{numberOfInitiatives}</span>
                    </div>
                </Tab>
                <span className="tab-divider" />
                <Tab>
                    <h4>People</h4>
                    <div className="flex-container">
                        <span className="peopleBadge">{numberOfPeople}</span>
                    </div>
                </Tab>
                <span className="tab-divider" />
                <Tab>
                    <h4>Engagements</h4>
                    <div className="flex-container">
                        <span className="engagementsBadge">{numberOfEngagements}</span>
                    </div>
                </Tab>
                <span className="tab-divider" />
            </TabBar>
        )
    }

    return null
}

const renderTabBody = (selectedTeamTab) => {
    const constructionHtml = (
        <GridCell span="12">
            <div>
                <br />
                <br />
                <h5>This tab is under construction</h5>
            </div>
        </GridCell>
    )
    switch (selectedTeamTab.toLowerCase()) {
        case 'engagements':
            return <EngagementTabContainer />
        case 'people':
            return <PeopleTabContainer />
        case 'initiatives':
            return <InitiativeTabContainer />
        default:
            return constructionHtml
    }
}

class TeamDetails extends React.Component {
    constructor(props) {
        super(props)
        this.show = this.show.bind(this)
    }

    callback = (event) => this.show(event)

    componentDidMount() {
        window.addEventListener('beforeunload', this.callback)
    }

    componentWillUnmount() {
        window.removeEventListener('beforeunload', this.callback)
    }

    show(event) {
        const {
            teamInitiatives,
            selectedTimeFrameInitiatives,
            selectedTimeFrameId,
            teamPeople,
            selectedTimeFrameTeamPeople,
            teamForecastedPeople,
            selectedTimeFrameForecastedPeople
        } = this.props
        if (
            hasInitiativeDataChanged(
                teamInitiatives,
                selectedTimeFrameInitiatives,
                selectedTimeFrameId
            ) ||
            hasPeopleDataChanged(teamPeople, selectedTimeFrameTeamPeople, selectedTimeFrameId) ||
            hasForecastedPeopleDataChanged(
                teamForecastedPeople,
                selectedTimeFrameForecastedPeople,
                selectedTimeFrameId
            )
        ) {
            // eslint-disable-next-line no-param-reassign
            event.returnValue = 'Page has unsaved changes. Continue?'
        }
    }

    render() {
        const {
            favoriteButtonClickedSaga,
            favoriteTeams,
            hasManageTeams,
            selectedTeam,
            selectedCommunityId,
            selectedPlatformId,
            selectedOrgId,
            selectedTeamTab,
            setSelectedTeam,
            setSelectedCommunityId,
            setSelectedPlatformId,
            setSelectedOrgId,
            setSelectedTeamTab,
            teamSelectOptions,
            teamFiltersOptions,
            teamInitiatives,
            selectedTimeFrameInitiatives,
            selectedTimeFrameId,
            groupedAndSortedEngagements,
            isShowingHistoricEngagements,
            unsavedDataModalBool,
            setUnsavedDataModalBool,
            teamPeople,
            selectedTimeFrameTeamPeople,
            teamForecastedPeople,
            selectedTimeFrameForecastedPeople,
            saveLockedTimeFrameData
        } = this.props
        const initiativeChangeData = hasInitiativeDataChanged(
            teamInitiatives,
            selectedTimeFrameInitiatives,
            selectedTimeFrameId
        )
        const peopleChangeData =
            hasPeopleDataChanged(teamPeople, selectedTimeFrameTeamPeople, selectedTimeFrameId) ||
            hasForecastedPeopleDataChanged(
                teamForecastedPeople,
                selectedTimeFrameForecastedPeople,
                selectedTimeFrameId
            )

        document.title = selectedTeam && selectedTeam.name ? selectedTeam.name : 'EZ Trac Core'

        return (
            <div className="app-container container">
                <div>{unsavedDataModalBool && <UnsavedDataModalContainer />} </div>
                {saveLockedTimeFrameData.showWarning && <SaveLockedTimeFrameWarningContainer />}
                <Grid>
                    <GridCell span="6" style={{marginTop: '-25px'}}>
                        <h2>Team Details</h2>
                        <GridInner>
                            <TeamFilters
                                setSelectedCommunityId={setSelectedCommunityId}
                                setSelectedPlatformId={setSelectedPlatformId}
                                setSelectedOrgId={setSelectedOrgId}
                                filtersOptions={teamFiltersOptions}
                                selectedPlatformId={selectedPlatformId}
                                selectedCommunityId={selectedCommunityId}
                                selectedOrgId={selectedOrgId}
                            />
                            <GridCell className="teamSelect" span={selectedTeam.id ? '10' : '12'}>
                                <Select
                                    id="teamSelect"
                                    onChange={(team) => {
                                        if (initiativeChangeData || peopleChangeData) {
                                            setUnsavedDataModalBool(true)
                                        } else {
                                            setSelectedTeam({
                                                id: team.value,
                                                name: team.label,
                                                isActive: team.active
                                            })
                                        }
                                    }}
                                    options={teamSelectOptions}
                                    placeholder="Select a team..."
                                    resetValue
                                    value={selectedTeam.id}
                                />
                            </GridCell>
                            {isEmpty(selectedTeam.id) ? (
                                <GridCell span="2" />
                            ) : (
                                <GridCell className="buttonContainer" span="2">
                                    <Icon
                                        className="favoriteButton"
                                        icon={
                                            includes(favoriteTeams, selectedTeam.id)
                                                ? 'star'
                                                : 'star_border'
                                        }
                                        onClick={() =>
                                            favoriteButtonClickedSaga({
                                                [selectedTeam.id]: selectedTeam.id
                                            })
                                        }
                                        title="Favorite"
                                    />
                                    {hasManageTeams ? (
                                        <Icon
                                            className="editButton"
                                            icon="edit"
                                            onClick={() => {
                                                const path = selectedTeam
                                                    ? `/ez-trac-core/team-maintenance?teamId=${selectedTeam.id}`
                                                    : 'ez-trac-core/team-maintenance'
                                                window.location = path
                                            }}
                                            title="Edit Team"
                                        />
                                    ) : null}
                                </GridCell>
                            )}
                        </GridInner>
                    </GridCell>
                </Grid>
                <Grid>
                    <GridCell span="12">
                        {renderTeamTabs(
                            setSelectedTeamTab,
                            selectedTeamTab,
                            selectedTeam,
                            selectedTimeFrameInitiatives,
                            groupedAndSortedEngagements,
                            isShowingHistoricEngagements,
                            setUnsavedDataModalBool,
                            teamPeople,
                            selectedTimeFrameTeamPeople,
                            selectedTimeFrameId,
                            teamForecastedPeople,
                            selectedTimeFrameForecastedPeople,
                            unsavedDataModalBool,
                            teamInitiatives
                        )}
                    </GridCell>
                </Grid>
                {selectedTeamTab && !isEmpty(selectedTeam.id) && renderTabBody(selectedTeamTab)}
            </div>
        )
    }
}
export default TeamDetails
