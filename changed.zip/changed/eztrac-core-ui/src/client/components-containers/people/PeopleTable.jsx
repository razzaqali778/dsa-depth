import {Chip, ChipSet} from '@rmwc/chip'
import {
    DataTable,
    DataTableBody,
    DataTableCell,
    DataTableContent,
    DataTableHead,
    DataTableHeadCell,
    DataTableRow
} from '@rmwc/data-table'
import {Icon} from '@rmwc/icon'
import {cloneDeep, differenceBy, isEmpty, map, sortBy} from 'lodash'
import React, {useEffect, useRef} from 'react'
import Select from 'react-select'
import {canEditTimeFrame} from '../utils/canEditTimeFrame'
import {getTimeFrameIdNMonthsAway} from '../../redux/utils/timeFrameUtils'
import {setSorting} from '../../utils/sortingHelper'
import {validatePct} from '../../redux/utils/validatorsForInitiatives'
import PeopleFinderDialogContainer from './PeopleFinderDialogContainer'

const newPersonPicked = (evt) => ({...evt.value, participationPct: 100})

const peopleOptions = (allActivePeople, selectedTimeFrameTeamPeople) => {
    const noDuplicatePeople = differenceBy(allActivePeople, selectedTimeFrameTeamPeople, 'personId')
    const mapOptionsPeople = map(sortBy(noDuplicatePeople, ['personName']), (person) => ({
        value: person,
        label: `${person.personName} (${person.personId})`
    }))

    return mapOptionsPeople
}

const sortDir = [null, -1, 1]

const customFilterOption = (option, rawInput) => {
    const words = rawInput.split(' ')

    return words.reduce(
        (acc, cur) => acc && option.label.toLowerCase().includes(cur.toLowerCase()),
        true
    )
}

const notFound = 'unknown'

const personUrl = (id) => `https://velocity.ag/profile/users/${id}`

const createEmailLink = (emailAddress) => <a href={`mailto:${emailAddress}`}>{emailAddress}</a>

const renderDetails = (userData) => userData || notFound

const renderJobDetails = (employeeType, jobTitle) =>
    employeeType.toUpperCase() === 'CONTRACTOR' ? employeeType : renderDetails(jobTitle)

const renderEmail = (email) => (email ? createEmailLink(email) : notFound)

const renderUserLink = (id, name) => (
    <a className="people-link" href={personUrl(id)} rel="noopener noreferrer" target="_blank">
        {name}
    </a>
)

const renderManagerDetails = ({id, preferredName}) =>
    id ? (
        <span>
            {renderUserLink(id, preferredName?.full)}
            <span className="italic"> ({id})</span>
        </span>
    ) : (
        notFound
    )

const renderPersonHoverDetails = (person, additionalData) => {
    const {personName, personId, costGroupName} = person
    const {email, jobTitle, employeeType, id, manager, status} = additionalData

    if (!status || status === 'EMPTY') return ''
    if (status === 'LOADING')
        return <span className="person-details-container">Loading user details...</span>
    if (id !== personId || status === 'ERROR') {
        return <span className="person-details-container">Unable to find additional user data</span>
    }

    return (
        <div className="person-details-container">
            <div className="person-details">
                <p>
                    {renderUserLink(personId, personName)}
                    <span className="italic"> ({personId})</span>
                </p>
            </div>
            <div className="person-details">
                <span className="bold">Manager: </span>
                <span>{renderManagerDetails({...manager})}</span>
            </div>
            <div className="person-details">
                <span className="bold">Title: </span>
                <span>{renderJobDetails(employeeType, jobTitle)}</span>
            </div>
            <div className="person-details">
                <span className="bold">Email: </span>
                <span>{renderEmail(email)}</span>
            </div>
            <div className="person-details">
                <span className="bold">Cost Group: </span>
                <span>{renderDetails(costGroupName)}</span>
            </div>
        </div>
    )
}

const PeopleTable = ({
    selectedTimeFrameId,
    selectedTimeFrame,
    setIsPeopleModifyFinderOpen,
    clearNewPersonData,
    newPersonData,
    selectedTimeFrameTeamPeople,
    setSelectedTimeFrameTeamPeople,
    deletePersonFromTeamState,
    setSortOrderPreferencePeopleLocal,
    sortOrderPreferencePeopleLocal,
    allActivePeople,
    addNewPerson,
    currentTimeFrame,
    timeFrames,
    selectedTimeFrameForecastedPeople,
    isAdmin,
    userDetailsHoveredSaga,
    userProfileDetails
}) => {
    const allowEditing = canEditTimeFrame(selectedTimeFrame, isAdmin)
    // A ref (not a plain variable) is required here: this component re-renders on every
    // keystroke/state change, and a plain `let timer` is re-initialized on each render, so a
    // pending hover timeout set on one render could never be cleared by the handler bound on a
    // later render. That left stale "Loading user details..." tooltips/saga calls firing after
    // the mouse had already left the row.
    const timerRef = useRef(null)

    useEffect(() => () => clearTimeout(timerRef.current), [])

    return (
        <DataTable style={{width: '100%', marginRight: '10px'}}>
            <PeopleFinderDialogContainer />
            <DataTableContent style={{width: '100%'}}>
                <DataTableHead>
                    <DataTableRow>
                        <DataTableCell>Team Members</DataTableCell>
                    </DataTableRow>
                    {allowEditing && (
                        <DataTableRow>
                            <DataTableCell colSpan="3">
                                <Select
                                    className="select-person"
                                    filterOption={customFilterOption}
                                    isClearable
                                    isSearchable
                                    onChange={(evt) => {
                                        if (evt.value.personId !== undefined) {
                                            addNewPerson(newPersonPicked(evt))
                                        }
                                        clearNewPersonData()
                                    }}
                                    onKeyDown={(evt) => {
                                        if (
                                            evt.key === 'Enter' &&
                                            newPersonData.personId !== undefined
                                        ) {
                                            // `evt` here is the keyboard event, not a react-select
                                            // option - it has no `.value`, so the previous
                                            // `newPersonPicked(evt)` silently added a person
                                            // record with only `participationPct` set (no
                                            // personId/personName). Use the already-staged
                                            // `newPersonData` instead, matching the onChange path.
                                            addNewPerson({...newPersonData, participationPct: 100})
                                        }
                                    }}
                                    options={peopleOptions(
                                        allActivePeople,
                                        selectedTimeFrameTeamPeople
                                    )}
                                    placeholder="Add New Person"
                                    value={
                                        newPersonData.personName
                                            ? {label: newPersonData.personName}
                                            : null
                                    }
                                />
                            </DataTableCell>
                            <DataTableCell className="icon-column">
                                <Icon
                                    className="search-icon"
                                    icon="search_rounded"
                                    onClick={() => setIsPeopleModifyFinderOpen(true)}
                                />
                            </DataTableCell>
                        </DataTableRow>
                    )}
                    <DataTableRow>
                        <DataTableHeadCell
                            className="people-name-column"
                            onClick={() => {
                                if (!isEmpty(selectedTimeFrameTeamPeople)) {
                                    setSorting(
                                        setSortOrderPreferencePeopleLocal,
                                        setSelectedTimeFrameTeamPeople,
                                        selectedTimeFrameTeamPeople,
                                        sortOrderPreferencePeopleLocal.nameNum,
                                        'nameNum',
                                        'personName',
                                        {
                                            ...sortOrderPreferencePeopleLocal,
                                            nameNum: 0,
                                            participationNum: 0
                                        }
                                    )
                                }
                            }}
                            sort={sortDir[sortOrderPreferencePeopleLocal.nameNum]}
                        >
                            Name
                        </DataTableHeadCell>
                        <DataTableHeadCell className="icon-column" />
                        <DataTableHeadCell
                            className="participation-column"
                            onClick={() => {
                                if (!isEmpty(selectedTimeFrameTeamPeople)) {
                                    setSorting(
                                        setSortOrderPreferencePeopleLocal,
                                        setSelectedTimeFrameTeamPeople,
                                        selectedTimeFrameTeamPeople,
                                        sortOrderPreferencePeopleLocal.participationNum,
                                        'participationNum',
                                        'participationPct',
                                        {
                                            ...sortOrderPreferencePeopleLocal,
                                            nameNum: 0,
                                            participationNum: 0
                                        }
                                    )
                                }
                            }}
                            sort={sortDir[sortOrderPreferencePeopleLocal.participationNum]}
                        >
                            Participation %
                        </DataTableHeadCell>
                        <DataTableHeadCell className="icon-column" />
                    </DataTableRow>
                </DataTableHead>
                {selectedTimeFrameId ===
                    getTimeFrameIdNMonthsAway(currentTimeFrame.id, timeFrames, 1) &&
                isEmpty(selectedTimeFrameTeamPeople) &&
                !isEmpty(selectedTimeFrameForecastedPeople) ? (
                    <DataTableBody>
                        <DataTableRow>
                            <DataTableCell alignMiddle colSpan="4">
                                <ChipSet>
                                    <Chip
                                        className="chip-warning"
                                        label="This month still contains forecasted people. Please add new people."
                                    />
                                </ChipSet>
                            </DataTableCell>
                        </DataTableRow>
                    </DataTableBody>
                ) : (
                    <DataTableBody>
                        {isEmpty(selectedTimeFrameTeamPeople) && (
                            <DataTableRow>
                                <DataTableCell alignMiddle colSpan="4">
                                    No team members for this month.
                                </DataTableCell>
                            </DataTableRow>
                        )}
                        {map(selectedTimeFrameTeamPeople, (person, index) => (
                            <DataTableRow key={person.personId}>
                                <DataTableCell className="details-row-wrapper">
                                    <div
                                        className="has-details"
                                        onMouseEnter={() => {
                                            timerRef.current = setTimeout(() => {
                                                userDetailsHoveredSaga(person)
                                            }, 800)
                                        }}
                                        onMouseLeave={() => {
                                            clearTimeout(timerRef.current)
                                            userDetailsHoveredSaga({})
                                        }}
                                    >
                                        <Icon
                                            className="info-button person-details-info-icon"
                                            icon="info_outline"
                                        />
                                        {userProfileDetails &&
                                            renderPersonHoverDetails(person, userProfileDetails)}
                                    </div>
                                    <a
                                        className="people-link"
                                        href={personUrl(person.personId)}
                                        rel="noopener noreferrer"
                                        target="_blank"
                                    >
                                        {' '}
                                        {person.personName}
                                    </a>
                                </DataTableCell>
                                <DataTableCell className="icon-column" />

                                {allowEditing ? (
                                    <DataTableCell className="table-input input-table-column-numbers">
                                        <input
                                            onChange={(evt) => {
                                                if (validatePct(evt.target.value)) {
                                                    const newPeople = cloneDeep(
                                                        selectedTimeFrameTeamPeople
                                                    )
                                                    newPeople[index].participationPct = Number(
                                                        evt.target.value
                                                    )
                                                    setSelectedTimeFrameTeamPeople(newPeople)
                                                }
                                            }}
                                            type="text"
                                            value={
                                                `${selectedTimeFrameTeamPeople[index].participationPct}` ||
                                                ''
                                            }
                                        />{' '}
                                        %
                                    </DataTableCell>
                                ) : (
                                    <DataTableCell className="table-input input-table-column-numbers">
                                        {selectedTimeFrameTeamPeople[index].participationPct} %
                                    </DataTableCell>
                                )}

                                <DataTableCell className="delete-button-column">
                                    {allowEditing ? (
                                        <Icon
                                            className="delete-person-button"
                                            icon="delete_forever"
                                            onClick={() => {
                                                deletePersonFromTeamState(person)
                                            }}
                                        />
                                    ) : null}
                                </DataTableCell>
                            </DataTableRow>
                        ))}
                    </DataTableBody>
                )}
            </DataTableContent>
        </DataTable>
    )
}
export default PeopleTable
