import {Button} from '@rmwc/button'
import {
    DataTable,
    DataTableBody,
    DataTableCell,
    DataTableContent,
    DataTableRow
} from '@rmwc/data-table'
import {filter, get, map, sumBy} from 'lodash'
import React from 'react'
import ReactTooltip from 'react-tooltip'
import Select from 'react-select'
import {canEditTimeFrame} from '../utils/canEditTimeFrame'
import {changeSelectedMonthData} from '../utils/ChangeSelectedMonth'
import {
    getTimeFrameIdNMonthsAway,
    getTimeFrameNameNMonthsAway
} from '../../redux/utils/timeFrameUtils'
import {
    hasForecastedPeopleDataChanged,
    hasPeopleDataChanged
} from '../../redux/utils/validatorsForPeople'
import ForecastedPeopleTableContainer from './ForecastedPeopleTableContainer'
import MonthDropdownContainer from '../teams/MonthDropdownContainer'
import PeopleTableContainer from './PeopleTableContainer'
import UnsavedDataModalContainer from '../teams/UnsavedDataModalContainer'
import {copyForwardButtonDisabled} from '../utils/copyForwardButtonDisabled'

const PeopleTab = ({
    selectedTimeFrameId,
    timeFrames,
    setSelectedTimeFrameId,
    teamPeople,
    forecastedPeople,
    establishInitialSortOrderPeople,
    sortOrderPreferencePeopleLocal,
    clearNewPersonData,
    clearNewForecastedPersonData,
    unsavedDataModalBool,
    teamInitiatives,
    sortOrderPreference,
    setSelectedTimeFrameTeamCost,
    teamCostData,
    clearNewInitiativeData,
    establishInitialSortOrder,
    selectedTimeFrameTeamPeople,
    selectedTimeFrameForecastedPeople,
    setUnsavedDataModalBool,
    selectedTimeFrame,
    setSelectedTimeFrameTeamPeople,
    setSelectedTimeFrameForecastedPeople,
    updatePeople,
    copyCalendarModalBool,
    setCopyCalendarModalBool,
    overwrittenMonths,
    selectedTimeFrameTeamCost,
    isAdmin,
    setSaveLockedTimeFrameData
}) => {
    const hasUnsavedPeople =
        hasPeopleDataChanged(teamPeople, selectedTimeFrameTeamPeople, selectedTimeFrameId) ||
        hasForecastedPeopleDataChanged(
            forecastedPeople,
            selectedTimeFrameForecastedPeople,
            selectedTimeFrameId
        )
    const isLockedTimeframe = get(selectedTimeFrame, 'lockdown', true)
    const allowEditing = canEditTimeFrame(selectedTimeFrame, isAdmin)
    const isCopyForwardDisabled = () =>
        copyForwardButtonDisabled(hasUnsavedPeople, selectedTimeFrame, isAdmin)

    const validDates = filter(timeFrames, (timeFrame) => timeFrame.isActive)
    const formattedDates = map(validDates, (date) => ({label: date.name, value: date.id}))
    const selectedTimeFrameName = get(selectedTimeFrame, 'name', '')
    const clearAllPeopleData = () => {
        clearNewPersonData()
        clearNewForecastedPersonData()
        const newTimeFramePeople = filter(
            teamPeople,
            (person) => person.timeFrameId === selectedTimeFrameId
        )
        const newTimeFrameForecastPeople = filter(
            forecastedPeople,
            (person) => person.timeFrameId === selectedTimeFrameId
        )

        setSelectedTimeFrameTeamPeople(newTimeFramePeople)
        setSelectedTimeFrameForecastedPeople(newTimeFrameForecastPeople)
    }

    const getTotalParticipation = () => {
        const teamMemberParticipation = sumBy(
            selectedTimeFrameTeamPeople,
            (person) => Number(person.participationPct) / 100
        )
        const placeholderParticipation = sumBy(selectedTimeFrameForecastedPeople, (person) =>
            Number(person.numberOfPeople)
        )
        const totalParticipation = (
            Number(teamMemberParticipation) + Number(placeholderParticipation)
        ).toFixed(2)

        return totalParticipation
    }

    const renderLockedTimeFrameMessage = () =>
        allowEditing ? 'LOCKED - only admin users are allowed to edit' : 'LOCKED'

    return (
        <div style={{marginTop: '3%', paddingBottom: '3%'}}>
            <div>{unsavedDataModalBool && <UnsavedDataModalContainer />}</div>
            <div className="people-tab-flex-container">
                <span className="people-tab-flex-item">
                    {getTimeFrameNameNMonthsAway(selectedTimeFrameId, validDates, -1) && (
                        <Button
                            icon="navigate_before"
                            label={
                                getTimeFrameNameNMonthsAway(
                                    selectedTimeFrameId,
                                    validDates,
                                    -1
                                ).split(' ')[0]
                            }
                            onClick={() =>
                                changeSelectedMonthData(
                                    setSelectedTimeFrameId,
                                    getTimeFrameIdNMonthsAway(selectedTimeFrameId, timeFrames, -1),
                                    teamPeople,
                                    forecastedPeople,
                                    establishInitialSortOrderPeople,
                                    sortOrderPreferencePeopleLocal,
                                    clearNewPersonData,
                                    clearNewForecastedPersonData,
                                    teamInitiatives,
                                    sortOrderPreference,
                                    setSelectedTimeFrameTeamCost,
                                    teamCostData,
                                    clearNewInitiativeData,
                                    establishInitialSortOrder
                                )
                            }
                        />
                    )}
                    <Select
                        className="select-month-people"
                        onChange={(evt) => {
                            if (hasUnsavedPeople) {
                                setUnsavedDataModalBool(true)
                            } else {
                                changeSelectedMonthData(
                                    setSelectedTimeFrameId,
                                    evt.value,
                                    teamPeople,
                                    forecastedPeople,
                                    establishInitialSortOrderPeople,
                                    sortOrderPreferencePeopleLocal,
                                    clearNewPersonData,
                                    clearNewForecastedPersonData,
                                    teamInitiatives,
                                    sortOrderPreference,
                                    setSelectedTimeFrameTeamCost,
                                    teamCostData,
                                    clearNewInitiativeData,
                                    establishInitialSortOrder
                                )
                            }
                        }}
                        options={formattedDates}
                        placeholder={selectedTimeFrameName}
                        value={selectedTimeFrameName}
                    />
                    {getTimeFrameNameNMonthsAway(selectedTimeFrameId, timeFrames, 1) && (
                        <Button
                            label={
                                getTimeFrameNameNMonthsAway(
                                    selectedTimeFrameId,
                                    timeFrames,
                                    1
                                ).split(' ')[0]
                            }
                            onClick={() =>
                                changeSelectedMonthData(
                                    setSelectedTimeFrameId,
                                    getTimeFrameIdNMonthsAway(selectedTimeFrameId, timeFrames, 1),
                                    teamPeople,
                                    forecastedPeople,
                                    establishInitialSortOrderPeople,
                                    sortOrderPreferencePeopleLocal,
                                    clearNewPersonData,
                                    clearNewForecastedPersonData,
                                    teamInitiatives,
                                    sortOrderPreference,
                                    setSelectedTimeFrameTeamCost,
                                    teamCostData,
                                    clearNewInitiativeData,
                                    establishInitialSortOrder
                                )
                            }
                            trailingIcon="navigate_next"
                        />
                    )}
                </span>
                <span className="people-tab-flex-item">
                    <span className="button-padding">
                        <Button disabled={!hasUnsavedPeople} onClick={clearAllPeopleData}>
                            Cancel
                        </Button>
                    </span>
                    <span className="button-padding">
                        <Button
                            disabled={!hasUnsavedPeople}
                            onClick={() => {
                                const saveAction = () => {
                                    updatePeople({selectedTimeFrameId})
                                    setSaveLockedTimeFrameData({
                                        showWarning: false
                                    })
                                }
                                if (isLockedTimeframe && allowEditing) {
                                    setSaveLockedTimeFrameData({
                                        showWarning: true,
                                        saveAction
                                    })
                                } else {
                                    saveAction()
                                }
                            }}
                            raised
                        >
                            Save
                        </Button>
                    </span>
                    <ReactTooltip />
                    <span
                        data-tip="Please save before copying forward."
                        data-tip-disable={!hasUnsavedPeople}
                    >
                        <Button
                            disabled={isCopyForwardDisabled()}
                            onClick={() => setCopyCalendarModalBool(!copyCalendarModalBool)}
                            outlined
                        >
                            Copy Forward To
                        </Button>
                        {copyCalendarModalBool && (
                            <MonthDropdownContainer
                                copyForwardFunction={updatePeople}
                                overwrittenMonths={overwrittenMonths}
                            />
                        )}
                    </span>
                </span>
            </div>
            <DataTable style={{width: '100%'}}>
                <div className="people-tab-table-container">
                    <div className="people-tab-table-item">
                        <PeopleTableContainer />
                    </div>
                    <div className="people-tab-table-item">
                        <ForecastedPeopleTableContainer />
                    </div>
                </div>
                <DataTableContent>
                    <DataTableBody>
                        <DataTableRow>
                            <DataTableCell style={{width: '80%'}}>Total</DataTableCell>
                            <DataTableCell>
                                {`Monthly Team Cost: $${selectedTimeFrameTeamCost ? selectedTimeFrameTeamCost.toLocaleString() : 0}`}
                            </DataTableCell>
                            <DataTableCell>
                                {`${getTotalParticipation()} Participation`}
                            </DataTableCell>
                        </DataTableRow>
                        <DataTableRow>
                            <DataTableCell colSpan={3} style={{textAlign: 'center', color: 'Grey'}}>
                                {get(selectedTimeFrame, 'lockdown', true)
                                    ? renderLockedTimeFrameMessage()
                                    : ''}
                            </DataTableCell>
                        </DataTableRow>
                    </DataTableBody>
                </DataTableContent>
            </DataTable>
        </div>
    )
}

export default PeopleTab
