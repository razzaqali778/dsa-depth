import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {
    fetchAllPeople
} from '../../../../src/client/redux/sagas/people/fetchAllPeopleSaga'

const costingServicesUrl = urls.costingServices

describe('listener', () => {
    it('listens only on FETCH_PEOPLE', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['people/FETCH_PEOPLE']

        expect(step()).toEqual(takeLatest(constants, fetchAllPeople))
    })
})

describe('saga flow', () => {
    it('happy path', () => {
        const gen = fetchAllPeople()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/people`
        const mockAllPeople = [
            {personId: '1', personName: 'some', isActive: true},
            {personId: '3', personName: 'another', isActive: false},
            {personId: '2', personName: 'stuff', isActive: true}
        ]

        const mockAllActivePeople = [
            {personId: '1', personName: 'some', isActive: true},
            {personId: '2', personName: 'stuff', isActive: true}
        ]

        const setPeopleAction = {
            type: 'people/SET_PEOPLE',
            payload: mockAllPeople
        }
        const setActivePeopleAction = {
            type: 'people/SET_ACTIVE_PEOPLE',
            payload: mockAllActivePeople
        }
        const mockGetResult = {
            payload: mockAllPeople,
            error: false
        }

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setPeopleAction))
        expect(step()).toEqual(dispatch(setActivePeopleAction))
        expect(gen.next().done).toBe(true)
    })
    it('bad path', () => {
        const gen = fetchAllPeople()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/people`

        const mockGetResult = {
            payload: 'It broke',
            error: true
        }

        const setPeopleAction = {
            type: 'people/SET_PEOPLE',
            payload: []
        }
        const setActivePeopleAction = {
            type: 'people/SET_ACTIVE_PEOPLE',
            payload: []
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch people')

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setPeopleAction))
        expect(step(toastrError)).toEqual(dispatch(setActivePeopleAction))
        expect(gen.next().done).toBe(true)
    })
})
