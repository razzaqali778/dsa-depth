import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {FETCH_TEAM_DATA} from '../../../../src/client/redux/constants/teamConstants'
import {SET_IS_LOADING} from '../../../../src/client/redux/constants/index'
import {UPDATE_PEOPLE} from '../../../../src/client/redux/constants/peopleConstants'
import {getSelectedTeam, getTimeFrames} from '../../../../src/client/redux/selectors/index'
import {
    getSelectedTimeFrameForecastedPeople,
    getSelectedTimeFrameTeamPeople
} from '../../../../src/client/redux/selectors/people'
import {patch} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {updatePeople} from '../../../../src/client/redux/sagas/people/updatePeopleSaga'

const coreServicesUrl = urls.coreServices
const headers = {Accept: '*/*'}

const selectedTeam = {
    id: 'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW'
}
const isLoadingTrue = {
    type: SET_IS_LOADING,
    payload: true
}

const isLoadingFalse = {
    type: SET_IS_LOADING,
    payload: false
}

describe('listener for updatePeopleSaga', () => {
    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value

        const constants = [UPDATE_PEOPLE]
        expect(step()).toEqual(takeLatest(constants, updatePeople))
    })
})

describe('Happy path', () => {
    const toasterSuccess = toastr.success('Successfully saved people')
    const fetchTeamData = {
        type: FETCH_TEAM_DATA
    }

    it('saves specific people for  the selected time frame', () => {
        const payload = {
            selectedTimeFrameId: 41904
        }

        const mockSelectedTimeFrameTeamPeople = [
            {
                costGroupName: 'costGroupA',
                isActive: true,
                isEmployee: true,
                modifiedBy: 'Pepper',
                personId: '1',
                personName: 'Pepper1',
                rateName: 'PepperRate',
                participationPct: 80,
                timeFrameId: 41904
            },
            {
                costGroupName: 'costGroupA',
                isActive: true,
                isEmployee: true,
                modifiedBy: 'Pepper',
                personId: '2',
                personName: 'Pepper2',
                rateName: 'PepperRate',
                participationPct: 20,
                timeFrameId: 41904
            }
        ]

        const gen = updatePeople({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const patchBody = {
            specificPeople: [
                {userId: '1', percent: 80},
                {userId: '2', percent: 20}
            ],
            genericPeople: [],
            timeFrameIds: [41904]
        }

        const mockFetchCall = {
            url: `${coreServicesUrl}/v2/efforts/members/team/MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW`,
            body: patchBody,
            headers
        }
        const mockResponse = {
            payload: patchBody,
            error: ''
        }
        expect(step()).toEqual(dispatch(isLoadingTrue))
        expect(step(true)).toEqual(select(getSelectedTimeFrameTeamPeople))
        expect(step(mockSelectedTimeFrameTeamPeople)).toEqual(
            select(getSelectedTimeFrameForecastedPeople)
        )
        expect(step([])).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(patch, mockFetchCall))
        expect(step(mockResponse)).toEqual(dispatch(fetchTeamData))
        expect(step(toasterSuccess)).toEqual(dispatch(isLoadingFalse))
        expect(gen.next().done).toBe(true)
    })

    it('saves specific and generic people for the selected time frame', () => {
        const selectedTimeFrameTeamPeople = [
            {
                costGroupName: 'costGroupA',
                isActive: true,
                isEmployee: true,
                modifiedBy: 'Pepper',
                personId: '1',
                personName: 'Pepper1',
                rateName: 'PepperRate',
                participationPct: 80,
                timeFrameId: 41904
            },
            {
                costGroupName: 'costGroupA',
                isActive: true,
                isEmployee: true,
                modifiedBy: 'Pepper',
                personId: '2',
                personName: 'Pepper2',
                rateName: 'PepperRate',
                participationPct: 20,
                timeFrameId: 41904
            }
        ]
        const timeFrameForecastedPeople = [
            {
                costGroupId: 'ITCS-PROD-PLTFM-DESIGN-DCT',
                numberOfPeople: '1.5',
                rateId: 'STANDARD'
            },
            {
                costGroupId: 'ITCS-PROD-PLTFM-FIELD-DCT',
                numberOfPeople: '4',
                rateId: 'STANDARD'
            }
        ]

        const payload = {
            copyForwardToTimeFrame: [{id: 41904}, {id: 41905}, {id: 41906}]
        }

        const patchBody = {
            specificPeople: [
                {
                    userId: '1',
                    percent: 80
                },
                {
                    userId: '2',
                    percent: 20
                }
            ],
            genericPeople: [
                {
                    costGroupId: 'ITCS-PROD-PLTFM-DESIGN-DCT',
                    numberOfPeople: 1.5,
                    rateId: 'STANDARD'
                },
                {
                    costGroupId: 'ITCS-PROD-PLTFM-FIELD-DCT',
                    numberOfPeople: 4,
                    rateId: 'STANDARD'
                }
            ],
            timeFrameIds: [41904, 41905, 41906]
        }

        const mockFetchCall = {
            url: `${coreServicesUrl}/v2/efforts/members/team/MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW`,
            body: patchBody,
            headers
        }

        const mockResponse = {
            payload: patchBody,
            error: ''
        }

        const gen = updatePeople({payload})
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(dispatch(isLoadingTrue))
        expect(step()).toEqual(select(getSelectedTimeFrameTeamPeople))
        expect(step(selectedTimeFrameTeamPeople)).toEqual(
            select(getSelectedTimeFrameForecastedPeople)
        )
        expect(step(timeFrameForecastedPeople)).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(patch, mockFetchCall))
        expect(step(mockResponse)).toEqual(dispatch(fetchTeamData))
        expect(step(toasterSuccess)).toEqual(dispatch(isLoadingFalse))
        expect(gen.next().done).toBe(true)
    })
    it('saves specific and generic people for the copy forward time frames', () => {
        const emptyTeamPeople = []
        const timeFrameForecastedPeople = [
            {
                costGroupId: 'ITCS-PROD-PLTFM-DESIGN-DCT',
                numberOfPeople: '1.5',
                rateId: 'STANDARD'
            },
            {
                costGroupId: 'ITCS-PROD-PLTFM-FIELD-DCT',
                numberOfPeople: '4',
                rateId: 'STANDARD'
            }
        ]

        const payload = {
            selectedTimeFrameId: 41904
        }

        const patchBody = {
            specificPeople: [],
            genericPeople: [
                {
                    costGroupId: 'ITCS-PROD-PLTFM-DESIGN-DCT',
                    numberOfPeople: 1.5,
                    rateId: 'STANDARD'
                },
                {
                    costGroupId: 'ITCS-PROD-PLTFM-FIELD-DCT',
                    numberOfPeople: 4,
                    rateId: 'STANDARD'
                }
            ],
            timeFrameIds: [41904]
        }

        const mockFetchCall = {
            url: `${coreServicesUrl}/v2/efforts/members/team/MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW`,
            body: patchBody,
            headers
        }

        const mockResponse = {
            payload: patchBody,
            error: ''
        }

        const gen = updatePeople({payload})
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(dispatch(isLoadingTrue))
        expect(step()).toEqual(select(getSelectedTimeFrameTeamPeople))
        expect(step(emptyTeamPeople)).toEqual(select(getSelectedTimeFrameForecastedPeople))
        expect(step(timeFrameForecastedPeople)).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(patch, mockFetchCall))
        expect(step(mockResponse)).toEqual(dispatch(fetchTeamData))
        expect(step(toasterSuccess)).toEqual(dispatch(isLoadingFalse))
        expect(gen.next().done).toBe(true)
    })
})

describe('Sadpath', () => {
    it('sad path: sends malformed data, returns toastr error', () => {
        const payload = {
            selectedTimeFrameId: 41904
        }

        const mockSelectedTimeFrameTeamPeople = [
            {
                costGroupName: 'costGroupA',
                isActive: true,
                isEmployee: true,
                modifiedBy: 'Pepper',
                personId: '1',
                personName: 'Pepper1',
                rateName: 'PepperRate',
                participationPct: 180,
                timeFrameId: 41904
            },
            {
                costGroupName: 'costGroupA',
                isActive: true,
                isEmployee: true,
                modifiedBy: 'Pepper',
                personId: '2',
                personName: 'Pepper2',
                rateName: 'PepperRate',
                participationPct: 120,
                timeFrameId: 41904
            }
        ]

        const gen = updatePeople({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const peopleData = {
            specificPeople: [
                {userId: '1', percent: 180},
                {userId: '2', percent: 120}
            ],
            genericPeople: [],
            timeFrameIds: [41904]
        }

        const mockFetchCall = {
            url: `${coreServicesUrl}/v2/efforts/members/team/MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW`,
            body: peopleData,
            headers
        }
        const mockResponse = {
            payload: 'Failed to save people for ',
            error: true
        }

        expect(step()).toEqual(dispatch(isLoadingTrue))
        expect(step(true)).toEqual(select(getSelectedTimeFrameTeamPeople))
        expect(step(mockSelectedTimeFrameTeamPeople)).toEqual(
            select(getSelectedTimeFrameForecastedPeople)
        )
        expect(step([])).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(patch, mockFetchCall))
        expect(step(mockResponse)).toEqual(select(getTimeFrames))
    })
})
