import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {FETCH_TEAM_DATA} from '../../../../src/client/redux/constants/teamConstants'
import {SET_IS_LOADING} from '../../../../src/client/redux/constants/index'
import {UPDATE_INITIATIVES} from '../../../../src/client/redux/constants/initiativeConstants'
import {getSelectedTeam, getTimeFrames} from '../../../../src/client/redux/selectors/index'
import {patch} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {
    updateInitiatives
} from '../../../../src/client/redux/sagas/initiatives/updateInitiativesSaga'

describe('listener for updateInitiativesSaga', () => {
    const selectedTeam = {
        id: 'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW'
    }

    const isLoadingFalse = {
        type: SET_IS_LOADING,
        payload: false
    }

    const isLoadingTrue = {
        type: SET_IS_LOADING,
        payload: true
    }

    const success = toastr.success('Successfuly saved initiatives')

    // headers response is in plain text not json
    const headers = {Accept: '*/*'}

    const coreServicesUrl = urls.coreServices

    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value

        const constants = [UPDATE_INITIATIVES]

        expect(step()).toEqual(takeLatest(constants, updateInitiatives))
    })

    describe('Happy path(s)', () => {
        it('happy path: successfully saves an initiative', () => {
            const payload = {
                selectedTimeFrameId: 41904,
                selectedTimeFrameInitiatives: [
                    {
                        initiativeName: 'The Name of This Initiative',
                        teamCostPct: 100,
                        timeFrameId: 41904,
                        id: 'identifier for initiative'
                    }
                ]
            }

            const gen = updateInitiatives({payload})
            const step = (lastYield) => gen.next(lastYield).value

            const initiativeData = [
                {
                    timeFrameId: 41904,
                    allocations: [
                        {
                            initiativeId: 'identifier for initiative',
                            percentageOfTeamCost: 100
                        }
                    ]
                }
            ]

            const fetchTeamData = {
                type: FETCH_TEAM_DATA
            }

            const mockFetchCall = {
                url: `${coreServicesUrl}/v2/efforts/allocations/team/MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW`,
                body: initiativeData,
                headers
            }

            const mockResponse = {
                payload: 'OK',
                error: ''
            }

            expect(step()).toEqual(dispatch(isLoadingTrue))
            expect(step(true)).toEqual(select(getSelectedTeam))
            expect(step(selectedTeam)).toEqual(call(patch, mockFetchCall))
            expect(step(mockResponse)).toEqual(dispatch(fetchTeamData))
            expect(step(success)).toEqual(dispatch(isLoadingFalse))
            expect(gen.next().done).toBe(true)
        })

        it('happy path: successfully saves multiple initiatives', () => {
            const payload = {
                selectedTimeFrameId: 41904,
                selectedTimeFrameInitiatives: [
                    {
                        name: 'The Name of This Initiative',
                        teamCostPct: 60,
                        timeFrameId: 41904,
                        id: 'identifier for initiative'
                    },
                    {
                        name: 'The Name of This Initiative',
                        teamCostPct: 40,
                        timeFrameId: 41904,
                        id: '15c968e0-e1ed-11e8-b98f-7ff0a3d28ce8'
                    }
                ]
            }

            const gen = updateInitiatives({payload})
            const step = (lastYield) => gen.next(lastYield).value

            const initiativeData = [
                {
                    timeFrameId: 41904,
                    allocations: [
                        {
                            initiativeId: 'identifier for initiative',
                            percentageOfTeamCost: 60
                        },
                        {
                            initiativeId: '15c968e0-e1ed-11e8-b98f-7ff0a3d28ce8',
                            percentageOfTeamCost: 40
                        }
                    ]
                }
            ]

            const fetchTeamData = {
                type: FETCH_TEAM_DATA
            }

            const mockFetchCall = {
                url: `${coreServicesUrl}/v2/efforts/allocations/team/MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW`,
                body: initiativeData,
                headers
            }

            const mockResponse = {
                payload: 'OK',
                error: ''
            }

            expect(step()).toEqual(dispatch(isLoadingTrue))
            expect(step(true)).toEqual(select(getSelectedTeam))
            expect(step(selectedTeam)).toEqual(call(patch, mockFetchCall))
            expect(step(mockResponse)).toEqual(dispatch(fetchTeamData))
            expect(step(success)).toEqual(dispatch(isLoadingFalse))
            expect(gen.next().done).toBe(true)
        })
    })

    describe('Sad path(s)', () => {
        it('sad path: sends malformed data, returns toastr error', () => {
            const payload = {
                selectedTimeFrameId: 41904,
                selectedTimeFrameInitiatives: [
                    {
                        name: 'The Name of This Initiative',
                        teamCostPct: 70,
                        timeFrameId: 41904,
                        id: 'identifier for initiative'
                    },
                    {
                        name: 'The Name of This Initiative',
                        teamCostPct: 40,
                        timeFrameId: 41904,
                        id: '15c968e0-e1ed-11e8-b98f-7ff0a3d28ce8'
                    }
                ]
            }

            const gen = updateInitiatives({payload})
            const step = (lastYield) => gen.next(lastYield).value

            const initiativeData = [
                {
                    timeFrameId: 41904,
                    allocations: [
                        {
                            initiativeId: 'identifier for initiative',
                            percentageOfTeamCost: 70
                        },
                        {
                            initiativeId: '15c968e0-e1ed-11e8-b98f-7ff0a3d28ce8',
                            percentageOfTeamCost: 40
                        }
                    ]
                }
            ]

            const mockFetchCall = {
                url: `${coreServicesUrl}/v2/efforts/allocations/team/MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW`,
                body: initiativeData,
                headers
            }

            const mockResponse = {
                payload: 'Allocations percentages must not be greater than 100',
                error: true
            }

            // const toastError = toastr.error(mockResponse.payload, 'Successfuly saved initiatives')

            expect(step()).toEqual(dispatch(isLoadingTrue))
            expect(step(true)).toEqual(select(getSelectedTeam))
            expect(step(selectedTeam)).toEqual(call(patch, mockFetchCall))
            expect(step(mockResponse)).toEqual(select(getTimeFrames))
        })
    })
})
