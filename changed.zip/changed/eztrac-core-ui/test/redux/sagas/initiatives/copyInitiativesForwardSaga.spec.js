import {put as dispatch, select, takeEvery} from 'redux-saga/effects'
import {
    CLEAR_COPY_FORWARD_TIME_FRAME,
    COPY_INITIATIVES_FORWARD,
    UPDATE_INITIATIVES
} from '../../../../src/client/redux/constants/initiativeConstants'
import {getSelectedTimeFrameTeamInitiatives} from '../../../../src/client/redux/selectors/initiatives'
import listener, {
    copyInitiativesForward
} from '../../../../src/client/redux/sagas/initiatives/copyInitiativesForwardSaga'

describe('listens for copyInitiativesForwardSaga', () => {
    const timeFrame = {id: 41904}
    const selectedTimeFrameInitiatives = {
        businessUnit: 'Commercial',
        financeCodeType: null,
        financeCodeValue: null,
        id: '6cff2800-2029-11e9-925b-0f018cbe9e01',
        initiativeCost: 121000,
        initiativeName: 'Commercialization',
        isAllocable: true,
        isInheritable: true,
        parentId: '93e30520-0fa5-11e9-a195-97d08e842828',
        parentName: 'RPO Phase 3',
        parent_status: null,
        portfolioCode: null,
        region: 'Global',
        status: 'Funded',
        teamCostPct: 55,
        timeFrameId: 41904,
        typeId: 'CAP-INIT'
    }
    const payload = {
        copyForwardToTimeFrame: [timeFrame]
    }

    const updatePayload = {
        payload: {
            copyForwardToTimeFrame: [timeFrame],
            selectedTimeFrameInitiatives
        },
        type: UPDATE_INITIATIVES
    }

    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value

        const constants = [COPY_INITIATIVES_FORWARD]
        expect(step()).toEqual(takeEvery(constants, copyInitiativesForward))
    })
    describe('Happy path(s)', () => {
        it('happy path: successfully copy forwards an initiative', () => {
            const gen = copyInitiativesForward({payload})
            const step = (lastYield) => gen.next(lastYield).value
            const clearCopyForwardTimeFrame = {
                type: CLEAR_COPY_FORWARD_TIME_FRAME
            }

            expect(step()).toEqual(select(getSelectedTimeFrameTeamInitiatives))
            expect(step(selectedTimeFrameInitiatives)).toEqual(dispatch(updatePayload))
            expect(step()).toEqual(dispatch(clearCopyForwardTimeFrame))
        })
    })
})
