import {
    hasForecastedPeopleDataChanged,
    hasPeopleDataChanged
} from '../../../src/client/redux/utils/validatorsForPeople'

describe('validatorsForPeople', () => {
    it('returns false when selected people match the original month people', () => {
        const originalPeople = [
            {personId: 'USER-2', participationPct: '50', timeFrameId: 41904},
            {personId: 'USER-1', participationPct: 100, timeFrameId: 41904},
            {personId: 'OTHER-MONTH', participationPct: 25, timeFrameId: 41905}
        ]
        const selectedPeople = [
            {personId: 'USER-1', participationPct: '100'},
            {personId: 'USER-2', participationPct: 50}
        ]

        expect(hasPeopleDataChanged(originalPeople, selectedPeople, 41904)).toBe(false)
    })

    it('returns true when selected people differ from the original month people', () => {
        const originalPeople = [{personId: 'USER-1', participationPct: 100, timeFrameId: 41904}]
        const selectedPeople = [{personId: 'USER-1', participationPct: 80}]

        expect(hasPeopleDataChanged(originalPeople, selectedPeople, 41904)).toBe(true)
    })

    it('returns false when forecasted people match the original month people', () => {
        const originalPeople = [
            {costGroupId: 'CG-1', numberOfPeople: '1.5', rateId: 'STD', timeFrameId: 41904}
        ]
        const selectedPeople = [{costGroupId: 'CG-1', numberOfPeople: 1.5, rateId: 'STD'}]

        expect(hasForecastedPeopleDataChanged(originalPeople, selectedPeople, 41904)).toBe(false)
    })

    it('returns true when forecasted people differ from the original month people', () => {
        const originalPeople = [
            {costGroupId: 'CG-1', numberOfPeople: '1.5', rateId: 'STD', timeFrameId: 41904}
        ]
        const selectedPeople = [{costGroupId: 'CG-1', numberOfPeople: 2, rateId: 'STD'}]

        expect(hasForecastedPeopleDataChanged(originalPeople, selectedPeople, 41904)).toBe(true)
    })
})
