const {
    applyFilters,
    buildDenormalizedRows,
    groupRows
} = require('../../src/api/getReportRowsForRange')

describe('getReportRowsForRange', () => {
    it('builds table rows using the reporting field names', () => {
        const rows = buildDenormalizedRows({
            spending: [
                {
                    timeFrameId: 1,
                    teamId: 'TEAM-1',
                    initiatives: [
                        {
                            initiativeId: 'INIT-1',
                            lineItems: [
                                {
                                    costGroupId: 'COST-GROUP-1',
                                    engagementId: 'ENGAGEMENT-1',
                                    personId: 'PERSON-1',
                                    spend: 100
                                }
                            ]
                        }
                    ]
                }
            ],
            teams: [
                {
                    teamId: 'TEAM-1',
                    teamName: 'Team 1',
                    communityId: 'COMMUNITY-1',
                    communityName: 'Community 1',
                    platformId: 'PLATFORM-1',
                    platformName: 'Platform 1',
                    orgId: 'ORG-1',
                    orgName: 'Org 1'
                }
            ],
            costGroups: [
                {
                    id: 'COST-GROUP-1',
                    name: 'Cost Group 1',
                    costCenter: 'CC-1',
                    isActive: true,
                    excludeFromDistributions: false
                }
            ],
            engagements: [
                {
                    id: 'ENGAGEMENT-1',
                    name: 'Engagement 1',
                    purchaseOrder: 'PO-1',
                    isActive: true
                }
            ],
            effortEngagements: [
                {
                    teamId: 'TEAM-1',
                    engagementId: 'ENGAGEMENT-1',
                    comment: 'Effort comment'
                }
            ],
            people: [
                {
                    id: 'PERSON-1',
                    name: 'Person 1'
                }
            ],
            initiatives: [
                {
                    id: 'INIT-1',
                    initiativeName: 'Initiative 1',
                    typeValue: 'Capital',
                    status: 'Funded',
                    financeCodeValue: 'FIN-1',
                    fundingInitiativeName: 'Funding Initiative 1',
                    portfolioCode: 'PORT-1',
                    activityId: 'ACT-1',
                    programCode: 'PGM-1',
                    budgets: [{fiscalYear: 2026, amount: 500}],
                    tags: [
                        {tagId: 'BUS-UNIT', tagValue: 'Business Unit 1'},
                        {tagId: 'REGION', tagValue: 'Region 1'}
                    ],
                    children: []
                }
            ],
            timeframes: [{id: 1, name: 'January 2026', fiscalYear: 2026}]
        })

        rows.should.deep.equal([
            {
                budget: 500,
                businessUnit: 'Business Unit 1',
                communityId: 'COMMUNITY-1',
                communityName: 'Community 1',
                costGroupId: 'COST-GROUP-1',
                costGroupName: 'Cost Group 1',
                effortComment: 'Effort comment',
                engagementId: 'ENGAGEMENT-1',
                engagementName: 'Engagement 1',
                personId: 'PERSON-1',
                personName: 'Person 1',
                engagementStatus: 'Active',
                purchaseOrderName: 'PO-1',
                costCenter: 'CC-1',
                financeCodeValue: 'FIN-1',
                portfolioCode: 'PORT-1',
                activityId: 'ACT-1',
                fundingInitiativeName: 'Funding Initiative 1',
                topLevelInitiativeName: 'Initiative 1',
                initiativeId: 'INIT-1',
                initiativeName: 'Initiative 1',
                initiativeAncestorIds: ['INIT-1'],
                platformId: 'PLATFORM-1',
                platformName: 'Platform 1',
                orgId: 'ORG-1',
                orgName: 'Org 1',
                region: 'Region 1',
                chargingTeamId: 'TEAM-1',
                chargingTeamName: 'Team 1',
                spend: 100,
                status: 'Funded',
                teamId: 'TEAM-1',
                teamName: 'Team 1',
                timeFrameStartDate: 'January 2026',
                typeName: 'Capital',
                capExp: 'CAP',
                isActive: true,
                excludeFromDistributions: false,
                programCode: 'PGM-1'
            }
        ])
    })

    it('filters and groups rows before paging', () => {
        const rows = [
            {initiativeName: 'Alpha', status: 'Funded', spend: 100},
            {initiativeName: 'Alpha', status: 'Funded', spend: 50},
            {initiativeName: 'Beta', status: 'Cancelled', spend: 25}
        ]
        const filteredRows = applyFilters(rows, [{value: 'status@Funded'}])
        const groupedRows = groupRows(filteredRows, [{name: 'initiativeName'}])

        groupedRows.should.deep.equal([{initiativeName: 'Alpha', spend: 150}])
    })
})
