const {getAllTimeframes} = require('./getTimeframes')
const getAllTeams = require('./getAllTeams')
const getAllSpendings = require('./getAllSpendings')
const getAllSpendFacts = require('./getAllSpendFacts')
const getAllEffortEngagements = require('./getAllEffortEngagements')

module.exports = {
    getAllTimeframes,
    getAllTeams,
    getAllSpendings,
    getAllSpendFacts,
    getAllEffortEngagements
}
