const agent = require('superagent')
const getToken = require('../../../util/getToken')
const config = require('../../../config')

module.exports = async (startTimeFrame, endTimeFrame) => {
    const token = await getToken()

    const result = await agent
        .get(
            `${config.get(
                'ez-trac-core-url'
            )}/spend/startTimeFrame/${startTimeFrame}/endTimeFrame/${endTimeFrame}?view=facts`
        )
        .set('Authorization', `Bearer ${token}`)

    return result.body
}
