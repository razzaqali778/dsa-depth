const {getAllInitiatives} = require('./external/vipServices')
const {
    getAllTeams,
    getAllSpendFacts,
    getAllEffortEngagements,
    getAllTimeframes
} = require('./external/coreServices')
const {getCostGroups, getAllEngagements} = require('./external/costingService')
const getAllPeople = require('./external/costingService/getAllPeople')

const DEFAULT_PAGE = 1
const DEFAULT_PAGE_SIZE = 10
const MAX_PAGE_SIZE = 200

const addGenericPersonItem = (peopleArray) => [
    ...peopleArray,
    {id: 'GENERIC-PERSON', name: 'Placeholder'}
]

const isPresent = (value) => value !== undefined && value !== null && value !== ''

const parseTimeframeParam = (value) => Number(value)

const parseJsonParam = (value, defaultValue) => {
    if (!isPresent(value)) {
        return defaultValue
    }

    try {
        return JSON.parse(value)
    } catch (err) {
        const error = new Error('Invalid report row query JSON')
        error.status = 400
        throw error
    }
}

const parsePaginationParams = ({page, pageSize} = {}) => {
    const parsedPage = isPresent(page) ? Number(page) : DEFAULT_PAGE
    const parsedPageSize = isPresent(pageSize) ? Number(pageSize) : DEFAULT_PAGE_SIZE

    if (!Number.isInteger(parsedPage) || parsedPage < 1) {
        const error = new Error('page must be an integer greater than or equal to 1')
        error.status = 400
        throw error
    }

    if (!Number.isInteger(parsedPageSize) || parsedPageSize < 1 || parsedPageSize > MAX_PAGE_SIZE) {
        const error = new Error(`pageSize must be an integer between 1 and ${MAX_PAGE_SIZE}`)
        error.status = 400
        throw error
    }

    return {page: parsedPage, pageSize: parsedPageSize}
}

const buildPaginationMeta = (page, pageSize, totalCount) => ({
    page,
    pageSize,
    totalCount,
    totalPages: totalCount === 0 ? 0 : Math.ceil(totalCount / pageSize)
})

const convertToMap = (key, items) =>
    items.reduce((map, item) => {
        map[item[key]] = item
        return map
    }, {})

const getEngagementStatus = (isActive) => (isActive ? 'Active' : 'Inactive')

const getValueOrUnassigned = (value) => (isPresent(value) ? value : 'Unassigned')

const getCapExp = (typeName) => {
    if (typeName === 'Unknown') return 'Unknown'
    return typeName && typeName.includes('Cap') ? 'CAP' : 'EXP'
}

const buildEffortEngagementCommentMap = (effortEngagements) =>
    effortEngagements.reduce((map, effortEngagement) => {
        map[`${effortEngagement.teamId}|${effortEngagement.engagementId}`] =
            effortEngagement.comment
        return map
    }, {})

const buildInitiativeMap = (initiatives) => {
    const initiativeMap = {}

    const visit = (initiative, topLevelInitiative, ancestorIds) => {
        const topLevel = topLevelInitiative || initiative.initiativeName
        const nextAncestorIds = [...ancestorIds, initiative.id]
        const tags = initiative.tags || []

        initiativeMap[initiative.id] = {
            id: initiative.id,
            initiativeName: initiative.initiativeName,
            typeName: initiative.typeValue,
            status: initiative.status,
            financeCodeValue: initiative.financeCodeValue,
            fundingInitiativeName: initiative.fundingInitiativeName,
            topLevelInitiativeName: topLevel,
            portfolioCode: initiative.portfolioCode,
            programCode: initiative.programCode,
            activityId: initiative.activityId,
            budgets: initiative.budgets || [],
            tags,
            businessUnit:
                (tags.find((tag) => tag.tagId === 'BUS-UNIT') || {}).tagValue || 'Unassigned',
            region: (tags.find((tag) => tag.tagId === 'REGION') || {}).tagValue || 'Unassigned',
            ancestorIds: nextAncestorIds
        }

        ;(initiative.children || []).forEach((child) => visit(child, topLevel, nextAncestorIds))
    }

    initiatives.forEach((initiative) => visit(initiative, null, []))

    return initiativeMap
}

const getBudget = (initiative, timeFrame) => {
    const budget = (initiative.budgets || []).find(
        (item) => item.fiscalYear === timeFrame.fiscalYear
    )
    return budget ? budget.amount : 0
}

const buildDenormalizedRowsFromFacts = ({
    spendFacts,
    teams,
    costGroups,
    engagements,
    effortEngagements,
    people,
    initiatives,
    timeframes
}) => {
    const teamMap = convertToMap('teamId', teams)
    const costGroupMap = convertToMap('id', costGroups)
    const engagementMap = convertToMap('id', engagements)
    const peopleMap = convertToMap('id', addGenericPersonItem(people))
    const timeFrameMap = convertToMap('id', timeframes)
    const initiativeMap = buildInitiativeMap(initiatives)
    const effortEngagementCommentMap = buildEffortEngagementCommentMap(effortEngagements)

    return spendFacts.map((fact) => {
        const team = teamMap[fact.teamId] || {teamId: fact.teamId}
        const timeFrame = timeFrameMap[fact.timeFrameId] || {id: fact.timeFrameId}
        const initiative = initiativeMap[fact.initiativeId] || {
            id: fact.initiativeId,
            initiativeName: fact.initiativeId,
            topLevelInitiativeName: fact.initiativeId,
            budgets: [],
            tags: [],
            ancestorIds: [fact.initiativeId]
        }
        const costGroup = costGroupMap[fact.costGroupId] || {
            id: fact.costGroupId,
            name: fact.costGroupId,
            notFound: true
        }
        const engagement = engagementMap[fact.engagementId] || {
            id: fact.engagementId,
            name: fact.engagementId,
            notFound: !fact.engagementId
        }
        const person = peopleMap[fact.personId] || {
            id: fact.personId,
            name: fact.personId,
            notFound: !fact.personId
        }
        const hasEngagement = engagement && engagement.id
        const effortComment = effortEngagementCommentMap[`${fact.teamId}|${fact.engagementId}`]

        return {
            budget: getBudget(initiative, timeFrame),
            businessUnit: initiative.businessUnit || 'Unassigned',
            communityId: team.communityId,
            communityName: team.communityName || 'Unassigned',
            costGroupId: costGroup.id,
            costGroupName: costGroup.name || null,
            effortComment: hasEngagement ? effortComment || 'Unassigned' : 'N/A',
            engagementId: engagement.id,
            engagementName: hasEngagement ? engagement.name : null,
            personId: person.id,
            personName: person && person.id ? person.name : null,
            engagementStatus: hasEngagement ? getEngagementStatus(engagement.isActive) : 'N/A',
            purchaseOrderName: hasEngagement ? engagement.purchaseOrder : null,
            costCenter: costGroup.costCenter,
            financeCodeValue: initiative.financeCodeValue || null,
            portfolioCode: initiative.portfolioCode || null,
            activityId: initiative.activityId || null,
            fundingInitiativeName: initiative.fundingInitiativeName,
            topLevelInitiativeName: initiative.topLevelInitiativeName,
            initiativeId: initiative.id,
            initiativeName: initiative.initiativeName,
            initiativeAncestorIds: initiative.ancestorIds || [initiative.id],
            platformId: team.platformId,
            platformName: team.platformName || 'Unassigned',
            orgId: team.orgId,
            orgName: team.orgName || 'Unassigned',
            region: initiative.region || 'Unassigned',
            chargingTeamId: team.teamId,
            chargingTeamName: team.teamName || 'Unassigned',
            spend: Number(fact.spend) || 0,
            status: initiative.status,
            teamId: team.teamId,
            teamName: team.teamName || 'Unassigned',
            timeFrameStartDate: timeFrame.name || timeFrame.id,
            typeName: initiative.typeName,
            capExp: getCapExp(initiative.typeName),
            isActive: costGroup.isActive,
            excludeFromDistributions: costGroup.excludeFromDistributions,
            programCode: initiative.programCode
        }
    })
}

const flattenSpendFacts = (spending) =>
    spending.flatMap((effortSpend) =>
        effortSpend.initiatives.flatMap((initiativeSpend) =>
            initiativeSpend.lineItems.map((lineItem) => ({
                timeFrameId: effortSpend.timeFrameId,
                teamId: effortSpend.teamId,
                initiativeId: initiativeSpend.initiativeId,
                costGroupId: lineItem.costGroupId,
                engagementId: lineItem.engagementId,
                personId: lineItem.personId,
                spend: lineItem.spend
            }))
        )
    )

const buildDenormalizedRows = ({spending, ...rest}) =>
    buildDenormalizedRowsFromFacts({
        ...rest,
        spendFacts: flattenSpendFacts(spending)
    })

const getFilterParts = (filter) => {
    const rawValue = filter.value || ''
    const separatorIndex = rawValue.indexOf('@')
    if (separatorIndex === -1) {
        return {key: rawValue, value: rawValue, id: filter.id}
    }

    return {
        key: rawValue.slice(0, separatorIndex),
        value: rawValue.slice(separatorIndex + 1),
        id: filter.id
    }
}

const matchesTextOrId = (row, filter, idKey, textKey) => {
    if (isPresent(filter.id)) {
        return row[idKey] === filter.id
    }

    return getValueOrUnassigned(row[textKey]) === filter.value
}

const matchesFilter = (row, filter) => {
    switch (filter.key) {
        case 'tag:BUS-UNIT':
            return row.businessUnit === filter.value
        case 'tag:REGION':
            return row.region === filter.value
        case 'chargingTeam':
            return matchesTextOrId(row, filter, 'chargingTeamId', 'chargingTeamName')
        case 'team':
            return matchesTextOrId(row, filter, 'teamId', 'teamName')
        case 'community':
            return matchesTextOrId(row, filter, 'communityId', 'communityName')
        case 'platform':
            return matchesTextOrId(row, filter, 'platformId', 'platformName')
        case 'org':
            return matchesTextOrId(row, filter, 'orgId', 'orgName')
        case 'initiativeName':
            return isPresent(filter.id)
                ? (row.initiativeAncestorIds || []).includes(filter.id)
                : row.initiativeName === filter.value
        case 'initiativeTypeName':
            return getValueOrUnassigned(row.typeName) === filter.value
        case 'financeCode':
            return getValueOrUnassigned(row.financeCodeValue) === filter.value
        case 'portfolioCode':
            return getValueOrUnassigned(row.portfolioCode) === filter.value
        case 'activityId':
            return getValueOrUnassigned(row.activityId) === filter.value
        case 'programCode':
            return getValueOrUnassigned(row.programCode) === filter.value
        case 'status':
            return getValueOrUnassigned(row.status) === filter.value
        case 'topLevelInitiativeName':
            return getValueOrUnassigned(row.topLevelInitiativeName) === filter.value
        case 'costGroup':
            return matchesTextOrId(row, filter, 'costGroupId', 'costGroupName')
        case 'sourceCostCenter':
            return getValueOrUnassigned(row.costCenter) === filter.value
        case 'engagement':
            return matchesTextOrId(row, filter, 'engagementId', 'engagementName')
        case 'engagementStatus':
            return row.engagementStatus === filter.value
        case 'purchaseOrder':
            return getValueOrUnassigned(row.purchaseOrderName) === filter.value
        case 'person':
            return matchesTextOrId(row, filter, 'personId', 'personName')
        default:
            return true
    }
}

const applyFilters = (rows, filters) => {
    const buckets = filters.reduce((map, filter) => {
        const filterParts = getFilterParts(filter)
        map[filterParts.key] = [...(map[filterParts.key] || []), filterParts]
        return map
    }, {})

    return rows.filter((row) =>
        Object.keys(buckets).every((key) => buckets[key].some((filter) => matchesFilter(row, filter)))
    )
}

const applyExcludedFilterOptions = (rows, excludedFilterOptions, costGroups = []) => {
    let filteredRows = rows

    if (excludedFilterOptions.filterExcludedCostGroups) {
        filteredRows = filteredRows.filter((row) => !row.excludeFromDistributions)
    }

    if (excludedFilterOptions.filterRedundantInitiativePayments) {
        const uniqueCostCenters = new Set(costGroups.map((costGroup) => costGroup.costCenter).filter(Boolean))
        filteredRows = filteredRows.filter((row) => !uniqueCostCenters.has(row.financeCodeValue))
    }

    return filteredRows
}

const getFieldNames = (fields) => fields.map((field) => field.name || field.value).filter(Boolean)

const groupRows = (rows, fields) => {
    const fieldNames = getFieldNames(fields)
    if (!fieldNames.length) {
        return []
    }

    const groupedRows = rows.reduce((map, row) => {
        const key = fieldNames.map((field) => row[field]).join('|')
        if (!map[key]) {
            const nextRow = fieldNames.reduce((acc, field) => {
                acc[field] = row[field]
                return acc
            }, {})
            map[key] = {...nextRow, spend: 0}
        }
        map[key].spend += row.spend
        return map
    }, {})

    return Object.values(groupedRows).filter((row) => row.spend > 0)
}

const compareValues = (a, b) => {
    if (a === b) return 0
    if (a === undefined || a === null) return 1
    if (b === undefined || b === null) return -1
    if (typeof a === 'number' && typeof b === 'number') return a - b
    return String(a).localeCompare(String(b))
}

const sortRows = (rows, fields, grouping, sorting) => {
    const fieldNames = getFieldNames(fields)
    const groupedFields = grouping.map((group) => group.columnName)
    const sortedFields = sorting.map((sort) => sort.columnName)
    const remainingFields = fieldNames.filter(
        (field) => !groupedFields.includes(field) && !sortedFields.includes(field)
    )
    const sortKeys = [
        ...groupedFields.map((field) => ({columnName: field, direction: 'asc'})),
        ...sorting,
        ...remainingFields.map((field) => ({columnName: field, direction: 'asc'})),
        {columnName: 'spend', direction: 'asc'}
    ]

    return [...rows].sort((a, b) => {
        for (const sort of sortKeys) {
            const result = compareValues(a[sort.columnName], b[sort.columnName])
            if (result !== 0) {
                return sort.direction === 'desc' ? -result : result
            }
        }
        return 0
    })
}

const paginateRows = (rows, page, pageSize) => {
    const start = (page - 1) * pageSize
    return rows.slice(start, start + pageSize)
}

const getReportRowsForRange = async (startTimeframe, endTimeframe, options = {}) => {
    const parsedStartTimeframe = parseTimeframeParam(startTimeframe)
    const parsedEndTimeframe = parseTimeframeParam(endTimeframe)
    const {page, pageSize} = parsePaginationParams(options)
    const fields = parseJsonParam(options.fields, [])
    const grouping = parseJsonParam(options.grouping, [])
    const sorting = parseJsonParam(options.sorting, [])
    const filters = parseJsonParam(options.filters, [])
    const excludedFilterOptions = parseJsonParam(options.excludedFilterOptions, {})

    const [initiatives, spendFacts, teams, costGroups, engagements, effortEngagements, people, timeframes] =
        await Promise.all([
            getAllInitiatives(),
            getAllSpendFacts(parsedStartTimeframe, parsedEndTimeframe),
            getAllTeams(),
            getCostGroups(),
            getAllEngagements(),
            getAllEffortEngagements(parsedStartTimeframe, parsedEndTimeframe),
            getAllPeople(),
            getAllTimeframes()
        ])

    const denormalizedRows = buildDenormalizedRowsFromFacts({
        spendFacts,
        teams,
        costGroups,
        engagements,
        effortEngagements,
        people,
        initiatives,
        timeframes
    })
    const filteredRows = applyExcludedFilterOptions(
        applyFilters(denormalizedRows, filters),
        excludedFilterOptions,
        costGroups
    )
    const groupedRows = groupRows(filteredRows, fields)
    const sortedRows = sortRows(groupedRows, fields, grouping, sorting)
    const totalSpend = sortedRows.reduce((sum, row) => sum + row.spend, 0)

    return {
        data: paginateRows(sortedRows, page, pageSize),
        pagination: buildPaginationMeta(page, pageSize, sortedRows.length),
        totalSpend
    }
}

module.exports = getReportRowsForRange
module.exports.buildDenormalizedRows = buildDenormalizedRows
module.exports.buildDenormalizedRowsFromFacts = buildDenormalizedRowsFromFacts
module.exports.applyFilters = applyFilters
module.exports.groupRows = groupRows
