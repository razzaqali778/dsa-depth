const {
    EffortSpendingDetail,
    SpendLineItemDetails,
    TeamIdOnly,
    CostGroupIdOnly,
    EngagementIdOnly,
    PersonIdOnly
} = require('./index')

const effortSpendingMap = (
    effortSpending,
    teamStructureMap,
    costGroupMap,
    engagementMap,
    effortEngagements,
    peopleMap
) => {
    const effortEngagementCommentMap = {}
    effortEngagements.forEach((effortEngagement) => {
        effortEngagementCommentMap[`${effortEngagement.teamId}|${effortEngagement.engagementId}`] =
            effortEngagement.comment
    })

    const createLineItemDetails = (lineItems, effortSpendTeamId) => {
        const result = lineItems.map((li) => {
            const effortComment =
                effortEngagementCommentMap[`${effortSpendTeamId}|${li.engagementId}`]
            return new SpendLineItemDetails(
                costGroupMap[li.costGroupId] || new CostGroupIdOnly(li.costGroupId),
                li.spend,
                engagementMap[li.engagementId] || new EngagementIdOnly(li.engagementId),
                effortComment || '',
                peopleMap[li.personId] || new PersonIdOnly(li.personId)
            )
        })
        return result
    }

    const initIdToSpendMap = {}

    effortSpending.forEach((effortSpend) => {
        effortSpend.initiatives.forEach((initiative) => {
            const {initiativeId} = initiative
            if (!initIdToSpendMap[initiativeId]) {
                initIdToSpendMap[initiativeId] = []
            }

            const effortSpendingDetail = new EffortSpendingDetail(
                effortSpend.timeFrameId,
                teamStructureMap[effortSpend.teamId] || new TeamIdOnly(effortSpend.teamId),
                initiative.spend,
                createLineItemDetails(initiative.lineItems, effortSpend.teamId)
            )

            initIdToSpendMap[initiativeId].push(effortSpendingDetail)
        })
    })

    return initIdToSpendMap
}

module.exports = effortSpendingMap
