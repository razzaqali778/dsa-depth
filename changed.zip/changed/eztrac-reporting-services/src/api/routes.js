const router = require('express').Router()
const getSpendingForRange = require('./getSpendingForRange')
const getReportRowsForRange = require('./getReportRowsForRange')
const entitlementMiddleware = require('./middleware/entitlementMiddleware')

router.get(
    '/spending/startTimeFrame/:startTimeframe/endTimeFrame/:endTimeframe',
    entitlementMiddleware,
    async (req, res) => {
        try {
            const {startTimeframe, endTimeframe} = req.params
            const {page, pageSize, initiativeId} = req.query

            if (req.query.view === 'rows') {
                const rows = await getReportRowsForRange(startTimeframe, endTimeframe, req.query)
                return res.json(rows)
            }

            const spending = await getSpendingForRange(startTimeframe, endTimeframe, {
                page,
                pageSize,
                initiativeId
            })
            return res.json(spending)
        } catch (err) {
            console.log(err)
            return res.status(err.status || 500).send({
                message: err.message
            })
        }
    }
)

module.exports = router
