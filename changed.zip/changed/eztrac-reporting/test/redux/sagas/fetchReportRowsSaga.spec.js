import {
  CLEAR_SELECTED_FILTERS,
  SET_ALL_FILTERS,
  SET_SELECTED_FILTERS,
} from '../../../src/client/redux/constants/selectedFiltersConstants'
import {
  FETCH_REPORT_ROWS,
  SET_REPORT_ROWS_DATA,
  SET_REPORT_ROWS_PAGINATION,
  SET_REPORT_ROWS_TOTAL_SPEND,
} from '../../../src/client/redux/constants/reportRowsConstants'
import {
  SET_ALL_FIELDS,
  SET_SELECTED_FIELDS,
} from '../../../src/client/redux/constants/selectedFieldsConstants'
import {
  SET_FETCHED_SPENDING_TREES,
  SET_INITIATIVES_LOADING,
} from '../../../src/client/redux/constants/initiativeConstants'
import {
  getEndTimeFrame,
  getExcludedFilterOptions,
  getReportRowsPagination,
  getSelectedFields,
  getSelectedGrouping,
  getSorting,
  getStartTimeFrame,
} from '../../../src/client/redux/selectors'
import { SET_EXCLUDED_FILTER_OPTIONS } from '../../../src/client/redux/constants/excludedFilterOptionsConstants'
import { SET_SELECTED_GROUPING } from '../../../src/client/redux/constants/selectedGroupingConstants'
import { SET_SELECTED_TIME_FRAMES } from '../../../src/client/redux/constants/timeFramesConstants'
import { SET_SORTING } from '../../../src/client/redux/constants/sortingConstants'
import { call, put as dispatch, select, takeLatest } from 'redux-saga/effects'
import { get } from '../../../src/client/redux/sagas/helpers/makeFetchCall'
import getCombinedSelectedFilters from '../../../src/client/redux/selectors/getCombinedSelectedFilters'
import listener, { fetchReportRowsSaga } from '../../../src/client/redux/sagas/fetchReportRowsSaga'

const startingTimeFrameId = 32103
const endingTimeFrameId = 32104

const encode = value => encodeURIComponent(JSON.stringify(value || []))

describe('Get paged report rows from Reporting Services', () => {
  it('listens for row-affecting actions', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const reportRowConstants = [
      FETCH_REPORT_ROWS,
      SET_SELECTED_TIME_FRAMES,
      SET_SELECTED_FIELDS,
      SET_ALL_FIELDS,
      SET_SELECTED_GROUPING,
      SET_SORTING,
      SET_SELECTED_FILTERS,
      SET_ALL_FILTERS,
      CLEAR_SELECTED_FILTERS,
      SET_EXCLUDED_FILTER_OPTIONS,
    ]

    expect(step()).toEqual(takeLatest(reportRowConstants, fetchReportRowsSaga))
    expect(gen.next().done).toBe(true)
  })

  it('fetches requested page and sends report shape options to the service', () => {
    const selectedFields = [{ name: 'initiativeName', title: 'Allocated Initiative' }]
    const grouping = [{ columnName: 'initiativeName' }]
    const sorting = [{ columnName: 'initiativeName', direction: 'asc' }]
    const selectedFilters = [{ label: 'Status: Funded', value: 'status@Funded' }]
    const excludedFilterOptions = { filterExcludedCostGroups: true }
    const pagination = { page: 1, pageSize: 10, totalCount: 40, totalPages: 4 }
    const responsePagination = { page: 3, pageSize: 25, totalCount: 40, totalPages: 2 }
    const responseRows = [{ initiativeName: 'Alpha', spend: 100 }]
    const totalSpend = 1000
    const query = [
      'view=rows',
      'page=3',
      'pageSize=25',
      `fields=${encode(selectedFields)}`,
      `grouping=${encode(grouping)}`,
      `sorting=${encode(sorting)}`,
      `filters=${encode(selectedFilters)}`,
      `excludedFilterOptions=${encode(excludedFilterOptions)}`,
    ].join('&')
    const gen = fetchReportRowsSaga({
      type: FETCH_REPORT_ROWS,
      payload: { page: 3, pageSize: 25 },
    })
    const step = lastYield => gen.next(lastYield).value

    expect(step()).toEqual(select(getStartTimeFrame))
    expect(step(startingTimeFrameId)).toEqual(select(getEndTimeFrame))
    expect(step(endingTimeFrameId)).toEqual(select(getReportRowsPagination))
    expect(step(pagination)).toEqual(select(getSelectedFields))
    expect(step(selectedFields)).toEqual(select(getSelectedGrouping))
    expect(step(grouping)).toEqual(select(getSorting))
    expect(step(sorting)).toEqual(select(getCombinedSelectedFilters))
    expect(step(selectedFilters)).toEqual(select(getExcludedFilterOptions))
    expect(step(excludedFilterOptions)).toEqual(dispatch({
      type: SET_INITIATIVES_LOADING,
      payload: true,
    }))
    expect(step()).toEqual(call(get, {
      url: `${window.phoenix.urls.services['ez-trac-reporting']}/v2/spending/startTimeFrame/${startingTimeFrameId}/endTimeFrame/${endingTimeFrameId}?${query}`, // eslint-disable-line max-len
    }))
    expect(step({ payload: {
      data: responseRows,
      pagination: responsePagination,
      totalSpend,
    } })).toEqual(dispatch({
      type: SET_INITIATIVES_LOADING,
      payload: false,
    }))
    expect(step()).toEqual(dispatch({
      type: SET_REPORT_ROWS_DATA,
      payload: responseRows,
    }))
    expect(step()).toEqual(dispatch({
      type: SET_REPORT_ROWS_PAGINATION,
      payload: responsePagination,
    }))
    expect(step()).toEqual(dispatch({
      type: SET_REPORT_ROWS_TOTAL_SPEND,
      payload: totalSpend,
    }))
    expect(step()).toEqual(dispatch({
      type: SET_FETCHED_SPENDING_TREES,
    }))
    expect(gen.next().done).toBe(true)
  })
})
