import { RETRIEVE_STORED_DATA } from '../../../src/client/redux/constants/storedDataConstants'
import {
  SET_FETCHED_SPENDING_TREES,
  SET_INITIATIVES_LOADING,
  SET_SELECTED_INITIATIVE,
} from '../../../src/client/redux/constants/initiativeConstants'
import {
  FETCH_SPENDING_TREES_DATA,
  FETCH_SPENDING_TREES_PAGE_DATA,
} from '../../../src/client/redux/constants/spendingTreesConstants'
import { SET_TAB } from '../../../src/client/redux/constants/tabsConstants'
import { SET_SELECTED_TIME_FRAMES } from '../../../src/client/redux/constants/timeFramesConstants'
import { call, put as dispatch, select, takeLatest } from 'redux-saga/effects'
import { getEndTimeFrame, getStartTimeFrame } from '../../../src/client/redux/selectors'
import { get } from '../../../src/client/redux/sagas/helpers/makeFetchCall'
import actions from '../../../src/client/redux/actions'
import listener, {
  fetchSpendingTreesDataForTrendSaga,
  fetchSpendingTreesPageDataSaga,
  fetchSpendingTreesDataSaga,
} from '../../../src/client/redux/sagas/fetchSpendingTreesDataSaga'

const startingTimeFrameId = 32103
const endingTimeFrameId = 32103

describe('Get all initiatives from Reporting Services', () => {
  it('listens for correct action fired', () => {
    const gen = listener()
    const step = lastYield => gen.next(lastYield).value
    const fullDataConstants = [
      FETCH_SPENDING_TREES_DATA,
    ]
    const trendDataConstants = [
      SET_TAB,
    ]
    const pageDataConstants = [
      FETCH_SPENDING_TREES_PAGE_DATA,
      SET_SELECTED_TIME_FRAMES,
      SET_SELECTED_INITIATIVE,
    ]

    expect(step()).toEqual(takeLatest(fullDataConstants, fetchSpendingTreesDataSaga))
    expect(step()).toEqual(takeLatest(trendDataConstants, fetchSpendingTreesDataForTrendSaga))
    expect(step()).toEqual(takeLatest(pageDataConstants, fetchSpendingTreesPageDataSaga))
    expect(gen.next().done).toBe(true)
  })

  it('fetches all initiatives from the reporting service within a range of timeFrames and sets the state', () => {
    const gen = fetchSpendingTreesDataSaga()
    const step = lastYield => gen.next(lastYield).value

    const setFetchedSpendingTreesAction = {
      type: SET_FETCHED_SPENDING_TREES,
    }

    const retrieveStoredDataAction = {
      type: RETRIEVE_STORED_DATA,
      payload: {
        url: `${window.phoenix.urls.services['ez-trac-reporting']}/v2/spending/startTimeFrame/${startingTimeFrameId}/endTimeFrame/${endingTimeFrameId}`, // eslint-disable-line max-len
        sortParam: 'initiativeName',
        storeParam: `spendingTrees(${startingTimeFrameId}/${endingTimeFrameId})`,
        setValueFunc: actions.setSpendingTreesData,
        loadingBarFunc: actions.setInitiativesLoading,
      },
    }


    expect(step()).toEqual(select(getStartTimeFrame))
    expect(step(startingTimeFrameId)).toEqual(select(getEndTimeFrame))
    expect(step(endingTimeFrameId)).toEqual(dispatch(retrieveStoredDataAction))
    expect(step()).toEqual(dispatch(setFetchedSpendingTreesAction))
    expect(gen.next().done).toBe(true)
  })

  it('fetches requested page and page size without resetting to first page', () => {
    const requestedPagination = { page: 3, pageSize: 25, totalCount: 100, totalPages: 4 }
    const pageResponse = {
      data: [
        { initiativeName: 'Zulu Initiative' },
        { initiativeName: 'Alpha Initiative' },
      ],
      pagination: requestedPagination,
    }
    const expectedPageData = [
      { name: 'Alpha Initiative' },
      { name: 'Zulu Initiative' },
    ]
    const gen = fetchSpendingTreesPageDataSaga({
      type: FETCH_SPENDING_TREES_PAGE_DATA,
      payload: requestedPagination,
    })
    const step = lastYield => gen.next(lastYield).value

    expect(step()).toEqual(select(getStartTimeFrame))
    expect(step(startingTimeFrameId)).toEqual(select(getEndTimeFrame))
    expect(step(endingTimeFrameId)).toEqual(select(state => state.initiatives.selectedInitiative))
    expect(step()).toEqual(select(state => state.spendingTreesPagination))
    expect(step({ page: 1, pageSize: 10, totalCount: 100, totalPages: 10 })).toEqual(dispatch({
      type: SET_INITIATIVES_LOADING,
      payload: true,
    }))
    expect(step()).toEqual(call(get, {
      url: `${window.phoenix.urls.services['ez-trac-reporting']}/v2/spending/startTimeFrame/${startingTimeFrameId}/endTimeFrame/${endingTimeFrameId}?page=3&pageSize=25`, // eslint-disable-line max-len
    }))
    expect(step({ payload: pageResponse })).toEqual(dispatch({
      type: SET_INITIATIVES_LOADING,
      payload: false,
    }))
    expect(step()).toEqual(dispatch(actions.setSpendingTreesPagination(requestedPagination)))
    expect(step()).toEqual(dispatch(actions.setSpendingTreesPageData(expectedPageData)))
    expect(gen.next().done).toBe(true)
  })
})
