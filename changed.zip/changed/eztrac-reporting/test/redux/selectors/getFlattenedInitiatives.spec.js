import selector from '../../../src/client/redux/selectors/getFlattenedInitiatives'

describe('get flattened initiatives', () => {
  it('flattens initiatives', () => {
    const leaf1 = {
      children: [],
      totalExpenditure: 200,
      directExpenditure: 200,
      initiative: {
        name: 'leaf1',
        tags: [
          { tagId: 'BUS-UNIT', tagValue: 'R&D' },
          { tagId: 'REGION', tagValue: 'South America' },
        ],
        id: 'leaf1Id',
      },
      effortSpending: [
        {
          timeFrameId: 32104,
          team: {
            teamName: 'team 2',
            teamId: 'teamid2',
          },
          spend: 200,
        },
      ],
    }
    const leaf2 = {
      children: [],
      totalExpenditure: 200,
      directExpenditure: 200,
      initiative: {
        name: 'leaf2',
        tags: [
          { tagId: 'BUS-UNIT', tagValue: 'R&D' },
          { tagId: 'REGION', tagValue: 'North America' },
        ],
        id: 'leaf2Id',
      },
      effortSpending: [
        {
          timeFrameId: 32104,
          team: {
            teamName: 'team 2',
            teamId: 'teamid2',
          },
          spend: 200,
        },
      ],
    }
    const leafParent2 = {
      children: [ leaf2 ],
      totalExpenditure: 200,
      directExpenditure: 200,
      initiative: {
        name: 'leafParent2',
        tags: [
          { tagId: 'BUS-UNIT', tagValue: 'R&D' },
          { tagId: 'REGION', tagValue: 'North America' },
        ],
        id: 'leafParent2Id',
      },
      effortSpending: [
        {
          timeFrameId: 32104,
          team: {
            teamName: 'team 1',
            teamId: 'teamid1',
          },
          spend: 200,
        },
      ],
    }

    const leafParent = {
      children: [ leaf1, leafParent2 ],
      totalExpenditure: 800,
      directExpenditure: 500,
      initiative: {
        name: 'leafParent',
        tags: [],
        id: 'leafParentId',
      },
      effortSpending: [
        {
          timeFrameId: 32104,
          team: {
            teamName: 'team 3',
            teamId: 'teamid3',
          },
          spend: 500,
        },
      ],
    }

    const root1 = {
      children: [ leafParent ],
      totalExpenditure: 800,
      directExpenditure: 0,
      initiative: {
        name: 'root1',
        tags: [],
        id: 'root1Id',
      },
      effortSpending: [],
    }

    const root2Child = {
      children: [],
      totalExpenditure: 40,
      directExpenditure: 40,
      initiative: {
        name: 'root2Child',
        tags: [],
        id: 'root2ChildId',
      },
      effortSpending: [
        {
          timeFrameId: 32104,
          team: {
            teamName: 'team 4',
            teamId: 'teamid4',
          },
          spend: 40,
        },
      ],
    }

    const root2 = {
      children: [ root2Child ],
      totalExpenditure: 90,
      directExpenditure: 50,
      initiative: {
        name: 'root2',
        tags: [],
        id: 'root2Id',
      },
      effortSpending: [
        {
          timeFrameId: 32104,
          team: {
            teamName: 'team 5',
            teamId: 'teamid5',
          },
          spend: 50,
        },
      ],
    }

    const state = {
      spendingTrees: [ root1, root2 ],
    }

    const expected = [
      { ...root1.initiative, effortSpending: root1.effortSpending, parent: null, path: '', namePath: '' },
      { ...leafParent.initiative, effortSpending: leafParent.effortSpending, parent: 'root1Id', path: 'root1Id', namePath: 'root1' }, // eslint-disable-line max-len
      { ...leaf1.initiative, effortSpending: leaf1.effortSpending, parent: 'leafParentId', path: 'root1Id.leafParentId', namePath: 'root1~leafParent' }, // eslint-disable-line max-len
      { ...leafParent2.initiative, effortSpending: leafParent2.effortSpending, parent: 'leafParentId', path: 'root1Id.leafParentId', namePath: 'root1~leafParent' }, // eslint-disable-line max-len
      { ...leaf2.initiative, effortSpending: leaf2.effortSpending, parent: 'leafParent2Id', path: 'root1Id.leafParentId.leafParent2Id', namePath: 'root1~leafParent~leafParent2' }, // eslint-disable-line max-len
      { ...root2.initiative, effortSpending: root2.effortSpending, parent: null, path: '', namePath: '' },
      { ...root2Child.initiative, effortSpending: root2Child.effortSpending, parent: 'root2Id', path: 'root2Id', namePath: 'root2' }, // eslint-disable-line max-len
    ]

    const actual = selector(state)
    expect(actual).toEqual(expected)
  })

  it('ignores malformed spending tree nodes without crashing', () => {
    const validChild = {
      children: [],
      initiative: {
        name: 'validChild',
        id: 'validChildId',
      },
      effortSpending: [],
    }

    const validRoot = {
      children: [ undefined, { children: [], effortSpending: [] }, validChild ],
      initiative: {
        name: 'validRoot',
        id: 'validRootId',
      },
      effortSpending: [],
    }

    const state = {
      spendingTrees: [ undefined, { children: [], effortSpending: [] }, validRoot ],
    }

    const expected = [
      { ...validRoot.initiative, effortSpending: validRoot.effortSpending, parent: null, path: '', namePath: '' },
      { ...validChild.initiative, effortSpending: validChild.effortSpending, parent: 'validRootId', path: 'validRootId', namePath: 'validRoot' }, // eslint-disable-line max-len
    ]

    const actual = selector(state)
    expect(actual).toEqual(expected)
  })
})
