import { sortInitiatives } from '../../../src/client/redux/selectors/getSortedFilteredInitiatives'

describe('get sorted initiatives', () => {
  it('sorts the children if there is only one top level initiative', () => {
    const spendingTrees = [{
      children: [{ initiative: { name: 'b' } }, { initiative: { name: 'a' } }],
      initiative: { name: 'parent' },
    }]

    const expected = [{
      children: [{ initiative: { name: 'a' } }, { initiative: { name: 'b' } }],
      initiative: { name: 'parent' },
    }]
    const actual = sortInitiatives(spendingTrees)

    expect(actual).toEqual(expected)
  })

  it('sorts all top level initiatives and not their children if there is more than one top level initiative', () => {
    const spendingTrees = [{
      children: [{ initiative: { name: 'b' } }, { initiative: { name: 'a' } }],
      initiative: { name: 'parentB' },
    },
    {
      children: [{ initiative: { name: 'd' } }, { initiative: { name: 'c' } }],
      initiative: { name: 'parentA' },
    }]

    const expected = [
      {
        children: [{ initiative: { name: 'd' } }, { initiative: { name: 'c' } }],
        initiative: { name: 'parentA' },
      },
      {
        children: [{ initiative: { name: 'b' } }, { initiative: { name: 'a' } }],
        initiative: { name: 'parentB' },
      },
    ]

    const actual = sortInitiatives(spendingTrees)

    expect(actual).toEqual(expected)
  })

  it('ignores malformed spending tree nodes without crashing', () => {
    const spendingTrees = [{
      children: [ undefined, { children: [] }, { initiative: { name: 'b' } }, { initiative: { name: 'a' } } ],
      initiative: { name: 'parent' },
    }]

    const expected = [{
      children: [{ initiative: { name: 'a' } }, { initiative: { name: 'b' } }],
      initiative: { name: 'parent' },
    }]

    const actual = sortInitiatives(spendingTrees)

    expect(actual).toEqual(expected)
  })
})
