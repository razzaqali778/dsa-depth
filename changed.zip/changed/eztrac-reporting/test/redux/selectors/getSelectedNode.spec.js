import selector from '../../../src/client/redux/selectors/getSelectedNode'

describe('gets the children of a selected initiative', () => {
  it('returns null if no selected node', () => {
    const state = {
      spendingTrees: [
        { initiative: { name: 'bob' } },
        { initiative: { name: 'billy bob' } },
        { initiative: { name: 'billy' } },
        { initiative: { name: 'bob billy' } },
      ],
      initiatives: {
        selectedInitiative: '',
        searchText: '',
      },
    }
    const expected = null
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })

  it('returns null if selected is not found,', () => {
    const state = {
      spendingTrees: [
        { initiative: { id: 'blob' } },
        { initiative: { id: 'billy blob' } },
        { initiative: { id: 'frank' } },
      ],
      initiatives: {
        selectedInitiative: 'bill',
        searchText: '',
      },
    }
    const expected = null
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })
  it('skips malformed nodes without crashing', () => {
    const state = {
      spendingTrees: [
        null,
        { children: [] },
        { initiative: { id: 'blob' } },
      ],
      initiatives: {
        selectedInitiative: 'blob',
        searchText: '',
      },
    }
    const expected = {
      node: { initiative: { id: 'blob' } },
      path: [{ id: '', name: 'Initiatives' }, { id: 'blob' }],
    }
    expect(selector(state)).toEqual(expected)
  })
  it('returns null when spendingTrees is not an array (e.g. paginated wrapper)', () => {
    const state = {
      spendingTrees: {
        data: [{ initiative: { id: 'blob' } }],
        pagination: { page: 1, pageSize: 25, totalCount: 1, totalPages: 1 },
        path: [{ id: '', name: 'Initiatives' }],
      },
      initiatives: {
        selectedInitiative: 'blob',
        searchText: '',
      },
    }
    expect(selector(state)).toEqual(null)
  })
  it('returns a node when it is selected,', () => {
    const state = {
      spendingTrees: [
        { initiative: { id: 'blob' } },
        { initiative: { id: 'billy blob' } },
        { initiative: { id: 'frank' } },
      ],
      initiatives: {
        selectedInitiative: 'blob',
        searchText: '',
      },
    }
    const expected = {
      node: { initiative: { id: 'blob' } },
      path: [{ id: '', name: 'Initiatives' }, { id: 'blob' }],
    }
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })
  it('returns a node when it is selected and is a child of a top level', () => {
    const state = {
      spendingTrees: [
        {
          initiative: { id: 'blob' },
          children: [{
            initiative: { id: 'blob-child', some: 'data' },
          }],
        },
        { initiative: { id: 'billy blob' } },
        { initiative: { id: 'frank' } },
      ],
      initiatives: {
        selectedInitiative: 'blob-child',
        searchText: '',
      },
    }

    const expected = {
      node: { initiative: { id: 'blob-child', some: 'data' } },
      path: [
        { id: '', name: 'Initiatives' },
        { id: 'blob' },
        { id: 'blob-child' },
      ],
    }
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })
  it('returns a node when it is selected and is a great grandchild of third top level', () => {
    const state = {
      spendingTrees: [
        {
          initiative: { id: 'blob' },
          children: [{ initiative: { id: 'blob-child', some: 'data' } }],
        },
        {
          initiative: { id: 'billy blob' },
          children: [{ initiative: { id: 'billy-blob-child' } }],
        },
        {
          initiative: { id: 'frank' },
          children: [{
            initiative: { id: 'franks-first-kid' },
            children: [{
              initiative: { id: 'franks-first-grandkid' },
            }, {
              initiative: { id: 'franks-second-grandkid' },
              children: [{ initiative: { id: 'franks-first-great-grandkid' } }],
            }],
          }],
        },
      ],
      initiatives: {
        selectedInitiative: 'franks-second-grandkid',
        searchText: '',
      },
    }

    const expected = {
      node: {
        initiative: {
          id: 'franks-second-grandkid',
        },
        children: [{ initiative: { id: 'franks-first-great-grandkid' } }],
      },
      path: [
        { id: '', name: 'Initiatives' },
        { id: 'frank' },
        { id: 'franks-first-kid' },
        { id: 'franks-second-grandkid' },
      ],
    }
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })
})
