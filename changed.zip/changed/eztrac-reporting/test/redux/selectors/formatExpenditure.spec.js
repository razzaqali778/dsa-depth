import { formatExpenditure } from '../../../src/client/redux/selectors'


describe('formatExpenditure selector test', () => {
  it('Tests comma placement for number in the hundres', () => {
    const actual = formatExpenditure(400.3245)

    expect(actual).toEqual('$400')
  })

  it('Tests comma placement for number in the thousands', () => {
    const actual = formatExpenditure(4000.3245)

    expect(actual).toEqual('$4,000')
  })

  it('Tests comma placement for number in the millions', () => {
    const actual = formatExpenditure(4000700.3245)

    expect(actual).toEqual('$4,000,700')
  })

  it('Formats numeric strings from the API', () => {
    expect(formatExpenditure('4000.3245')).toEqual('$4,000')
  })

  it('Returns $0 for non-numeric values', () => {
    expect(formatExpenditure(undefined)).toEqual('$0')
    expect(formatExpenditure(null)).toEqual('$0')
    expect(formatExpenditure('')).toEqual('$0')
    expect(formatExpenditure('abc')).toEqual('$0')
  })
})
