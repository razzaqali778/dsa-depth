import { createSelector } from 'reselect'
import { getSelectedInitiative, getSpendingTrees } from './'
import pick from 'lodash/pick'
import reduce from 'lodash/reduce'
import slice from 'lodash/slice'

export default createSelector(
  getSpendingTrees,
  getSelectedInitiative,
  (spendingTrees, selected) => {
    if ( !( selected && selected.length ) ) { return null }

    const search = (list, val) => {
      if ( !Array.isArray(list) ) { return val }

      const found = reduce(list, (memo, node) => {
        if ( memo.node ) { return memo } // node was found, stop searching
        if ( !( node && node.initiative && node.initiative.id !== undefined ) ) {
          return memo // skip malformed nodes (e.g. paginated wrapper mistakenly stored as trees)
        }
        const path = [ ...memo.path, pick(node.initiative, [ 'id', 'name' ]) ] // add node to path
        if ( node.initiative.id === selected ) {
          return { node, path } // done, return
        }
        const recurseResult = search(node.children, { ...memo, path })

        if ( !recurseResult.node ) { // returning up the tree, no match found, need to pop off the path
          return { ...recurseResult, path: slice(recurseResult.path, 0, recurseResult.path.length - 1) }
        }

        return recurseResult
      }, val)

      return found
    }

    const found = search(spendingTrees, { node: null, path: [{ id: '', name: 'Initiatives' }] })

    if ( found.node ) {
      return found
    }

    return null
  },
)
