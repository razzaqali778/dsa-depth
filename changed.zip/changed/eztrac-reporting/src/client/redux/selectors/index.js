import sortBy from 'lodash/sortBy'

export const formatExpenditure = expenditure => {
  const amount = Number(expenditure)

  return amount
    ? `$${amount.toFixed().replace(/(\d)(?=(\d{3})+$)/g, '$1,')}`
    : '$0'
}

export const getStateTimeFrames = state => state.timeFrames
export const getInitiatives = state => state.initiatives.initiatives
export const getInitiativeTagNames = state => state.initiatives.tagNames
export const getSearchText = state => state.initiatives.searchText
export const getSelectedInitiative = state => state.initiatives.selectedInitiative
export const getInitiativesLoading = state => state.initiatives.initiativesLoading

export const getSpendingTrees = state => state.spendingTrees
export const getReportRowsPagination = state => state.reportRows.pagination

export const getTimeFrames = state => state.timeFrames.timeFrames
export const getStartTimeFrame = state => state.timeFrames.startTimeFrame
export const getEndTimeFrame = state => state.timeFrames.endTimeFrame
export const getFiscalYears = state => state.timeFrames.fiscalYears
export const getTimeFrameSelectionType = state => state.timeFrames.selectionType

export const getSelectedFilters = state => state.selectedFilters

export const getLocationQuery = state => state.location.query

export const getSelectedFields = state => state.selectedFields

export const getSaveModal = state => state.saveModal
export const getLoadModal = state => state.loadModal
export const getEditModal = state => state.editModal
export const getHelpModal = state => state.helpModal
export const getSavedReports = state => sortBy(state.preferences.reports, [ 'name' ])

export const getSaveModalMode = state => state.saveModal.mode

export const getSelectedReport = state => state.editModal.selectedReport
export const getLoadModalSelectedReport = state => state.loadModal.selectedReport

export const getSaveModalDetails = state => state.saveModal
export const getIncludedFields = state => state.saveModal.includeFields
export const getIncludedFilters = state => state.saveModal.includeFilters
export const getSelectedTimeFrameSelectionType = state => state.saveModal.selectionType
export const getSavingReportName = state => state.saveModal.reportName.trim()

export const getReportName = state => state.saveModal.reportName

export const getActiveReport = state => state.activeReport

export const getPreferences = state => state.preferences

export const getSelectedGrouping = state => state.selectedGrouping

export const getDownloadMenu = state => state.downloadMenu

export const getTabs = state => state.tabs.tabs

export const getSorting = state => state.sorting

export const getDeprecatedFilterAlertModal = state => state.deprecatedFilterAlertModal

export const getDeprecatedFilters = state => state.deprecatedFilters

export const getExcludedFilterOptions = state => state.excludedFilterOptions

export const getCostGroups = state => state.costGroups
