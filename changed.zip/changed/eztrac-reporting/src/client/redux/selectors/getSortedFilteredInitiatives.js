import { createSelector } from 'reselect'
import getFilteredInitiatives from './getFilteredInitiatives'
import filter from 'lodash/filter'
import sortBy from 'lodash/sortBy'

const isValidSpendingTree = tree => tree && tree.initiative && tree.initiative.name

export const sortInitiatives = spendingTrees => {
  const validSpendingTrees = filter(spendingTrees, isValidSpendingTree)

  return validSpendingTrees.length === 1
    ?
    [{ ...validSpendingTrees[0], children: sortBy(filter(validSpendingTrees[0].children, isValidSpendingTree), tree => tree.initiative.name) }]
    :
    sortBy(validSpendingTrees, tree => tree.initiative.name)
}

export default createSelector(
  getFilteredInitiatives,
  sortInitiatives,
)
