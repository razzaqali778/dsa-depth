import { createSelector } from 'reselect'
import { getSpendingTrees } from './'
import forEach from 'lodash/forEach'

export const getFlattened = spendingTrees => {
  const visit = (list, parent, spendingTree, path, namePath) => {
    if ( !(spendingTree && spendingTree.initiative && spendingTree.initiative.id) ) { return }

    const { initiative, children = [], effortSpending = [] } = spendingTree

    list.push({
      ...initiative,
      effortSpending,
      parent,
      path,
      namePath,
    })

    const nextPath = path === '' ? initiative.id : `${path}.${initiative.id}`
    const nextNamePath = namePath === '' ? initiative.name : `${namePath}~${initiative.name}`

    forEach(children, child => visit(list, initiative.id, child, nextPath, nextNamePath))
  }

  const list = []

  forEach(spendingTrees, tree => visit(list, null, tree, '', ''))

  return list
}

export default createSelector(
  getSpendingTrees,
  getFlattened,
)
