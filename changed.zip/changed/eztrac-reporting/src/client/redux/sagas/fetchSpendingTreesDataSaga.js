import {
  call,
  put as dispatch,
  select,
  takeLatest,
} from 'redux-saga/effects'
import { getEndTimeFrame, getStartTimeFrame } from '../selectors'
import { get } from './helpers/makeFetchCall'
import { serviceBindings } from '../../getServiceBinding'
import actions from '../actions'
import { FETCH_SPENDING_TREES_PAGE_DATA } from '../constants/spendingTreesConstants'
import sortBy from 'lodash/sortBy'
import isEmpty from 'lodash/isEmpty'

const reportingServicesUrl = serviceBindings.reportingUrl

export function* fetchSpendingTreesDataSaga() {
  const startTimeFrame = yield select(getStartTimeFrame)
  const endTimeFrame = yield select(getEndTimeFrame)
  if ( startTimeFrame !== 0 && endTimeFrame !== 0 ) {
    yield dispatch(actions.retrieveStoredData({
      url: `${reportingServicesUrl}/v2/spending/startTimeFrame/${startTimeFrame}/endTimeFrame/${endTimeFrame}`, // eslint-disable-line max-len
      sortParam: 'initiativeName',
      storeParam: `spendingTrees(${startTimeFrame}/${endTimeFrame})`,
      setValueFunc: actions.setSpendingTreesData,
      loadingBarFunc: actions.setInitiativesLoading,
    }))
  }
  yield dispatch(actions.setFetchedSpendingTrees())
}

export function* fetchSpendingTreesPageDataSaga({ payload = {}, type } = {}) {
  const startTimeFrame = yield select(getStartTimeFrame)
  const endTimeFrame = yield select(getEndTimeFrame)
  const selectedInitiative = yield select(state => state.initiatives.selectedInitiative)
  const pagination = yield select(state => state.spendingTreesPagination)
  if ( startTimeFrame !== 0 && endTimeFrame !== 0 ) {
    const shouldResetToFirstPage = type !== FETCH_SPENDING_TREES_PAGE_DATA
    const page = payload.page || (shouldResetToFirstPage ? 1 : pagination && pagination.page) || 1
    const pageSize = payload.pageSize || (pagination && pagination.pageSize) || 10
    const initiativeQuery = selectedInitiative ? `&initiativeId=${selectedInitiative}` : ''
    const url = `${reportingServicesUrl}/v2/spending/startTimeFrame/${startTimeFrame}/endTimeFrame/${endTimeFrame}?page=${page}&pageSize=${pageSize}${initiativeQuery}` // eslint-disable-line max-len

    yield dispatch(actions.setInitiativesLoading(true))
    const { payload: data, error: err } = yield call(get, { url })
    yield dispatch(actions.setInitiativesLoading(false))

    if ( err ) { return }

    if ( data.pagination ) {
      yield dispatch(actions.setSpendingTreesPagination(data.pagination))
    }

    const responseData = data.data || data
    const sortedData = sortBy(responseData, 'initiativeName')
    const pageData = JSON.parse(JSON.stringify(sortedData).replace(/initiativeName/g, 'name'))
    yield dispatch(actions.setSpendingTreesPageData(pageData))
  }
}

export function* fetchSpendingTreesDataForTrendSaga({ payload } = {}) {
  const spendingTrees = yield select(state => state.spendingTrees)

  if ( payload === 1 && isEmpty(spendingTrees) ) {
    yield* fetchSpendingTreesDataSaga()
  }
}

export default function* () {
  yield takeLatest([
    actions.fetchSpendingTreesData().type,
  ], fetchSpendingTreesDataSaga)
  yield takeLatest([
    actions.setTab().type,
  ], fetchSpendingTreesDataForTrendSaga)
  yield takeLatest([
    actions.fetchSpendingTreesPageData().type,
    actions.setSelectedTimeFrames().type,
    actions.setSelectedInitiative().type,
  ], fetchSpendingTreesPageDataSaga)
}
