import {
  call,
  put as dispatch,
  takeLatest,
} from 'redux-saga/effects'
import { get } from './helpers/makeFetchCall'
import actions from '../actions'
import isEmpty from 'lodash/isEmpty'
import localForage from 'localforage'
import os from 'os-browserify'
import sortBy from 'lodash/sortBy'
import store from 'store2'

export function* retrieveStoredDataSaga({ payload }) {
  const isLocalHost = os.hostname() === 'localhost'

  if ( !store.session.has('session') && isLocalHost ) {
    store.session('session', 'on')
    localForage.clear()
  }

  const url = payload.url
  const shouldUseLocalCache = isLocalHost && !payload.paginationFunc
  const storeName = shouldUseLocalCache ? payload.storeParam : ''
  let returnVal = shouldUseLocalCache
    ? yield localForage.getItem(payload.storeParam, (err, val) => val === null ? [] : val)
    : []

  if ( isEmpty(returnVal) ) {
    yield dispatch(payload.loadingBarFunc(true))
    const { payload: data, error: err } = yield call(get, { url })
    if ( err ) {
      yield dispatch(payload.loadingBarFunc(false))

      return
    }

    if ( payload.paginationFunc && data.pagination ) {
      yield dispatch(payload.paginationFunc(data.pagination))
    }

    const responseData = data.data || data
    const sortedData = payload.sortParam !== '' ? sortBy(responseData, payload.sortParam) : responseData
    returnVal = JSON.stringify(sortedData).replace(/initiativeName/g, 'name')
  }

  if ( storeName !== '' ) {
    localForage.setItem(storeName, returnVal)
  }

  const retrievedData = JSON.parse(returnVal)
  yield dispatch(payload.loadingBarFunc(false))
  yield dispatch(payload.setValueFunc(retrievedData))
  yield dispatch(actions.getDeprecatedFilters())
  yield dispatch(actions.checkFiltersForIds())
}

export default function* () {
  yield takeLatest([
    actions.retrieveStoredData().type,
  ], retrieveStoredDataSaga)
}
