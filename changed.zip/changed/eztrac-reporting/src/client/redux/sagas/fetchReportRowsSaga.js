import {
  call,
  put as dispatch,
  select,
  takeLatest,
} from 'redux-saga/effects'
import {
  CLEAR_SELECTED_FILTERS,
  SET_ALL_FILTERS,
  SET_SELECTED_FILTERS,
} from '../constants/selectedFiltersConstants'
import {
  FETCH_REPORT_ROWS,
} from '../constants/reportRowsConstants'
import {
  SET_ALL_FIELDS,
  SET_SELECTED_FIELDS,
} from '../constants/selectedFieldsConstants'
import {
  getEndTimeFrame,
  getExcludedFilterOptions,
  getReportRowsPagination,
  getSelectedFields,
  getSelectedGrouping,
  getSorting,
  getStartTimeFrame,
} from '../selectors'
import { SET_EXCLUDED_FILTER_OPTIONS } from '../constants/excludedFilterOptionsConstants'
import { SET_SELECTED_GROUPING } from '../constants/selectedGroupingConstants'
import { SET_SELECTED_TIME_FRAMES } from '../constants/timeFramesConstants'
import { SET_SORTING } from '../constants/sortingConstants'
import { get } from './helpers/makeFetchCall'
import { serviceBindings } from '../../getServiceBinding'
import actions from '../actions'
import getCombinedSelectedFilters from '../selectors/getCombinedSelectedFilters'

const reportingServicesUrl = serviceBindings.reportingUrl

const encodeQuery = value => encodeURIComponent(JSON.stringify(value || []))

const getRequestedPagination = (payload, pagination, shouldResetToFirstPage) => ({
  page: payload.page || (shouldResetToFirstPage ? 1 : pagination.page) || 1,
  pageSize: payload.pageSize || pagination.pageSize || 10,
})

export function* fetchReportRowsSaga({ payload = {}, type } = {}) {
  const startTimeFrame = yield select(getStartTimeFrame)
  const endTimeFrame = yield select(getEndTimeFrame)

  if ( startTimeFrame === 0 || endTimeFrame === 0 ) {
    return
  }

  const pagination = yield select(getReportRowsPagination)
  const selectedFields = yield select(getSelectedFields)
  const selectedGrouping = yield select(getSelectedGrouping)
  const sorting = yield select(getSorting)
  const selectedFilters = yield select(getCombinedSelectedFilters)
  const excludedFilterOptions = yield select(getExcludedFilterOptions)
  const shouldResetToFirstPage = type !== FETCH_REPORT_ROWS
  const { page, pageSize } = getRequestedPagination(payload, pagination, shouldResetToFirstPage)
  const query = [
    'view=rows',
    `page=${page}`,
    `pageSize=${pageSize}`,
    `fields=${encodeQuery(selectedFields)}`,
    `grouping=${encodeQuery(selectedGrouping)}`,
    `sorting=${encodeQuery(sorting)}`,
    `filters=${encodeQuery(selectedFilters)}`,
    `excludedFilterOptions=${encodeQuery(excludedFilterOptions)}`,
  ].join('&')
  const url = `${reportingServicesUrl}/v2/spending/startTimeFrame/${startTimeFrame}/endTimeFrame/${endTimeFrame}?${query}` // eslint-disable-line max-len

  yield dispatch(actions.setInitiativesLoading(true))
  const { payload: data, error: err } = yield call(get, { url })
  yield dispatch(actions.setInitiativesLoading(false))

  if ( err ) { return }

  yield dispatch(actions.setReportRowsData(data.data || []))
  yield dispatch(actions.setReportRowsPagination(data.pagination))
  yield dispatch(actions.setReportRowsTotalSpend(data.totalSpend))
  yield dispatch(actions.setFetchedSpendingTrees())
}

export default function* () {
  yield takeLatest([
    FETCH_REPORT_ROWS,
    SET_SELECTED_TIME_FRAMES,
    SET_SELECTED_FIELDS,
    SET_ALL_FIELDS,
    SET_SELECTED_GROUPING,
    SET_SORTING,
    SET_SELECTED_FILTERS,
    SET_ALL_FILTERS,
    CLEAR_SELECTED_FILTERS,
    SET_EXCLUDED_FILTER_OPTIONS,
  ], fetchReportRowsSaga)
}
