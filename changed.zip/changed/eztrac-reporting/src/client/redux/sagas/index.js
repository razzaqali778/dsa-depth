import { all, call, fork } from 'redux-saga/effects'
import checkFiltersForIdsListener from './checkFiltersForIdsSaga'
import checkboxToggleListener from './checkboxToggleSaga'
import clearReportListener from './clearReportSaga'
import closeEditModalListener from './closeEditModalSaga'
import closeLoadModalListener from './closeLoadModalSaga'
import closeSaveModalListener from './closeSaveModalSaga'
import deleteReportListener from './deleteReportSaga'
import fetchCostGroups from './fetchCostGroupsSaga'
import fetchCurrentFiscalYear from './fetchCurrentFiscalYearSaga'
import fetchCurrentMonth from './fetchCurrentMonthSaga'
import fetchFavoriteTeamPreferences from './fetchFavoriteTeamPreferencesSaga'
import fetchFiscalYears from './fetchFiscalYearsSaga'
import fetchNextFiscalYear from './fetchNextFiscalYearSaga'
import fetchPreferences from './fetchPreferences'
import fetchPreviousFiscalYear from './fetchPreviousFiscalYearSaga'
import fetchReportRows from './fetchReportRowsSaga'
import fetchRemainingFiscalYear from './fetchRemainingFiscalYearSaga'
import fetchSpendingTreesData from './fetchSpendingTreesDataSaga'
import fetchTagNames from './fetchTagNames'
import fetchTimeFrames from './fetchTimeFramesSaga'
import handleLocationChangeListener from './handleLocationChange'
import handleLocationStateChangeListener from './handleLocationStateChange'
import handleManualTimeFrameSelectionListener from './handleManualTimeFrameSelectionSaga'
import loadReportListener from './loadReportSaga'
import openEditModalListener from './openEditModalSaga'
import openSaveModalListener from './openSaveModalSaga'
import refreshReport from './refreshReportSaga'
import renameReportListener from './renameReportSaga'
import retrieveStoredDataListener from './retrieveStoredDataSaga'
import saveActiveReportListener from './saveActiveReportSaga'
import saveReportListener from './saveReportSaga'
import setDeprecatedFiltersListener from './setDeprecatedFiltersSaga'
import setNewReportNameListener from './setNewReportNameSaga'
import setPreferencesListener from './setPreferences'
import setReportNameListener from './setReportNameSaga'
import setSelectedReportListener from './setSelectedReportSaga'
import validateEndTimeFrameSelectionListener from './validateEndTimeFrameSelection'

/* eslint-disable max-statements */
export default function* sagasMain() {
  yield fork(handleLocationStateChangeListener)
  yield fork(handleManualTimeFrameSelectionListener)
  yield fork(handleLocationChangeListener)
  yield fork(fetchSpendingTreesData)
  yield fork(fetchReportRows)
  yield fork(validateEndTimeFrameSelectionListener)
  yield fork(setPreferencesListener)
  yield fork(saveReportListener)
  yield fork(saveActiveReportListener)
  yield fork(closeSaveModalListener)
  yield fork(closeEditModalListener)
  yield fork(closeLoadModalListener)
  yield fork(loadReportListener)
  yield fork(fetchPreferences)
  yield fork(fetchFavoriteTeamPreferences)
  yield fork(deleteReportListener)
  yield fork(renameReportListener)
  yield fork(setReportNameListener)
  yield fork(setNewReportNameListener)
  yield fork(checkboxToggleListener)
  yield fork(setSelectedReportListener)
  yield fork(retrieveStoredDataListener)
  yield fork(fetchPreviousFiscalYear)
  yield fork(fetchCurrentFiscalYear)
  yield fork(fetchCurrentMonth)
  yield fork(fetchRemainingFiscalYear)
  yield fork(fetchNextFiscalYear)
  yield fork(openSaveModalListener)
  yield fork(openEditModalListener)
  yield fork(clearReportListener)
  yield fork(setDeprecatedFiltersListener)
  yield fork(checkFiltersForIdsListener)
  yield all([
    call(fetchCostGroups),
    call(fetchTimeFrames),
    call(fetchTagNames),
    call(fetchFiscalYears),
  ])
  yield call(refreshReport)
}
/* eslint-enable max-statements */
