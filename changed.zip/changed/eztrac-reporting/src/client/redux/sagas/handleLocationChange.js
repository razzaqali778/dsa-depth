import { decodeJSON } from '../../utils/base64Encode'
import {
  put as dispatch,
  select,
  take,
  takeLatest,
} from 'redux-saga/effects'
import { getActiveReport, getExcludedFilterOptions } from '../../../client/redux/selectors'
import actions from '../actions'
import isEmpty from 'lodash/isEmpty'
import isEqual from 'lodash/isEqual'
import isString from 'lodash/isString'

export const getSelectionType = state => state.selectionType
export const getTimeFrames = state => state.timeFrames
export const getStartTimeFrame = state => state.timeFrames.startTimeFrame
export const getEndTimeFrame = state => state.timeFrames.endTimeFrame
export const getSpendingTrees = state => state.spendingTrees
export const getSelectedFilters = state => state.selectedFilters
export const getSelectedFields = state => state.selectedFields
export const getSelectedGroupings = state => state.selectedGroupings
export const getSelectedSorting = state => state.sorting
export const getSelectedInitiative = state => state.initiatives.selectedInitiative

function* handleStartTimeFrame(startTimeFrame) {
  if ( startTimeFrame ) {
    const val = parseInt(startTimeFrame, 10)
    const cur = yield select(getStartTimeFrame)
    if ( !isEqual(val, cur) ) {
      yield dispatch(actions.setStartTimeFrame(val))
    }
  }
}

function* handleEndTimeFrame(endTimeFrame) {
  if ( endTimeFrame ) {
    const val = parseInt(endTimeFrame, 10)
    const cur = yield select(getEndTimeFrame)
    if ( !isEqual(val, cur) ) {
      yield dispatch(actions.setEndTimeFrame(val))
    }
  }
}

function* handleTimeFrameTypeSelection(selectionTypeString) {
  const cur = yield select(getSelectionType)
  const selectionType = selectionTypeString && isString(selectionTypeString) ? decodeJSON(selectionTypeString) : ''
  if ( !isEqual(selectionType, cur) ) {
    yield dispatch(actions.setSelectionType(selectionType))
  }
}

function* handleInitialFetch(startTimeFrame, endTimeFrame, firstLoad) {
  if ( startTimeFrame && endTimeFrame && firstLoad ) {
    const timeFrames = yield select(getTimeFrames)
    const spendingTrees = yield select(getSpendingTrees)

    if ( isEmpty(timeFrames) ) {
      yield take(actions.setTimeFrames().type)
    }
    if ( isEmpty(spendingTrees) ) {
      yield dispatch(actions.setSelectedTimeFrames())
    }
  }
}

function* handleFilters(filterString) {
  const cur = yield select(getSelectedFilters)
  const filters = filterString && isString(filterString) ? decodeJSON(filterString) : {}
  if ( !isEqual(filters, cur) ) {
    yield dispatch(actions.setAllFilters(filters))
  }
}

function* handleGroupings(groupingString) {
  const cur = yield select(getSelectedGroupings)
  const groupings = groupingString && isString(groupingString) ? decodeJSON(groupingString) : []
  if ( !isEqual(groupings, cur) ) {
    yield dispatch(actions.setSelectedGrouping(groupings))
  }
}

function* handleSorting(sortingString) {
  const cur = yield select(getSelectedSorting)
  const sorting = sortingString && isString(sortingString) ? decodeJSON(sortingString) : cur
  if ( !isEqual(sorting, cur) ) {
    yield dispatch(actions.setSorting(sorting))
  }
}

function* handleFields(fieldString) {
  const cur = yield select(getSelectedFields)
  const fields = fieldString && isString(fieldString) ? decodeJSON(fieldString) : []

  if ( !isEqual(fields, cur) ) {
    yield dispatch(actions.setAllFields(fields))
  }
}

function* handleSelectedInitiative(selectedInitiative) {
  const cur = yield select(getSelectedInitiative)
  if ( selectedInitiative !== cur ) {
    yield dispatch(actions.setSelectedInitiative(selectedInitiative || ''))
  }
}

function* handleActiveReport(activeReport) {
  const currentActiveReport = yield select(getActiveReport)
  const report = activeReport ? decodeJSON(activeReport) : currentActiveReport
  if ( report !== currentActiveReport ) {
    yield dispatch(actions.setActiveReport(report || 'New Report' ))
  }
}
function* handleExcludedFilterOptions(excludedFilterOptions) {
  const currentExcludedFilterOptions = yield select(getExcludedFilterOptions)
  const filterOptions = excludedFilterOptions ? decodeJSON(excludedFilterOptions) : currentExcludedFilterOptions
  if ( !isEqual(currentExcludedFilterOptions, filterOptions ) ) {
    yield dispatch(actions.setExcludedFilterOptions(filterOptions))
  }
}

export function* handleLocationChange({ payload }) {
  const { pathname, firstLoad, queryString } = payload

  const query = (payload.query.startTimeFrame && payload.query.endTimeFrame)
    ? {
      ...payload.query,
      startTimeFrame: payload.query.startTimeFrame,
      endTimeFrame: payload.query.endTimeFrame,
    }
    : payload.query

  const {
    activeReport,
    filters,
    startTimeFrame,
    endTimeFrame,
    selectedInitiative,
    fields,
    selectionType,
    sorting,
    groupings,
    excludedFilterOptions,
  } = query


  yield dispatch(actions.setLocation({ query, pathname, queryString }))
  yield* handleExcludedFilterOptions(excludedFilterOptions)
  yield* handleActiveReport(activeReport)
  yield* handleTimeFrameTypeSelection(selectionType)
  yield* handleStartTimeFrame(startTimeFrame)
  yield* handleEndTimeFrame(endTimeFrame)
  yield* handleInitialFetch(startTimeFrame, endTimeFrame, firstLoad)
  yield* handleSelectedInitiative(selectedInitiative)
  yield* handleFilters(filters)
  yield* handleFields(fields)
  yield* handleGroupings(groupings)
  yield* handleSorting(sorting)
}

export default function* () {
  yield takeLatest([
    actions.updateLocation().type,
  ], handleLocationChange)
}
