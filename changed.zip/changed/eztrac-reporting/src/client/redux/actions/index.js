import {
  activeReportConstants,
  appContainerConstants,
  confirmSaveModalConstants,
  costGroupsConstants,
  customTimeFrameModalConstants,
  deprecatedFilterAlertModalConstants,
  deprecatedFiltersConstants,
  downloadMenuConstants,
  editModalConstants,
  excludedFilterOptionsConstants,
  helpModalConstants,
  initiativeConstants,
  loadModalConstants,
  locationConstants,
  newReportModalConstants,
  preferencesConstants,
  refreshReportConstants,
  reportRowsConstants,
  reportModifiedConstants,
  saveModalConstants,
  selectedFieldsConstants,
  selectedFiltersConstants,
  selectedGroupingConstants,
  sortingConstants,
  spendingTreesConstants,
  statusTypesConstants,
  storedDataConstants,
  tabsConstants,
  timeFramesConstants,
} from '../constants'
import makeActions from '@monsantoit/redux-make-actions'

export const initiativesActions = makeActions(initiativeConstants)
export const timeFramesActions = makeActions(timeFramesConstants)
export const tabsActions = makeActions(tabsConstants)
export const appContainerActions = makeActions(appContainerConstants)
export const preferencesActions = makeActions(preferencesConstants)
export const selectedFiltersActions = makeActions(selectedFiltersConstants)
export const selectedGroupingActions = makeActions(selectedGroupingConstants)
export const statusTypesActions = makeActions(statusTypesConstants)
export const spendingTreesActions = makeActions(spendingTreesConstants)
export const selectedFieldsActions = makeActions(selectedFieldsConstants)
export const locationActions = makeActions(locationConstants)
export const saveModalActions = makeActions(saveModalConstants)
export const loadModalActions = makeActions(loadModalConstants)
export const editModalActions = makeActions(editModalConstants)
export const activeReportActions = makeActions(activeReportConstants)
export const customTimeFrameModalActions = makeActions(customTimeFrameModalConstants)
export const confirmSaveModalActions = makeActions(confirmSaveModalConstants)
export const newReportModalActions = makeActions(newReportModalConstants)
export const reportModifiedActions = makeActions(reportModifiedConstants)
export const storedDataActions = makeActions(storedDataConstants)
export const helpModalActions = makeActions(helpModalConstants)
export const downloadMenuActions = makeActions(downloadMenuConstants)
export const sortingActions = makeActions(sortingConstants)
export const deprecatedFiltersActions = makeActions(deprecatedFiltersConstants)
export const deprecatedFilterAlertModalActions = makeActions(deprecatedFilterAlertModalConstants)
export const excludedFilterOptionsActions = makeActions(excludedFilterOptionsConstants)
export const costGroupsActions = makeActions(costGroupsConstants)
export const refreshReportActions = makeActions(refreshReportConstants)
export const reportRowsActions = makeActions(reportRowsConstants)

export default {
  ...initiativesActions,
  ...timeFramesActions,
  ...tabsActions,
  ...appContainerActions,
  ...preferencesActions,
  ...selectedFiltersActions,
  ...selectedGroupingActions,
  ...spendingTreesActions,
  ...statusTypesActions,
  ...selectedFieldsActions,
  ...locationActions,
  ...saveModalActions,
  ...loadModalActions,
  ...editModalActions,
  ...activeReportActions,
  ...customTimeFrameModalActions,
  ...confirmSaveModalActions,
  ...newReportModalActions,
  ...reportModifiedActions,
  ...storedDataActions,
  ...helpModalActions,
  ...downloadMenuActions,
  ...sortingActions,
  ...deprecatedFiltersActions,
  ...deprecatedFilterAlertModalActions,
  ...excludedFilterOptionsActions,
  ...costGroupsActions,
  ...refreshReportActions,
  ...reportRowsActions,
}
