const namespace = 'reportRows'

export const FETCH_REPORT_ROWS = `${namespace}/FETCH_REPORT_ROWS`
export const SET_REPORT_ROWS_DATA = `${namespace}/SET_REPORT_ROWS_DATA`
export const SET_REPORT_ROWS_PAGINATION = `${namespace}/SET_REPORT_ROWS_PAGINATION`
export const SET_REPORT_ROWS_TOTAL_SPEND = `${namespace}/SET_REPORT_ROWS_TOTAL_SPEND`
