import {
  SET_SPENDING_TREES_DATA,
  SET_SPENDING_TREES_PAGE_DATA,
  SET_SPENDING_TREES_PAGINATION,
} from '../constants/spendingTreesConstants'

const reducer = (state = [], action = {}) => {
  switch ( action.type ) {
    case SET_SPENDING_TREES_DATA: return action.payload
    default: return state
  }
}

export const pageData = (state = [], action = {}) => {
  switch ( action.type ) {
    case SET_SPENDING_TREES_PAGE_DATA: return action.payload
    default: return state
  }
}

export const pagination = (state = { page: 1, pageSize: 10, totalCount: 0, totalPages: 0 }, action = {}) => {
  switch ( action.type ) {
    case SET_SPENDING_TREES_PAGINATION: return action.payload
    default: return state
  }
}

export default reducer
