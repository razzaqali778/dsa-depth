import { combineReducers } from 'redux'
import activeReport from './activeReportsReducer'
import appContainer from './appContainerReducer'
import confirmSaveModal from './confirmSaveModalReducer'
import costGroups from './costGroupsReducer'
import deprecatedFilterAlertModal from './deprecatedFilterAlertModalReducer'
import deprecatedFilters from './deprecatedFiltersReducer'
import downloadMenu from './downloadMenuReducer'
import editModal from './editModalReducer'
import excludedFilterOptions from './excludedFilterOptionsReducer'
import helpModal from './helpModalReducer'
import initiatives from './initiativesReducer'
import loadModal from './loadModalReducer'
import location from './locationReducer'
import newReportModal from './newReportModalReducer'
import preferences from './preferencesReducer'
import reportRows from './reportRowsReducer'
import reportModified from './reportModifiedReducer'
import saveModal from './saveModalReducer'
import selectedFields from './selectedFieldsReducer'
import selectedFilters from './selectedFiltersReducer'
import selectedGrouping from './selectedGroupingReducer'
import sorting from './sortingReducer'
import spendingTrees, {
  pageData as spendingTreesPage,
  pagination as spendingTreesPagination,
} from './spendingTreesReducer'
import tabs from './tabsReducer'
import timeFrames from './timeFramesReducer'

export default combineReducers({
  initiatives,
  timeFrames,
  tabs,
  appContainer,
  selectedFilters,
  selectedGrouping,
  spendingTrees,
  spendingTreesPage,
  spendingTreesPagination,
  selectedFields,
  location,
  preferences,
  reportRows,
  reportModified,
  activeReport,
  saveModal,
  loadModal,
  editModal,
  helpModal,
  confirmSaveModal,
  newReportModal,
  downloadMenu,
  sorting,
  deprecatedFilters,
  deprecatedFilterAlertModal,
  excludedFilterOptions,
  costGroups,
})
