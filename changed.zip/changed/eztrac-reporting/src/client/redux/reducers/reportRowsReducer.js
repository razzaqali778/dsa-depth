import {
  SET_REPORT_ROWS_DATA,
  SET_REPORT_ROWS_PAGINATION,
  SET_REPORT_ROWS_TOTAL_SPEND,
} from '../constants/reportRowsConstants'

const defaultPagination = { page: 1, pageSize: 10, totalCount: 0, totalPages: 0 }

const reducer = (state = {
  data: [],
  pagination: defaultPagination,
  totalSpend: 0,
}, action = {}) => {
  switch ( action.type ) {
    case SET_REPORT_ROWS_DATA:
      return { ...state, data: action.payload }
    case SET_REPORT_ROWS_PAGINATION:
      return { ...state, pagination: action.payload || defaultPagination }
    case SET_REPORT_ROWS_TOTAL_SPEND:
      return { ...state, totalSpend: action.payload || 0 }
    default:
      return state
  }
}

export default reducer
