import '../../styles/components/cardsContainer.css'
import { Button, Card, CardContent, Grid, MenuItem, Select, Typography } from '@material-ui/core'
import { connect } from 'react-redux'
import { formatExpenditure } from '../../redux/selectors'
import { initiativesActions, spendingTreesActions } from '../../redux/actions'
import React from 'react'
import countInitiativeChildren from '../../utils/countInitiativeChildren'
import getIsFilteredToNothing from '../../redux/selectors/getIsFilteredToNothing'
import { sortInitiatives } from '../../redux/selectors/getSortedFilteredInitiatives'
import map from 'lodash/map'
import sortBy from 'lodash/sortBy'

const ROWS_PER_PAGE_OPTIONS = [ 10, 25, 50, 100 ]

const expenditureDisplay = ({ filteredInitiativeExpenditure: filtered, totalExpenditure: total }) =>
  filtered && filtered !== total
    ? `${formatExpenditure(filtered)} (of ${formatExpenditure(total)})`
    : `${formatExpenditure(total)}`

const SpendingTreeCounts = ({ count }) => count > 0
  ? <Typography className="number-of-trees">Initiatives Found: { count }</Typography>
  : null


const DisplayTags = ({ tagNames, tags }) => {
  if ( tags && tags.length > 1 ) {
    const sortedTags = sortBy(tags, 'tagId')

    return sortedTags.map(({ tagId, tagValue }) => (
      <Typography key={tagId}>
        <b>{`${tagNames[tagId]}:`}</b> {`${tagValue}`}
      </Typography>
    ))
  }

  return (
    <Typography>
      No Tags Available
    </Typography>
  )
}

const CardComponent = ({
  spendingTree: { directExpenditure, totalExpenditure,
    filteredInitiativeExpenditure, initiative, children,
  },
  isParent,
  isClickable,
  setSelectedInitiative,
  tagNames,
  cardSize,
}) => (
  <Grid item key={`${initiative.name}${directExpenditure}`} sm={cardSize}>
    <Card className={`card ${isParent ? '' : 'child-card'}`}>
      <CardContent className="card-content">
        <Typography
          className={`card-header ${isClickable ? 'clickable' : ''}`}
          onClick={isClickable ? () => setSelectedInitiative(initiative.id) : () => null}
        >
          <strong>{initiative.name}</strong>
        </Typography>
        <Typography className="card-item">
          <b>Total Expenditure:</b> {expenditureDisplay({ totalExpenditure, filteredInitiativeExpenditure })}
        </Typography>
        <Typography className="card-item">
          <b>Sub-Initiatives:</b> {countInitiativeChildren({ children })}
        </Typography>
        <Typography className="card-item">
          <b>Status:</b> <span className={initiative.status.toLowerCase()}>{initiative.status}</span>
        </Typography>
        {initiative.financeCodeValue ? (<Typography className="card-item">
          <b>Finance Code:</b> <span>{initiative.financeCodeValue}</span>
        </Typography>) : null}
        <DisplayTags tagNames={tagNames} tags={initiative.tags} />
      </CardContent>
    </Card>
  </Grid>
)

class ReportingContainer extends React.Component {
  constructor(props) {
    super(props)
    this.handleChangeRowsPerPage = this.handleChangeRowsPerPage.bind(this)
  }

  handlePreviousPage() {
    const { fetchSpendingTreesPageData, pagination } = this.props
    fetchSpendingTreesPageData({ ...pagination, page: Math.max(pagination.page - 1, 1) })
  }

  handleNextPage() {
    const { fetchSpendingTreesPageData, pagination } = this.props
    const lastPage = Math.max(pagination.totalPages, 1)
    fetchSpendingTreesPageData({ ...pagination, page: Math.min(pagination.page + 1, lastPage) })
  }

  handleChangeRowsPerPage(event) {
    const { fetchSpendingTreesPageData, pagination } = this.props
    fetchSpendingTreesPageData({
      ...pagination,
      page: 1,
      pageSize: parseInt(event.target.value, 10),
    })
  }

  renderPagination() {
    const { pagination } = this.props
    const { page, pageSize, totalCount, totalPages } = pagination
    const safeTotalPages = Math.max(totalPages, 1)
    const firstItem = totalCount === 0 ? 0 : ((page - 1) * pageSize) + 1
    const lastItem = Math.min(page * pageSize, totalCount)
    const isFirstPage = page <= 1
    const isLastPage = page >= safeTotalPages

    return totalCount > 0
      ? <div className="initiative-pagination-toolbar">
        <Typography className="initiative-pagination-label">
          {`Showing ${firstItem}-${lastItem} of ${totalCount} | Page ${page} of ${safeTotalPages}`}
        </Typography>
        <Typography className="initiative-pagination-label">Rows per page</Typography>
        <Select
          className="initiative-pagination-select"
          onChange={this.handleChangeRowsPerPage}
          value={pageSize}
        >
          {ROWS_PER_PAGE_OPTIONS.map(option => (
            <MenuItem key={option} value={option}>{option}</MenuItem>
          ))}
        </Select>
        <Button
          color="primary"
          disabled={isFirstPage}
          onClick={() => this.handlePreviousPage()}
          variant="contained"
        >
          Previous
        </Button>
        <Button
          color="primary"
          disabled={isLastPage}
          onClick={() => this.handleNextPage()}
          variant="contained"
        >
          Next
        </Button>
      </div>
      : null
  }

  renderParentCard(parent) {
    const { filtersExpanded, setSelectedInitiative, tagNames } = this.props

    return (
    <Grid className="parent-container" container>
      <CardComponent
        cardSize={filtersExpanded ? 4 : 3}
        isParent
        setSelectedInitiative={setSelectedInitiative}
        spendingTree={parent}
        tagNames={tagNames}
      />
    </Grid>
    )
  }

  renderCardList() {
    const { spendingTrees, isFilteredToNothing, filtersExpanded, setSelectedInitiative, tagNames } = this.props
    const InitiativeCards = ({ cardInitiatives, isParent }) => map(cardInitiatives, i => (
      <CardComponent
        cardSize={filtersExpanded ? 4 : 3}
        isClickable
        isParent={isParent}
        key={`init-card-${i.initiative.name}`}
        setSelectedInitiative={setSelectedInitiative}
        spendingTree={i}
        tagNames={tagNames}
      />),
    )
    if ( isFilteredToNothing ) {
      return <Grid item sm={4}><p>No Matches Against Current Filters</p></Grid>
    } else if ( spendingTrees && spendingTrees.length > 1 ) {
      return <InitiativeCards cardInitiatives={spendingTrees} isParent />
    } else if ( spendingTrees && spendingTrees.length === 1 ) {
      const children = spendingTrees[0].children || []

      return [
        <React.Fragment key="init-card-parent">{this.renderParentCard(spendingTrees[0])}</React.Fragment>,
        <Grid className="parent-container" container key="child-separator" >
          <h3 className="no-span">Child Initiatives</h3>
        </Grid>,
        <InitiativeCards cardInitiatives={children} isParent={false} key="init-card-children" />,
      ]
    }

    return <div />
  }

  getPaginationCount() {
    const { spendingTrees } = this.props

    if ( !spendingTrees ) { return 0 }
    if ( spendingTrees.length === 1 ) { return (spendingTrees[0].children || []).length }

    return spendingTrees.length
  }

  render() {
    const { pagination } = this.props

    return (
    <div>
      <SpendingTreeCounts count={pagination.totalCount} />
      {this.renderPagination()}
      <Grid className="cards-container" container spacing={24}>
        {this.renderCardList()}
      </Grid>
    </div>

    )
  }
}

const mapStateToProps = state => ({
  spendingTrees: sortInitiatives(state.spendingTreesPage),
  isFilteredToNothing: getIsFilteredToNothing(state),
  tagNames: state.initiatives.tagNames,
  filtersExpanded: state.tabs.filtersExpanded,
  pagination: state.spendingTreesPagination,
})

export default connect(
  mapStateToProps, { ...initiativesActions, ...spendingTreesActions },
)(ReportingContainer)
