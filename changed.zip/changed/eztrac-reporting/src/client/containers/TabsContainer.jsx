import '../styles/components/tabsContainer.css'
import { AppBar, Fab, Tab, Tabs, Typography } from '@material-ui/core'
import { Info } from '@material-ui/icons'
import {
  appContainerActions,
  helpModalActions,
  tabsActions,
} from '../redux/actions'
import { connect } from 'react-redux'
import { createSink } from 'recompose'
import CardsContainer from './InitiativeContainerTabs/CardsContainer'
import DataTable from '../components/DataTable/DataTable'
import PropTypes from 'prop-types'
import React from 'react'
import TrendTable from '../components/TrendTable/TrendTable'

let update

const Sink = createSink(() => {
  setTimeout(() => {
    update()
  }, 200)
})

const ReportingInitiativeContainer = ({
  tabs,
  setTab,
  filtersExpanded,
  shouldShow,
  openHelpModal,
}) => {
  const TabContainer = content => (
    <Typography className="tabs-content" component="div" >
      {content.content}
    </Typography>
  )

  const tabLabel = label => (
    <div className="tab-label" >
      {label}
    </div>
  )

  if ( !shouldShow ) {
    return null
  }

  const buttonStyle = {
    icon: {
      fontSize: '30px',
    },
    position: 'fixed',
    bottom: '1%',
    right: '1.2%',
  }

  return (
    <div className="tabs-container">
      <Sink props={{ filtersExpanded }} />
      <AppBar color="default" position="static">
        <Tabs
          action={actions => { update = actions.updateIndicator }}
          centered
          indicatorColor="primary"
          onChange={(event, value) => setTab(value)}
          textColor="primary"
          value={tabs}
          variant="fullWidth"
        >
          <Tab label={tabLabel('Results')} />
          <Tab label={tabLabel('Trend')} />
          <Tab label={tabLabel('Initiative List')} />
        </Tabs>
      </AppBar>
      {tabs === 0 && <TabContainer content={
        <div>
          <Fab aria-label="Help" color="primary" onClick={() => openHelpModal()} style={buttonStyle} >
            <Info style={buttonStyle.icon} />
          </Fab>
          <DataTable />
        </div>
      }
      />}
      {tabs === 1 && <TabContainer content={
        <div>
          <TrendTable />
        </div>
      }
      />}
      {tabs === 2 && <TabContainer content={<CardsContainer />} /> }
    </div>
  )
}

ReportingInitiativeContainer.propTypes = {
  setTab: PropTypes.func,
  tabs: PropTypes.number,
}

const mapStateToProps = state => ({
  tabs: state.tabs.tabs,
  filtersExpanded: state.tabs.filtersExpanded,
  shouldShow: (state.reportRows && state.reportRows.data && state.reportRows.data.length)
    || (state.spendingTreesPage && state.spendingTreesPage.length)
    || (state.spendingTrees && state.spendingTrees.length),
})

export default connect(
  mapStateToProps, {
    ...appContainerActions,
    ...tabsActions,
    ...helpModalActions,
  })(ReportingInitiativeContainer)
