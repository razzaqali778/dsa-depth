import '../../styles/components/dataTable.css'
import {
  DragDropProvider,
  Grid,
  PagingPanel,
  Table,
  VirtualTable,
} from '@devexpress/dx-react-grid-material-ui'
import { Paper, Tooltip } from '@material-ui/core'
import { connect } from 'react-redux'
import { getAllFieldOptions } from '../../redux/selectors/getFieldOptions'
import ColumnVisibility from './ColumnVisibility'
import Controller from './Controller'
import Formatter from './Formatter'
import React from 'react'
import Renderer from './Renderer'
import Summary from './SummaryPlugin'
import includes from 'lodash/includes'

const Row = restProps => <Table.Row {...restProps} className="tableStriped" />
const RootComponent = restProps => <Grid.Root {...restProps} className="table-component" />
const ContainerComponent = restProps =>
  <VirtualTable.Container {...restProps} className="table-container" style={{ zIndex: 0 }} />

const Cell = restProps => {
  const toolTipText = includes(
    [ 'engagementName', 'purchaseOrderName', 'effortComment', 'personName' ],
    restProps.column.name,
  )
    ? 'N/A'
    : 'Unassigned'

  return (
    <Tooltip
      placement="bottom"
      title={restProps.value ? restProps.value : toolTipText}
    >
      <Table.Cell {...restProps} className="table-cell" />
    </Tooltip>)
}
const DataTable = ({
  reportRows,
  allFieldOptions,
}) => (<div id="table-wrapper">
  <Paper>
    <Grid
      columns={allFieldOptions}
      rootComponent={RootComponent}
      rows={reportRows}
    >
      <Formatter />
      <Controller />
      <DragDropProvider />
      <VirtualTable
        cellComponent={Cell}
        columnExtensions={[{ columnName: 'spend', align: 'right' }]}
        containerComponent={ContainerComponent}
        rowComponent={Row}
      />
      <Renderer />
      <ColumnVisibility />
      <Summary />
      <PagingPanel pageSizes={[ 10, 25, 50, 100 ]} />
    </Grid>
  </Paper>
</div>)

const mapStateToProps = state => ({
  allFieldOptions: getAllFieldOptions(),
  reportRows: state.reportRows.data,
})

const addConnect = connect(mapStateToProps)

export default addConnect(DataTable)
