import '../../styles/components/dataTable.css'
import {
  GroupingState,
  CustomPaging,
  IntegratedGrouping,
  IntegratedSorting,
  PagingState,
  SortingState,
} from '@devexpress/dx-react-grid'
import {
  Plugin,
} from '@devexpress/dx-react-core'

import { connect } from 'react-redux'
import { getSelectedFields, getSelectedGrouping, getSorting } from '../../redux/selectors'
import {
  reportRowsActions,
  selectedFieldsActions,
  selectedGroupingActions,
  sortingActions,
} from '../../redux/actions'
import React from 'react'
import filter from 'lodash/filter'
import find from 'lodash/find'
import includes from 'lodash/includes'
import map from 'lodash/map'
import parseInt from 'lodash/parseInt'

const onGroupingChange = (setSelectedGrouping, setSelectedFields, grouping, selectedFields) => {
  setSelectedGrouping(grouping)
  const groupingFieldOrder = map(grouping, ({ columnName }) => find(selectedFields, field => field.name === columnName))
  const newSelectedFieldOrder = filter(selectedFields, field => !includes(groupingFieldOrder, field) )
  setSelectedFields([ ...groupingFieldOrder, ...newSelectedFieldOrder ])
}

const isNum = value => /^\d+$/.test(value)

const comparePriority = (a, b) => {
  const monthRegex = /^[a-zA-Z]+\s[0-9]{4}/
  if ( a === b ) {
    return 0
  }
  if ( a === undefined ) {
    return 1
  }
  if ( b === undefined ) {
    return -1
  }
  if ( monthRegex.test(a) ) {
    return new Date(a) < new Date(b) ? -1 : 1
  }
  if ( isNum(a) && isNum(b) ) {
    return parseInt(a) < parseInt(b) ? -1 : 1
  }

  return a < b ? -1 : 1
}
const unrequiredColumns = [
  'businessUnit',
  'costGroupName',
  'portfolioCode',
  'activityId',
  'region',
  'financeCode',
  'timeFrameStartDate',
  'programCode',
]
const integratedSortingColumnExtensions = map(unrequiredColumns, column => ({
  columnName: column,
  compare: comparePriority,
}))

const Controller = ({
  fetchReportRows,
  grouping,
  pagination,
  setSelectedGrouping,
  setSelectedFields,
  setSorting,
  selectedFields,
  sorting,
}) => (
  <Plugin>
    <PagingState
      currentPage={(pagination.page || 1) - 1}
      onCurrentPageChange={currentPage => fetchReportRows({
        page: currentPage + 1,
        pageSize: pagination.pageSize,
      })}
      onPageSizeChange={pageSize => fetchReportRows({
        page: 1,
        pageSize,
      })}
      pageSize={pagination.pageSize || 10}
    />
    <SortingState
      columnExtensions={[{ columnName: 'spend', sortingEnabled: false }]}
      onSortingChange={setSorting}
      sorting={sorting}
    />
    <GroupingState
      columnExtensions={[{ columnName: 'spend', groupingEnabled: false }]}
      grouping={grouping}
      onGroupingChange={change => onGroupingChange(setSelectedGrouping, setSelectedFields, change, selectedFields)}
    />
    <IntegratedSorting
      columnExtensions={integratedSortingColumnExtensions}
    />
    <IntegratedGrouping />
    <CustomPaging totalCount={pagination.totalCount || 0} />
  </Plugin>
)

const mapStateToProps = state => ({
  grouping: getSelectedGrouping(state),
  pagination: state.reportRows.pagination,
  selectedFields: getSelectedFields(state),
  sorting: getSorting(state),
})

const addConnect = connect( mapStateToProps,
  { ...reportRowsActions, ...selectedFieldsActions, ...selectedGroupingActions, ...sortingActions } )

export default addConnect(Controller)
