import agent from 'superagent';
import getToken from './getToken';

const authRequest = async (method: string, url: string, payload?: string | object) => {
  const token = await getToken();
  const request = agent(method, url)
    .set('Authorization', `Bearer ${token}`)
    .timeout({response: 30000, deadline: 60000});
  if (['POST', 'PUT', 'PATCH'].includes(method.toUpperCase())) request.send(payload);
  return request;
};

export default authRequest;
