import {entitlementAppName, entitlements} from '../../config/entitlementsConfig';

export const isAdmin = (userProfileHeader: string): boolean => {
  let profile;
  try {
    profile = JSON.parse(userProfileHeader);
  } catch {
    // A missing/malformed user-profile header should be treated as "not an admin",
    // not crash the request with an unhandled SyntaxError.
    return false;
  }
  const eztracEntitlements: string[] | undefined = profile?.entitlements?.[entitlementAppName];
  if (
    eztracEntitlements &&
    eztracEntitlements.some(e => entitlements.adminOnly.includes(e.toLowerCase()))
  )
    return true;
  return false;
};
