import {TeamId} from 'src/api/team/models';
import {TimeFrameId} from '../../api/timeframe/models';
import config from '../../config/index';
import authRequest from '../superagentWrapper';
import {CostGroupBreakdown, EffortCostingDetails} from 'src/api/costcalc/models';

const url = () => `${config.get('ez-trac-urls.ez-trac-costing')}`;

export interface PersonCostingData {
  costGroupName: string;
  isActive: boolean;
  isEmployee: boolean;
  personId: string;
  personName: string;
  rateName: string;
}

export interface CalendarHours {
  name: string;
  timeFrameId: TimeFrameId;
  employeeHours: number;
  contractorHours: number;
  calendarId: String;
}

export interface EffortCostingResult {
  teamId: TeamId;
  timeFrameId: TimeFrameId;
  teamMemberCosts: CostGroupBreakdown[];
}

interface CalendarHoursResponse extends Omit<CalendarHours, 'timeFrameId'> {
  timeFrameId: string | number | bigint;
}

interface EffortCostingResultResponse extends Omit<EffortCostingResult, 'timeFrameId'> {
  timeFrameId: string | number | bigint;
}

function batchArrayInGroups(array: EffortCostingDetails[], size: number) {
  const result = [];
  for (let i = 0; i < array.length; i += size) {
    result.push(array.slice(i, i + size));
  }
  return result;
}

export const batchCallCostingService = async (
  costingRequests: EffortCostingDetails[]
): Promise<EffortCostingResult[]> => {
  const chunks = batchArrayInGroups(costingRequests, 200);
  const results = await Promise.all(
    chunks.map(batch => eztracCostingClient.getEffortCostCalculation(batch))
  );

  return results.flat();
};

export const eztracCostingClient = {
  async getPersonCostingData(): Promise<PersonCostingData[]> {
    const {body} = await authRequest('GET', `${url()}/v1/people`);
    return body;
  },
  async getCalendarHours(): Promise<CalendarHours[]> {
    const {body} = await authRequest('GET', `${url()}/v1/calendars/hours`);
    return body.map((calendarHours: CalendarHoursResponse) => ({
      ...calendarHours,
      timeFrameId: BigInt(calendarHours.timeFrameId),
    }));
  },
  async getEffortCostCalculation(
    effortCostingDetails: EffortCostingDetails[]
  ): Promise<EffortCostingResult[]> {
    const {body} = await authRequest('POST', `${url()}/v1/cost-calc/effort`, effortCostingDetails);
    return body.map((details: EffortCostingResultResponse) => ({
      ...details,
      timeFrameId: BigInt(details.timeFrameId),
    }));
  },
};
