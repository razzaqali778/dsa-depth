import config from '../../config/index';
import authRequest from '../superagentWrapper';

const url = () => `${config.get('ez-trac-urls.ez-trac-vip')}`;

export interface Initiative {
  id: string;
  name: string;
  activityId?: string;
  financeCode?: string;
  status?: string;
  typeId: string;
  fundingInitiative?: Initiative;
  children?: Initiative[];
}

interface InitiativeDTO {
  initiative_id: string;
  initiative_name: string;
  activity_id: string;
  finance_code_value: string;
  status: string;
  type_id: string;
  children: InitiativeDTO[];
}

const convertToInitiative = (initiativeExtended: InitiativeDTO): Initiative => ({
  activityId: initiativeExtended.activity_id,
  id: initiativeExtended.initiative_id,
  name: initiativeExtended.initiative_name,
  financeCode: initiativeExtended.finance_code_value,
  typeId: initiativeExtended.type_id,
  status: initiativeExtended.status,
  fundingInitiative: undefined,
  // Leaf initiatives can come back from the VIP service with `children` missing/null rather than
  // an empty array; without this guard the whole hierarchy fetch (used by GET export and the
  // health check route) throws.
  children: (initiativeExtended.children ?? []).map((child: InitiativeDTO) =>
    convertToInitiative(child)
  ),
});

export const eztracVipClient = {
  async getInitiativeHierarchy(): Promise<Initiative[]> {
    const {body} = await authRequest('GET', `${url()}/v1/getInitiativeHierarchy`);
    return body.map((i: InitiativeDTO) => convertToInitiative(i));
  },
};
