import {papiClient} from '../../util/client/papiClient';
import {AppContext} from '../AppContext';
import {PersonId} from '../effort/models';
import {container} from 'tsyringe';

export const getOrCreatePeople = async (userIds: PersonId[]) => {
  const r = container.resolve(AppContext).repositories;

  const localPeopleIds = await r.personRepository.getExistingPersons(userIds);
  const localPeopleIdSet = new Set(localPeopleIds);
  const notLocalPeopleIds = userIds.filter(id => !localPeopleIdSet.has(id));
  // `.length >= 0` is always true, so this call to the external PAPI/GraphQL service used to run
  // on every request even when every person already exists locally (empty array). Only call out
  // when there is actually someone to look up.
  if (notLocalPeopleIds.length > 0) {
    const papiPeople = await papiClient.getUsersById(notLocalPeopleIds);
    const unknownPeopleIds = notLocalPeopleIds.filter(id => !papiPeople.find(p => p.id === id));
    await Promise.all([
      ...papiPeople.map(person => r.personRepository.createPerson(person.id, person.name)),
      ...unknownPeopleIds.map(personId => r.personRepository.createPerson(personId, personId)),
    ]);
  }
};
