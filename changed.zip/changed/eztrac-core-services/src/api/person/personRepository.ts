import {container} from 'tsyringe';
import {PersonId} from '../effort/models';
import {AppContext} from '../AppContext';

export interface PersonRepository {
  getExistingPersons(personIds: PersonId[]): Promise<PersonId[]>;
  createPerson(personId: PersonId, personName: string): Promise<null>;
}

export const personRepository: PersonRepository = {
  async getExistingPersons(personIds: PersonId[]): Promise<PersonId[]> {
    if (!personIds?.length) return [];
    const db = container.resolve(AppContext).db;

    const sql = `
      SELECT user_id from public.person
      WHERE  user_id in ($1:csv)
    `;

    return db
      .manyOrNone(sql, [personIds])
      .then(results => results.map((r: {user_id: PersonId}) => r.user_id));
  },

  createPerson(personId: PersonId, personName: string): Promise<null> {
    const db = container.resolve(AppContext).db;

    const sql = `
      INSERT INTO public.person (user_id, name)
      VALUES ($<personId>, $<personName>)
      ON CONFLICT (user_id) DO NOTHING
    `;

    return db.none(sql, {personId, personName});
  },
};
