import {PersonCostingData} from 'src/util/client/eztracCostingClient';
import {Initiative} from 'src/util/client/eztracVipClient';
import {User} from 'src/util/client/papiClient';
import {TeamId} from 'src/api/team/models';
import {TeamStructure} from '../team/models';
import {Workday} from '../timeframe/models';
import {PersonAllocation} from './models';
import {InitiativeId} from '../initiative/initiative';
import {EffortEntity, PersonId} from '../effort/models';

const notFoundValue = 'UNKNOWN';

interface ParticipantPerInitiativeHours {
  teamId: TeamId;
  initiativeId: InitiativeId;
  personId: PersonId;
  hours: number;
}

interface ParticipantHours {
  userId: string;
  hours: number;
}

interface InitiativeHours {
  initiativeId: InitiativeId;
  hours: number;
}

const notFoundUser = (userId: string): User => ({
  id: userId,
  name: userId,
  manager: {name: notFoundValue},
});

const notFoundInitiative = (initiativeId: InitiativeId): Initiative => ({
  id: initiativeId,
  name: initiativeId,
  typeId: notFoundValue,
});

const notFoundTeam = (teamId: TeamId): TeamStructure => ({
  teamId: teamId,
  teamName: teamId,
  communityId: notFoundValue,
  communityName: notFoundValue,
  platformId: notFoundValue,
  platformName: notFoundValue,
  orgId: notFoundValue,
  orgName: notFoundValue,
  isActive: true,
});

const notFoundPersonCostingData = (personId: string): PersonCostingData => ({
  personId: personId,
  personName: personId,
  costGroupName: notFoundValue,
  rateName: notFoundValue,
  isEmployee: false,
  isActive: true,
});

function generateParticipantPerInitiativeHours(
  participantHours: ParticipantHours[],
  initiativeHours: InitiativeHours[],
  teamId: TeamId
) {
  const personAllocations = [];
  while (participantHours.length !== 0 && initiativeHours.length !== 0) {
    const pHours = participantHours[0];
    const aHours = initiativeHours[0];
    let allocatedHours = 0;
    if (pHours.hours > aHours.hours) {
      allocatedHours = aHours.hours;
      pHours.hours -= aHours.hours;
      initiativeHours.shift();
    } else if (pHours.hours < aHours.hours) {
      allocatedHours = pHours.hours;
      aHours.hours -= pHours.hours;
      participantHours.shift();
    } else {
      allocatedHours = pHours.hours;
      participantHours.shift();
      initiativeHours.shift();
    }
    personAllocations.push({
      teamId: teamId,
      initiativeId: aHours.initiativeId,
      personId: pHours.userId,
      hours: roundToDecimal(allocatedHours),
    });
  }
  return personAllocations;
}

function mapPersonToInitiative(
  efforts: EffortEntity[],
  workdays: Workday[]
): ParticipantPerInitiativeHours[] {
  const hoursInMonth = workdays.reduce((sum, current) => sum + current.hours, 0);
  const personAllocationHours: ParticipantPerInitiativeHours[] = [];
  efforts.forEach(effort => {
    const effortAllocations = effort.allocations ?? [];
    const effortMembers = effort.members ?? [];
    const allocatedPercent =
      effortAllocations.reduce((sum, current) => sum + Number(current.percentageOfTeamCost), 0) /
      100;
    const totalHours =
      (effortMembers.reduce((sum, current) => sum + Number(current.percent), 0) * hoursInMonth) /
      100;
    const participantHours = effortMembers.map(member => ({
      userId: member.userId,
      hours: (Number(member.percent) * allocatedPercent * hoursInMonth) / 100,
    }));
    const initiativeHours = effortAllocations.map(allocation => ({
      initiativeId: allocation.initiativeId,
      hours: (Number(allocation.percentageOfTeamCost) * totalHours) / 100,
    }));
    const personPerInitiativeHours = generateParticipantPerInitiativeHours(
      participantHours,
      initiativeHours,
      effort.teamId
    );
    personAllocationHours.push(...personPerInitiativeHours);
  });
  return personAllocationHours;
}

export function roundToDecimal(numberToRound: number, decimalDigits = 1): number {
  const factor = 10 ** decimalDigits;
  return Math.round(numberToRound * factor) / factor;
}

export function getPersonAllocations(
  efforts: EffortEntity[],
  workdays: Workday[],
  people: User[],
  initiativeMap: Map<string, Initiative>,
  teams: TeamStructure[],
  costingData: PersonCostingData[]
): PersonAllocation[] {
  const personPerInitiativeHoursList = mapPersonToInitiative(efforts, workdays);
  const personAllocations = personPerInitiativeHoursList.map(item => ({
    hours: item.hours,
    person: people.find(p => p.id === item.personId) ?? notFoundUser(item.personId),
    initiative: initiativeMap.get(item.initiativeId) ?? notFoundInitiative(item.initiativeId),
    team: teams.find(t => t.teamId === item.teamId) ?? notFoundTeam(item.teamId),
    costingData:
      costingData.find(d => d.personId === item.personId) ??
      notFoundPersonCostingData(item.personId),
  }));
  return personAllocations;
}
