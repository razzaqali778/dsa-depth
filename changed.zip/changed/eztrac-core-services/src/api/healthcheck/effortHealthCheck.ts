import {EffortEntity} from '../effort/models';
import {AllocationPct} from '../initiative/initiative';
import {TimeFrame} from '../timeframe/models';
import {HealthCheck} from './models';
import {eztracVipClient, Initiative} from '../../util/client/eztracVipClient';
import {transformAndFlatten} from '../GETExport/initiativeTransformation';
import {TeamStructure} from '../team/models';
import moment from 'moment';

export async function checkEffortsInternal(
  timeFrame: TimeFrame,
  teams: TeamStructure[],
  initiatives: Map<string, Initiative>,
  efforts: EffortEntity[]
): Promise<HealthCheck[]> {
  const result: HealthCheck[] = [];

  efforts.flatMap(effort => {
    const errors = checkEffortForErrors(timeFrame, initiatives, effort);
    if (errors.length) {
      const team = teams.find(team => team.teamId === effort.teamId);
      // An effort whose team isn't in the current team list (e.g. deactivated/removed
      // after the effort row was created) has no team metadata to report - skip it
      // rather than crashing the whole health check on a `team!.teamName` access.
      if (!team) {
        return;
      }
      const healthCheckWithErrors: HealthCheck = {
        timeFrameName: timeFrame.name,
        teamName: team.teamName,
        teamId: effort.teamId,
        communityName: team.communityName,
        platformName: team.platformName,
        errors: errors,
      };
      result.push(healthCheckWithErrors);
    }
  });
  return result;
}

export const checkEffortForErrors = (
  timeFrame: TimeFrame,
  initMap: Map<string, Initiative>,
  effort: EffortEntity
): String[] => {
  let errors: String[] = [];
  errors.push(effortEmpty(effort));
  errors.push(noCostEffort(effort));
  errors.push(allocationsNot100(effort));
  errors.push(hasForecastPeople(timeFrame, effort));
  errors = errors.concat(initiativesCompleted(initMap, effort));
  errors = errors.concat(initiativesPlanning(initMap, timeFrame, effort));
  return errors.filter(err => err !== '');
};

const effortEmpty = (effort: EffortEntity): String => {
  if (
    (effort.allocations === undefined || !effort.allocations?.length) &&
    (effort.members === undefined || !effort.members?.length) &&
    (effort.forecastPeople === undefined || !effort.forecastPeople?.length) &&
    (effort.engagements === undefined || !effort.engagements?.length)
  ) {
    return emptyEffortError;
  } else return '';
};

const noCostEffort = (effort: EffortEntity): String => {
  const nonZeroMembers = effort.members?.filter(member => member.percent > 0);
  if (
    effort.allocations !== undefined &&
    effort.allocations.length &&
    (nonZeroMembers === undefined || !nonZeroMembers?.length) &&
    (effort.forecastPeople === undefined || !effort.forecastPeople?.length) &&
    (effort.engagements === undefined || !effort.engagements?.length)
  ) {
    return noCostsError;
  } else return '';
};

const hasForecastPeople = (timeFrame: TimeFrame, effort: EffortEntity): String => {
  if (effort.forecastPeople?.length && !isFutureTimeFrame(timeFrame)) return forecastPeopleError;
  else return '';
};

const allocationsNot100 = (effort: EffortEntity): String => {
  const effortAllocations = effort.allocations ?? [];
  const sum = effortAllocations.reduce(
    (sum, current) => sum + BigInt(current.percentageOfTeamCost),
    0n
  );

  if (sum !== 100n && effortEmpty(effort) === '') return allocationsNot100Error(sum);
  else return '';
};

const initiativesCompleted = (initMap: Map<string, Initiative>, effort: EffortEntity): String[] => {
  const completedInits: Initiative[] = allocatedInits(initMap, effort).filter(
    ai => ai.status === 'Completed'
  );
  const result: String[] = [];
  for (const ci of completedInits) {
    result.push(initiativeCompletedError(ci));
  }
  return result;
};

const initiativesPlanning = (
  initMap: Map<string, Initiative>,
  timeFrame: TimeFrame,
  effort: EffortEntity
): String[] => {
  if (isFutureTimeFrame(timeFrame)) {
    return [''];
  } else {
    const planningInits = allocatedInits(initMap, effort).filter(ai => ai.status === 'Planning');
    const result: String[] = [];
    for (const pi of planningInits) {
      result.push(initiativeInPlanningError(pi));
    }
    return result;
  }
};

const allocatedInits = (
  initiativesMap: Map<string, Initiative>,
  effort: EffortEntity
): Initiative[] => {
  const allocatedInitiatives: Initiative[] = [];
  effort.allocations?.filter(ea => {
    const initiative = initiativesMap.get(ea.initiativeId);
    if (initiative !== undefined) {
      allocatedInitiatives.push(initiative);
    }
  });
  return allocatedInitiatives;
};

const isFutureTimeFrame = (timeFrame: TimeFrame): Boolean => {
  const now = moment();
  const startDate = moment(timeFrame.startDate);
  return startDate.isAfter(now);
};

export async function generateAllInitiatives() {
  const initiatives = await eztracVipClient
    .getInitiativeHierarchy()
    .then(initiatives => transformAndFlatten(initiatives));
  return initiatives;
}

export const emptyEffortError: String =
  'Effort has no allocations, team members, or engagements. Should this team be deactivated?';

export const noCostsError: String =
  'Effort has allocations but no costs, team members or engagements';

export const forecastPeopleError: String =
  'Effort still has forecast people assigned to it during the current month';

export const allocationsNot100Error = (totalAllocation: AllocationPct): String => {
  return `Allocation percentages only add up to ${totalAllocation}%`;
};

export const initiativeCompletedError = (init: Initiative): String => {
  return `Initiative ${init.name} is allocated but is marked as complete`;
};

export const initiativeInPlanningError = (init: Initiative): String => {
  return `Initiative ${init.name} is allocated in the current month but is marked as in planning`;
};
