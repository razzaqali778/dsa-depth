import {TimeframeRepository} from './timeframe/timeFrameRepository';
import {EffortRepository} from './effort/effortRepository';
import {TeamRepository} from './team/teamRepository';
import {EffortAllocationsRepository} from './effort/allocation/effortAllocationsRepository';
import {EffortEngagementsRepository} from './effort/engagement/effortEngagementsRepository';
import {EffortMembersRepository} from './effort/members/effortMembersRepository';
import {PersonRepository} from './person/personRepository';
import {PlatformRepository} from './platform/platformRepository';
import {CommunityRepository} from './community/communityRepository';
import {OrgRepository} from './org/orgRepository';
import {SpendRepository} from './spend/spendRepository';

export type AppRepositories = {
  timeFrameRepository: TimeframeRepository;
  effortRepository: EffortRepository;
  teamRepository: TeamRepository;
  effortAllocationsRepository: EffortAllocationsRepository;
  effortEngagementsRepository: EffortEngagementsRepository;
  effortMembersRepository: EffortMembersRepository;
  personRepository: PersonRepository;
  platformRepository: PlatformRepository;
  communityRepository: CommunityRepository;
  orgRepository: OrgRepository;
  spendRepository: SpendRepository;
};
