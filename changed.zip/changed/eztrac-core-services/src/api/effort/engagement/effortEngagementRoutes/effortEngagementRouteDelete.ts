import {Response, Router} from 'express';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {SwaggerDoc} from '../../../../util/swaggerTypes';
import {DeleteEffortEngagement, schema} from '../validationSchema';
import {apiResponse} from '../../../../middleware/apiResponse';
import {deleteEffortEngagements} from '../effortEngagementService';
import {entitlements} from '../../../../config/entitlementsConfig';
import {getEffortsByIds} from '../../effortService';
import {isAdmin} from '../../../../util/security/isAdmin';
const profileMiddleware = require('@monsantoit/profile-middleware');

const validator = createValidator();
const tags = ['efforts-engagements'];

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.effortWrite,
  methods: ['delete'],
});

const effortEngagementDeleteActions = ({router, doc}: {router: Router; doc: SwaggerDoc}) => {
  doc['/efforts/engagements/team/:teamId/timeFrame/:timeFrameId/engagement/:engagementId'] = {
    delete: {
      tags,
      operationId: 'deleteEffortEngagement',
      summary: 'delete effort engagement matching team and timeframe',
      parameters: [
        {
          name: 'teamId',
          in: 'path',
          description: 'engagement team ID',
          required: true,
          type: 'string',
        },
        {
          name: 'timeFrameId',
          in: 'path',
          description: 'engagement time frame ID',
          required: true,
          type: 'number',
        },
        {
          name: 'engagementId',
          in: 'path',
          description: 'engagement ID',
          required: true,
          type: 'number',
        },
      ],

      responses: {
        200: {description: 'Engagement by given ids has been removed'},
        400: {description: 'Bad request'},
        404: {
          description: 'Egagement with provided id not found for given team and timeframe',
        },
      },
    },
  };

  router.delete(
    '/efforts/engagements/team/:teamId/timeFrame/:timeFrameId/engagement/:engagementId',
    entitlementMiddleware,
    validator.params(schema.engagementQueryParams),
    apiResponse(async (req: ValidatedRequest<DeleteEffortEngagement>, res: Response) => {
      const {teamId, timeFrameId, engagementId} = req.params;
      const affectedEffortIds = await deleteEffortEngagements(
        teamId,
        timeFrameId,
        engagementId,
        isAdmin(req.headers['user-profile'])
      );
      const efforts = await getEffortsByIds(affectedEffortIds);
      const cost = efforts.reduce((sum, current) => sum + Number(current.cost), 0);
      res.send({cost});
    })
  );

  return {router, doc};
};

export default effortEngagementDeleteActions;
