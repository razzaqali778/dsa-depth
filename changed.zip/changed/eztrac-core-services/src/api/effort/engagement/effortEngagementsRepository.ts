import {container} from 'tsyringe';
import {AppContext} from '../../AppContext';
import {TeamId} from '../../team/models';
import {TimeFrameId} from '../../timeframe/models';
import {EffortEngagement, EngagementCost, EngagementId} from './models';
import {EngagementCalcConverter} from './engagementCalcConverter';
import {EffortId} from '../models';
import {isEmpty} from 'lodash';

export const teamEffortQuery = `SELECT
team_cost_engagement.amount,
team_cost_engagement.comment,
team_cost_engagement.engagement_id    as "engagementId",
team_cost_engagement.amount_details   as "amountDetails",
team_id                               as "teamId",
team_cost.timeframe_id                as "timeFrameId",
team_cost.team_cost_id                as "effortId"
FROM public.team_cost_engagement      as team_cost_engagement
  join
public.team_cost as team_cost
ON team_cost_engagement.team_cost_id = team_cost.team_cost_id
  `;

export const timeframesInRangeQuery = `JOIN public.timeframe as startTimeFrame
  ON startTimeFrame.timeframe_id = $<startTimeFrame>
JOIN public.timeframe as endTimeFrame
  ON endTimeFrame.timeframe_id = $<endTimeFrame>
JOIN public.timeframe as timeframe
  ON timeframe.timeframe_start_date >= startTimeFrame.timeframe_start_date
    AND timeframe.timeframe_end_date <= endTimeFrame.timeframe_end_date
    AND timeframe.timeframe_id = team_cost.timeframe_id`;

interface EffortEngagementDbModel {
  effortId: EffortId;
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  amount: EngagementCost;
  engagementId: EngagementId;
  amountDetails?: string;
  comment?: string;
}

const convertEngagementDetails = (engagements: EffortEngagementDbModel[]): EffortEngagement[] =>
  engagements.map(e =>
    !isEmpty(e.amountDetails)
      ? {
          ...e,
          amountDetails: EngagementCalcConverter.convertToObject(e.amountDetails),
        }
      : (e as EffortEngagement)
  );

export interface EffortEngagementsRepository {
  getEffortEngagementsByTimeFrames(
    startTimeFrameId: TimeFrameId,
    endTimeFrameId: TimeFrameId
  ): Promise<EffortEngagement[]>;
  getEffortEngagementsByTeam(teamId: TeamId): Promise<EffortEngagement[]>;
  getEffortEngagementsByTeamAndTimeframes(
    teamId: TeamId,
    startTimeFrame: TimeFrameId,
    endTimeFrame: TimeFrameId
  ): Promise<EffortEngagement[]>;
  getEffortEngagementsByEffortIds(effortIds: EffortId[]): Promise<EffortEngagement[]>;
}

export const effortEngagementsRepository: EffortEngagementsRepository = {
  getEffortEngagementsByTimeFrames(
    startTimeFrameId: TimeFrameId,
    endTimeFrameId: TimeFrameId
  ): Promise<EffortEngagement[]> {
    const db = container.resolve(AppContext).db;
    const sql = `
      ${teamEffortQuery}
      ${timeframesInRangeQuery}`;
    return db
      .manyOrNone(sql, {
        startTimeFrame: startTimeFrameId,
        endTimeFrame: endTimeFrameId,
      })
      .then(engagements => convertEngagementDetails(engagements));
  },
  getEffortEngagementsByTeam(teamId: TeamId): Promise<EffortEngagement[]> {
    const db = container.resolve(AppContext).db;
    const sql = `
      ${teamEffortQuery}
      WHERE team_id = $<teamId>`;
    return db.manyOrNone(sql, {teamId}).then(engagements => convertEngagementDetails(engagements));
  },
  getEffortEngagementsByTeamAndTimeframes(
    teamId: TeamId,
    startTimeFrame: TimeFrameId,
    endTimeFrame: TimeFrameId
  ): Promise<EffortEngagement[]> {
    const db = container.resolve(AppContext).db;
    const sql = `
      ${teamEffortQuery}
      ${timeframesInRangeQuery}
      WHERE team_id = $<teamId>`;
    return db
      .manyOrNone(sql, {
        teamId,
        startTimeFrame,
        endTimeFrame,
      })
      .then(engagements => convertEngagementDetails(engagements));
  },
  async getEffortEngagementsByEffortIds(effortIds) {
    if (!effortIds?.length) return [];
    const db = container.resolve(AppContext).db;
    const sql = `
        ${teamEffortQuery}
        WHERE team_cost.team_cost_id in ($1:csv)
      `;
    return db
      .manyOrNone(sql, [effortIds])
      .then(engagements => convertEngagementDetails(engagements));
  },
};
