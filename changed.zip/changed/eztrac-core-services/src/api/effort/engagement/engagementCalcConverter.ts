import {EngagementCalcInfo} from './models';

export class EngagementCalcConverter {
  static convertToObject(str?: string): EngagementCalcInfo | undefined {
    if (!str) {
      return undefined;
    }
    try {
      return JSON.parse(str);
    } catch {
      // Malformed amount_details shouldn't crash the whole engagement read -
      // surface it as "no breakdown available" instead of a 500.
      return undefined;
    }
  }
}
