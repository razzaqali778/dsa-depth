import {container} from 'tsyringe';
import {AppContext} from '../../AppContext';
import {TimeFrameId} from '../../../api/timeframe/models';
import {
  EngagementId,
  EngagementCalcInfo,
  EngagementDTO,
  EffortEngagement,
  Engagement,
} from './models';
import {calculateCost} from './utils';
import {CalendarHours, eztracCostingClient} from '../../../util/client/eztracCostingClient';
import {TeamId} from '../../team/models';
import {validateTimeFrameRange} from '../../../../src/api/timeframe/timeFrameService';
import {EffortEntity, EffortId} from '../models';
import {getTeamByIdOrThrow} from '../../team/teamService';
import {
  getFullEffortEntitiesByTeamAndTimeFrames,
  getOrCreateEfforts,
  updateEfforts,
  validateUserIsAuthorizedToModifyChosenTimeFrames,
} from '../effortService';

export const DEFAULT_HOURS_AMOUNT = 160;

const mapToEngagementDTO = (engagements: EffortEngagement[]): EngagementDTO[] =>
  engagements.map(e => {
    const {effortId: _effortId, ...engagement} = e;
    return engagement;
  });

const getCalculatedAmount = (
  calendarHours: CalendarHours[],
  amountDetails: EngagementCalcInfo,
  timeFrameId: TimeFrameId
) => {
  const calendarHoursForTimeFrame = calendarHours.find(h => h.timeFrameId === timeFrameId);
  const calculatedHours = calendarHoursForTimeFrame?.contractorHours || DEFAULT_HOURS_AMOUNT;
  const cost = calculateCost(amountDetails.rates, calculatedHours) || 0;
  return BigInt(cost);
};

const createOrUpdateEngagements = async (
  timeFrameIds: TimeFrameId[],
  isAdmin: boolean,
  engagement: Engagement,
  efforts: EffortEntity[]
) => {
  const r = container.resolve(AppContext).repositories;

  await validateUserIsAuthorizedToModifyChosenTimeFrames(timeFrameIds, isAdmin, r);

  let calendarHours: CalendarHours[];

  if (engagement.amountDetails) {
    const hours = await eztracCostingClient.getCalendarHours();
    calendarHours =
      hours.filter(hour => hour.calendarId === engagement.amountDetails?.calendarId) || [];
  }

  const modifiedEfforts = efforts.map(effort => {
    const recalculatedAmount = engagement.amountDetails
      ? getCalculatedAmount(calendarHours, engagement.amountDetails, effort.timeFrameId)
      : engagement.amount;
    const filteredEngagements =
      effort.engagements?.filter(e => e.engagementId !== engagement.engagementId) ?? [];
    return {
      ...effort,
      engagements: [...filteredEngagements, {...engagement, amount: recalculatedAmount}],
    };
  });

  return updateEfforts(modifiedEfforts);
};

export const byTimeFrameIds = async (
  startTimeFrameId: TimeFrameId,
  endTimeFrameId: TimeFrameId
): Promise<EffortEngagement[]> => {
  const repositories = container.resolve(AppContext).repositories;

  await validateTimeFrameRange(startTimeFrameId, endTimeFrameId);

  const effortEngagements =
    await repositories.effortEngagementsRepository.getEffortEngagementsByTimeFrames(
      startTimeFrameId,
      endTimeFrameId
    );

  return mapToEngagementDTO(effortEngagements);
};

export const byTeamAndTimeRange = async (
  teamId: string,
  startTimeFrameId: bigint,
  endTimeFrameId: bigint
): Promise<EngagementDTO[]> => {
  const repositories = container.resolve(AppContext).repositories;

  await validateTimeFrameRange(startTimeFrameId, endTimeFrameId);

  const effortEngagements =
    await repositories.effortEngagementsRepository.getEffortEngagementsByTeamAndTimeframes(
      teamId,
      startTimeFrameId,
      endTimeFrameId
    );

  return mapToEngagementDTO(effortEngagements);
};

export const byTeam = async (teamId: string): Promise<EffortEngagement[]> => {
  const repositories = container.resolve(AppContext).repositories;

  const effortEngagements =
    await repositories.effortEngagementsRepository.getEffortEngagementsByTeam(teamId);

  return mapToEngagementDTO(effortEngagements);
};

export const addEffortEngagements = async (
  startTimeFrameId: TimeFrameId,
  endTimeFrameId: TimeFrameId,
  teamId: TeamId,
  engagement: Engagement,
  isAdmin: boolean
): Promise<EffortId[]> => {
  const r = container.resolve(AppContext).repositories;

  await validateTimeFrameRange(startTimeFrameId, endTimeFrameId);

  await getTeamByIdOrThrow(teamId);

  const timeFrameIds = await r.timeFrameRepository.getTimeFrameIdsInRange(
    startTimeFrameId,
    endTimeFrameId
  );

  const efforts = await getOrCreateEfforts(timeFrameIds, teamId);

  return createOrUpdateEngagements(timeFrameIds, isAdmin, engagement, efforts);
};

export const updateEngagements = async (
  timeFrameId: TimeFrameId,
  teamId: TeamId,
  engagement: Engagement,
  isAdmin: boolean,
  updateAllFuture: boolean
) => {
  const r = container.resolve(AppContext).repositories;

  await getTeamByIdOrThrow(teamId);

  const timeFrameIds = updateAllFuture
    ? await r.timeFrameRepository.getTimeFrameAndAllFutureTimeFrameIds(timeFrameId)
    : [timeFrameId];

  const efforts = await getFullEffortEntitiesByTeamAndTimeFrames(teamId, timeFrameIds);

  return createOrUpdateEngagements(timeFrameIds, isAdmin, engagement, efforts);
};

export const deleteEffortEngagements = async (
  teamId: TeamId,
  timeFrameId: TimeFrameId,
  engagementId: EngagementId,
  isAdmin: boolean
) => {
  const r = container.resolve(AppContext).repositories;

  const timeFrameIds = await r.timeFrameRepository.getTimeFrameAndAllFutureTimeFrameIds(
    timeFrameId
  );

  await validateUserIsAuthorizedToModifyChosenTimeFrames(timeFrameIds, isAdmin, r);

  const efforts = await getFullEffortEntitiesByTeamAndTimeFrames(teamId, timeFrameIds);

  const updatedEfforts = efforts.map(effort => ({
    ...effort,
    engagements: effort.engagements?.filter(engagement => engagement.engagementId !== engagementId),
  }));

  return updateEfforts(updatedEfforts);
};
