import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {TeamId} from '../team/models';
import {TimeFrameId} from '../timeframe/models';
import {Effort, EffortEntity, EffortId} from './models';
import {eztracCostingClient} from '../../util/client/eztracCostingClient';
import {AppRepositories} from '../AppRepositories';
import {ForbiddenError} from '../types/ForbiddenError';
import {isEmpty} from 'lodash';

const effortIsEmpty = (effort: EffortEntity) =>
  isEmpty(effort.allocations) &&
  isEmpty(effort.engagements) &&
  isEmpty(effort.forecastPeople) &&
  isEmpty(effort.members);

const updateEffortBreakdowns = async (efforts: EffortEntity[]): Promise<EffortEntity[]> => {
  const effortCostCalculationRequest = efforts.map(effort => ({
    teamId: effort.teamId,
    timeFrameId: effort.timeFrameId,
    participants: effort.members ?? [],
    genericParticipants: effort.forecastPeople ?? [],
    engagements: effort.engagements ?? [],
  }));
  const effortsCostCalculations = await eztracCostingClient.getEffortCostCalculation(
    effortCostCalculationRequest
  );
  const effortsWithUpdatedBreakdowns = efforts.map(
    effort =>
      ({
        ...effort,
        costBreakdowns:
          effortsCostCalculations.find(
            calculation =>
              calculation.teamId === effort.teamId && calculation.timeFrameId === effort.timeFrameId
          )?.teamMemberCosts ?? [],
      } as EffortEntity)
  );
  return effortsWithUpdatedBreakdowns;
};

const groupByEffortId = <T extends {effortId: EffortId}>(items: T[]) => {
  const grouped = new Map<string, T[]>();

  items.forEach(item => {
    const key = String(item.effortId);
    const groupedItems = grouped.get(key);

    if (groupedItems) {
      groupedItems.push(item);
    } else {
      grouped.set(key, [item]);
    }
  });

  return grouped;
};

const getRowsForEffort = <T extends {effortId: EffortId}>(
  grouped: Map<string, T[]>,
  effortId: EffortId
) => grouped.get(String(effortId)) ?? [];

const getFullEffortEntities = async (efforts: Effort[]): Promise<EffortEntity[]> => {
  const r = container.resolve(AppContext).repositories;

  const effortIds = efforts.map(e => e.id);

  if (effortIds.length === 0) return [];

  const engagementsPromise =
    r.effortEngagementsRepository.getEffortEngagementsByEffortIds(effortIds);
  const allocationsPromise = r.effortAllocationsRepository.getAllocationsByEffortIds(effortIds);
  const membersPromise = r.effortMembersRepository.getMembersByEffortIds(effortIds);
  const forecastMembersPromise =
    r.effortMembersRepository.getForecastedMembersByEffortIds(effortIds);
  const breakdownsPromise = r.effortRepository.getEffortCostBreakdownsByEffortIds(effortIds);

  const [engagements, allocations, members, forecastMembers, costGroupBreakdowns] =
    await Promise.all([
      engagementsPromise,
      allocationsPromise,
      membersPromise,
      forecastMembersPromise,
      breakdownsPromise,
    ]);

  const engagementsByEffortId = groupByEffortId(engagements);
  const allocationsByEffortId = groupByEffortId(allocations);
  const membersByEffortId = groupByEffortId(members);
  const forecastMembersByEffortId = groupByEffortId(forecastMembers);
  const breakdownsByEffortId = groupByEffortId(costGroupBreakdowns);

  const fullEfforts = efforts.map(
    effort =>
      ({
        id: effort.id,
        timeFrameId: effort.timeFrameId,
        teamId: effort.teamId,
        allocations: getRowsForEffort(allocationsByEffortId, effort.id).map(a => {
          const {
            effortId: _effortId,
            timeFrameId: _timeFrameId,
            teamId: _teamId,
            ...allocationSimple
          } = a;
          return allocationSimple;
        }),
        members: getRowsForEffort(membersByEffortId, effort.id).map(m => {
          const {
            effortId: _effortId,
            timeFrameId: _timeFrameId,
            teamId: _teamId,
            ...memberSimple
          } = m;
          return memberSimple;
        }),
        forecastPeople: getRowsForEffort(forecastMembersByEffortId, effort.id).map(fm => {
          const {
            effortId: _effortId,
            timeFrameId: _timeFrameId,
            teamId: _teamId,
            ...forecastMemberSimple
          } = fm;
          return {
            ...forecastMemberSimple,
            numberOfPeople: Number(forecastMemberSimple.numberOfPeople),
          };
        }),
        engagements: getRowsForEffort(engagementsByEffortId, effort.id).map(e => {
          const {
            effortId: _effortId,
            timeFrameId: _timeFrameId,
            teamId: _teamId,
            ...engagementSimple
          } = e;
          return engagementSimple;
        }),
        costBreakdowns: getRowsForEffort(breakdownsByEffortId, effort.id).map(b => {
          const {effortId: _effortId, ...breakdownSimple} = b;
          return breakdownSimple;
        }),
      } as EffortEntity)
  );

  return fullEfforts;
};

export const validateUserIsAuthorizedToModifyChosenTimeFrames = async (
  timeFrameIds: TimeFrameId[],
  isAdmin: boolean,
  r: AppRepositories
) => {
  if (isAdmin) return;

  const timeFrames = await r.timeFrameRepository.getTimeFramesByIds(timeFrameIds);
  const containsClosedTimeFrames = timeFrames?.some(timeFrame => {
    const endDate = new Date(timeFrame.endDate).getTime();
    return timeFrame.lockdown || endDate < Date.now();
  });

  if (containsClosedTimeFrames) throw new ForbiddenError();
};

export const getFullEffortEntitiesByTeamAndTimeFrames = async (
  teamId: TeamId,
  timeFrameIds: TimeFrameId[]
): Promise<EffortEntity[]> => {
  const r = container.resolve(AppContext).repositories;

  const efforts = await r.effortRepository.getEffortByTeamAndTimeframes(timeFrameIds, teamId);
  const fullEfforts = await getFullEffortEntities(efforts);

  return fullEfforts;
};

export const getFullEffortEntityByTeamAndTimeFrame = async function (
  teamId: TeamId,
  timeFrameId: TimeFrameId
): Promise<EffortEntity> {
  const efforts = await getFullEffortEntitiesByTeamAndTimeFrames(teamId, [timeFrameId]);
  return efforts[0];
};

export const getFullEffortEntitiesByTimeFrames = async (
  timeFrameIds: TimeFrameId[]
): Promise<EffortEntity[]> => {
  const r = container.resolve(AppContext).repositories;

  const efforts = await r.effortRepository.getEffortByTimeFrames(timeFrameIds);
  const fullEfforts = await getFullEffortEntities(efforts);

  return fullEfforts;
};

export const getFullEffortEntitiesByTeamsAndTimeFrames = async (
  teamIds: TeamId[],
  timeFrameIds: TimeFrameId[]
): Promise<EffortEntity[]> => {
  const r = container.resolve(AppContext).repositories;

  const efforts = await r.effortRepository.getEffortsByTeamsAndTimeFrames(teamIds, timeFrameIds);
  const fullEfforts = await getFullEffortEntities(efforts);

  return fullEfforts;
};

export const getFullEffortEntitiesByTeamStartAndEndTimeFrameId = async function (
  teamId: TeamId,
  startTimeFrameId: TimeFrameId,
  endTimeFrameId: TimeFrameId
): Promise<EffortEntity[]> {
  const r = container.resolve(AppContext).repositories;
  const timeFrameIds = await r.timeFrameRepository.getTimeFrameIdsInRange(
    startTimeFrameId,
    endTimeFrameId
  );
  return await getFullEffortEntitiesByTeamAndTimeFrames(teamId, timeFrameIds);
};

export const getOrCreateEfforts = async (timeFrameIds: TimeFrameId[], teamId: TeamId) => {
  const existingEfforts = await getFullEffortEntitiesByTeamAndTimeFrames(teamId, timeFrameIds);
  const allEfforts = timeFrameIds.map(timeFrameId => {
    const existingEffort = existingEfforts.find(
      // type casting needed for tests
      effort => BigInt(effort.timeFrameId) === timeFrameId
    );

    return existingEffort ?? ({timeFrameId, teamId} as EffortEntity);
  });
  return allEfforts;
};

export const updateEfforts = async (efforts: EffortEntity[], breakdownsHaveToBeUpdated = true) => {
  const r = container.resolve(AppContext).repositories;

  const effortsToBeDeleted = efforts.filter(effort => effortIsEmpty(effort));
  const effortsToBeUpdated = efforts.filter(effort => !effortIsEmpty(effort));

  await Promise.all(effortsToBeDeleted.map(effort => r.effortRepository.deleteEffort(effort)));

  // Must use effortsToBeUpdated (not the original `efforts`) here: `efforts` still includes the
  // now-deleted empty efforts above. Passing those into updateEffort would re-create an empty
  // team_cost row for an effort that was just intentionally deleted (or, for efforts that never
  // had an id, insert a brand-new empty row for a team/time frame that should have no effort row
  // at all).
  const effortsWithUpdatedBreakdowns = breakdownsHaveToBeUpdated
    ? await updateEffortBreakdowns(effortsToBeUpdated)
    : effortsToBeUpdated;
  const affectedEffortsIds = await Promise.all(
    effortsWithUpdatedBreakdowns.map(effort => r.effortRepository.updateEffort(effort))
  );

  return affectedEffortsIds;
};

export const getEffortsByIds = async (effortIds: EffortId[]): Promise<Effort[]> => {
  const r = container.resolve(AppContext).repositories;
  return r.effortRepository.getEffortsByIds(effortIds);
};
