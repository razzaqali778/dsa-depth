import {EffortCostingDetails, StandardTeamCostingResult} from './models';
import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {TimeFrame, TimeFrameId} from '../timeframe/models';
import {EffortEntity, EffortCostBreakdown, EffortId} from '../effort/models';
import {EffortCostingResult, batchCallCostingService} from '../../util/client/eztracCostingClient';
import {getFullEffortEntitiesByTimeFrames} from '../effort/effortService';

const DEFAULT_COSTING_CONCURRENCY = 4;

const getCostingConcurrency = () => {
  const configured = Number(process.env.COST_ALL_TEAMS_CONCURRENCY);
  return Number.isFinite(configured) && configured > 0
    ? Math.floor(configured)
    : DEFAULT_COSTING_CONCURRENCY;
};

async function mapWithConcurrency<T, R>(
  items: T[],
  concurrency: number,
  mapper: (item: T) => Promise<R>
): Promise<R[]> {
  const results: R[] = [];
  let nextIndex = 0;
  const workerCount = Math.min(Math.max(concurrency, 1), items.length);

  const workers = Array.from({length: workerCount}, async () => {
    while (nextIndex < items.length) {
      const currentIndex = nextIndex;
      nextIndex += 1;
      results[currentIndex] = await mapper(items[currentIndex]);
    }
  });

  await Promise.all(workers);
  return results;
}

function parseToCostingServiceRequestBody(efforts: EffortEntity[]): EffortCostingDetails[] {
  return efforts.map(
    effort =>
      ({
        teamId: effort.teamId,
        timeFrameId: effort.timeFrameId,
        participants: effort.members?.map(m => ({userId: m.userId, percent: m.percent})),
        genericParticipants: effort.forecastPeople?.map(fp => ({
          numberOfPeople: fp.numberOfPeople,
          rateId: fp.rateId,
          costGroupId: fp.costGroupId,
        })),
        engagements: effort.engagements?.map(e => ({
          amount: e.amount,
          engagementId: e.engagementId,
          amountDetails: e.amountDetails,
        })),
      } as EffortCostingDetails)
  );
}

const processCostingServiceResponse = (
  costingResults: EffortCostingResult[],
  efforts: EffortEntity[]
): EffortCostBreakdown[] => {
  const effortCostBreakdowns: EffortCostBreakdown[] = [];

  efforts.forEach(effort => {
    const costingResult = costingResults.find(
      r => r.teamId === effort.teamId && r.timeFrameId === effort.timeFrameId
    );
    costingResult?.teamMemberCosts.forEach(cost => {
      effortCostBreakdowns.push({
        effortId: effort.id!,
        costGroupId: cost.costGroupId,
        cost: cost.cost,
        engagementId: cost.engagementId,
        personId: cost.personId,
      });
    });
  });

  return effortCostBreakdowns;
};

const costTimeFrameAllTeams = async (timeFrame: TimeFrame): Promise<StandardTeamCostingResult> => {
  const efforts = await getFullEffortEntitiesByTimeFrames([timeFrame.id]);
  const costingServiceRequest = parseToCostingServiceRequestBody(efforts);
  const costingResponse = await batchCallCostingService(costingServiceRequest);
  const costBreakdowns = processCostingServiceResponse(costingResponse, efforts);
  const effortIds = efforts.flatMap(effort => (effort.id ? [effort.id] : []));
  const rowsAffected = await updateEffortCostBreakdowns(costBreakdowns, effortIds);
  return {
    costCalcResponse: costingResponse,
    breakdownRows: costBreakdowns,
    numAffectedRows: rowsAffected,
  };
};

const updateEffortCostBreakdowns = async (
  costBreakdowns: EffortCostBreakdown[],
  effortIdsToReplace: EffortId[]
): Promise<number> => {
  const r = container.resolve(AppContext).repositories;
  const costBreakdownsCount = await r.effortRepository.updateEffortCostBreakdowns(
    costBreakdowns,
    effortIdsToReplace
  );
  return costBreakdownsCount;
};

export const costAllTeams = async function (): Promise<
  Map<TimeFrameId, StandardTeamCostingResult>
> {
  const result = new Map();
  const r = container.resolve(AppContext).repositories;
  const timeFrames = await r.timeFrameRepository.getNonHistoricTimeFrames();

  // Each time frame's costing run is independent, but unbounded Promise.all can overload the
  // costing service and database when many active months exist. Keep concurrency bounded.
  const costingResults = await mapWithConcurrency(
    timeFrames,
    getCostingConcurrency(),
    async timeFrame => ({
      timeFrameId: timeFrame.id,
      result: await costTimeFrameAllTeams(timeFrame),
    })
  );

  for (const {timeFrameId, result: costingResult} of costingResults) {
    result.set(timeFrameId, costingResult);
  }
  return result;
};
