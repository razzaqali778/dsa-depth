import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';

const getSpendParams = Joi.object({
  startTimeFrame: Joi.number().integer().required(),
  endTimeFrame: Joi.number().integer().required(),
});

const getSpendQuery = Joi.object({
  view: Joi.string().valid('facts').optional(),
}).unknown(true);

export interface GetSpendSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    startTimeFrame: bigint;
    endTimeFrame: bigint;
  };
  [ContainerTypes.Query]: {
    view?: 'facts';
  };
}

export const schema = {
  getSpendParams,
  getSpendQuery,
};
