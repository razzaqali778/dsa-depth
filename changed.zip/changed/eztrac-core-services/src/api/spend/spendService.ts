import _ from 'lodash';
import {container} from 'tsyringe';
import {Dictionary} from 'tsyringe/dist/typings/types';
import {AppContext} from '../AppContext';
import {CostValue} from '../costcalc/models';
import {EffortAllocation} from '../effort/allocation/models';
import {EngagementId} from '../effort/engagement/models';
import {CostGroupId, EffortCostBreakdown, PersonId} from '../effort/models';
import {InitiativeId} from '../initiative/initiative';
import {TeamId} from '../team/models';
import {TimeFrameId} from '../timeframe/models';
import {TeamCostSpendFact} from './spendRepository';

interface SpendLineItem {
  costGroupId: CostGroupId;
  spend: CostValue;
  engagementId: EngagementId;
  personId: PersonId;
}

interface InitiativeSpending {
  initiativeId: InitiativeId;
  spend: CostValue;
  lineItems: SpendLineItem[];
}

export interface EffortSpending {
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  initiatives: InitiativeSpending[];
}

function getLineItems(
  breakdowns: EffortCostBreakdown[],
  allocation: EffortAllocation
): SpendLineItem[] {
  return _.chain(breakdowns)
    .map(b => {
      const spend = Math.round((Number(allocation.percentageOfTeamCost) * Number(b.cost)) / 100);
      return {
        costGroupId: b.costGroupId ?? '',
        spend: BigInt(spend),
        engagementId: b.engagementId ?? '',
        personId: b.personId ?? '',
      };
    })
    .filter(item => item.spend > 0)
    .value();
}

function getInitiativeSpending(
  allocations: EffortAllocation[],
  breakdowns: EffortCostBreakdown[]
): InitiativeSpending[] {
  return allocations.map(a => {
    const lineItems: SpendLineItem[] = getLineItems(breakdowns, a);
    const spend = lineItems.reduce((sum, current) => sum + Number(current.spend), 0);
    return {
      initiativeId: a.initiativeId,
      spend: BigInt(spend),
      lineItems: lineItems,
    };
  });
}

function getEffortsSpending(
  allocations: EffortAllocation[],
  groupedBreakdowns: Dictionary<EffortCostBreakdown[]>
) {
  return _.chain(allocations)
    .filter(ea => ea.percentageOfTeamCost > 0)
    .groupBy(ea => ea.effortId)
    .map((allocations, effortId) => {
      const breakdowns = groupedBreakdowns[effortId] ?? [];
      const initiativeSpending = getInitiativeSpending(allocations, breakdowns);
      return {
        timeFrameId: allocations[0].timeFrameId,
        teamId: allocations[0].teamId,
        initiatives: initiativeSpending,
      } as EffortSpending;
    })
    .filter(spending => spending.initiatives && spending.initiatives.length > 0)
    .value();
}

function getEffortsSpendingFromFacts(facts: TeamCostSpendFact[]): EffortSpending[] {
  return _.chain(facts)
    .groupBy(fact => `${fact.timeFrameId}|${fact.teamId}`)
    .map(groupedFacts => {
      const initiatives = _.chain(groupedFacts)
        .groupBy(fact => fact.initiativeId)
        .map(initiativeFacts => {
          const lineItems = initiativeFacts.map(fact => ({
            costGroupId: fact.costGroupId ?? '',
            spend: fact.spend,
            engagementId: fact.engagementId ?? '',
            personId: fact.personId ?? '',
          }));

          return {
            initiativeId: initiativeFacts[0].initiativeId,
            spend: BigInt(lineItems.reduce((sum, current) => sum + Number(current.spend), 0)),
            lineItems,
          };
        })
        .filter(initiative => initiative.spend > 0)
        .value();

      return {
        timeFrameId: groupedFacts[0].timeFrameId,
        teamId: groupedFacts[0].teamId,
        initiatives,
      } as EffortSpending;
    })
    .filter(spending => spending.initiatives && spending.initiatives.length > 0)
    .value();
}

function getFactsFromEffortsSpending(effortsSpending: EffortSpending[]): TeamCostSpendFact[] {
  return _.chain(effortsSpending)
    .flatMap(effortSpending =>
      effortSpending.initiatives.flatMap(initiative =>
        initiative.lineItems.map(lineItem => {
          return {
            timeFrameId: effortSpending.timeFrameId,
            teamId: effortSpending.teamId,
            initiativeId: initiative.initiativeId,
            costGroupId: lineItem.costGroupId,
            engagementId: lineItem.engagementId,
            personId: lineItem.personId,
            spend: lineItem.spend,
          } as TeamCostSpendFact;
        })
      )
    )
    .filter(fact => fact.spend > 0)
    .value();
}

async function getEffortsSpendInTimeRangeFromSourceTables(
  startTimeFrame: TimeFrameId,
  endTimeFrame: TimeFrameId
): Promise<EffortSpending[]> {
  const r = container.resolve(AppContext).repositories;
  const effortAllocations = await r.effortAllocationsRepository.getEffortAllocationsByTimeRange(
    startTimeFrame,
    endTimeFrame
  );

  if (effortAllocations.length === 0) return [];

  // Dedupe before building the SQL IN-lists - one allocation row per effort means the same
  // teamId/timeFrameId pair otherwise gets repeated once per allocation, bloating the query.
  const costBreakdowns = await r.effortRepository.getEffortCostBreakdowns(
    [...new Set(effortAllocations.map(ea => ea.teamId))],
    [...new Set(effortAllocations.map(ea => ea.timeFrameId))]
  );
  const groupedBreakdowns = _.chain(costBreakdowns)
    .filter(cb => cb.cost !== undefined && cb.cost > 0)
    .groupBy(cb => cb.effortId)
    .value();

  const effortsSpending = getEffortsSpending(effortAllocations, groupedBreakdowns);
  return effortsSpending;
}

export async function getTeamCostSpendFactsInTimeRange(
  startTimeFrame: TimeFrameId,
  endTimeFrame: TimeFrameId
): Promise<TeamCostSpendFact[]> {
  const r = container.resolve(AppContext).repositories;
  if (!r.spendRepository) {
    return getFactsFromEffortsSpending(
      await getEffortsSpendInTimeRangeFromSourceTables(startTimeFrame, endTimeFrame)
    );
  }

  try {
    return r.spendRepository.getTeamCostSpendByTimeRange(startTimeFrame, endTimeFrame);
  } catch (error) {
    console.error('Failed to read team_cost_spend fact table; falling back to source tables', error);
    return getFactsFromEffortsSpending(
      await getEffortsSpendInTimeRangeFromSourceTables(startTimeFrame, endTimeFrame)
    );
  }
}

export async function getEffortsSpendInTimeRange(
  startTimeFrame: TimeFrameId,
  endTimeFrame: TimeFrameId
): Promise<EffortSpending[]> {
  const facts = await getTeamCostSpendFactsInTimeRange(startTimeFrame, endTimeFrame);
  return getEffortsSpendingFromFacts(facts);
}
