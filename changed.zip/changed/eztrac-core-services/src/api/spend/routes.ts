import {Response} from 'express';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {apiResponse} from '../../middleware/apiResponse';
import {ValidatedRequest, createValidator} from 'express-joi-validation';
import {GetSpendSchema, schema} from './validationSchema';
import {
  getEffortsSpendInTimeRange,
  getTeamCostSpendFactsInTimeRange,
} from './spendService';

const router = require('express').Router();
const validator = createValidator();

const doc: SwaggerDoc = {};

const tags = ['spend'];

doc['/spend/startTimeFrame/{startTimeFrame}/endTimeFrame/{endTimeFrame}'] = {
  get: {
    tags,
    operationId: 'getSpendInTimeRange',
    parameters: [
      {
        name: 'startTimeFrame',
        in: 'path',
        description: 'id of the start time frame',
        required: true,
        type: 'integer',
      },
      {
        name: 'endTimeFrame',
        in: 'path',
        description: 'id of the end time frame',
        required: true,
        type: 'integer',
      },
    ],
    summary: 'Get efforts spend in time range',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      404: {description: 'Not found'},
    },
  },
};

router.get(
  '/spend/startTimeFrame/:startTimeFrame/endTimeFrame/:endTimeFrame',
  validator.params(schema.getSpendParams),
  validator.query(schema.getSpendQuery),
  apiResponse(async (req: ValidatedRequest<GetSpendSchema>, res: Response) => {
    const {startTimeFrame, endTimeFrame} = req.params;
    const {view} = req.query;

    if (view === 'facts') {
      const facts = await getTeamCostSpendFactsInTimeRange(startTimeFrame, endTimeFrame);
      res.send(facts);
      return;
    }

    const effortSpending = await getEffortsSpendInTimeRange(startTimeFrame, endTimeFrame);
    res.send(effortSpending);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
