import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {CostValue} from '../costcalc/models';
import {EngagementId} from '../effort/engagement/models';
import {CostGroupId, PersonId} from '../effort/models';
import {InitiativeId} from '../initiative/initiative';
import {TeamId} from '../team/models';
import {TimeFrameId} from '../timeframe/models';

export interface TeamCostSpendFact {
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  initiativeId: InitiativeId;
  costGroupId: CostGroupId;
  engagementId: EngagementId;
  personId: PersonId;
  spend: CostValue;
}

export interface SpendRepository {
  getTeamCostSpendByTimeRange(
    startTimeFrame: TimeFrameId,
    endTimeFrame: TimeFrameId
  ): Promise<TeamCostSpendFact[]>;
}

export const spendRepository: SpendRepository = {
  getTeamCostSpendByTimeRange(startTimeFrame, endTimeFrame): Promise<TeamCostSpendFact[]> {
    const db = container.resolve(AppContext).db;
    const sql = `
      SELECT
        timeframe_id      as "timeFrameId",
        team_id           as "teamId",
        vip_initiative_id as "initiativeId",
        cost_group_id     as "costGroupId",
        engagement_id     as "engagementId",
        person_id         as "personId",
        spend             as "spend"
      FROM public.team_cost_spend
      WHERE timeframe_id BETWEEN $<startTimeFrame> AND $<endTimeFrame>
        AND spend > 0
      ORDER BY
        timeframe_id,
        team_id,
        vip_initiative_id,
        cost_group_id,
        engagement_id,
        person_id
    `;

    return db.any<TeamCostSpendFact>(sql, {startTimeFrame, endTimeFrame});
  },
};