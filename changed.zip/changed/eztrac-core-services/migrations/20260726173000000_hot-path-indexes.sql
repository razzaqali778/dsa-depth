-- Up Migration
CREATE INDEX IF NOT EXISTS idx_team_cost_team_id
  ON public.team_cost (team_id);

CREATE INDEX IF NOT EXISTS idx_team_cost_timeframe_team
  ON public.team_cost (timeframe_id, team_id);

CREATE INDEX IF NOT EXISTS idx_team_cost_allocation_team_cost_id
  ON public.team_cost_allocation (team_cost_id);

CREATE INDEX IF NOT EXISTS idx_team_cost_member_team_cost_id
  ON public.team_cost_member (team_cost_id);

CREATE INDEX IF NOT EXISTS idx_timeframe_start_end
  ON public.timeframe (timeframe_start_date, timeframe_end_date);

-- Down Migration
DROP INDEX IF EXISTS public.idx_timeframe_start_end;
DROP INDEX IF EXISTS public.idx_team_cost_member_team_cost_id;
DROP INDEX IF EXISTS public.idx_team_cost_allocation_team_cost_id;
DROP INDEX IF EXISTS public.idx_team_cost_timeframe_team;
DROP INDEX IF EXISTS public.idx_team_cost_team_id;
