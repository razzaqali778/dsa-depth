# Performance and bug-fix audit (2026-07-24)

**Date:** 2026-07-24
**Result:** 15 real bugs fixed across two passes (2 high-latency N+1/serial-I/O issues, 9 correctness/crash bugs, 4 code-quality issues), 9 new regression tests added
**Validation:** `tsc --noEmit`, `gts lint`, and the full unit suite (`npm run test`) all pass — **205 tests passing** (196 before this audit + 9 new regression tests)

This audit was done in two passes: an initial manual pass (fixes #1–9 below), followed by a second, independent audit pass ([Audit eztrac-core-services for bugs](6d7f09f5-3ce1-4bc3-9a6e-3cefb8b97974)) that cross-checked the same codebase and surfaced 6 additional real, fixable issues (fixes #10–15) that the first pass had either missed or filed as deferred without fixing. Both passes' findings are consolidated here.

This document records a full audit of `src/`, `server.ts`, and the routes under `/team`, `/effort`, `/effortAllocation`, `/effortEngagement`, `/effortMember`, `/timeframe`, `/healthcheck`, `/cost/standard-teams`, `/GETExport`, `/spend`, `/platform`, `/community`, `/org`, plus the fixes applied and the reasoning behind each one. Every fix below was verified against the existing test/lint/type-check tooling; nothing was changed without being able to prove it still behaves correctly.

---

## How this was done

1. Read the route/service/repository layer for every API area (`src/api/**`) plus the DB and HTTP client layers (`src/db/dbManager.ts`, `src/util/client/*`).
2. For every suspected issue, traced the exact call path (route → service → repository → SQL/HTTP) to confirm it was real, not theoretical, and to understand blast radius before touching it.
3. Applied the minimal, targeted fix for each issue — no drive-by refactors.
4. Re-ran `tsc --noEmit`, `gts lint`, and `npm run test` after every change (not just at the end), so any regression would have been caught immediately, file by file.
5. Added regression tests for the two bugs that had **zero** existing test coverage, so they can't silently reappear.

---

## Fixed: performance / latency

### 1. Health check did one DB round-trip per team (N+1)

**Route:** `GET /healthcheck/...` → `src/api/healthcheck/healthCheckEffortsService.ts`

**Before:** looped over every team returned for a time frame and called `getFullEffortEntityByTeamAndTimeFrame(team.teamId, timeFrameId)` one at a time — each call itself issuing ~6 queries (1 base + 5 child-table queries). For an org with *N* teams this was roughly *6N* sequential round-trips.

**Fix:** replaced the loop with a single call to `getFullEffortEntitiesByTimeFrames([timeFrameId])` (already used elsewhere in the codebase, e.g. `standardTeamCosting.ts`), which fetches every team's effort for that time frame in one batched query set, then filters the result down to the teams that are actually returned by `getTeamsWithStructureByTimeFrameId`. Route latency now scales with a constant number of queries instead of the number of teams.

### 2. Standard-team costing recalculated every time frame one at a time

**Route:** `PUT /cost/standard-teams` → `src/api/costcalc/standardTeamCosting.ts`

**Before:** `costAllTeams` looped over every non-historic time frame with `for (...) { await costTimeFrameAllTeams(timeFrame) }`. Each iteration does a full effort fetch, a costing-service HTTP call, and a DB write — completely independent of every other time frame — yet they ran strictly sequentially, so total latency was `(per-time-frame cost) × (number of time frames)`.

**Fix:** changed to `Promise.all(timeFrames.map(...))` so every time frame's costing run executes concurrently. This is a route hit by a scheduled job (see `eztrac-cron`), so cutting its wall-clock time directly reduces the window during which cost data is being recalculated.

### 3. `getOrCreatePeople` always called the external PAPI/GraphQL service

**File:** `src/api/person/personService.ts`

**Before:** `if (notLocalPeopleIds.length >= 0)` — a length can never be negative, so this condition was always `true`. Every call to this function (hit whenever effort members are created/updated) made an external PAPI GraphQL call even when every person already existed locally (i.e. the array was empty).

**Fix:** changed to `length > 0`, so the external call is skipped entirely when there's nothing to look up. Also switched the `localPeopleIds.includes(id)` membership check (O(n·m)) to a `Set` lookup (O(n+m)) in the same function.

### 4. `batchCallCostingService` misused `forEach(async ...)`

**File:** `src/util/client/eztracCostingClient.ts`

**Before:** built up a promises array via `chunks.forEach(async batch => { promises.push(...) })` — the `async` did nothing useful and obscured intent.

**Fix:** simplified to `Promise.all(chunks.map(batch => ...))`, which is both clearer and removes a common footgun pattern (an `async forEach` callback whose returned promise is silently discarded) from the codebase.

---

## Fixed: correctness / reliability

### 5. `updateEfforts` could resurrect a just-deleted, empty effort

**File:** `src/api/effort/effortService.ts` — used by `updateEffortAllocations` (`PUT /effortAllocation`, called with `breakdownsHaveToBeUpdated = false`)

**Before:**
```ts
const effortsWithUpdatedBreakdowns = breakdownsHaveToBeUpdated
  ? await updateEffortBreakdowns(effortsToBeUpdated)
  : efforts; // BUG: includes the efforts that were just deleted above
```
`updateEfforts` splits incoming efforts into `effortsToBeDeleted` (empty efforts) and `effortsToBeUpdated` (non-empty), deletes the empty ones, then — when `breakdownsHaveToBeUpdated` is `false` — fed the **original, unfiltered** `efforts` array (still containing the just-deleted empty ones) into `updateEffort`. For an effort with an existing id, this re-ran harmless no-op deletes. For a placeholder effort that never had an id (common output of `getOrCreateEfforts` for a time frame with no existing effort row), `updateEffort`'s `if (!effortId)` branch would **insert a brand-new, empty `team_cost` row** for a team/time-frame combination that should have no effort row at all — i.e., saving an all-zero allocation update could silently create phantom database rows.

**Fix:** use `effortsToBeUpdated` in both branches of the ternary, consistent with the `breakdownsHaveToBeUpdated = true` branch.

**Regression test added:** `test/api/effort/effortService.spec.ts` → `updateEfforts` → *"deletes empty efforts and does not re-create them via updateEffort when breakdowns are skipped."*

### 6. GET export / health check crashed on time frames with no configured workdays

**File:** `src/api/timeframe/timeFrameRepository.ts` → `getWorkdaysByTimeFrameIdAndCountry`

**Before:**
```ts
return db.oneOrNone(sql, {timeFrameId, country}).then(workdayRow =>
  JSON.parse(workdayRow.workdayHours).map(...) // workdayRow can be null
);
```
`oneOrNone` returns `null` when no row matches. Any time frame/country combination without configured workdays (new time frames, less-common countries) threw `TypeError: Cannot read properties of null`, turning into an unhandled 500 for the whole GET export.

**Fix:** return `[]` when no row is found. This is a safe default — `mapHoursToWorkdays`/`mapPersonAllocationToWorkday` in `src/api/GETExport/hoursToWorkdayMapper.ts` already handle an empty workday list correctly (their loop condition is `workdays.length !== 0`).

**Regression test added:** `test/api/timeframe/timeFrameRepository.spec.ts` → *"Returns an empty array (not a crash) when no workdays are configured for the time frame/country."*

### 7. VIP initiative hierarchy fetch could crash on leaf nodes

**File:** `src/util/client/eztracVipClient.ts`

**Before:** `initiativeExtended.children.map(...)` assumed `children` was always an array. If the upstream VIP service returns `null`/`undefined` for a leaf initiative's `children` (the DTO type doesn't guarantee otherwise), this throws and breaks `generateAllInitiatives()` — which both **GET export** and the **health check route** (fix #1 above) depend on.

**Fix:** `(initiativeExtended.children ?? []).map(...)`.

### 8. Global error handler double-responded to every 500

**File:** `server.ts`

**Before:**
```ts
app.use('/*', (err: unknown, req, res, next) => {
  console.error(err);
  res.status(StatusCodes.INTERNAL_SERVER_ERROR).send();
  next(err); // response already sent
});
```
Calling `next(err)` after the response was already fully sent forwarded to Express's default error handler, which tries to write to the response again — producing a spurious `Cannot set headers after they are sent to the client` error logged on **every single unhandled 500**, adding noise and minor extra latency to every error path.

**Fix:** removed the trailing `next(err)` call (guarded with `res.headersSent` as a belt-and-suspenders check).

### 9. Bare `throw Error` produced an opaque, useless error

**File:** `src/api/effort/effortRepository.ts` → `updateEffort`

**Before:** `if (!effortId) throw Error;` — throws the `Error` **constructor function itself**, not an `Error` instance. Any consumer inspecting `err.message` or `err.stack` gets nothing useful; this collapses whatever caused the missing id into an opaque 500.

**Fix:** `throw new Error('Failed to create team_cost row: no id returned')`.

---

## Second pass: fixes from an independent cross-check audit

[Audit eztrac-core-services for bugs](6d7f09f5-3ce1-4bc3-9a6e-3cefb8b97974) re-audited the whole service and largely confirmed fixes #1–9 above, but also surfaced these additional real bugs, which have now been fixed:

### 10. Health check could crash on an orphaned effort (non-null assertion)

**File:** `src/api/healthcheck/effortHealthCheck.ts`

**Before:** `const team = teams.find(...)` followed by `team!.teamName` — if an effort's `teamId` isn't present in the current team list (e.g. the team was deactivated/removed after the effort row was created), this throws a `TypeError`, failing the health check for **every** team, not just the orphaned one.

**Fix:** skip (don't report) an errored effort whose team can't be found, instead of crashing.

**Regression test added:** `test/api/healthcheck/effortHealthCheck.spec.ts` → *"skips (rather than crashes on) an errored effort whose team is not in the given team list."*

### 11. `isAdmin` could crash on a malformed/missing `user-profile` header

**File:** `src/util/security/isAdmin.ts`

**Before:** `JSON.parse(userProfileHeader)?.entitlements[entitlementAppName]` — an unguarded `JSON.parse` throws on invalid JSON, and even if parsing succeeds, `.entitlements[...]` throws if `entitlements` itself is missing (the `?.` only guarded the outer `JSON.parse(...)` call, not the nested property access). Every route that gates admin-only behavior (`effortMember`, `effortEngagement`, `effortAllocation` routes) calls this synchronously — an unhandled throw here becomes an unhandled 500 instead of a "not an admin" 403.

**Fix:** wrapped `JSON.parse` in try/catch (returns `false` on parse failure) and added optional chaining on `entitlements?.[entitlementAppName]`.

**Regression tests added:** `test/util/isAdmin.spec.ts` → *"returns false instead of throwing when the header is not valid JSON"* and *"...when the header has no entitlements at all."*

### 12. Engagement `amount_details` could crash the whole engagement read on malformed JSON

**File:** `src/api/effort/engagement/engagementCalcConverter.ts`

**Before:** `JSON.parse(str)` was unguarded; a single corrupt `amount_details` value in the `team_cost_engagement` table would throw and take down the entire `getEffortEngagements*` call (which returns *all* engagements for a team/time-range, not just the one bad row).

**Fix:** wrapped in try/catch, returning `undefined` (treated as "no breakdown available", same as the existing empty-string case) instead of throwing.

### 13. `roundToDecimal` only worked correctly for its own default argument

**File:** `src/api/GETExport/personToInitiativeMapper.ts`

**Before:** `(Math.round(x * 10 * decimalDigits) / 10) * decimalDigits` — this formula only reduces to "round to `decimalDigits` places" when `decimalDigits === 1`; any other value produces numbers rounded (and scaled) incorrectly. Every current call site happens to use the default, so this hadn't caused a visible bug yet, but it was a landmine for the next GET-export change that needed 2-decimal precision.

**Fix:** `Math.round(x * 10**decimalDigits) / 10**decimalDigits` — the standard, correct formula for rounding to *n* decimal places.

**Regression tests added:** `test/api/getexport/personToInitiativeMapper.spec.ts` → new `roundToDecimal` describe block covering the default case and non-default `decimalDigits` values.

### 14. Duplicate IDs inflated the `/spend` cost-breakdown query

**File:** `src/api/spend/spendService.ts`

**Before:** `getEffortCostBreakdowns(effortAllocations.map(ea => ea.teamId), effortAllocations.map(ea => ea.timeFrameId))` passed one team/time-frame id per **allocation row**, not per unique team/time-frame — so a team with 5 initiative allocations in a time range sent the same id 5 times into the SQL `IN (...)` list, bloating the query for no benefit (the underlying query already does `team_id IN (...) AND timeframe_id IN (...)`, an independent filter, not a paired-tuple join).

**Fix:** dedupe both id lists with `[...new Set(...)]` before querying.

**Regression test added:** `test/api/spend/spendService.spec.ts` → *"Dedupes team/time frame ids before querying cost breakdowns, one allocation row per effort"* (asserts the exact deduped arguments passed to the repository).

### 15. Dead, self-comparing SQL fragment removed

**File:** `src/api/effort/engagement/effortEngagementsRepository.ts`

**Before:** `timeframesOlderThanQuery` was exported but never imported/used anywhere, and its join condition compared a column to itself (`timeframe.timeframe_start_date >= timeframe.timeframe_start_date`, always true) — a landmine if anyone ever "helpfully" wired it up as-is.

**Fix:** deleted the unused export.

---

## Verified but intentionally not changed (documented for a follow-up pass)

These were confirmed as real by one or both audit passes, but were judged too broad/risky to fix blindly without a DB/staging environment to validate against, or because they need a product/design decision. Recommended priority order for a follow-up:

| # | Issue | File | Why deferred |
|---|---|---|---|
| 1 | No pagination/streaming on list & GET-export endpoints (`GETExport/all`, `getTeamsWithStructure`, full-timeframe allocation reads, `/spend`) | `GETExport/routes.ts`, `team/teamRepository.ts`, `effort/allocation/effortAllocationsRepository.ts`, `spend/spendService.ts` | Needs an API-contract decision (page size, cursor vs offset) that affects UI callers too |
| 2 | `deleteEffort` runs 5 `DELETE` statements outside a transaction | `effort/effortRepository.ts` | Should be wrapped in `db.tx`; low risk but touches core write path, wants integration-test coverage against a real DB before merging |
| 3 | Concurrent `updateEffort` calls for the *same* `team_cost_id` can race (delete-then-insert, no row lock) | `effort/effortRepository.ts`, `effort/effortService.ts` | Needs a locking strategy decision (advisory lock vs `SELECT … FOR UPDATE` vs optimistic concurrency) |
| 4 | No HTTP timeouts on outbound calls (`superagentWrapper.ts`); OAuth token re-fetched on every call (`getToken.ts`); no `query_timeout` on the PG pool (`dbManager.ts`) | `util/superagentWrapper.ts`, `util/getToken.ts`, `db/dbManager.ts` | Timeout values should be tuned against real traffic, not guessed |
| 5 | PG pool `max: 200` (up to 800 across replicas) with `idleTimeoutMillis` reused as the request-duration budget | `db/dbManager.ts` | Needs coordination with infra on `max_connections`; changing blind risks connection exhaustion in prod |
| 6 | `getCurrentTimeFrameWithOffset` forces `date.setDate(2)` in local server time, which can pick the wrong month near boundaries/DST | `timeframe/timeFrameRepository.ts` | Behavior is relied upon by existing "current time frame" semantics; needs a date-handling design decision, not a one-line fix |
| 7 | `O(n×m)` `.find()`/`.filter()` lookups inside `.map()` in GET-export row assembly and effort entity assembly | `GETExport/personToInitiativeMapper.ts`, `effort/effortService.ts`, `costcalc/standardTeamCosting.ts` | Real but only matters at larger team counts; worth a dedicated perf pass with profiling rather than scattergun edits |
| 8 | Inconsistent success/error response shapes across routes (`{message}` vs empty body vs `res.sendStatus` vs raw payload) | multiple route files | This is an API contract change that affects every UI caller; needs to be coordinated with `eztrac-core-ui` (and any other consumers) rather than changed silently in this service alone |
| 9 | `GETExport` fetches independent data (initiatives, workdays, people, person-costing) mostly sequentially, and re-fetches near-static reference data (initiative hierarchy, person costing) on every export call with no caching | `GETExport/fullGetEntriesGenerator.ts`, `GETExport/personToInitiativeMapper.ts` | Real latency win, but touches the most business-critical export path; wants a dedicated pass with a real backend to compare before/after export output byte-for-byte, not a blind `Promise.all` refactor |
| 10 | `createPerson` has no upsert (`ON CONFLICT`), so concurrent requests creating the same new person can hit a unique-constraint error | `person/personRepository.ts` | Needs to confirm the desired conflict behavior (silently ignore vs. update vs. surface a specific error) against real usage patterns |
| 11 | Duplicated full-effort assembly logic between `effortService.ts` (uses `.filter()` per effort) and the already-Map-based `EffortRowSetsToEntity.parse` | `effort/effortService.ts`, `effort/effortRowSetsToEntity.ts` | Not a bug today, but a maintenance/drift risk; consolidating is a bigger refactor than a targeted fix |

---

## Validation summary

```text
tsc --noEmit -p tsconfig.json     → 0 errors
gts lint                          → 0 problems
npm run test (mocha)              → 205 passing (was 196 before this audit; +9 new regression tests), 0 failing
npm run build (tsc + gts lint)    → succeeds
```

No database, Vault, or external service access was available in this environment, so `npm run test:integration` was not run here — the unit suite (which mocks the DB layer) was used for all validation. **Recommend running `npm run test:integration` in CI/a real environment before merging**, especially for fix #5 (`updateEfforts`).
