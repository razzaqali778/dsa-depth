import sinon from 'sinon';
import {timeFrameRepository} from '../../../src/api/timeframe/timeFrameRepository';
import {eztracCostingClient} from '../../../src/util/client/eztracCostingClient';
import {effortRepository} from '../../../src/api/effort/effortRepository';
import {addEffortEngagements} from '../../../src/api/effort/engagement/effortEngagementService';
import {teamRepository} from '../../../src/api/team/teamRepository';
import {effortEngagementsRepository} from '../../../src/api/effort/engagement/effortEngagementsRepository';
import {effortAllocationsRepository} from '../../../src/api/effort/allocation/effortAllocationsRepository';
import {effortMembersRepository} from '../../../src/api/effort/members/effortMembersRepository';
import {
  getFullEffortEntitiesByTeamAndTimeFrames,
  updateEfforts,
} from '../../../src/api/effort/effortService';
import {expect} from 'chai';
import {EffortEngagement} from 'src/api/effort/engagement/models';
import {EffortEntity} from '../../../src/api/effort/models';

describe('Effort service', () => {
  const sandbox = sinon.createSandbox();

  const teamId = 'TEAM-ID';
  const startTimeFrame = 42301n;
  const endTimeFrame = 42302n;
  const engagement = {
    engagementId: 'ENGAGEMENT-UPDATE-ID',
    amount: 20n,
    comment: 'comment 123',
  } as EffortEngagement;

  beforeEach(() => {
    sandbox.stub(teamRepository, 'getTeamById').resolves({
      id: teamId,
      name: 'team',
      isActive: true,
      communityId: 'community',
    });
    sandbox
      .stub(timeFrameRepository, 'getTimeFrameIdsInRange')
      .resolves([startTimeFrame, endTimeFrame]);
    const getTimeFrameByIdStub = sandbox.stub(timeFrameRepository, 'getTimeFrameById');
    getTimeFrameByIdStub.onFirstCall().resolves({
      id: startTimeFrame,
      name: 'tf',
      startDate: Date.UTC(2023, 1, 1).toString(),
      endDate: Date.UTC(2023, 1, 31).toString(),
      lockdown: false,
      isActive: true,
    });
    getTimeFrameByIdStub.onSecondCall().resolves({
      id: startTimeFrame,
      name: 'tf2',
      startDate: Date.UTC(2023, 2, 1).toString(),
      endDate: Date.UTC(2023, 3, 0).toString(),
      lockdown: false,
      isActive: true,
    });
  });

  afterEach(() => sandbox.restore());

  describe('returns full effort entity', () => {
    it('by team and time frames', async () => {
      // Arrange
      const effortIds = [1n, 2n];
      const timeFrameIds = [42401n, 42402n];
      const engagementIds = ['eng123', 'eng345'];
      const teamId = 'team123';
      const initiativeId = 'init123';
      sandbox.stub(effortRepository, 'getEffortByTeamAndTimeframes').resolves([
        {id: effortIds[0], timeFrameId: timeFrameIds[0], teamId, cost: 100n},
        {id: effortIds[1], timeFrameId: timeFrameIds[1], teamId, cost: 200n},
      ]);
      sandbox.stub(effortEngagementsRepository, 'getEffortEngagementsByEffortIds').resolves([
        {
          effortId: effortIds[0],
          timeFrameId: timeFrameIds[0],
          teamId,
          amount: 100n,
          engagementId: engagementIds[0],
        },
        {
          effortId: effortIds[1],
          timeFrameId: timeFrameIds[1],
          teamId,
          amount: 50n,
          engagementId: engagementIds[1],
        },
      ]);
      sandbox.stub(effortAllocationsRepository, 'getAllocationsByEffortIds').resolves([
        {
          effortId: effortIds[0],
          timeFrameId: timeFrameIds[0],
          teamId,
          initiativeId: initiativeId,
          percentageOfTeamCost: 50n,
        },
      ]);
      sandbox.stub(effortMembersRepository, 'getMembersByEffortIds').resolves([
        {
          effortId: effortIds[1],
          timeFrameId: timeFrameIds[1],
          teamId,
          userId: 'user123',
          percent: 100,
        },
      ]);
      sandbox.stub(effortMembersRepository, 'getForecastedMembersByEffortIds').resolves([]);
      sandbox.stub(effortRepository, 'getEffortCostBreakdownsByEffortIds').resolves([
        {effortId: effortIds[0], costGroupId: '', cost: 100n, engagementId: engagementIds[0]},
        {effortId: effortIds[1], costGroupId: 'cost1', cost: 150n},
        {effortId: effortIds[1], costGroupId: '', cost: 50n, engagementId: engagementIds[1]},
      ]);

      // Act
      const fullEfforts = await getFullEffortEntitiesByTeamAndTimeFrames(teamId, timeFrameIds);

      // Assert
      expect(fullEfforts).to.have.deep.members([
        {
          id: effortIds[0],
          timeFrameId: timeFrameIds[0],
          teamId,
          allocations: [{initiativeId, percentageOfTeamCost: 50n}],
          members: [],
          forecastPeople: [],
          engagements: [{engagementId: engagementIds[0], amount: 100n}],
          costBreakdowns: [{costGroupId: '', cost: 100n, engagementId: engagementIds[0]}],
        },
        {
          id: effortIds[1],
          timeFrameId: timeFrameIds[1],
          teamId,
          allocations: [],
          members: [{userId: 'user123', percent: 100}],
          forecastPeople: [],
          engagements: [{engagementId: engagementIds[1], amount: 50n}],
          costBreakdowns: [
            {costGroupId: 'cost1', cost: 150n},
            {costGroupId: '', cost: 50n, engagementId: engagementIds[1]},
          ],
        },
      ]);
    });
  });

  it('updates engagement on an effort when effort exists', async () => {
    // Arrange
    const updateEffortStub = sandbox.stub(effortRepository, 'updateEffort');

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves([
      {
        teamId: teamId,
        timeFrameId: startTimeFrame,
        teamMemberCosts: [
          {
            costGroupId: '1',
            cost: 5n,
            engagementId: 'ENGAGEMENT-ID',
          },
          {
            costGroupId: '2',
            cost: engagement.amount!,
            engagementId: engagement.engagementId,
          },
        ],
      },
      {
        teamId: teamId,
        timeFrameId: endTimeFrame,
        teamMemberCosts: [
          {
            costGroupId: '2',
            cost: engagement.amount!,
            engagementId: engagement.engagementId,
          },
          {
            costGroupId: '3',
            cost: 20000n,
            engagementId: undefined,
          },
        ],
      },
    ]);

    // Act
    await addEffortEngagements(startTimeFrame, endTimeFrame, teamId, engagement, true);

    // Assert
    sinon.assert.callCount(updateEffortStub, 2);
  });

  it('updates engagement on an effort when effort does not exist', async () => {
    // Arrange
    const updateEffortStub = sandbox.stub(effortRepository, 'updateEffort');

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves([
      {
        teamId: teamId,
        timeFrameId: startTimeFrame,
        teamMemberCosts: [
          {
            costGroupId: '2',
            cost: engagement.amount!,
            engagementId: engagement.engagementId,
          },
        ],
      },
      {
        teamId: teamId,
        timeFrameId: endTimeFrame,
        teamMemberCosts: [
          {
            costGroupId: '2',
            cost: engagement.amount!,
            engagementId: engagement.engagementId,
          },
        ],
      },
    ]);

    // Act
    await addEffortEngagements(startTimeFrame, endTimeFrame, teamId, engagement, true);

    // Assert
    sinon.assert.callCount(updateEffortStub, 2);
    sinon.assert.calledWithExactly(updateEffortStub.getCall(0), {
      timeFrameId: startTimeFrame,
      teamId: teamId,
      engagements: [engagement],
      costBreakdowns: [
        {
          costGroupId: '2',
          cost: engagement.amount!,
          engagementId: engagement.engagementId,
        },
      ],
    });
    sinon.assert.calledWithExactly(updateEffortStub.getCall(1), {
      timeFrameId: endTimeFrame,
      teamId: teamId,
      engagements: [engagement],
      costBreakdowns: [
        {
          costGroupId: '2',
          cost: engagement.amount!,
          engagementId: engagement.engagementId,
        },
      ],
    });
  });

  describe('updateEfforts', () => {
    it('deletes empty efforts and does not re-create them via updateEffort when breakdowns are skipped', async () => {
      // Regression test: emptied-out efforts were previously passed to both deleteEffort AND
      // updateEffort when breakdownsHaveToBeUpdated=false (e.g. from updateEffortAllocations),
      // which re-created an empty team_cost row for an effort that had just been deleted.
      const deleteEffortStub = sandbox.stub(effortRepository, 'deleteEffort').resolves();
      const updateEffortStub = sandbox.stub(effortRepository, 'updateEffort').resolves(1n);

      const emptyEffort: EffortEntity = {
        id: 1n,
        timeFrameId: startTimeFrame,
        teamId,
        allocations: [],
        members: [],
        forecastPeople: [],
        engagements: [],
      };
      const nonEmptyEffort: EffortEntity = {
        id: 2n,
        timeFrameId: endTimeFrame,
        teamId,
        allocations: [{initiativeId: 'init123', percentageOfTeamCost: 100n}],
        members: [],
        forecastPeople: [],
        engagements: [],
      };

      const result = await updateEfforts([emptyEffort, nonEmptyEffort], false);

      sinon.assert.calledOnceWithExactly(deleteEffortStub, emptyEffort);
      sinon.assert.calledOnceWithExactly(updateEffortStub, nonEmptyEffort);
      expect(result).to.deep.eq([1n]);
    });
  });
});
