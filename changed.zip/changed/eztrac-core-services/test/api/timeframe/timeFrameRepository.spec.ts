import {container} from 'tsyringe';
import {AppContext} from '../../../src/api/AppContext';
import {timeFrameRepository} from '../../../src/api/timeframe/timeFrameRepository';
import {expect} from 'chai';
import chai from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';
import {
  addMonths,
  currentTimeFrame,
  futureTimeFrame,
  getTimeFrameStartAndEndDate,
  pastTimeFrame,
  seedTimeFrames,
  testData,
  timeFrames,
} from '../../common/dataSeed';
import {TimeFrame} from 'src/api/timeframe/models';
chai.use(require('chai-as-promised'));

// because pg-mem apparently converses bigint to number and it messes up the comparisons with expected data
const mapToBigint = (timeFrames: TimeFrame[]): TimeFrame[] =>
  timeFrames.map((tf: TimeFrame) => ({...tf, id: BigInt(tf.id)}));

describe('Time frame repository', () => {
  const futureButLockedTimeFrame = {
    id: 5n,
    name: 'Future but locked time frame',
    lockdown: true,
    isActive: false,
    ...getTimeFrameStartAndEndDate(addMonths(new Date(), 1)),
  };

  before(async () => {
    await setupCoreDatabase();
    const db = container.resolve(AppContext).db;
    await seedTimeFrames(db, [futureButLockedTimeFrame]);
  });

  it('Returns all time frames', async () => {
    // Act
    const resultTimeFrames = await timeFrameRepository.getTimeFrames();

    // Assert
    expect(mapToBigint(resultTimeFrames)).to.have.deep.members([
      ...timeFrames,
      futureButLockedTimeFrame,
    ]);
  });

  it('Returns current time frame', async () => {
    // Act
    const resultTimeFrame = await timeFrameRepository.getCurrentTimeFrameWithOffset(0);

    // Assert
    expect(mapToBigint([resultTimeFrame!])[0]).to.deep.equal(currentTimeFrame);
  });

  it('Returns current time frame with offset', async () => {
    // Arrange
    const offset = 12;

    // Act
    const resultTimeFrame = await timeFrameRepository.getCurrentTimeFrameWithOffset(offset);

    // Assert
    expect(mapToBigint([resultTimeFrame!])[0]).to.deep.equal(futureTimeFrame);
  });

  it('Returns all non-historic timeFrames', async () => {
    // Act
    const resultTimeFrames = await timeFrameRepository.getNonHistoricTimeFrames();

    // Assert
    expect(mapToBigint(resultTimeFrames)).to.have.deep.members([
      currentTimeFrame,
      futureButLockedTimeFrame,
      futureTimeFrame,
    ]);
  });

  it('Returns time frame ids in given range', async () => {
    // Arrange
    const startTimeFrameId = pastTimeFrame.id;
    const endTimeFrameId = futureTimeFrame.id;

    // Act
    const resultTimeFrameIds = await timeFrameRepository.getTimeFrameIdsInRange(
      startTimeFrameId,
      endTimeFrameId
    );

    // Assert
    expect(resultTimeFrameIds.map(id => BigInt(id))).to.have.members(
      [pastTimeFrame, currentTimeFrame, futureButLockedTimeFrame, futureTimeFrame].map(tf => tf.id)
    );
  });

  it('Returns time frame with given id', async () => {
    // Arrange
    const id = futureButLockedTimeFrame.id;

    // Act
    const resultTimeFrame = await timeFrameRepository.getTimeFrameById(id);

    // Assert
    expect(mapToBigint([resultTimeFrame!])[0]).to.deep.equal(futureButLockedTimeFrame);
  });

  it('Returns time frame with given ids', async () => {
    // Arrange
    const ids = [futureButLockedTimeFrame, currentTimeFrame, pastTimeFrame].map(tf => tf.id);

    // Act
    const resultTimeFrames = await timeFrameRepository.getTimeFramesByIds(ids);

    // Assert
    expect(mapToBigint(resultTimeFrames!)).to.have.deep.members([
      futureButLockedTimeFrame,
      currentTimeFrame,
      pastTimeFrame,
    ]);
  });

  it('Returns workdays data by given time frame id and country', async () => {
    // Arrange
    const timeFrameId = currentTimeFrame.id;
    const country = 'US';

    // Act
    const resultWorkdays = await timeFrameRepository.getWorkdaysByTimeFrameIdAndCountry(
      timeFrameId,
      country
    );

    // Assert

    // maybe it could be refactored after adding tests to GET report export? It feels like it shouldn't be this complicated
    const timeFrameWorkdays = testData.workdays.find(
      wd => wd.timeframeId === timeFrameId && wd.country === country
    );
    const expectedWorkdays = JSON.parse(timeFrameWorkdays?.workdayHours ?? '').map(
      (wd: {day: string; hours: number}) => {
        const date = new Date(wd.day);
        date.setUTCHours(12);
        return {
          date: date,
          hours: wd.hours,
        };
      }
    );

    expect(resultWorkdays).to.have.deep.members(expectedWorkdays);
  });

  it('Returns an empty array (not a crash) when no workdays are configured for the time frame/country', async () => {
    // Regression test: this used to dereference a null DB row and throw a TypeError.
    const resultWorkdays = await timeFrameRepository.getWorkdaysByTimeFrameIdAndCountry(
      currentTimeFrame.id,
      'ZZ-UNKNOWN-COUNTRY'
    );

    expect(resultWorkdays).to.deep.eq([]);
  });

  it('Returns an empty array (not a crash) when workday JSON is malformed', async () => {
    const db = container.resolve(AppContext).db;
    await db.none(
      `INSERT INTO public.timeframe_workdays (timeframe_id, country, workday_hours)
       VALUES ($<timeFrameId>, $<country>, $<workdayHours>)`,
      {
        timeFrameId: currentTimeFrame.id,
        country: 'BAD-JSON',
        workdayHours: '{not-json',
      }
    );

    const resultWorkdays = await timeFrameRepository.getWorkdaysByTimeFrameIdAndCountry(
      currentTimeFrame.id,
      'BAD-JSON'
    );

    expect(resultWorkdays).to.deep.eq([]);
  });

  it('Returns given time frames and all future time frames ids', async () => {
    // Arrange
    const id = futureButLockedTimeFrame.id;

    // Act
    const resultTimeFrameIds = await timeFrameRepository.getTimeFrameAndAllFutureTimeFrameIds(id);

    // Assert
    expect(resultTimeFrameIds.map(id => BigInt(id))).to.have.members(
      [futureButLockedTimeFrame, futureTimeFrame].map(tf => tf.id)
    );
  });

  it('Sets lockdown status on given time frame', async () => {
    // Arrange
    const id = futureButLockedTimeFrame.id;
    const timeFrameToBeModified = await timeFrameRepository.getTimeFrameById(id);
    const lockdownStatus = !timeFrameToBeModified?.lockdown;

    // Act
    await timeFrameRepository.setTimeFrameLockdownStatus(id, lockdownStatus);

    // Assert
    const modifiedTimeFrame = await timeFrameRepository.getTimeFrameById(id);
    expect(modifiedTimeFrame?.lockdown).to.equal(lockdownStatus);
  });
});
