import {expect} from 'chai';
import chai from 'chai';
import sinon from 'sinon';
import {HealthCheck} from '../../../src/api/healthcheck/models';
import {eztracVipClient} from '../../../src/util/client/eztracVipClient';
import {
  checkEffortForErrors,
  checkEffortsInternal,
  emptyEffortError,
  noCostsError,
  forecastPeopleError,
  allocationsNot100Error,
  initiativeCompletedError,
  initiativeInPlanningError,
} from '../../../src/api/healthcheck/effortHealthCheck';
import {
  completedInit1,
  completedInit2,
  effortEntities,
  initiativeHierarchy,
  initMap,
  planningInit1,
  planningInit2,
  team1,
  team2,
  team3,
  teams,
  timeFrames,
} from './healthCheckTestData';

chai.use(require('chai-as-promised'));

describe('EffortHealthCheck unit tests', () => {
  const sandbox = sinon.createSandbox();
  before(async () => {
    sandbox.stub(eztracVipClient, 'getInitiativeHierarchy').resolves(initiativeHierarchy);
  });
  after(() => {
    sandbox.restore();
  });

  it('returns an empty list of errors if there are no health check errors', () => {
    const effort = effortEntities[0];
    const expected: String[] = [];
    const result = checkEffortForErrors(timeFrames[0], initMap, effort);
    expect(result).to.deep.equal(expected);
  });

  it('generates an error if team has no initiatives or costs (people, forecast people, or engagements)', () => {
    // Note: Doesn't generate allocations not 100 error
    const effort = effortEntities[1];
    const expected = [emptyEffortError];
    const result = checkEffortForErrors(timeFrames[0], initMap, effort);
    expect(result).to.deep.equal(expected);
  });

  it('generates an error if team has no cost (but has allocations)', () => {
    const effort = effortEntities[2];
    const expected = [noCostsError];
    const result = checkEffortForErrors(timeFrames[0], initMap, effort);
    expect(result).to.deep.equal(expected);
  });

  it("generates an error if team still has forecast people on it and it's not a future month", () => {
    const effort = effortEntities[3];
    const expected = [forecastPeopleError];
    const result = checkEffortForErrors(timeFrames[0], initMap, effort);
    expect(result).to.deep.equal(expected);
  });

  it("doesn't generate an error if team still has forecast people on it but it's a future month", () => {
    const effort = effortEntities[4];
    const expected: String[] = [];
    const result = checkEffortForErrors(timeFrames[1], initMap, effort);
    expect(result).to.deep.equal(expected);
  });

  it("generates an error if allocations don't add up to 100%", () => {
    const effort = effortEntities[5];
    const allocPct = effort.allocations?.reduce(
      (sum, current) => sum + BigInt(current.percentageOfTeamCost),
      0n
    );
    const expected = allocPct ? [allocationsNot100Error(allocPct)] : allocationsNot100Error(0n);
    const result = checkEffortForErrors(timeFrames[0], initMap, effort);
    expect(result).to.deep.equal(expected);
  });

  it('generates errors for allocated initiatives that are in a completed state', () => {
    const effort = effortEntities[6];
    const expected = [
      initiativeCompletedError(completedInit1),
      initiativeCompletedError(completedInit2),
    ];
    const result = checkEffortForErrors(timeFrames[0], initMap, effort);
    expect(result).to.deep.equal(expected);
  });

  it('generates errors for allocated that are in a planning state in a non future month', () => {
    const effort = effortEntities[7];
    const expected = [
      initiativeInPlanningError(planningInit1),
      initiativeInPlanningError(planningInit2),
    ];
    const result = checkEffortForErrors(timeFrames[0], initMap, effort);
    expect(result).to.deep.equal(expected);
  });

  it("doesn't generates errors for allocated that are in a planning state in a future month", () => {
    const effort = effortEntities[8];
    const expected: String[] = [];
    const result = checkEffortForErrors(timeFrames[1], initMap, effort);
    expect(result).to.deep.equal(expected);
  });

  /* Effort Health Check, check multiple efforts */

  it("doesn't generate any health check error object if no errors exist on the efforts, single effort scenario", async () => {
    const effort = effortEntities[9];
    const expected: HealthCheck[] = [];
    const result = await checkEffortsInternal(timeFrames[0], teams, initMap, [effort]);
    return expect(result).to.deep.equal(expected);
  });

  it('generates a health check errors object if an effort has a health check error, single effort scenario', async () => {
    const effort = effortEntities[1];
    const expected: HealthCheck[] = [
      {
        timeFrameName: timeFrames[0].name,
        teamName: team1.teamName,
        teamId: team1.teamId,
        communityName: team1.communityName,
        platformName: team1.platformName,
        errors: [emptyEffortError],
      },
    ];
    const result = await checkEffortsInternal(timeFrames[0], teams, initMap, [effort]);
    return expect(result).to.deep.equal(expected);
  });

  it('generates a health check errors object for each effort that has errors', async () => {
    const goodEffort = effortEntities[0];
    const emptyEffort = effortEntities[10];
    const completedInitsEffort = effortEntities[11];
    const expected: HealthCheck[] = [
      {
        timeFrameName: timeFrames[0].name,
        teamName: team2.teamName,
        teamId: team2.teamId,
        communityName: team2.communityName,
        platformName: team2.platformName,
        errors: [emptyEffortError],
      },
      {
        timeFrameName: timeFrames[0].name,
        teamName: team3.teamName,
        teamId: team3.teamId,
        communityName: team3.communityName,
        platformName: team3.platformName,
        errors: [
          initiativeCompletedError(completedInit1),
          initiativeCompletedError(completedInit2),
        ],
      },
    ];
    const results = await checkEffortsInternal(timeFrames[0], teams, initMap, [
      goodEffort,
      emptyEffort,
      completedInitsEffort,
    ]);
    return expect(results).to.deep.equal(expected);
  });

  it('skips (rather than crashes on) an errored effort whose team is not in the given team list', async () => {
    // Regression test: previously used a non-null assertion (`team!.teamName`) on the result of
    // `teams.find(...)`, which throws if the effort's team isn't present (e.g. deactivated/removed).
    const orphanEffort = {...effortEntities[1], teamId: 'TEAM-NOT-IN-LIST'};
    const expected: HealthCheck[] = [];
    const result = await checkEffortsInternal(timeFrames[0], teams, initMap, [orphanEffort]);
    return expect(result).to.deep.equal(expected);
  });
});
