import {expect} from 'chai';
import {container} from 'tsyringe';
import {AppContext} from '../../../src/api/AppContext';
import {personRepository} from '../../../src/api/person/personRepository';
import {setupCoreDatabase} from '../../common/databaseSetup';
import {persons} from '../../common/dataSeed';

describe('Person repository', () => {
  before(async () => {
    await setupCoreDatabase();
  });

  it('ignores duplicate person creates without throwing', async () => {
    const existingPerson = persons[0];

    await personRepository.createPerson(existingPerson.id, 'Updated Name');

    const db = container.resolve(AppContext).db;
    const result = await db.one<{name: string}>(
      'SELECT name FROM public.person WHERE user_id = $<personId>',
      {personId: existingPerson.id}
    );

    expect(result.name).to.eq(existingPerson.name);
  });
});
