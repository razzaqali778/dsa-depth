import {
  getPersonAllocations,
  roundToDecimal,
} from '../../../src/api/GETExport/personToInitiativeMapper';
import {
  effort1,
  initiatives,
  people,
  personCostingData,
  teams,
  workdays,
} from './GETExportTestData';
import {expect} from 'chai';

describe('roundToDecimal', () => {
  it('rounds to 1 decimal place by default', () => {
    expect(roundToDecimal(1.24)).to.eq(1.2);
    expect(roundToDecimal(1.25)).to.eq(1.3);
  });
  it('rounds to the given number of decimal places', () => {
    // Regression test: the previous formula (`Math.round(x * 10 * digits) / 10 * digits`) only
    // happened to work for digits=1 and silently produced the wrong scale for any other value.
    expect(roundToDecimal(1.2345, 2)).to.eq(1.23);
    expect(roundToDecimal(1.239, 2)).to.eq(1.24);
  });
  it('rounds to a whole number when given 0 decimal digits', () => {
    expect(roundToDecimal(1.6, 0)).to.eq(2);
  });
});

describe('Map person hours to initiative hours', () => {
  it('returns person per initiative hours list ', () => {
    const expected = [
      {
        hours: 150,
        person: people[0],
        team: teams[0],
        initiative: initiatives.get(effort1.allocations[0].initiativeId),
        costingData: personCostingData[0],
      },
      {
        hours: 30,
        person: people[1],
        team: teams[0],
        initiative: initiatives.get(effort1.allocations[0].initiativeId),
        costingData: personCostingData[1],
      },
      {
        hours: 45,
        person: people[1],
        team: teams[0],
        initiative: initiatives.get(effort1.allocations[1].initiativeId),
        costingData: personCostingData[1],
      },
      {
        hours: 27,
        person: people[2],
        team: teams[0],
        initiative: initiatives.get(effort1.allocations[1].initiativeId),
        costingData: personCostingData[2],
      },
      {
        hours: 78,
        person: people[2],
        team: teams[0],
        initiative: initiatives.get(effort1.allocations[2].initiativeId),
        costingData: personCostingData[2],
      },
      {
        hours: 30,
        person: people[3],
        team: teams[0],
        initiative: initiatives.get(effort1.allocations[2].initiativeId),
        costingData: personCostingData[3],
      },
    ];
    const result = getPersonAllocations(
      [effort1],
      workdays,
      people,
      initiatives,
      teams,
      personCostingData
    );
    expect(result).to.deep.equal(expected);
  });
  it('returns person per initiative hours list with uknown values filled in', () => {
    const notFoundValue = 'UNKNOWN';
    const effortWithUnknownProperties = {
      timeFrameId: 42201n,
      teamId: 'unknownTeam',
      allocations: [
        {
          effortId: 1n,
          initiativeId: 'uknownInitiative',
          percentageOfTeamCost: 100n,
        },
      ],
      members: [
        {
          userId: 'uknownUser',
          percent: 100,
        },
      ],
    };
    const expected = [
      {
        hours: 150,
        person: {
          id: effortWithUnknownProperties.members[0].userId,
          name: effortWithUnknownProperties.members[0].userId,
          manager: {name: notFoundValue},
        },
        team: {
          teamId: effortWithUnknownProperties.teamId,
          teamName: effortWithUnknownProperties.teamId,
          communityId: notFoundValue,
          communityName: notFoundValue,
          platformId: notFoundValue,
          platformName: notFoundValue,
          orgId: notFoundValue,
          orgName: notFoundValue,
          isActive: true,
        },
        initiative: {
          id: effortWithUnknownProperties.allocations[0].initiativeId,
          name: effortWithUnknownProperties.allocations[0].initiativeId,
          typeId: notFoundValue,
        },
        costingData: {
          personId: effortWithUnknownProperties.members[0].userId,
          personName: effortWithUnknownProperties.members[0].userId,
          costGroupName: notFoundValue,
          rateName: notFoundValue,
          isEmployee: false,
          isActive: true,
        },
      },
    ];
    const result = getPersonAllocations(
      [effortWithUnknownProperties],
      workdays,
      people,
      initiatives,
      teams,
      personCostingData
    );
    expect(result).to.deep.equal(expected);
  });
});
