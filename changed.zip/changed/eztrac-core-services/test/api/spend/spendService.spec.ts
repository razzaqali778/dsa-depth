import {expect} from 'chai';
import chai from 'chai';
import {EffortCostBreakdown} from '../../../src/api/effort/models';
import {EffortAllocation} from '../../../src/api/effort/allocation/models';
import sinon from 'sinon';
import {container} from 'tsyringe';
import {AppContext} from '../../../src/api/AppContext';
import {buildRepositories} from '../../common/baseBuilders';
import {
  getEffortsSpendInTimeRange,
  getTeamCostSpendFactsInTimeRange,
} from '../../../src/api/spend/spendService';
import _ from 'lodash';

chai.use(require('chai-as-promised'));

const costGroupId = 'costGroupId';

function registerRepositories(
  effortAllocations: EffortAllocation[],
  effortCostBreakdowns: EffortCostBreakdown[]
) {
  const effortRepository = {
    getEffortCostBreakdowns: () => {
      return Promise.resolve(effortCostBreakdowns);
    },
  };
  const effortAllocationsRepository = {
    getEffortAllocationsByTimeRange: () => {
      return Promise.resolve(effortAllocations);
    },
  };
  container.register('Repositories', {
    useValue: buildRepositories(effortRepository, {}, {}, effortAllocationsRepository, {}, {}),
  });
}
const engagementId = 'engagementId';

describe('Spend service', () => {
  before(async () => {
    const dbMock = sinon.mock();
    container.register('Database', {
      useValue: dbMock,
    });
    container.register('AppContext', {
      useClass: AppContext,
    });
  });

  it('The sum of line item spending is equal to cost breakdowns (assuming all efforts have 100% allocation)', async () => {
    const effortCostBreakdowns: EffortCostBreakdown[] = [
      {
        effortId: 1n,
        costGroupId: costGroupId,
        cost: 120n,
        engagementId: engagementId,
      },
      {
        effortId: 1n,
        costGroupId: costGroupId,
        cost: 10n,
        engagementId: engagementId,
      },
      {
        effortId: 1n,
        costGroupId: costGroupId,
        cost: 100n,
        engagementId: engagementId,
      },
      {
        effortId: 2n,
        costGroupId: costGroupId,
        cost: 100n,
        engagementId: engagementId,
      },
    ];
    const effortAllocations: EffortAllocation[] = [
      {
        effortId: 1n,
        timeFrameId: 1n,
        teamId: 'team1',
        initiativeId: 'initiative1',
        percentageOfTeamCost: 50n,
      },
      {
        effortId: 1n,
        timeFrameId: 1n,
        teamId: 'team1',
        initiativeId: 'initiative2',
        percentageOfTeamCost: 50n,
      },
      {
        effortId: 2n,
        timeFrameId: 2n,
        teamId: 'team2',
        initiativeId: 'initiative',
        percentageOfTeamCost: 100n,
      },
    ];
    registerRepositories(effortAllocations, effortCostBreakdowns);

    const result = await getEffortsSpendInTimeRange(1n, 3n);
    const expectedSpend = effortCostBreakdowns.reduce(
      (sum, current) => sum + Number(current.cost),
      0
    );
    const initiativeSpend = result.reduce(
      (sum, current) =>
        sum + Number(current.initiatives.reduce((sum, current) => sum + Number(current.spend), 0)),
      0
    );
    expect(initiativeSpend).to.eq(expectedSpend);
  });
  it('The spend associated to initiatives must be proportional to their allocation percentage', async () => {
    const initiative1 = 'initiative1';
    const initiative2 = 'initiative2';
    const initiative3 = 'initiative3';
    const basePercentage = 10n;
    const multiplier1 = 1n;
    const multiplier2 = 2n;
    const multiplier3 = 3n;
    const multiplier4 = 4n;
    const partialBreakdown = {
      costGroupId: costGroupId,
      cost: 100n,
      engagementId: engagementId,
    };
    const baseCost = (partialBreakdown.cost * basePercentage) / 100n;
    const effortCostBreakdowns: EffortCostBreakdown[] = [
      {
        ...partialBreakdown,
        effortId: 1n,
      },
      {
        ...partialBreakdown,
        effortId: 2n,
      },
      {
        ...partialBreakdown,
        effortId: 3n,
      },
      {
        ...partialBreakdown,
        effortId: 4n,
      },
    ];
    const effortAllocations: EffortAllocation[] = [
      {
        effortId: 1n,
        timeFrameId: 1n,
        teamId: 'team1',
        initiativeId: initiative1,
        percentageOfTeamCost: basePercentage * multiplier1,
      },
      {
        effortId: 2n,
        timeFrameId: 2n,
        teamId: 'team1',
        initiativeId: initiative2,
        percentageOfTeamCost: basePercentage * multiplier2,
      },
      {
        effortId: 3n,
        timeFrameId: 2n,
        teamId: 'team2',
        initiativeId: initiative3,
        percentageOfTeamCost: basePercentage * multiplier3,
      },
      {
        effortId: 4n,
        timeFrameId: 1n,
        teamId: 'team2',
        initiativeId: initiative3,
        percentageOfTeamCost: basePercentage * multiplier4,
      },
    ];
    registerRepositories(effortAllocations, effortCostBreakdowns);

    const result = await getEffortsSpendInTimeRange(1n, 3n);
    const initiativeCostMap = _.chain(result)
      .flatMap(r => r.initiatives)
      .groupBy(i => i.initiativeId)
      .map((spending, initiativeId) => {
        return {
          initiative: initiativeId,
          spend: spending.reduce((sum, current) => sum + current.spend, 0n),
        };
      })
      .reduce(
        (map, current) => map.set(current.initiative, current.spend),
        new Map<string, bigint>()
      )
      .value();
    expect(initiativeCostMap.get(initiative1)).to.eq(baseCost * multiplier1);
    expect(initiativeCostMap.get(initiative2)).to.eq(baseCost * multiplier2);
    expect(initiativeCostMap.get(initiative3)).to.eq(
      baseCost * multiplier3 + baseCost * multiplier4
    );
  });
  it('The spend associated to a cost group/engagement pair must be proportional to the cost breakdowns of each group/engagement', async () => {
    const costGroup1 = 'costGroup1';
    const costGroup2 = 'costGroup2';
    const baseCost = 100n;
    const multiplier1 = 1n;
    const multiplier2 = 2n;
    const multiplier3 = 3n;
    const partialEffortAllocation = {
      teamId: 'team1',
      initiativeId: 'initiative1',
      percentageOfTeamCost: 100n,
    };
    const effortCostBreakdowns: EffortCostBreakdown[] = [
      {
        effortId: 1n,
        costGroupId: costGroup1,
        cost: baseCost * multiplier1,
      },
      {
        effortId: 2n,
        costGroupId: costGroup2,
        cost: baseCost * multiplier2,
      },
      {
        effortId: 2n,
        costGroupId: costGroup2,
        cost: baseCost * multiplier3,
        engagementId: engagementId,
      },
    ];
    const key1 = `${effortCostBreakdowns[0].costGroupId};`;
    const key2 = `${effortCostBreakdowns[1].costGroupId};`;
    const key3 = `${effortCostBreakdowns[2].costGroupId};${effortCostBreakdowns[2].engagementId}`;

    const effortAllocations: EffortAllocation[] = [
      {
        ...partialEffortAllocation,
        effortId: 1n,
        timeFrameId: 1n,
      },
      {
        ...partialEffortAllocation,
        effortId: 2n,
        timeFrameId: 2n,
      },
    ];
    registerRepositories(effortAllocations, effortCostBreakdowns);

    const result = await getEffortsSpendInTimeRange(1n, 3n);
    const costGroupSpendMap = _.chain(result)
      .flatMap(r => r.initiatives)
      .flatMap(i => i.lineItems)
      .groupBy(li => `${li.costGroupId};${li.engagementId}`)
      .map((lineItems, key) => {
        return {
          key: key,
          spend: lineItems.reduce((sum, current) => sum + current.spend, 0n),
        };
      })
      .reduce((map, current) => map.set(current.key, current.spend), new Map<string, bigint>())
      .value();
    expect(costGroupSpendMap.get(key1)).to.eq(baseCost * multiplier1);
    expect(costGroupSpendMap.get(key2)).to.eq(baseCost * multiplier2);
    expect(costGroupSpendMap.get(key3)).to.eq(baseCost * multiplier3);
  });
  it('Does not include initiatives with 0 percent allocation', async () => {
    const partialBreakdown = {
      costGroupId: costGroupId,
      cost: 100n,
      engagementId: engagementId,
    };
    const zeroAllocationInitiative = 'zeroAllocation';
    const effortCostBreakdowns: EffortCostBreakdown[] = [
      {
        ...partialBreakdown,
        effortId: 1n,
      },
      {
        ...partialBreakdown,
        effortId: 2n,
      },
    ];
    const effortAllocations: EffortAllocation[] = [
      {
        teamId: 'team1',
        initiativeId: 'initiative1',
        percentageOfTeamCost: 100n,
        effortId: 1n,
        timeFrameId: 1n,
      },
      {
        teamId: 'team1',
        initiativeId: zeroAllocationInitiative,
        percentageOfTeamCost: 0n,
        effortId: 2n,
        timeFrameId: 2n,
      },
    ];
    registerRepositories(effortAllocations, effortCostBreakdowns);

    const result = await getEffortsSpendInTimeRange(1n, 3n);
    const initiatives = _.chain(result)
      .flatMap(r => r.initiatives)
      .map(i => i.initiativeId)
      .value();
    expect(initiatives).to.not.contain(zeroAllocationInitiative);
  });
  it('Returns no spend instead of crashing when allocations have no cost breakdown rows', async () => {
    const effortAllocations: EffortAllocation[] = [
      {
        teamId: 'team1',
        initiativeId: 'initiative1',
        percentageOfTeamCost: 100n,
        effortId: 1n,
        timeFrameId: 1n,
      },
    ];
    registerRepositories(effortAllocations, []);

    const result = await getEffortsSpendInTimeRange(1n, 3n);

    expect(result).to.deep.eq([]);
  });
  it('Dedupes team/time frame ids before querying cost breakdowns, one allocation row per effort', async () => {
    const getEffortCostBreakdowns = sinon.stub().resolves([]);
    const effortAllocations: EffortAllocation[] = [
      {
        effortId: 1n,
        timeFrameId: 1n,
        teamId: 'team1',
        initiativeId: 'initiative1',
        percentageOfTeamCost: 50n,
      },
      // Same team/time frame as the row above, on a different effort - should not
      // duplicate the team/time frame ids passed to the cost breakdown query.
      {
        effortId: 1n,
        timeFrameId: 1n,
        teamId: 'team1',
        initiativeId: 'initiative2',
        percentageOfTeamCost: 50n,
      },
      {
        effortId: 2n,
        timeFrameId: 2n,
        teamId: 'team2',
        initiativeId: 'initiative3',
        percentageOfTeamCost: 100n,
      },
    ];
    const effortRepository = {getEffortCostBreakdowns};
    const effortAllocationsRepository = {
      getEffortAllocationsByTimeRange: () => Promise.resolve(effortAllocations),
    };
    container.register('Repositories', {
      useValue: buildRepositories(effortRepository, {}, {}, effortAllocationsRepository, {}, {}),
    });

    await getEffortsSpendInTimeRange(1n, 3n);

    expect(getEffortCostBreakdowns.calledOnce).to.eq(true);
    const [teamIds, timeFrameIds] = getEffortCostBreakdowns.firstCall.args;
    expect(teamIds).to.deep.equal(['team1', 'team2']);
    expect(timeFrameIds).to.deep.equal([1n, 2n]);
  });
  it('Returns flat spend facts for report row consumers', async () => {
    const effortCostBreakdowns: EffortCostBreakdown[] = [
      {
        effortId: 1n,
        costGroupId: costGroupId,
        cost: 100n,
        engagementId: engagementId,
      },
    ];
    const effortAllocations: EffortAllocation[] = [
      {
        effortId: 1n,
        timeFrameId: 1n,
        teamId: 'team1',
        initiativeId: 'initiative1',
        percentageOfTeamCost: 50n,
      },
    ];
    registerRepositories(effortAllocations, effortCostBreakdowns);

    const result = await getTeamCostSpendFactsInTimeRange(1n, 3n);

    expect(result).to.deep.equal([
      {
        timeFrameId: 1n,
        teamId: 'team1',
        initiativeId: 'initiative1',
        costGroupId: costGroupId,
        engagementId: engagementId,
        personId: '',
        spend: 50n,
      },
    ]);
  });
});
