import {expect} from 'chai';
import {isAdmin} from '../../src/util/security/isAdmin';

describe('IsAdmin function', () => {
  it('returns true if user has admin entitlement', () => {
    // Arrange
    const profileHeader = {
      id: 'testUser',
      entitlements: {
        eztrac: ['eztrac-admin-user'],
      },
    };

    // Act
    const isUserAdmin = isAdmin(JSON.stringify(profileHeader));

    // Assert
    expect(isUserAdmin).to.eq(true);
  });
  it('returns false if user has no eztrac entitlements', () => {
    // Arrange
    const profileHeader = {
      id: 'testUser',
      entitlements: {
        notEztrac: ['eztrac-admin-user'],
      },
    };

    // Act
    const isUserAdmin = isAdmin(JSON.stringify(profileHeader));

    // Assert
    expect(isUserAdmin).to.eq(false);
  });
  it('returns false if user has no admin entitlements', () => {
    // Arrange
    const profileHeader = {
      id: 'testUser',
      entitlements: {
        eztrac: ['not-eztrac-admin-user'],
      },
    };

    // Act
    const isUserAdmin = isAdmin(JSON.stringify(profileHeader));

    // Assert
    expect(isUserAdmin).to.eq(false);
  });
  it('returns false instead of throwing when the header is not valid JSON', () => {
    // Regression test: JSON.parse used to be unguarded, so a malformed/missing header
    // would throw a SyntaxError instead of being treated as "not an admin".
    expect(isAdmin('not valid json')).to.eq(false);
  });
  it('returns false instead of throwing when the header has no entitlements at all', () => {
    expect(isAdmin(JSON.stringify({id: 'testUser'}))).to.eq(false);
  });
});
