import 'reflect-metadata';
import {AppContext} from '../../src/api/AppContext';
import {IDatabase} from 'pg-promise';
import {container} from 'tsyringe';
import {EffortRepository, effortRepository} from '../../src/api/effort/effortRepository';
import {
  TimeframeRepository,
  timeFrameRepository,
} from '../../src/api/timeframe/timeFrameRepository';
import {AppRepositories} from '../../src/api/AppRepositories';
import {teamRepository, TeamRepository} from '../../src/api/team/teamRepository';
import {
  effortAllocationsRepository,
  EffortAllocationsRepository,
} from '../../src/api/effort/allocation/effortAllocationsRepository';
import {
  effortEngagementsRepository,
  EffortEngagementsRepository,
} from '../../src/api/effort/engagement/effortEngagementsRepository';
import {
  EffortMembersRepository,
  effortMembersRepository,
} from '../../src/api/effort/members/effortMembersRepository';
import {PersonRepository, personRepository} from '../../src/api/person/personRepository';
import {PlatformRepository, platformRepository} from '../../src/api/platform/platformRepository';
import {
  CommunityRepository,
  communityRepository,
} from '../../src/api/community/communityRepository';
import {OrgRepository, orgRepository} from '../../src/api/org/orgRepository';
import {SpendRepository, spendRepository} from '../../src/api/spend/spendRepository';

export const buildRepositories = (
  effortRepository: Partial<EffortRepository>,
  timeFrameRepository: Partial<TimeframeRepository>,
  teamRepository: Partial<TeamRepository>,
  effortAllocationsRepository: Partial<EffortAllocationsRepository>,
  effortEngagementsRepository: Partial<EffortEngagementsRepository>,
  effortMembersRepository: Partial<EffortMembersRepository>
): AppRepositories => ({
  timeFrameRepository: timeFrameRepository as TimeframeRepository,
  effortRepository: effortRepository as EffortRepository,
  teamRepository: teamRepository as TeamRepository,
  effortAllocationsRepository: effortAllocationsRepository as EffortAllocationsRepository,
  effortEngagementsRepository: effortEngagementsRepository as EffortEngagementsRepository,
  effortMembersRepository: effortMembersRepository as EffortMembersRepository,
  personRepository: personRepository as PersonRepository,
  platformRepository: platformRepository as PlatformRepository,
  communityRepository: communityRepository as CommunityRepository,
  orgRepository: orgRepository as OrgRepository,
  spendRepository: spendRepository as SpendRepository,
});

export function registerDependenciesWithDatabase(db: IDatabase<{}>) {
  container.register('Database', {
    useValue: db,
  });

  const appRepositories: AppRepositories = {
    effortRepository: effortRepository,
    timeFrameRepository: timeFrameRepository,
    teamRepository: teamRepository,
    effortAllocationsRepository: effortAllocationsRepository,
    effortEngagementsRepository: effortEngagementsRepository,
    effortMembersRepository: effortMembersRepository,
    personRepository: personRepository,
    platformRepository: platformRepository,
    communityRepository: communityRepository,
    orgRepository: orgRepository,
    spendRepository: spendRepository,
  };

  container.register('Repositories', {
    useValue: appRepositories,
  });

  container.register('AppContext', {
    useClass: AppContext,
  });
}
