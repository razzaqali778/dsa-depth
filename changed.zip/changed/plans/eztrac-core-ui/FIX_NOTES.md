# eztrac-core-ui Fix Notes

Date: 2026-07-26

## Fixed In Code

- Initiative month navigation now blocks only when there are real unsaved initiative changes.
- People change validators now return true when data changed, matching initiative validator semantics.
- Team tab switching and team switching now use the corrected people validator semantics.
- Failed people and initiative catalog fetches now dispatch empty data, unblocking sagas waiting on `setPeople` or `setInitiatives`.
- Team-data fetch now clears global loading in a `finally` block, including cancellation by `takeLatest`.
- People and initiative saves now use `takeLatest` to prevent overlapping duplicate saves.
- Initiative copy-forward now sends one multi-month allocation payload instead of dispatching many independent saves.
- Initiative monthly cost is read-only when the timeframe is not editable.
- Initiative and people tables now show empty states for empty months.
- Timeframe startup selection now guards against empty or mismatched timeframe lists.
- Responsive rules were added for main containers, people/initiative tables, and engagement cards.

## Already Fixed Before This Pass

- Profile hover error action was already corrected to `setUserProfileDetails`.
- Initiative table random remount via `uuid()` had already been removed.
- People table duplicate React key had already been changed to `personId`.
- Some hover timer, zero-team-cost, timeframe utility, and engagement responsive fixes were already present.

## Different From The Original Plan

- The plan suggested new server-side people and initiative typeahead endpoints. I did not replace the full catalog selects because that requires backend API work and UX changes.
- The plan suggested virtualization. I did not add a virtualization dependency in this pass because the workspace has no installed dependencies and this needs broader table QA.
- The plan suggested richer Save/Discard modal actions. I kept the current modal behavior and fixed the dirty-state bugs first.
- Copy-forward was fixed using the existing multi-timeframe allocation payload instead of waiting for a brand-new endpoint.

## Follow-Up Items

- Add async server-backed selects for people and allocable initiatives.
- Add virtualization for large people, initiative, forecast, and engagement lists.
- Replace global loading with domain-level loading flags.
- Add Save/Discard actions to the unsaved-data modal after product behavior is confirmed.
