# eztrac-core-ui Frontend Test Plan

Date: 2026-07-26

## Automated Tests

Run after installing dependencies:

```bash
npm install
npm run test:precommit
npm run lint
npm run build
```

The npm test scripts now use `cross-env`, so they run from Windows shells as well as Git Bash/WSL after dependencies are installed.

Focused tests to verify:

- `validatorsForPeople.spec.js`
- `fetchAllPeopleSaga.spec.js`
- `fetchInitiativesSaga.spec.js`
- `copyInitiativesForwardSaga.spec.js`
- `updatePeopleSaga.spec.js`
- `updateInitiativesSaga.spec.js`
- `fetchTeamDataSaga.spec.js`

## Manual Functional Checks

- Open a team, go to Initiatives, make no changes, and switch months. It should switch without showing the unsaved-data modal.
- Change an initiative allocation, then switch months. It should show the unsaved-data modal and should not navigate away.
- Save changed initiative allocations. The save should run once and refresh team data.
- Use Copy Forward for initiatives to multiple future months. All chosen months should receive the copied allocation data.
- Open People, make no changes, and switch months. It should switch without the unsaved-data modal.
- Change a person or forecasted person value, then switch tabs/team/month. It should show the unsaved-data modal.
- Click Save repeatedly on People and Initiatives. Only the latest save should win, and loading should clear.
- Simulate failed people or initiative catalog calls. Dependent team data sagas should not hang forever.
- Open a locked/non-editable timeframe. Initiative monthly cost should display as text, not an input.

## Manual UI Checks

- Test desktop width around 1440 px: existing table layout should remain usable.
- Test tablet width around 1024 px: people and initiative panels should stack and table overflow should scroll inside the panel.
- Test mobile width around 390 px: month controls should wrap without overlapping, and engagement cards should be single column.
- Check empty months for Initiatives and People. The table should show a clear empty row rather than a blank area.
- Hover person and initiative info icons. Existing details popovers should still appear and not leave stale loading text.

## Validation Blocker In This Workspace

Dependency installation is blocked by npm authentication. `npm ci` reaches the registry and then fails with `E401 Incorrect or missing password`; `npm whoami` reports that this machine is not logged in. After npm credentials are refreshed, rerun `npm ci` and the automated commands above.
