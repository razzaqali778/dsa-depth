# eztrac-core-services Fix Notes

Date: 2026-07-26

## Fixed In Code

- Current timeframe lookup now uses a UTC target month date and inclusive timeframe bounds, avoiding boundary-month drift.
- Workday lookup now returns an empty list for missing or malformed workday configuration instead of crashing GET export.
- Spend fallback now handles allocations with no cost breakdown rows without throwing.
- Person creation is idempotent with `ON CONFLICT (user_id) DO NOTHING`, reducing concurrent write races.
- Outbound superagent calls now have response and deadline timeouts.
- JSON request body limit was reduced from 50 MB to 5 MB.
- Standard recost now deletes breakdowns for every effort in scope, including efforts whose new costing result is zero rows.
- Standard recost now uses bounded timeframe concurrency instead of unbounded `Promise.all`.
- Full effort hydration now pre-groups child rows by effort id instead of repeatedly scanning arrays.
- Health check effort loading now batch-loads only the checked teams for the requested timeframe.
- GET export now runs independent workday, people, and costing-data calls in parallel where possible.
- Added hot-path indexes for team/timeframe and child-table joins.

## Already Fixed Before This Pass

- Delete engagement authorization for future closed timeframes was already present.
- Admin header JSON parsing was already guarded.
- Error middleware no longer forwards after sending a 500 response.
- Some health-check batching and workday null handling had already been partially applied.

## Different From The Original Plan

- The plan suggested caching VIP/PAPI data for GET export. I did not add TTL caching in this pass because it can change freshness semantics; only safe parallelization was added.
- The plan suggested mandatory pagination/search contracts for several endpoints. Those require API and UI contract changes, so they remain follow-up work.
- Pool sizing and database statement timeouts were not changed because production pool requirements need environment confirmation.
- BigInt precision cleanup in spend serialization is still a follow-up. The immediate crash case was fixed.

## Follow-Up Items

- Add server-side pagination/typeahead for people, initiatives, engagements, and large effort reads.
- Profile the five slow endpoints from `PLAN.md` with `EXPLAIN ANALYZE` after applying the new indexes.
- Decide whether GET export can use a short TTL cache without violating freshness expectations.
- Add statement timeout and right-sized pool values through environment configuration.
