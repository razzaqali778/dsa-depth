# eztrac-core-services Backend Test Plan

Date: 2026-07-26

## Automated Tests

Run after installing dependencies:

```bash
npm install
npm run compile
npm run test:precommit
```

Focused regression coverage added or expected:

- Spend fallback returns `[]` when allocations exist but no cost breakdowns exist.
- Workday lookup returns `[]` for malformed JSON.
- Person duplicate creation does not throw or overwrite the existing row.
- Recost deletes stale breakdown rows when the new cost result has no replacement rows.

## Manual API Checks

- `GET /v2/timeframes/current` around the first and last day of a month should resolve the correct month.
- `GET /v2/spend/startTimeFrame/{id}/endTimeFrame/{id}` should return successfully when a team has allocations but zero cost breakdown rows.
- `PUT /v2/cost/standard-teams` should remove stale spend for efforts whose people/engagements were cleared.
- `GET /v2/healthCheck/efforts/timeFrameId/{id}` should return the same results as before, with fewer database round trips.
- `GET /v2/getExport/timeFrameId/{id}/all` should still match existing export totals.

## Performance Checks

- Run `EXPLAIN ANALYZE` for spend, full effort, health check, and GET export queries before and after the hot-path index migration.
- Confirm outbound costing/VIP/PAPI failures now stop at the configured timeout instead of hanging.
- Run standard recost against multiple active months and confirm concurrency does not overwhelm costing-services or Postgres.

## Validation Blocker In This Workspace

The validation scripts are now Windows-safe through `cross-env`, but dependency installation is blocked by npm authentication. `npm ci` reaches the registry and then fails with `E401 Incorrect or missing password`; `npm whoami` reports that this machine is not logged in. After npm credentials are refreshed, rerun `npm ci` and the automated commands above.
