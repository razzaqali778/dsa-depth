# Deprecated

Git hooks here are replaced by the shared Husky setup.

Use `eztrac-dev-tools/git-hooks/` instead — see that README, or copy from `eztrac-core-ui/.husky/`.
