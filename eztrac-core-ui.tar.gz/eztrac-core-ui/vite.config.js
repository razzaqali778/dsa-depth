import {defineConfig} from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
    plugins: [react()],
    base: '/ez-trac-core',
    css: {
        preprocessorOptions: {
            scss: {
                api: 'modern-compiler'
            }
        }
    },
    build: {
        outDir: 'package/public',
        commonjsOptions: {transformMixedEsModules: true}
    },
    esbuild: {
        supported: {
            destructuring: true
        }
    },
    optimizeDeps: {
        esbuildOptions: {
            supported: {
                destructuring: true
            }
        }
    },
    server: {
        host: 'localhost',
        port: 3035,
        // Ocelot (in Docker) proxies /ez-trac-core to this dev server via
        // host.docker.internal, so it must be an allowed host for Vite's
        // DNS-rebinding protection (Vite 5.4.12+/6.x).
        allowedHosts: ['host.docker.internal']
    },
    define: {
        APP_VERSION: JSON.stringify(process.env.npm_package_version),
        APP_BUILD_TIME: JSON.stringify(new Date().toISOString())
    }
})
