const packageJson = require('./package.json')

const config = {
    projectId: 'eaf368c9-27ac-433f-b476-959a0b75afcf',
    projectName: packageJson.name,
    contextRoot: 'ez-trac-core',
    team: 'WORKFORCE-DEV-ADMINS',
    pipelineClientId: 'fc5e8fa2-cae2-4b2b-a958-da09257cc72c',
    deployableVersion: packageJson.version,
    overwrite: true,
    quiet: true
}
module.exports = config
