module.exports = {
    extends: ['@bayerit/eslint-config-velocity/ui'],
    ignorePatterns: ['/package/*'],
    env: {
        browser: true
    },
    globals: {
        phoenix: 'readonly'
    }
}
