export const urls = {
    coreServices: 'https://ez-trac-core-services.velocity-np.ag',
    costingServices: 'https://ez-trac-costing-services.velocity-np.ag'
}
