import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import * as preferencesHelper from '../../../src/client/redux/sagas/helpers/preferences'
import {getFavoriteTeams} from '../../../src/client/redux/selectors'
import listener, {
    setFavoriteTeamsPreferences as saga
} from '../../../src/client/redux/sagas/preferences/setFavoriteTeamsPreferencesSaga'

describe('validates set preferences saga', () => {
    it('sets preferences', () => {
        const input = {
            payload: {
                teamId: 'teamId'
            }
        }
        const favoriteTeams = {
            'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW': 'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW'
        }
        const gen = saga(input)
        const step = (lastYield) => gen.next(lastYield).value

        const newFavoriteTeams = {...favoriteTeams, ...input.payload}
        const setPreferences = {
            payload: newFavoriteTeams,
            type: 'preferences/SET_FAVORITE_TEAMS_PREFERENCE'
        }

        preferencesHelper.setFavoriteTeamsPreference = jest.fn() // eslint-disable-line no-import-assign
        const {mock} = preferencesHelper.setFavoriteTeamsPreference

        expect(step()).toEqual(select(getFavoriteTeams))
        expect(step(favoriteTeams)).toEqual(dispatch(setPreferences))
        expect(gen.next().done).toEqual(true)
        expect(mock.calls[0][0]).toEqual('teamId')
        expect(mock.calls[0][1]).toEqual('teamId')
    })

    it('listens for the correct action fired', () => {
        const getSagaActions = (listen) => {
            const gen = listen()
            const step = (lastYield) => gen.next(lastYield).value

            return step()
        }
        const constants = ['preferences/FAVORITE_BUTTON_CLICKED']

        expect(getSagaActions(listener)).toEqual(takeLatest(constants, saga))
    })

    it('deletes the preference if it was already a favorite', () => {
        const input = {
            payload: {
                teamId: 'teamId'
            }
        }
        const favoriteTeams = {
            'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW': 'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW',
            teamId: 'teamId'
        }
        const gen = saga(input)
        const step = (lastYield) => gen.next(lastYield).value

        const newFavoriteTeams = {
            'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW': 'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW'
        }
        const setPreferences = {
            payload: newFavoriteTeams,
            type: 'preferences/SET_FAVORITE_TEAMS_PREFERENCE'
        }

        preferencesHelper.deleteFavoriteTeamsPreference = jest.fn() // eslint-disable-line no-import-assign
        const {mock} = preferencesHelper.deleteFavoriteTeamsPreference

        expect(step()).toEqual(select(getFavoriteTeams))
        expect(step(favoriteTeams)).toEqual(dispatch(setPreferences))
        expect(gen.next().done).toEqual(true)
        expect(mock.calls[0][0]).toEqual('teamId')
    })
})
