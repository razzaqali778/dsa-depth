import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {SET_PLATFORMS} from '../../../src/client/redux/constants/teamConstants'
import {get} from '../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../urlConsts'
import listener, {fetchPlatforms} from '../../../src/client/redux/sagas/teams/fetchPlatformsSaga'

const coreServicesUrl = urls.coreServices

describe('listener', () => {
    it('listens on FETCH_COMMUNITIES', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constant = ['team/FETCH_PLATFORMS']
        expect(step()).toEqual(takeLatest(constant, fetchPlatforms))
    })
})

describe('saga flow', () => {
    it('successfully fetches platforms', () => {
        const gen = fetchPlatforms()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${coreServicesUrl}/v2/platforms`

        const mockPlatforms = [
            {
                name: 'Finance'
            },
            {
                name: 'Field'
            }
        ]

        const setPlatformsAction = {
            type: SET_PLATFORMS,
            payload: mockPlatforms
        }

        const mockGetResult = {
            payload: mockPlatforms,
            error: false
        }

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setPlatformsAction))
        expect(gen.next().done).toBe(true)
    })
    it('displays a toastr error if it fails to fetch platforms', () => {
        const gen = fetchPlatforms()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${coreServicesUrl}/v2/platforms`

        const mockGetResult = {
            payload: 'error',
            error: true
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch platforms')

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
