// import { SET_IS_LOADING } from '../../../src/client/redux/constants'
import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../urlConsts'
import listener, {fetchTeams} from '../../../src/client/redux/sagas/teams/fetchTeamsSaga'

const coreServicesUrl = urls.coreServices

describe('listener', () => {
    it('listens only on FETCH_TEAMS', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['team/FETCH_TEAMS']

        expect(step()).toEqual(takeLatest(constants, fetchTeams))
    })
})

describe('saga flow', () => {
    it('happy path', () => {
        const gen = fetchTeams()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${coreServicesUrl}/v2/teams`
        const mockTeams = ['some', 'stuff']
        const setTeamsAction = {
            type: 'team/SET_TEAMS',
            payload: mockTeams
        }

        const mockGetResult = {
            payload: mockTeams,
            error: false
        }

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setTeamsAction))
        expect(gen.next().done).toBe(true)
    })
    it('bad path', () => {
        const gen = fetchTeams()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${coreServicesUrl}/v2/teams`

        const mockGetResult = {
            payload: 'It broke',
            error: true
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch teams')

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
