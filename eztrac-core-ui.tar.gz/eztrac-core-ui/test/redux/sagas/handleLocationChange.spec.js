import {put as dispatch, select, take, takeLatest} from 'redux-saga/effects'
import {SET_TEAMS} from '../../../src/client/redux/constants/teamConstants'
import {UPDATE_LOCATION} from '../../../src/client/redux/constants/locationConstants'
import actions from '../../../src/client/redux/actions'
import listener, {
    getTeams,
    handleLocationChange
} from '../../../src/client/redux/sagas/handleLocationChange'

const timeFrames = [
    {
        endDate: 1546300799000,
        id: 41812,
        isActive: true,
        lockdown: false,
        name: 'Dec 2018',
        startDate: 1543622400000
    },
    {
        endDate: 1548979199000,
        id: 41901,
        isActive: true,
        lockdown: false,
        name: 'Jan 2019',
        startDate: 1548979199000
    }
]
const state = {
    team: {
        teams: [
            {
                teamId: 'ELD-OCT-18'
            }
        ]
    }
}

describe('listener', () => {
    it('listens on UPDATE_LOCATION ', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [UPDATE_LOCATION]

        expect(step()).toEqual(takeLatest(constants, handleLocationChange))
    })
})

describe('handle location change saga flow', () => {
    it('handles first load with no incoming query params', () => {
        const action = {
            type: UPDATE_LOCATION,
            payload: {
                pathname: 'team',
                firstLoad: true,
                query: {}
            }
        }

        const {payload} = action
        const {pathname, query} = payload

        const gen = handleLocationChange(action)
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(dispatch(actions.setLocation({pathname, query})))
        expect(step(pathname)).toEqual(dispatch(actions.fetchTimeFrames()))
        expect(step(timeFrames)).toEqual(dispatch(actions.fetchTeams()))
        expect(step()).toEqual(dispatch(actions.fetchCommunities()))
        expect(step()).toEqual(dispatch(actions.fetchPlatforms()))
        expect(step()).toEqual(dispatch(actions.fetchOrgs()))
        expect(step()).toEqual(dispatch(actions.fetchEngagementOptions()))
        expect(step()).toEqual(dispatch(actions.fetchCalendars()))
        expect(step()).toEqual(dispatch(actions.fetchInitiatives()))
        expect(step()).toEqual(dispatch(actions.fetchPeople()))
        expect(step()).toEqual(dispatch(actions.fetchRates()))
        expect(step()).toEqual(dispatch(actions.fetchCostGroups()))
        expect(step()).toEqual(take(actions.setTimeFrames().type))
    })
    it('handles first load with incoming query params', () => {
        const action = {
            type: UPDATE_LOCATION,
            payload: {
                pathname: 'team',
                firstLoad: true,
                query: {
                    teamId: 'ELD-OCT-18',
                    teamTab: 'engagements'
                }
            }
        }

        const {payload} = action
        const {pathname, query} = payload

        const stringifyFunction = JSON.stringify(getTeams())
        const gen = handleLocationChange(action)
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(dispatch(actions.setLocation({pathname, query})))
        expect(step(pathname)).toEqual(dispatch(actions.fetchTimeFrames()))
        expect(step(timeFrames)).toEqual(dispatch(actions.fetchTeams()))
        expect(step()).toEqual(dispatch(actions.fetchCommunities()))
        expect(step()).toEqual(dispatch(actions.fetchPlatforms()))
        expect(step()).toEqual(dispatch(actions.fetchOrgs()))
        expect(step()).toEqual(dispatch(actions.fetchEngagementOptions()))
        expect(step()).toEqual(dispatch(actions.fetchCalendars()))
        expect(step()).toEqual(dispatch(actions.fetchInitiatives()))
        expect(step()).toEqual(dispatch(actions.fetchPeople()))
        expect(step()).toEqual(dispatch(actions.fetchRates()))
        expect(step()).toEqual(dispatch(actions.fetchCostGroups()))
        expect(step()).toEqual(take(actions.setTimeFrames().type))
        expect(JSON.stringify(step())).toEqual(stringifyFunction)
        expect(step(state.team.teams)).toEqual(
            dispatch(actions.setSelectedTeamFromUrl(state.team.teams.teamId))
        )
        expect(step()).toEqual(dispatch(actions.setSelectedTeamTab(query.teamTab)))
        expect(gen.next().done).toBe(true)
    })
})
describe.skip('getTeams saga/function flow', () => {
    it('successfully returns teams when none are present', () => {
        const gen = getTeams()
        const step = (lastYield) => gen.next(lastYield).value

        const action = {
            type: SET_TEAMS,
            payload: state.team.teams
        }

        expect(step()).toEqual(select(() => []))
        expect(step([])).toEqual(take(action.type))
        expect(step(action.payload)).toEqual(select(() => state.team.teams))
        expect(gen.next().done).toBe(true)
    })
    it('returns teams when they are present', () => {
        const gen = getTeams()
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(select(() => [{teamId: 'ELD-OCT-18'}]))
        expect(gen.next().done).toBe(true)
    })
})
