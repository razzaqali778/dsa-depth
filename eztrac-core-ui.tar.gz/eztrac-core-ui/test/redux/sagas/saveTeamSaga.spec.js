import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {
    SAVE_TEAM,
    SET_IS_EDITING,
    SET_SELECTED_TEAM,
    SET_TEAMS
} from '../../../src/client/redux/constants/teamConstants'
import {SET_IS_LOADING} from '../../../src/client/redux/constants'
import {getIsCreatingTeam, getTeams} from '../../../src/client/redux/selectors'
import {post, put} from '../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../urlConsts'
import listener, {saveTeam} from '../../../src/client/redux/sagas/teams/saveTeamSaga'

const coreServicesUrl = urls.coreServices

const setIsLoadingTrue = {
    type: SET_IS_LOADING,
    payload: true
}
const setIsLoadingFalse = {
    type: SET_IS_LOADING,
    payload: false
}
const setIsEditingFalse = {
    type: SET_IS_EDITING,
    payload: false
}

describe('save team saga', () => {
    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [SAVE_TEAM]

        expect(step()).toEqual(takeLatest(constants, saveTeam))
    })
    it('happy path replacing existing team', () => {
        const payload = {
            communityId: 'COMMUNITY-2',
            isActive: true,
            teamName: 'Empire Strikes Back Is The Best Star Wars',
            selectedTeamId: 'TEAM-ID'
        }

        const gen = saveTeam({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const teams = [
            {
                id: 'OTHER-TEAM-ID',
                name: 'Some Team Who Cares',
                communityId: 'COMMUNITY-1',
                isActive: true
            },
            {
                id: 'TEAM-ID',
                name: 'The Force Awakens Was Bad',
                communityId: 'COMMUNITY-1',
                isActive: true
            },
            {
                id: 'SOME-OTHER-TEAM-ID',
                name: 'Rogue One Was Great Too',
                communityId: 'COMMUNITY-1',
                isActive: true
            }
        ]

        const putOpts = {
            url: `${coreServicesUrl}/v2/team/TEAM-ID`,
            body: {
                id: 'TEAM-ID',
                name: 'Empire Strikes Back Is The Best Star Wars',
                isActive: true,
                communityId: 'COMMUNITY-2'
            }
        }

        const putResponse = {
            error: false,
            payload: {
                id: 'TEAM-ID',
                name: 'Empire Strikes Back Is The Best Star Wars',
                communityId: 'COMMUNITY-2'
            }
        }

        const updatedTeams = [
            {
                id: 'OTHER-TEAM-ID',
                name: 'Some Team Who Cares',
                communityId: 'COMMUNITY-1',
                isActive: true
            },
            {
                id: 'TEAM-ID',
                name: 'Empire Strikes Back Is The Best Star Wars',
                communityId: 'COMMUNITY-2',
                isActive: true
            },
            {
                id: 'SOME-OTHER-TEAM-ID',
                name: 'Rogue One Was Great Too',
                communityId: 'COMMUNITY-1',
                isActive: true
            }
        ]
        const updatedSelectedTeam = {
            id: 'TEAM-ID',
            name: 'Empire Strikes Back Is The Best Star Wars'
        }
        const setUpdatedTeams = {
            type: SET_TEAMS,
            payload: updatedTeams
        }
        const setSelectedTeamToUpdatedTeam = {
            type: SET_SELECTED_TEAM,
            payload: updatedSelectedTeam
        }
        const toastrSuccess = toastr.success('Successfully saved team')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getIsCreatingTeam))
        expect(step(false)).toEqual(call(put, putOpts))
        expect(step(putResponse)).toEqual(select(getTeams))
        expect(step(teams)).toEqual(dispatch(setUpdatedTeams))
        expect(step()).toEqual(dispatch(setSelectedTeamToUpdatedTeam))
        expect(step()).toEqual(dispatch(setIsLoadingFalse))
        expect(step()).toEqual(dispatch(setIsEditingFalse))
        expect(step(toastrSuccess))
        expect(gen.next().done).toBe(true)
    })
    it('happy path adding new team', () => {
        const payload = {
            communityId: 'COMMUNITY-2',
            isActive: true,
            teamName: 'I Bet Solo Will Be Bad',
            selectedTeamId: null
        }

        const gen = saveTeam({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const teams = [
            {
                id: 'OTHER-TEAM-ID',
                name: 'Some Team Who Cares',
                communityId: 'COMMUNITY-1',
                isActive: true
            },
            {
                id: 'TEAM-ID',
                name: 'The Force Awakens Was Bad',
                communityId: 'COMMUNITY-1',
                isActive: true
            },
            {
                id: 'SOME-OTHER-TEAM-ID',
                name: 'Rogue One Was Great Too',
                communityId: 'COMMUNITY-1',
                isActive: true
            }
        ]

        const postOpts = {
            url: `${coreServicesUrl}/v2/team`,
            body: {
                name: 'I Bet Solo Will Be Bad',
                isActive: true,
                communityId: 'COMMUNITY-2'
            }
        }

        const postResponse = {
            error: false,
            payload: {
                id: 'NEW-TEAM-ID',
                name: 'I Bet Solo Will Be Bad',
                communityId: 'COMMUNITY-1',
                isActive: true
            }
        }

        const updatedTeams = [
            {
                id: 'OTHER-TEAM-ID',
                name: 'Some Team Who Cares',
                communityId: 'COMMUNITY-1',
                isActive: true
            },
            {
                id: 'TEAM-ID',
                name: 'The Force Awakens Was Bad',
                communityId: 'COMMUNITY-1',
                isActive: true
            },
            {
                id: 'SOME-OTHER-TEAM-ID',
                name: 'Rogue One Was Great Too',
                communityId: 'COMMUNITY-1',
                isActive: true
            },
            {
                id: 'NEW-TEAM-ID',
                name: 'I Bet Solo Will Be Bad',
                communityId: 'COMMUNITY-2',
                isActive: true
            }
        ]
        const updatedSelectedTeam = {
            id: 'NEW-TEAM-ID',
            name: 'I Bet Solo Will Be Bad'
        }
        const setUpdatedTeams = {
            type: SET_TEAMS,
            payload: updatedTeams
        }
        const setSelectedTeamToUpdatedTeam = {
            type: SET_SELECTED_TEAM,
            payload: updatedSelectedTeam
        }

        const toastrSuccess = toastr.success('Successfully saved team')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getIsCreatingTeam))
        expect(step(true)).toEqual(call(post, postOpts))
        expect(step(postResponse)).toEqual(select(getTeams))
        expect(step(teams)).toEqual(dispatch(setUpdatedTeams))
        expect(step()).toEqual(dispatch(setSelectedTeamToUpdatedTeam))
        expect(step()).toEqual(dispatch(setIsLoadingFalse))
        expect(step()).toEqual(dispatch(setIsEditingFalse))
        expect(step(toastrSuccess))
        expect(gen.next().done).toBe(true)
    })
    it('sad path of errors', () => {
        const payload = {
            error: true,
            payload: {}
        }
        const gen = saveTeam({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const postOpts = {
            url: `${coreServicesUrl}/v2/team`,
            body: {
                name: undefined,
                isActive: undefined,
                communityId: undefined
            }
        }
        const postResponse = {
            error: true,
            url: `${coreServicesUrl}/v2/team`,
            body: {
                name: undefined,
                communityId: undefined,
                isActive: undefined
            }
        }

        const toastrError = toastr.error(postResponse.payload, 'Failed to save team')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getIsCreatingTeam))
        expect(step(true)).toEqual(call(post, postOpts))
        expect(step(postResponse)).toEqual(dispatch(setIsLoadingFalse))
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
