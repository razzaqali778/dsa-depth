import {call, put as dispatch} from 'redux-saga/effects'
import {SET_SORT_ORDER_PREFERENCE_PEOPLE_LOCAL} from '../../../src/client/redux/constants/preferencesConstants'
import {getPeopleSortOrderPreferenceServer} from '../../../src/client/redux/sagas/helpers/preferences'
import saga from '../../../src/client/redux/sagas/preferences/fetchPeopleSortOrderPreferencesSaga'

describe('fetchPeopleSortOrderPreferences', () => {
    it('fetches peopleSortOrderPreference and sets it in state', () => {
        const gen = saga()
        const step = (lastYield) => gen.next(lastYield).value

        const sortOrderPreference = {
            sort: {
                costGroupNum: 0,
                nameNum: 1,
                numberOfPeopleNum: 0,
                participationNum: 0,
                rateNum: 0
            }
        }

        const action = {
            type: SET_SORT_ORDER_PREFERENCE_PEOPLE_LOCAL,
            payload: sortOrderPreference.sort
        }

        expect(step()).toEqual(call(getPeopleSortOrderPreferenceServer))
        expect(step(sortOrderPreference)).toEqual(dispatch(action))
        expect(gen.next().done).toEqual(true)
    })
    it('fails to fetch peopleSortOrderPreference and returns default sort order', () => {
        const gen = saga()
        const step = (lastYield) => gen.next(lastYield).value

        const sortOrderPreference = {}

        const expectedSortOrderPreference = {
            costGroupNum: 0,
            nameNum: 1,
            numberOfPeopleNum: 0,
            participationNum: 0,
            rateNum: 0
        }
        const action = {
            type: SET_SORT_ORDER_PREFERENCE_PEOPLE_LOCAL,
            payload: expectedSortOrderPreference
        }
        expect(step()).toEqual(call(getPeopleSortOrderPreferenceServer))
        const sortOrderPreferenceStep = step(sortOrderPreference)
        expect(sortOrderPreferenceStep).toEqual(dispatch(action))
        expect(sortOrderPreferenceStep.PUT.action.payload).toEqual(expectedSortOrderPreference)
        expect(gen.next().done).toEqual(true)
    })
})
