import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {
    CLEAR_INITIATIVE_WARNINGS,
    SET_INITIATIVE_WARNINGS,
    UPDATE_INITIATIVE_WARNINGS
} from '../../../../src/client/redux/constants/initiativeConstants'
import {
    SET_END_TIME_FRAME,
    SET_SELECTED_TIME_FRAME_ID,
    SET_START_TIME_FRAME
} from '../../../../src/client/redux/constants/timeFramesConstants'
import {SET_TEAM_COST_DATA} from '../../../../src/client/redux/constants/teamConstants'
import {
    getEndTimeFrame,
    getSelectedTimeFrameId,
    getTeamCostData
} from '../../../../src/client/redux/selectors'
import {getTeamInitiatives} from '../../../../src/client/redux/selectors/initiatives'
import checkForCostData from '../../../../src/client/redux/utils/checkForCostData'
import getCurrentMonthTimeFrame from '../../../../src/client/redux/selectors/getCurrentMonthTimeFrame'
import getTimeFrames from '../../../../src/client/redux/sagas/takes/getTimeFrames'
import listener, {
    updateInitiativeWarnings
} from '../../../../src/client/redux/sagas/initiatives/updateInitiativeWarningsSaga'

jest.mock('../../../../src/client/redux/utils/checkForCostData')

const clearInitativeWarningsAction = {type: CLEAR_INITIATIVE_WARNINGS}

const setInitiativeWarningsAction = {
    type: SET_INITIATIVE_WARNINGS,
    payload: 'Warning! Total percent is under 100%'
}

const allTimeFrames = [
    {
        endDate: 1554076799000,
        id: 41903,
        isActive: true,
        lockdown: false,
        name: 'Mar 2019',
        startDate: 1551398400000
    },
    {
        endDate: 1556668799000,
        id: 41904,
        isActive: true,
        lockdown: false,
        name: 'Apr 2019',
        startDate: 1554076800000
    }
]

const currentMonthTimeFrame = {
    endDate: 1554076799000,
    id: 41903,
    isActive: true,
    lockdown: false,
    name: 'Mar 2019',
    startDate: 1551398400000
}

const timeFrameId = 41904

describe('listener for updateWarningSaga', () => {
    it('the saga is listening', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [
            UPDATE_INITIATIVE_WARNINGS,
            SET_TEAM_COST_DATA,
            SET_SELECTED_TIME_FRAME_ID,
            SET_START_TIME_FRAME,
            SET_END_TIME_FRAME
        ]

        expect(step()).toEqual(takeLatest(constants, updateInitiativeWarnings))
    })
})
describe('maps warning errors', () => {
    it('returns no warnings', () => {
        const gen = updateInitiativeWarnings()
        const step = (lastYield) => gen.next(lastYield).value
        const teamInitiatives = [
            {
                teamCostPct: 100,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
                timeFrameId: 41903,
                initiativeCost: 612000,
                teamCost: 612000,
                name: 'Velocity Field Support'
            },
            {
                teamCostPct: 100,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
                timeFrameId: 41904,
                initiativeCost: 612000,
                teamCost: 612000,
                name: 'Velocity Field Support'
            }
        ]

        expect(step()).toEqual(call(getTimeFrames))
        expect(step(allTimeFrames)).toEqual(select(getCurrentMonthTimeFrame))
        expect(step(currentMonthTimeFrame)).toEqual(select(getTeamInitiatives))
        expect(step(teamInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(timeFrameId)).toEqual(select(getTeamCostData))
        expect(step(getTeamCostData)).toEqual(select(getEndTimeFrame))
        expect(step()).toEqual(dispatch(clearInitativeWarningsAction))
        expect(gen.next().done).toBe(true)
    })
    it('returns warning if total percentage is under 100', () => {
        const gen = updateInitiativeWarnings()
        const step = (lastYield) => gen.next(lastYield).value
        const teamInitiatives = [
            {
                teamCostPct: 100,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
                timeFrameId: 41903,
                initiativeCost: 612000,
                teamCost: 612000,
                name: 'Velocity Field Support'
            },
            {
                teamCostPct: 90,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
                timeFrameId: 41904,
                initiativeCost: 612000,
                teamCost: 612000,
                name: 'Velocity Field Support'
            }
        ]

        expect(step()).toEqual(call(getTimeFrames))
        expect(step(allTimeFrames)).toEqual(select(getCurrentMonthTimeFrame))
        expect(step(currentMonthTimeFrame)).toEqual(select(getTeamInitiatives))
        expect(step(teamInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(timeFrameId)).toEqual(select(getTeamCostData))
        expect(step(getTeamCostData)).toEqual(select(getEndTimeFrame))
        expect(step()).toEqual(dispatch(clearInitativeWarningsAction))
        expect(step()).toEqual(dispatch(setInitiativeWarningsAction))
        expect(gen.next().done).toBe(true)
    })
    it('returns a warning using currentMonthTime if selectedTimeFrame is not set', () => {
        const gen = updateInitiativeWarnings()
        const step = (lastYield) => gen.next(lastYield).value

        const teamInitiatives = [
            {
                teamCostPct: 90,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
                timeFrameId: 41903,
                initiativeCost: 612000,
                teamCost: 612000,
                name: 'Velocity Field Support'
            },
            {
                teamCostPct: 100,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
                timeFrameId: 41904,
                initiativeCost: 612000,
                teamCost: 612000,
                name: 'Velocity Field Support'
            }
        ]

        expect(step()).toEqual(call(getTimeFrames))
        expect(step(allTimeFrames)).toEqual(select(getCurrentMonthTimeFrame))
        expect(step(currentMonthTimeFrame)).toEqual(select(getTeamInitiatives))
        expect(step(teamInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(undefined)).toEqual(select(getTeamCostData))
        expect(step(getTeamCostData)).toEqual(select(getEndTimeFrame))
        expect(step()).toEqual(dispatch(clearInitativeWarningsAction))
        expect(step()).toEqual(dispatch(setInitiativeWarningsAction))
        expect(gen.next().done).toBe(true)
    })
    it('returns a warning message for missing cost data', () => {
        checkForCostData.mockImplementation(() => 'Warning!')

        const gen = updateInitiativeWarnings()
        const step = (lastYield) => gen.next(lastYield).value
        const teamInitiatives = [
            {
                teamCostPct: 100,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
                timeFrameId: 41903,
                initiativeCost: 612000,
                teamCost: 612000,
                name: 'Velocity Field Support'
            },
            {
                teamCostPct: 100,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
                timeFrameId: 41904,
                initiativeCost: 612000,
                teamCost: 612000,
                name: 'Velocity Field Support'
            }
        ]

        const setCostDataInitiativeWarning = {
            type: SET_INITIATIVE_WARNINGS,
            payload: 'Warning!'
        }

        expect(step()).toEqual(call(getTimeFrames))
        expect(step(allTimeFrames)).toEqual(select(getCurrentMonthTimeFrame))
        expect(step(currentMonthTimeFrame)).toEqual(select(getTeamInitiatives))
        expect(step(teamInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(timeFrameId)).toEqual(select(getTeamCostData))
        expect(step(getTeamCostData)).toEqual(select(getEndTimeFrame))
        expect(step()).toEqual(dispatch(clearInitativeWarningsAction))
        expect(step()).toEqual(dispatch(setCostDataInitiativeWarning))
        expect(gen.next().done).toBe(true)
    })
})
