import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {
    ADD_NEW_INITIATIVE,
    CLEAR_NEW_INITIATIVE_DATA,
    SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES
} from '../../../../src/client/redux/constants/initiativeConstants'
import {appendTimeFrameId} from '../../../../src/client/redux/utils/newInitiative'
import {
    getSelectedTimeFrameId,
    getSortOrderPreferenceLocal
} from '../../../../src/client/redux/selectors'
import {getSelectedTimeFrameTeamInitiatives} from '../../../../src/client/redux/selectors/initiatives'
import listener, {
    addNewInitiative
} from '../../../../src/client/redux/sagas/initiatives/addInitiativeSaga'

describe('addInitiative listener', () => {
    it('listens on the correct actions', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constant = ['initiatives/ADD_NEW_INITIATIVE']

        expect(step()).toEqual(takeLatest(constant, addNewInitiative))
    })
})
describe('addInitiative saga flow', () => {
    const selectedInitiativeFramework = {
        businessUnit: null,
        financeCodeType: null,
        financeCodeValue: null,
        teamCostPct: 100,
        parent_status: 'Planning',
        portfolioCode: null,
        region: null,
        timeFrameId: 41905,
        initiativeCost: 612000,
        isAllocable: true,
        isInheritable: true,
        status: 'Planning',
        typeId: 'EXP-INIT'
    }
    const selectedTimeFrameInitiatives = [
        {
            ...selectedInitiativeFramework,
            id: 'ee4a50c0-0214-11e9-a195-97d08e842820',
            parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef2',
            parentName: 'Anis Field Support',
            initiativeName: 'Anis Field Support'
        },
        {
            ...selectedInitiativeFramework,
            id: 'ee4a50c0-0214-11e9-a195-97d08e842821',
            parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef2',
            parentName: 'ASP Field Support',
            initiativeName: 'Companion Field Support'
        },
        {
            ...selectedInitiativeFramework,
            id: 'ee4a50c0-0214-11e9-a195-97d08e842822',
            parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef3',
            parentName: 'ASP Field Support',
            initiativeName: 'Velocity Field Support'
        }
    ]
    const selectedTimeFrameId = 41905
    const sortOrderPreferenceLocal = {
        allocationNum: 0,
        costNum: 0,
        nameNum: 1
    }
    const setSelectedTimeFrameTeamInitiativesAction = (value) => ({
        type: SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES,
        payload: value
    })
    const clearNewInitiativeDataAction = {
        type: CLEAR_NEW_INITIATIVE_DATA
    }
    const newSelectedTimeFrameInitiatives = (value) => [
        ...selectedTimeFrameInitiatives,
        appendTimeFrameId(value, selectedTimeFrameId)
    ]
    it('prints error to console when passed an empty payload', () => {
        const gen = addNewInitiative({})
        const step = (lastYield) => gen.next(lastYield).value
        const newInitiativeData = {
            value: {
                ...selectedInitiativeFramework,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842823',
                parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef4',
                parentName: 'ASP Field Support',
                initiativeName: 'Velocity Field Support'
            }
        }
        newSelectedTimeFrameInitiatives(newInitiativeData.value)

        expect(step(newInitiativeData)).toEqual(select(getSelectedTimeFrameTeamInitiatives))
        expect(step(selectedTimeFrameInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(gen.next().done).toBe(true)
    })
    it('adds an initiative when a row.id is not in the current array', () => {
        const newRow = {
            ...selectedInitiativeFramework,
            id: 'ee4a50c0-0214-11e9-a195-97d08e842825',
            parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef3',
            parentName: 'ASP Field Support',
            initiativeName: 'Velocity Field Support'
        }
        const action = {
            type: ADD_NEW_INITIATIVE,
            payload: newRow
        }
        const gen = addNewInitiative(action)
        const step = (lastYield) => gen.next(lastYield).value
        const expectedResult = newSelectedTimeFrameInitiatives(newRow)

        expect(step([])).toEqual(select(getSelectedTimeFrameTeamInitiatives))
        expect(step(selectedTimeFrameInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(select(getSortOrderPreferenceLocal))
        expect(step(sortOrderPreferenceLocal)).toEqual(
            dispatch(setSelectedTimeFrameTeamInitiativesAction(expectedResult))
        )
        expect(step()).toEqual(dispatch(clearNewInitiativeDataAction))
        expect(gen.next().done).toBe(true)
    })
    it('deletes the initiative from the array when the row.id is in the current array', () => {
        const deleteRow = {
            ...selectedInitiativeFramework,
            id: 'ee4a50c0-0214-11e9-a195-97d08e842822',
            parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef3',
            parentName: 'ASP Field Support',
            initiativeName: 'Velocity Field Support'
        }
        const action = {
            type: ADD_NEW_INITIATIVE,
            payload: deleteRow
        }
        const gen = addNewInitiative(action)
        const step = (lastYield) => gen.next(lastYield).value
        const expectedResult = [
            {
                ...selectedInitiativeFramework,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842820',
                parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef2',
                parentName: 'Anis Field Support',
                initiativeName: 'Anis Field Support'
            },
            {
                ...selectedInitiativeFramework,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842821',
                parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef2',
                parentName: 'ASP Field Support',
                initiativeName: 'Companion Field Support'
            }
        ]

        expect(step([])).toEqual(select(getSelectedTimeFrameTeamInitiatives))
        expect(step(selectedTimeFrameInitiatives)).toEqual(select(getSelectedTimeFrameId))

        expect(step(getSelectedTimeFrameId)).toEqual(
            dispatch(setSelectedTimeFrameTeamInitiativesAction(expectedResult))
        )
        expect(gen.next().done).toBe(true)
    })
})
