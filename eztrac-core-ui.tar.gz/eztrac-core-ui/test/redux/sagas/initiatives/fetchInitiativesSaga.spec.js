import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {SET_INITIATIVES} from '../../../../src/client/redux/constants/initiativeConstants'
import {get} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import listener, {
    fetchInitiatives
} from '../../../../src/client/redux/sagas/initiatives/fetchInitiativesSaga'

const url = `${window.phoenix.serviceBindings['ez-trac-vip']}/v2/initiatives?isAllocable=true&fields=parent,tags`

describe('fetchInitiatives listener', () => {
    it('listens on the correct actions', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constant = ['initiatives/FETCH_INITIATIVES']

        expect(step()).toEqual(takeLatest(constant, fetchInitiatives))
    })
})

describe('fetchInitiatives saga flow', () => {
    it('successfully fetches initiatives', () => {
        const gen = fetchInitiatives()
        const step = (lastYield) => gen.next(lastYield).value

        const mockInitiatives = [
            {
                businessUnit: null,
                financeCodeType: null,
                financeCodeValue: null,
                id: '6c71e61e-8e10-4585-a6f4-02c3e363d685',
                initiativeName: '1st Slice Universal Sequence Repository (AD)',
                isAllocable: true,
                isInheritable: true,
                parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                parentName: 'BIO',
                parent_status: null,
                portfolioCode: null,
                status: 'Completed',
                typeId: 'UNKOWN',
                region: null
            },
            {
                businessUnit: null,
                financeCodeType: null,
                financeCodeValue: null,
                id: '7c23d2f0-5067-4786-9f8e-b08655f3f939',
                initiativeName: '1st Slice Universal Sequence Repository Cap-Exp (AD)',
                isAllocable: true,
                isInheritable: true,
                parentId: '9d440c0c-5714-45c0-979b-57da1b26ab45',
                parentName: 'BIO Expense',
                parent_status: null,
                portfolioCode: null,
                status: 'Completed',
                typeId: 'UNKNOWN',
                region: null
            }
        ]

        const setInitiativesAction = {
            type: SET_INITIATIVES,
            payload: mockInitiatives
        }

        const mockGetResult = {
            payload: mockInitiatives,
            error: false
        }

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setInitiativesAction))
        expect(gen.next().done).toBe(true)
    })
    it('displays a toastr error if it fails to fetch initiatives', () => {
        const gen = fetchInitiatives()
        const step = (lastYield) => gen.next(lastYield).value

        const mockGetResult = {
            payload: 'error',
            error: true
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch initiatives')

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
