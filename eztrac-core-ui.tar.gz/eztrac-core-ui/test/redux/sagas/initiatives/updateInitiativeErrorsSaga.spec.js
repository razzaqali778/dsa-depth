import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {
    CLEAR_INITIATIVE_ERRORS,
    SET_INITIATIVE_ERRORS,
    UPDATE_INITIATIVE_ERRORS
} from '../../../../src/client/redux/constants/initiativeConstants'
import {SET_SELECTED_TIME_FRAME_ID} from '../../../../src/client/redux/constants/timeFramesConstants'
import {SET_TEAM_COST_DATA} from '../../../../src/client/redux/constants/teamConstants'
import {getSelectedTimeFrameId} from '../../../../src/client/redux/selectors'
import {getTeamInitiatives} from '../../../../src/client/redux/selectors/initiatives'
import getCurrentMonthTimeFrame from '../../../../src/client/redux/selectors/getCurrentMonthTimeFrame'
import listener, {
    updateInitiativeErrors
} from '../../../../src/client/redux/sagas/initiatives/updateInitiativeErrorsSaga'

const clearInitiativeErrorsAction = {type: CLEAR_INITIATIVE_ERRORS}

const setInitiativeErrorsAction = {
    type: SET_INITIATIVE_ERRORS,
    payload: "Error! Initiatives cannot be 'Planning' in the current month"
}

const currentMonthTimeFrame = {id: 41904}

const teamInitiatives = [
    {
        teamCostPct: 100,
        id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
        timeFrameId: 41904,
        initiativeCost: 612000,
        teamCost: 612000,
        name: 'Velocity Field Support',
        status: 'Funded'
    },
    {
        teamCostPct: 100,
        id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
        timeFrameId: 41904,
        initiativeCost: 612000,
        teamCost: 612000,
        name: 'Velocity Field Support',
        status: 'Planning'
    }
]

describe('listener for updateErrorSaga', () => {
    it('the saga is listening', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [UPDATE_INITIATIVE_ERRORS, SET_TEAM_COST_DATA, SET_SELECTED_TIME_FRAME_ID]

        expect(step()).toEqual(takeLatest(constants, updateInitiativeErrors))
    })
})
describe('maps errors', () => {
    it('returns no errors', () => {
        const gen = updateInitiativeErrors()
        const step = (lastYield) => gen.next(lastYield).value
        const selectedTimeFrameId = 41905

        expect(step()).toEqual(select(getCurrentMonthTimeFrame))
        expect(step(currentMonthTimeFrame)).toEqual(select(getTeamInitiatives))
        expect(step(teamInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(dispatch(clearInitiativeErrorsAction))
        expect(gen.next().done).toBe(true)
    })
    it('returns an error when an initiative is planning in the current month', () => {
        const gen = updateInitiativeErrors()
        const step = (lastYield) => gen.next(lastYield).value
        const selectedTimeFrameId = 41904

        expect(step()).toEqual(select(getCurrentMonthTimeFrame))
        expect(step(currentMonthTimeFrame)).toEqual(select(getTeamInitiatives))
        expect(step(teamInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(dispatch(clearInitiativeErrorsAction))
        expect(step()).toEqual(dispatch(setInitiativeErrorsAction))
        expect(gen.next().done).toBe(true)
    })
})
