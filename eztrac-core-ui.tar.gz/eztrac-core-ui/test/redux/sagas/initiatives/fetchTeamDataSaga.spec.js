import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {
    FETCH_TEAM_COST_DATA,
    FETCH_TEAM_DATA,
    SET_SELECTED_TEAM,
    SET_SELECTED_TEAM_FROM_URL
} from '../../../../src/client/redux/constants/teamConstants'

import {
    FETCH_TEAM_FORECASTED_PEOPLE,
    FETCH_TEAM_PEOPLE
} from '../../../../src/client/redux/constants/peopleConstants'
import {FETCH_TEAM_INITIATIVES} from '../../../../src/client/redux/constants/initiativeConstants'
import {SET_IS_LOADING} from '../../../../src/client/redux/constants'
import {get} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {getSelectedTeam} from '../../../../src/client/redux/selectors/index'
import {urls} from '../../../urlConsts'
import getTimeFrames from '../../../../src/client/redux/sagas/takes/getTimeFrames'
import listener, {fetchTeamData} from '../../../../src/client/redux/sagas/fetchTeamDataSaga'

const coreServicesUrl = urls.coreServices

describe('fetch team data saga', () => {
    describe('fetchTeamData listener ', () => {
        it('listens on the correct actions', () => {
            const gen = listener()
            const step = (lastYield) => gen.next(lastYield).value
            const constants = [FETCH_TEAM_DATA, SET_SELECTED_TEAM, SET_SELECTED_TEAM_FROM_URL]

            expect(step()).toEqual(takeLatest(constants, fetchTeamData))
        })
    })
    describe('fetchTeamData saga flow', () => {
        const isLoadingFalse = {
            type: SET_IS_LOADING,
            payload: false
        }

        const isLoadingTrue = {
            type: SET_IS_LOADING,
            payload: true
        }

        const selectedTeam = {id: 'MY_TEAM'}

        it('successfully fetches the team data for all active time frames', () => {
            const gen = fetchTeamData()
            const step = (lastYield) => gen.next(lastYield).value

            const mockTimeFrames = [
                {id: '42006', isActive: false},
                {id: '42007', isActive: true},
                {id: '42008', isActive: true},
                {id: '42009', isActive: true}
            ]

            const mockResponse = {
                error: false,
                payload: [
                    {
                        data: 'some_data'
                    }
                ]
            }

            const fetchTeamInitiativesAction = {
                type: FETCH_TEAM_INITIATIVES,
                payload: mockResponse.payload
            }

            const fetchTeamPeopleAction = {
                type: FETCH_TEAM_PEOPLE,
                payload: mockResponse.payload
            }

            const fetchTeamForecastedPeopleAction = {
                type: FETCH_TEAM_FORECASTED_PEOPLE,
                payload: mockResponse.payload
            }

            const fetchTeamCostData = {
                type: FETCH_TEAM_COST_DATA,
                payload: mockResponse.payload
            }

            const url = `${coreServicesUrl}/v2/efforts/full/team/MY_TEAM?startTimeFrame=42007&endTimeFrame=42009`

            expect(step()).toEqual(dispatch(isLoadingTrue))
            expect(step(true)).toEqual(select(getSelectedTeam))
            expect(step(selectedTeam)).toEqual(call(getTimeFrames))
            expect(step(mockTimeFrames)).toEqual(call(get, {url}))
            expect(step(mockResponse)).toEqual(dispatch(fetchTeamInitiativesAction))
            expect(step()).toEqual(dispatch(fetchTeamPeopleAction))
            expect(step()).toEqual(dispatch(fetchTeamForecastedPeopleAction))
            expect(step()).toEqual(dispatch(fetchTeamCostData))
            expect(step()).toEqual(dispatch(isLoadingFalse))
            expect(step(false))
            expect(gen.next().done).toBe(true)
        })

        it('handles an error and does not dispatch additional actions', () => {
            const gen = fetchTeamData()
            const step = (lastYield) => gen.next(lastYield).value

            const mockTimeFrames = [
                {id: '42006', isActive: false},
                {id: '42007', isActive: true},
                {id: '42008', isActive: true},
                {id: '42009', isActive: true}
            ]

            const mockResponse = {
                error: true,
                payload: [
                    {
                        data: 'some_data'
                    }
                ]
            }

            const url = `${coreServicesUrl}/v2/efforts/full/team/MY_TEAM?startTimeFrame=42007&endTimeFrame=42009`

            expect(step()).toEqual(dispatch(isLoadingTrue))
            expect(step(true)).toEqual(select(getSelectedTeam))
            expect(step(selectedTeam)).toEqual(call(getTimeFrames))
            expect(step(mockTimeFrames)).toEqual(call(get, {url}))
            expect(step(mockResponse)).toEqual(dispatch(isLoadingFalse))
            expect(step(false))
            expect(gen.next().done).toBe(true)
        })
    })
})
