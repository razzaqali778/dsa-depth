import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {
    CLEAR_NEW_INITIATIVE_DATA,
    SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES
} from '../../../../src/client/redux/constants/initiativeConstants'
import {appendTimeFrameId} from '../../../../src/client/redux/utils/newInitiative'
import {
    getNewInitiativeData,
    getSelectedTimeFrameTeamInitiatives
} from '../../../../src/client/redux/selectors/initiatives'
import {
    getSelectedTimeFrameId,
    getSortOrderPreferenceLocal
} from '../../../../src/client/redux/selectors'
import listener, {
    addNewInitiativeFromState
} from '../../../../src/client/redux/sagas/initiatives/addInitiativeFromStateSaga'

describe('addInitiative listener', () => {
    it('listens on the correct actions', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constant = ['initiatives/ADD_NEW_INITIATIVE_FROM_STATE']

        expect(step()).toEqual(takeLatest(constant, addNewInitiativeFromState))
    })
})
describe('addInitiative saga flow', () => {
    const selectedInitiativeFramework = {
        businessUnit: null,
        financeCodeType: null,
        financeCodeValue: null,
        teamCostPct: 100,
        parent_status: 'Planning',
        portfolioCode: null,
        region: null,
        timeFrameId: 41905,
        initiativeCost: 612000,
        isAllocable: true,
        isInheritable: true,
        status: 'Planning',
        typeId: 'EXP-INIT'
    }
    const sortOrderPreferenceLocal = {
        allocationNum: 0,
        costNum: 0,
        nameNum: 1
    }
    const selectedTimeFrameInitiatives = [
        {
            ...selectedInitiativeFramework,
            id: 'ee4a50c0-0214-11e9-a195-97d08e842820',
            parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef2',
            parentName: 'Anis Field Support',
            initiativeName: 'Anis Field Support'
        },
        {
            ...selectedInitiativeFramework,
            id: 'ee4a50c0-0214-11e9-a195-97d08e842820',
            parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef2',
            parentName: 'Anis Field Support',
            initiativeName: 'Anis Field Support'
        },
        {
            ...selectedInitiativeFramework,
            id: 'ee4a50c0-0214-11e9-a195-97d08e842822',
            parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef3',
            parentName: 'ASP Field Support',
            initiativeName: 'Velocity Field Support'
        }
    ]
    const selectedTimeFrameId = 41905
    const setSelectedTimeFrameTeamInitiativesAction = (value) => ({
        type: SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES,
        payload: value
    })
    const clearNewInitiativeDataAction = {
        type: CLEAR_NEW_INITIATIVE_DATA
    }
    const newSelectedTimeFrameInitiatives = (value) => [
        ...selectedTimeFrameInitiatives,
        appendTimeFrameId(value, selectedTimeFrameId)
    ]
    it('adds the new initiative from state to the selectedTimeFrameTeamInitiatives when there is no payload', () => {
        const gen = addNewInitiativeFromState()
        const step = (lastYield) => gen.next(lastYield).value
        const newInitiativeData = {
            value: {
                ...selectedInitiativeFramework,
                id: 'ee4a50c0-0214-11e9-a195-97d08e842823',
                parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef4',
                parentName: 'ASP Field Support',
                initiativeName: 'Velocity Field Support'
            }
        }
        const expectedResult = newSelectedTimeFrameInitiatives(newInitiativeData.value)

        expect(step()).toEqual(select(getNewInitiativeData))
        expect(step(newInitiativeData)).toEqual(select(getSelectedTimeFrameTeamInitiatives))
        expect(step(selectedTimeFrameInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(select(getSortOrderPreferenceLocal))
        expect(step(sortOrderPreferenceLocal)).toEqual(
            dispatch(setSelectedTimeFrameTeamInitiativesAction(expectedResult))
        )
        expect(step()).toEqual(dispatch(clearNewInitiativeDataAction))
        expect(gen.next().done).toBe(true)
    })
})
