import * as Saga from 'redux-saga/effects'
import {
    FETCH_TEAM_COST_DATA,
    SET_SELECTED_TIME_FRAME_TEAM_COST,
    SET_TEAM_COST_DATA
} from '../../../src/client/redux/constants/teamConstants'
import {recordSaga} from './runSaga'
import {testStateBuilder} from '../../testStateBuilder'
import actions from '../../../src/client/redux/actions'
import listener, {fetchTeamCostData} from '../../../src/client/redux/sagas/fetchTeamCostDataSaga'

describe('Fetch Team Cost Data Saga', () => {
    it('Listens on the correct actions', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [FETCH_TEAM_COST_DATA]
        expect(step()).toEqual(Saga.takeLatest(constants, fetchTeamCostData))
    })
    describe('given an executed saga, ', () => {
        let dispatchedActions
        const findAction = (actionName) =>
            dispatchedActions.find((action) => action.type === actionName)
        const effortResponse = [
            {
                error: false,
                timeFrameId: 41904,
                costBreakdowns: [{cost: 1000}]
            },
            {
                error: false,
                timeFrameId: 41905,
                costBreakdowns: [{cost: 2000}]
            }
        ]
        beforeEach(async () => {
            dispatchedActions = await recordSaga(
                fetchTeamCostData,
                {type: FETCH_TEAM_COST_DATA, payload: effortResponse},
                testStateBuilder()
            )
        })
        it('dispatches an action with formatted team cost data ', () => {
            const expectedCostData = [
                {timeFrameId: 41904, teamCost: 1000},
                {timeFrameId: 41905, teamCost: 2000}
            ]

            expect(findAction(SET_TEAM_COST_DATA)).toEqual(
                actions.setTeamCostData(expectedCostData)
            )
        })
        it('sets the selected time frame team cost data', () => {
            const expectedSelectedTimeFrameTeamCostData = {timeFrameId: 41904, teamCost: 1000}

            expect(findAction(SET_SELECTED_TIME_FRAME_TEAM_COST)).toEqual(
                actions.setSelectedTimeFrameTeamCost(expectedSelectedTimeFrameTeamCostData)
            )
        })
    })
})
