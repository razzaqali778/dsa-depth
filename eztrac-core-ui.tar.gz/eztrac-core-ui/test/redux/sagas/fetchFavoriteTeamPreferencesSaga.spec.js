import {call, put as dispatch} from 'redux-saga/effects'
import {getFavoriteTeamsPreference} from '../../../src/client/redux/sagas/helpers/preferences'
import saga from '../../../src/client/redux/sagas/preferences/fetchFavoriteTeamPreferencesSaga'

describe('fetchPreferences', () => {
    it('fetches preferences and sets them in state', () => {
        const gen = saga()
        const step = (lastYield) => gen.next(lastYield).value

        const preferences = [
            {
                'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW': 'MARKETING-WEB-TOOLS-TEAM-SLALOM-SOW'
            }
        ]

        const action = {
            type: 'preferences/SET_FAVORITE_TEAMS_PREFERENCE',
            payload: preferences
        }

        expect(step()).toEqual(call(getFavoriteTeamsPreference))
        expect(step(preferences)).toEqual(dispatch(action))
        expect(gen.next().done).toEqual(true)
    })
    it('does nothing if there are no preferences', () => {
        const gen = saga()
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(call(getFavoriteTeamsPreference))
        expect(step()).toEqual()
        expect(gen.next().done).toEqual(true)
    })
})
