import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {FETCH_TEAM_DATA} from '../../../src/client/redux/constants/teamConstants'
import {SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES} from '../../../src/client/redux/constants/initiativeConstants'
import {
    getSelectedTimeFrameId,
    getSortOrderPreferenceLocal,
    getStartEndSelector
} from '../../../src/client/redux/selectors'
import {getSelectedTimeFrameTeamInitiatives} from '../../../src/client/redux/selectors/initiatives'
import getRelevantTimeFrames from '../../../src/client/redux/selectors/getRelevantTimeFrames'
import listener, {
    setAppropriateTimeFrames
} from '../../../src/client/redux/sagas/setAppropriateTimeFramesSaga'

const setStartTimeFrameAction = ({id, startCode}) => ({
    type: 'timeFrames/SET_START_TIME_FRAME',
    payload: {id, startCode}
})
const setEndTimeFrameAction = ({id, startCode}) => ({
    type: 'timeFrames/SET_END_TIME_FRAME',
    payload: {id, startCode}
})
const fetchTeamDataAction = {
    type: FETCH_TEAM_DATA
}
const sortOrderPreferenceLocal = {
    allocationNum: 0,
    costNum: 0,
    nameNum: 1
}
const timeFrameInitiatives = [
    {
        businessUnit: null,
        financeCodeType: null,
        financeCodeValue: null,
        id: 'ee4a50c0-0214-11e9-a195-97d08e842828',
        initiativeName: 'Velocity Field Support',
        isAllocable: true,
        isInheritable: true,
        parentId: '17fcad50-9fe6-11e8-834f-0f1a7fcdaef2',
        parentName: 'ASP Field Support',
        parent_status: 'Planning',
        portfolioCode: null,
        region: null,
        status: 'Planning',
        typeId: 'EXP-INIT'
    },
    {
        businessUnit: null,
        financeCodeType: 'Cost Center',
        financeCodeValue: 'SLR76402',
        id: '63764a40-c3d0-11e7-9217-11582b14483e',
        initiativeName: 'Velocity Support',
        isAllocable: true,
        isInheritable: true,
        parentId: '449465a0-9efd-11e7-95c2-f3e864cd7c94',
        parentName: 'IT: GLB',
        parent_status: null,
        portfolioCode: null,
        region: null,
        status: 'Funded',
        typeId: 'SUP'
    }
]
const setSelectedTimeFrameTeamInitiativesAction = {
    type: SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES,
    payload: timeFrameInitiatives
}

describe('listener', () => {
    it('listens only SET_APPROPRIATE_TIME_FRAMES', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['timeFrames/SET_APPROPRIATE_TIME_FRAMES']

        expect(step()).toEqual(takeLatest(constants, setAppropriateTimeFrames))
    })
})

describe('ƒ', () => {
    it('sets the start time and does not adjust the selected time frame', () => {
        const startTimeCode = 1551398400000
        const chosenTimeFrame = 41903
        const input = {
            payload: {
                chosenTimeFrame,
                startTimeCode
            }
        }
        const gen = setAppropriateTimeFrames(input)
        const step = (lastYield) => gen.next(lastYield).value
        const selectedTimeFrameId = 41904

        const relevantTimeFrames = [
            {value: 41903, startCode: 1551398400000},
            {value: 41904, startCode: 1554076800000},
            {value: 41905, startCode: 1556668800000},
            {value: 41906, startCode: 1559347200000}
        ]

        expect(step()).toEqual(select(getSelectedTimeFrameTeamInitiatives))
        expect(step(timeFrameInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(select(getStartEndSelector))
        expect(step(true)).toEqual(
            dispatch(setStartTimeFrameAction({id: chosenTimeFrame, startCode: startTimeCode}))
        )
        expect(step()).toEqual(select(getRelevantTimeFrames))
        expect(step(relevantTimeFrames)).toEqual(select(getSortOrderPreferenceLocal))
        expect(step(sortOrderPreferenceLocal)).toEqual(
            dispatch(setSelectedTimeFrameTeamInitiativesAction)
        )
        expect(gen.next().done).toBe(true)
    })
    it('sets the start time and does adjust the selected time frame', () => {
        const startTimeCode = 1556668800000
        const chosenTimeFrame = 41905
        const input = {
            payload: {
                chosenTimeFrame,
                startTimeCode
            }
        }
        const gen = setAppropriateTimeFrames(input)
        const step = (lastYield) => gen.next(lastYield).value
        const selectedTimeFrameId = 41904

        const setSelectedTimeFrameIdAction = {
            type: 'timeFrames/SET_SELECTED_TIME_FRAME_ID',
            payload: chosenTimeFrame
        }

        const relevantTimeFrames = [
            {id: 41905, startCode: 1556668800000},
            {id: 41906, startCode: 1559347200000}
        ]

        expect(step()).toEqual(select(getSelectedTimeFrameTeamInitiatives))
        expect(step(timeFrameInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(select(getStartEndSelector))
        expect(step(true)).toEqual(
            dispatch(setStartTimeFrameAction({id: chosenTimeFrame, startCode: startTimeCode}))
        )
        expect(step()).toEqual(select(getRelevantTimeFrames))
        expect(step(relevantTimeFrames)).toEqual(dispatch(setSelectedTimeFrameIdAction))
        expect(step()).toEqual(dispatch(fetchTeamDataAction))
        expect(step()).toEqual(select(getSortOrderPreferenceLocal))
        expect(step(sortOrderPreferenceLocal)).toEqual(
            dispatch(setSelectedTimeFrameTeamInitiativesAction)
        )

        expect(gen.next().done).toBe(true)
    })

    it('sets the end time and does not adjust the selected time frame', () => {
        const startTimeCode = 1559347200000
        const chosenTimeFrame = 41906
        const input = {
            payload: {
                chosenTimeFrame,
                startTimeCode
            }
        }
        const gen = setAppropriateTimeFrames(input)
        const step = (lastYield) => gen.next(lastYield).value
        const selectedTimeFrameId = 41904

        const relevantTimeFrames = [
            {value: 41903, startCode: 1551398400000},
            {value: 41904, startCode: 1554076800000},
            {value: 41905, startCode: 1556668800000},
            {value: 41906, startCode: 1559347200000}
        ]

        expect(step()).toEqual(select(getSelectedTimeFrameTeamInitiatives))
        expect(step(timeFrameInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(select(getStartEndSelector))
        expect(step(false)).toEqual(
            dispatch(setEndTimeFrameAction({id: chosenTimeFrame, startCode: startTimeCode}))
        )
        expect(step()).toEqual(select(getRelevantTimeFrames))
        expect(step(relevantTimeFrames)).toEqual(select(getSortOrderPreferenceLocal))
        expect(step(sortOrderPreferenceLocal)).toEqual(
            dispatch(setSelectedTimeFrameTeamInitiativesAction)
        )
        expect(gen.next(relevantTimeFrames).done).toBe(true)
    })

    it('sets the end time and does adjust the selected time frame', () => {
        const startTimeCode = 1561939200000
        const chosenTimeFrame = 41907
        const input = {
            payload: {
                chosenTimeFrame,
                startTimeCode
            }
        }
        const gen = setAppropriateTimeFrames(input)
        const step = (lastYield) => gen.next(lastYield).value
        const selectedTimeFrameId = 41908

        const setSelectedTimeFrameIdAction = {
            type: 'timeFrames/SET_SELECTED_TIME_FRAME_ID',
            payload: chosenTimeFrame
        }

        const relevantTimeFrames = [
            {id: 41903, startCode: 1551398400000},
            {id: 41904, startCode: 1554076800000},
            {id: 41905, startCode: 1556668800000},
            {id: 41906, startCode: 1559347200000},
            {id: 41907, startCode: 1561939200000}
        ]

        expect(step()).toEqual(select(getSelectedTimeFrameTeamInitiatives))
        expect(step(timeFrameInitiatives)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(select(getStartEndSelector))
        expect(step(false)).toEqual(
            dispatch(setEndTimeFrameAction({id: chosenTimeFrame, startCode: startTimeCode}))
        )
        expect(step()).toEqual(select(getRelevantTimeFrames))
        expect(step(relevantTimeFrames)).toEqual(dispatch(setSelectedTimeFrameIdAction))
        expect(step()).toEqual(dispatch(fetchTeamDataAction))
        expect(step()).toEqual(select(getSortOrderPreferenceLocal))
        expect(step(sortOrderPreferenceLocal)).toEqual(
            dispatch(setSelectedTimeFrameTeamInitiativesAction)
        )
        expect(gen.next().done).toBe(true)
    })
})
