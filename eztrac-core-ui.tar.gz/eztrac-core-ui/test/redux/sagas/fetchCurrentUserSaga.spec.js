import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import {queries, queryProfile} from '@bayerit/profile-client'
import {
    FETCH_CURRENT_USER,
    SET_CURRENT_USER
} from '../../../src/client/redux/constants/userConstants'
import listner, {fetchCurrentUser} from '../../../src/client/redux/sagas/fetchCurrentUserSaga'

describe('fetch current user', () => {
    it('calls query profile', () => {
        const gen = fetchCurrentUser()
        const step = (lastYield) => gen.next(lastYield).value
        const currentUserQuery = queries.currentUserWithEntitlements('eztrac')

        const dummyUserProfile = {
            getCurrentUser: {
                id: 4,
                preferredName: {
                    first: 'john',
                    last: 'johN',
                    middle: 'jOHn',
                    full: 'john johN jOHn'
                },
                entitlements: ['some text', 'look, an entitlement', 'this one as well too']
            }
        }

        const dummyAction = {
            type: SET_CURRENT_USER,
            payload: dummyUserProfile.getCurrentUser
        }
        expect(JSON.stringify(step())).toEqual(JSON.stringify(call(queryProfile, currentUserQuery)))
        expect(step(dummyUserProfile)).toEqual(dispatch(dummyAction))
    })

    it('listens on get user action', () => {
        const gen = listner()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [FETCH_CURRENT_USER]

        expect(step()).toEqual(takeLatest(constants, fetchCurrentUser))
    })
})
