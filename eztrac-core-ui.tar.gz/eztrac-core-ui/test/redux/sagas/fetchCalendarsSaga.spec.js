import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {SET_CALENDARS} from '../../../src/client/redux/constants/engagementConstants'
import {get} from '../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../urlConsts'
import listener, {fetchCalendars} from '../../../src/client/redux/sagas/fetchCalendarsSaga'

const costingServicesUrl = urls.costingServices

describe('listener', () => {
    it('listens on FETCH_CALENDARS', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constant = ['engagements/FETCH_CALENDARS']
        expect(step()).toEqual(takeLatest(constant, fetchCalendars))
    })
})

describe('saga flow', () => {
    it('happy path', () => {
        const gen = fetchCalendars()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/calendars/hours`
        const mockCalendars = [
            {
                name: 'yeah'
            },
            {
                name: 'nah'
            },
            {
                name: 'yeah'
            }
        ]

        const setCalendarsAction = {
            type: SET_CALENDARS,
            payload: mockCalendars
        }
        const mockGetResult = {payload: mockCalendars, error: false}

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setCalendarsAction))
        expect(gen.next().done).toBe(true)
    })

    it('bad path', () => {
        const gen = fetchCalendars()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/calendars/hours`

        const mockGetResult = {
            payload: 'It broke',
            error: true
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch calendar hours')

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
