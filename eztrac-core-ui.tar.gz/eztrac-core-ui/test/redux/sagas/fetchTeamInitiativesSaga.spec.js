import * as Saga from 'redux-saga/effects'
import {
    FETCH_TEAM_INITIATIVES,
    SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES,
    SET_TEAM_INITIATIVES
} from '../../../src/client/redux/constants/initiativeConstants'
import {recordSaga} from './runSaga'
import {testStateBuilder} from '../../testStateBuilder'
import actions from '../../../src/client/redux/actions'
import listener, {
    fetchTeamInitiatives
} from '../../../src/client/redux/sagas/initiatives/fetchTeamInitiativesSaga'

jest.mock('../../../src/client/components-containers/toastrWrapper')

describe('fetchTeamInitiatives', () => {
    it('listens on the correct actions', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['initiatives/FETCH_TEAM_INITIATIVES']

        expect(step()).toEqual(Saga.takeLatest(constants, fetchTeamInitiatives))
    })
    describe('given an executed saga, ', () => {
        let dispatchedActions
        const findAction = (actionName) =>
            dispatchedActions.find((action) => action.type === actionName)

        beforeEach(async () => {
            const effortResponses = [
                {
                    timeFrameId: 41904,
                    teamId: 'TeamID1',
                    costBreakdowns: [
                        {
                            costGroupId: 'SOME_COST_GROUP',
                            cost: 200
                        }
                    ],
                    allocations: [
                        {
                            percentageOfTeamCost: 100,
                            initiativeId: 'InitiativeID1'
                        }
                    ]
                }
            ]
            dispatchedActions = await recordSaga(
                fetchTeamInitiatives,
                {type: FETCH_TEAM_INITIATIVES, payload: effortResponses},
                testStateBuilder()
            )
        })

        it('dispatches an action with formatted team initiative data', () => {
            const expectedInitiativeData = [
                {
                    id: 'InitiativeID1',
                    initiativeCost: 200,
                    teamCostPct: 100,
                    timeFrameId: 41904
                }
            ]
            expect(findAction(SET_TEAM_INITIATIVES)).toEqual(
                actions.setTeamInitiatives(expectedInitiativeData)
            )
        })
        it('sets the selected time frame team initiatives', () => {
            const expectedTeamInitiativeData = [
                {
                    id: 'InitiativeID1',
                    initiativeCost: 200,
                    teamCostPct: 100,
                    timeFrameId: 41904
                }
            ]

            expect(findAction(SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES)).toEqual(
                actions.setSelectedTimeFrameTeamInitiatives(expectedTeamInitiativeData)
            )
        })
    })
})
