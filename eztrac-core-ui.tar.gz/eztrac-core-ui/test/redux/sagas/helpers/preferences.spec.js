import {
    deleteFavoriteTeamsPreference,
    getFavoriteTeamsPreference,
    setFavoriteTeamsPreference
} from '../../../../src/client/redux/sagas/helpers/preferences'

let preferences
beforeEach(() => {
    preferences = {
        id: 'aThing'
    }
})

describe('testing preferences helper', () => {
    const mockClient = {
        promise: () =>
            new Promise((resolve) => {
                resolve()
            }),
        get: () => preferences,
        put: (key, val) => {
            preferences[key] = val

            return preferences
        },
        remove: (id) => {
            delete preferences[id]

            return preferences
        }
    }

    it('gets preferences', async () => {
        expect(await getFavoriteTeamsPreference(mockClient)).toEqual({id: 'aThing'})
    })
    it('sets preferences', async () => {
        expect(
            await setFavoriteTeamsPreference(
                'GLaDOS',
                'Genetic Lifeform and Disk Operating System',
                mockClient
            )
        ).toEqual({GLaDOS: 'Genetic Lifeform and Disk Operating System', id: 'aThing'})
    })
    it('removes a preference', async () => {
        expect(await deleteFavoriteTeamsPreference('id', mockClient)).toEqual({})
    })
})
