import {call, put as dispatch} from 'redux-saga/effects'
import {SET_SELECTED_TEAM_TAB} from '../../../src/client/redux/constants/preferencesConstants'
import {getLastTabPreferenceServer} from '../../../src/client/redux/sagas/helpers/preferences'
import saga from '../../../src/client/redux/sagas/preferences/fetchLastTabPreferencesSaga'

describe('fetchLastTabPreferences', () => {
    it('fetches lastTabPreference and sets it in state', () => {
        const gen = saga()
        const step = (lastYield) => gen.next(lastYield).value

        const lastTabPreference = {
            lastTab: 'engagements'
        }
        const action = {
            type: SET_SELECTED_TEAM_TAB,
            payload: lastTabPreference.lastTab
        }

        expect(step()).toEqual(call(getLastTabPreferenceServer))
        expect(step(lastTabPreference)).toEqual(dispatch(action))
        expect(gen.next().done).toEqual(true)
    })
    it('fails to fetch sortOrderPreference and returns default sort order', () => {
        const gen = saga()
        const step = (lastYield) => gen.next(lastYield).value

        const lastTabPreference = {
            lastTab: 'engagements'
        }
        const expectedLastTabPreference = 'engagements'

        const action = {
            type: SET_SELECTED_TEAM_TAB,
            payload: lastTabPreference.lastTab
        }
        expect(step()).toEqual(call(getLastTabPreferenceServer))
        const lastTabPreferenceStep = step(lastTabPreference)
        expect(lastTabPreferenceStep).toEqual(dispatch(action))
        expect(lastTabPreferenceStep.PUT.action.payload).toEqual(expectedLastTabPreference)
        expect(gen.next().done).toEqual(true)
    })
})
