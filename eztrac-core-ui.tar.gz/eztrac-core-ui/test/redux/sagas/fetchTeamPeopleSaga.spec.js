import * as Saga from 'redux-saga/effects'

import {
    FETCH_TEAM_PEOPLE,
    SET_SELECTED_TIME_FRAME_TEAM_PEOPLE,
    SET_TEAM_PEOPLE
} from '../../../src/client/redux/constants/peopleConstants'
import {recordSaga} from './runSaga'
import {testStateBuilder} from '../../testStateBuilder'
import actions from '../../../src/client/redux/actions'
import listener, {fetchTeamPeople} from '../../../src/client/redux/sagas/people/fetchTeamPeopleSaga'

jest.mock('../../../src/client/components-containers/toastrWrapper')

describe('Fetch Team People Saga', () => {
    it('Listens on the correct actions', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [FETCH_TEAM_PEOPLE]
        expect(step()).toEqual(Saga.takeLatest(constants, fetchTeamPeople))
    })
    describe('given an executed saga, ', () => {
        let dispatchedActions
        const findAction = (actionName) =>
            dispatchedActions.find((action) => action.type === actionName)
        const effortResponse = [
            {
                timeFrameId: 41904,
                members: [{userId: 'PersonId1', percent: 100}]
            },
            {
                timeFrameId: 41905,
                members: [{userId: 'PersonId2', percent: 100}]
            }
        ]

        beforeEach(async () => {
            dispatchedActions = await recordSaga(
                fetchTeamPeople,
                {type: FETCH_TEAM_PEOPLE, payload: effortResponse},
                testStateBuilder()
            )
        })
        it('dispatches an action with formatted team people data ', () => {
            const expectedPeopleData = [
                {
                    personId: 'PersonId1',
                    personName: 'personName1',
                    timeFrameId: 41904,
                    participationPct: 100
                },
                {
                    personId: 'PersonId2',
                    personName: 'personName2',
                    timeFrameId: 41905,
                    participationPct: 100
                }
            ]

            expect(findAction(SET_TEAM_PEOPLE)).toEqual(actions.setTeamPeople(expectedPeopleData))
        })
        it('sets the selected time frame team people', () => {
            const expectedSelectedTimeFrameTeamPeopleData = [
                {
                    personId: 'PersonId1',
                    personName: 'personName1',
                    timeFrameId: 41904,
                    participationPct: 100
                }
            ]

            expect(findAction(SET_SELECTED_TIME_FRAME_TEAM_PEOPLE)).toEqual(
                actions.setSelectedTimeFrameTeamPeople(expectedSelectedTimeFrameTeamPeopleData)
            )
        })
    })
})
