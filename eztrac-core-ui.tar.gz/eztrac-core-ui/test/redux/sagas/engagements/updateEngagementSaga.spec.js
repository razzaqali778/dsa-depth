import {put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {SET_IS_LOADING} from '../../../../src/client/redux/constants'
import {UPDATE_ENGAGEMENT} from '../../../../src/client/redux/constants/engagementConstants'
import listener, {
    updateEngagement
} from '../../../../src/client/redux/sagas/engagements/updateEngagementSaga'

const payload = {
    isUpdatingAll: true,
    selectedTimeFrameId: 41909,
    selectedEngagementId: 'ENGAGEMENT2',
    comment: 'engagement comment'
}

const setIsLoadingTrue = {
    type: SET_IS_LOADING,
    payload: true
}

describe('update engagement saga', () => {
    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value

        const constants = [UPDATE_ENGAGEMENT]

        expect(step()).toEqual(takeLatest(constants, updateEngagement))
    })
    it('happy path on updating an engagement cost for all future months', () => {
        const gen = updateEngagement({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const toastrSuccess = toastr.success('Successfully saved engagement')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step(toastrSuccess))
    })
    it('bad path with an error on updating engagement cost', () => {
        const gen = updateEngagement({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const patchResponse = {
            error: true,
            payload: {
                amount: 4000
            }
        }

        const toastrError = toastr.error(patchResponse.payload, 'Failed to save engagement')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step(toastrError))
    })
})
