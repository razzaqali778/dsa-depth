import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {getSelectedTeam} from '../../../../src/client/redux/selectors'
import {urls} from '../../../urlConsts'
import listener, {
    fetchAllTeamEngagements
} from '../../../../src/client/redux/sagas/engagements/fetchAllTeamEngagementsSaga'

const coreServicesUrl = urls.coreServices

describe('listener', () => {
    it('listens on FETCH_ALL_TEAM_ENGAGEMENTS, SET_SELECTED_TEAM', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [
            'engagements/FETCH_ALL_TEAM_ENGAGEMENTS',
            'team/SET_SELECTED_TEAM',
            'team/SET_SELECTED_TEAM_FROM_URL'
        ]

        expect(step()).toEqual(takeLatest(constants, fetchAllTeamEngagements))
    })
})

describe('saga flow', () => {
    it('happy path', () => {
        const gen = fetchAllTeamEngagements()
        const step = (lastYield) => gen.next(lastYield).value
        const selectedTeam = {
            id: 'stuff'
        }

        const url = `${coreServicesUrl}/v2/efforts/engagements/team/${selectedTeam.id}`
        const mockEngagements = ['some', 'stuff']
        const setAllTeamEngagementsAction = {
            type: 'engagements/SET_ALL_TEAM_ENGAGEMENTS',
            payload: mockEngagements
        }

        const mockGetResult = {payload: mockEngagements, error: false}
        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setAllTeamEngagementsAction))
        expect(gen.next().done).toBe(true)
    })

    it('bad path', () => {
        const gen = fetchAllTeamEngagements()
        const step = (lastYield) => gen.next(lastYield).value
        const selectedTeam = {
            id: 'stuff'
        }

        const url = `${coreServicesUrl}/v2/efforts/engagements/team/${selectedTeam.id}`

        const mockGetResult = {
            payload: 'It broke',
            error: true
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch engagements')

        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
