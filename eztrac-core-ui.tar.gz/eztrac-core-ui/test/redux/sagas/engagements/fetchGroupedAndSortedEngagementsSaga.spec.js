import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {SET_GROUPED_AND_SORTED_ENGAGEMENTS} from '../../../../src/client/redux/constants/engagementConstants'
import getGroupedAndSortedEngagements from '../../../../src/client/redux/selectors/engagements/getGroupedAndSortedEngagements'
import listener, {
    fetchGroupedAndSortedEngagements
} from '../../../../src/client/redux/sagas/engagements/fetchGroupedAndSortedEngagementsSaga'

describe('listener', () => {
    it('listens on FETCH_GROUPED_AND_SORTED_ENGAGEMENTS & SET_ALL_TEAM_ENGAGEMENTS', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constant = [
            'engagements/FETCH_GROUPED_AND_SORTED_ENGAGEMENTS',
            'engagements/SET_ALL_TEAM_ENGAGEMENTS'
        ]
        expect(step()).toEqual(takeLatest(constant, fetchGroupedAndSortedEngagements))
    })
})

describe('saga flow', () => {
    it('sets grouped and sorted engagements', () => {
        const gen = fetchGroupedAndSortedEngagements()
        const step = (lastYield) => gen.next(lastYield).value

        const setGroupedAndSortedEngagementsAction = {
            type: SET_GROUPED_AND_SORTED_ENGAGEMENTS
        }

        expect(step()).toEqual(select(getGroupedAndSortedEngagements))
        expect(step()).toEqual(dispatch(setGroupedAndSortedEngagementsAction))
    })
})
