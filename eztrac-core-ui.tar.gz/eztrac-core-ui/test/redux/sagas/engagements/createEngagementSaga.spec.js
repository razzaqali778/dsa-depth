import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {
    CREATE_ENGAGEMENT,
    FETCH_ALL_TEAM_ENGAGEMENTS,
    TOGGLE_IS_CREATING_ENGAGEMENT
} from '../../../../src/client/redux/constants/engagementConstants'
import {SET_IS_LOADING} from '../../../../src/client/redux/constants'
import {getSelectedTeam} from '../../../../src/client/redux/selectors'
import {getTotalEngagementCost} from '../../../../src/client/redux/selectors/engagements'
import {post} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {
    createEngagement
} from '../../../../src/client/redux/sagas/engagements/createEngagementSaga'

const coreServicesUrl = urls.coreServices

const selectedTeam = {
    communityId: 'FIELD-MAPS',
    id: 'DIREWOLF-DEV-TEAM',
    isActive: true,
    name: 'Direwolf Dev Team'
}

const setIsLoadingTrue = {
    type: SET_IS_LOADING,
    payload: true
}

const createPayloadWithoutCost = {
    selectedStartTimeFrameId: 40918,
    selectedEndTimeFrameId: 40919,
    selectedEngagementId: 'ENGAGEMENT2'
}

const createPayloadWithCost = {
    selectedStartTimeFrameId: 40918,
    selectedEndTimeFrameId: 40919,
    selectedEngagementId: 'ENGAGEMENT2',
    engagementCost: '4004'
}

const setIsLoadingFalse = {
    type: SET_IS_LOADING,
    payload: false
}

const postOpts = {
    url: `${coreServicesUrl}/v2/efforts/engagements`,
    body: {
        teamId: 'DIREWOLF-DEV-TEAM',
        startTimeFrameId: 40918,
        endTimeFrameId: 40919,
        amount: 15000,
        amountType: 'Monthly',
        engagementId: 'ENGAGEMENT2'
    }
}

const amount = 15000

describe('create engagement saga', () => {
    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [CREATE_ENGAGEMENT]

        expect(step()).toEqual(takeLatest(constants, createEngagement))
    })
    it('happy path on adding engagement with preselected cost', () => {
        const gen = createEngagement({payload: createPayloadWithoutCost})
        const step = (lastYield) => gen.next(lastYield).value

        const postResponse = {
            error: false,
            payload: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 40918,
                amount: 10000,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT2'
            }
        }

        const updatedEngagements = [
            {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 40918,
                amount: 5000,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT1'
            },
            {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41018,
                amount: 5000,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT1'
            },
            {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 40918,
                amount: 15000,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT2'
            }
        ]

        const toggleIsCreatingFalse = {
            type: TOGGLE_IS_CREATING_ENGAGEMENT,
            payload: false
        }
        const fetchAllTeamEngagementsAction = {
            type: FETCH_ALL_TEAM_ENGAGEMENTS
        }

        const toastrSuccess = toastr.success('Successfully saved engagement')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getTotalEngagementCost))
        expect(step(amount)).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(post, postOpts))
        expect(step(postResponse)).toEqual(dispatch(fetchAllTeamEngagementsAction))
        expect(step(updatedEngagements)).toEqual(dispatch(setIsLoadingFalse))
        expect(step()).toEqual(dispatch(toggleIsCreatingFalse))
        expect(step(toastrSuccess))
    })
    it('happy path on adding an engagement with cost defined in payload', () => {
        const gen = createEngagement({payload: createPayloadWithCost})
        const step = (lastYield) => gen.next(lastYield).value

        const postResponse = {
            error: false,
            payload: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 40918,
                amount: 4004,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT2'
            }
        }

        const postOptsWithCost = {
            url: `${coreServicesUrl}/v2/efforts/engagements`,
            body: {
                teamId: 'DIREWOLF-DEV-TEAM',
                startTimeFrameId: 40918,
                endTimeFrameId: 40919,
                amount: 4004,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT2'
            }
        }

        const updatedEngagements = [
            {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 40918,
                amount: 5000,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT1'
            },
            {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41018,
                amount: 5000,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT1'
            }
        ]

        const toggleIsCreatingFalse = {
            type: TOGGLE_IS_CREATING_ENGAGEMENT,
            payload: false
        }
        const fetchAllTeamEngagementsAction = {
            type: FETCH_ALL_TEAM_ENGAGEMENTS
        }

        const toastrSuccess = toastr.success('Successfully saved engagement')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step(amount)).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(post, postOptsWithCost))
        expect(step(postResponse)).toEqual(dispatch(fetchAllTeamEngagementsAction))
        expect(step(updatedEngagements)).toEqual(dispatch(setIsLoadingFalse))
        expect(step()).toEqual(dispatch(toggleIsCreatingFalse))
        expect(step(toastrSuccess))
    })
    it('bad path with error on adding engagement', () => {
        const gen = createEngagement({payload: createPayloadWithoutCost})
        const step = (lastYield) => gen.next(lastYield).value

        const postResponse = {
            error: true,
            payload: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 40918,
                amount: 10000,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT2'
            }
        }

        const {payload} = postResponse

        const toastrError = toastr.error(payload, 'Failed to save')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getTotalEngagementCost))
        expect(step(amount)).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(post, postOpts))
        expect(step(postResponse)).toEqual(dispatch(setIsLoadingFalse))
        expect(step(toastrError))
    })
})
