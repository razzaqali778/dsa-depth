import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {
    fetchEngagementOptions
} from '../../../../src/client/redux/sagas/engagements/fetchEngagementOptionsSaga'

const costingServicesUrl = urls.costingServices

describe('listener', () => {
    it('listens on FETCH_ENGAGEMENT_OPTIONS', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constant = ['engagements/FETCH_ENGAGEMENT_OPTIONS']
        expect(step()).toEqual(takeLatest(constant, fetchEngagementOptions))
    })
})

describe('saga flow', () => {
    it('happy path', () => {
        const gen = fetchEngagementOptions()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/engagements`
        const mockEngagements = ['some', 'stuff']
        const setEngagementOptionsAction = {
            type: 'engagements/SET_ENGAGEMENT_OPTIONS',
            payload: mockEngagements
        }

        const mockGetResult = {payload: mockEngagements, error: false}
        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setEngagementOptionsAction))
        expect(gen.next().done).toBe(true)
    })
    it('bad path', () => {
        const gen = fetchEngagementOptions()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/engagements`

        const mockGetResult = {
            payload: 'It broke',
            error: true
        }

        const toastrError = toastr.error(
            mockGetResult.payload,
            'Failed to fetch engagement options'
        )

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
