import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {
    CLEAR_CALCULATOR_ROWS,
    FETCH_ALL_TEAM_ENGAGEMENTS,
    SET_IS_CALCULATING,
    SET_IS_EDITING_ENGAGEMENT,
    SET_SELECTED_CALENDAR,
    SET_TOTAL_ENGAGEMENT_COST,
    UPDATE_CALCULATED_ENGAGEMENTS
} from '../../../../src/client/redux/constants/engagementConstants'
import {DEFAULT_RATE_CALENDAR} from '../../../../src/client/redux/constants/utilConstants'
import {SET_IS_LOADING} from '../../../../src/client/redux/constants'
import {
    getCalculatorRows,
    getSelectedRateCalendar
} from '../../../../src/client/redux/selectors/engagements'
import {getSelectedTeam} from '../../../../src/client/redux/selectors'
import {patch} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {
    updateCalculatedEngagements
} from '../../../../src/client/redux/sagas/engagements/updateCalculatedEngagementsSaga'

const coreServicesUrl = urls.coreServices

const setIsLoadingTrue = {
    type: SET_IS_LOADING,
    payload: true
}

const setIsLoadingFalse = {
    type: SET_IS_LOADING,
    payload: false
}

describe('updateCalculatedEngagementsSaga', () => {
    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value

        const constants = [UPDATE_CALCULATED_ENGAGEMENTS]

        expect(step()).toEqual(takeLatest(constants, updateCalculatedEngagements))
    })

    it('performs patch with calculator info', () => {
        const payload = {
            selectedTimeFrameId: 41902,
            selectedEngagementId: '5',
            isUpdatingAll: false,
            comment: 'engagement comment'
        }

        const gen = updateCalculatedEngagements({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const selectedTeam = {
            id: 'DIREWOLF-DEV-TEAM'
        }

        const calculatorRows = [
            {
                people: '4',
                hourlyRate: '23',
                comment: 'row test'
            },
            {
                people: '5',
                hourlyRate: '20'
            }
        ]

        const selectedRateCalendar = 'ABC'

        const mockBuildRequest = {
            url: `${coreServicesUrl}/v2/efforts/engagements/team/DIREWOLF-DEV-TEAM/timeFrame/41902/engagement/5/calculated?all=false`,
            body: {
                calcInfo: {
                    calendarId: 'ABC',
                    rates: [
                        {
                            people: 4,
                            hourlyRate: 23,
                            comment: 'row test'
                        },
                        {
                            people: 5,
                            hourlyRate: 20
                        }
                    ]
                },
                comment: 'engagement comment'
            }
        }

        const patchResponse = [
            {
                error: false,
                payload: ''
            },
            {
                error: false,
                payload: ''
            }
        ]

        const toastrSuccess = toastr.success('successfully saved engagement')

        const fetchAllTeamEngagements = {
            type: FETCH_ALL_TEAM_ENGAGEMENTS
        }

        const setIsEditingEngagement = {
            type: SET_IS_EDITING_ENGAGEMENT,
            payload: false
        }

        const setSelectedCalendar = {
            type: SET_SELECTED_CALENDAR,
            payload: DEFAULT_RATE_CALENDAR
        }

        const clearCalculatorRows = {
            type: CLEAR_CALCULATOR_ROWS
        }

        const setTotalEngagementCost = {
            type: SET_TOTAL_ENGAGEMENT_COST,
            payload: null
        }

        const setIsCalculating = {
            type: SET_IS_CALCULATING,
            payload: {timeFrameId: null, engagementId: null}
        }

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(select(getCalculatorRows))
        expect(step(calculatorRows)).toEqual(select(getSelectedRateCalendar))
        expect(step(selectedRateCalendar)).toEqual(call(patch, mockBuildRequest))
        expect(step(patchResponse)).toEqual(dispatch(setIsLoadingFalse))
        expect(step()).toEqual(dispatch(setIsEditingEngagement))
        expect(step()).toEqual(dispatch(fetchAllTeamEngagements))
        expect(step()).toEqual(dispatch(setSelectedCalendar))
        expect(step()).toEqual(dispatch(clearCalculatorRows))
        expect(step()).toEqual(dispatch(setTotalEngagementCost))
        expect(step()).toEqual(dispatch(setIsCalculating))
        expect(step(toastrSuccess))
    })
})
