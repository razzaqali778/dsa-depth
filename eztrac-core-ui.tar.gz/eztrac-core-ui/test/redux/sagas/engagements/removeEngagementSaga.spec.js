import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {REMOVE_ENGAGEMENT} from '../../../../src/client/redux/constants/engagementConstants'
import {SET_IS_LOADING} from '../../../../src/client/redux/constants'
import {del} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {getSelectedTeam} from '../../../../src/client/redux/selectors'
import {urls} from '../../../urlConsts'
import actions from '../../../../src/client/redux/actions'
import listener, {
    removeEngagement
} from '../../../../src/client/redux/sagas/engagements/removeEngagementSaga'

const coreServicesUrl = urls.coreServices

const payload = {
    currentEngagement: {
        amount: 200000,
        amountType: 'Monthly',
        endDate: 1543622399000,
        engagementId: 'MONSANTO',
        engagementName: 'Monsanto',
        isEngagementActive: true,
        isTimeFrameActive: true,
        startDate: 1541030400000,
        teamId: 'DIREWOLF-DEV-TEAM',
        timeFrameId: 41812,
        timeFrameLockdown: false,
        timeFrameName: 'Dec 2018'
    }
}

const selectedTeam = {
    communityId: 'FIELD-MAPS',
    id: 'DIREWOLF-DEV-TEAM',
    isActive: true,
    name: 'Direwolf Dev Team'
}

const setIsLoadingTrue = {
    type: SET_IS_LOADING,
    payload: true
}

const setIsLoadingFalse = {
    type: SET_IS_LOADING,
    payload: false
}

describe('end engagement saga', () => {
    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [REMOVE_ENGAGEMENT]

        expect(step()).toEqual(takeLatest(constants, removeEngagement))
    })
    it('happy path on ending engagement', () => {
        const gen = removeEngagement({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const delRequestUrl = {
            url: `${coreServicesUrl}/v2/efforts/engagements/team/DIREWOLF-DEV-TEAM/timeFrame/41812/engagement/MONSANTO`,
            body: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41812,
                engagementId: 'MONSANTO'
            }
        }

        const delResponse = {
            error: false,
            payload: {
                response: 'OK'
            }
        }

        const updatedEngagements = [
            {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41811,
                amount: 200000,
                amountType: 'Monthly',
                engagementId: 'MONSANTO'
            }
        ]

        const toastrSuccess = toastr.success('Successfully ended engagement')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(del, delRequestUrl))
        expect(step(delResponse)).toEqual(dispatch(actions.fetchAllTeamEngagements()))
        expect(step(updatedEngagements)).toEqual(dispatch(setIsLoadingFalse))
        expect(step(toastrSuccess))
    })
    it('bad path with error on deleting engagement', () => {
        const gen = removeEngagement({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const delRequestUrl = {
            url: `${coreServicesUrl}/v2/efforts/engagements/team/DIREWOLF-DEV-TEAM/timeFrame/41812/engagement/MONSANTO`,
            body: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41812,
                engagementId: 'MONSANTO'
            }
        }

        const delResponse = {
            error: true,
            payload: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41812,
                amount: 200000
            }
        }

        const toastrError = toastr.error(payload, 'Failed to end engagement')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(del, delRequestUrl))
        expect(step(delResponse)).toEqual(dispatch(setIsLoadingFalse))
        expect(step(toastrError))
    })
})
