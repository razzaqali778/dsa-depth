import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {
    END_ENGAGEMENT,
    FETCH_ALL_TEAM_ENGAGEMENTS
} from '../../../../src/client/redux/constants/engagementConstants'
import {SET_IS_LOADING} from '../../../../src/client/redux/constants'
import {del} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {
    endEngagement
} from '../../../../src/client/redux/sagas/engagements/endEngagementSaga'

const coreServicesUrl = urls.coreServices

const selectedTeam = {
    communityId: 'FIELD-MAPS',
    id: 'DIREWOLF-DEV-TEAM',
    isActive: true,
    name: 'Direwolf Dev Team'
}

const engagement = [
    {
        timeFrameName: 'Nov 2018',
        timeFrameId: 41811,
        engagementId: 'ENGAGEMENT2'
    },
    {
        timeFrameId: 41812,
        engagementId: 'ENGAGEMENT2'
    },
    {
        timeFrameId: 41901,
        engagementId: 'ENGAGEMENT2'
    }
]

const fetchAllTeamEngagementsAction = {
    type: FETCH_ALL_TEAM_ENGAGEMENTS
}

const setIsLoadingTrue = {
    type: SET_IS_LOADING,
    payload: true
}

const setIsLoadingFalse = {
    type: SET_IS_LOADING,
    payload: false
}

describe('save engagement saga', () => {
    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [END_ENGAGEMENT]

        expect(step()).toEqual(takeLatest(constants, endEngagement))
    })

    it('if the end date is changed, it sends a delete request', () => {
        const payload = {
            endTimeFrame: 41812,
            selectedTeam,
            engagement
        }

        const gen = endEngagement({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const delRequestUrl = {
            url: `${coreServicesUrl}/v2/efforts/engagements/team/DIREWOLF-DEV-TEAM/timeFrame/41901/engagement/ENGAGEMENT2`,
            body: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41901,
                engagementId: 'ENGAGEMENT2'
            }
        }

        const delResponse = {
            error: false,
            payload: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41901,
                amount: 10000
            }
        }

        const toastrSuccess = toastr.success('Successfully saved engagement')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(call(del, delRequestUrl))
        expect(step(delResponse)).toEqual(dispatch(fetchAllTeamEngagementsAction))
        expect(step()).toEqual(dispatch(setIsLoadingFalse))
        expect(step(toastrSuccess))
    })

    it('if unsuccessful request', () => {
        const payload = {
            endTimeFrame: 41812,
            currentEngagement: {
                engagementId: 'ENGAGEMENT2'
            },
            currentEndTimeFrame: {
                value: 41906,
                label: 'Jun 2019'
            },
            selectedTeam,
            engagement
        }

        const gen = endEngagement({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const delRequestUrl = {
            url: `${coreServicesUrl}/v2/efforts/engagements/team/DIREWOLF-DEV-TEAM/timeFrame/41901/engagement/ENGAGEMENT2`,
            body: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41901,
                engagementId: 'ENGAGEMENT2'
            }
        }

        const delResponse = {
            error: true,
            payload: {
                teamId: 'DIREWOLF-DEV-TEAM',
                timeFrameId: 41901,
                amount: 10000
            }
        }

        const {delPayload} = delResponse

        const toastrError = toastr.error(delPayload, 'Failed to save')

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(call(del, delRequestUrl))
        expect(step(delResponse)).toEqual(dispatch(setIsLoadingFalse))
        expect(step(toastrError))
    })
})
