import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {
    CREATE_CALCULATED_ENGAGEMENT,
    FETCH_ALL_TEAM_ENGAGEMENTS,
    SET_SELECTED_CALENDAR,
    TOGGLE_IS_CREATING_ENGAGEMENT
} from '../../../../src/client/redux/constants/engagementConstants'
import {SET_IS_LOADING} from '../../../../src/client/redux/constants'
import {
    getCalculatorRows,
    getSelectedRateCalendar
} from '../../../../src/client/redux/selectors/engagements'
import {getSelectedTeam} from '../../../../src/client/redux/selectors'
import {post} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {
    createCalculatedEngagement
} from '../../../../src/client/redux/sagas/engagements/createCalculatedEngagementSaga'

const setIsLoadingTrue = {
    type: SET_IS_LOADING,
    payload: true
}

const setIsLoadingFalse = {
    type: SET_IS_LOADING,
    payload: false
}

const payload = {
    selectedStartTimeFrameId: 41902,
    selectedEndTimeFrameId: 41905,
    selectedEngagementId: '5'
}

const selectedTeam = {
    id: 'DIREWOLF-DEV-TEAM'
}

const payloadWithAmountDetails = {
    selectedStartTimeFrameId: 41902,
    selectedEndTimeFrameId: 41905,
    selectedEngagementId: '5',
    amountDetails: {
        calendarId: 'us-calendar-id',
        rates: [
            {
                people: 4,
                hourlyRate: 12
            }
        ]
    }
}

const postResponse = [
    {
        error: false,
        payload: ''
    },
    {
        error: false,
        payload: ''
    }
]

const toastrSuccess = toastr.success('successfully saved engagement')

const fetchAllTeamEngagements = {
    type: FETCH_ALL_TEAM_ENGAGEMENTS
}

const toggleIsCreatingEngagement = {
    type: TOGGLE_IS_CREATING_ENGAGEMENT,
    payload: false
}

const setSelectedCalendar = {
    type: SET_SELECTED_CALENDAR,
    payload: 'US-VARIABLE'
}

const coreServicesUrl = urls.coreServices

describe('createCalculatedEngagementSaga', () => {
    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value

        const constants = [CREATE_CALCULATED_ENGAGEMENT]

        expect(step()).toEqual(takeLatest(constants, createCalculatedEngagement))
    })

    it('calls the post to create an engagement with provided amountDetails', () => {
        const gen = createCalculatedEngagement({payload: payloadWithAmountDetails})
        const step = (lastYield) => gen.next(lastYield).value

        const mockBuildRequest = {
            url: `${coreServicesUrl}/v2/efforts/engagements/team/DIREWOLF-DEV-TEAM/timeFrame/41902/engagement/5/calculated`,
            body: {
                endTimeFrameId: payloadWithAmountDetails.selectedEndTimeFrameId,
                engagementCalcInfo: {
                    calendarId: payloadWithAmountDetails.amountDetails.calendarId,
                    rates: payloadWithAmountDetails.amountDetails.rates
                }
            }
        }

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(call(post, mockBuildRequest))
        expect(step(postResponse)).toEqual(dispatch(setIsLoadingFalse))
        expect(step()).toEqual(dispatch(fetchAllTeamEngagements))
        expect(step()).toEqual(dispatch(toggleIsCreatingEngagement))
        expect(step()).toEqual(dispatch(setSelectedCalendar))
        expect(step(toastrSuccess))
    })

    it('calls the post to create an engagement with new calculator info', () => {
        const gen = createCalculatedEngagement({payload})
        const step = (lastYield) => gen.next(lastYield).value

        const calculatorRows = [
            {
                people: '4',
                hourlyRate: '23',
                comment: 'a comment'
            },
            {
                people: '5',
                hourlyRate: '20'
            }
        ]

        const selectedRateCalendar = 'ABC'

        const mockBuildRequest = {
            url: `${coreServicesUrl}/v2/efforts/engagements/team/DIREWOLF-DEV-TEAM/timeFrame/41902/engagement/5/calculated`,
            body: {
                endTimeFrameId: payload.selectedEndTimeFrameId,
                engagementCalcInfo: {
                    calendarId: selectedRateCalendar,
                    rates: [
                        {
                            people: 4,
                            hourlyRate: 23,
                            comment: 'a comment'
                        },
                        {
                            people: 5,
                            hourlyRate: 20,
                            comment: undefined
                        }
                    ]
                }
            }
        }

        expect(step()).toEqual(dispatch(setIsLoadingTrue))
        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(select(getCalculatorRows))
        expect(step(calculatorRows)).toEqual(select(getSelectedRateCalendar))

        expect(step(selectedRateCalendar)).toEqual(call(post, mockBuildRequest))

        expect(step(postResponse)).toEqual(dispatch(setIsLoadingFalse))
        expect(step()).toEqual(dispatch(fetchAllTeamEngagements))
        expect(step()).toEqual(dispatch(toggleIsCreatingEngagement))
        expect(step()).toEqual(dispatch(setSelectedCalendar))
        expect(step(toastrSuccess))
    })
})
