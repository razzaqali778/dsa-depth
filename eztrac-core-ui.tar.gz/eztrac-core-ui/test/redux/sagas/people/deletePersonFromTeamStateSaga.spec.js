import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {
    DELETE_PERSON_FROM_TEAM_STATE,
    SET_SELECTED_TIME_FRAME_TEAM_PEOPLE
} from '../../../../src/client/redux/constants/peopleConstants'
import {getSelectedTimeFrameTeamPeople} from '../../../../src/client/redux/selectors/people'
import listener, {
    deletePersonFromTeamState
} from '../../../../src/client/redux/sagas/people/deletePersonFromTeamStateSaga'

describe('listener', () => {
    it('listens only on DELETE_PERSON_FROM_TEAM_STATE', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['people/DELETE_PERSON_FROM_TEAM_STATE']

        expect(step()).toEqual(takeLatest(constants, deletePersonFromTeamState))
    })
})

describe('deletePersonFromState saga flow', () => {
    const selectedTimeFrameTeamPeople = [
        {
            personId: 2,
            personName: 'Otle, Chip'
        },
        {
            personId: 3,
            personName: 'Bucks, Star'
        }
    ]

    const setSelectedTimeFrameTeamPeopleAction = (value) => ({
        type: SET_SELECTED_TIME_FRAME_TEAM_PEOPLE,
        payload: value
    })

    it('deletes the person from state in the selectedTimeFrameTeamPeople', () => {
        const deletePerson = {
            personId: 3,
            personName: 'Bucks, Star'
        }

        const action = {
            type: DELETE_PERSON_FROM_TEAM_STATE,
            payload: deletePerson
        }

        const gen = deletePersonFromTeamState(action)
        const step = (lastYield) => gen.next(lastYield).value

        const expectedResult = [
            {
                personId: 2,
                personName: 'Otle, Chip'
            }
        ]

        expect(step()).toEqual(select(getSelectedTimeFrameTeamPeople))
        expect(step(selectedTimeFrameTeamPeople)).toEqual(
            dispatch(setSelectedTimeFrameTeamPeopleAction(expectedResult))
        )
        expect(gen.next().done).toBe(true)
    })
})
