import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {fetchAllRates} from '../../../../src/client/redux/sagas/people/fetchAllRatesSaga'

const costingServicesUrl = urls.costingServices

describe('listener', () => {
    it('listens only on RATES', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['people/FETCH_RATES']

        expect(step()).toEqual(takeLatest(constants, fetchAllRates))
    })
})

describe('saga flow', () => {
    it('happy path', () => {
        const gen = fetchAllRates()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/rates`
        const mockRates = [
            {id: '1', name: 'some', isActive: 'true'},
            {id: '2', name: 'some', isActive: 'true'}
        ]
        const setRatesAction = {
            type: 'people/SET_RATES',
            payload: mockRates
        }

        const mockGetResult = {
            payload: mockRates,
            error: false
        }

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setRatesAction))
        expect(gen.next().done).toBe(true)
    })
    it('bad path', () => {
        const gen = fetchAllRates()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/rates`

        const mockGetResult = {
            payload: 'It broke',
            error: true
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch rates')

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
