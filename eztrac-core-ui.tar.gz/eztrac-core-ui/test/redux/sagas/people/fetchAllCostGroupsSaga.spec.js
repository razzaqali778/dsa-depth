import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../../urlConsts'
import listener, {
    fetchAllCostGroups
} from '../../../../src/client/redux/sagas/people/fetchAllCostGroupsSaga'

const costingServicesUrl = urls.costingServices

describe('listener', () => {
    it('listens only on COST-GROUPS', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['people/FETCH_COST_GROUPS']

        expect(step()).toEqual(takeLatest(constants, fetchAllCostGroups))
    })
})

describe('saga flow', () => {
    it('happy path', () => {
        const gen = fetchAllCostGroups()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/costGroups`
        const mockRates = [
            {id: '1', name: 'some', isActive: 'true'},
            {id: '2', name: 'some', isActive: 'true'}
        ]
        const setCostGroupsAction = {
            type: 'people/SET_COST_GROUPS',
            payload: mockRates
        }

        const mockGetResult = {
            payload: mockRates,
            error: false
        }

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setCostGroupsAction))
        expect(gen.next().done).toBe(true)
    })
    it('bad path', () => {
        const gen = fetchAllCostGroups()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${costingServicesUrl}/v1/costGroups`

        const mockGetResult = {
            payload: 'It broke',
            error: true
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch cost groups')

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
