import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {
    CLEAR_NEW_FORECASTED_PERSON_DATA,
    SET_SELECTED_TIME_FRAME_FORECASTED_PEOPLE
} from '../../../../src/client/redux/constants/peopleConstants'
import {appendTimeFrameId} from '../../../../src/client/redux/utils/newInitiative'
import {
    getNewForecastedPersonData,
    getSelectedTimeFrameForecastedPeople
} from '../../../../src/client/redux/selectors/people'
import {
    getSelectedTimeFrameId,
    getSortOrderPreferencePeopleLocal
} from '../../../../src/client/redux/selectors'
import listener, {
    addNewForecastedPersonFromState
} from '../../../../src/client/redux/sagas/people/addNewForecastedPersonFromStateSaga'

describe('listener', () => {
    it('listens only on ADD_NEW_FORECASTED_PERSON_FROM_STATE', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['people/ADD_NEW_FORECASTED_PERSON_FROM_STATE']

        expect(step()).toEqual(takeLatest(constants, addNewForecastedPersonFromState))
    })
})

describe('addNewForecastedPersonFromState saga flow', () => {
    const selectedTimeFrameId = 41905

    const selectedTimeFrameForecastedPeople = [
        {
            rateId: 'PEPPER',
            costGroupId: 'A_TON',
            numberOfPeople: 4
        },
        {
            rateId: 'GALAXY',
            costGroupId: 'NONE',
            numberOfPeople: 4
        }
    ]

    const clearNewForecastedPersonDataAction = {
        type: CLEAR_NEW_FORECASTED_PERSON_DATA
    }
    const sortOrderPreferencePeopleLocal = {
        costGroupNum: 0,
        nameNum: 1,
        numberOfPeopleNum: 0,
        participationNum: 0,
        rateNum: 0
    }
    const newSelectedTimeFrameForecastedPeople = (value) => [
        ...selectedTimeFrameForecastedPeople,
        appendTimeFrameId(value, selectedTimeFrameId)
    ]

    const setSelectedTimeFrameForecastedPeopleAction = (value) => ({
        type: SET_SELECTED_TIME_FRAME_FORECASTED_PEOPLE,
        payload: value
    })

    it('adds the new forecasted person from state to the selectedTimeFrameTeamPeople', () => {
        const gen = addNewForecastedPersonFromState()
        const step = (lastYield) => gen.next(lastYield).value

        const newForecastedPersonData = {
            rateId: 'WIP',
            costGroupId: 'RIP',
            numberOfPeople: 0
        }

        const expectedResult = newSelectedTimeFrameForecastedPeople(newForecastedPersonData)

        expect(step()).toEqual(select(getNewForecastedPersonData))
        expect(step(newForecastedPersonData)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(select(getSelectedTimeFrameForecastedPeople))
        expect(step(selectedTimeFrameForecastedPeople)).toEqual(
            select(getSortOrderPreferencePeopleLocal)
        )
        expect(step(sortOrderPreferencePeopleLocal)).toEqual(
            dispatch(setSelectedTimeFrameForecastedPeopleAction(expectedResult))
        )
        expect(step()).toEqual(dispatch(clearNewForecastedPersonDataAction))
        expect(gen.next().done).toBe(true)
    })
})
