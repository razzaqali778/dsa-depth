import {put as dispatch, select, takeEvery} from 'redux-saga/effects'
import {
    COPY_PEOPLE_FORWARD,
    UPDATE_PEOPLE
} from '../../../../src/client/redux/constants/peopleConstants'
import {getTeamPeople} from '../../../../src/client/redux/selectors/people'
import listener, {
    copyPeopleForward
} from '../../../../src/client/redux/sagas/people/copyPeopleForwardSaga'

describe('listens for copyPeopleForwardSaga', () => {
    const copyForwardFromTimeFrame = 41910
    const copyForwardToTimeFrame = 41911
    const payload = {copyForwardFromTimeFrame, copyForwardToTimeFrame}
    const teamPeople = [
        {
            costGroupName: 'HISTORIC',
            isActive: true,
            isEmployee: true,
            modifiedBy: 'automatic',
            participationPct: 100,
            personId: 'MATLN',
            personName: 'Mert Lernt',
            rateName: 'very little',
            timeFrameId: 41910
        }
    ]
    const updatePayload = {
        payload: {
            selectedTimeFrameId: copyForwardToTimeFrame,
            peopleToBeCopied: teamPeople
        },
        type: UPDATE_PEOPLE
    }

    it('listens on the correct action', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value

        const constants = [COPY_PEOPLE_FORWARD]
        expect(step()).toEqual(takeEvery(constants, copyPeopleForward))
    })

    it('happy path: successfully copies forward people', () => {
        const gen = copyPeopleForward({payload})
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(select(getTeamPeople))
        expect(step(teamPeople)).toEqual(dispatch(updatePayload))
    })
})
