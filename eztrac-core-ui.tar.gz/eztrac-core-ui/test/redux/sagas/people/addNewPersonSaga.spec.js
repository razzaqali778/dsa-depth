import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import sortBy from 'lodash/sortBy'
import {
    ADD_NEW_PERSON,
    SET_SELECTED_TIME_FRAME_TEAM_PEOPLE
} from '../../../../src/client/redux/constants/peopleConstants'
import {appendTimeFrameId} from '../../../../src/client/redux/utils/newInitiative'
import {
    getSelectedTimeFrameId,
    getSortOrderPreferencePeopleLocal
} from '../../../../src/client/redux/selectors'
import {getSelectedTimeFrameTeamPeople} from '../../../../src/client/redux/selectors/people'
import listener, {addNewPerson} from '../../../../src/client/redux/sagas/people/addNewPersonSaga'

describe('addPerson listener', () => {
    it('listens on the correct actions', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constant = ['people/ADD_NEW_PERSON']

        expect(step()).toEqual(takeLatest(constant, addNewPerson))
    })
})
describe('addPerson saga flow', () => {
    const selectedPersonFramework = {
        costGroupName: 'costGroupA',
        isActive: true,
        isEmployee: true,
        modifiedBy: 'Pepper',
        personId: '1',
        personName: 'Pepper1',
        rateName: 'PepperRate'
    }
    const sortOrderPreferencePeopleLocal = {
        costGroupNum: 0,
        nameNum: 1,
        numberOfPeopleNum: 0,
        participationNum: 0,
        rateNum: 0
    }
    const selectedTimeFrameTeamPeople = [
        {
            ...selectedPersonFramework,
            personId: '2',
            personName: 'Galaxy'
        },
        {
            ...selectedPersonFramework,
            personId: '3',
            personName: 'WIP'
        },
        {
            ...selectedPersonFramework,
            personId: '4',
            personName: 'Team4'
        }
    ]
    const selectedTimeFrameId = 41905

    const setSelectedTimeFrameTeamPeopleAction = (value) => ({
        type: SET_SELECTED_TIME_FRAME_TEAM_PEOPLE,
        payload: value
    })

    const newSelectedTimeFrameTeamPeople = (value) => [
        ...selectedTimeFrameTeamPeople,
        appendTimeFrameId(value, selectedTimeFrameId)
    ]
    it('prints error to console when passed an empty payload', () => {
        const gen = addNewPerson({})
        const step = (lastYield) => gen.next(lastYield).value
        const newPersonData = {
            ...selectedPersonFramework,
            personId: '2',
            personName: 'Galaxy'
        }
        const updatedPersonData = newSelectedTimeFrameTeamPeople(newPersonData)

        expect(step(updatedPersonData)).toEqual(select(getSelectedTimeFrameTeamPeople))
        expect(step(selectedTimeFrameTeamPeople)).toEqual(select(getSelectedTimeFrameId))
        expect(gen.next().done).toBe(true)
    })

    it('adds a person when a row.id is not in the current array', () => {
        const newRow = {
            ...selectedPersonFramework,
            personId: '6',
            personName: 'Team6'
        }
        const action = {
            type: ADD_NEW_PERSON,
            payload: newRow
        }
        const gen = addNewPerson(action)
        const step = (lastYield) => gen.next(lastYield).value
        const expectedResult = sortBy(newSelectedTimeFrameTeamPeople(newRow), 'personName')

        expect(step([])).toEqual(select(getSelectedTimeFrameTeamPeople))
        expect(step(selectedTimeFrameTeamPeople)).toEqual(select(getSelectedTimeFrameId))
        expect(step(selectedTimeFrameId)).toEqual(select(getSortOrderPreferencePeopleLocal))
        expect(step(sortOrderPreferencePeopleLocal)).toEqual(
            dispatch(setSelectedTimeFrameTeamPeopleAction(expectedResult))
        )
        expect(gen.next().done).toBe(true)
    })
})
