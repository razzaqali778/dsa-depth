import * as Saga from 'redux-saga/effects'
import {
    FETCH_TEAM_FORECASTED_PEOPLE,
    SET_SELECTED_TIME_FRAME_FORECASTED_PEOPLE,
    SET_TEAM_FORECASTED_PEOPLE
} from '../../../src/client/redux/constants/peopleConstants'
import {recordSaga} from './runSaga'
import {testStateBuilder} from '../../testStateBuilder'
import actions from '../../../src/client/redux/actions'
import listener, {
    fetchTeamForecastedPeople
} from '../../../src/client/redux/sagas/people/fetchTeamForecastedPeopleSaga'

describe('Fetch Team Forecasted People Saga', () => {
    it('Listens on the correct actions', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [FETCH_TEAM_FORECASTED_PEOPLE]
        expect(step()).toEqual(Saga.takeLatest(constants, fetchTeamForecastedPeople))
    })

    describe('given an executed saga, ', () => {
        let dispatchedActions
        const findAction = (actionName) =>
            dispatchedActions.find((action) => action.type === actionName)
        const effortResponse = [
            {
                timeFrameId: 41912,
                id: 119245,
                cost: 612000,
                forecastPeople: [{costGroupId: 'CGID1', numberOfPeople: 2.5, rateId: 'RATEID1'}]
            },
            {
                timeFrameId: 42001,
                id: 119245,
                cost: 612000,
                forecastPeople: [{costGroupId: 'CGID2', numberOfPeople: 1, rateId: 'RATEID2'}]
            }
        ]

        beforeEach(async () => {
            dispatchedActions = await recordSaga(
                fetchTeamForecastedPeople,
                {type: FETCH_TEAM_FORECASTED_PEOPLE, payload: effortResponse},
                testStateBuilder({timeFrame: {selectedTimeFrameId: 41912}})
            )
        })
        it('dispatches an action with formatted team people data ', () => {
            const expectedForecastedPeopleData = [
                {costGroupId: 'CGID1', rateId: 'RATEID1', numberOfPeople: 2.5, timeFrameId: 41912},
                {costGroupId: 'CGID2', rateId: 'RATEID2', numberOfPeople: 1, timeFrameId: 42001}
            ]
            expect(findAction(SET_TEAM_FORECASTED_PEOPLE)).toEqual(
                actions.setTeamForecastedPeople(expectedForecastedPeopleData)
            )
        })
        it('sets the selected time frame team people', () => {
            const expectedSelectedTimeFrameTeamPeopleData = [
                {costGroupId: 'CGID1', rateId: 'RATEID1', numberOfPeople: 2.5, timeFrameId: 41912}
            ]

            expect(findAction(SET_SELECTED_TIME_FRAME_FORECASTED_PEOPLE)).toEqual(
                actions.setSelectedTimeFrameForecastedPeople(
                    expectedSelectedTimeFrameTeamPeopleData
                )
            )
        })
    })
})
