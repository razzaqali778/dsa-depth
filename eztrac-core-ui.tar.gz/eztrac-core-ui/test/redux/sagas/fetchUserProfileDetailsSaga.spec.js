import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import {getUserProfileDetails} from '../../../src/client/redux/sagas/helpers/papi'
import {FETCH_USER_PROFILE_DETAILS} from '../../../src/client/redux/constants/peopleConstants'
import actions from '../../../src/client/redux/actions'
import listener, {
    fetchUserProfileDetailsById
} from '../../../src/client/redux/sagas/fetchUserProfileDetailsSaga'

describe('fetch user profile details', () => {
    it('dispatches EMPTY status when no personId is provided', () => {
        const gen = fetchUserProfileDetailsById({payload: {}})

        expect(gen.next().value).toEqual(dispatch(actions.setUserProfileDetails({status: 'EMPTY'})))
        expect(gen.next().done).toBe(true)
    })

    it('dispatches LOADING then OK with the fetched data on success', () => {
        const gen = fetchUserProfileDetailsById({payload: {personId: '123'}})
        const dummyUserData = {id: '123', preferredName: {first: 'Jane', last: 'Doe'}}

        expect(gen.next().value).toEqual(
            dispatch(actions.setUserProfileDetails({status: 'LOADING'}))
        )
        expect(gen.next().value).toEqual(call(getUserProfileDetails, {userId: '123'}))
        expect(gen.next(dummyUserData).value).toEqual(
            dispatch(actions.setUserProfileDetails({status: 'OK', ...dummyUserData}))
        )
        expect(gen.next().done).toBe(true)
    })

    it('dispatches ERROR status via setUserProfileDetails when the fetch returns no data', () => {
        const gen = fetchUserProfileDetailsById({payload: {personId: '123'}})

        gen.next()
        gen.next()
        // Regression test: this previously called the nonexistent `actions.setUserProfileDetail`
        // (singular), which threw a TypeError and crashed the saga instead of surfacing the
        // "Unable to find additional user data" error state.
        expect(gen.next(undefined).value).toEqual(
            dispatch(actions.setUserProfileDetails({status: 'ERROR'}))
        )
        expect(gen.next().done).toBe(true)
    })

    it('listens on fetch user profile details action', () => {
        const gen = listener()

        expect(gen.next().value).toEqual(
            takeLatest([FETCH_USER_PROFILE_DETAILS], fetchUserProfileDetailsById)
        )
    })
})
