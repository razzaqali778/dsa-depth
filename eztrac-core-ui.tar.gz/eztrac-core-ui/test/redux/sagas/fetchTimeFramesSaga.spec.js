import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../../../src/client/redux/sagas/helpers/makeFetchCall'
import {getTimeFrames} from '../../../src/client/redux/selectors'
import {urls} from '../../urlConsts'
import getCurrentMonthTimeFrame from '../../../src/client/redux/selectors/getCurrentMonthTimeFrame'
import listener, {fetchTimeFrames} from '../../../src/client/redux/sagas/fetchTimeFramesSaga'

const coreServicesUrl = urls.coreServices

describe('listener', () => {
    it('listens only on FETCH_TIME_FRAMES', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['timeFrames/FETCH_TIME_FRAMES']

        expect(step()).toEqual(takeLatest(constants, fetchTimeFrames))
    })
})

describe('saga flow', () => {
    it('happy path', () => {
        const gen = fetchTimeFrames()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${coreServicesUrl}/v2/timeframes`
        const mockTimeFrames = ['some', 'stuff']
        const timeFrames = [
            {id: 41903, startDate: 1551398400000},
            {id: 41904, startDate: 1554076800000},
            {id: 41905, startDate: 1556668800000},
            {id: 41906, startDate: 1559347200000}
        ]
        const currentMonthTimeFrame = {id: 41904}
        const startTimeFrame = {id: 41903, startCode: 1551398400000}
        const endTimeFrame = {id: 41906, startCode: 1559347200000}

        const setTimeFramesAction = {
            type: 'timeFrames/SET_TIME_FRAMES',
            payload: mockTimeFrames
        }
        const setSelectedTimeFrameAction = {
            type: 'timeFrames/SET_SELECTED_TIME_FRAME_ID',
            payload: currentMonthTimeFrame.id
        }

        const setStartTimeFrameAction = {
            type: 'timeFrames/SET_START_TIME_FRAME',
            payload: startTimeFrame
        }

        const setEndTimeFrameAction = {
            type: 'timeFrames/SET_END_TIME_FRAME',
            payload: endTimeFrame
        }

        const mockGetResult = {payload: mockTimeFrames, error: false}
        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setTimeFramesAction))
        expect(step()).toEqual(select(getCurrentMonthTimeFrame))
        expect(step(currentMonthTimeFrame)).toEqual(dispatch(setSelectedTimeFrameAction))
        expect(step()).toEqual(select(getTimeFrames))
        expect(step(timeFrames)).toEqual(dispatch(setStartTimeFrameAction))
        expect(step()).toEqual(dispatch(setEndTimeFrameAction))
        expect(gen.next().done).toBe(true)
    })
    it('bad path', () => {
        const gen = fetchTimeFrames()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${coreServicesUrl}/v2/timeframes`

        const mockGetResult = {
            payload: 'It broke',
            error: true
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch timeframes')

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
