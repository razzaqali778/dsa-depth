import {call, put as dispatch} from 'redux-saga/effects'
import {SET_SORT_ORDER_PREFERENCE} from '../../../src/client/redux/constants/preferencesConstants'
import {getSortOrderPreferenceServer} from '../../../src/client/redux/sagas/helpers/preferences'
import saga from '../../../src/client/redux/sagas/preferences/fetchSortOrderPreferencesSaga'

describe('fetchSortOrderPreferences', () => {
    it('fetches sortOrderPreference and sets it in state', () => {
        const gen = saga()
        const step = (lastYield) => gen.next(lastYield).value

        const sortOrderPreference = {
            sort: {
                nameNum: 0,
                allocationNum: 0,
                costNum: 1
            }
        }

        const action = {
            type: SET_SORT_ORDER_PREFERENCE,
            payload: sortOrderPreference.sort
        }

        expect(step()).toEqual(call(getSortOrderPreferenceServer))
        expect(step(sortOrderPreference)).toEqual(dispatch(action))
        expect(gen.next().done).toEqual(true)
    })
    it('fails to fetch sortOrderPreference and returns default sort order', () => {
        const gen = saga()
        const step = (lastYield) => gen.next(lastYield).value

        const sortOrderPreference = {}

        const expectedSortOrderPreference = {
            nameNum: 1,
            allocationNum: 0,
            costNum: 0
        }
        const action = {
            type: SET_SORT_ORDER_PREFERENCE,
            payload: expectedSortOrderPreference
        }
        expect(step()).toEqual(call(getSortOrderPreferenceServer))
        const sortOrderPreferenceStep = step(sortOrderPreference)
        expect(sortOrderPreferenceStep).toEqual(dispatch(action))
        expect(sortOrderPreferenceStep.PUT.action.payload).toEqual(expectedSortOrderPreference)
        expect(gen.next().done).toEqual(true)
    })
})
