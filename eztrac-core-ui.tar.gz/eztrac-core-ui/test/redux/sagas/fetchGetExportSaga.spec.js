import {call, takeLatest} from 'redux-saga/effects'
import {get} from '../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../urlConsts'
import listener, {fetchGetExport} from '../../../src/client/redux/sagas/fetchGetExportSaga'

const coreServicesUrl = urls.coreServices

describe('listener', () => {
    it('listens only on FETCH_GET_EXPORT', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['getExport/FETCH_GET_EXPORT']

        expect(step()).toEqual(takeLatest(constants, fetchGetExport))
    })
})

describe.skip('saga flow', () => {
    it('calls getExport successfully', () => {
        const gen = fetchGetExport()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${coreServicesUrl}/v2/getExport/timeFrameId/42004/teams?teamId=SPIRIT-DEV-TEAM&teamId=VORTEX-DEV-TEAM&teamId=ARMAGEDDON-DEV-TEAM`
        // const mockTeams = [ 'some', 'stuff' ]
        // const setTeamsAction = {
        //   type: 'team/SET_TEAMS',
        //   payload: mockTeams,
        // }

        // const mockGetResult = {
        //   payload: mockTeams,
        //   error: false,
        // }

        expect(step()).toEqual(call(get, {url}))
        // expect(step(mockGetResult)).toEqual(dispatch(setTeamsAction))
        // expect(gen.next().done).toBe(true)
    })
    // it.skip('bad path', () => {
    //   const gen = fetchTeams()
    //   const step = lastYield => gen.next(lastYield).value

    //   const url = `${coreServicesUrl}/v2/teams`

    //   const mockGetResult = {
    //     payload: 'It broke',
    //     error: true,
    //   }

    //   const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch teams')

    //   expect(step()).toEqual(call(get, { url }))
    //   expect(step(mockGetResult)).toEqual()
    //   expect(step(toastrError))
    //   expect(gen.next().done).toBe(true)
    // })
})
