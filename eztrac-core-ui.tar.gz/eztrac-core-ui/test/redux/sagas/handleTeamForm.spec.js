import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {
    SET_FORM_COMMUNITY_ID,
    SET_FORM_IS_ACTIVE,
    SET_FORM_TEAM_NAME,
    SET_IS_EDITING,
    TOGGLE_IS_CREATING_TEAM
} from '../../../src/client/redux/constants/teamConstants'
import {getIsCreatingTeam, getSelectedTeam, getTeams} from '../../../src/client/redux/selectors'
import listener, {handleTeamForm} from '../../../src/client/redux/sagas/handleTeamForm'

describe('listener', () => {
    it('listens on actions', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = [SET_IS_EDITING, TOGGLE_IS_CREATING_TEAM]

        expect(step()).toEqual(takeLatest(constants, handleTeamForm))
    })
})

describe('handleTeamForm', () => {
    it('sets the form team name, community ID, and active flag', () => {
        const gen = handleTeamForm()
        const step = (lastYield) => gen.next(lastYield).value

        const selectedTeam = {id: 'TEAM-1', name: 'Team 1'}
        const teams = [
            {id: 'TEAM-1', name: 'Team 1', communityId: 'COMMUNITY-1', isActive: true},
            {id: 'TEAM-2', name: 'Team 2', communityId: 'COMMUNITY-1', isActive: true}
        ]

        const setFormTeamNameAction = {
            type: SET_FORM_TEAM_NAME,
            payload: 'Team 1'
        }

        const setFormCommunityIdAction = {
            type: SET_FORM_COMMUNITY_ID,
            payload: 'COMMUNITY-1'
        }

        const setFormIsActiveAction = {
            type: SET_FORM_IS_ACTIVE,
            payload: true
        }
        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(select(getTeams))
        expect(step(teams)).toEqual(select(getIsCreatingTeam))
        expect(step(false)).toEqual(dispatch(setFormTeamNameAction))
        expect(step()).toEqual(dispatch(setFormCommunityIdAction))
        expect(step()).toEqual(dispatch(setFormIsActiveAction))
        expect(gen.next().done).toBe(true)
    })
    it('returns an empty object if a teamId is not found', () => {
        const gen = handleTeamForm()
        const step = (lastYield) => gen.next(lastYield).value

        const selectedTeam = {id: 'TEAM-3', name: 'Team 3'}
        const teams = [
            {id: 'TEAM-1', name: 'Team 1', communityId: 'COMMUNITY-1', isActive: true},
            {id: 'TEAM-2', name: 'Team 2', communityId: 'COMMUNITY-1', isActive: true}
        ]

        const setFormTeamNameAction = {
            type: SET_FORM_TEAM_NAME
        }

        const setFormCommunityIdAction = {
            type: SET_FORM_COMMUNITY_ID
        }

        const setFormIsActiveAction = {
            type: SET_FORM_IS_ACTIVE
        }
        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(select(getTeams))
        expect(step(teams)).toEqual(select(getIsCreatingTeam))
        expect(step(false)).toEqual(dispatch(setFormTeamNameAction))
        expect(step()).toEqual(dispatch(setFormCommunityIdAction))
        expect(step()).toEqual(dispatch(setFormIsActiveAction))
        expect(gen.next().done).toBe(true)
    })
    it('sets the form team name, community ID, and active flag for new team', () => {
        const gen = handleTeamForm()
        const step = (lastYield) => gen.next(lastYield).value

        const selectedTeam = {id: null, name: 'New Team'}
        const teams = []

        const setFormTeamNameAction = {
            type: SET_FORM_TEAM_NAME,
            payload: 'New Team'
        }

        const setFormCommunityIdAction = {
            type: SET_FORM_COMMUNITY_ID,
            payload: null
        }

        const setFormIsActiveAction = {
            type: SET_FORM_IS_ACTIVE,
            payload: true
        }
        expect(step()).toEqual(select(getSelectedTeam))
        expect(step(selectedTeam)).toEqual(select(getTeams))
        expect(step(teams)).toEqual(select(getIsCreatingTeam))
        expect(step(true)).toEqual(dispatch(setFormTeamNameAction))
        expect(step()).toEqual(dispatch(setFormCommunityIdAction))
        expect(step()).toEqual(dispatch(setFormIsActiveAction))
        expect(gen.next().done).toBe(true)
    })
})
