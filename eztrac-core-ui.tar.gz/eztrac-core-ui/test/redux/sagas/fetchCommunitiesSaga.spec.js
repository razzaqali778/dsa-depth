import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {SET_COMMUNITIES} from '../../../src/client/redux/constants/teamConstants'
import {get} from '../../../src/client/redux/sagas/helpers/makeFetchCall'
import {urls} from '../../urlConsts'
import listener, {
    fetchCommunities
} from '../../../src/client/redux/sagas/teams/fetchCommunitiesSaga'

const coreServicesUrl = urls.coreServices

describe('listener', () => {
    it('listens on FETCH_COMMUNITIES', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constant = ['team/FETCH_COMMUNITIES']
        expect(step()).toEqual(takeLatest(constant, fetchCommunities))
    })
})

describe('saga flow', () => {
    it('successfully fetches communities', () => {
        const gen = fetchCommunities()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${coreServicesUrl}/v2/communities`

        const mockCommunities = [
            {
                name: 'Logistics'
            },
            {
                name: 'Maps'
            }
        ]

        const setCommunitesAction = {
            type: SET_COMMUNITIES,
            payload: mockCommunities
        }

        const mockGetResult = {
            payload: mockCommunities,
            error: false
        }

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual(dispatch(setCommunitesAction))
        expect(gen.next().done).toBe(true)
    })
    it('displays a toastr error if it fails to fetch communities', () => {
        const gen = fetchCommunities()
        const step = (lastYield) => gen.next(lastYield).value

        const url = `${coreServicesUrl}/v2/communities`

        const mockGetResult = {
            payload: 'error',
            error: true
        }

        const toastrError = toastr.error(mockGetResult.payload, 'Failed to fetch communities')

        expect(step()).toEqual(call(get, {url}))
        expect(step(mockGetResult)).toEqual()
        expect(step(toastrError))
        expect(gen.next().done).toBe(true)
    })
})
