import {put as dispatch, takeLatest} from 'redux-saga/effects'
import {FETCH_ALL_TEAM_ENGAGEMENTS} from '../../../src/client/redux/constants/engagementConstants'
import {SET_SELECTED_TEAM} from '../../../src/client/redux/constants/teamConstants'
import {SET_SELECTED_TEAM_TAB} from '../../../src/client/redux/constants/preferencesConstants'
import actions from '../../../src/client/redux/actions'
import listener, {
    handleLocationStateChange
} from '../../../src/client/redux/sagas/handleLocationStateChange'

describe('listener', () => {
    it('listens on SET_SELECTED_TEAM & SET_SELECTED_TEAM_TAB', () => {
        const gen = listener()
        const step = (lastYield) => gen.next(lastYield).value
        const constants = ['team/SET_SELECTED_TEAM', 'preferences/SET_SELECTED_TEAM_TAB']

        expect(step()).toEqual(takeLatest(constants, handleLocationStateChange))
    })
})

describe('handleLocationStateChangeSaga', () => {
    it('dispatches updateLocationQuery for the setSelectedTeam action if there is a payload & payload.id', () => {
        const setSelectedTeamAction = {
            type: SET_SELECTED_TEAM,
            payload: {
                id: '1'
            }
        }

        const {id} = setSelectedTeamAction.payload

        const gen = handleLocationStateChange(setSelectedTeamAction)
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(dispatch(actions.updateLocationQuery({teamId: id})))
    })
    it('dispatches removeLocationQuery for the setSelectedTeam action if there is not a payload & payload.id', () => {
        const setSelectedTeamAction = {
            type: SET_SELECTED_TEAM
        }

        const gen = handleLocationStateChange(setSelectedTeamAction)
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(dispatch(actions.removeLocationQuery('teamId')))
    })
    it('dispatches updateLocationQuery for the setSelectedTeamTab if there is a payload', () => {
        const setSelectedTeamTabAction = {
            type: SET_SELECTED_TEAM_TAB,
            payload: 'engagements'
        }

        const {payload} = setSelectedTeamTabAction

        const gen = handleLocationStateChange(setSelectedTeamTabAction)
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(dispatch(actions.updateLocationQuery({teamTab: payload})))
    })
    it('dispatches removeLocationQuery for the setSelectedTeamTab if there is not a payload', () => {
        const setSelectedTeamTabAction = {
            type: SET_SELECTED_TEAM_TAB
        }

        const gen = handleLocationStateChange(setSelectedTeamTabAction)
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(dispatch(actions.removeLocationQuery('teamTab')))
    })
    it('returns null if the action type does not match any of the action in ther cases above', () => {
        const action = {
            type: FETCH_ALL_TEAM_ENGAGEMENTS
        }

        const gen = handleLocationStateChange(action)
        const step = (lastYield) => gen.next(lastYield).value

        expect(step()).toEqual(null)
    })
})
