import selector from '../../../src/client/redux/selectors/getTimeFrameTeamInitiatives'

// This selector works upon the assumption that timeframes will continuously increase going forward
// for example 2018 had a time frame like 32104 and 2019 has a time frame like 41904

describe('get time frame team initiatives', () => {
    it('returns a filtered array of initiatives for a team for a selected time frame', () => {
        const state = {
            initiative: {
                teamInitiatives: [
                    {timeFrameId: 41901, initiativeName: '1', vipId: '1'},
                    {timeFrameId: 41902, initiativeName: '2', vipId: '2'},
                    {timeFrameId: 41903, initiativeName: '3', vipId: '3'},
                    {timeFrameId: 41904, initiativeName: '4', vipId: '4'},
                    {timeFrameId: 41905, initiativeName: '5', vipId: '5'},
                    {timeFrameId: 41906, initiativeName: '6', vipId: '6'}
                ]
            },
            timeFrame: {
                startTimeFrame: {
                    id: 41903
                },
                endTimeFrame: {
                    id: 41905
                }
            }
        }

        const expected = [
            {timeFrameId: 41903, initiativeName: '3', vipId: '3'},
            {timeFrameId: 41904, initiativeName: '4', vipId: '4'},
            {timeFrameId: 41905, initiativeName: '5', vipId: '5'}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
