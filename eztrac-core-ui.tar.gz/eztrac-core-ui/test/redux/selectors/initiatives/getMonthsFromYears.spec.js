import selector from '../../../../src/client/redux/selectors/initiatives/getMonthsFromYears'

describe('get months from years', () => {
    it('returns an empty array if timeFrames is empty', () => {
        const state = {
            timeFrame: {
                timeFrames: []
            }
        }
        const expected = []

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns a list of years with their months in the future relative to selected time frame', () => {
        const state = {
            timeFrame: {
                selectedTimeFrameId: 10,
                timeFrames: [
                    {
                        name: 'Oct 2019',
                        id: 10,
                        isActive: true,
                        startDate: new Date('2019-10-01').getTime(),
                        endDate: new Date('2019-10-31').getTime()
                    },
                    {
                        name: 'Nov 2019',
                        id: 11,
                        isActive: true,
                        startDate: new Date('2019-11-01').getTime(),
                        endDate: new Date('2019-11-30').getTime()
                    },
                    {
                        name: 'Jan 2020',
                        id: 1,
                        isActive: true,
                        startDate: new Date('2020-01-01').getTime(),
                        endDate: new Date('2020-01-31').getTime()
                    }
                ]
            }
        }
        const expected = [
            {
                year: '2019',
                months: [
                    {
                        month: 'Nov',
                        id: 11,
                        isActive: true,
                        startTime: new Date('2019-11-01').getTime()
                    }
                ]
            },
            {
                year: '2020',
                months: [
                    {
                        month: 'Jan',
                        id: 1,
                        isActive: true,
                        startTime: new Date('2020-01-01').getTime()
                    }
                ]
            }
        ]

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
