import selector from '../../../../src/client/redux/selectors/initiatives/getInitiativeSelectOptions'

jest.mock('../../../../src/client/redux/selectors/getCurrentMonthTimeFrame', () => () => ({
    id: '1'
}))

describe('turns raw initiative data to label value for select box', () => {
    it('returns a formatted options array that are only funded if current month', () => {
        const state = {
            timeFrame: {
                timeFrames: [
                    {id: '1', name: 'June 2015', startDate: 1, lockdown: false},
                    {id: '2', name: 'June 2016', startDate: 2, lockdown: false},
                    {id: '3', name: 'May 2015', startDate: 0, lockdown: true}
                ],
                selectedTimeFrameId: '1'
            },
            initiative: {
                allInitiatives: [
                    {
                        businessUnit: null,
                        financeCodeType: null,
                        financeCodeValue: null,
                        id: '7777777-dsfgasfas-sdfasfa8898',
                        initiativeName: 'An initiative name',
                        isAllocable: true,
                        isInheritable: true,
                        parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                        parentName: 'BIO',
                        parent_status: null,
                        portfolioCode: null,
                        status: 'Funded',
                        typeId: 'CAP-INIT',
                        region: null
                    },
                    {
                        businessUnit: null,
                        financeCodeType: null,
                        financeCodeValue: null,
                        id: '1111111-34334-545sf-543fwsffserer',
                        initiativeName: 'Test Initiative',
                        isAllocable: true,
                        isInheritable: true,
                        parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                        parentName: 'BIO',
                        parent_status: null,
                        portfolioCode: null,
                        status: 'Planning',
                        typeId: 'CAP-INIT',
                        region: null
                    }
                ],
                newInitiativeData: {
                    value: {
                        teamCostPct: 0
                    }
                }
            }
        }

        const expected = [
            {
                label: 'Portfolio Code: N/A\nAn initiative name [BIO]',
                value: {
                    businessUnit: null,
                    financeCodeType: null,
                    financeCodeValue: null,
                    id: '7777777-dsfgasfas-sdfasfa8898',
                    initiativeCost: 0,
                    initiativeName: 'An initiative name',
                    isAllocable: true,
                    isInheritable: true,
                    parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                    parentName: 'BIO',
                    parent_status: null,
                    portfolioCode: null,
                    teamCostPct: 0,
                    status: 'Funded',
                    typeId: 'CAP-INIT',
                    region: null
                }
            }
        ]

        const actual = selector(state)
        expect(actual).toEqual(expected)
    })
    it('returns a formatted options array where portfolioCode is set', () => {
        const state = {
            timeFrame: {
                timeFrames: [
                    {id: '1', name: 'June 2015', startDate: 1, lockdown: false},
                    {id: '2', name: 'June 2016', startDate: 2, lockdown: false},
                    {id: '3', name: 'May 2015', startDate: 0, lockdown: true}
                ],
                selectedTimeFrameId: '1'
            },
            initiative: {
                allInitiatives: [
                    {
                        businessUnit: null,
                        financeCodeType: 'Cost Center',
                        financeCodeValue: 'ABC',
                        id: '7777777-dsfgasfas-sdfasfa8898',
                        initiativeName: 'An initiative name',
                        isAllocable: true,
                        isInheritable: true,
                        parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                        parentName: 'BIO',
                        parent_status: null,
                        portfolioCode: 'ABC-123',
                        status: 'Funded',
                        typeId: 'CAP-INIT',
                        region: null
                    }
                ],
                newInitiativeData: {
                    value: {
                        teamCostPct: 0
                    }
                }
            }
        }

        const expected = [
            {
                label: 'Portfolio Code: ABC-123\nAn initiative name [BIO]',
                value: {
                    businessUnit: null,
                    financeCodeType: 'Cost Center',
                    financeCodeValue: 'ABC',
                    id: '7777777-dsfgasfas-sdfasfa8898',
                    initiativeCost: 0,
                    initiativeName: 'An initiative name',
                    isAllocable: true,
                    isInheritable: true,
                    parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                    parentName: 'BIO',
                    parent_status: null,
                    portfolioCode: 'ABC-123',
                    teamCostPct: 0,
                    status: 'Funded',
                    typeId: 'CAP-INIT',
                    region: null
                }
            }
        ]

        const actual = selector(state)
        expect(actual).toEqual(expected)
    })
    it('returns a formatted options array that are funded or planning if not current month', () => {
        const state = {
            timeFrame: {
                timeFrames: [
                    {id: '1', name: 'June 2015', startDate: 1, lockdown: false},
                    {id: '2', name: 'June 2016', startDate: 2, lockdown: false},
                    {id: '3', name: 'May 2015', startDate: 0, lockdown: true}
                ],
                selectedTimeFrameId: '2'
            },
            initiative: {
                allInitiatives: [
                    {
                        businessUnit: null,
                        financeCodeType: null,
                        financeCodeValue: null,
                        id: '7777777-dsfgasfas-sdfasfa8898',
                        initiativeName: 'An initiative name',
                        isAllocable: true,
                        isInheritable: true,
                        parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                        parentName: 'BIO',
                        parent_status: null,
                        portfolioCode: null,
                        status: 'Funded',
                        typeId: 'CAP-INIT',
                        region: null
                    },
                    {
                        businessUnit: null,
                        financeCodeType: null,
                        financeCodeValue: null,
                        id: '1111111-34334-545sf-543fwsffserer',
                        initiativeName: 'Test Initiative',
                        isAllocable: true,
                        isInheritable: true,
                        parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                        parentName: 'BIO',
                        parent_status: null,
                        portfolioCode: null,
                        status: 'Planning',
                        typeId: 'CAP-INIT',
                        region: null
                    }
                ],
                newInitiativeData: {
                    value: {
                        teamCostPct: 0
                    }
                }
            }
        }

        const expected = [
            {
                label: 'Portfolio Code: N/A\nAn initiative name [BIO]',
                value: {
                    businessUnit: null,
                    financeCodeType: null,
                    financeCodeValue: null,
                    id: '7777777-dsfgasfas-sdfasfa8898',
                    initiativeCost: 0,
                    initiativeName: 'An initiative name',
                    isAllocable: true,
                    isInheritable: true,
                    parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                    parentName: 'BIO',
                    parent_status: null,
                    portfolioCode: null,
                    teamCostPct: 0,
                    status: 'Funded',
                    typeId: 'CAP-INIT',
                    region: null
                }
            },
            {
                label: 'Portfolio Code: N/A\nTest Initiative [BIO]',
                value: {
                    businessUnit: null,
                    financeCodeType: null,
                    financeCodeValue: null,
                    id: '1111111-34334-545sf-543fwsffserer',
                    initiativeCost: 0,
                    initiativeName: 'Test Initiative',
                    isAllocable: true,
                    isInheritable: true,
                    parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                    parentName: 'BIO',
                    parent_status: null,
                    portfolioCode: null,
                    teamCostPct: 0,
                    status: 'Planning',
                    typeId: 'CAP-INIT',
                    region: null
                }
            }
        ]

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
