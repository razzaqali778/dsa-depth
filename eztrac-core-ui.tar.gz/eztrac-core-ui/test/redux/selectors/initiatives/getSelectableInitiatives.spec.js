import selector from '../../../../src/client/redux/selectors/initiatives/getSelectableInitiatives'

jest.mock('../../../../src/client/redux/selectors/getCurrentMonthTimeFrame', () => () => ({
    id: '1'
}))

describe('filters raw initiative data to a format we can use', () => {
    it('returns an array of initiatives with tags and business unit ', () => {
        const state = {
            timeFrame: {
                timeFrames: [
                    {id: '1', name: 'June 2015', startDate: 1, lockdown: false},
                    {id: '2', name: 'June 2016', startDate: 2, lockdown: false},
                    {id: '3', name: 'May 2015', startDate: 0, lockdown: true}
                ],
                selectedTimeFrameId: '1'
            },
            initiative: {
                allInitiatives: [
                    {
                        businessUnit: 'Commercial',
                        financeCodeType: null,
                        financeCodeValue: null,
                        id: '7777777-dsfgasfas-sdfasfa8898',
                        initiativeName: 'An initiative name',
                        isAllocable: true,
                        isInheritable: true,
                        parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                        parentName: 'BIO',
                        parent_status: null,
                        portfolioCode: null,
                        status: 'Funded',
                        typeId: 'CAP-INIT',
                        region: 'North America'
                    },
                    {
                        businessUnit: null,
                        financeCodeType: null,
                        financeCodeValue: null,
                        id: '1111111-34334-545sf-543fwsffserer',
                        initiativeName: 'Test Initiative',
                        isAllocable: true,
                        isInheritable: true,
                        parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                        parentName: 'BIO',
                        parent_status: null,
                        portfolioCode: null,
                        status: 'Funded',
                        typeId: 'CAP-INIT',
                        region: 'North America'
                    }
                ]
            }
        }

        const expected = [
            {
                financeCodeType: null,
                financeCodeValue: null,
                id: '7777777-dsfgasfas-sdfasfa8898',
                initiativeName: 'An initiative name',
                isAllocable: true,
                isInheritable: true,
                parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                parentName: 'BIO',
                parent_status: null,
                portfolioCode: null,
                status: 'Funded',
                typeId: 'CAP-INIT',
                region: 'North America',
                businessUnit: 'Commercial'
            },
            {
                financeCodeType: null,
                financeCodeValue: null,
                id: '1111111-34334-545sf-543fwsffserer',
                initiativeName: 'Test Initiative',
                isAllocable: true,
                isInheritable: true,
                parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                parentName: 'BIO',
                parent_status: null,
                portfolioCode: null,
                status: 'Funded',
                typeId: 'CAP-INIT',
                region: 'North America',
                businessUnit: null
            }
        ]

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
