import selector from '../../../src/client/redux/selectors/getHasManageTeams'

describe('getHasManageTeams', () => {
    it('returns true if the user has the manage teams entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: 'eztrac-manage-teams'
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })
    it('returns false if the user does not have the manage teams entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: 'eztrac-read-user'
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(false)
    })
})
