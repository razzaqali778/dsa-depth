import selector from '../../../src/client/redux/selectors/preferences/getFavoriteTeamSelectOptions'

describe('get favorite team options', () => {
    it('returns an array with a favorite object and non favorite object', () => {
        const state = {
            team: {
                platforms: [{id: 'PLATFORM-1', name: 'Platform 1', isActive: true}],
                communities: [
                    {
                        id: 'COMMUNITY-1',
                        name: 'Community 1',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    }
                ],
                teams: [
                    {id: 'TEAM-1', name: 'Team 1', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-2', name: 'Team 2', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-3', name: 'Team 3', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-4', name: 'Team 4', communityId: 'COMMUNITY-1', isActive: true}
                ]
            },
            preference: {
                preferences: {
                    'TEAM-1': 'TEAM-1',
                    'TEAM-3': 'TEAM-3'
                }
            }
        }

        const expected = [
            {
                label: 'Favorites',
                options: [
                    {value: 'TEAM-1', label: 'Team 1', communityId: 'COMMUNITY-1', active: true},
                    {value: 'TEAM-3', label: 'Team 3', communityId: 'COMMUNITY-1', active: true}
                ]
            },
            {
                label: 'Teams',
                options: [
                    {value: 'TEAM-2', label: 'Team 2', communityId: 'COMMUNITY-1', active: true},
                    {value: 'TEAM-4', label: 'Team 4', communityId: 'COMMUNITY-1', active: true}
                ]
            }
        ]

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
    it('returns only active teams', () => {
        const state = {
            team: {
                platforms: [{id: 'PLATFORM-1', name: 'Platform 1', isActive: true}],
                communities: [
                    {
                        id: 'COMMUNITY-1',
                        name: 'Community 1',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    }
                ],
                teams: [
                    {id: 'TEAM-1', name: 'Team 1', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-2', name: 'Team 2', communityId: 'COMMUNITY-1', isActive: false},
                    {id: 'TEAM-3', name: 'Team 3', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-4', name: 'Team 4', communityId: 'COMMUNITY-1', isActive: true}
                ]
            },
            preference: {
                preferences: {}
            }
        }

        const expected = [
            {
                label: 'Favorites',
                options: []
            },
            {
                label: 'Teams',
                options: [
                    {value: 'TEAM-1', label: 'Team 1', communityId: 'COMMUNITY-1', active: true},
                    {value: 'TEAM-3', label: 'Team 3', communityId: 'COMMUNITY-1', active: true},
                    {value: 'TEAM-4', label: 'Team 4', communityId: 'COMMUNITY-1', active: true}
                ]
            }
        ]

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns only favorite teams that are in the team arrays', () => {
        const state = {
            team: {
                platforms: [{id: 'PLATFORM-1', name: 'Platform 1', isActive: true}],
                communities: [
                    {
                        id: 'COMMUNITY-1',
                        name: 'Community 1',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    }
                ],
                teams: [
                    {id: 'TEAM-1', name: 'Team 1', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-2', name: 'Team 2', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-3', name: 'Team 3', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-4', name: 'Team 4', communityId: 'COMMUNITY-1', isActive: true}
                ]
            },
            preference: {
                preferences: {
                    'TEAM-1': 'TEAM-1',
                    'TEAM-3': 'TEAM-3',
                    'TEAM-5': 'TEAM-5'
                }
            }
        }

        const expected = [
            {
                label: 'Favorites',
                options: [
                    {value: 'TEAM-1', label: 'Team 1', communityId: 'COMMUNITY-1', active: true},
                    {value: 'TEAM-3', label: 'Team 3', communityId: 'COMMUNITY-1', active: true}
                ]
            },
            {
                label: 'Teams',
                options: [
                    {value: 'TEAM-2', label: 'Team 2', communityId: 'COMMUNITY-1', active: true},
                    {value: 'TEAM-4', label: 'Team 4', communityId: 'COMMUNITY-1', active: true}
                ]
            }
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
