import selector from '../../../../src/client/redux/selectors/teams/getSelectedTeamInfo'

describe('get selected team info', () => {
    it('returns info for a selected team', () => {
        const state = {
            team: {
                selectedTeam: {
                    id: 'TEAM-1',
                    name: 'Team 1'
                },
                teams: [
                    {id: 'TEAM-1', name: 'Team 1', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-2', name: 'Team 2', communityId: 'COMMUNITY-2', isActive: true}
                ],
                communities: [
                    {id: 'COMMUNITY-1', name: 'Community 1', platformId: 'PLATFORM-1'},
                    {id: 'COMMUNITY-2', name: 'Community 2', platformId: 'PLATFORM-1'}
                ],
                platforms: [{id: 'PLATFORM-1', name: 'Platform 1', orgId: 'ORG-1'}],
                orgs: [{id: 'ORG-1', name: 'Org 1'}]
            }
        }

        const expected = {
            id: 'TEAM-1',
            name: 'Team 1',
            isActive: true,
            communityId: 'COMMUNITY-1',
            communityName: 'Community 1',
            platformId: 'PLATFORM-1',
            platformName: 'Platform 1',
            orgId: 'ORG-1',
            orgName: 'Org 1'
        }

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
    it('returns info for a selected team when team, community, and platform are empty', () => {
        const state = {
            team: {
                selectedTeam: {
                    id: 'TEAM-1',
                    name: 'Team 1'
                },
                teams: [],
                communities: [],
                platforms: [],
                orgs: [],
                isCreatingTeam: false
            }
        }

        const expected = {
            id: undefined,
            name: undefined,
            isActive: undefined,
            communityId: undefined,
            communityName: undefined,
            platformId: undefined,
            platformName: undefined,
            orgId: undefined,
            orgName: undefined
        }

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
    it('returns info for a team being created', () => {
        const state = {
            team: {
                selectedTeam: {
                    id: null,
                    name: 'Team 1'
                },
                teams: [],
                communities: [],
                platforms: [],
                isCreatingTeam: true
            }
        }

        const expected = {
            id: '',
            name: 'Team 1'
        }

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
