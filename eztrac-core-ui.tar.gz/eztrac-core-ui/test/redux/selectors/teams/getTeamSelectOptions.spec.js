import selector from '../../../../src/client/redux/selectors/teams/getTeamSelectOptions'

describe('get team select options', () => {
    it('returns empty array when teams are empty', () => {
        const state = {
            team: {
                teams: []
            }
        }

        const expected = []
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns an array of value: label ', () => {
        const state = {
            team: {
                teams: [
                    {id: '1', name: 'Team 1', some: 'stuff'},
                    {id: '2', name: 'Team 2', other: 'things'}
                ]
            }
        }

        const expected = [
            {value: '1', label: 'Team 1'},
            {value: '2', label: 'Team 2'}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
