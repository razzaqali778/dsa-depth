import selector from '../../../../src/client/redux/selectors/teams/getActiveTeamSelectOptions'

describe('get active team options', () => {
    it('returns an array with an active object and inactive object', () => {
        const state = {
            team: {
                teams: [
                    {id: 'TEAM-1', name: 'Team 1', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-2', name: 'Team 2', communityId: 'COMMUNITY-1', isActive: false},
                    {id: 'TEAM-3', name: 'Team 3', communityId: 'COMMUNITY-1', isActive: true},
                    {id: 'TEAM-4', name: 'Team 4', communityId: 'COMMUNITY-1', isActive: false}
                ]
            },
            preference: {
                preferences: {}
            }
        }

        const expected = [
            {
                label: 'Favorites',
                options: []
            },
            {
                label: 'Active',
                options: [
                    {value: 'TEAM-1', label: 'Team 1', communityId: 'COMMUNITY-1', active: true},
                    {value: 'TEAM-3', label: 'Team 3', communityId: 'COMMUNITY-1', active: true}
                ]
            },
            {
                label: 'Inactive',
                options: [
                    {value: 'TEAM-2', label: 'Team 2', communityId: 'COMMUNITY-1', active: false},
                    {value: 'TEAM-4', label: 'Team 4', communityId: 'COMMUNITY-1', active: false}
                ]
            }
        ]

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
