import selector from '../../../../src/client/redux/selectors/teams/getTeamFiltersOptions'

describe('get team filters options', () => {
    it('returns empty array when orgs, communities and platforms are empty', () => {
        const state = {
            team: {
                communities: [],
                platforms: [],
                orgs: []
            }
        }

        const expected = {orgs: [], communities: [], platforms: []}
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns an object with filters options including all active orgs, platforms and communities when no org or platform selected', () => {
        const state = {
            team: {
                orgs: [
                    {id: 'ORG-1', name: 'Org 1', isActive: true},
                    {id: 'ORG-2', name: 'Org 2', isActive: true}
                ],
                platforms: [
                    {id: 'PLATFORM-1', name: 'Platform 1', orgId: 'ORG-1', isActive: true},
                    {id: 'PLATFORM-2', name: 'Platform 2', orgId: 'ORG-2', isActive: true}
                ],
                communities: [
                    {
                        id: 'COMMUNITY-1',
                        name: 'Community 1',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    },
                    {
                        id: 'COMMUNITY-2',
                        name: 'Community 2',
                        platformId: 'PLATFORM-2',
                        isActive: true
                    },
                    {
                        id: 'COMMUNITY-3',
                        name: 'Community 3',
                        platformId: 'PLATFORM-1',
                        isActive: false
                    }
                ]
            }
        }

        const expected = {
            communities: [
                {label: 'Community 1', value: 'COMMUNITY-1'},
                {label: 'Community 2', value: 'COMMUNITY-2'}
            ],
            platforms: [
                {label: 'Platform 1', value: 'PLATFORM-1'},
                {label: 'Platform 2', value: 'PLATFORM-2'}
            ],
            orgs: [
                {label: 'Org 1', value: 'ORG-1'},
                {label: 'Org 2', value: 'ORG-2'}
            ]
        }

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns an object with filters options, platforms and communities filtered by selected org', () => {
        const state = {
            team: {
                selectedOrgId: 'ORG-1',
                orgs: [
                    {id: 'ORG-1', name: 'Org 1', isActive: true},
                    {id: 'ORG-2', name: 'Org 2', isActive: true}
                ],
                platforms: [
                    {id: 'PLATFORM-1', name: 'Platform 1', orgId: 'ORG-1', isActive: true},
                    {id: 'PLATFORM-2', name: 'Platform 2', orgId: 'ORG-2', isActive: true}
                ],
                communities: [
                    {
                        id: 'COMMUNITY-1',
                        name: 'Community 1',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    },
                    {
                        id: 'COMMUNITY-2',
                        name: 'Community 2',
                        platformId: 'PLATFORM-2',
                        isActive: true
                    },
                    {
                        id: 'COMMUNITY-3',
                        name: 'Community 3',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    }
                ]
            }
        }

        const expected = {
            communities: [
                {label: 'Community 1', value: 'COMMUNITY-1'},
                {label: 'Community 3', value: 'COMMUNITY-3'}
            ],
            platforms: [{label: 'Platform 1', value: 'PLATFORM-1'}],
            orgs: [
                {label: 'Org 1', value: 'ORG-1'},
                {label: 'Org 2', value: 'ORG-2'}
            ]
        }

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns an object with filters options, platforms and communities filtered by selected platform', () => {
        const state = {
            team: {
                selectedPlatformId: 'PLATFORM-1',
                orgs: [
                    {id: 'ORG-1', name: 'Org 1', isActive: true},
                    {id: 'ORG-2', name: 'Org 2', isActive: true}
                ],
                platforms: [
                    {id: 'PLATFORM-1', name: 'Platform 1', orgId: 'ORG-1', isActive: true},
                    {id: 'PLATFORM-2', name: 'Platform 2', orgId: 'ORG-2', isActive: true}
                ],
                communities: [
                    {
                        id: 'COMMUNITY-1',
                        name: 'Community 1',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    },
                    {
                        id: 'COMMUNITY-2',
                        name: 'Community 2',
                        platformId: 'PLATFORM-2',
                        isActive: true
                    },
                    {
                        id: 'COMMUNITY-3',
                        name: 'Community 3',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    }
                ]
            }
        }

        const expected = {
            communities: [
                {label: 'Community 1', value: 'COMMUNITY-1'},
                {label: 'Community 3', value: 'COMMUNITY-3'}
            ],
            platforms: [
                {label: 'Platform 1', value: 'PLATFORM-1'},
                {label: 'Platform 2', value: 'PLATFORM-2'}
            ],
            orgs: [
                {label: 'Org 1', value: 'ORG-1'},
                {label: 'Org 2', value: 'ORG-2'}
            ]
        }

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns an object with filters options, platforms and communities filtered by selected org and platform', () => {
        const state = {
            team: {
                selectedOrgId: 'ORG-2',
                selectedPlatformId: 'PLATFORM-2',
                orgs: [
                    {id: 'ORG-1', name: 'Org 1', isActive: true},
                    {id: 'ORG-2', name: 'Org 2', isActive: true}
                ],
                platforms: [
                    {id: 'PLATFORM-1', name: 'Platform 1', orgId: 'ORG-1', isActive: true},
                    {id: 'PLATFORM-2', name: 'Platform 2', orgId: 'ORG-2', isActive: true}
                ],
                communities: [
                    {
                        id: 'COMMUNITY-1',
                        name: 'Community 1',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    },
                    {
                        id: 'COMMUNITY-2',
                        name: 'Community 2',
                        platformId: 'PLATFORM-2',
                        isActive: true
                    },
                    {
                        id: 'COMMUNITY-3',
                        name: 'Community 3',
                        platformId: 'PLATFORM-1',
                        isActive: true
                    }
                ]
            }
        }

        const expected = {
            communities: [{label: 'Community 2', value: 'COMMUNITY-2'}],
            platforms: [{label: 'Platform 2', value: 'PLATFORM-2'}],
            orgs: [
                {label: 'Org 1', value: 'ORG-1'},
                {label: 'Org 2', value: 'ORG-2'}
            ]
        }

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
