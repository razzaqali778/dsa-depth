import selector from '../../../src/client/redux/selectors/getIsAdmin'

describe('getIsAdmin', () => {
    it('returns true if the user has the admin entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: 'eztrac-admin-user'
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })
    it('returns false if the user does not have the admin entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: 'eztrac-read-user'
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(false)
    })
})
