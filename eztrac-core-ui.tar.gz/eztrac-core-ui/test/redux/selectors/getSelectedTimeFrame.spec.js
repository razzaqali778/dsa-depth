import selector from '../../../src/client/redux/selectors/getSelectedTimeFrame'

describe('get time frame for the selected id', () => {
    it('returns a time frame for the given id', () => {
        const state = {
            timeFrame: {
                timeFrames: [
                    {id: '1', name: 'June 2015', startDate: 1, lockdown: false},
                    {id: '2', name: 'June 2016', startDate: 2, lockdown: false},
                    {id: '3', name: 'May 2015', startDate: 0, lockdown: true}
                ],
                selectedTimeFrameId: '2'
            }
        }

        const expected = {id: '2', name: 'June 2016', startDate: 2, lockdown: false}
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
