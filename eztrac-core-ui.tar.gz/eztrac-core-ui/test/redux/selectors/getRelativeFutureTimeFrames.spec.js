import selector from '../../../src/client/redux/selectors/getRelativeFutureTimeFrames'

describe('get relative future time frames', () => {
    it('return empty array if there are no time frames', () => {
        const state = {
            timeFrame: {timeFrames: []}
        }

        const expected = []

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('return empty array if all the time frames are in the past relative to the selected time frame ', () => {
        const state = {
            timeFrame: {
                selectedTimeFrameId: 11639,
                timeFrames: [
                    {
                        endDate: new Date('2014-10-31T23:59:59Z').getTime(),
                        id: 11637,
                        isActive: true,
                        lockdown: true,
                        name: 'Oct 2014',
                        startDate: new Date('2014-10-01T00:00:00Z').getTime()
                    },
                    {
                        endDate: new Date('2014-11-30T23:59:59Z').getTime(),
                        id: 11638,
                        isActive: true,
                        lockdown: true,
                        name: 'Nov 2014',
                        startDate: new Date('2014-11-01T00:00:00Z').getTime()
                    },
                    {
                        endDate: new Date('2014-12-31T23:59:59Z').getTime(),
                        id: 11639,
                        isActive: true,
                        lockdown: true,
                        name: 'Dec 2014',
                        startDate: new Date('2014-12-01T00:00:00Z').getTime()
                    }
                ]
            }
        }

        const expected = []

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns array of future time frames, relative to selected time frame', () => {
        const state = {
            timeFrame: {
                selectedTimeFrameId: 11637,
                timeFrames: [
                    {
                        endDate: new Date('2014-10-31T23:59:59Z').getTime(),
                        id: 11637,
                        isActive: true,
                        lockdown: true,
                        name: 'Oct 2014',
                        startDate: new Date('2014-10-01T00:00:00Z').getTime()
                    },
                    {
                        endDate: new Date('2014-11-30T23:59:59Z').getTime(),
                        id: 11638,
                        isActive: true,
                        lockdown: true,
                        name: 'Nov 2014',
                        startDate: new Date('2014-11-01T00:00:00Z').getTime()
                    },
                    {
                        endDate: new Date('2014-12-31T23:59:59Z').getTime(),
                        id: 11639,
                        isActive: true,
                        lockdown: true,
                        name: 'Dec 2014',
                        startDate: new Date('2014-12-01T00:00:00Z').getTime()
                    }
                ]
            }
        }

        const expected = [
            {
                endDate: new Date('2014-11-30T23:59:59Z').getTime(),
                id: 11638,
                isActive: true,
                lockdown: true,
                name: 'Nov 2014',
                startDate: new Date('2014-11-01T00:00:00Z').getTime()
            },
            {
                endDate: new Date('2014-12-31T23:59:59Z').getTime(),
                id: 11639,
                isActive: true,
                lockdown: true,
                name: 'Dec 2014',
                startDate: new Date('2014-12-01T00:00:00Z').getTime()
            }
        ]

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
