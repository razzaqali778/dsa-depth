import selector from '../../../src/client/redux/selectors/getIsTeamMaintenanceSaveDisabled'

describe('getIsSaveDisabled', () => {
    it('returns true if the save is disabled due to empty communityId', () => {
        const state = {
            team: {
                formValues: {
                    teamName: 'Team 1',
                    communityId: null,
                    isActive: true
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })

    it('returns true if the save is disabled due to empty team name', () => {
        const state = {
            team: {
                formValues: {
                    teamName: '',
                    communityId: 'Community 1',
                    isActive: true
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })

    it('returns false if the save is enabled', () => {
        const state = {
            team: {
                formValues: {
                    teamName: 'Team 1',
                    communityId: 'Community 1',
                    isActive: true
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(false)
    })
})
