import selector from '../../../src/client/redux/selectors/getHasManageEfforts'

describe('getHasManageEfforts', () => {
    it('returns true if the user has the manage efforts entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: 'eztrac-manage-efforts'
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })
    it('returns false if the user does not have the manage efforts entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: 'eztrac-read-user'
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(false)
    })
})
