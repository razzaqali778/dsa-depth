import selector from '../../../src/client/redux/selectors/getOverwrittenMonths'

describe('get overwritten months', () => {
    it('return an empty array if there are no team initiatives', () => {
        const state = {
            initiative: {
                teamInitiatives: [],
                copyForwardTimeFrame: []
            }
        }
        const expected = []

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
    it('returns an array of months if months in the team initiatives overlap with copy forward time frames', () => {
        const state = {
            initiative: {
                teamInitiatives: [{timeFrameId: 123}, {timeFrameId: 654}, {timeFrameId: 111}],
                copyForwardTimeFrame: [
                    {id: 123, name: 'Sept 2019'},
                    {id: 111, name: 'Oct 2019'},
                    {id: 115, name: 'Nov 2019'}
                ]
            }
        }
        const expected = ['Sept 2019', 'Oct 2019']

        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
