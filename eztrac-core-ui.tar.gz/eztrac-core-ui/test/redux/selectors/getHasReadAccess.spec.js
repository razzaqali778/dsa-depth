import selector from '../../../src/client/redux/selectors/getHasReadAccess'

describe('getHasReadAccess', () => {
    it('returns true if the user has the eztrac-read-user entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: 'eztrac-read-user'
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })
    it('returns true if the user has the eztrac-write-user entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: 'eztrac-write-user'
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })
    it('returns true if the user has the ez-trac-admin entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: 'ez-trac-admin'
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })
    it('returns false if the user does not have the read, write, or admin entitlement', () => {
        const state = {
            users: {
                currentUser: {
                    entitlements: [
                        {
                            code: ''
                        }
                    ]
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(false)
    })
})
