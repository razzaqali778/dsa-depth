import selector from '../../../../src/client/redux/selectors/engagements/getGroupedAndSortedEngagements'

describe('get grouped and sorted engagements', () => {
    it('returns empty if there are no engagements', () => {
        const state = {
            engagement: {},
            timeFrame: {},
            engagementOptions: {}
        }
        const expected = {}
        expect(selector(state)).toEqual(expected)
    })

    it('returns empty if there are no engagements options', () => {
        const state = {
            engagement: {
                allTeamEngagements: [{engagementId: 'b', timeFrameId: 2}],
                engagementOptions: []
            },
            timeFrame: {
                timeFrames: [
                    {
                        name: 'Nov 2018',
                        endDate: 1543622399000,
                        id: 1,
                        isActive: true,
                        startDate: 1541030400000
                    },
                    {
                        name: 'Dec 2018',
                        endDate: 1546300799000,
                        id: 2,
                        isActive: true,
                        startDate: 1543622400000
                    }
                ]
            }
        }
        const expected = {}
        expect(selector(state)).toEqual(expected)
    })

    it('returns empty if there are no timeframes', () => {
        const state = {
            engagement: {
                allTeamEngagements: [{engagementId: 'b', timeFrameId: 2}],
                engagementOptions: [
                    {name: 'engagement1', isActive: true, id: 'a'},
                    {name: 'Monsanto', isActive: true, id: 'b'}
                ]
            },
            timeFrame: {timeFrames: []}
        }
        const expected = {}
        expect(selector(state)).toEqual(expected)
    })

    it('return grouped and sorted engagements', () => {
        const state = {
            engagement: {
                allTeamEngagements: [
                    {engagementId: 'b', timeFrameId: 2},
                    {engagementId: 'a', timeFrameId: 2},
                    {engagementId: 'b', timeFrameId: 1},
                    {engagementId: 'a', timeFrameId: 1}
                ],
                engagementOptions: [
                    {name: 'engagement1', isActive: true, id: 'a'},
                    {name: 'Monsanto', isActive: true, id: 'b'}
                ]
            },

            timeFrame: {
                timeFrames: [
                    {
                        name: 'Nov 2018',
                        endDate: 1543622399000,
                        id: 1,
                        isActive: true,
                        startDate: 1541030400000
                    },
                    {
                        name: 'Dec 2018',
                        endDate: 1546300799000,
                        id: 2,
                        isActive: true,
                        startDate: 1543622400000
                    }
                ]
            }
        }
        const expected = {
            a: [
                {
                    engagementId: 'a',
                    timeFrameId: 1,
                    timeFrameName: 'Nov 2018',
                    endDate: 1543622399000,
                    isTimeFrameActive: true,
                    startDate: 1541030400000,
                    timeFrameLockdown: undefined,
                    engagementName: 'engagement1',
                    isEngagementActive: true
                },
                {
                    engagementId: 'a',
                    timeFrameId: 2,
                    timeFrameName: 'Dec 2018',
                    endDate: 1546300799000,
                    isTimeFrameActive: true,
                    startDate: 1543622400000,
                    timeFrameLockdown: undefined,
                    engagementName: 'engagement1',
                    isEngagementActive: true
                }
            ],
            b: [
                {
                    engagementId: 'b',
                    timeFrameId: 1,
                    timeFrameName: 'Nov 2018',
                    endDate: 1543622399000,
                    isTimeFrameActive: true,
                    startDate: 1541030400000,
                    timeFrameLockdown: undefined,
                    engagementName: 'Monsanto',
                    isEngagementActive: true
                },
                {
                    engagementId: 'b',
                    timeFrameId: 2,
                    timeFrameName: 'Dec 2018',
                    endDate: 1546300799000,
                    isTimeFrameActive: true,
                    startDate: 1543622400000,
                    timeFrameLockdown: undefined,
                    engagementName: 'Monsanto',
                    isEngagementActive: true
                }
            ]
        }
        expect(selector(state)).toEqual(expected)
    })
})
