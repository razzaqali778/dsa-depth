import selector from '../../../../src/client/redux/selectors/engagements/getIsEngagementSaveDisabled'

describe('getIsEngagementSaveDisabled', () => {
    it('returns true if the save is disabled due to empty amount', () => {
        const state = {
            engagement: {
                formValues: {
                    amount: null,
                    selectedEngagement: {
                        label: 'some',
                        value: 'stuff'
                    },
                    timeFrameId: 11636
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })

    it('returns true if the save is disabled due to empty selectedEngagement', () => {
        const state = {
            engagement: {
                formValues: {
                    amount: 6789,
                    selectedEngagement: [],
                    timeFrameId: 11636
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })

    it('returns true if the save is disabled due to empty timeFrame', () => {
        const state = {
            engagement: {
                formValues: {
                    amount: 6789,
                    selectedEngagement: {
                        label: 'some',
                        value: 'stuff'
                    },
                    timeFrameId: ''
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(true)
    })

    it('returns false if the save is enabled', () => {
        const state = {
            engagement: {
                formValues: {
                    amount: 6789,
                    selectedEngagement: {
                        label: 'some',
                        value: 'stuff'
                    },
                    timeFrameId: 11636
                }
            }
        }

        const actual = selector(state)
        expect(actual).toEqual(false)
    })
})
