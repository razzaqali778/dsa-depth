import selector from '../../../../src/client/redux/selectors/engagements/getFilteredEngagements'

describe('get filtered engagements', () => {
    it('returns empty if there are no engagements options', () => {
        const state = {
            engagement: {
                allTeamEngagements: [{engagementId: 'b', timeFrameId: 2}],
                engagementOptions: [],
                engagementFilterPhrase: 'eng'
            },
            timeFrame: {
                timeFrames: [
                    {
                        name: 'Nov 2018',
                        endDate: 1543622399000,
                        id: 1,
                        isActive: true,
                        startDate: 1541030400000
                    },
                    {
                        name: 'Dec 2018',
                        endDate: 1546300799000,
                        id: 2,
                        isActive: true,
                        startDate: 1543622400000
                    }
                ]
            }
        }
        const expected = {}
        expect(selector(state)).toEqual(expected)
    })

    it('return filtered engagements - filter phrase matching engagement name', () => {
        const state = {
            engagement: {
                allTeamEngagements: [
                    {engagementId: 'b', timeFrameId: 2},
                    {engagementId: 'a', timeFrameId: 2},
                    {engagementId: 'b', timeFrameId: 1},
                    {engagementId: 'a', timeFrameId: 1}
                ],
                engagementOptions: [
                    {name: 'engagement1', isActive: true, id: 'a'},
                    {name: 'Monsanto', isActive: true, id: 'b'}
                ],
                engagementFilterPhrase: 'eng'
            },

            timeFrame: {
                timeFrames: [
                    {
                        name: 'Nov 2018',
                        endDate: 1543622399000,
                        id: 1,
                        isActive: true,
                        startDate: 1541030400000
                    },
                    {
                        name: 'Dec 2018',
                        endDate: 1546300799000,
                        id: 2,
                        isActive: true,
                        startDate: 1543622400000
                    }
                ]
            }
        }
        const expected = {
            a: [
                {
                    engagementId: 'a',
                    timeFrameId: 1,
                    timeFrameName: 'Nov 2018',
                    endDate: 1543622399000,
                    isTimeFrameActive: true,
                    startDate: 1541030400000,
                    timeFrameLockdown: undefined,
                    engagementName: 'engagement1',
                    isEngagementActive: true
                },
                {
                    engagementId: 'a',
                    timeFrameId: 2,
                    timeFrameName: 'Dec 2018',
                    endDate: 1546300799000,
                    isTimeFrameActive: true,
                    startDate: 1543622400000,
                    timeFrameLockdown: undefined,
                    engagementName: 'engagement1',
                    isEngagementActive: true
                }
            ]
        }
        expect(selector(state)).toEqual(expected)
    })

    it('return filtered engagements - filter phrase matching purchase order', () => {
        const state = {
            engagement: {
                allTeamEngagements: [
                    {engagementId: 'b', timeFrameId: 2},
                    {engagementId: 'a', timeFrameId: 2},
                    {engagementId: 'b', timeFrameId: 1},
                    {engagementId: 'a', timeFrameId: 1}
                ],
                engagementOptions: [
                    {name: 'engagement1', isActive: true, id: 'a', purchaseOrder: '12345'},
                    {name: 'Monsanto', isActive: true, id: 'b', purchaseOrder: '6789'}
                ],
                engagementFilterPhrase: '89'
            },

            timeFrame: {
                timeFrames: [
                    {
                        name: 'Nov 2018',
                        endDate: 1543622399000,
                        id: 1,
                        isActive: true,
                        startDate: 1541030400000
                    },
                    {
                        name: 'Dec 2018',
                        endDate: 1546300799000,
                        id: 2,
                        isActive: true,
                        startDate: 1543622400000
                    }
                ]
            }
        }
        const expected = {
            b: [
                {
                    engagementId: 'b',
                    timeFrameId: 1,
                    timeFrameName: 'Nov 2018',
                    endDate: 1543622399000,
                    isTimeFrameActive: true,
                    startDate: 1541030400000,
                    timeFrameLockdown: undefined,
                    engagementName: 'Monsanto',
                    isEngagementActive: true,
                    purchaseOrder: '6789'
                },
                {
                    engagementId: 'b',
                    timeFrameId: 2,
                    timeFrameName: 'Dec 2018',
                    endDate: 1546300799000,
                    isTimeFrameActive: true,
                    startDate: 1543622400000,
                    timeFrameLockdown: undefined,
                    engagementName: 'Monsanto',
                    isEngagementActive: true,
                    purchaseOrder: '6789'
                }
            ]
        }
        expect(selector(state)).toEqual(expected)
    })
})
