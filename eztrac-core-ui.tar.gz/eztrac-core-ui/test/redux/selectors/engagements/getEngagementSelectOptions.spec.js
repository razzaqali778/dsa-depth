import selector from '../../../../src/client/redux/selectors/engagements/getEngagementSelectOptions'

describe('get engagement options select value', () => {
    const makeLabel = (name, purchaseOrder) => `PO ${purchaseOrder}\n${name}`

    it('returns empty array when teams are empty', () => {
        const state = {
            engagement: {
                engagementOptions: []
            }
        }

        const expected = []
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns an array of value: label', () => {
        const state = {
            engagement: {
                engagementOptions: [
                    {
                        id: '1',
                        name: 'Engagement 1',
                        some: 'garbage',
                        isActive: true,
                        purchaseOrder: '11'
                    },
                    {
                        id: '2',
                        name: 'Engagement 2',
                        more: 'garbage',
                        isActive: true,
                        purchaseOrder: '22'
                    }
                ]
            }
        }

        const expected = [
            {value: '1', label: makeLabel('Engagement 1', '11')},
            {value: '2', label: makeLabel('Engagement 2', '22')}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('sorts engagementOptions alphabetically', () => {
        const state = {
            engagement: {
                engagementOptions: [
                    {id: '1', name: 'mesothelioma', isActive: true, purchaseOrder: '123'},
                    {id: '2', name: 'blah', isActive: true, purchaseOrder: '456'},
                    {id: '3', name: 'juicebox', isActive: true, purchaseOrder: '789'}
                ]
            }
        }

        const expected = [
            {value: '2', label: makeLabel('blah', '456')},
            {value: '3', label: makeLabel('juicebox', '789')},
            {value: '1', label: makeLabel('mesothelioma', '123')}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('filters out engagements that are not active', () => {
        const state = {
            engagement: {
                engagementOptions: [
                    {id: '1', name: 'mesothelioma', isActive: true, purchaseOrder: '1'},
                    {id: '2', name: 'blah', isActive: false, purchaseOrder: '2'},
                    {id: '3', name: 'juicebox', isActive: true, purchaseOrder: 'TBD'}
                ]
            }
        }

        const expected = [
            {value: '3', label: makeLabel('juicebox', 'TBD')},
            {value: '1', label: makeLabel('mesothelioma', '1')}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
