import moment from 'moment'
import selector from '../../../../src/client/redux/selectors/engagements/getStartTimeFrameSelectOptions'

beforeAll(() => {
    jest.useFakeTimers('modern')
    jest.setSystemTime(new Date(2023, 3, 1))
})

afterAll(() => {
    jest.useRealTimers()
})

describe('get start time frame select options', () => {
    const nonAdmin = {
        entitlements: [
            {
                code: 'eztrac-read-user'
            }
        ]
    }

    const admin = {
        entitlements: [
            {
                code: 'eztrac-admin-user'
            }
        ]
    }

    it('returns array of all current year time frames - locked and not locked - when user is an admin', () => {
        const previousYearTimeFrameId = 'previousYearTimeFrameId'
        const startTimeFrameId = 'startTimeFrameId'
        const nextTimeFrameId = 'nextTimeFrameId'
        const startTimeFrameName = 'start time frame'
        const nextTimeFrameName = 'next time frame'
        const state = {
            timeFrame: {
                timeFrames: [
                    {
                        id: previousYearTimeFrameId,
                        name: 'time frame from the previous year',
                        startDate: moment().subtract(1, 'year'),
                        lockdown: true
                    },
                    {
                        id: 'lockedTimeFrame',
                        name: 'some locked time frame',
                        startDate: moment().subtract(1, 'month').valueOf(),
                        lockdown: true
                    },
                    {
                        id: startTimeFrameId,
                        name: startTimeFrameName,
                        startDate: moment().add(1, 'month').valueOf(),
                        lockdown: false,
                        endDate: moment().add(2, 'months').valueOf()
                    },
                    {
                        id: nextTimeFrameId,
                        name: nextTimeFrameName,
                        startDate: moment().add(2, 'months').valueOf(),
                        lockdown: false,
                        endDate: moment().add(3, 'months').valueOf()
                    }
                ]
            },
            users: {
                currentUser: admin
            }
        }

        const expected = [
            {value: 'lockedTimeFrame', label: 'LOCKED\nsome locked time frame', isLocked: true},
            {value: startTimeFrameId, label: startTimeFrameName, isLocked: false},
            {value: nextTimeFrameId, label: nextTimeFrameName, isLocked: false}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns array of all current year time frames that are not locked - when user is not an admin', () => {
        const previousYearTimeFrameId = 'previousYearTimeFrameId'
        const startTimeFrameId = 'startTimeFrameId'
        const nextTimeFrameId = 'nextTimeFrameId'
        const startTimeFrameName = 'start time frame'
        const nextTimeFrameName = 'next time frame'
        const state = {
            timeFrame: {
                timeFrames: [
                    {
                        id: previousYearTimeFrameId,
                        name: 'time frame from the previous year',
                        startDate: moment().subtract(1, 'year'),
                        lockdown: true
                    },
                    {
                        id: 'lockedTimeFrame',
                        name: 'locked time frame',
                        startDate: moment().subtract(1, 'month').valueOf(),
                        lockdown: true
                    },
                    {
                        id: startTimeFrameId,
                        name: startTimeFrameName,
                        startDate: moment().add(1, 'month').valueOf(),
                        lockdown: false,
                        endDate: moment().add(2, 'months').valueOf()
                    },
                    {
                        id: nextTimeFrameId,
                        name: nextTimeFrameName,
                        startDate: moment().add(2, 'months').valueOf(),
                        lockdown: false,
                        endDate: moment().add(3, 'months').valueOf()
                    }
                ]
            },
            users: {
                currentUser: nonAdmin
            }
        }

        const expected = [
            {value: startTimeFrameId, label: startTimeFrameName, isLocked: false},
            {value: nextTimeFrameId, label: nextTimeFrameName, isLocked: false}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
