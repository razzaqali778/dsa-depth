import moment from 'moment'
import selector from '../../../../src/client/redux/selectors/engagements/getEndTimeFrameSelectOptions'

beforeAll(() => {
    jest.useFakeTimers('modern')
    jest.setSystemTime(new Date(2023, 3, 1))
})

afterAll(() => {
    jest.useRealTimers()
})

describe('get end time frame select options', () => {
    const nonAdmin = {
        entitlements: [
            {
                code: 'eztrac-read-user'
            }
        ]
    }

    const admin = {
        entitlements: [
            {
                code: 'eztrac-admin-user'
            }
        ]
    }

    const previousYearTimeFrameId = 'previousYearTimeFrameId'
    const currentYearLockedTimeFrameId = 'currentYearLockedTimeFrameId'
    const currentYearLockedTimeFrameName = 'current year locked time frame'
    const currentYearTimeFrameId = 'currentYearTimeFrameId'
    const currentYearTimeFrameName = 'current year time frame'
    const currentYearNextTimeFrameId = 'currentYearNextTimeFrameId'
    const currentYearNextTimeFrameName = 'current year next time frame'

    it('returns empty array when selected engagement is empty', () => {
        const state = {
            engagement: {
                selectedEngagement: []
            },
            timeFrame: {
                timeFrames: []
            },
            users: {
                currentUser: nonAdmin
            }
        }

        const expected = []
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it(`returns an array of all current year time frames \n
  when the user is admin and the engagement start time frame is in the previous year`, () => {
        const state = {
            engagement: {
                selectedEngagement: [
                    {
                        timeFrameId: previousYearTimeFrameId
                    }
                ]
            },
            timeFrame: {
                timeFrames: [
                    {
                        id: currentYearLockedTimeFrameId,
                        name: currentYearLockedTimeFrameName,
                        startDate: moment().subtract(1, 'month').valueOf(),
                        lockdown: true
                    },
                    {
                        id: currentYearTimeFrameId,
                        name: currentYearTimeFrameName,
                        startDate: moment(),
                        lockdown: false,
                        endDate: moment().add(1, 'month').valueOf()
                    }
                ]
            },
            users: {
                currentUser: admin
            }
        }

        const expected = [
            {
                value: currentYearLockedTimeFrameId,
                label: `${currentYearLockedTimeFrameName} (locked)`
            },
            {value: currentYearTimeFrameId, label: `${currentYearTimeFrameName}`}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it(`returns an array of not locked current year time frames \n
  when the user is not an admin and the engagement start time frame is in the previous year`, () => {
        const state = {
            engagement: {
                selectedEngagement: [
                    {
                        timeFrameId: previousYearTimeFrameId
                    }
                ]
            },
            timeFrame: {
                timeFrames: [
                    {
                        id: currentYearLockedTimeFrameId,
                        name: currentYearLockedTimeFrameName,
                        startDate: moment().subtract(1, 'month').valueOf(),
                        lockdown: true
                    },
                    {
                        id: currentYearTimeFrameId,
                        name: currentYearTimeFrameName,
                        startDate: moment(),
                        lockdown: false,
                        endDate: moment().add(1, 'month').valueOf()
                    }
                ]
            },
            users: {
                currentUser: nonAdmin
            }
        }

        const expected = [{value: currentYearTimeFrameId, label: `${currentYearTimeFrameName}`}]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it(`returns an array of current year time frames, beginning with the start time frame\n
  when the user is an admin and the engagement start time frame is in the current year`, () => {
        const state = {
            engagement: {
                selectedEngagement: [
                    {
                        timeFrameId: currentYearLockedTimeFrameId
                    }
                ]
            },
            timeFrame: {
                timeFrames: [
                    {
                        id: currentYearLockedTimeFrameId,
                        name: currentYearLockedTimeFrameName,
                        startDate: moment().subtract(1, 'month').valueOf(),
                        lockdown: true
                    },
                    {
                        id: currentYearTimeFrameId,
                        name: currentYearTimeFrameName,
                        startDate: moment(),
                        lockdown: false,
                        endDate: moment().add(1, 'month').valueOf()
                    },
                    {
                        id: currentYearNextTimeFrameId,
                        name: currentYearNextTimeFrameName,
                        startDate: moment().add(1, 'month').valueOf(),
                        lockdown: false,
                        endDate: moment().add(2, 'months').valueOf()
                    }
                ]
            },
            users: {
                currentUser: admin
            }
        }

        const expected = [
            {
                value: currentYearLockedTimeFrameId,
                label: `${currentYearLockedTimeFrameName} (locked)`
            },
            {value: currentYearTimeFrameId, label: `${currentYearTimeFrameName}`},
            {value: currentYearNextTimeFrameId, label: `${currentYearNextTimeFrameName}`}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it(`returns an array of current year time frames, beginning with the non-locked start time frame\n
  when the user is an admin and the engagement start time frame is in the current year`, () => {
        const state = {
            engagement: {
                selectedEngagement: [
                    {
                        timeFrameId: currentYearTimeFrameId
                    }
                ]
            },
            timeFrame: {
                timeFrames: [
                    {
                        id: currentYearLockedTimeFrameId,
                        name: currentYearLockedTimeFrameName,
                        startDate: moment().subtract(1, 'month').valueOf(),
                        lockdown: true
                    },
                    {
                        id: currentYearTimeFrameId,
                        name: currentYearTimeFrameName,
                        startDate: moment(),
                        lockdown: false,
                        endDate: moment().add(1, 'month').valueOf()
                    },
                    {
                        id: currentYearNextTimeFrameId,
                        name: currentYearNextTimeFrameName,
                        startDate: moment().add(1, 'month').valueOf(),
                        lockdown: false,
                        endDate: moment().add(2, 'months').valueOf()
                    }
                ]
            },
            users: {
                currentUser: admin
            }
        }

        const expected = [
            {value: currentYearTimeFrameId, label: `${currentYearTimeFrameName}`},
            {value: currentYearNextTimeFrameId, label: `${currentYearNextTimeFrameName}`}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })

    it('returns only not locked current year time frames when the user is not an admin', () => {
        const state = {
            engagement: {
                selectedEngagement: [
                    {
                        timeFrameId: currentYearTimeFrameId
                    }
                ]
            },
            timeFrame: {
                timeFrames: [
                    {
                        id: currentYearLockedTimeFrameId,
                        name: currentYearLockedTimeFrameName,
                        startDate: moment().subtract(1, 'month').valueOf(),
                        lockdown: true
                    },
                    {
                        id: currentYearTimeFrameId,
                        name: currentYearTimeFrameName,
                        startDate: moment(),
                        lockdown: false,
                        endDate: moment().add(1, 'month').valueOf()
                    },
                    {
                        id: currentYearNextTimeFrameId,
                        name: currentYearNextTimeFrameName,
                        startDate: moment().add(1, 'month').valueOf(),
                        lockdown: false,
                        endDate: moment().add(2, 'months').valueOf()
                    }
                ]
            },
            users: {
                currentUser: nonAdmin
            }
        }

        const expected = [
            {value: currentYearTimeFrameId, label: `${currentYearTimeFrameName}`},
            {value: currentYearNextTimeFrameId, label: `${currentYearNextTimeFrameName}`}
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
