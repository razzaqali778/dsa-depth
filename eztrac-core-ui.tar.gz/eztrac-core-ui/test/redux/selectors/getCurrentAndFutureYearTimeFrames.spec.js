import selector from '../../../src/client/redux/selectors/getCurrentAndFutureYearTimeFrames'

beforeAll(() => {
    jest.useFakeTimers('modern')
    jest.setSystemTime(new Date(2023, 3, 1))
})

afterAll(() => {
    jest.useRealTimers()
})

describe('get current and future year time frames', () => {
    it('returns current year time frames', () => {
        const date = new Date()

        const previousYearTimeFrameId = 'previousYearTimeFrameId'
        const previousYearTimeFrameName = 'previous year time frame'
        const previousYearDate = new Date().setUTCFullYear(date.getUTCFullYear() - 1).valueOf()

        const currentYearLockedTimeFrameId = 'currentYearLockedTimeFrameId'
        const currentYearLockedTimeFrameName = 'current year locked time frame'
        const currentYearLockedDate = new Date().setUTCMonth(date.getUTCMonth() - 1).valueOf()

        const currentYearTimeFrameId = 'currentYearTimeFrameId'
        const currentYearTimeFrameName = 'current year time frame'
        const currentYearDate = new Date().valueOf()

        const currentYearNextTimeFrameId = 'currentYearNextTimeFrameId'
        const currentYearNextTimeFrameName = 'current year next time frame'
        const currentYearNextTfDate = new Date().setUTCMonth(date.getUTCMonth() + 1).valueOf()
        const currentYearFutureTfDate = new Date().setUTCMonth(date.getUTCMonth() + 2).valueOf()

        const nextYearTimeFrameId = 'nextYearTimeFrameId'
        const nextYearTimeFrameName = 'next year time frame'
        const nextYearTimeFrameStartDate = new Date()
            .setUTCFullYear(date.getUTCFullYear() + 1)
            .valueOf()
        const nextYearTimeFrameEndDate = new Date(nextYearTimeFrameStartDate)
            .setUTCMonth(new Date(nextYearTimeFrameStartDate).getUTCMonth() + 1)
            .valueOf()

        const state = {
            timeFrame: {
                timeFrames: [
                    {
                        id: previousYearTimeFrameId,
                        name: previousYearTimeFrameName,
                        startDate: previousYearDate,
                        lockdown: true
                    },
                    {
                        id: currentYearLockedTimeFrameId,
                        name: currentYearLockedTimeFrameName,
                        startDate: currentYearLockedDate,
                        lockdown: true
                    },
                    {
                        id: currentYearTimeFrameId,
                        name: currentYearTimeFrameName,
                        startDate: currentYearDate,
                        lockdown: false,
                        endDate: currentYearNextTfDate
                    },
                    {
                        id: currentYearNextTimeFrameId,
                        name: currentYearNextTimeFrameName,
                        startDate: currentYearNextTfDate,
                        lockdown: false,
                        endDate: currentYearFutureTfDate
                    },
                    {
                        id: nextYearTimeFrameId,
                        name: nextYearTimeFrameName,
                        startDate: nextYearTimeFrameStartDate,
                        lockdown: false,
                        endDate: nextYearTimeFrameEndDate
                    }
                ]
            }
        }

        const expected = [
            {
                id: currentYearLockedTimeFrameId,
                name: currentYearLockedTimeFrameName,
                startDate: currentYearLockedDate,
                lockdown: true
            },
            {
                id: currentYearTimeFrameId,
                name: currentYearTimeFrameName,
                startDate: currentYearDate,
                lockdown: false,
                endDate: currentYearNextTfDate
            },
            {
                id: currentYearNextTimeFrameId,
                name: currentYearNextTimeFrameName,
                startDate: currentYearNextTfDate,
                lockdown: false,
                endDate: currentYearFutureTfDate
            },
            {
                id: nextYearTimeFrameId,
                name: nextYearTimeFrameName,
                startDate: nextYearTimeFrameStartDate,
                lockdown: false,
                endDate: nextYearTimeFrameEndDate
            }
        ]
        const actual = selector(state)

        expect(actual).toEqual(expected)
    })
})
