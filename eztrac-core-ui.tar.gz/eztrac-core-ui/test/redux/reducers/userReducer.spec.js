import {SET_CURRENT_USER} from '../../../src/client/redux/constants/userConstants'
import reducer from '../../../src/client/redux/reducers/userReducer'

const initialState = {
    currentUser: {}
}
describe('userReducer', () => {
    it('exports correct initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })
    it('responds correctly to set current user', () => {
        const expectedUser = {
            user: 'John'
        }

        const action = {
            type: SET_CURRENT_USER,
            payload: expectedUser
        }
        const state = reducer(initialState, action)

        expect(state).toEqual({currentUser: expectedUser})
    })
})
