import {
    SET_FAVORITE_TEAMS_PREFERENCE,
    SET_SELECTED_TEAM_TAB,
    SET_SORT_ORDER_PREFERENCE,
    SET_SORT_ORDER_PREFERENCE_PEOPLE_LOCAL
} from '../../../src/client/redux/constants/preferencesConstants'
import reducer from '../../../src/client/redux/reducers/preferencesReducer'

const initialState = {
    preferences: {},
    sortOrderPreferences: {
        allocationNum: 0,
        costNum: 0,
        nameNum: 1
    },
    selectedTeamTab: '',
    sortOrderPreferencesPeople: {
        participationNum: 0,
        nameNum: 0,
        rateNum: 0,
        costGroupNum: 0,
        numberOfPeopleNum: 0
    }
}

describe('team favorite preference reducer', () => {
    it('exports correct initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })

    it('responds correctly to SET_FAVORITE_TEAMS_PREFERENCE', () => {
        const action = {
            type: SET_FAVORITE_TEAMS_PREFERENCE,
            payload: {some: 'stuff'}
        }

        const expectedState = {
            ...initialState,
            preferences: {some: 'stuff'}
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
})

describe('sort order preference reducer', () => {
    it('exports correct initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })

    it('responds correctly to SET_SORT_ORDER_PREFERENCE', () => {
        const action = {
            type: SET_SORT_ORDER_PREFERENCE,
            payload: {allocationNum: 0, costNum: 1, nameNum: 0}
        }

        const expectedState = {
            ...initialState,
            sortOrderPreferences: {allocationNum: 0, costNum: 1, nameNum: 0}
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_SORT_ORDER_PREFERENCE_PEOPLE_LOCAL', () => {
        const action = {
            type: SET_SORT_ORDER_PREFERENCE_PEOPLE_LOCAL,
            payload: {
                participationNum: 0,
                nameNum: 1,
                rateNum: 0,
                costGroupNum: 0,
                numberOfPeopleNum: 2
            }
        }

        const expectedState = {
            ...initialState,
            sortOrderPreferencesPeople: {
                participationNum: 0,
                nameNum: 1,
                rateNum: 0,
                costGroupNum: 0,
                numberOfPeopleNum: 2
            }
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
})

describe('last tab preference reducer', () => {
    it('responds correctly to SET_SELECTED_TEAM_TAB', () => {
        const action = {
            type: SET_SELECTED_TEAM_TAB,
            payload: 2
        }
        const expectedState = {
            ...initialState,
            selectedTeamTab: 2
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
})
