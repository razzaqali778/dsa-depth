import {
    CLEAR_COPY_FORWARD_TIME_FRAME,
    CLEAR_INITIATIVE_ERRORS,
    CLEAR_INITIATIVE_WARNINGS,
    CLEAR_NEW_INITIATIVE_DATA,
    SET_COPY_FORWARD_TIME_FRAME,
    SET_INITIATIVES,
    SET_INITIATIVES_TABLE_SORT,
    SET_INITIATIVE_ERRORS,
    SET_INITIATIVE_WARNINGS,
    SET_IS_INITIATIVE_COPY_FORWARD_CONTAINER_OPEN,
    SET_IS_INITIATIVE_MODIFY_FINDER_OPEN,
    SET_NEW_INITIATIVE_DATA,
    SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES,
    SET_TEAM_INITIATIVES
} from '../../../src/client/redux/constants/initiativeConstants'
import reducer from '../../../src/client/redux/reducers/initiativeReducer'

const initialState = {
    allInitiatives: [],
    copyForwardTimeFrame: [],
    teamInitiatives: [],
    initiativeWarnings: [],
    initiativeErrors: [],
    initiativesTableSort: {
        allocationNum: 0,
        costNum: 0,
        nameNum: 1
    },
    selectedTimeFrameTeamInitiatives: [],
    newInitiativeData: {
        value: {
            teamCostPct: 0,
            initiativeCost: 0
        }
    },
    isInitiativeCopyForwardContainerOpen: false,
    isInitiativeModifyFinderOpen: false
}

describe('initiative reducer', () => {
    it('exports the correct initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })
    it('responds correctly to SET_INITIATIVES', () => {
        const action = {
            type: SET_INITIATIVES,
            payload: [
                {
                    financeCodeType: null,
                    financeCodeValue: null,
                    id: '6c71e61e-8e10-4585-a6f4-02c3e363d685',
                    initiativeName: '1st Slice Universal Sequence Repository (AD)',
                    isAllocable: true,
                    isInheritable: true,
                    parentId: '0b7bb535-d6f0-4859-a159-7020d5d1c81c',
                    parentName: 'BIO',
                    parent_status: null,
                    portfolioCode: null,
                    status: 'Completed',
                    typeId: 'UNKOWN'
                },
                {
                    financeCodeType: null,
                    financeCodeValue: null,
                    id: '7c23d2f0-5067-4786-9f8e-b08655f3f939',
                    initiativeName: '1st Slice Universal Sequence Repository Cap-Exp (AD)',
                    isAllocable: true,
                    isInheritable: true,
                    parentId: '9d440c0c-5714-45c0-979b-57da1b26ab45',
                    parentName: 'BIO Expense',
                    parent_status: null,
                    portfolioCode: null,
                    status: 'Completed',
                    typeId: 'UNKNOWN'
                }
            ]
        }

        const expectedState = {
            ...initialState,
            allInitiatives: action.payload
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_TEAM_INITIATIVES', () => {
        const action = {
            type: SET_TEAM_INITIATIVES,
            payload: [
                {
                    name: 'Velocity Field Support',
                    teamCostPct: 100,
                    id: 'ee4a50c0-0214-11e9-a195-97d08e842828'
                }
            ]
        }

        const expectedState = {
            ...initialState,
            teamInitiatives: action.payload
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_INITIATIVE_WARNINGS', () => {
        const action = {
            type: SET_INITIATIVE_WARNINGS,
            payload: 'This is a warning!'
        }

        const expectedState = {
            ...initialState,
            initiativeWarnings: ['This is a warning!']
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to CLEAR_INITIATIVE_WARNINGS', () => {
        const action = {
            type: CLEAR_INITIATIVE_WARNINGS
        }

        const warningState = {
            ...initialState,
            initiativeWarnings: ['This warning must be cleared to an empty array']
        }

        const state = reducer(warningState, action)
        expect(state).toEqual(initialState)
    })
    it('responds correctly to SET_INITIATIVE_ERRORS', () => {
        const action = {
            type: SET_INITIATIVE_ERRORS,
            payload: 'This is an error!'
        }

        const expectedState = {
            ...initialState,
            initiativeErrors: ['This is an error!']
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to CLEAR_INITIATIVE_ERRORS', () => {
        const action = {
            type: CLEAR_INITIATIVE_ERRORS
        }

        const errorState = {
            ...initialState,
            initiativeErrors: ['This error must be cleared to an empty array']
        }

        const state = reducer(errorState, action)
        expect(state).toEqual(initialState)
    })
    it('responds correctly to SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES', () => {
        const action = {
            type: SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES,
            payload: [
                {
                    id: '7c23d2f0-5067-4786-9f8e-b08655f3f939',
                    initiativeName: '1st Slice Universal Sequence Repository Cap-Exp (AD)'
                },
                {
                    id: '6c71e61e-8e10-4585-a6f4-02c3e363d685',
                    initiativeName: '1st Slice Universal Sequence Repository (AD)'
                }
            ]
        }
        const expectedState = {
            ...initialState,
            selectedTimeFrameTeamInitiatives: [
                {
                    id: '7c23d2f0-5067-4786-9f8e-b08655f3f939',
                    initiativeName: '1st Slice Universal Sequence Repository Cap-Exp (AD)'
                },
                {
                    id: '6c71e61e-8e10-4585-a6f4-02c3e363d685',
                    initiativeName: '1st Slice Universal Sequence Repository (AD)'
                }
            ]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('it responds correctly to SET_NEW_INITIATIVE_DATA', () => {
        const action = {
            type: SET_NEW_INITIATIVE_DATA,
            payload: {
                id: '7c23d2f0-5067-4786-9f8e-b08655f3f939',
                initiativeName: '1st Slice Universal Sequence Repository Cap-Exp (AD)'
            }
        }
        const expectedState = {
            ...initialState,
            newInitiativeData: {
                id: '7c23d2f0-5067-4786-9f8e-b08655f3f939',
                initiativeName: '1st Slice Universal Sequence Repository Cap-Exp (AD)'
            }
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('it responds correctly to CLEAR_NEW_INITIATIVE_DATA', () => {
        const action = {
            type: CLEAR_NEW_INITIATIVE_DATA,
            action: {}
        }
        const expectedState = {
            ...initialState,
            newInitiativeData: {
                value: {
                    teamCostPct: 0,
                    initiativeCost: 0
                }
            }
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('it responds correctly to SET_IS_INITIATIVE_COPY_FORWARD_CONTAINER_OPEN', () => {
        const action = {
            type: SET_IS_INITIATIVE_COPY_FORWARD_CONTAINER_OPEN,
            payload: true
        }
        const expectedState = {
            ...initialState,
            isInitiativeCopyForwardContainerOpen: true
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('it responds correctly to SET_IS_INITIATIVE_MODIFY_FINDER_OPEN', () => {
        const action = {
            type: SET_IS_INITIATIVE_MODIFY_FINDER_OPEN,
            payload: true
        }
        const expectedState = {
            ...initialState,
            isInitiativeModifyFinderOpen: true
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_INITIATIVES_TABLE_SORT', () => {
        const action = {
            type: SET_INITIATIVES_TABLE_SORT,
            payload: {
                nameNum: 0,
                allocationNum: 1,
                costNum: 0
            }
        }

        const expectedState = {
            ...initialState,
            initiativesTableSort: action.payload
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_COPY_FORWARD_TIME_FRAME', () => {
        const action = {
            type: SET_COPY_FORWARD_TIME_FRAME,
            payload: 41902
        }
        const initialStateCopyForward = {
            allInitiatives: [],
            copyForwardTimeFrame: [41901],
            teamInitiatives: [],
            initiativeWarnings: [],
            initiativeErrors: [],
            initiativesTableSort: {
                allocationNum: 0,
                costNum: 0,
                nameNum: 1
            },
            selectedTimeFrameTeamInitiatives: [],
            newInitiativeData: {},
            isInitiativeCopyForwardContainerOpen: false,
            isInitiativeModifyFinderOpen: false
        }

        const expectedState = {
            ...initialStateCopyForward,
            copyForwardTimeFrame: [41901, action.payload]
        }
        const state = reducer(initialStateCopyForward, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to CLEAR_COPY_FORWARD_TIME_FRAME', () => {
        const action = {
            type: CLEAR_COPY_FORWARD_TIME_FRAME
        }

        const initialStateCopyForward = {
            allInitiatives: [],
            copyForwardTimeFrame: [],
            teamInitiatives: [],
            initiativeWarnings: [],
            initiativeErrors: [],
            initiativesTableSort: {
                allocationNum: 0,
                costNum: 0,
                nameNum: 1
            },
            selectedTimeFrameTeamInitiatives: [],
            newInitiativeData: {},
            isInitiativeCopyForwardContainerOpen: false,
            isInitiativeModifyFinderOpen: false
        }

        const expectedState = {
            ...initialStateCopyForward,
            copyForwardTimeFrame: []
        }

        const state = reducer(initialStateCopyForward, action)
        expect(state).toEqual(expectedState)
    })
})
