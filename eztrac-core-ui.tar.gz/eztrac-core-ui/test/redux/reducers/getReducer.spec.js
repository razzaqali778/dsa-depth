import {
    SET_GET_CSV_DOWNLOAD,
    SET_SELECTED_REGION
} from '../../../src/client/redux/constants/getConstants'
import reducer from '../../../src/client/redux/reducers/getReducer'

const initialState = {
    csvDownload: [],
    selectedCommunityPlatform: [],
    selectedTeams: [],
    selectedRegion: '',
    downloadAll: false
}

describe('get reducer', () => {
    it('starts with empty array initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })
    it('saves the download when SET_GET_DOWNLOAD is fired', () => {
        const action = {
            type: SET_GET_CSV_DOWNLOAD,
            payload: [{downloadObject: 'stuff'}]
        }
        const expectedState = {
            csvDownload: [{downloadObject: 'stuff'}],
            selectedCommunityPlatform: [],
            selectedTeams: [],
            selectedRegion: '',
            downloadAll: false
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('sets region value when SET_SELECTED_REGION is fired', () => {
        const region = 'Poland'
        const action = {
            type: SET_SELECTED_REGION,
            payload: region
        }
        const expectedState = {
            csvDownload: [],
            selectedCommunityPlatform: [],
            selectedTeams: [],
            selectedRegion: region,
            downloadAll: false
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
})
