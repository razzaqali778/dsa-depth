import {
    CLEAR_NEW_FORECASTED_PERSON_DATA,
    CLEAR_NEW_PERSON_DATA,
    SET_ACTIVE_PEOPLE,
    SET_COST_GROUPS,
    SET_IS_PEOPLE_MODIFY_FINDER_OPEN,
    SET_NEW_FORECASTED_PERSON_DATA,
    SET_NEW_PERSON_DATA,
    SET_PEOPLE,
    SET_RATES,
    SET_SELECTED_TIME_FRAME_FORECASTED_PEOPLE,
    SET_SELECTED_TIME_FRAME_TEAM_PEOPLE,
    SET_TEAM_FORECASTED_PEOPLE,
    SET_TEAM_PEOPLE
} from '../../../src/client/redux/constants/peopleConstants'
import reducer from '../../../src/client/redux/reducers/peopleReducer'

const initialState = {
    people: [],
    activePeople: [],
    isPeopleModifyFinderOpen: false,
    newPersonData: {
        participationPct: 100
    },
    selectedTimeFrameTeamPeople: [],
    teamPeople: [],
    selectedTimeFrameForecastedPeople: [],
    teamForecastedPeople: [],
    costGroups: [],
    currentUserProfileDetails: {},
    rates: [],
    newForecastedPersonData: {
        numberOfPeople: 1,
        costGroupId: '',
        rateId: ''
    }
}

describe('people reducer', () => {
    it('exports correct initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })

    it('responds correctly to SET_PEOPLE', () => {
        const action = {
            type: SET_PEOPLE,
            payload: [{personId: 'person1'}, {personId: 'person2'}]
        }

        const expectedState = {
            ...initialState,
            people: [{personId: 'person1'}, {personId: 'person2'}]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_RATES', () => {
        const action = {
            type: SET_RATES,
            payload: [{id: 'rate1'}, {id: 'rate2'}]
        }

        const expectedState = {
            ...initialState,
            rates: [{id: 'rate1'}, {id: 'rate2'}]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_COST_GROUPS', () => {
        const action = {
            type: SET_COST_GROUPS,
            payload: [{id: 'costgroup1'}, {id: 'costgroup2'}]
        }

        const expectedState = {
            ...initialState,
            costGroups: [{id: 'costgroup1'}, {id: 'costgroup2'}]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_IS_PEOPLE_MODIFY_FINDER_OPEN', () => {
        const action = {
            type: SET_IS_PEOPLE_MODIFY_FINDER_OPEN,
            payload: true
        }

        const expectedState = {
            ...initialState,
            isPeopleModifyFinderOpen: true
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_SELECTED_TIME_FRAME_TEAM_PEOPLE', () => {
        const action = {
            type: SET_SELECTED_TIME_FRAME_TEAM_PEOPLE,
            payload: [{personId: 'person1'}, {personId: 'person2'}]
        }

        const expectedState = {
            ...initialState,
            selectedTimeFrameTeamPeople: [{personId: 'person1'}, {personId: 'person2'}]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_NEW_PERSON_DATA', () => {
        const action = {
            type: SET_NEW_PERSON_DATA,
            payload: {personId: 'person1'}
        }

        const expectedState = {
            ...initialState,
            newPersonData: {personId: 'person1'}
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to CLEAR_NEW_PERSON_DATA', () => {
        const action = {
            type: CLEAR_NEW_PERSON_DATA,
            payload: {}
        }

        const expectedState = {
            ...initialState,
            newPersonData: {
                participationPct: 100
            }
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_NEW_FORECASTED_PERSON_DATA', () => {
        const action = {
            type: SET_NEW_FORECASTED_PERSON_DATA,
            payload: {
                numberOfPeople: 56,
                costGroupId: 'PEPPER',
                costGroupName: 'Pepper',
                rateId: 'A_LOT',
                rateName: 'A lot'
            }
        }

        const expectedState = {
            ...initialState,
            newForecastedPersonData: {
                numberOfPeople: 56,
                costGroupId: 'PEPPER',
                costGroupName: 'Pepper',
                rateId: 'A_LOT',
                rateName: 'A lot'
            }
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to CLEAR_NEW_FORECASTED_PERSON_DATA', () => {
        const action = {
            type: CLEAR_NEW_FORECASTED_PERSON_DATA,
            payload: {}
        }

        const expectedState = {
            ...initialState,
            newForecastedPersonData: {
                numberOfPeople: 1,
                costGroupId: '',
                costGroupName: '',
                rateId: '',
                rateName: ''
            }
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_TEAM_PEOPLE', () => {
        const action = {
            type: SET_TEAM_PEOPLE,
            payload: [
                {personName: 'person1', personId: '12345', participationPct: 100},
                {personName: 'person2', personId: '67890', participationPct: 100},
                {personName: 'person3', personId: 'ABCDE', participationPct: 50}
            ]
        }

        const expectedState = {
            ...initialState,
            teamPeople: [
                {personName: 'person1', personId: '12345', participationPct: 100},
                {personName: 'person2', personId: '67890', participationPct: 100},
                {personName: 'person3', personId: 'ABCDE', participationPct: 50}
            ]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_SELECTED_TIME_FRAME_FORECASTED_PEOPLE', () => {
        const action = {
            type: SET_SELECTED_TIME_FRAME_FORECASTED_PEOPLE,
            payload: [
                {
                    costGroupId: 'CostGroup1',
                    numberOfPeople: 1,
                    rateId: 'STANDARD',
                    timeFrameId: 41910
                },
                {
                    costGroupId: 'CostGroup2',
                    numberOfPeople: 1,
                    rateId: 'STANDARD',
                    timeFrameId: 41910
                },
                {
                    costGroupId: 'CostGroup3',
                    numberOfPeople: 1,
                    rateId: 'STANDARD',
                    timeFrameId: 41910
                }
            ]
        }
        const expectedState = {
            ...initialState,
            selectedTimeFrameForecastedPeople: [
                {
                    costGroupId: 'CostGroup1',
                    numberOfPeople: 1,
                    rateId: 'STANDARD',
                    timeFrameId: 41910
                },
                {
                    costGroupId: 'CostGroup2',
                    numberOfPeople: 1,
                    rateId: 'STANDARD',
                    timeFrameId: 41910
                },
                {
                    costGroupId: 'CostGroup3',
                    numberOfPeople: 1,
                    rateId: 'STANDARD',
                    timeFrameId: 41910
                }
            ]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_TEAM_FORECASTED_PEOPLE', () => {
        const action = {
            type: SET_TEAM_FORECASTED_PEOPLE,
            payload: [
                {
                    numberOfPeople: 4,
                    costGroupId: 'MY-COST-GROUP',
                    rateId: 'Standard',
                    timeFrameId: 41908
                },
                {
                    numberOfPeople: 2,
                    costGroupId: 'MY-COST-GROUP-2',
                    rateId: 'Not-Standard',
                    timeFrameId: 41909
                }
            ]
        }

        const expectedState = {
            ...initialState,
            teamForecastedPeople: [
                {
                    numberOfPeople: 4,
                    costGroupId: 'MY-COST-GROUP',
                    rateId: 'Standard',
                    timeFrameId: 41908
                },
                {
                    numberOfPeople: 2,
                    costGroupId: 'MY-COST-GROUP-2',
                    rateId: 'Not-Standard',
                    timeFrameId: 41909
                }
            ]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_ACTIVE_PEOPLE', () => {
        const action = {
            type: SET_ACTIVE_PEOPLE,
            payload: [
                {personId: '1', personName: 'My name', isActive: true},
                {personId: '2', personName: 'My other name', isActive: true}
            ]
        }

        const expectedState = {
            ...initialState,
            activePeople: [
                {personId: '1', personName: 'My name', isActive: true},
                {personId: '2', personName: 'My other name', isActive: true}
            ]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
})
