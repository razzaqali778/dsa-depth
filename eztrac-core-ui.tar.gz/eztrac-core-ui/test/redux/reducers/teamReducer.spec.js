import {
    SET_COMMUNITIES,
    SET_FORM_COMMUNITY_ID,
    SET_FORM_IS_ACTIVE,
    SET_FORM_TEAM_NAME,
    SET_IS_EDITING,
    SET_PLATFORMS,
    SET_ORGS,
    SET_SELECTED_TEAM,
    SET_SELECTED_TEAM_FROM_URL,
    SET_SELECTED_TEAM_TAB_FROM_URL,
    SET_SELECTED_TIME_FRAME_TEAM_COST,
    SET_TEAMS,
    SET_TEAM_COST_DATA,
    TOGGLE_IS_CREATING_TEAM
} from '../../../src/client/redux/constants/teamConstants'
import reducer from '../../../src/client/redux/reducers/teamReducer'

const initialState = {
    teams: [],
    communities: [],
    platforms: [],
    orgs: [],
    selectedTeamTab: '',
    selectedTeam: {},
    selectedPlatformId: '',
    selectedCommunityId: '',
    selectedOrgId: '',
    formValues: {
        communityId: '',
        isActive: false,
        teamName: ''
    },
    isCreatingTeam: false,
    unsavedDataModalBool: false,
    unsavedChanges: false
}

describe('team reducer', () => {
    it('exports correct initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })
    it('responds correctly to SET_TEAMS', () => {
        const action = {
            type: SET_TEAMS,
            payload: [{some: 'stuff'}]
        }

        const expectedState = {
            ...initialState,
            teams: [{some: 'stuff'}]
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_SELECTED_TEAM_TAB_FROM_URL', () => {
        const action = {
            type: SET_SELECTED_TEAM_TAB_FROM_URL,
            payload: 'initiatives'
        }
        const expectedState = {
            ...initialState,
            selectedTeamTab: 'initiatives'
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds to SET_SELECTED_TEAM correctly', () => {
        const action = {
            type: SET_SELECTED_TEAM,
            payload: {id: 'body once told me', name: 'world was gonna roll me'}
        }

        const expectedState = {
            ...initialState,
            selectedTeam: {id: 'body once told me', name: 'world was gonna roll me'}
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds to SET_SELECTED_TEAM correctly when the user backspaces', () => {
        const action = {
            type: SET_SELECTED_TEAM
        }

        const expectedState = {
            ...initialState,
            selectedTeam: {id: '', name: ''}
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_COMMUNITIES', () => {
        const action = {
            type: SET_COMMUNITIES,
            payload: ['some', 'stuff']
        }
        const expectedState = {
            ...initialState,
            communities: ['some', 'stuff']
        }
        const actualState = reducer(initialState, action)

        expect(actualState).toEqual(expectedState)
    })
    it('responds correctly to SET_PLATFORMS', () => {
        const action = {
            type: SET_PLATFORMS,
            payload: ['some', 'stuff']
        }
        const expectedState = {
            ...initialState,
            platforms: ['some', 'stuff']
        }
        const actualState = reducer(initialState, action)

        expect(actualState).toEqual(expectedState)
    })

    it('responds correctly to SET_ORGS', () => {
        const action = {
            type: SET_ORGS,
            payload: ['org', 'org org']
        }
        const expectedState = {
            ...initialState,
            orgs: ['org', 'org org']
        }
        const actualState = reducer(initialState, action)

        expect(actualState).toEqual(expectedState)
    })

    it('responds correctly to SET_IS_EDITING', () => {
        const action = {
            type: SET_IS_EDITING,
            payload: 'TEST'
        }
        const expectedState = {
            ...initialState,
            selectedTeam: {isEditing: action.payload}
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_SELECTED_TEAM_FROM_URL with valid value', () => {
        const action = {
            type: SET_SELECTED_TEAM_FROM_URL,
            payload: {id: 56, name: 'Happy Team!'}
        }
        const expectedState = {
            ...initialState,
            selectedTeam: action.payload
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_SELECTED_TEAM_FROM_URL with invalid value', () => {
        const action = {
            type: SET_SELECTED_TEAM_FROM_URL,
            payload: undefined
        }
        const expectedState = {
            ...initialState,
            selectedTeam: {id: '', name: ''}
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_TEAM_COST_DATA', () => {
        const action = {
            type: SET_TEAM_COST_DATA,
            payload: 700000
        }
        const expectedState = {
            ...initialState,
            selectedTeam: {teamCostData: action.payload}
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_SELECTED_TIME_FRAME_TEAM_COST with valid value', () => {
        const action = {
            type: SET_SELECTED_TIME_FRAME_TEAM_COST,
            payload: {teamCost: 36000}
        }
        const expectedState = {
            ...initialState,
            selectedTeam: {selectedTimeFrameTeamCost: action.payload.teamCost}
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_SELECTED_TIME_FRAME_TEAM_COST with invalid value', () => {
        const action = {
            type: SET_SELECTED_TIME_FRAME_TEAM_COST,
            payload: undefined
        }
        const expectedState = {
            ...initialState,
            selectedTeam: {selectedTimeFrameTeamCost: 0}
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to TOGGLE_IS_CREATING_TEAM', () => {
        const action = {
            type: TOGGLE_IS_CREATING_TEAM,
            payload: true
        }
        const expectedState = {
            ...initialState,
            isCreatingTeam: action.payload
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    describe('it updates formValues correctly', () => {
        it('responds to SET_FORM_COMMUNITY_ID', () => {
            const action = {
                type: SET_FORM_COMMUNITY_ID,
                payload: 'some-community-id'
            }

            const expectedState = {
                ...initialState,
                formValues: {...initialState.formValues, communityId: 'some-community-id'}
            }

            const actualState = reducer(initialState, action)

            expect(actualState).toEqual(expectedState)
        })
        it('responds to SET_FORM_IS_ACTIVE', () => {
            const action = {
                type: SET_FORM_IS_ACTIVE,
                payload: true
            }

            const expectedState = {
                ...initialState,
                formValues: {...initialState.formValues, isActive: true}
            }

            const actualState = reducer(initialState, action)

            expect(actualState).toEqual(expectedState)
        })
        it('responds to SET_FORM_TEAM_NAME', () => {
            const action = {
                type: SET_FORM_TEAM_NAME,
                payload: 'some-team-name'
            }

            const expectedState = {
                ...initialState,
                formValues: {...initialState.formValues, teamName: 'some-team-name'}
            }

            const actualState = reducer(initialState, action)

            expect(actualState).toEqual(expectedState)
        })
    })
})
