import {
    SET_ALL_TEAM_ENGAGEMENTS,
    SET_ENGAGEMENT_FILTER_PHRASE,
    SET_ENGAGEMENT_OPTIONS,
    SET_IS_EDITING_ENGAGEMENT,
    SET_SELECTED_ENGAGEMENT,
    SET_TOTAL_ENGAGEMENT_COST,
    TOGGLE_IS_CREATING_ENGAGEMENT
} from '../../../../src/client/redux/constants/engagementConstants'
import reducer from '../../../../src/client/redux/reducers/engagements/engagementsReducer'

const initialState = {
    engagementOptions: [],
    selectedEngagement: '',
    editDialogOpened: false,
    engagementFilterPhrase: '',
    removeDialogOpened: false,
    totalEngagementCost: null,
    groupedAndSortedEngagements: {},
    isCreatingEngagement: false,
    toggleHistoricEngagements: false,
    isEditing: '',
    allTeamEngagements: [],
    scratchPad: {
        calendarHours: [],
        selectedRateCalendar: 'US-VARIABLE',
        calculatorRows: [],
        isCalculating: false
    }
}

describe('engagements reducer', () => {
    it('exports correct initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })

    it('responds correctly to SET_ENGAGEMENT_OPTIONS', () => {
        const action = {
            type: SET_ENGAGEMENT_OPTIONS,
            payload: {name: 'engagement 1'}
        }
        const expectedState = {
            ...initialState,
            engagementOptions: {name: 'engagement 1'}
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_SELECTED_ENGAGEMENT', () => {
        const action = {
            type: SET_SELECTED_ENGAGEMENT,
            payload: {name: 'garbage'}
        }
        const expectedState = {
            ...initialState,
            selectedEngagement: {name: 'garbage'}
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_TOTAL_ENGAGEMENT_COST', () => {
        const action = {
            type: SET_TOTAL_ENGAGEMENT_COST,
            payload: 5000
        }
        const expectedState = {
            ...initialState,
            totalEngagementCost: 5000
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_IS_EDITING', () => {
        const action = {
            type: SET_IS_EDITING_ENGAGEMENT,
            payload: 'ENGAGEMENT1'
        }
        const expectedState = {
            ...initialState,
            isEditing: action.payload
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to TOGGLE_IS_CREATING_ENGAGEMENT', () => {
        const action = {
            type: TOGGLE_IS_CREATING_ENGAGEMENT,
            payload: true
        }
        const expectedState = {
            ...initialState,
            isCreatingEngagement: action.payload
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_ALL_TEAM_ENGAGEMENTS', () => {
        const action = {
            type: SET_ALL_TEAM_ENGAGEMENTS,
            payload: [
                {
                    data: 'fake'
                }
            ]
        }

        const expectedState = {
            ...initialState,
            allTeamEngagements: action.payload
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_ENGAGEMENT_FILTER_PHRASE', () => {
        const action = {
            type: SET_ENGAGEMENT_FILTER_PHRASE,
            payload: 'filter'
        }

        const expectedState = {
            ...initialState,
            engagementFilterPhrase: action.payload
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
})
