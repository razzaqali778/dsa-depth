import {
    ADD_CALCULATOR_ROW,
    CLEAR_CALCULATOR_ROWS,
    REMOVE_CALCULATOR_ROW,
    SET_CALENDARS,
    SET_SELECTED_CALENDAR,
    TOGGLE_IS_CALCULATING
} from '../../../../src/client/redux/constants/engagementConstants'
import reducer from '../../../../src/client/redux/reducers/engagements/scratchPadReducer'

const initialState = {
    calculatorRows: [],
    isCalculating: false,
    calendarHours: [],
    selectedRateCalendar: 'US-VARIABLE'
}

describe('scratchpad reducer', () => {
    it('exports correct initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })

    it('responds correctly to CLEAR_CALCULATOR_ROWS', () => {
        const action = {
            type: CLEAR_CALCULATOR_ROWS
        }
        const expectedState = {
            ...initialState,
            calculatorRows: []
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to REMOVE_CALCULATOR_ROW', () => {
        const updatedInitialState = {
            ...initialState,
            calculatorRows: [
                {
                    people: '1',
                    hourlyRate: '30',
                    startingCost: null,
                    timeStamp: 1
                },
                {
                    people: '3',
                    hourlyRate: '35',
                    startingCost: null,
                    timeStamp: 2
                }
            ]
        }

        const action = {
            type: REMOVE_CALCULATOR_ROW,
            payload: updatedInitialState.calculatorRows[0]
        }

        const expectedState = {
            ...updatedInitialState,
            calculatorRows: [
                {
                    people: '3',
                    hourlyRate: '35',
                    startingCost: null,
                    timeStamp: 2
                }
            ]
        }

        const state = reducer(updatedInitialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to ADD_CALCULATOR_ROW', () => {
        const action = {
            type: ADD_CALCULATOR_ROW,
            payload: {
                people: '1',
                hourlyRate: '30',
                startingCost: null,
                timeStamp: 1
            }
        }

        const expectedState = {
            ...initialState,
            calculatorRows: [
                {
                    people: '1',
                    hourlyRate: '30',
                    startingCost: null,
                    timeStamp: 1
                }
            ]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_CALENDARS', () => {
        const action = {
            type: SET_CALENDARS,
            payload: [
                {
                    name: 'Argentina Variable',
                    timeFrameId: 32100,
                    employeeHours: 160,
                    contractorHours: 160,
                    calendarId: 'ARG-VARIABLE'
                },
                {
                    name: 'Argentina Variable',
                    timeFrameId: 32101,
                    employeeHours: 168,
                    contractorHours: 168,
                    calendarId: 'ARG-VARIABLE'
                },
                {
                    name: 'Argentina Variable',
                    timeFrameId: 32102,
                    employeeHours: 168,
                    contractorHours: 168,
                    calendarId: 'ARG-VARIABLE'
                }
            ]
        }

        const expectedState = {
            ...initialState,
            calendarHours: [
                {
                    name: 'Argentina Variable',
                    timeFrameId: 32100,
                    employeeHours: 160,
                    contractorHours: 160,
                    calendarId: 'ARG-VARIABLE'
                },
                {
                    name: 'Argentina Variable',
                    timeFrameId: 32101,
                    employeeHours: 168,
                    contractorHours: 168,
                    calendarId: 'ARG-VARIABLE'
                },
                {
                    name: 'Argentina Variable',
                    timeFrameId: 32102,
                    employeeHours: 168,
                    contractorHours: 168,
                    calendarId: 'ARG-VARIABLE'
                }
            ]
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_SELECTED_CALENDAR', () => {
        const action = {
            type: SET_SELECTED_CALENDAR,
            payload: 'ARG-VARIABLE'
        }

        const expectedState = {
            ...initialState,
            selectedRateCalendar: 'ARG-VARIABLE'
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to TOGGLE_IS_CALCULATING', () => {
        const action = {
            type: TOGGLE_IS_CALCULATING,
            payload: true
        }

        const expectedState = {
            ...initialState,
            isCalculating: true
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
})
