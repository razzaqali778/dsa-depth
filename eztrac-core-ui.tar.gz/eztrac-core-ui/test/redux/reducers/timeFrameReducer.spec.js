import {
    SET_CALENDAR_MODAL_BOOL,
    SET_END_TIME_FRAME,
    SET_SELECTED_TIME_FRAME_ID,
    SET_START_END_SELECTOR,
    SET_START_TIME_FRAME,
    SET_TIME_FRAMES
} from '../../../src/client/redux/constants/timeFramesConstants'

import reducer from '../../../src/client/redux/reducers/timeFrameReducer'

const initialState = {
    timeFrames: [],
    selectedTimeFrameId: '',
    startTimeFrame: {},
    endTimeFrame: {},
    calendarModalBool: false,
    copyCalendarModalBool: false,
    startEndSelector: true,
    saveLockedTimeFrameData: {
        showWarning: false
    }
}

describe('time frame reducer', () => {
    it('exports correct initial state', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })
    it('responds correctly to SET_SELECTED_TIME_FRAME_ID', () => {
        const action = {
            type: SET_SELECTED_TIME_FRAME_ID,
            payload: 41904
        }
        const expectedState = {
            ...initialState,
            selectedTimeFrameId: 41904
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_TIME_FRAMES', () => {
        const action = {
            type: SET_TIME_FRAMES,
            payload: [{name: 'timeframe1'}, {name: 'timeframe2'}]
        }
        const expectedState = {
            ...initialState,
            timeFrames: [{name: 'timeframe1'}, {name: 'timeframe2'}]
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })

    it('responds correctly to SET_START_TIMEFRAME with valid value', () => {
        const action = {
            type: SET_START_TIME_FRAME,
            payload: {name: 'timeframe1'}
        }
        const expectedState = {
            ...initialState,
            startTimeFrame: {name: 'timeframe1'}
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_START_TIMEFRAME with invalid value', () => {
        const action = {
            type: SET_START_TIME_FRAME,
            payload: undefined
        }
        const expectedState = {
            ...initialState,
            startTimeFrame: {value: '', label: ''}
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_END_TIMEFRAME with valid value', () => {
        const action = {
            type: SET_END_TIME_FRAME,
            payload: {name: 'timeframe1'}
        }
        const expectedState = {
            ...initialState,
            endTimeFrame: {name: 'timeframe1'}
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_END_TIMEFRAME with invalid value', () => {
        const action = {
            type: SET_END_TIME_FRAME,
            payload: undefined
        }
        const expectedState = {
            ...initialState,
            endTimeFrame: {value: '', label: ''}
        }
        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_CALENDAR_MODAL_BOOL', () => {
        const action = {
            type: SET_CALENDAR_MODAL_BOOL,
            payload: true
        }
        const expectedState = {
            ...initialState,
            calendarModalBool: true
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
    it('responds correctly to SET_START_END_SELECTOR', () => {
        const action = {
            type: SET_START_END_SELECTOR,
            payload: false
        }
        const expectedState = {
            ...initialState,
            startEndSelector: false
        }

        const state = reducer(initialState, action)
        expect(state).toEqual(expectedState)
    })
})
