import {
    REMOVE_LOCATION_QUERY,
    SET_LOCATION,
    UPDATE_LOCATION_QUERY
} from '../../../src/client/redux/constants/locationConstants'

import reducer from '../../../src/client/redux/reducers/locationReducer'

const initialState = {
    pathname: '',
    query: {}
}

describe('location reducer', () => {
    it('returns initial state by default', () => {
        const state = reducer()
        expect(state).toEqual(initialState)
    })

    it('set location action', () => {
        const setLocationAction = {
            type: SET_LOCATION,
            payload: {
                pathname: 'WWRD path',
                query: {
                    teamId: 'WWRD'
                }
            }
        }

        const expectedState = {
            pathname: 'WWRD path',
            query: {
                teamId: 'WWRD'
            }
        }

        const state = reducer(initialState, setLocationAction)
        expect(state).toEqual(expectedState)
    })

    it('updates the location query', () => {
        const updateLocationQueryAction = {
            type: UPDATE_LOCATION_QUERY,
            payload: {
                teamId: '4',
                timeFrameId: '45'
            }
        }

        const expectedState = {
            pathname: '',
            query: {
                teamId: '4',
                timeFrameId: '45'
            }
        }

        const state = reducer(initialState, updateLocationQueryAction)
        expect(state).toEqual(expectedState)
    })

    it('removes the location query', () => {
        const updateLocationQueryAction = {
            type: UPDATE_LOCATION_QUERY,
            payload: {
                teamId: '4',
                timeFrameId: '45'
            }
        }

        const removeLocationQueryAction = {
            type: REMOVE_LOCATION_QUERY,
            payload: 'timeFrameId'
        }

        const expectedState = {
            pathname: '',
            query: {
                teamId: '4'
            }
        }

        const setState = reducer(initialState, updateLocationQueryAction)
        const state = reducer(setState, removeLocationQueryAction)
        expect(state).toEqual(expectedState)
    })
})
