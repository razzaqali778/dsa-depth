import {
    getEndOfCurrentFiscalYearTimeFrameId,
    getTimeFrameIdNMonthsAway,
    getUnlockedTimeFramesForRange
} from '../../../src/client/redux/utils/timeFrameUtils'

describe('time frame util', () => {
    describe('get next time frame id', () => {
        it('returns null if selected time frame is not in the list', () => {
            const selectedTimeFrameId = 99999
            const timeFrames = [
                {
                    endDate: 1517443199000,
                    id: 32104,
                    isActive: true,
                    lockdown: true,
                    name: 'Jan 2018',
                    startDate: 1514764800000
                }
            ]
            expect(getTimeFrameIdNMonthsAway(selectedTimeFrameId, timeFrames, -1)).toEqual(null)
            expect(getTimeFrameIdNMonthsAway(selectedTimeFrameId, [], -1)).toEqual(null)
            expect(getTimeFrameIdNMonthsAway(undefined, timeFrames, -1)).toEqual(null)
        })
        it('returns null if next time frame is not defined', () => {
            const selectedTimeFrameId = 32104
            const timeFrames = [
                {
                    endDate: 1517443199000,
                    id: 32104,
                    isActive: true,
                    lockdown: true,
                    name: 'Jan 2018',
                    startDate: 1514764800000
                }
            ]
            const result = getTimeFrameIdNMonthsAway(selectedTimeFrameId, timeFrames, 1)
            const expectedResult = null
            expect(result).toEqual(expectedResult)
        })
        it('returns id of next time frame', () => {
            const selectedTimeFrameId = 32104
            const timeFrames = [
                {
                    endDate: 1517443199000,
                    id: 32104,
                    isActive: true,
                    lockdown: true,
                    name: 'Jan 2018',
                    startDate: 1514764800000
                },
                {
                    endDate: 1519862399000,
                    id: 32105,
                    isActive: true,
                    lockdown: true,
                    name: 'Feb 2018',
                    startDate: 1517443200000
                }
            ]
            const result = getTimeFrameIdNMonthsAway(selectedTimeFrameId, timeFrames, 1)
            const expectedResult = 32105
            expect(result).toEqual(expectedResult)
        })
    })
    describe('get end of current fiscal year time frame id', () => {
        it('returns null if december time frame is not defined', () => {
            const selectedTimeFrameId = 32104
            const timeFrames = [
                {
                    endDate: 1517443199000,
                    id: 32104,
                    isActive: true,
                    lockdown: true,
                    name: 'Jan 2018',
                    startDate: 1514764800000
                }
            ]
            const result = getEndOfCurrentFiscalYearTimeFrameId(selectedTimeFrameId, timeFrames)
            const expectedResult = null
            expect(result).toEqual(expectedResult)
        })
        it('returns id of december for the fiscal year of the selected time frame', () => {
            const selectedTimeFrameId = 32104
            const timeFrames = [
                {
                    endDate: 1517443199000,
                    id: 32104,
                    isActive: true,
                    lockdown: true,
                    name: 'Jan 2018',
                    startDate: 1514764800000
                },
                {
                    endDate: 1546300799999,
                    id: 41812,
                    isActive: true,
                    lockdown: false,
                    name: 'Dec 2018',
                    startDate: 1543622400000
                }
            ]
            const result = getEndOfCurrentFiscalYearTimeFrameId(selectedTimeFrameId, timeFrames)
            const expectedResult = 41812
            expect(result).toEqual(expectedResult)
        })
    })
    describe('get unlocked time frames for range', () => {
        it('returns an empty array if time frames are locked down ', () => {
            const startTimeFrameId = 32104
            const endTimeFrameId = 41812
            const timeFrames = [
                {
                    endDate: 1517443199000,
                    id: 32104,
                    isActive: true,
                    lockdown: true,
                    name: 'Jan 2018',
                    startDate: 1514764800000
                },
                {
                    endDate: 1519862399000,
                    id: 32105,
                    isActive: true,
                    lockdown: true,
                    name: 'Feb 2018',
                    startDate: 1517443200000
                },
                {
                    endDate: 1522540799000,
                    id: 32106,
                    isActive: true,
                    lockdown: true,
                    name: 'Mar 2018',
                    startDate: 1519862400000
                },
                {
                    endDate: 1525132799000,
                    id: 32107,
                    isActive: true,
                    lockdown: true,
                    name: 'Apr 2018',
                    startDate: 1522540800000
                },
                {
                    endDate: 1527811199000,
                    id: 32108,
                    isActive: true,
                    lockdown: true,
                    name: 'May 2018',
                    startDate: 1525132800000
                },
                {
                    endDate: 1530403199000,
                    id: 32109,
                    isActive: true,
                    lockdown: true,
                    name: 'Jun 2018',
                    startDate: 1527811200000
                },
                {
                    endDate: 1533081599000,
                    id: 32110,
                    isActive: true,
                    lockdown: true,
                    name: 'Jul 2018',
                    startDate: 1530403200000
                },
                {
                    endDate: 1535759999000,
                    id: 32111,
                    isActive: true,
                    lockdown: true,
                    name: 'Aug 2018',
                    startDate: 1533081600000
                },
                {
                    endDate: 1538351999000,
                    id: 41809,
                    isActive: true,
                    lockdown: true,
                    name: 'Sep 2018',
                    startDate: 1535760000000
                },
                {
                    endDate: 1541030399000,
                    id: 41810,
                    isActive: true,
                    lockdown: true,
                    name: 'Oct 2018',
                    startDate: 1538352000000
                },
                {
                    endDate: 1543622399000,
                    id: 41811,
                    isActive: true,
                    lockdown: true,
                    name: 'Nov 2018',
                    startDate: 1541030400000
                },
                {
                    endDate: 1546300799999,
                    id: 41812,
                    isActive: true,
                    lockdown: true,
                    name: 'Dec 2018',
                    startDate: 1543622400000
                }
            ]
            const result = getUnlockedTimeFramesForRange(
                startTimeFrameId,
                endTimeFrameId,
                timeFrames
            )
            const expectedResult = []
            expect(result).toEqual(expectedResult)
        })
        it('returns an array of not locked timeframe from the next month until the end of the range', () => {
            const startTimeFrameId = 32104
            const endTimeFrameId = 41812
            const timeFrames = [
                {
                    endDate: 1517443199000,
                    id: 32104,
                    isActive: true,
                    lockdown: true,
                    name: 'Jan 2018',
                    startDate: 1514764800000
                },
                {
                    endDate: 1519862399000,
                    id: 32105,
                    isActive: true,
                    lockdown: true,
                    name: 'Feb 2018',
                    startDate: 1517443200000
                },
                {
                    endDate: 1522540799000,
                    id: 32106,
                    isActive: true,
                    lockdown: true,
                    name: 'Mar 2018',
                    startDate: 1519862400000
                },
                {
                    endDate: 1525132799000,
                    id: 32107,
                    isActive: true,
                    lockdown: false,
                    name: 'Apr 2018',
                    startDate: 1522540800000
                },
                {
                    endDate: 1527811199000,
                    id: 32108,
                    isActive: true,
                    lockdown: false,
                    name: 'May 2018',
                    startDate: 1525132800000
                },
                {
                    endDate: 1530403199000,
                    id: 32109,
                    isActive: true,
                    lockdown: false,
                    name: 'Jun 2018',
                    startDate: 1527811200000
                },
                {
                    endDate: 1533081599000,
                    id: 32110,
                    isActive: true,
                    lockdown: false,
                    name: 'Jul 2018',
                    startDate: 1530403200000
                },
                {
                    endDate: 1535759999000,
                    id: 32111,
                    isActive: true,
                    lockdown: false,
                    name: 'Aug 2018',
                    startDate: 1533081600000
                },
                {
                    endDate: 1538351999000,
                    id: 41809,
                    isActive: true,
                    lockdown: false,
                    name: 'Sep 2018',
                    startDate: 1535760000000
                },
                {
                    endDate: 1541030399000,
                    id: 41810,
                    isActive: true,
                    lockdown: false,
                    name: 'Oct 2018',
                    startDate: 1538352000000
                },
                {
                    endDate: 1543622399000,
                    id: 41811,
                    isActive: true,
                    lockdown: false,
                    name: 'Nov 2018',
                    startDate: 1541030400000
                },
                {
                    endDate: 1546300799999,
                    id: 41812,
                    isActive: true,
                    lockdown: false,
                    name: 'Dec 2018',
                    startDate: 1543622400000
                }
            ]
            const result = getUnlockedTimeFramesForRange(
                startTimeFrameId,
                endTimeFrameId,
                timeFrames
            )
            const expectedResult = [
                {
                    endDate: 1525132799000,
                    id: 32107,
                    isActive: true,
                    lockdown: false,
                    name: 'Apr 2018',
                    startDate: 1522540800000
                },
                {
                    endDate: 1527811199000,
                    id: 32108,
                    isActive: true,
                    lockdown: false,
                    name: 'May 2018',
                    startDate: 1525132800000
                },
                {
                    endDate: 1530403199000,
                    id: 32109,
                    isActive: true,
                    lockdown: false,
                    name: 'Jun 2018',
                    startDate: 1527811200000
                },
                {
                    endDate: 1533081599000,
                    id: 32110,
                    isActive: true,
                    lockdown: false,
                    name: 'Jul 2018',
                    startDate: 1530403200000
                },
                {
                    endDate: 1535759999000,
                    id: 32111,
                    isActive: true,
                    lockdown: false,
                    name: 'Aug 2018',
                    startDate: 1533081600000
                },
                {
                    endDate: 1538351999000,
                    id: 41809,
                    isActive: true,
                    lockdown: false,
                    name: 'Sep 2018',
                    startDate: 1535760000000
                },
                {
                    endDate: 1541030399000,
                    id: 41810,
                    isActive: true,
                    lockdown: false,
                    name: 'Oct 2018',
                    startDate: 1538352000000
                },
                {
                    endDate: 1543622399000,
                    id: 41811,
                    isActive: true,
                    lockdown: false,
                    name: 'Nov 2018',
                    startDate: 1541030400000
                },
                {
                    endDate: 1546300799999,
                    id: 41812,
                    isActive: true,
                    lockdown: false,
                    name: 'Dec 2018',
                    startDate: 1543622400000
                }
            ]
            expect(result).toEqual(expectedResult)
        })
        it('returns an array of a single time frame if start and end are the same id', () => {
            const startTimeFrameId = 32104
            const endTimeFrameId = 32104
            const timeFrames = [
                {
                    endDate: 1517443199000,
                    id: 32104,
                    isActive: true,
                    lockdown: false,
                    name: 'Jan 2018',
                    startDate: 1514764800000
                },
                {
                    endDate: 1519862399000,
                    id: 32105,
                    isActive: true,
                    lockdown: false,
                    name: 'Feb 2018',
                    startDate: 1517443200000
                },
                {
                    endDate: 1522540799000,
                    id: 32106,
                    isActive: true,
                    lockdown: false,
                    name: 'Mar 2018',
                    startDate: 1519862400000
                },
                {
                    endDate: 1525132799000,
                    id: 32107,
                    isActive: true,
                    lockdown: false,
                    name: 'Apr 2018',
                    startDate: 1522540800000
                },
                {
                    endDate: 1527811199000,
                    id: 32108,
                    isActive: true,
                    lockdown: false,
                    name: 'May 2018',
                    startDate: 1525132800000
                },
                {
                    endDate: 1530403199000,
                    id: 32109,
                    isActive: true,
                    lockdown: false,
                    name: 'Jun 2018',
                    startDate: 1527811200000
                },
                {
                    endDate: 1533081599000,
                    id: 32110,
                    isActive: true,
                    lockdown: false,
                    name: 'Jul 2018',
                    startDate: 1530403200000
                },
                {
                    endDate: 1535759999000,
                    id: 32111,
                    isActive: true,
                    lockdown: false,
                    name: 'Aug 2018',
                    startDate: 1533081600000
                },
                {
                    endDate: 1538351999000,
                    id: 41809,
                    isActive: true,
                    lockdown: false,
                    name: 'Sep 2018',
                    startDate: 1535760000000
                },
                {
                    endDate: 1541030399000,
                    id: 41810,
                    isActive: true,
                    lockdown: false,
                    name: 'Oct 2018',
                    startDate: 1538352000000
                },
                {
                    endDate: 1543622399000,
                    id: 41811,
                    isActive: true,
                    lockdown: false,
                    name: 'Nov 2018',
                    startDate: 1541030400000
                },
                {
                    endDate: 1546300799999,
                    id: 41812,
                    isActive: true,
                    lockdown: false,
                    name: 'Dec 2018',
                    startDate: 1543622400000
                }
            ]
            const result = getUnlockedTimeFramesForRange(
                startTimeFrameId,
                endTimeFrameId,
                timeFrames
            )
            const expectedResult = [
                {
                    endDate: 1517443199000,
                    id: 32104,
                    isActive: true,
                    lockdown: false,
                    name: 'Jan 2018',
                    startDate: 1514764800000
                }
            ]
            expect(result).toEqual(expectedResult)
        })
    })
})
