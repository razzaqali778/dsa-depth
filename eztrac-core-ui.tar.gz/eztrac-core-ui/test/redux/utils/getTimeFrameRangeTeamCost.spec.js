import getTimeFrameTeamCostData from '../../../src/client/redux/utils/getTimeFrameRangeTeamCost'

const teamCostData = [
    {timeFrameId: '41901', teamCost: 100},
    {timeFrameId: '41902', teamCost: 100},
    {timeFrameId: '41903', teamCost: 100},
    {timeFrameId: '41904', teamCost: 100},
    {timeFrameId: '41905', teamCost: 100},
    {timeFrameId: '41906', teamCost: 100},
    {timeFrameId: '41907', teamCost: 100},
    {timeFrameId: '41908', teamCost: 100},
    {timeFrameId: '41909', teamCost: 100},
    {timeFrameId: '41910', teamCost: 100},
    {timeFrameId: '41911', teamCost: 100},
    {timeFrameId: '41912', teamCost: 100}
]

describe('checks for time frame team cost data', () => {
    it('team cost of all timeframes', () => {
        const startTimeFrame = 41901
        const endTimeFrame = 41912

        const expected = 1200
        const result = getTimeFrameTeamCostData(startTimeFrame, endTimeFrame, teamCostData)

        expect(result).toEqual(expected)
    })

    it('team cost of some of the time frames', () => {
        const startTimeFrame = 41904
        const endTimeFrame = 41907

        const expected = 400
        const result = getTimeFrameTeamCostData(startTimeFrame, endTimeFrame, teamCostData)

        expect(result).toEqual(expected)
    })
})
