import {appendTimeFrameId, isSelected} from '../../../src/client/redux/utils/newInitiative'

const mockSelectedTimeFrameInitiatives = [
    {
        initiativeCost: 200,
        teamCost: 200,
        initiativeName: 'PD EZ-Trac',
        teamCostPct: 50,
        timeFrameId: 41902,
        timeFrameName: 'Feb 2019',
        id: '48757af0-9efe-11e7-95c2-f3e864cd7c91'
    },
    {
        initiativeCost: 300,
        teamCost: 300,
        initiativeName: 'PD EZ-Trac',
        teamCostPct: 50,
        timeFrameId: 41903,
        timeFrameName: 'Mar 2019',
        id: '48757af0-9efe-11e7-95c2-f3e864cd7c92'
    },
    {
        initiativeCost: 400,
        teamCost: 400,
        initiativeName: 'PD EZ-Trac',
        teamCostPct: 50,
        timeFrameId: 41904,
        timeFrameName: 'Apr 2019',
        id: '48757af0-9efe-11e7-95c2-f3e864cd7c93'
    },
    {
        initiativeCost: 500,
        teamCost: 500,
        initiativeName: 'PD EZ-Trac',
        teamCostPct: 50,
        timeFrameId: 41905,
        timeFrameName: 'May 2019',
        id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
    }
]
const mockSelectedTimeFrameId = 41905
const expectedInitiative = {
    teamCost: 500,
    initiativeName: 'PD EZ-Trac',
    timeFrameId: 41905,
    timeFrameName: 'May 2019',
    id: '48757af0-9efe-11e7-95c2-f3e864cd7c95'
}

describe('it tests isSelected and appendTimeFrameId', () => {
    it('it makes sure isSelected returns true', () => {
        const mockKey = {
            id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
        }

        expect(isSelected(mockKey.id, mockSelectedTimeFrameInitiatives)).toBe(true)
    })
    it('it makes sure isSelected returns false', () => {
        const mockKey = {
            id: '48757af0-9efe-11e7-95c2-f3e864cd7c97'
        }

        expect(isSelected(mockKey.id, mockSelectedTimeFrameInitiatives)).toBe(false)
    })
    it('it adds time frame data to an initiative', () => {
        const mockInitiative = {
            teamCost: 500,
            initiativeName: 'PD EZ-Trac',
            timeFrameName: 'May 2019',
            id: '48757af0-9efe-11e7-95c2-f3e864cd7c95'
        }

        expect(appendTimeFrameId(mockInitiative, mockSelectedTimeFrameId)).toEqual(
            expectedInitiative
        )
    })
})
