import checkForCostData from '../../../src/client/redux/utils/checkForCostData'

const allTimeFrames = [
    {
        endDate: 1548979199000,
        id: 41901,
        isActive: true,
        lockdown: true,
        name: 'Jan 2019',
        startDate: 1546300800000
    },
    {
        endDate: 1551398399000,
        id: 41902,
        isActive: true,
        lockdown: true,
        name: 'Feb 2019',
        startDate: 154897920000
    },
    {
        endDate: 1554076799000,
        id: 41903,
        isActive: true,
        lockdown: false,
        name: 'Mar 2019',
        startDate: 1551398400000
    },
    {
        endDate: 1556668799000,
        id: 41904,
        isActive: true,
        lockdown: false,
        name: 'Apr 2019',
        startDate: 1554076800000
    },
    {
        endDate: 1559347199000,
        id: 41905,
        isActive: true,
        lockdown: false,
        name: 'May 2019',
        startDate: 1556668800000
    },
    {
        endDate: 1561939199000,
        id: 41906,
        isActive: true,
        lockdown: false,
        name: 'Jun 2019',
        startDate: 1559347200000
    }
]

const currentMonthTimeFrame = {
    endDate: 1554076799000,
    id: 41903,
    isActive: true,
    lockdown: false,
    name: 'Mar 2019',
    startDate: 1551398400000
}

const endTimeFrame = {id: 41906}

describe('checks for cost data', () => {
    it('returns null if there is no missing data', () => {
        const mockTeamInitiative = [
            {
                initiativeCost: 200,
                teamCost: 200,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41902,
                timeFrameName: 'Feb 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 300,
                teamCost: 300,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41903,
                timeFrameName: 'Mar 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 400,
                teamCost: 400,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41904,
                timeFrameName: 'Apr 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 500,
                teamCost: 500,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41905,
                timeFrameName: 'May 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 500,
                teamCost: 500,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41906,
                timeFrameName: 'Jun 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            }
        ]

        const expected = null
        const result = checkForCostData(
            mockTeamInitiative,
            allTimeFrames,
            currentMonthTimeFrame,
            endTimeFrame
        )

        expect(result).toEqual(expected)
    })
    it('gets angry with an error message for empty cost data, 2 months or less', () => {
        const mockTeamInitiative = [
            {
                initiativeCost: 200,
                teamCost: 200,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41902,
                timeFrameName: 'Feb 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 0,
                teamCost: 0,
                name: 'PD EZ-Trac',
                teamCostPct: 0,
                timeFrameId: 41903,
                timeFrameName: 'Mar 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 400,
                teamCost: 400,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41904,
                timeFrameName: 'Apr 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 500,
                teamCost: 500,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41905,
                timeFrameName: 'May 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            }
        ]

        const expected = 'WARNING! No cost data for, Mar 2019, Jun 2019'
        const result = checkForCostData(
            mockTeamInitiative,
            allTimeFrames,
            currentMonthTimeFrame,
            endTimeFrame
        )

        expect(result).toEqual(expected)
    })

    it('gets angry with an error message for empty cost data, more than 2 months', () => {
        const mockTeamInitiative = [
            {
                initiativeCost: 200,
                teamCost: 0,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41902,
                timeFrameName: 'Feb 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 0,
                teamCost: 0,
                name: 'PD EZ-Trac',
                teamCostPct: 0,
                timeFrameId: 41903,
                timeFrameName: 'Mar 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 400,
                teamCost: 0,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41904,
                timeFrameName: 'Apr 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            },
            {
                initiativeCost: 500,
                teamCost: 0,
                name: 'PD EZ-Trac',
                teamCostPct: 50,
                timeFrameId: 41905,
                timeFrameName: 'May 2019',
                id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
            }
        ]

        const expected = 'WARNING! No cost data for:  Mar 2019,  Apr 2019'
        const result = checkForCostData(
            mockTeamInitiative,
            allTimeFrames,
            currentMonthTimeFrame,
            endTimeFrame
        )

        expect(result).toEqual(expected)
    })
})
