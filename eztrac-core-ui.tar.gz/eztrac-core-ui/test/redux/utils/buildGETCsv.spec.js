import {fail} from 'assert'
import buildGETCsv from '../../../src/client/redux/utils/buildGETCsv'

const sampleData1 = {
    initiative: {activityId: 'A00J1000024'},
    hours: 8,
    date: 1585699200000,
    team: {teamName: 'Team Awesome'},
    person: {id: 'rehigg', name: 'Higgins, Roy', manager: {id: 'GOD', name: 'The Lord Almighty'}},
    costingData: {costGroupName: 'ITCS Awesome Platform - DCT'}
}
const sampleData2 = {
    initiative: {activityId: 'A00J100005'},
    hours: 20,
    date: 1585699200000,
    team: {teamName: 'Team OK'},
    person: {id: 'bobsmith', name: 'Bob Smith', manager: {id: 'GOD', name: 'The Lord Almighty'}},
    costingData: {costGroupName: 'ITCS Awesome Platform - CNT'}
}
const partialData1 = {
    initiative: {activityId: 'A00J1000024'},
    hours: 8,
    date: 1585699200000,
    team: {teamName: 'Team Awesome'},
    person: {id: 'rehigg', name: 'Higgins, Roy'},
    costingData: {costGroupName: 'ITCS Awesome Platform - DCT'}
}

const expectedHeader = '"CWID","GET ID","Date","Hours",,"Person","Manager","Cost Group","Team"'

const delimit = (i) => (i ? `"${i}"` : '')

const buildExpectedRow = (e) =>
    `${delimit(e.user)},${delimit(e.activityId)},${delimit(e.date)},${e.hours},,${delimit(e.person)},${delimit(e.manager)},${delimit(e.costGroup)},${delimit(e.team)}`

describe('build GET CSV file from service JSON', () => {
    describe('invalid cases', () => {
        it('given an undefined returns empty array', () => {
            const result = buildGETCsv()

            expect(result).toEqual([])
        })
        it('given an empty returns empty array', () => {
            const result = buildGETCsv([])

            expect(result).toEqual([])
        })
        it('given an object return empty array', () => {
            const result = buildGETCsv({})

            expect(result).toEqual([])
        })
        it('given an random object throws an error message', () => {
            const invalidObject = {name: 'anyOld Object'}
            const expectedError = 'Expected GET export array'

            try {
                const r = buildGETCsv(invalidObject)
                fail('Expected error but got', r)
            } catch (e) {
                expect(e.message).toEqual(expectedError)
            }
        })
        it('given an array with only invalid objects throws an error', () => {
            const invalidObject = {name: 'anyOld Object'}
            const expectedError = 'Records must contain person, hours, date, and initiative'

            try {
                const r = buildGETCsv([invalidObject])
                fail('Expected error but got', r)
            } catch (e) {
                expect(e.message).toEqual(expectedError)
            }
        })
    })
    it('given simple data, converts needed data to a CSV format (with formatted dates)', () => {
        const result = buildGETCsv([sampleData1])
        const expectedDataLine = buildExpectedRow({
            user: 'rehigg',
            date: '2020.04.01',
            hours: 8,
            activityId: 'A00J1000024',
            person: 'Higgins, Roy',
            team: 'Team Awesome',
            manager: 'The Lord Almighty',
            costGroup: 'ITCS Awesome Platform - DCT'
        })
        const expected = `${expectedHeader}\n${expectedDataLine}`

        expect(result).toEqual(expected)
    })
    it('given missing data, converts available data to a CSV format (with formatted dates)', () => {
        const result = buildGETCsv([partialData1])
        const expectedDataLine = buildExpectedRow({
            user: 'rehigg',
            date: '2020.04.01',
            hours: 8,
            activityId: 'A00J1000024',
            person: 'Higgins, Roy',
            team: 'Team Awesome',
            manager: '',
            costGroup: 'ITCS Awesome Platform - DCT'
        })
        const expected = `${expectedHeader}\n${expectedDataLine}`

        expect(result).toEqual(expected)
    })
    it('given multiple lines of data, converts needed data to a CSV format', () => {
        const result = buildGETCsv([sampleData1, sampleData2])
        const expectedDataLine1 = buildExpectedRow({
            user: 'rehigg',
            date: '2020.04.01',
            hours: 8,
            activityId: 'A00J1000024',
            person: 'Higgins, Roy',
            team: 'Team Awesome',
            manager: 'The Lord Almighty',
            costGroup: 'ITCS Awesome Platform - DCT'
        })
        const expectedDataLine2 = buildExpectedRow({
            user: 'bobsmith',
            date: '2020.04.01',
            hours: 20,
            activityId: 'A00J100005',
            person: 'Bob Smith',
            team: 'Team OK',
            manager: 'The Lord Almighty',
            costGroup: 'ITCS Awesome Platform - CNT'
        })
        const expected = `${expectedHeader}\n${expectedDataLine2}\n${expectedDataLine1}`

        expect(result).toEqual(expected)
    })
    it('given an array with an invalid random object and valid objects, skips the invalid', () => {
        const result = buildGETCsv([{name: 'anyOld Object'}, sampleData1])
        const expectedDataLine = buildExpectedRow({
            user: 'rehigg',
            date: '2020.04.01',
            hours: 8,
            activityId: 'A00J1000024',
            person: 'Higgins, Roy',
            team: 'Team Awesome',
            manager: 'The Lord Almighty',
            costGroup: 'ITCS Awesome Platform - DCT'
        })
        const expected = `${expectedHeader}\n${expectedDataLine}`

        expect(result).toEqual(expected)
    })
    it('outputs empty column, given no activity Id', () => {
        const emptyActivityId = {
            initiative: {featureCode: 'A00J1000024'},
            hours: 8,
            date: 1585699200000,
            team: {teamName: 'Team Awesome'},
            person: {
                id: 'rehigg',
                name: 'Higgins, Roy',
                manager: {id: 'GOD', name: 'The Lord Almighty'}
            },
            costingData: {costGroupName: 'ITCS Awesome Platform - DCT'}
        }
        const result = buildGETCsv([emptyActivityId])
        const expectedDataLine = buildExpectedRow({
            user: 'rehigg',
            date: '2020.04.01',
            hours: 8,
            person: 'Higgins, Roy',
            team: 'Team Awesome',
            manager: 'The Lord Almighty',
            costGroup: 'ITCS Awesome Platform - DCT'
        })
        const expected = `${expectedHeader}\n${expectedDataLine}`

        expect(result).toEqual(expected)
    })
    it('converts dates to UTC', () => {
        const emptyActivityId = {
            initiative: {featureCode: 'A00J1000024'},
            hours: 8,
            date: 1585699200000,
            team: {teamName: 'Team Awesome'},
            person: {
                id: 'rehigg',
                name: 'Higgins, Roy',
                manager: {id: 'GOD', name: 'The Lord Almighty'}
            },
            costingData: {costGroupName: 'ITCS Awesome Platform - DCT'}
        }
        const result = buildGETCsv([emptyActivityId])
        const expectedDataLine = buildExpectedRow({
            user: 'rehigg',
            date: '2020.04.01',
            hours: 8,
            person: 'Higgins, Roy',
            team: 'Team Awesome',
            manager: 'The Lord Almighty',
            costGroup: 'ITCS Awesome Platform - DCT'
        })
        const expected = `${expectedHeader}\n${expectedDataLine}`

        expect(result).toEqual(expected)
    })
    it('sorts by userId then date', () => {
        const sortFirstActivity = {
            initiative: {featureCode: 'A00J1000024'},
            hours: 1,
            date: 1585699200000,
            team: {teamName: 'Team Awesome'},
            person: {
                id: 'rehigg',
                name: 'Higgins, Roy',
                manager: {id: 'GOD', name: 'The Lord Almighty'}
            },
            costingData: {costGroupName: 'ITCS Awesome Platform - DCT'}
        }
        const sortLastActivity = {
            initiative: {featureCode: 'A00J1000024'},
            hours: 4,
            date: 1585699200000,
            team: {teamName: 'Team XX'},
            person: {
                id: 'xxhigg',
                name: 'Roy X. Higgins',
                manager: {id: 'DOG', name: 'The Dog Almighty'}
            },
            costingData: {costGroupName: 'ITCS Awesome Platform - CNT'}
        }
        const sortThirdActivity = {
            initiative: {featureCode: 'A00J1000024'},
            hours: 3,
            date: 1585499200000,
            team: {teamName: 'Team XX'},
            person: {
                id: 'xxhigg',
                name: 'Roy X. Higgins',
                manager: {id: 'DOG', name: 'The Dog Almighty'}
            },
            costingData: {costGroupName: 'ITCS Awesome Platform - CNT'}
        }
        const sortSecondActivity = {
            initiative: {featureCode: 'A00J1000024'},
            hours: 2,
            date: 1585799300010,
            team: {teamName: 'Team Awesome'},
            person: {
                id: 'rehigg',
                name: 'Higgins, Roy',
                manager: {id: 'GOD', name: 'The Lord Almighty'}
            },
            costingData: {costGroupName: 'ITCS Awesome Platform - DCT'}
        }
        const result = buildGETCsv([
            sortLastActivity,
            sortFirstActivity,
            sortSecondActivity,
            sortThirdActivity
        ])
        const expectedDataLine1 = buildExpectedRow({
            user: 'rehigg',
            date: '2020.04.01',
            hours: 1,
            person: 'Higgins, Roy',
            team: 'Team Awesome',
            manager: 'The Lord Almighty',
            costGroup: 'ITCS Awesome Platform - DCT'
        })
        const expectedDataLine2 = buildExpectedRow({
            user: 'rehigg',
            date: '2020.04.02',
            hours: 2,
            person: 'Higgins, Roy',
            team: 'Team Awesome',
            manager: 'The Lord Almighty',
            costGroup: 'ITCS Awesome Platform - DCT'
        })
        const expectedDataLine3 = buildExpectedRow({
            user: 'xxhigg',
            date: '2020.03.29',
            hours: 3,
            person: 'Roy X. Higgins',
            team: 'Team XX',
            manager: 'The Dog Almighty',
            costGroup: 'ITCS Awesome Platform - CNT'
        })
        const expectedDataLine4 = buildExpectedRow({
            user: 'xxhigg',
            date: '2020.04.01',
            hours: 4,
            person: 'Roy X. Higgins',
            team: 'Team XX',
            manager: 'The Dog Almighty',
            costGroup: 'ITCS Awesome Platform - CNT'
        })
        const expected = `${expectedHeader}\n${expectedDataLine1}\n${expectedDataLine2}\n${expectedDataLine3}\n${expectedDataLine4}`

        expect(result).toEqual(expected)
    })
})
