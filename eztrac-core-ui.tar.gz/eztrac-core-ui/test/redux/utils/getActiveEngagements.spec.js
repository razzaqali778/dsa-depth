import {getActiveEngagements} from '../../../src/client/redux/utils/getActiveEngagements'

describe('gets active engagements', () => {
    it('returns the subset of the grouped engagements which are currently active', () => {
        const engagements = {
            a: [
                {
                    engagementId: 'a',
                    timeFrameId: 1,
                    timeFrameName: 'Nov 2018',
                    endDate: 1543622399000,
                    isTimeFrameActive: true,
                    startDate: 1541030400000,
                    timeFrameLockdown: true,
                    engagementName: 'engagement1',
                    isEngagementActive: true
                },
                {
                    engagementId: 'a',
                    timeFrameId: 2,
                    timeFrameName: 'Dec 2018',
                    endDate: 1546300799000,
                    isTimeFrameActive: true,
                    startDate: 1543622400000,
                    timeFrameLockdown: false,
                    engagementName: 'engagement1',
                    isEngagementActive: true
                }
            ],
            b: [
                {
                    engagementId: 'b',
                    timeFrameId: 1,
                    timeFrameName: 'Nov 2018',
                    endDate: 1543622399000,
                    isTimeFrameActive: true,
                    startDate: 1541030400000,
                    timeFrameLockdown: true,
                    engagementName: 'Monsanto',
                    isEngagementActive: true
                },
                {
                    engagementId: 'b',
                    timeFrameId: 2,
                    timeFrameName: 'Dec 2018',
                    endDate: 1546300799000,
                    isTimeFrameActive: true,
                    startDate: 1543622400000,
                    timeFrameLockdown: true,
                    engagementName: 'Monsanto',
                    isEngagementActive: true
                }
            ]
        }

        const expected = [
            [
                {
                    engagementId: 'a',
                    timeFrameId: 1,
                    timeFrameName: 'Nov 2018',
                    endDate: 1543622399000,
                    isTimeFrameActive: true,
                    startDate: 1541030400000,
                    timeFrameLockdown: true,
                    engagementName: 'engagement1',
                    isEngagementActive: true
                },
                {
                    engagementId: 'a',
                    timeFrameId: 2,
                    timeFrameName: 'Dec 2018',
                    endDate: 1546300799000,
                    isTimeFrameActive: true,
                    startDate: 1543622400000,
                    timeFrameLockdown: false,
                    engagementName: 'engagement1',
                    isEngagementActive: true
                }
            ]
        ]

        const result = getActiveEngagements(engagements)
        expect(result).toEqual(expected)
    })
})
