import {
    addCostToTimeFrameTotals,
    calculatedCostsForEngagement
} from '../../../src/client/redux/utils/calculatedCostForEngagement'

describe('calculatedCostForEngagement util', () => {
    it('returns an empty array if there are no rows', () => {
        const result = calculatedCostsForEngagement([])

        expect(result).toEqual([])
    })

    it('returns totals for one timeframe', () => {
        const calculatorRows = [
            {
                people: '2',
                hourlyRate: '30',
                timeStamp: 1
            }
        ]

        const calendar = [
            {
                name: 'US Variable',
                timeFrameId: 32100,
                employeeHours: 160,
                contractorHours: 160,
                calendarId: 'US-VARIABLE'
            }
        ]

        const result = calculatedCostsForEngagement(calculatorRows, calendar)
        const expectedResult = [
            {
                timeFrameId: 32100,
                cost: 9600
            }
        ]

        expect(result).toEqual(expectedResult)
    })

    it('returns totals for multiple timeframes', () => {
        const calculatorRows = [
            {
                people: '2',
                hourlyRate: '30',
                timeStamp: 1
            }
        ]

        const calendar = [
            {
                name: 'US Variable',
                timeFrameId: 32100,
                employeeHours: 160,
                contractorHours: 160,
                calendarId: 'US-VARIABLE'
            },
            {
                name: 'US Variable',
                timeFrameId: 32101,
                employeeHours: 168,
                contractorHours: 168,
                calendarId: 'US-VARIABLE'
            }
        ]

        const result = calculatedCostsForEngagement(calculatorRows, calendar)
        const expectedResult = [
            {
                timeFrameId: 32100,
                cost: 9600
            },
            {
                timeFrameId: 32101,
                cost: 10080
            }
        ]

        expect(result).toEqual(expectedResult)
    })

    it('returns totals for multiple rows', () => {
        const calculatorRows = [
            {
                people: '2',
                hourlyRate: '30',
                timeStamp: 1
            },
            {
                people: '4',
                hourlyRate: '40',
                timeStamp: 1
            }
        ]

        const calendar = [
            {
                name: 'US Variable',
                timeFrameId: 32100,
                employeeHours: 160,
                contractorHours: 160,
                calendarId: 'US-VARIABLE'
            }
        ]

        const result = calculatedCostsForEngagement(calculatorRows, calendar)
        const expectedResult = [
            {
                timeFrameId: 32100,
                cost: 35200
            }
        ]

        expect(result).toEqual(expectedResult)
    })

    it('returns totals for multiple rows and timeframes', () => {
        const calculatorRows = [
            {
                people: '2',
                hourlyRate: '30',
                timeStamp: 1
            },
            {
                people: '4',
                hourlyRate: '40',
                timeStamp: 1
            }
        ]

        const calendar = [
            {
                name: 'US Variable',
                timeFrameId: 32100,
                employeeHours: 160,
                contractorHours: 160,
                calendarId: 'US-VARIABLE'
            },
            {
                name: 'US Variable',
                timeFrameId: 32101,
                employeeHours: 168,
                contractorHours: 168,
                calendarId: 'US-VARIABLE'
            }
        ]

        const result = calculatedCostsForEngagement(calculatorRows, calendar)
        const expectedResult = [
            {
                timeFrameId: 32100,
                cost: 35200
            },
            {
                timeFrameId: 32101,
                cost: 36960
            }
        ]

        expect(result).toEqual(expectedResult)
    })
})

describe('addCostToTimeFrameTotals', () => {
    it('returns the table row if there is no timeframe match', () => {
        const totalTable = [
            {
                timeFrameId: 1,
                cost: 30
            },
            {
                timeFrameId: 2,
                cost: 20
            }
        ]

        const result = addCostToTimeFrameTotals(totalTable, 3, 20)
        const expectedResult = [
            {
                timeFrameId: 1,
                cost: 30
            },
            {
                timeFrameId: 2,
                cost: 20
            },
            {
                timeFrameId: 3,
                cost: 20
            }
        ]

        expect(result).toEqual(expectedResult)
    })

    it('updates cost when timeFrame exists', () => {
        const totalTable = [
            {
                timeFrameId: 1,
                cost: 30
            },
            {
                timeFrameId: 2,
                cost: 20
            }
        ]

        const result = addCostToTimeFrameTotals(totalTable, 2, 23)

        const expectedResult = [
            {
                timeFrameId: 1,
                cost: 30
            },
            {
                timeFrameId: 2,
                cost: 43
            }
        ]

        expect(result).toEqual(expectedResult)
    })
})
