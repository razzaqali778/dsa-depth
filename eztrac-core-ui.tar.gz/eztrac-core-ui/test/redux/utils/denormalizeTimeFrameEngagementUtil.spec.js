import denormalize from '../../../src/client/redux/utils/denormalizeTimeFrameEngagementUtil'

describe('denormalizes engagements && timeframes', () => {
    it('returns no data if there is nothing passed in', () => {
        const expected = denormalize([], [])

        expect(expected).toEqual([])
    })

    it('returns correct team engagement', () => {
        const teamEngagements = [
            {
                amount: 200,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT1',
                teamId: 'RISING-STAR-DEV-TEAM',
                timeFrameId: 41812
            },
            {
                amount: 100,
                amountType: 'Monthly',
                engagementId: 'MONSANTO',
                teamId: 'RISING-STAR-DEV-TEAM',
                timeFrameId: 41901
            }
        ]

        expect(denormalize(teamEngagements, [])).toEqual(teamEngagements)
    })

    it('if given team engagements and timeframe, returns denormalized team engagement', () => {
        const teamEngagements = [
            {
                amount: 200,
                amountType: 'Monthly',
                engagementId: 'ENGAGEMENT1',
                teamId: 'RISING-STAR-DEV-TEAM',
                timeFrameId: 41812
            },
            {
                amount: 100,
                amountType: 'Monthly',
                engagementId: 'MONSANTO',
                teamId: 'RISING-STAR-DEV-TEAM',
                timeFrameId: 41901
            }
        ]

        const timeFrames = [
            {
                endDate: 1412121599000,
                id: 41901,
                isActive: false,
                lockdown: true,
                name: 'Sep 2014',
                startDate: 1409529600000
            },
            {
                endDate: 1414799999000,
                id: 41812,
                isActive: false,
                lockdown: true,
                name: 'Oct 2014',
                startDate: 1412121600000
            }
        ]

        const engagementOptions = [
            {
                name: 'engagement1',
                id: 'ENGAGEMENT1',
                isActive: true,
                costGroupId: 'PE-ANALYTICS',
                modifiedBy: 'JAGOEC'
            },
            {
                name: 'Monsanto',
                id: 'MONSANTO',
                isActive: true,
                costGroupId: 'PE-ANALYTICS',
                modifiedBy: 'JAGOEC'
            }
        ]

        const result = denormalize(teamEngagements, timeFrames, engagementOptions)
        expect(result[1].startDate).toEqual(timeFrames[0].startDate)
        expect(result[0].timeFrameName).toEqual(timeFrames[1].name)
        expect(result[0].isTimeFrameActive).toEqual(timeFrames[1].isActive)
        expect(result[0].timeFrameLockdown).toEqual(timeFrames[1].lockdown)
    })
})
