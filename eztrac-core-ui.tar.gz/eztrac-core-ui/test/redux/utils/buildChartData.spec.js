import buildChartData from '../../../src/client/redux/utils/buildChartData'

const relevantTimeFrames = [
    {
        label: 'Feb 2019',
        value: 41902
    },
    {
        label: 'Mar 2019',
        value: 41903
    },
    {
        label: 'Apr 2019',
        value: 41904
    },
    {
        label: 'May 2019',
        value: 41905
    }
]

const mockTeamInitiative = [
    {
        initiativeCost: 200,
        teamCost: 200,
        initiativeName: 'PD EZ-Trac',
        teamCostPct: 50,
        timeFrameId: 41902,
        timeFrameName: 'Feb 2019',
        id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
    },
    {
        initiativeCost: 300,
        teamCost: 300,
        initiativeName: 'PD EZ-Trac',
        teamCostPct: 50,
        timeFrameId: 41903,
        timeFrameName: 'Mar 2019',
        id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
    },
    {
        initiativeCost: 400,
        teamCost: 400,
        initiativeName: 'PD EZ-Trac',
        teamCostPct: 50,
        timeFrameId: 41904,
        timeFrameName: 'Apr 2019',
        id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
    },
    {
        initiativeCost: 500,
        teamCost: 500,
        initiativeName: 'PD EZ-Trac',
        teamCostPct: 50,
        timeFrameId: 41905,
        timeFrameName: 'May 2019',
        id: '48757af0-9efe-11e7-95c2-f3e864cd7c94'
    }
]

describe('builds chart data for one initiative', () => {
    it('returns an empty array for labels if given an empty dataset', () => {
        const emptyTeamInitiatives = []
        const expected = []

        const result = buildChartData(emptyTeamInitiatives, [])
        expect(result.labels).toEqual(expected)
    })

    it('returns an array of timeframe names if given data', () => {
        const expected = ['Feb 2019', 'Mar 2019', 'Apr 2019', 'May 2019']

        const result = buildChartData(mockTeamInitiative, relevantTimeFrames)
        expect(result.labels).toEqual(expected)
    })

    it('fills in the dataset data values if the team has allocation/initiative data', () => {
        const expected = [200, 300, 400, 500]

        const result = buildChartData(mockTeamInitiative, relevantTimeFrames)
        expect(result.datasets[0].data).toEqual(expected)
    })

    it('fills in the initiative name for the label within the dataset', () => {
        const expected = 'PD EZ-Trac'

        const result = buildChartData(mockTeamInitiative, relevantTimeFrames)
        expect(result.datasets[0].label).toEqual(expected)
    })

    it('fills in the correct color based on the given index', () => {
        const expected = 'rgba(255, 57, 53, 0.5)'

        const result = buildChartData(mockTeamInitiative, relevantTimeFrames)
        expect(result.datasets[0].backgroundColor).toEqual(expected)
    })

    it('fills in all data correctly for single initiative', () => {
        const expected = {
            labels: ['Feb 2019', 'Mar 2019', 'Apr 2019', 'May 2019'],
            datasets: [
                {
                    stack: 'stack1',
                    label: 'PD EZ-Trac',
                    data: [200, 300, 400, 500],
                    backgroundColor: 'rgba(255, 57, 53, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                }
            ]
        }

        const result = buildChartData(mockTeamInitiative, relevantTimeFrames)
        expect(result).toEqual(expected)
    })
})

describe('builds chart data for multiple initiatives', () => {
    const mockTeamInitiatives = [
        ...mockTeamInitiative,
        {
            initiativeCost: 200,
            teamCost: 200,
            initiativeName: 'EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41902,
            timeFrameName: 'Feb 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        },
        {
            initiativeCost: 300,
            teamCost: 300,
            initiativeName: 'EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41903,
            timeFrameName: 'Mar 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        },
        {
            initiativeCost: 400,
            teamCost: 400,
            initiativeName: 'EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41904,
            timeFrameName: 'Apr 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        },
        {
            initiativeCost: 500,
            teamCost: 500,
            initiativeName: 'EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41905,
            timeFrameName: 'May 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        }
    ]

    it('fills in chart data for multiple initiatives', () => {
        const expected = {
            labels: ['Feb 2019', 'Mar 2019', 'Apr 2019', 'May 2019'],
            datasets: [
                {
                    stack: 'stack1',
                    label: 'PD EZ-Trac',
                    data: [200, 300, 400, 500],
                    backgroundColor: 'rgba(255, 57, 53, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                },
                {
                    stack: 'stack1',
                    label: 'EZ-Trac',
                    data: [200, 300, 400, 500],
                    backgroundColor: 'rgba(30, 136, 229, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                }
            ]
        }

        const result = buildChartData(mockTeamInitiatives, relevantTimeFrames)
        expect(result).toEqual(expected)
    })
})

describe('builds chart data for multiple initiatives with the same name', () => {
    const mockTeamInitiatives = [
        ...mockTeamInitiative,
        {
            initiativeCost: 100,
            teamCost: 100,
            initiativeName: 'PD EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41902,
            timeFrameName: 'Feb 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        },
        {
            initiativeCost: 600,
            teamCost: 600,
            initiativeName: 'PD EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41903,
            timeFrameName: 'Mar 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        },
        {
            initiativeCost: 700,
            teamCost: 700,
            initiativeName: 'PD EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41904,
            timeFrameName: 'Apr 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        },
        {
            initiativeCost: 800,
            teamCost: 800,
            initiativeName: 'PD EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41905,
            timeFrameName: 'May 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        }
    ]

    it('fills in chart data for multiple initiatives', () => {
        const expected = {
            labels: ['Feb 2019', 'Mar 2019', 'Apr 2019', 'May 2019'],
            datasets: [
                {
                    stack: 'stack1',
                    label: 'PD EZ-Trac',
                    data: [200, 300, 400, 500],
                    backgroundColor: 'rgba(255, 57, 53, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                },
                {
                    stack: 'stack1',
                    label: 'PD EZ-Trac (1)',
                    data: [100, 600, 700, 800],
                    backgroundColor: 'rgba(30, 136, 229, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                }
            ]
        }

        const result = buildChartData(mockTeamInitiatives, relevantTimeFrames)
        expect(result).toEqual(expected)
    })
})

describe('builds chart data for initiatives with missing timeframes', () => {
    const mockTeamInitiatives = [
        ...mockTeamInitiative,
        {
            initiativeCost: 400,
            teamCost: 400,
            initiativeName: 'EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41904,
            timeFrameName: 'Apr 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        },
        {
            initiativeCost: 500,
            teamCost: 500,
            initiativeName: 'EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41905,
            timeFrameName: 'May 2019',
            id: '6c71e61e-8e10-4585-a6f4-02c3e363d685'
        }
    ]

    it('builds chart data for initiatives with missing timeframes', () => {
        const expected = {
            labels: ['Feb 2019', 'Mar 2019', 'Apr 2019', 'May 2019'],
            datasets: [
                {
                    stack: 'stack1',
                    label: 'PD EZ-Trac',
                    data: [200, 300, 400, 500],
                    backgroundColor: 'rgba(255, 57, 53, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                },
                {
                    stack: 'stack1',
                    label: 'EZ-Trac',
                    data: [0, 0, 400, 500],
                    backgroundColor: 'rgba(30, 136, 229, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                }
            ]
        }

        const result = buildChartData(mockTeamInitiatives, relevantTimeFrames)
        expect(result).toEqual(expected)
    })
})

describe('builds chart data for a team with many initiatives', () => {
    const mockTeamInitiatives = [
        {
            initiativeCost: 200,
            teamCost: 200,
            initiativeName: 'PD EZ-Trac',
            teamCostPct: 50,
            timeFrameId: 41902,
            timeFrameName: 'Feb 2019',
            id: '1'
        },
        {
            initiativeCost: 300,
            teamCost: 300,
            initiativeName: 'Prod Dev',
            teamCostPct: 50,
            timeFrameId: 41903,
            timeFrameName: 'Mar 2019',
            id: '2'
        },
        {
            initiativeCost: 400,
            teamCost: 400,
            initiativeName: 'GLaDOS',
            teamCostPct: 50,
            timeFrameId: 41904,
            timeFrameName: 'Apr 2019',
            id: '3'
        },
        {
            initiativeCost: 500,
            teamCost: 500,
            initiativeName: 'Ragnarok',
            teamCostPct: 50,
            timeFrameId: 41905,
            timeFrameName: 'May 2019',
            id: '4'
        },
        {
            initiativeCost: 100,
            teamCost: 100,
            initiativeName: 'WIP',
            teamCostPct: 50,
            timeFrameId: 41902,
            timeFrameName: 'Feb 2019',
            id: '5'
        },
        {
            initiativeCost: 50,
            teamCost: 50,
            initiativeName: 'ELD',
            teamCostPct: 50,
            timeFrameId: 41903,
            timeFrameName: 'Mar 2019',
            id: '6'
        }
    ]
    it('builds chart data for initiatives for a team with 6 or more initiatives in the timeframe', () => {
        const expected = {
            labels: ['Feb 2019', 'Mar 2019', 'Apr 2019', 'May 2019'],
            datasets: [
                {
                    stack: 'stack1',
                    label: 'PD EZ-Trac',
                    data: [200, 0, 0, 0],
                    backgroundColor: 'rgba(255, 57, 53, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                },
                {
                    stack: 'stack1',
                    label: 'Prod Dev',
                    data: [0, 300, 0, 0],
                    backgroundColor: 'rgba(30, 136, 229, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                },
                {
                    stack: 'stack1',
                    label: 'GLaDOS',
                    data: [0, 0, 400, 0],
                    backgroundColor: 'rgba(67, 160, 71, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                },
                {
                    stack: 'stack1',
                    label: 'Ragnarok',
                    data: [0, 0, 0, 500],
                    backgroundColor: 'rgba(255, 216, 53, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                },
                {
                    stack: 'stack1',
                    label: 'WIP',
                    data: [100, 0, 0, 0],
                    backgroundColor: 'rgba(156, 39, 176, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                },
                {
                    stack: 'stack1',
                    label: 'Other',
                    data: [0, 50, 0, 0],
                    backgroundColor: 'rgba(255, 140, 0, 0.5)',
                    borderColor: 'rgba(0, 0, 0, .4)',
                    borderWidth: 1
                }
            ]
        }
        const result = buildChartData(mockTeamInitiatives, relevantTimeFrames)
        expect(result).toEqual(expected)
    })
})
