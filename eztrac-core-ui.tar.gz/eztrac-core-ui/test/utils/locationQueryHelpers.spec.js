import {updateQuery} from '../../src/client/utils/locationQueryHelpers'

describe('updateQuery', () => {
    describe('adding new query params to end of string', () => {
        it('works when string is empty', () => {
            const oldQuery = {}
            const newQuery = {
                some: 'stuff'
            }

            const actual = updateQuery(oldQuery, newQuery, '')
            const expected = 'some=stuff'

            expect(actual).toEqual(expected)
        })
        it('works when string is not empty', () => {
            const oldQuery = {
                some: 'stuff',
                and: 'morestuff'
            }

            const oldString = '?some=stuff&and=morestuff'

            const newQuery = {
                ...oldQuery,
                new: 'things'
            }

            const actual = updateQuery(oldQuery, newQuery, oldString)
            const expected = 'some=stuff&and=morestuff&new=things'

            expect(actual).toEqual(expected)
        })
    })
    describe('replace query param in place', () => {
        it('replaces in place in first position', () => {
            const oldQuery = {
                some: 'things',
                other: 'stuff'
            }
            const newQuery = {
                some: 'newthings',
                other: 'stuff'
            }

            const oldString = '?some=things&other=stuff'

            const actual = updateQuery(oldQuery, newQuery, oldString)
            const expected = 'some=newthings&other=stuff'

            expect(actual).toEqual(expected)
        })
        it('replaces in place in middle position', () => {
            const oldQuery = {
                some: 'things',
                other: 'stuff',
                bob: 'thorton'
            }
            const newQuery = {
                some: 'things',
                other: 'junk',
                bob: 'thorton'
            }

            const oldString = '?some=things&other=stuff&bob=thorton'

            const actual = updateQuery(oldQuery, newQuery, oldString)
            const expected = 'some=things&other=junk&bob=thorton'

            expect(actual).toEqual(expected)
        })
        it('replaces in place in last position', () => {
            const oldQuery = {
                other: 'stuff',
                some: 'things',
                bob: 'thorton'
            }
            const newQuery = {
                some: 'things',
                bob: 'billy',
                other: 'stuff'
            }

            const oldString = '?some=things&other=stuff&bob=thorton'

            const actual = updateQuery(oldQuery, newQuery, oldString)
            const expected = 'some=things&other=stuff&bob=billy'

            expect(actual).toEqual(expected)
        })
    })
    describe('removes parameters from string if missing from new', () => {
        it('removes from front', () => {
            const oldQuery = {
                other: 'stuff',
                some: 'things'
            }
            const newQuery = {
                other: 'stuff'
            }
            const oldString = '?some=things&other=stuff'

            const actual = updateQuery(oldQuery, newQuery, oldString)
            const expected = 'other=stuff'

            expect(actual).toEqual(expected)
        })
        it('removes from the middle', () => {
            const oldQuery = {
                billy: 'bob',
                some: 'things',
                other: 'stuff'
            }
            const newQuery = {
                other: 'stuff',
                some: 'things'
            }
            const oldString = '?some=things&billy=bob&other=stuff'

            const actual = updateQuery(oldQuery, newQuery, oldString)
            const expected = 'some=things&other=stuff'

            expect(actual).toEqual(expected)
        })
        it('removes from the end', () => {
            const oldQuery = {
                billy: 'bob',
                some: 'things',
                other: 'stuff'
            }
            const newQuery = {
                billy: 'bob',
                some: 'things'
            }
            const oldString = '?some=things&billy=bob&other=stuff'

            const actual = updateQuery(oldQuery, newQuery, oldString)
            const expected = 'some=things&billy=bob'

            expect(actual).toEqual(expected)
        })
    })

    it('adds, removes, and updates at once', () => {
        const oldQuery = {
            billy: 'bob',
            some: 'stuff',
            other: 'things'
        }

        const newQuery = {
            billy: 'jean',
            some: 'stuff',
            new: 'bananas'
        }

        const oldString = '?some=stuff&other=things&billy=bob'

        const actual = updateQuery(oldQuery, newQuery, oldString)
        const expected = 'some=stuff&billy=jean&new=bananas'

        expect(actual).toEqual(expected)
    })
})
