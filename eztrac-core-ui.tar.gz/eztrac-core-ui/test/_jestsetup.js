import {TextDecoder, TextEncoder} from 'util'

global.TextEncoder = TextEncoder
global.TextDecoder = TextDecoder

global.phoenix = {
    authHeader: () => {},
    serviceBindings: {
        'phoenix-home': 'phoenix-tools-np.io',
        'profile-url': 'https://profile.phoenix-tools-np.io',
        'ez-trac-vip-ui': 'https://peadmin-np.monsanto.net/ez-trac-vip',
        'ez-trac-core': 'https://ez-trac-core-services.velocity-np.ag',
        'ez-trac-costing': 'https://ez-trac-costing-services.velocity-np.ag',
        'ez-trac-vip': 'https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services'
    }
}

window.phoenix = global.phoenix
