export const testStateBuilder = (changedStateElements) => ({
    people: {
        selectedTimeFrameTeamPeople: [
            {personName: 'personName1', personId: 'PersonId1'},
            {personName: 'personName2', personId: 'PersonId2'}
        ],
        people: [
            {personId: 'PersonId1', personName: 'personName1'},
            {personId: 'PersonId2', personName: 'personName2'}
        ]
    },
    timeFrame: {
        selectedTimeFrameId: 41904
    },
    team: {
        selectedTeam: {id: 'team-id', name: 'team name'}
    },
    initiative: {
        allInitiatives: [{id: 'InitiativeID1'}]
    },
    preference: {
        sortOrderPreferences: {nameNum: 1, allocationNum: 0, costNum: 0},
        sortOrderPreferencesPeople: {
            nameNum: 1,
            numberOfPeopleNum: 0,
            costGroupNum: 0,
            participationNum: 0,
            rateNum: 0
        }
    },
    ...changedStateElements
})
