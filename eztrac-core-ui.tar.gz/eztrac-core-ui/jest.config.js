export default {
    collectCoverageFrom: [
        'src/client/redux/sagas/*.js',
        'src/client/redux/sagas/helpers/*.js',
        'src/client/redux/reducers/*.js',
        '!src/client/redux/sagas/index.js',
        '!src/client/redux/reducers/index.js'
    ],
    coverageDirectory: '.jest-coverage',
    roots: ['test/', 'src/'],
    setupFiles: ['./test/_jestsetup.js'],
    testPathIgnorePatterns: [
        '<rootDir>/node_modules/',
        '<rootDir>/src/',
        '<rootDir>/test/_jestsetup.js'
    ],
    testMatch: [
        '**/test/**/*.spec.js'
        // '**/test/**/*.spec.jsx',
    ],
    testEnvironment: 'jsdom'
}
