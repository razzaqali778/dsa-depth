import{c as Ot,T as xt,ak as Nt,h as It,r as O,R as B}from"./index-D5BZpYtt.js";import{M as St,w as kt,c as bt}from"./index-kNFmOydd.js";import{T as Lt}from"./mapToTeamSelectOptions-BabyXdrB.js";const Ee=Ot(xt,Nt,(o,r)=>It(o,e=>e.id===r));/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */var J=function(o,r){return J=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){for(var n in t)t.hasOwnProperty(n)&&(e[n]=t[n])},J(o,r)};function Rt(o,r){J(o,r);function e(){this.constructor=o}o.prototype=r===null?Object.create(r):(e.prototype=r.prototype,new e)}var Q=function(){return Q=Object.assign||function(r){for(var e,t=1,n=arguments.length;t<n;t++){e=arguments[t];for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(r[i]=e[i])}return r},Q.apply(this,arguments)};/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */var k={ANIM_CHECKED_INDETERMINATE:"mdc-checkbox--anim-checked-indeterminate",ANIM_CHECKED_UNCHECKED:"mdc-checkbox--anim-checked-unchecked",ANIM_INDETERMINATE_CHECKED:"mdc-checkbox--anim-indeterminate-checked",ANIM_INDETERMINATE_UNCHECKED:"mdc-checkbox--anim-indeterminate-unchecked",ANIM_UNCHECKED_CHECKED:"mdc-checkbox--anim-unchecked-checked",ANIM_UNCHECKED_INDETERMINATE:"mdc-checkbox--anim-unchecked-indeterminate",BACKGROUND:"mdc-checkbox__background",CHECKED:"mdc-checkbox--checked",CHECKMARK:"mdc-checkbox__checkmark",CHECKMARK_PATH:"mdc-checkbox__checkmark-path",DISABLED:"mdc-checkbox--disabled",INDETERMINATE:"mdc-checkbox--indeterminate",MIXEDMARK:"mdc-checkbox__mixedmark",NATIVE_CONTROL:"mdc-checkbox__native-control",ROOT:"mdc-checkbox",SELECTED:"mdc-checkbox--selected",UPGRADED:"mdc-checkbox--upgraded"},T={ARIA_CHECKED_ATTR:"aria-checked",ARIA_CHECKED_INDETERMINATE_VALUE:"mixed",NATIVE_CONTROL_SELECTOR:".mdc-checkbox__native-control",TRANSITION_STATE_CHECKED:"checked",TRANSITION_STATE_INDETERMINATE:"indeterminate",TRANSITION_STATE_INIT:"init",TRANSITION_STATE_UNCHECKED:"unchecked"},at={ANIM_END_LATCH_MS:250};/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */var mt=(function(o){Rt(r,o);function r(e){var t=o.call(this,Q({},r.defaultAdapter,e))||this;return t.currentCheckState_=T.TRANSITION_STATE_INIT,t.currentAnimationClass_="",t.animEndLatchTimer_=0,t.enableAnimationEndHandler_=!1,t}return Object.defineProperty(r,"cssClasses",{get:function(){return k},enumerable:!0,configurable:!0}),Object.defineProperty(r,"strings",{get:function(){return T},enumerable:!0,configurable:!0}),Object.defineProperty(r,"numbers",{get:function(){return at},enumerable:!0,configurable:!0}),Object.defineProperty(r,"defaultAdapter",{get:function(){return{addClass:function(){},forceLayout:function(){},hasNativeControl:function(){return!1},isAttachedToDOM:function(){return!1},isChecked:function(){return!1},isIndeterminate:function(){return!1},removeClass:function(){},removeNativeControlAttr:function(){},setNativeControlAttr:function(){},setNativeControlDisabled:function(){}}},enumerable:!0,configurable:!0}),r.prototype.init=function(){this.currentCheckState_=this.determineCheckState_(),this.updateAriaChecked_(),this.adapter_.addClass(k.UPGRADED)},r.prototype.destroy=function(){clearTimeout(this.animEndLatchTimer_)},r.prototype.setDisabled=function(e){this.adapter_.setNativeControlDisabled(e),e?this.adapter_.addClass(k.DISABLED):this.adapter_.removeClass(k.DISABLED)},r.prototype.handleAnimationEnd=function(){var e=this;this.enableAnimationEndHandler_&&(clearTimeout(this.animEndLatchTimer_),this.animEndLatchTimer_=setTimeout(function(){e.adapter_.removeClass(e.currentAnimationClass_),e.enableAnimationEndHandler_=!1},at.ANIM_END_LATCH_MS))},r.prototype.handleChange=function(){this.transitionCheckState_()},r.prototype.transitionCheckState_=function(){if(this.adapter_.hasNativeControl()){var e=this.currentCheckState_,t=this.determineCheckState_();if(e!==t){this.updateAriaChecked_();var n=T.TRANSITION_STATE_UNCHECKED,i=k.SELECTED;t===n?this.adapter_.removeClass(i):this.adapter_.addClass(i),this.currentAnimationClass_.length>0&&(clearTimeout(this.animEndLatchTimer_),this.adapter_.forceLayout(),this.adapter_.removeClass(this.currentAnimationClass_)),this.currentAnimationClass_=this.getTransitionAnimationClass_(e,t),this.currentCheckState_=t,this.adapter_.isAttachedToDOM()&&this.currentAnimationClass_.length>0&&(this.adapter_.addClass(this.currentAnimationClass_),this.enableAnimationEndHandler_=!0)}}},r.prototype.determineCheckState_=function(){var e=T.TRANSITION_STATE_INDETERMINATE,t=T.TRANSITION_STATE_CHECKED,n=T.TRANSITION_STATE_UNCHECKED;return this.adapter_.isIndeterminate()?e:this.adapter_.isChecked()?t:n},r.prototype.getTransitionAnimationClass_=function(e,t){var n=T.TRANSITION_STATE_INIT,i=T.TRANSITION_STATE_CHECKED,a=T.TRANSITION_STATE_UNCHECKED,s=r.cssClasses,l=s.ANIM_UNCHECKED_CHECKED,p=s.ANIM_UNCHECKED_INDETERMINATE,f=s.ANIM_CHECKED_UNCHECKED,c=s.ANIM_CHECKED_INDETERMINATE,u=s.ANIM_INDETERMINATE_CHECKED,b=s.ANIM_INDETERMINATE_UNCHECKED;switch(e){case n:return t===a?"":t===i?u:b;case a:return t===i?l:p;case i:return t===a?f:c;default:return t===i?u:b}},r.prototype.updateAriaChecked_=function(){this.adapter_.isIndeterminate()?this.adapter_.setNativeControlAttr(T.ARIA_CHECKED_ATTR,T.ARIA_CHECKED_INDETERMINATE_VALUE):this.adapter_.removeNativeControlAttr(T.ARIA_CHECKED_ATTR)},r})(St),vt=(function(){var o=function(r,e){return o=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,n){t.__proto__=n}||function(t,n){for(var i in n)n.hasOwnProperty(i)&&(t[i]=n[i])},o(r,e)};return function(r,e){o(r,e);function t(){this.constructor=r}r.prototype=e===null?Object.create(e):(t.prototype=e.prototype,new t)}})(),j=function(){return j=Object.assign||function(o){for(var r,e=1,t=arguments.length;e<t;e++){r=arguments[e];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(o[n]=r[n])}return o},j.apply(this,arguments)},Dt=function(o,r){var e={};for(var t in o)Object.prototype.hasOwnProperty.call(o,t)&&r.indexOf(t)<0&&(e[t]=o[t]);if(o!=null&&typeof Object.getOwnPropertySymbols=="function")for(var n=0,t=Object.getOwnPropertySymbols(o);n<t.length;n++)r.indexOf(t[n])<0&&Object.prototype.propertyIsEnumerable.call(o,t[n])&&(e[t[n]]=o[t[n]]);return e};mt.prototype.installPropertyChangeHooks_=function(){};var Pt=kt({surface:!1,unbounded:!0})(bt({displayName:"CheckboxRoot",classNames:function(o){return["mdc-checkbox",{"mdc-checkbox--disabled":o.disabled}]},consumeProps:["disabled"]})),Mt=bt({displayName:"CheckboxNativeControl",defaultProps:{type:"checkbox"},tag:"input",classNames:["mdc-checkbox__native-control"]}),Ht=(function(o){vt(r,o);function r(){return o!==null&&o.apply(this,arguments)||this}return r.prototype.shouldComponentUpdate=function(){return!1},r.prototype.render=function(){return O.createElement("div",{className:"mdc-checkbox__background"},O.createElement("svg",{className:"mdc-checkbox__checkmark",viewBox:"0 0 24 24"},O.createElement("path",{className:"mdc-checkbox__checkmark-path",fill:"none",stroke:"white",d:"M1.73,12.91 8.1,19.28 22.79,4.59"})),O.createElement("div",{className:"mdc-checkbox__mixedmark"}))},r.displayName="CheckboxBackground",r})(O.Component),ye=(function(o){vt(r,o);function r(e){var t=o.call(this,e)||this;return t.nativeCb=t.createElement("nativeCb"),t.root=t.createElement("root"),t.handleAnimationEnd=t.handleAnimationEnd.bind(t),t.handleOnChange=t.handleOnChange.bind(t),t}return r.prototype.sync=function(e){this.foundation&&this.foundation.handleChange(),this.nativeCb.ref&&e.indeterminate!==this.nativeCb.ref.indeterminate&&(this.nativeCb.ref.indeterminate=!!e.indeterminate)},r.prototype.getDefaultFoundation=function(){var e=this;return new mt({addClass:function(t){return e.root.addClass(t)},removeClass:function(t){return e.root.removeClass(t)},setNativeControlAttr:function(t,n){return e.nativeCb.setProp(t,n)},removeNativeControlAttr:function(t){return e.nativeCb.removeProp(t)},isIndeterminate:function(){return!!e.props.indeterminate},isChecked:function(){return e.props.checked!==void 0?!!e.props.checked:!!e.nativeCb.ref&&e.nativeCb.ref.checked},hasNativeControl:function(){return!!e.nativeCb.ref},setNativeControlDisabled:function(t){return e.nativeCb.setProp("disabled",t)},forceLayout:function(){return e.root.ref&&e.root.ref.offsetWidth},isAttachedToDOM:function(){return!0}})},r.prototype.handleAnimationEnd=function(e){this.props.onAnimationEnd&&this.props.onAnimationEnd(e),this.foundation&&this.foundation.handleAnimationEnd()},r.prototype.handleOnChange=function(e){this.props.onChange&&this.props.onChange(e),this.sync(this.props)},r.prototype.render=function(){var e=this,t=this.props;t.children,t.className,t.label,t.style,t.indeterminate;var n=t.inputRef,i=Dt(t,["children","className","label","style","indeterminate","inputRef"]),a=O.createElement(Pt,j({},this.toggleRootProps,{ref:this.root.setRef,onAnimationEnd:this.handleAnimationEnd}),O.createElement(Mt,j({},this.nativeCb.props(i),{ref:function(s){e.nativeCb.setRef(s),typeof n=="function"?n&&n(s):typeof n=="object"&&(n.current=s)},id:this.id,onChange:this.handleOnChange})),O.createElement(Ht,null));return this.renderToggle(a)},r.displayName="Checkbox",r})(Lt);function Bt(o){if(!(typeof window>"u")){var r=document.createElement("style");return r.setAttribute("type","text/css"),r.innerHTML=o,document.head.appendChild(r),o}}function jt(o,r){if(!(o instanceof r))throw new TypeError("Cannot call a class as a function")}function st(o,r){for(var e=0;e<r.length;e++){var t=r[e];t.enumerable=t.enumerable||!1,t.configurable=!0,"value"in t&&(t.writable=!0),Object.defineProperty(o,t.key,t)}}function Kt(o,r,e){return r&&st(o.prototype,r),e&&st(o,e),o}function I(o,r,e){return r in o?Object.defineProperty(o,r,{value:e,enumerable:!0,configurable:!0,writable:!0}):o[r]=e,o}function K(){return K=Object.assign||function(o){for(var r=1;r<arguments.length;r++){var e=arguments[r];for(var t in e)Object.prototype.hasOwnProperty.call(e,t)&&(o[t]=e[t])}return o},K.apply(this,arguments)}function lt(o,r){var e=Object.keys(o);if(Object.getOwnPropertySymbols){var t=Object.getOwnPropertySymbols(o);r&&(t=t.filter(function(n){return Object.getOwnPropertyDescriptor(o,n).enumerable})),e.push.apply(e,t)}return e}function Ut(o){for(var r=1;r<arguments.length;r++){var e=arguments[r]!=null?arguments[r]:{};r%2?lt(Object(e),!0).forEach(function(t){I(o,t,e[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(o,Object.getOwnPropertyDescriptors(e)):lt(Object(e)).forEach(function(t){Object.defineProperty(o,t,Object.getOwnPropertyDescriptor(e,t))})}return o}function Ft(o,r){if(typeof r!="function"&&r!==null)throw new TypeError("Super expression must either be null or a function");o.prototype=Object.create(r&&r.prototype,{constructor:{value:o,writable:!0,configurable:!0}}),r&&tt(o,r)}function Z(o){return Z=Object.setPrototypeOf?Object.getPrototypeOf:function(e){return e.__proto__||Object.getPrototypeOf(e)},Z(o)}function tt(o,r){return tt=Object.setPrototypeOf||function(t,n){return t.__proto__=n,t},tt(o,r)}function $t(o){if(o===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return o}function zt(o,r){return r&&(typeof r=="object"||typeof r=="function")?r:$t(o)}function Gt(o,r){return r={exports:{}},o(r,r.exports),r.exports}function U(o){return function(){return o}}var N=function(){};N.thatReturns=U;N.thatReturnsFalse=U(!1);N.thatReturnsTrue=U(!0);N.thatReturnsNull=U(null);N.thatReturnsThis=function(){return this};N.thatReturnsArgument=function(o){return o};var Wt=N;function Xt(o,r,e,t,n,i,a,s){if(!o){var l;if(r===void 0)l=new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");else{var p=[e,t,n,i,a,s],f=0;l=new Error(r.replace(/%s/g,function(){return p[f++]})),l.name="Invariant Violation"}throw l.framesToPop=1,l}}var Yt=Xt;/*
object-assign
(c) Sindre Sorhus
@license MIT
*/var pt=Object.getOwnPropertySymbols,Vt=Object.prototype.hasOwnProperty,qt=Object.prototype.propertyIsEnumerable;function Jt(o){if(o==null)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(o)}function Qt(){try{if(!Object.assign)return!1;var o=new String("abc");if(o[5]="de",Object.getOwnPropertyNames(o)[0]==="5")return!1;for(var r={},e=0;e<10;e++)r["_"+String.fromCharCode(e)]=e;var t=Object.getOwnPropertyNames(r).map(function(i){return r[i]});if(t.join("")!=="0123456789")return!1;var n={};return"abcdefghijklmnopqrst".split("").forEach(function(i){n[i]=i}),Object.keys(Object.assign({},n)).join("")==="abcdefghijklmnopqrst"}catch{return!1}}Qt();var Zt="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED",te=Zt,ee=function(){function o(t,n,i,a,s,l){l!==te&&Yt(!1,"Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types")}o.isRequired=o;function r(){return o}var e={array:o,bool:o,func:o,number:o,object:o,string:o,symbol:o,any:o,arrayOf:r,element:o,instanceOf:r,node:o,objectOf:r,oneOf:r,oneOfType:r,shape:r,exact:r};return e.checkPropTypes=Wt,e.PropTypes=e,e},d=Gt(function(o){o.exports=ee()}),C={GLOBAL:{HIDE:"__react_tooltip_hide_event",REBUILD:"__react_tooltip_rebuild_event",SHOW:"__react_tooltip_show_event"}},V=function(r,e){var t;typeof window.CustomEvent=="function"?t=new window.CustomEvent(r,{detail:e}):(t=document.createEvent("Event"),t.initEvent(r,!1,!0),t.detail=e),window.dispatchEvent(t)};function re(o){o.hide=function(r){V(C.GLOBAL.HIDE,{target:r})},o.rebuild=function(){V(C.GLOBAL.REBUILD)},o.show=function(r){V(C.GLOBAL.SHOW,{target:r})},o.prototype.globalRebuild=function(){this.mount&&(this.unbindListener(),this.bindListener())},o.prototype.globalShow=function(r){if(this.mount){var e={currentTarget:r.detail.target};this.showTooltip(e,!0)}},o.prototype.globalHide=function(r){if(this.mount){var e=r&&r.detail&&r.detail.target&&!0||!1;this.hideTooltip({currentTarget:e&&r.detail.target},e)}}}function oe(o){o.prototype.bindWindowEvents=function(r){window.removeEventListener(C.GLOBAL.HIDE,this.globalHide),window.addEventListener(C.GLOBAL.HIDE,this.globalHide,!1),window.removeEventListener(C.GLOBAL.REBUILD,this.globalRebuild),window.addEventListener(C.GLOBAL.REBUILD,this.globalRebuild,!1),window.removeEventListener(C.GLOBAL.SHOW,this.globalShow),window.addEventListener(C.GLOBAL.SHOW,this.globalShow,!1),r&&(window.removeEventListener("resize",this.onWindowResize),window.addEventListener("resize",this.onWindowResize,!1))},o.prototype.unbindWindowEvents=function(){window.removeEventListener(C.GLOBAL.HIDE,this.globalHide),window.removeEventListener(C.GLOBAL.REBUILD,this.globalRebuild),window.removeEventListener(C.GLOBAL.SHOW,this.globalShow),window.removeEventListener("resize",this.onWindowResize)},o.prototype.onWindowResize=function(){this.mount&&this.hideTooltip()}}var gt=function(r,e){var t=this.state.show,n=this.props.id,i=this.isCapture(e.currentTarget),a=e.currentTarget.getAttribute("currentItem");i||e.stopPropagation(),t&&a==="true"?r||this.hideTooltip(e):(e.currentTarget.setAttribute("currentItem","true"),ne(e.currentTarget,this.getTargetArray(n)),this.showTooltip(e))},ne=function(r,e){for(var t=0;t<e.length;t++)r!==e[t]?e[t].setAttribute("currentItem","false"):e[t].setAttribute("currentItem","true")},q={id:"9b69f92e-d3fe-498b-b1b4-c5e63a51b0cf",set:function(r,e,t){if(this.id in r){var n=r[this.id];n[e]=t}else Object.defineProperty(r,this.id,{configurable:!0,value:I({},e,t)})},get:function(r,e){var t=r[this.id];if(t!==void 0)return t[e]}};function ie(o){o.prototype.isCustomEvent=function(r){var e=this.state.event;return e||!!r.getAttribute("data-event")},o.prototype.customBindListener=function(r){var e=this,t=this.state,n=t.event,i=t.eventOff,a=r.getAttribute("data-event")||n,s=r.getAttribute("data-event-off")||i;a.split(" ").forEach(function(l){r.removeEventListener(l,q.get(r,l));var p=gt.bind(e,s);q.set(r,l,p),r.addEventListener(l,p,!1)}),s&&s.split(" ").forEach(function(l){r.removeEventListener(l,e.hideTooltip),r.addEventListener(l,e.hideTooltip,!1)})},o.prototype.customUnbindListener=function(r){var e=this.state,t=e.event,n=e.eventOff,i=t||r.getAttribute("data-event"),a=n||r.getAttribute("data-event-off");r.removeEventListener(i,q.get(r,t)),a&&r.removeEventListener(a,this.hideTooltip)}}function ae(o){o.prototype.isCapture=function(r){return r&&r.getAttribute("data-iscapture")==="true"||this.props.isCapture||!1}}function se(o){o.prototype.getEffect=function(r){var e=r.getAttribute("data-effect");return e||this.props.effect||"float"}}var le=function(r){var e={};for(var t in r)typeof r[t]=="function"?e[t]=r[t].bind(r):e[t]=r[t];return e},L=function(r,e,t){var n=e.respectEffect,i=n===void 0?!1:n,a=e.customEvent,s=a===void 0?!1:a,l=this.props.id,p=t.target.getAttribute("data-tip")||null,f=t.target.getAttribute("data-for")||null,c=t.target;if(!(this.isCustomEvent(c)&&!s)){var u=l==null&&f==null||f===l;if(p!=null&&(!i||this.getEffect(c)==="float")&&u){var b=le(t);b.currentTarget=c,r(b)}}},ct=function(r,e){var t={};return r.forEach(function(n){var i=n.getAttribute(e);i&&i.split(" ").forEach(function(a){return t[a]=!0})}),t},ft=function(){return document.getElementsByTagName("body")[0]};function pe(o){o.prototype.isBodyMode=function(){return!!this.props.bodyMode},o.prototype.bindBodyListener=function(r){var e=this,t=this.state,n=t.event,i=t.eventOff,a=t.possibleCustomEvents,s=t.possibleCustomEventsOff,l=ft(),p=ct(r,"data-event"),f=ct(r,"data-event-off");n!=null&&(p[n]=!0),i!=null&&(f[i]=!0),a.split(" ").forEach(function(m){return p[m]=!0}),s.split(" ").forEach(function(m){return f[m]=!0}),this.unbindBodyListener(l);var c=this.bodyModeListeners={};n==null&&(c.mouseover=L.bind(this,this.showTooltip,{}),c.mousemove=L.bind(this,this.updateTooltip,{respectEffect:!0}),c.mouseout=L.bind(this,this.hideTooltip,{}));for(var u in p)c[u]=L.bind(this,function(m){var y=m.currentTarget.getAttribute("data-event-off")||i;gt.call(e,y,m)},{customEvent:!0});for(var b in f)c[b]=L.bind(this,this.hideTooltip,{customEvent:!0});for(var v in c)l.addEventListener(v,c[v])},o.prototype.unbindBodyListener=function(r){r=r||ft();var e=this.bodyModeListeners;for(var t in e)r.removeEventListener(t,e[t])}}var ce=function(){return window.MutationObserver||window.WebKitMutationObserver||window.MozMutationObserver};function fe(o){o.prototype.bindRemovalTracker=function(){var r=this,e=ce();if(e!=null){var t=new e(function(n){for(var i=0;i<n.length;i++)for(var a=n[i],s=0;s<a.removedNodes.length;s++){var l=a.removedNodes[s];if(l===r.state.currentTarget){r.hideTooltip();return}}});t.observe(window.document,{childList:!0,subtree:!0}),this.removalTracker=t}},o.prototype.unbindRemovalTracker=function(){this.removalTracker&&(this.removalTracker.disconnect(),this.removalTracker=null)}}function dt(o,r,e,t,n,i,a){for(var s=et(e),l=s.width,p=s.height,f=et(r),c=f.width,u=f.height,b=de(o,r,i),v=b.mouseX,m=b.mouseY,y=ue(i,c,u,l,p),A=he(a),D=A.extraOffset_X,g=A.extraOffset_Y,P=window.innerWidth,_=window.innerHeight,S=_e(e),M=S.parentTop,F=S.parentLeft,H=function(h){var x=y[h].l;return v+x+D},$=function(h){var x=y[h].r;return v+x+D},rt=function(h){var x=y[h].t;return m+x+g},Et=function(h){var x=y[h].b;return m+x+g},yt=function(h){return H(h)<0},Tt=function(h){return $(h)>P},Ct=function(h){return rt(h)<0},wt=function(h){return Et(h)>_},z=function(h){return yt(h)||Tt(h)||Ct(h)||wt(h)},ot=function(h){return!z(h)},At=["top","bottom","left","right"],G=[],W=0;W<4;W++){var nt=At[W];ot(nt)&&G.push(nt)}var X=!1,Y,it=n!==t;return ot(n)&&it?(X=!0,Y=n):G.length>0&&it&&z(n)&&z(t)&&(X=!0,Y=G[0]),X?{isNewState:!0,newState:{place:Y}}:{isNewState:!1,position:{left:parseInt(H(t)-F,10),top:parseInt(rt(t)-M,10)}}}var et=function(r){var e=r.getBoundingClientRect(),t=e.height,n=e.width;return{height:parseInt(t,10),width:parseInt(n,10)}},de=function(r,e,t){var n=e.getBoundingClientRect(),i=n.top,a=n.left,s=et(e),l=s.width,p=s.height;return t==="float"?{mouseX:r.clientX,mouseY:r.clientY}:{mouseX:a+l/2,mouseY:i+p/2}},ue=function(r,e,t,n,i){var a,s,l,p,f=3,c=2,u=12;return r==="float"?(a={l:-(n/2),r:n/2,t:-(i+f+c),b:-f},l={l:-(n/2),r:n/2,t:f+u,b:i+f+c+u},p={l:-(n+f+c),r:-f,t:-(i/2),b:i/2},s={l:f,r:n+f+c,t:-(i/2),b:i/2}):r==="solid"&&(a={l:-(n/2),r:n/2,t:-(t/2+i+c),b:-(t/2)},l={l:-(n/2),r:n/2,t:t/2,b:t/2+i+c},p={l:-(n+e/2+c),r:-(e/2),t:-(i/2),b:i/2},s={l:e/2,r:n+e/2+c,t:-(i/2),b:i/2}),{top:a,bottom:l,left:p,right:s}},he=function(r){var e=0,t=0;Object.prototype.toString.apply(r)==="[object String]"&&(r=JSON.parse(r.toString().replace(/\'/g,'"')));for(var n in r)n==="top"?t-=parseInt(r[n],10):n==="bottom"?t+=parseInt(r[n],10):n==="left"?e-=parseInt(r[n],10):n==="right"&&(e+=parseInt(r[n],10));return{extraOffset_X:e,extraOffset_Y:t}},_e=function(r){for(var e=r;e&&window.getComputedStyle(e).getPropertyValue("transform")==="none";)e=e.parentElement;var t=e&&e.getBoundingClientRect().top||0,n=e&&e.getBoundingClientRect().left||0;return{parentTop:t,parentLeft:n}};function ut(o,r,e,t){if(r)return r;if(e!=null)return e;if(e===null)return null;var n=/<br\s*\/?>/;return!t||t==="false"||!n.test(o)?o:o.split(n).map(function(i,a){return B.createElement("span",{key:a,className:"multi-line"},i)})}function ht(o){var r={};return Object.keys(o).filter(function(e){return/(^aria-\w+$|^role$)/.test(e)}).forEach(function(e){r[e]=o[e]}),r}function be(o){var r=o.length;return o.hasOwnProperty?Array.prototype.slice.call(o):new Array(r).fill().map(function(e){return o[e]})}Bt(`.__react_component_tooltip {
  border-radius: 3px;
  display: inline-block;
  font-size: 13px;
  left: -999em;
  opacity: 0;
  padding: 8px 21px;
  position: fixed;
  pointer-events: none;
  transition: opacity 0.3s ease-out;
  top: -999em;
  visibility: hidden;
  z-index: 999;
}
.__react_component_tooltip.allow_hover, .__react_component_tooltip.allow_click {
  pointer-events: auto;
}
.__react_component_tooltip:before, .__react_component_tooltip:after {
  content: "";
  width: 0;
  height: 0;
  position: absolute;
}
.__react_component_tooltip.show {
  opacity: 0.9;
  margin-top: 0px;
  margin-left: 0px;
  visibility: visible;
}
.__react_component_tooltip.type-dark {
  color: #fff;
  background-color: #222;
}
.__react_component_tooltip.type-dark.place-top:after {
  border-top-color: #222;
  border-top-style: solid;
  border-top-width: 6px;
}
.__react_component_tooltip.type-dark.place-bottom:after {
  border-bottom-color: #222;
  border-bottom-style: solid;
  border-bottom-width: 6px;
}
.__react_component_tooltip.type-dark.place-left:after {
  border-left-color: #222;
  border-left-style: solid;
  border-left-width: 6px;
}
.__react_component_tooltip.type-dark.place-right:after {
  border-right-color: #222;
  border-right-style: solid;
  border-right-width: 6px;
}
.__react_component_tooltip.type-dark.border {
  border: 1px solid #fff;
}
.__react_component_tooltip.type-dark.border.place-top:before {
  border-top: 8px solid #fff;
}
.__react_component_tooltip.type-dark.border.place-bottom:before {
  border-bottom: 8px solid #fff;
}
.__react_component_tooltip.type-dark.border.place-left:before {
  border-left: 8px solid #fff;
}
.__react_component_tooltip.type-dark.border.place-right:before {
  border-right: 8px solid #fff;
}
.__react_component_tooltip.type-success {
  color: #fff;
  background-color: #8DC572;
}
.__react_component_tooltip.type-success.place-top:after {
  border-top-color: #8DC572;
  border-top-style: solid;
  border-top-width: 6px;
}
.__react_component_tooltip.type-success.place-bottom:after {
  border-bottom-color: #8DC572;
  border-bottom-style: solid;
  border-bottom-width: 6px;
}
.__react_component_tooltip.type-success.place-left:after {
  border-left-color: #8DC572;
  border-left-style: solid;
  border-left-width: 6px;
}
.__react_component_tooltip.type-success.place-right:after {
  border-right-color: #8DC572;
  border-right-style: solid;
  border-right-width: 6px;
}
.__react_component_tooltip.type-success.border {
  border: 1px solid #fff;
}
.__react_component_tooltip.type-success.border.place-top:before {
  border-top: 8px solid #fff;
}
.__react_component_tooltip.type-success.border.place-bottom:before {
  border-bottom: 8px solid #fff;
}
.__react_component_tooltip.type-success.border.place-left:before {
  border-left: 8px solid #fff;
}
.__react_component_tooltip.type-success.border.place-right:before {
  border-right: 8px solid #fff;
}
.__react_component_tooltip.type-warning {
  color: #fff;
  background-color: #F0AD4E;
}
.__react_component_tooltip.type-warning.place-top:after {
  border-top-color: #F0AD4E;
  border-top-style: solid;
  border-top-width: 6px;
}
.__react_component_tooltip.type-warning.place-bottom:after {
  border-bottom-color: #F0AD4E;
  border-bottom-style: solid;
  border-bottom-width: 6px;
}
.__react_component_tooltip.type-warning.place-left:after {
  border-left-color: #F0AD4E;
  border-left-style: solid;
  border-left-width: 6px;
}
.__react_component_tooltip.type-warning.place-right:after {
  border-right-color: #F0AD4E;
  border-right-style: solid;
  border-right-width: 6px;
}
.__react_component_tooltip.type-warning.border {
  border: 1px solid #fff;
}
.__react_component_tooltip.type-warning.border.place-top:before {
  border-top: 8px solid #fff;
}
.__react_component_tooltip.type-warning.border.place-bottom:before {
  border-bottom: 8px solid #fff;
}
.__react_component_tooltip.type-warning.border.place-left:before {
  border-left: 8px solid #fff;
}
.__react_component_tooltip.type-warning.border.place-right:before {
  border-right: 8px solid #fff;
}
.__react_component_tooltip.type-error {
  color: #fff;
  background-color: #BE6464;
}
.__react_component_tooltip.type-error.place-top:after {
  border-top-color: #BE6464;
  border-top-style: solid;
  border-top-width: 6px;
}
.__react_component_tooltip.type-error.place-bottom:after {
  border-bottom-color: #BE6464;
  border-bottom-style: solid;
  border-bottom-width: 6px;
}
.__react_component_tooltip.type-error.place-left:after {
  border-left-color: #BE6464;
  border-left-style: solid;
  border-left-width: 6px;
}
.__react_component_tooltip.type-error.place-right:after {
  border-right-color: #BE6464;
  border-right-style: solid;
  border-right-width: 6px;
}
.__react_component_tooltip.type-error.border {
  border: 1px solid #fff;
}
.__react_component_tooltip.type-error.border.place-top:before {
  border-top: 8px solid #fff;
}
.__react_component_tooltip.type-error.border.place-bottom:before {
  border-bottom: 8px solid #fff;
}
.__react_component_tooltip.type-error.border.place-left:before {
  border-left: 8px solid #fff;
}
.__react_component_tooltip.type-error.border.place-right:before {
  border-right: 8px solid #fff;
}
.__react_component_tooltip.type-info {
  color: #fff;
  background-color: #337AB7;
}
.__react_component_tooltip.type-info.place-top:after {
  border-top-color: #337AB7;
  border-top-style: solid;
  border-top-width: 6px;
}
.__react_component_tooltip.type-info.place-bottom:after {
  border-bottom-color: #337AB7;
  border-bottom-style: solid;
  border-bottom-width: 6px;
}
.__react_component_tooltip.type-info.place-left:after {
  border-left-color: #337AB7;
  border-left-style: solid;
  border-left-width: 6px;
}
.__react_component_tooltip.type-info.place-right:after {
  border-right-color: #337AB7;
  border-right-style: solid;
  border-right-width: 6px;
}
.__react_component_tooltip.type-info.border {
  border: 1px solid #fff;
}
.__react_component_tooltip.type-info.border.place-top:before {
  border-top: 8px solid #fff;
}
.__react_component_tooltip.type-info.border.place-bottom:before {
  border-bottom: 8px solid #fff;
}
.__react_component_tooltip.type-info.border.place-left:before {
  border-left: 8px solid #fff;
}
.__react_component_tooltip.type-info.border.place-right:before {
  border-right: 8px solid #fff;
}
.__react_component_tooltip.type-light {
  color: #222;
  background-color: #fff;
}
.__react_component_tooltip.type-light.place-top:after {
  border-top-color: #fff;
  border-top-style: solid;
  border-top-width: 6px;
}
.__react_component_tooltip.type-light.place-bottom:after {
  border-bottom-color: #fff;
  border-bottom-style: solid;
  border-bottom-width: 6px;
}
.__react_component_tooltip.type-light.place-left:after {
  border-left-color: #fff;
  border-left-style: solid;
  border-left-width: 6px;
}
.__react_component_tooltip.type-light.place-right:after {
  border-right-color: #fff;
  border-right-style: solid;
  border-right-width: 6px;
}
.__react_component_tooltip.type-light.border {
  border: 1px solid #222;
}
.__react_component_tooltip.type-light.border.place-top:before {
  border-top: 8px solid #222;
}
.__react_component_tooltip.type-light.border.place-bottom:before {
  border-bottom: 8px solid #222;
}
.__react_component_tooltip.type-light.border.place-left:before {
  border-left: 8px solid #222;
}
.__react_component_tooltip.type-light.border.place-right:before {
  border-right: 8px solid #222;
}
.__react_component_tooltip.place-top {
  margin-top: -10px;
}
.__react_component_tooltip.place-top:before {
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  bottom: -8px;
  left: 50%;
  margin-left: -10px;
}
.__react_component_tooltip.place-top:after {
  border-left: 8px solid transparent;
  border-right: 8px solid transparent;
  bottom: -6px;
  left: 50%;
  margin-left: -8px;
}
.__react_component_tooltip.place-bottom {
  margin-top: 10px;
}
.__react_component_tooltip.place-bottom:before {
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  top: -8px;
  left: 50%;
  margin-left: -10px;
}
.__react_component_tooltip.place-bottom:after {
  border-left: 8px solid transparent;
  border-right: 8px solid transparent;
  top: -6px;
  left: 50%;
  margin-left: -8px;
}
.__react_component_tooltip.place-left {
  margin-left: -10px;
}
.__react_component_tooltip.place-left:before {
  border-top: 6px solid transparent;
  border-bottom: 6px solid transparent;
  right: -8px;
  top: 50%;
  margin-top: -5px;
}
.__react_component_tooltip.place-left:after {
  border-top: 5px solid transparent;
  border-bottom: 5px solid transparent;
  right: -6px;
  top: 50%;
  margin-top: -4px;
}
.__react_component_tooltip.place-right {
  margin-left: 10px;
}
.__react_component_tooltip.place-right:before {
  border-top: 6px solid transparent;
  border-bottom: 6px solid transparent;
  left: -8px;
  top: 50%;
  margin-top: -5px;
}
.__react_component_tooltip.place-right:after {
  border-top: 5px solid transparent;
  border-bottom: 5px solid transparent;
  left: -6px;
  top: 50%;
  margin-top: -4px;
}
.__react_component_tooltip .multi-line {
  display: block;
  padding: 2px 0px;
  text-align: center;
}`);var E,R,_t,Te=re(E=oe(E=ie(E=ae(E=se(E=pe(E=fe(E=(_t=R=(function(o){Ft(r,o);function r(e){var t;return jt(this,r),t=zt(this,Z(r).call(this,e)),t.state={place:e.place||"top",desiredPlace:e.place||"top",type:"dark",effect:"float",show:!1,border:!1,offset:{},extraClass:"",html:!1,delayHide:0,delayShow:0,event:e.event||null,eventOff:e.eventOff||null,currentEvent:null,currentTarget:null,ariaProps:ht(e),isEmptyTip:!1,disable:!1,possibleCustomEvents:e.possibleCustomEvents||"",possibleCustomEventsOff:e.possibleCustomEventsOff||"",originTooltip:null,isMultiline:!1},t.bind(["showTooltip","updateTooltip","hideTooltip","hideTooltipOnScroll","getTooltipContent","globalRebuild","globalShow","globalHide","onWindowResize","mouseOnToolTip"]),t.mount=!0,t.delayShowLoop=null,t.delayHideLoop=null,t.delayReshow=null,t.intervalUpdateContent=null,t}return Kt(r,[{key:"bind",value:function(t){var n=this;t.forEach(function(i){n[i]=n[i].bind(n)})}},{key:"componentDidMount",value:function(){var t=this.props;t.insecure;var n=t.resizeHide;this.bindListener(),this.bindWindowEvents(n)}},{key:"componentWillUnmount",value:function(){this.mount=!1,this.clearTimer(),this.unbindListener(),this.removeScrollListener(),this.unbindWindowEvents()}},{key:"mouseOnToolTip",value:function(){var t=this.state.show;return t&&this.tooltipRef?(this.tooltipRef.matches||(this.tooltipRef.msMatchesSelector?this.tooltipRef.matches=this.tooltipRef.msMatchesSelector:this.tooltipRef.matches=this.tooltipRef.mozMatchesSelector),this.tooltipRef.matches(":hover")):!1}},{key:"getTargetArray",value:function(t){var n;if(!t)n=document.querySelectorAll("[data-tip]:not([data-for])");else{var i=t.replace(/\\/g,"\\\\").replace(/"/g,'\\"');n=document.querySelectorAll('[data-tip][data-for="'.concat(i,'"]'))}return be(n)}},{key:"bindListener",value:function(){var t=this,n=this.props,i=n.id,a=n.globalEventOff,s=n.isCapture,l=this.getTargetArray(i);l.forEach(function(p){p.getAttribute("currentItem")===null&&p.setAttribute("currentItem","false"),t.unbindBasicListener(p),t.isCustomEvent(p)&&t.customUnbindListener(p)}),this.isBodyMode()?this.bindBodyListener(l):l.forEach(function(p){var f=t.isCapture(p),c=t.getEffect(p);if(t.isCustomEvent(p)){t.customBindListener(p);return}p.addEventListener("mouseenter",t.showTooltip,f),c==="float"&&p.addEventListener("mousemove",t.updateTooltip,f),p.addEventListener("mouseleave",t.hideTooltip,f)}),a&&(window.removeEventListener(a,this.hideTooltip),window.addEventListener(a,this.hideTooltip,s)),this.bindRemovalTracker()}},{key:"unbindListener",value:function(){var t=this,n=this.props,i=n.id,a=n.globalEventOff;if(this.isBodyMode())this.unbindBodyListener();else{var s=this.getTargetArray(i);s.forEach(function(l){t.unbindBasicListener(l),t.isCustomEvent(l)&&t.customUnbindListener(l)})}a&&window.removeEventListener(a,this.hideTooltip),this.unbindRemovalTracker()}},{key:"unbindBasicListener",value:function(t){var n=this.isCapture(t);t.removeEventListener("mouseenter",this.showTooltip,n),t.removeEventListener("mousemove",this.updateTooltip,n),t.removeEventListener("mouseleave",this.hideTooltip,n)}},{key:"getTooltipContent",value:function(){var t=this.props,n=t.getContent,i=t.children,a;return n&&(Array.isArray(n)?a=n[0]&&n[0](this.state.originTooltip):a=n(this.state.originTooltip)),ut(this.state.originTooltip,i,a,this.state.isMultiline)}},{key:"isEmptyTip",value:function(t){return typeof t=="string"&&t===""||t===null}},{key:"showTooltip",value:function(t,n){if(n){var i=this.getTargetArray(this.props.id),a=i.some(function(M){return M===t.currentTarget});if(!a)return}var s=this.props,l=s.multiline,p=s.getContent,f=t.currentTarget.getAttribute("data-tip"),c=t.currentTarget.getAttribute("data-multiline")||l||!1,u=t instanceof window.FocusEvent||n,b=!0;t.currentTarget.getAttribute("data-scroll-hide")?b=t.currentTarget.getAttribute("data-scroll-hide")==="true":this.props.scrollHide!=null&&(b=this.props.scrollHide);var v=t.currentTarget.getAttribute("data-place")||this.props.place||"top",m=u&&"solid"||this.getEffect(t.currentTarget),y=t.currentTarget.getAttribute("data-offset")||this.props.offset||{},A=dt(t,t.currentTarget,this.tooltipRef,v,v,m,y);A.position&&this.props.overridePosition&&(A.position=this.props.overridePosition(A.position,t.currentTarget,this.tooltipRef,v,v,m,y));var D=A.isNewState?A.newState.place:v;this.clearTimer();var g=t.currentTarget,P=this.state.show?g.getAttribute("data-delay-update")||this.props.delayUpdate:0,_=this,S=function(){_.setState({originTooltip:f,isMultiline:c,desiredPlace:v,place:D,type:g.getAttribute("data-type")||_.props.type||"dark",effect:m,offset:y,html:g.getAttribute("data-html")?g.getAttribute("data-html")==="true":_.props.html||!1,delayShow:g.getAttribute("data-delay-show")||_.props.delayShow||0,delayHide:g.getAttribute("data-delay-hide")||_.props.delayHide||0,delayUpdate:g.getAttribute("data-delay-update")||_.props.delayUpdate||0,border:g.getAttribute("data-border")?g.getAttribute("data-border")==="true":_.props.border||!1,extraClass:g.getAttribute("data-class")||_.props.class||_.props.className||"",disable:g.getAttribute("data-tip-disable")?g.getAttribute("data-tip-disable")==="true":_.props.disable||!1,currentTarget:g},function(){b&&_.addScrollListener(_.state.currentTarget),_.updateTooltip(t),p&&Array.isArray(p)&&(_.intervalUpdateContent=setInterval(function(){if(_.mount){var F=_.props.getContent,H=ut(f,"",F[0](),c),$=_.isEmptyTip(H);_.setState({isEmptyTip:$}),_.updatePosition()}},p[1]))})};P?this.delayReshow=setTimeout(S,P):S()}},{key:"updateTooltip",value:function(t){var n=this,i=this.state,a=i.delayShow,s=i.disable,l=this.props.afterShow,p=this.getTooltipContent(),f=parseInt(a,10),c=t.currentTarget||t.target;if(!this.mouseOnToolTip()&&!(this.isEmptyTip(p)||s)){var u=function(){if(Array.isArray(p)&&p.length>0||p){var v=!n.state.show;n.setState({currentEvent:t,currentTarget:c,show:!0},function(){n.updatePosition(),v&&l&&l(t)})}};clearTimeout(this.delayShowLoop),a?this.delayShowLoop=setTimeout(u,f):u()}}},{key:"listenForTooltipExit",value:function(){var t=this.state.show;t&&this.tooltipRef&&this.tooltipRef.addEventListener("mouseleave",this.hideTooltip)}},{key:"removeListenerForTooltipExit",value:function(){var t=this.state.show;t&&this.tooltipRef&&this.tooltipRef.removeEventListener("mouseleave",this.hideTooltip)}},{key:"hideTooltip",value:function(t,n){var i=this,a=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{isScroll:!1},s=this.state.disable,l=a.isScroll,p=l?0:this.state.delayHide,f=this.props.afterHide,c=this.getTooltipContent();if(this.mount&&!(this.isEmptyTip(c)||s)){if(n){var u=this.getTargetArray(this.props.id),b=u.some(function(m){return m===t.currentTarget});if(!b||!this.state.show)return}var v=function(){var y=i.state.show;if(i.mouseOnToolTip()){i.listenForTooltipExit();return}i.removeListenerForTooltipExit(),i.setState({show:!1},function(){i.removeScrollListener(),y&&f&&f(t)})};this.clearTimer(),p?this.delayHideLoop=setTimeout(v,parseInt(p,10)):v()}}},{key:"hideTooltipOnScroll",value:function(t,n){this.hideTooltip(t,n,{isScroll:!0})}},{key:"addScrollListener",value:function(t){var n=this.isCapture(t);window.addEventListener("scroll",this.hideTooltipOnScroll,n)}},{key:"removeScrollListener",value:function(){window.removeEventListener("scroll",this.hideTooltipOnScroll)}},{key:"updatePosition",value:function(){var t=this,n=this.state,i=n.currentEvent,a=n.currentTarget,s=n.place,l=n.desiredPlace,p=n.effect,f=n.offset,c=this.tooltipRef,u=dt(i,a,c,s,l,p,f);if(u.position&&this.props.overridePosition&&(u.position=this.props.overridePosition(u.position,i,a,c,s,l,p,f)),u.isNewState)return this.setState(u.newState,function(){t.updatePosition()});c.style.left=u.position.left+"px",c.style.top=u.position.top+"px"}},{key:"clearTimer",value:function(){clearTimeout(this.delayShowLoop),clearTimeout(this.delayHideLoop),clearTimeout(this.delayReshow),clearInterval(this.intervalUpdateContent)}},{key:"render",value:function(){var t=this,n=this.state,i=n.extraClass,a=n.html,s=n.ariaProps,l=n.disable,p=this.getTooltipContent(),f=this.isEmptyTip(p),c="__react_component_tooltip"+(this.state.show&&!l&&!f?" show":"")+(this.state.border?" border":"")+" place-".concat(this.state.place)+" type-".concat(this.state.type)+(this.props.delayUpdate?" allow_hover":"")+(this.props.clickable?" allow_click":""),u=this.props.wrapper;r.supportedWrappers.indexOf(u)<0&&(u=r.defaultProps.wrapper);var b=[c,i].filter(Boolean).join(" ");return a?B.createElement(u,K({className:b,id:this.props.id,ref:function(m){return t.tooltipRef=m}},s,{"data-id":"tooltip",dangerouslySetInnerHTML:{__html:p}})):B.createElement(u,K({className:b,id:this.props.id},s,{ref:function(m){return t.tooltipRef=m},"data-id":"tooltip"}),p)}}],[{key:"getDerivedStateFromProps",value:function(t,n){var i=n.ariaProps,a=ht(t),s=Object.keys(a).some(function(l){return a[l]!==i[l]});return s?Ut({},n,{ariaProps:a}):null}}]),r})(B.Component),I(R,"propTypes",{children:d.any,place:d.string,type:d.string,effect:d.string,offset:d.object,multiline:d.bool,border:d.bool,insecure:d.bool,class:d.string,className:d.string,id:d.string,html:d.bool,delayHide:d.number,delayUpdate:d.number,delayShow:d.number,event:d.string,eventOff:d.string,watchWindow:d.bool,isCapture:d.bool,globalEventOff:d.string,getContent:d.any,afterShow:d.func,afterHide:d.func,overridePosition:d.func,disable:d.bool,scrollHide:d.bool,resizeHide:d.bool,wrapper:d.string,bodyMode:d.bool,possibleCustomEvents:d.string,possibleCustomEventsOff:d.string,clickable:d.bool}),I(R,"defaultProps",{insecure:!0,resizeHide:!0,wrapper:"div",clickable:!1}),I(R,"supportedWrappers",["div","span"]),I(R,"displayName","ReactTooltip"),_t))||E)||E)||E)||E)||E)||E)||E;export{ye as C,Te as R,Ee as g};
