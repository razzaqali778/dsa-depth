import{r as u,c as b,a as O,B as y,v as P,h as j}from"./index-D5BZpYtt.js";import{c,M as F,F as h}from"./index-kNFmOydd.js";var I=function(t){var e=(Math.random()+Math.random()+1).toString(36).substring(2);return t+"-"+e},f=function(){return f=Object.assign||function(t){for(var e,n=1,r=arguments.length;n<r;n++){e=arguments[n];for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&(t[a]=e[a])}return t},f.apply(this,arguments)},x=function(t,e){var n={};for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&e.indexOf(r)<0&&(n[r]=t[r]);if(t!=null&&typeof Object.getOwnPropertySymbols=="function")for(var a=0,r=Object.getOwnPropertySymbols(t);a<r.length;a++)e.indexOf(r[a])<0&&Object.prototype.propertyIsEnumerable.call(t,r[a])&&(n[r[a]]=t[r[a]]);return n},C=c({displayName:"GridRoot",classNames:function(t){var e;return["mdc-layout-grid",(e={},e["mdc-layout-grid--align-"+(t.align||"")]=t.align!==void 0,e["mdc-layout-grid--fixed-column-width"]=t.fixedColumnWidth,e)]},consumeProps:["fixedColumnWidth","align"]}),N=function(t){var e=t.children,n=x(t,["children"]),r=e,a=!(r&&typeof r=="object"&&(r.type||{}).displayName==="GridInner");return u.createElement(C,f({},n),a?u.createElement(w,null,e):e)};N.displayName="Grid";var B=c({displayName:"GridCell",classNames:function(t){var e;return["mdc-layout-grid__cell",(e={},e["mdc-layout-grid__cell--order-"+(t.order||"")]=t.order!==void 0,e["mdc-layout-grid__cell--align-"+(t.align||"")]=t.align!==void 0,e["mdc-layout-grid__cell--span-"+(t.span||"")]=t.span!==void 0,e["mdc-layout-grid__cell--span-"+(t.phone||"")+"-phone"]=t.phone!==void 0,e["mdc-layout-grid__cell--span-"+(t.tablet||"")+"-tablet"]=t.tablet!==void 0,e["mdc-layout-grid__cell--span-"+(t.desktop||"")+"-desktop"]=t.desktop!==void 0,e)]},consumeProps:["span","phone","tablet","desktop","order","align"]}),w=c({displayName:"GridInner",classNames:["mdc-layout-grid__inner"]});/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */var p=function(t,e){return p=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(n,r){n.__proto__=r}||function(n,r){for(var a in r)r.hasOwnProperty(a)&&(n[a]=r[a])},p(t,e)};function T(t,e){p(t,e);function n(){this.constructor=t}t.prototype=e===null?Object.create(e):(n.prototype=e.prototype,new n)}var m=function(){return m=Object.assign||function(e){for(var n,r=1,a=arguments.length;r<a;r++){n=arguments[r];for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(e[o]=n[o])}return e},m.apply(this,arguments)};/**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */var E={ROOT:"mdc-form-field"},R={LABEL_SELECTOR:".mdc-form-field > label"};/**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */var S=(function(t){T(e,t);function e(n){var r=t.call(this,m({},e.defaultAdapter,n))||this;return r.clickHandler_=function(){return r.handleClick_()},r}return Object.defineProperty(e,"cssClasses",{get:function(){return E},enumerable:!0,configurable:!0}),Object.defineProperty(e,"strings",{get:function(){return R},enumerable:!0,configurable:!0}),Object.defineProperty(e,"defaultAdapter",{get:function(){return{activateInputRipple:function(){},deactivateInputRipple:function(){},deregisterInteractionHandler:function(){},registerInteractionHandler:function(){}}},enumerable:!0,configurable:!0}),e.prototype.init=function(){this.adapter_.registerInteractionHandler("click",this.clickHandler_)},e.prototype.destroy=function(){this.adapter_.deregisterInteractionHandler("click",this.clickHandler_)},e.prototype.handleClick_=function(){var n=this;this.adapter_.activateInputRipple(),requestAnimationFrame(function(){return n.adapter_.deactivateInputRipple()})},e})(F),k=(function(){var t=function(e,n){return t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(r,a){r.__proto__=a}||function(r,a){for(var o in a)a.hasOwnProperty(o)&&(r[o]=a[o])},t(e,n)};return function(e,n){t(e,n);function r(){this.constructor=e}e.prototype=n===null?Object.create(n):(r.prototype=n.prototype,new r)}})(),g=function(){return g=Object.assign||function(t){for(var e,n=1,r=arguments.length;n<r;n++){e=arguments[n];for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&(t[a]=e[a])}return t},g.apply(this,arguments)},G=c({displayName:"FormFieldRoot",defaultProps:{alignEnd:void 0},classNames:function(t){return["mdc-form-field",{"mdc-form-field--align-end":t.alignEnd}]},consumeProps:["alignEnd"]}),H=(function(t){k(e,t);function e(){return t!==null&&t.apply(this,arguments)||this}return e.prototype.getDefaultFoundation=function(){return new S({registerInteractionHandler:function(n,r){},deregisterInteractionHandler:function(n,r){},activateInputRipple:function(){},deactivateInputRipple:function(){}})},e.prototype.render=function(){return u.createElement(G,g({},this.props))},e.displayName="FormField",e})(h),A=(function(){var t=function(e,n){return t=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(r,a){r.__proto__=a}||function(r,a){for(var o in a)a.hasOwnProperty(o)&&(r[o]=a[o])},t(e,n)};return function(e,n){t(e,n);function r(){this.constructor=e}e.prototype=n===null?Object.create(n):(r.prototype=n.prototype,new r)}})(),l=function(){return l=Object.assign||function(t){for(var e,n=1,r=arguments.length;n<r;n++){e=arguments[n];for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&(t[a]=e[a])}return t},l.apply(this,arguments)},W=(function(t){A(e,t);function e(){var n=t!==null&&t.apply(this,arguments)||this;return n.generatedId=I(n.constructor.displayName),n}return Object.defineProperty(e.prototype,"hasLabel",{get:function(){return this.props.label||this.props.children},enumerable:!0,configurable:!0}),Object.defineProperty(e.prototype,"id",{get:function(){return this.props.id||this.generatedId},enumerable:!0,configurable:!0}),Object.defineProperty(e.prototype,"toggleRootProps",{get:function(){var n=this.props,r=n.className,a=n.style,o=n.disabled,i=n.rootProps,d=i===void 0?{}:i;return this.hasLabel?this.root.props({disabled:o}):l({},this.root.props(l({className:r,style:a,disabled:o},d)))},enumerable:!0,configurable:!0}),e.prototype.renderToggle=function(n){var r=this.props,a=r.className,o=r.style,i=r.rootProps,d=r.label,v=r.children;return this.hasLabel?u.createElement(H,l({},i,{className:a,style:o}),n,u.createElement("label",{id:this.id+"label",htmlFor:this.id},d,v)):n},e})(h);const z=b(O,t=>y(t,({id:e,name:n,isActive:r,communityId:a})=>({value:e,label:n,active:r,communityId:a})));var s,_;function D(){if(_)return s;_=1;function t(e){for(var n=-1,r=e==null?0:e.length,a=0,o=[];++n<r;){var i=e[n];i&&(o[a++]=i)}return o}return s=t,s}var L=D();const M=P(L),J=(t,e)=>M(y(e,r=>{const a=j(t,o=>o.value===r);if(a){const o=a.active===!1?`${a.label}  (inactive)`:a.label;return{value:a.value,label:o,active:a.active,communityId:a.communityId}}return null}));export{w as G,W as T,B as a,N as b,z as g,J as m,I as r};
