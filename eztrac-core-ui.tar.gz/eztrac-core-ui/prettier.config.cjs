module.exports = Object.assign(
    {},
    require('./node_modules/@bayerit/eslint-config-velocity/.prettierrc')
)
