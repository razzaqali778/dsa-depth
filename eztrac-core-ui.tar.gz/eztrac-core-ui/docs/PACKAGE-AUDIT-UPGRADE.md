# Package audit and upgrade (Node 22.22.3)

**Date:** 2026-06-09  
**Result:** `npm audit` → **0 vulnerabilities**  
**Validation:** lint, build, 92 test suites (356 tests) — all pass on Node `22.22.3`

---

## Summary

| Before | After |
|---|---|
| 24 vulnerabilities (1 critical, 9 high, 12 moderate, 2 low) | **0 vulnerabilities** |
| Node 20.x | Node **22.22.3** |
| Vite 5.4.x | Vite **6.4.3** |
| uuid 3.x | uuid **11.1.1** |
| lodash 4.17.21 | lodash **4.18.1** |

---

## Direct dependency upgrades and breaking changes

### `uuid` 3.3.3 → 11.1.1

| | |
|---|---|
| **Breaking change** | Default export removed; must use named imports |
| **Before** | `import uuid from 'uuid'` then `uuid()` |
| **After** | `import { v4 as uuid } from 'uuid'` then `uuid()` |
| **App impact** | One file: `InitiativeTab.jsx` (React key generation) |
| **Runtime** | Same v4 UUID strings; browser bundle unaffected |

### `lodash` 4.17.21 → 4.18.1

| | |
|---|---|
| **Breaking change** | Minor 4.x release; no API changes used by this app |
| **App usage** | Standard helpers only (`map`, `filter`, `find`, etc.) — no `_.template` |
| **Override** | `"overrides": { "lodash": "$lodash" }` forces patched version for transitive deps (`@monsantoit/phoenix-navbar`, `@bayerit/profile-client`) |

### `vite` 5.4.x → 6.4.3

| | |
|---|---|
| **Breaking change** | Vite 6 major; config in this repo unchanged (base path, port, SCSS) |
| **Security fix** | GHSA-4w7w-66w2-5vf9 path traversal in optimized deps `.map` handling |
| **Dev-only** | Vulnerability affected dev server, not production static deploy |
| **Build** | Production build succeeds; bundle size ~1.76 MB (similar to before) |

### `@vitejs/plugin-react` 4.3.x → 4.4.x

| | |
|---|---|
| **Breaking change** | None for this project |
| **Reason** | Compatibility with Vite 6 |

---

## Transitive fixes (`npm audit fix` + overrides)

Applied via `npm audit fix` (non-breaking) and `package.json` overrides:

| Package | Fix | Notes |
|---|---|---|
| `@babel/*` | Patched via audit fix | Dev/build tooling |
| `esbuild` | Override `^0.25.0` | Dev build tool; GHSA-67mh-4wv8-2f99 |
| `form-data`, `cross-spawn`, `flatted`, etc. | Patched via audit fix | Mostly dev/test transitive |
| `@bayerit/preferences-client` | 5.0.x → 5.1.2 (audit fix) | Uses superagent 8 → formidable 2 → cuid2 |

### Test fix for preferences-client upgrade

`@bayerit/preferences-client@5.1.2` pulls in `formidable@2` → `@paralleldrive/cuid2` → `@noble/hashes`, which requires `TextEncoder` at import time. Jest/jsdom did not expose it by default.

**Fix:** polyfill in `test/_jestsetup.js`:

```js
import {TextDecoder, TextEncoder} from 'util'
global.TextEncoder = TextEncoder
global.TextDecoder = TextDecoder
```

Browser runtime already has `TextEncoder`; this is test-only.

---

## Engine warnings (non-blocking)

These packages declare Node engine ranges that exclude 22.x. Build, tests, and dev server work; CI should be monitored:

| Package | Declared engines | Observed on Node 22 |
|---|---|---|
| `@monsantoit/phoenix-navbar@3.8.16` | `>18 <21` | Works; package deprecated in favour of `@bayerit/phoenix-navbar` |
| `@bayerit/phx-ocelot-auth-tools@2.0.1` | `^20.0.0` | Works (Ocelot local auth) |

---

## Validation checklist (Node 22.22.3)

```bash
nvm use 22.22.3
npm ci
npm run audit          # expect: found 0 vulnerabilities
npm run lint           # pass
npm run build      # pass
npm test           # 92 suites, 356 tests pass
npm run dev        # http://127.0.0.1:3035/ez-trac-core
```

**Via Ocelot:** http://localhost/ez-trac-core/teams

---

## Files changed

| File | Change |
|---|---|
| `package.json` | lodash, uuid, vite, plugin-react; `overrides` for lodash + esbuild |
| `package-lock.json` | Regenerated |
| `src/client/components-containers/initiatives/InitiativeTab.jsx` | uuid named import |
| `test/_jestsetup.js` | TextEncoder/TextDecoder polyfill |
| `docs/PACKAGE-AUDIT-UPGRADE.md` | This document |
