# Performance, responsiveness, and bug-fix audit (2026-07-24)

**Date:** 2026-07-24
**Result:** 13 real bugs/perf issues fixed across two passes, spanning `/teams`, `/team-maintenance`, `/platforms`, `/communities`, and `/GETExport`; 1 new regression test added; route-level code splitting added
**Validation:** `eslint`, `stylelint`, and the full Jest suite all pass — **93 suites / 360 tests passing** (92/356 before + 1 new regression test); production build (`npm run build`) succeeds

This audit was done in two passes: an initial manual pass (fixes #1–11 below), followed by a second, independent audit pass ([Audit eztrac-core-ui for bugs](57df289c-be8c-4a04-a55a-fc4a20495bf6)) that cross-checked the same codebase and surfaced 2 additional real, fixable issues (fixes #12–13) that the first pass had filed as deferred without fixing. Both passes' findings are consolidated here.

This document records a full audit of `src/client/` (containers, redux, sagas, selectors, styles) plus the fixes applied and the reasoning behind each one. Every fix below was verified against the existing lint/test/build tooling.

---

## How this was done

1. Read through every route's container tree (`components-containers/**`) and the full `redux/sagas` + `redux/selectors` layer, plus every stylesheet under `src/client/styles/`.
2. Confirmed each suspected issue by tracing the actual render/dispatch path — not just reading code in isolation — before fixing it.
3. Applied targeted fixes; re-ran `eslint`, `stylelint`, `jest`, and `vite build` after each change.
4. Added a regression test for the one bug that had zero test coverage (the redux-saga action-name typo).

---

## Fixed: performance / latency

### 1. Initiatives table was fully unmounted and remounted on almost every render

**File:** `components-containers/initiatives/InitiativeTab.jsx`

**Before:**
```jsx
<InitiativeTableContainer key={`${uuid()}`} />
```
A brand-new random UUID was generated on **every render** of `InitiativeTab`, which is a connected component re-rendered whenever initiative errors, warnings, cost data, or the selected time frame change. Because the `key` prop changed every time, React tore down and rebuilt the entire initiatives table (and everything inside it — react-select instances, refs, DOM) instead of just re-rendering it with new props. This is the kind of thing that shows up to users as flicker/jank and unnecessary work on every keystroke or save.

**Fix:** removed the key entirely. `InitiativeTable` has no local component state that depends on a forced remount (everything it renders comes from Redux via props), so a normal re-render is correct and much cheaper.

### 2. Route bundle was a single ~1.75 MB chunk regardless of which page a user visited

**File:** `components-containers/app/AppContainer.jsx`

**Before:** all five route containers (`/teams`, `/team-maintenance`, `/platforms`, `/communities`, `/GETExport`) were statically imported, so `vite build` produced one JS bundle containing the code for every route, shipped to every user on first load regardless of which page they actually needed.

**Fix:** converted each route's container to `React.lazy(() => import(...))`, wrapped in a single `<Suspense>` boundary with a lightweight fallback (reusing the existing loading-spinner markup/styles). Verified with a production build:

| Route | Before | After |
|---|---|---|
| `/platforms` | full ~1.75 MB bundle | `PlatformList` chunk: **1.7 kB** (gzip 0.87 kB) + shared chunks |
| `/communities` | full ~1.75 MB bundle | `CommunityList` chunk: **1.7 kB** (gzip 0.87 kB) + shared chunks |
| `/team-maintenance` | full ~1.75 MB bundle | `TeamMaintenanceContainer` chunk: **6.8 kB** (gzip 2.24 kB) + shared chunks |
| `/GETExport` | full ~1.75 MB bundle | `GetExportContainer` chunk: **4.2 kB** (gzip 1.76 kB) + shared chunks |
| `/teams` | full ~1.75 MB bundle | `TeamDetailsContainer` chunk: 515 kB (gzip 143 kB) — this route legitimately needs most of the feature code |

Anyone landing on `/platforms`, `/communities`, `/team-maintenance`, or `/GETExport` now downloads and parses only a few KB of route-specific code instead of the entire app, cutting time-to-interactive for those routes substantially. `/teams` (the heaviest, most commonly used route) sees a smaller but still real reduction since it no longer has to include the other four routes' code either.

### 3. Hover tooltip fetched user profile data even after the mouse had left the row

**File:** `components-containers/people/PeopleTable.jsx`

**Before:**
```jsx
let timer // plain variable, re-initialized on every render
...
onMouseEnter={() => { timer = setTimeout(() => userDetailsHoveredSaga(person), 800) }}
onMouseLeave={() => { clearTimeout(timer) }}
```
`PeopleTable` is a function component that re-renders on essentially every keystroke/state change in the team-people tab. Because `timer` was a plain local variable (not a `ref`), each render created a fresh `timer` binding; if a re-render happened between `onMouseEnter` and `onMouseLeave` (very plausible within an 800 ms window), the `onMouseLeave` handler bound after that re-render closed over a *different*, never-set `timer` and could not cancel the pending timeout. The profile-lookup saga (and the "Loading user details..." tooltip) could then fire after the user had already moved the mouse away.

**Fix:** moved the timer into a `useRef`, and added an unmount cleanup (`useEffect(() => () => clearTimeout(timerRef.current), [])`) so a pending hover timer can't fire after the table itself unmounts.

### 4. `useListenForOutsideClicks` could run a stale callback forever

**File:** `components-containers/utils/useListenForOutsideClicks.js`

**Before:** the effect's dependency array was `[ref]` only, but the hook took a `handleClickOutside` callback that both call sites (`MonthDropdown.jsx`, `DatePickerDropdown.jsx`) pass as a **new inline arrow function on every render**. Since the effect never re-subscribes (its deps don't include the callback), the very first render's closure is used for the lifetime of the component. This works out safely today only because both current callers happen to forward to stable Redux dispatch functions — but it's a latent bug for any future caller that closes over local state or props.

**Fix:** the callback is now stored in a `ref` that's updated on every render and invoked via `handleClickOutsideRef.current()` inside the (still stable, mount-once) event listener — the standard "latest ref" pattern. This removes the footgun without changing the listener's mount/unmount behavior.

### 5. Chart minimum-size floor was silently ignored (lodash `max` misuse)

**File:** `components-containers/initiatives/RenderChart.jsx`

**Before:**
```js
const chartHeight = max([Math.floor(window.innerHeight * 0.45)], 450)
const chartWidth = max([Math.floor(window.innerWidth * 0.45)], 650)
```
This looks like `Math.max(value, floor)`, but lodash's `_.max` signature is `_.max(array)` — it returns the largest element of a *single* array argument and ignores any second argument entirely. So `max([x], 450)` always just returns `x`; the intended 450 px/650 px minimum chart size never applied. On small windows the chart could render at a tiny, squished size.

**Fix:** switched to the actual `Math.max(value, floor)` and dropped the now-unnecessary lodash import.

---

## Fixed: correctness

### 6. Failed profile lookups crashed the saga instead of showing an error

**File:** `redux/sagas/fetchUserProfileDetailsSaga.js`

**Before:**
```js
if (!data) {
  yield dispatch(actions.setUserProfileDetail({status: 'ERROR'})) // no "s" — doesn't exist
}
```
Every other branch in this file (and everywhere else in the codebase) calls the plural `actions.setUserProfileDetails`. `actions.setUserProfileDetail` (singular) is not defined anywhere — calling it throws `TypeError: actions.setUserProfileDetail is not a function` **inside a `takeLatest`-driven saga**, which (depending on redux-saga's error propagation) can crash the whole saga middleware on the very first failed profile lookup, and definitely means the intended "Unable to find additional user data" error state (`PeopleTable.jsx`'s `renderPersonHoverDetails`) never actually rendered.

**Fix:** corrected to `actions.setUserProfileDetails({status: 'ERROR'})`.

**Regression test added:** `test/redux/sagas/fetchUserProfileDetailsSaga.spec.js` (new file — this saga had **0% test coverage** before, which is exactly why the typo went unnoticed). Covers all three branches (`EMPTY`, `OK`, `ERROR`) plus the listener registration.

### 7. Pressing Enter to add a person added a broken record

**File:** `components-containers/people/PeopleTable.jsx`

**Before:**
```jsx
onKeyDown={(evt) => {
    if (evt.key === 'Enter' && newPersonData.personId !== undefined) {
        addNewPerson(newPersonPicked(evt)) // evt is a KeyboardEvent here, not a react-select option
    }
}}
```
`newPersonPicked = (evt) => ({...evt.value, participationPct: 100})` is written for the `onChange` handler, where `evt` is the selected react-select option (`{value, label}`). The `onKeyDown` handler passes the native `KeyboardEvent` instead, which has no `.value`; `{...undefined}` silently spreads to nothing, so `addNewPerson` was called with just `{participationPct: 100}` — a person record with no `personId`/`personName`.

**Fix:** use the already-staged `newPersonData` (the same data the `personId !== undefined` check is validating) instead of re-deriving from the keyboard event: `addNewPerson({...newPersonData, participationPct: 100})`.

### 8. Editing an initiative's dollar cost could save `Infinity`/`NaN` as a percentage

**File:** `components-containers/initiatives/InitiativeTable.jsx`

**Before:**
```js
newInitiatives[index].teamCostPct = Math.round((Number(evt.target.value) / selectedTimeFrameTeamCost) * 100)
```
When a team's total cost for the time frame is `$0` (a normal state for a brand-new team with no people/engagements yet) and a user types a dollar amount into an initiative's cost field, this divides by zero, producing `Infinity` (or `NaN` for a `0` input), which then gets stored in component state and can be saved to the backend.

**Fix:** guarded the division — when `selectedTimeFrameTeamCost` is `0`, the percentage is set to `0` instead of computed.

### 9. Divide-by-zero-adjacent CSS/tooltip bug: "Planning" status tooltip never appeared

**Files:** `styles/containers/InitiativeContainer.scss`, `styles/containers/InitiativeContainer.css` (deleted)

**Before:** the "Funded" status cell's hover rule correctly targets `.status-tooltip` (the class actually rendered in `InitiativeTable.jsx`), but the "Planning" status cell's hover rule targeted `.initiative-table-status-tooltip` — a class that doesn't exist anywhere in the JSX. Hovering the "P" (Planning) badge silently did nothing.

There was also a second, **unimported** `InitiativeContainer.css` file sitting next to the actual `InitiativeContainer.scss` with divergent class names (e.g. `.initiative-table-status-cell-planning`), which is presumably where the mismatched class name leaked in from — someone edited the dead `.css` file at some point, not the live `.scss` one.

**Fix:** corrected the selector to `.status-tooltip` in the live `.scss` file, and deleted the dead, unimported `.css` file so it can't cause this kind of confusion again.

---

## Fixed: cosmetic / responsive

### 10. Loading overlay could overflow off both edges of the screen

**File:** `styles/components/LoadingBlockerStyles.css`

**Before:** `.block-message { width: 600px; left: 50%; margin: 25px 25px 25px -300px; }` — a fixed 600 px box centered with a matching `-300px` negative margin. This only actually fits and centers correctly at exactly 600 px; on any viewport narrower than ~650 px (phones, small tablets, split-screen windows) the box overflowed off both sides of the screen, since it couldn't shrink.

**Fix:** `width: min(600px, calc(100vw - 32px))` with `transform: translateX(-50%)` for centering — same 600 px box on normal screens, but it now shrinks to fit narrow viewports with a consistent 16px margin on each side, and stays correctly centered at any resulting width.

### 11. Engagement cards stayed at ~48% width with no small-screen breakpoint

**File:** `styles/containers/EngagementContainer.css`

**Before:** `.display-engagement-card { width: 48%; ... }` had no responsive breakpoint anywhere in the file. Combined with `.engagement-timeframe-container`'s `min-width: 200px`, two half-width cards side by side get cramped/overflow content on phone-width screens.

**Fix:** added `@media (max-width: 768px) { .display-engagement-card { width: 100%; } }` so cards stack full-width on small screens instead of squeezing two per row.

---

## Second pass: fixes from an independent cross-check audit

[Audit eztrac-core-ui for bugs](57df289c-be8c-4a04-a55a-fc4a20495bf6) re-audited the whole app and largely confirmed fixes #1–11 above, but also flagged two issues inside files already touched by fix #5 (lodash `max` misuse) and the "no debounce" deferred item, which were fixable immediately without needing a running app:

### 12. Chart data was rebuilt from scratch on every render, and an unnecessary remount key was still present

**File:** `components-containers/initiatives/RenderChart.jsx`

**Before:** `buildChartData(teamInitiatives, relevantTimeFrames)` (a group/sort operation) ran inline in the render body on every render, and `<Bar ... key={chartWidth} />` forced a full chart remount whenever the computed width changed — on top of the already-fixed `lodash.max()` bug (see fix #5), this meant the chart did unnecessary work and threw away its internal Chart.js instance more than needed.

**Fix:** wrapped `buildChartData(...)` in `useMemo` keyed on `[teamInitiatives, relevantTimeFrames]`, and removed the `key={chartWidth}` remount — `Chart.js`'s own `responsive: true` option (already set) handles resizing without a forced React remount.

### 13. `FilterBar`'s debounced search could use a stale callback and never cancelled on unmount

**File:** `components-containers/common/FilterBar.jsx`

**Before:** `useCallback(debounce(onSearchPhraseChange, 300), [])` — the empty dependency array froze the debounced function to whatever `onSearchPhraseChange` was on the *first* render, and any pending debounced call was never cancelled when the component unmounted (e.g. navigating away from `/platforms` mid-keystroke).

**Fix:** switched to `useMemo(() => debounce(onSearchPhraseChange, 300), [onSearchPhraseChange])` so the debounce is recreated if the callback identity changes, plus a `useEffect` cleanup that calls `.cancel()` on unmount.

---

## Verified but intentionally not changed (documented for a follow-up pass)

These were confirmed as real by one or both audit passes, but fixing them safely needs either a visual QA pass (this environment has no way to run/screenshot the actual app — it requires Ocelot + VPN + live backends) or a deliberate behavior-change decision, so they're recorded here rather than changed blind.

| # | Issue | File(s) | Why deferred |
|---|---|---|---|
| 1 | Copy-forward and bulk save sagas use `takeEvery`, so copying N months forward fires N concurrent `updateInitiatives`/`updatePeople` PATCH requests that can race each other | `redux/sagas/initiatives/copyInitiativesForwardSaga.js`, `updateInitiativesSaga.js`, `redux/sagas/people/updatePeopleSaga.js`, `copyPeopleForwardSaga.js` | Switching to `takeLatest`/serialized dispatch changes save semantics (a fast second copy-forward would cancel the first); needs a product decision on whether concurrent saves per time frame are ever legitimate, plus end-to-end testing against a real backend |
| 2 | Almost no responsive coverage app-wide — only 2 of ~14 stylesheets have any `@media` query | `styles/**` | A full responsive pass touches nearly every screen's layout; doing this without being able to render and screenshot the app risks shipping visually broken changes that look fine in the diff but wrong on screen. Recommend a dedicated pass with visual QA (e.g. via a running Ocelot + non-prod backend session) rather than blind CSS edits |
| 3 | Several hardcoded pixel widths that likely crowd small screens (`.select-month` 250px, `.headerDiv` 290px, `.people-link`/`.initiatives-link` 25px, etc.) | `PeopleContainer.scss`, `InitiativeContainer.scss`, `DatePickerContainer.scss`, `AppContainerStyles.css`, `TeamMaintenanceContainer.scss` | Same as #2 — needs visual verification, not blind find/replace |
| 4 | Team maintenance keeps `isEditing` state when switching the selected team while mid-edit, so Team B's form can show stale data from Team A | `redux/reducers/teamReducer.js`, `components-containers/teamMaintenance/CreateEditTeams.jsx`, `TeamMaintenance.jsx` | Real bug, but the correct fix (reset on `SET_SELECTED_TEAM`, or key the form by team id) needs to be checked against the actual edit/cancel/save flow in a running app to avoid breaking the "unsaved changes" warning modal that already exists for this component |
| 5 | Large presentational components (`PeopleTable`, `ForecastedPeopleTable`, `InitiativeTable`, `DisplayEngagementCard`, `CalculatorTable`) have no `React.memo`/`PureComponent`, so they re-render whenever an unrelated ancestor re-renders | multiple | Real perf opportunity, but memoizing a class component (`InitiativeTable`, `DisplayEngagementCard`) requires converting to `PureComponent` or adding `shouldComponentUpdate`, which is a bigger, riskier structural change than a targeted bug fix — recommended as a dedicated follow-up with render-count profiling to confirm the win |
| 6 | Engagement search box dispatches to Redux on every keystroke with no debounce (contrast with `FilterBar.jsx`'s existing 300ms debounce pattern, now fixed by #13 above) | `components-containers/engagements/engagementTab/EngagementTab.jsx` | Low risk, but changing input responsiveness needs a quick manual check that typing still feels smooth in a running app |
| 7 | `setState` called during `render()` in `DisplayEngagementCard` | `components-containers/engagements/DisplayEngagementCard.jsx` | Should move to `componentDidUpdate`; deferred because reproducing/verifying the exact condition needs the running edit-comment flow |
| 8 | `hasPeopleDataChanged`/`hasForecastedPeopleDataChanged` return `true` when data is **unchanged** (opposite of the equivalent initiatives validator's naming) | `redux/utils/validatorsForPeople.js` | Not a live bug today — every call site already inverts the result with `!` — but renaming/flipping it touches multiple call sites at once; recorded so a future change doesn't get the polarity wrong |
| 9 | Options/list computations (`peopleOptions`, `differenceBy`/`map` for initiative options, `platforms.map(mapToListItem)`) run directly in render instead of through a memoized selector/`useMemo` | `PeopleTable.jsx`, `InitiativeTable.jsx`, `PlatformList.jsx`, `CommunityList.jsx` | Real, but best done together with item #5 above as one focused "reduce re-render work" pass with before/after render-count measurements |
| 10 | Team-switch and person-switch null-guard gaps (`selectedTimeFrame.name`, `currentTimeFrame.id`, `canEditTimeFrame`/`copyForwardButtonDisabled` assuming a timeframe object always exists) | `PeopleTab.jsx`, `InitiativeTable.jsx`, `copyForwardButtonDisabled.js`, `canEditTimeFrame.js` | These only manifest during specific loading-state races that are hard to confirm without a running app; recommend adding optional chaining defensively in a follow-up along with a manual repro check |
| 11 | Weak/index-based list keys (`InitiativeTab.jsx` warning chips keyed by `${index} ${selectedTimeFrameId}`) | `components-containers/initiatives/InitiativeTab.jsx` | No stable id exists on the underlying warning/error objects today; fixing this well means adding one upstream rather than picking a different, equally-fragile derived key |
| 12 | Comment save in `DisplayEngagementCard` fires one API call per time-frame row instead of batching | `components-containers/engagements/DisplayEngagementCard.jsx` | Behavior change to the save flow; needs confirmation the backend has (or should have) a batch endpoint before changing client call patterns |

---

## Validation summary

```text
eslint --ext .js,.jsx src test    → 0 problems
stylelint (containers/components) → 0 problems
jest (full suite)                 → 93 suites / 360 tests passing (was 92/356), 3 skipped, 0 failing
vite build                        → succeeds; route chunks confirmed split (see fix #2 table above)
```

This environment has no way to run the app end-to-end (it requires Ocelot, VPN access, and live non-prod backend services), so all fixes above were validated via static analysis, the existing automated test suite, and a production build — **not** via manual click-through or screenshots. Recommend a manual smoke test of `/teams`, `/team-maintenance`, `/platforms`, `/communities`, and `/GETExport` in a real non-prod environment before release, especially for the code-splitting change (fix #2) and the CSS changes (fixes #9–11).
