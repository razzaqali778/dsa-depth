# Node 22.22.3 upgrade — assessment and npm audit

**Date:** 2026-06-09  
**Repo:** `eztrac-core-ui`  
**Previous Node:** 20.x (CI default `20.12.2`)  
**Target Node:** `22.22.3` (LTS *Jod*)

## Recommendation

**Proceed with the upgrade.** Node is used only for local development, CI build/lint/test, and packaging static assets. The shipped browser bundle is unchanged. Build, test suite, and production bundle were verified on Node `22.22.3` with no Node-related failures.

---

## What changed in the repo

| File | Change |
|---|---|
| `package.json` | `engines.node` → `22.22.3` |
| `.nvmrc` | Added `22.22.3` |
| `.github/workflows/*.yml` | CI `node_version` default → `22.22.3` |
| `README.md` | Prerequisites updated |

---

## Validation on Node 22.22.3

| Check | Result | Notes |
|---|---|---|
| `npm run build` | Pass | Vite build + tarball packaging succeeded |
| `npm test` | Pass | 92 suites, 356 tests passed |
| `npm run lint` | Pass | Fixed trailing comma in `service-bindings.js` |
| Browser runtime | Unaffected | React 16 app runs in the browser, not on Node |

---

## Node 20 → 22 breaking changes — impact on this repo

This project is a **static React SPA**. Node does not run in production; PEAdmin serves compiled JS/CSS. Most Node 22 breaking changes therefore do **not** affect end users.

### Low / no impact

| Change | Why it does not block us |
|---|---|
| **Browser runtime unchanged** | Users run compiled assets in Chrome/Edge; Node version only affects dev/CI tooling. |
| **Vite 5 + Jest 29 + sass-embedded** | All support Node 18+ and work on Node 22 (verified by build/test). |
| **OpenSSL 3** | Already required from Node 17+; no new jump at 22 for this stack. |
| **Global `fetch` / Web Crypto** | Stable since Node 18; build tools already use modern APIs. |
| **npm 10** (bundled with Node 22) | Compatible with existing `package-lock.json` v3. |

### Worth knowing (not blockers)

| Change | Relevance |
|---|---|
| **`import assert` removed** | Use `import with` if any source used import assertions. This repo does not. |
| **Legacy `url.parse()` discouraged** | Prefer WHATWG `URL` in new code. Existing deps may still use legacy APIs internally; no failure observed. |
| **Stricter default test runner behavior** | Jest 29 abstracts this; all 92 suites passed. |
| **Internal `@bayerit` / `@monsantoit` packages** | `@monsantoit/phoenix-navbar` declares `node: >18 <21` (engine warning only; build/tests pass). `@bayerit/phx-ocelot-auth-tools` declares `^20.0.0`. Monitor first CI run. |
| **Phoenix `le-deploy` shared CI workflow** | Accepts `node_version` input; defaults updated to `22.22.3`. Confirm Phoenix runners provide Node 22 if CI fails. |

### Not applicable

- Native addons / `node-gyp` — none in direct dependencies
- Server-side Node APIs in app code — app is client-only React
- ESM-only Node entrypoints — build uses Vite + Jest with existing config

---

## npm audit report

**Command:** `npm audit` (Node 22.22.3, npm 10.9.8)  
**Date:** 2026-06-09 (after lockfile peer-dep fix)

### Summary

| Severity | Count |
|---|---|
| Critical | 1 |
| High | 9 |
| Moderate | 12 |
| Low | 2 |
| **Total** | **24** |

> **Note:** `npm audit fix` (non-breaking) was attempted after correcting a malformed `>=^16.0.0` peer range in `package-lock.json` (from `react-toggle`). It reduced vulnerabilities to 8 but **broke 8 Jest suites** (cuid2/formidable/superagent chain). Changes were reverted; only the peer-dep and `engines` fixes remain in the lockfile.

### Findings by package

| Package | Severity | Issue (summary) | Fix notes |
|---|---|---|---|
| `form-data` | Critical | Unsafe random boundary generation | Transitive (`@monsantoit/profile-client`); `npm audit fix` |
| `@babel/plugin-transform-modules-systemjs` | High | Arbitrary code generation on malicious input | Dev/build-time only; `npm audit fix` |
| `cross-spawn` | High | ReDoS | Dev tooling; `npm audit fix` |
| `flatted` | High | DoS / prototype pollution in `parse()` | Dev tooling; `npm audit fix` |
| `immutable` | High | Prototype pollution | Transitive; `npm audit fix` |
| `lodash` / `lodash-es` | High | Prototype pollution / code injection in `_.template` | Direct dep + transitive; `npm audit fix` |
| `minimatch` | High | ReDoS | Dev tooling; `npm audit fix` |
| `picomatch` | High | ReDoS / glob matching | Dev tooling; `npm audit fix` |
| `rollup` | High | Path traversal file write | Build tool (Vite); upgrade Vite/rollup via `npm audit fix` |
| `@babel/helpers`, `@babel/runtime` | Moderate | RegExp complexity in transpiled code | Dev/build-time; `npm audit fix` |
| `ajv` | Moderate | ReDoS with `$data` option | ESLint transitive; `npm audit fix` |
| `brace-expansion` | Moderate | ReDoS / process hang | Dev tooling; `npm audit fix` |
| `esbuild` / `vite` | Moderate | Dev server request leakage | **Dev-only** — not exposed in prod static deploy; upgrade Vite |
| `js-yaml` | Moderate | Prototype pollution in merge | Test/lint transitive; `npm audit fix` |
| `nanoid` | Moderate | Predictable IDs with bad input | Transitive; `npm audit fix` |
| `postcss` | Moderate | XSS in CSS stringify | Build-time; `npm audit fix` |
| `qs` | Moderate | DoS via array parsing | Transitive; `npm audit fix` |
| `uuid` | Moderate | Buffer bounds check (v3/v5/v6) | Direct dep; **`npm audit fix --force` → uuid@14 (breaking)** |
| `ws` | Moderate | Memory disclosure | Dev server transitive; `npm audit fix` |
| `yaml` | Moderate | Stack overflow on nested YAML | Dev tooling; `npm audit fix` |
| `@tootallnate/once` | Low | Control flow scoping | Transitive; `npm audit fix` |
| `formidable` | Low | Filename guessing | Transitive; `npm audit fix` |

### Audit fix status

```bash
npm audit fix          # safe (non-breaking) updates — attempted 2026-06-09
npm audit fix --force  # includes breaking changes (e.g. uuid@14)
```

`npm audit fix` (non-breaking) **failed** with:

```
EINVALIDTAGNAME — Invalid tag name ">=^16.0.0" of package "react@>=^16.0.0"
```

This appears to be an npm audit resolver issue with a malformed range in the dependency tree, not caused by the Node upgrade. Manual dependency bumps (Vite, lodash, uuid) in a follow-up PR are recommended.

### Production risk from audit findings

Most vulnerabilities are in **dev/build/test** dependencies (Vite, ESLint, Jest, Babel). The deployed artifact is static HTML/JS/CSS on PEAdmin; esbuild/vite dev-server issues do not apply to production hosting.

**Higher priority for follow-up:**

1. **`lodash`** — direct dependency; bump to patched `4.17.21+` (already pinned; confirm lockfile resolves latest patch)
2. **`uuid`** — direct dependency at `^3.3.3`; audit wants `>=11.1.1`; major upgrade needs code review
3. **`form-data`** — transitive via `@monsantoit/profile-client`; may need upstream package update

---

## Rollout checklist

1. Install Node `22.22.3` locally: `nvm install 22.22.3 && nvm use`
2. Run `npm ci && npm run build && npm test && npm run lint`
3. Merge Node version changes; confirm **np-deploy** CI passes on Node 22
4. Schedule dependency audit remediation (separate from Node upgrade)

---

## References

- [Node.js 22 release notes](https://nodejs.org/en/blog/release/v22.0.0)
- [Node.js 22 LTS (*Jod*)](https://nodejs.org/en/about/previous-releases)
- [Vite — Node version support](https://vitejs.dev/guide/)
