# EZ-Trac Core UI

React/Redux front end for EZ-Trac core features, hosted on [PEAdmin](https://peadmin-np.monsanto.net) under the `/ez-trac-core` context root. Supports team planning, team maintenance, platform and community administration, and GET data export.

| | | |
|---|---|---|
| **Lightning Express name** | `eztrac-core-ui` | `https://devtools.bayer.com/lightning-express/eaf368c9-27ac-433f-b476-959a0b75afcf`
| **Deployable** | `ez-trac-core-ui-aws` | `https://devtools.bayer.com/deployment-approvals/deployables/ez-trac-core-ui-aws`
| **Ocelot route** | `/ez-trac-core` | [non prod](https://devtools-np.bayer.com/ocelot?route=peadmin-np.monsanto.net%2Fez-trac-core), [prod](https://devtools.bayer.com/ocelot?route=peadmin.monsanto.net%2Fez-trac-core)

## Features and routes

All routes are relative to `/ez-trac-core` (e.g. `/ez-trac-core/teams`).

| Route | Purpose |
|---|---|
| `/teams` | Team planning: initiatives, people, and engagements by time frame |
| `/team-maintenance` | Create and edit teams (requires manage-teams entitlement) |
| `/platforms` | Platform administration |
| `/communities` | Community administration |
| `/GETExport` | Export GET reporting data (CSV) |

## Tech stack

- **UI:** React 16, RMWC, React Router 4
- **State:** Redux, Redux-Saga, Reselect
- **Build:** Vite 5 (dev server on port `3035`)
- **Auth / shell:** Phoenix navbar (`@monsantoit/phoenix-navbar`), PEAdmin, Ocelot (local)
- **API clients:** `@bayerit/profile-client`, `@bayerit/preferences-client`

## Backend services

The UI does not connect to a database directly. It calls backend services via Phoenix service bindings (`src/client/service-bindings.js`):

| Binding key | Non-prod | Prod |
|---|---|---|
| `ez-trac-core` | `https://ez-trac-core-services.velocity-np.ag` | `https://ez-trac-core-services.velocity.ag` |
| `ez-trac-costing` | `https://ez-trac-costing-services.velocity-np.ag` | `https://ez-trac-costing-services.velocity.ag` |
| `ez-trac-vip` | `https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services` | `https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services` |
| `ez-trac-vip-ui` | `https://peadmin-np.monsanto.net/ez-trac-vip` | `https://peadmin.monsanto.net/ez-trac-vip` |
| `profile-url` | `https://profile.phoenix-tools-np.io` | `https://profile.phoenix-tools.io` |

Related EZ-Trac UIs and services (core API, costing, VIP) must be available in the target environment for full functionality.

When running locally, the `local` entry in [`service-bindings.js`](./src/client/service-bindings.js) currently mirrors non-prod URLs. To use locally running backends instead, update the `local` bindings (e.g. `ez-trac-core`, `ez-trac-costing`, `ez-trac-vip`) to point at your local service URLs.

## Entitlements

Access is enforced via Phoenix entitlements. Entitlements and access are managed through [Ez-Trac PAPI application](https://devtools.bayer.com/profile/applications/EZTRAC) (prod; for non-prod use `https://devtools-np.bayer.com/profile/applications/EZTRAC`).

| Entitlement | Grants |
|---|---|
| `eztrac-read-user` | Read access to the app |
| `eztrac-write-user` | Read access (included in read check) |
| `ez-trac-admin` | Read access (legacy admin code) |
| `eztrac-manage-teams` | Team maintenance (create/edit teams) |
| `eztrac-manage-efforts` | Manage engagements/efforts |
| `eztrac-admin-user` | Admin capabilities |

Without a read entitlement, users see the invalid-entitlement screen.

See [docs/NODE-22-UPGRADE.md](./docs/NODE-22-UPGRADE.md) for the Node 22 upgrade assessment and [docs/PACKAGE-AUDIT-UPGRADE.md](./docs/PACKAGE-AUDIT-UPGRADE.md) for the dependency audit remediation (0 vulnerabilities).

## Prerequisites

- **Node.js** `22.22.3` (see `package.json` `engines` and `.nvmrc`)
- **npm** access to Bayer Artifactory (internal `@bayerit` / `@monsantoit` packages)
- **Ocelot** for local development (auth proxy to non-prod services)
- **Vault** access for OAuth client secrets (see below)

## Local development

### 1. Install dependencies

```bash
npm install
```

Ensure your npm registry is configured for [Bayer Artifactory](https://docs.int.bayer.com/cloud/devops/artifactory/npm/) if install fails on scoped packages.

### 2. Configure Vault access

Set up Vault CLI access so you can read OAuth client secrets for local Ocelot configuration. See [Using Vault on the CLI](https://docs.int.bayer.com/cloud/devops/vault/access-vault/#using-vault-on-the-cli).

Log into Vault before you start Ocelot.

### 3. Configure Ocelot

Local development requires [Ocelot](https://docs.int.bayer.com/cloud/api/ocelot/running-locally/) so the browser can authenticate and proxy requests to non-prod backends.

Copy or merge [ez-trac-core-ui-config.json](./ez-trac-core-ui-config.json) into your Ocelot routes (typically `.ocelot/routes`). 

Start Ocelot before opening the app in the browser.

### 4. Start the dev server

```bash
npm run dev
```

Vite serves the app at **http://localhost:3035** with base path `/ez-trac-core`.

### 5. Open the app

Use Ocelot’s proxied URL (not the Vite port directly), for example:

- http://localhost/ez-trac-core/teams
- http://localhost/ez-trac-core/team-maintenance
- http://localhost/ez-trac-core/platforms

Both **Ocelot** and **`npm run dev`** must be running.

## Linting and formatting

```bash
npm run lint
npm run lint:fix
npm run audit
```

Prettier config: `prettier.config.cjs`. ESLint extends `@bayerit/eslint-config-velocity`.

## Project layout

```
src/client/
  index.jsx              # App entry, router basename, Phoenix navbar
  service-bindings.js    # Backend URL map (np / prod / local)
  components-containers/ # Route-level containers and feature UI
  redux/                 # Actions, reducers, sagas, selectors
  styles/                # CSS/SCSS (includes vendored toastr.css)
test/                    # Jest specs (*.spec.js)
index.html               # Vite HTML shell (PEAdmin navbar assets)
vite.config.js           # Build output, dev server port, base path
```

## Vault

Secrets are stored in HashiCorp Vault.

### Paths

| Path | Environment |
|---|---|
| `/secret/ez-trac/core-ui/np` | Non-prod |
| `/secret/ez-trac/core-ui/prod` | Production |

## Deployment

Static assets are published with [Lightning Express](https://docs.int.bayer.com/cloud/phoenix/lightning-express/#lightning-express) (`le-deploy`). CI/CD is handled by GitHub Actions workflows in [`.github/workflows/`](./.github/workflows/) that call reusable workflows maintained by the Phoenix team in [`bayer-int/phx-internal-ci-scripts`](https://github.com/bayer-int/phx-internal-ci-scripts) ([`le-deploy.yaml`](https://github.com/bayer-int/phx-internal-ci-scripts/blob/v1/.github/workflows/le-deploy.yaml)). Local workflow files only pass build step, environment, and EZ-Trac-specific inputs; build, deploy, and release logic lives in the shared Phoenix workflow.

This app uses the **shared Lightning Express account** for hosting build artifacts, not the dedicated EZ-Trac Lightning Express accounts used by other EZ-Trac services. Deployment settings for `le-deploy` live in [`le-deploy-config.cjs`](./le-deploy-config.cjs) (project ID, context root, team, etc.); these values must match the project configuration in the [Lightning Express UI](https://devtools.bayer.com/lightning-express/eaf368c9-27ac-433f-b476-959a0b75afcf) linked in the table above.

| Workflow | Trigger | Purpose |
|---|---|---|
| `np-deploy-le.yml` | Push to `main` | Deploy to NonProd |
| `prepare-le.yml` | Manual | Bump version (patch/minor/major) and create Deployment Document |
| `release-le.yml` | Manual | Promote an approved version to Prod |

### Production release and approvals

Non-prod deploys automatically on push to `main`. Production releases follow a separate approval flow:

1. Run **`prepare-le.yml`** — bumps `package.json` version, builds the artifact, and creates a Deployment Document for the `ez-trac-core-ui-aws` deployable.
2. **Obtain release approval** — after prepare completes, the new version must be approved before it can go to prod. Use the [Deployment Approvals UI](https://devtools.bayer.com/deployment-approvals) to find and approve the pending deployment for `ez-trac-core-ui-aws` (also linked in the table above). See the [approval process documentation](https://docs.int.bayer.com/cloud/crop-science/development/tools/deployment-approvals/approvalProcess/#deployment-approvals-approval-process) for details on reviewers, status, and required steps.
3. Run **`release-le.yml`** — once approved, run the release workflow with the approved `deployable_version` to promote that build to prod.

Deploy scripts expect `CLIENT_ID` and `CLIENT_SECRET` for the Lightning Express deployment client. Build artifacts are packaged as `eztrac-core-ui-<version>.tgz` after `npm run build`.

**Non-prod:** https://peadmin-np.monsanto.net/ez-trac-core  
**Prod:** https://peadmin.monsanto.net/ez-trac-core
