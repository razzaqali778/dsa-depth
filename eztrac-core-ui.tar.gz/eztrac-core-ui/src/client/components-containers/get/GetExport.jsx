import '../../styles/containers/AppContainerStyles.css'
import {Button} from '@rmwc/button'
import {Checkbox} from '@rmwc/checkbox'
import {Grid, GridCell, GridInner} from '@rmwc/grid'
import {Icon} from '@rmwc/icon'
import React from 'react'
import ReactTooltip from 'react-tooltip'
import Select from 'react-select'
import filter from 'lodash/filter'
import isEmpty from 'lodash/isEmpty'
import join from 'lodash/join'
import map from 'lodash/map'
import {regionTooltip, regions} from './regionConstants'

const infoSelectStyles = {
    container: (base) => ({
        ...base,
        'padding-left': '25px'
    })
}

const getRegionSelectOption = (value) => regions.find((region) => region.value === value)

const saveDownload = (
    getCsv,
    selectedTimeFrame,
    selectedTeams,
    selectedCommunityPlatform,
    downloadAll,
    selectedRegion
) => {
    const downloadContext = isEmpty(selectedCommunityPlatform)
        ? join(map(selectedTeams, 'value'), '_')
        : selectedCommunityPlatform.value
    const fileName = downloadAll
        ? `${selectedTimeFrame.name}_ALL_${selectedRegion}`
        : `${selectedTimeFrame.name}_${downloadContext}_${selectedRegion}`
    const newFileData = new Blob([getCsv], {type: 'text/csv'})
    const url = URL.createObjectURL(newFileData)
    const link = document.createElement('a')
    link.setAttribute('href', url)
    link.setAttribute('download', `${fileName}.csv`)
    link.click()
}

const enableDownload = (timeFrame, platformCommunity, teams, downloadAll, region) => {
    if (isEmpty(timeFrame) || isEmpty(region)) {
        return false
    }
    if (isEmpty(platformCommunity) && isEmpty(teams) && !downloadAll) {
        return false
    }

    return true
}

const GetExport = ({
    fetchGetExport,
    teamOptions,
    timeFrames,
    selectedTimeFrame,
    selectedRegion,
    formattedPlatformCommunityOptions,
    GETCsvDownload,
    setSelectedTimeFrameId,
    setSelectedRegion,
    setSelectedCommunityPlatform,
    selectedCommunityPlatform,
    setSelectedTeams,
    selectedTeams,
    setGetCsvDownload,
    setDownloadAll,
    downloadAll
}) => (
    <div className="app-container container">
        <Grid>
            <GridCell span="12" style={{marginTop: '-25px'}}>
                <h2>Download for GET Export</h2>
                <GridInner span="10">
                    <GridCell className="getExport" span="10">
                        <Select
                            className="select-month"
                            onChange={(input) => {
                                setGetCsvDownload([])
                                setSelectedTimeFrameId(input.value)
                            }}
                            options={map(
                                filter(timeFrames, (timeFrame) => timeFrame.isActive),
                                (date) => ({label: date.name, value: date.id})
                            )}
                            placeholder={
                                selectedTimeFrame ? selectedTimeFrame.name : 'Select a Timeframe'
                            }
                        />
                        <div className="info-select">
                            <Select
                                className="select-month"
                                onChange={(input) => {
                                    setGetCsvDownload([])
                                    setSelectedRegion(input.value)
                                }}
                                options={regions}
                                placeholder="Select region"
                                styles={infoSelectStyles}
                                value={getRegionSelectOption(selectedRegion)}
                            />
                            <ReactTooltip />
                            <span data-tip={regionTooltip}>
                                <Icon className="info-button" icon="info_outline" />
                            </span>
                        </div>
                    </GridCell>
                    <GridCell span="5">
                        <h4>Pick a Platform/Community</h4>
                    </GridCell>
                    <GridCell span="5">
                        <h4>OR Team(s)</h4>
                    </GridCell>
                    <GridCell className="platformCommunitySelect" span="5">
                        <Select
                            isClearable
                            isDisabled={downloadAll}
                            onChange={(event) => setSelectedCommunityPlatform(event)}
                            options={formattedPlatformCommunityOptions} // out of date
                            placeholder="Select a Platform or Community"
                            value={
                                selectedCommunityPlatform
                                    ? selectedCommunityPlatform.name
                                    : 'Select a Platform or Community'
                            }
                        />
                    </GridCell>
                    <GridCell className="teamsSelect" span="5">
                        <Select
                            className="teamSelect get-select"
                            isDisabled={downloadAll}
                            isMulti
                            onChange={(teams) => setSelectedTeams(teams)}
                            options={teamOptions}
                            placeholder="Select Team(s)"
                            value={selectedTeams ? selectedTeams.name : 'Select Teams'}
                        />
                    </GridCell>
                    <GridCell className="download" span="10">
                        <Checkbox
                            checked={downloadAll}
                            label="Download All Platforms and Teams"
                            onChange={(evt) => setDownloadAll(!!evt.currentTarget.checked)}
                        />
                    </GridCell>
                    <GridCell className="download" span="10">
                        <Button
                            disabled={
                                !enableDownload(
                                    selectedTimeFrame,
                                    selectedCommunityPlatform,
                                    selectedTeams,
                                    downloadAll,
                                    selectedRegion
                                )
                            }
                            onClick={() => {
                                fetchGetExport(
                                    selectedTimeFrame,
                                    selectedTeams,
                                    selectedCommunityPlatform,
                                    downloadAll,
                                    selectedRegion
                                )
                            }}
                            outlined
                        >
                            Download GET Csv
                        </Button>
                    </GridCell>
                </GridInner>
            </GridCell>
        </Grid>

        {isEmpty(GETCsvDownload) ? (
            <div id="noFile" />
        ) : (
            saveDownload(
                GETCsvDownload,
                selectedTimeFrame,
                selectedTeams,
                selectedCommunityPlatform,
                downloadAll,
                selectedRegion
            )
        )}
    </div>
)

export default GetExport
