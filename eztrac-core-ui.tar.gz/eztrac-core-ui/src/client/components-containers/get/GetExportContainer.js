import {connect} from 'react-redux'
import {getActions} from '../../redux/actions'
import {
    getCsvDownload,
    getDownloadAll,
    getSelectedCommunityPlatform,
    getSelectedRegion,
    getSelectedTeams,
    getTimeFrames
} from '../../redux/selectors'
import GETExport from './GetExport'
import getActiveTeamSelectOptions from '../../redux/selectors/teams/getActiveTeamSelectOptions'
import getFormattedPlatformAndCommunity from '../../redux/selectors/teams/getFormattedPlatformAndCommunity'
import getSelectedTimeFrame from '../../redux/selectors/getSelectedTimeFrame'
import timeFrameActions from '../../redux/actions/timeFramesActions'

const mapStateToProps = (state) => ({
    teamOptions: getActiveTeamSelectOptions(state),
    timeFrames: getTimeFrames(state),
    selectedTimeFrame: getSelectedTimeFrame(state),
    selectedRegion: getSelectedRegion(state),
    formattedPlatformCommunityOptions: getFormattedPlatformAndCommunity(state),
    GETCsvDownload: getCsvDownload(state),
    selectedCommunityPlatform: getSelectedCommunityPlatform(state),
    selectedTeams: getSelectedTeams(state),
    downloadAll: getDownloadAll(state)
})

const mapDispatchToProps = (dispatch) => ({
    fetchGetExport: (timeframe, teams, communityPlatform, downloadAll, region) =>
        dispatch(
            getActions.fetchGetExport({timeframe, teams, communityPlatform, downloadAll, region})
        ),
    setSelectedTimeFrameId: (timeframe) =>
        dispatch(timeFrameActions.setSelectedTimeFrameId(timeframe)),
    setSelectedRegion: (region) => dispatch(getActions.setSelectedRegion(region)),
    setSelectedCommunityPlatform: (community) =>
        dispatch(getActions.setSelectedCommunityPlatform(community)),
    setSelectedTeams: (teams) => dispatch(getActions.setSelectedTeams(teams)),
    setGetCsvDownload: (csv) => dispatch(getActions.setGetCsvDownload(csv)),
    setDownloadAll: (downloadAllSelection) =>
        dispatch(getActions.setDownloadAll(downloadAllSelection))
})

export default connect(mapStateToProps, mapDispatchToProps)(GETExport)
