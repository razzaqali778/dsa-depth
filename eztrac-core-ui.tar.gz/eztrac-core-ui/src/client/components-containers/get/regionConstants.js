export const regions = [
    {
        value: 'STD-Fixed',
        label: 'US'
    },
    {
        value: 'DE-FIXED',
        label: 'Germany'
    },
    {
        value: 'AR',
        label: 'Argentina'
    },
    {
        value: 'BR-FIXED',
        label: 'Brazil'
    }
]

export const regionTooltip =
    "Selecting a region will change the calendar used to calculate maximum number of hours per month, but it won't affect which persons are included in the report"
