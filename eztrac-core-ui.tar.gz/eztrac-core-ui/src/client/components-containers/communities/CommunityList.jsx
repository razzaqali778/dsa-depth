import React, {useCallback, useState} from 'react'
import {useSelector, useDispatch} from 'react-redux'
import {getTeams} from '../../redux/selectors'
import ChildEntitiesModal from '../common/ChildEntitiesModal'
import EntityList from '../common/EntityList'
import getCommunitiesExtended from '../../redux/selectors/teams/getCommunitiesExtended'
import actions from '../../redux/actions'
import ConfirmationModal from '../common/ConfirmationModal'
import LoadVelocityStylesheet from '../common/LoadVelocityStylesheet'
import getPlatformsSelectOptions from '../../redux/selectors/teams/getPlatformsSelectOptions'

export default function CommunityList() {
    const [showTeamsModal, setShowTeamsModal] = useState(false)
    const [modalData, setModalData] = useState({childEntities: [], entityName: ''})
    const [showConfirmationModal, setShowConfirmationModal] = useState(false)
    const [confirmationModalSaveAction, setConfirmationModalSaveAction] = useState(null)

    const platformSelectOptions = useSelector(getPlatformsSelectOptions)
    const communities = useSelector(getCommunitiesExtended)
    const teams = useSelector(getTeams)

    const dispatch = useDispatch()

    const handleShowTeams = useCallback(
        (community) => {
            setShowTeamsModal(true)
            const communitiesTeams = teams.filter((t) => t.communityId === community.id)
            setModalData({childEntities: communitiesTeams, entityName: community.name})
        },
        [teams]
    )

    const handleSaveEditedCommunity = (editedCommunity) => {
        const selectedCommunity = communities.find((c) => c.id === editedCommunity.id)
        const communityDeactivated = selectedCommunity.isActive && !editedCommunity.isActive
        const activeCommunityTeams = teams.filter(
            (t) => t.communityId === editedCommunity.id && t.isActive
        )
        if (communityDeactivated && activeCommunityTeams.length) {
            setConfirmationModalSaveAction(
                actions.saveCommunity({community: editedCommunity, isCreating: false})
            )
            setShowConfirmationModal(true)
            return
        }
        dispatch(actions.saveCommunity({community: editedCommunity, isCreating: false}))
    }

    const mapToListItem = (community) => ({
        id: community.id,
        name: community.name,
        isActive: community.isActive,
        parentId: community.platformId,
        parentName: community.platformName
    })

    const mapListItemToCommunity = (listItem) => ({
        id: listItem.id,
        name: listItem.name,
        isActive: listItem.isActive,
        platformId: listItem.parentId
    })

    return (
        <>
            <LoadVelocityStylesheet />
            <div className="container">
                <h1>Communities</h1>
                <ConfirmationModal
                    open={showConfirmationModal}
                    onClose={() => setShowConfirmationModal(false)}
                    onSaveAction={confirmationModalSaveAction}
                    title="Deactivating community"
                    body="There are active teams under this community."
                />
                <ChildEntitiesModal
                    open={showTeamsModal}
                    onClose={() => setShowTeamsModal(false)}
                    data={modalData}
                    entityType="community"
                />
                <EntityList
                    entities={communities.map((c) => mapToListItem(c))}
                    handleShowChildrenClick={handleShowTeams}
                    entityType="community"
                    parentOptions={platformSelectOptions}
                    onNewEntitySave={(newEntity) => {
                        dispatch(
                            actions.saveCommunity({
                                community: mapListItemToCommunity(newEntity),
                                isCreating: true
                            })
                        )
                    }}
                    onEditedEntitySave={(editedEntity) => {
                        handleSaveEditedCommunity(mapListItemToCommunity(editedEntity))
                    }}
                />
            </div>
        </>
    )
}
