const ALL = 'ALL'
const ACTIVE = 'ACTIVE'
const INACTIVE = 'INACTIVE'

export const statusFilterValues = {
    ACTIVE,
    ALL,
    INACTIVE
}
