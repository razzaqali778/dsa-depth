import React, {useCallback, useEffect, useState} from 'react'
import '../../styles/components/EntityListStyles.css'
import FilterBar from './FilterBar'
import {statusFilterValues} from './consts'
import EditEntityForm from './EditEntityForm'
import EntityListItem from './EntityListItem'
import DownloadCSV from '../utils/buildCsv'

export default function EntityList({
    entities,
    handleShowChildrenClick,
    entityType,
    parentOptions,
    onNewEntitySave,
    onEditedEntitySave
}) {
    const [statusFilter, setStatusFilter] = useState('ACTIVE')
    const [searchPhrase, setSearchPhrase] = useState('')
    const [filteredEntities, setFilteredEntities] = useState([])
    const [showCreateForm, setShowCreateForm] = useState(false)

    const csvFileName = entityType === 'platform' ? 'platforms' : 'communities'
    const parentTypeLabel = entityType === 'platform' ? 'Org' : 'Platform'

    const filterByStatus = (entitiesArray) => {
        switch (statusFilter) {
            case statusFilterValues.ACTIVE:
                return entitiesArray.filter((e) => e.isActive)
            case statusFilterValues.INACTIVE:
                return entitiesArray.filter((e) => !e.isActive)
            default:
                return entitiesArray
        }
    }

    const filterBySearchPhrase = (entitiesArray) => {
        const search = searchPhrase.toLowerCase()

        if (search === '') return entitiesArray

        return entitiesArray.filter(
            (e) => e.name.toLowerCase().includes(search) || e.id.toLowerCase().includes(search)
        )
    }

    const handleStatusFilterChange = useCallback(
        (filter) => {
            setStatusFilter(filter)
        },
        [statusFilter]
    )

    const handleSearchPhraseChange = useCallback(
        (searchPhraseString) => {
            setSearchPhrase(searchPhraseString)
        },
        [searchPhrase]
    )

    useEffect(() => {
        setFilteredEntities(filterBySearchPhrase(filterByStatus(entities)))
    }, [statusFilter, searchPhrase, entities])

    const handleSaveNewEntity = (newEntity) => {
        setShowCreateForm(false)
        onNewEntitySave(newEntity)
    }

    return (
        <>
            <FilterBar
                selectedStatus={statusFilter}
                onStatusChange={handleStatusFilterChange}
                statusOptions={Object.values(statusFilterValues)}
                onSearchPhraseChange={handleSearchPhraseChange}
                onNewEntityClick={() => setShowCreateForm(true)}
                onDownloadCsv={() => DownloadCSV(filteredEntities, csvFileName)}
            />
            {showCreateForm ? (
                <EditEntityForm
                    onClose={() => setShowCreateForm(false)}
                    parentOptions={parentOptions}
                    parentTypeLabel={parentTypeLabel}
                    onSave={(newEntity) => handleSaveNewEntity(newEntity)}
                />
            ) : null}
            <div className="entity-list">
                {filteredEntities.map((entity) => (
                    <EntityListItem
                        entity={entity}
                        entityType={entityType}
                        key={entity.id}
                        parentOptions={parentOptions}
                        parentTypeLabel={parentTypeLabel}
                        onShowChildrenClick={() => handleShowChildrenClick(entity)}
                        onSaveEditedEntity={onEditedEntitySave}
                    />
                ))}
            </div>
        </>
    )
}
