import React, {useState} from 'react'
import '../../styles/components/EntityListStyles.css'
import EditEntityForm from './EditEntityForm'

function ShowChildEntitiesButton({handleClick, label}) {
    return (
        <button type="button" className="btn btn-default pull-right" onClick={() => handleClick()}>
            {label}
        </button>
    )
}

export default function EntityListItem({
    entity,
    entityType,
    parentTypeLabel,
    onShowChildrenClick,
    parentOptions,
    onSaveEditedEntity
}) {
    const [editMode, setEditMode] = useState(false)

    const typeLabel = entityType === 'platform' ? 'Platform' : 'Community'
    const childTypeLabel = entityType === 'platform' ? 'Communities' : 'Teams'

    const entityStatus = (status = false) => {
        const statusLabel = status ? 'Active' : 'Inactive'
        const className = status ? 'success' : 'danger'

        return (
            <span className={`label label-${className}`}>
                {statusLabel} {typeLabel}
            </span>
        )
    }

    const handleSaveEntity = (newEntity) => {
        setEditMode(false)
        onSaveEditedEntity(newEntity)
    }

    return (
        <>
            {editMode ? (
                <EditEntityForm
                    onClose={() => setEditMode(false)}
                    selectedEntity={entity}
                    parentOptions={parentOptions}
                    parentTypeLabel={parentTypeLabel}
                    onSave={(editedEntity) => handleSaveEntity(editedEntity)}
                />
            ) : null}
            <div className="list-group-item">
                <h4 className="list-group-item-heading inline-block">{entity.name}</h4>
                <button
                    type="button"
                    className="btn btn-default pull-right"
                    onClick={() => setEditMode(true)}
                >
                    Edit
                </button>
                <ShowChildEntitiesButton
                    handleClick={() => onShowChildrenClick()}
                    label={`Show ${childTypeLabel}`}
                />
                <div>
                    <span>{typeLabel} ID:&nbsp;</span>
                    <code>{entity.id}</code>
                </div>
                <div>
                    <span>{parentTypeLabel}:&nbsp;</span>
                    <code>{entity.parentName}</code>
                </div>
                {entityStatus(entity.isActive)}
            </div>
        </>
    )
}
