import React, {memo, useEffect, useMemo} from 'react'
import '../../styles/components/EntityListStyles.css'
import {debounce} from 'lodash'
import FilterButton from './FilterButton'

function DownloadCSVButton({onDownloadCsv}) {
    return (
        <button
            className="btn btn-default pull-right"
            color="default"
            onClick={() => onDownloadCsv()}
            title="Download CSV"
            type="button"
            aria-label="Download CSV"
        >
            <i className="fa fa-download" />
        </button>
    )
}

function NewEntityButton({handleClick}) {
    return (
        <button
            className="btn btn-success pull-right"
            onClick={() => handleClick()}
            title="Add Cost Group"
            type="button"
            aria-label="Add Cost Group"
        >
            <i className="fa fa-plus" />
        </button>
    )
}

function FilterBar({
    selectedStatus,
    onStatusChange,
    statusOptions,
    onSearchPhraseChange,
    onNewEntityClick,
    onDownloadCsv
}) {
    // Recreate the debounced function whenever onSearchPhraseChange changes (previously frozen to
    // the first render's callback via an empty deps array, a stale-closure risk for future callers
    // passing a non-stable handler), and cancel any pending call on unmount so it can't fire after
    // this component is gone.
    const debounceSearchPhrase = useMemo(
        () => debounce(onSearchPhraseChange, 300),
        [onSearchPhraseChange]
    )
    useEffect(() => () => debounceSearchPhrase.cancel(), [debounceSearchPhrase])

    return (
        <div className="filterBar">
            <div className="col-md-9 searchBar">
                <div className="col-md-1 searchBar dropdown">
                    <FilterButton
                        value={selectedStatus}
                        options={statusOptions}
                        onSelect={onStatusChange}
                    />
                </div>
                <div className="col-md-8 searchBar">
                    <input
                        className="form-control"
                        onChange={({target}) => debounceSearchPhrase(target.value)}
                        placeholder="Search by Name or ID..."
                        type="text"
                    />
                </div>
            </div>
            <div className="actionButtonsWrapper">
                <div className="multipleDownloadButton">
                    <DownloadCSVButton onDownloadCsv={onDownloadCsv} />
                </div>
                <NewEntityButton handleClick={onNewEntityClick} />
            </div>
        </div>
    )
}

export default memo(FilterBar)
