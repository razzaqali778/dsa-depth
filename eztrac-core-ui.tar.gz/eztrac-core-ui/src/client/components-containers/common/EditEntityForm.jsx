import React, {useState} from 'react'
import Toggle from 'react-toggle'
import Select from 'react-select'
import 'react-toggle/style.css'
import '../../styles/components/ReactToggle.css'

function IsActiveToggle({defaultChecked, toggleIsActiveValue}) {
    return (
        // eslint-disable-next-line jsx-a11y/label-has-associated-control
        <label className="react-toggle-label">
            <span className="react-toggle-text">Active?</span>
            <Toggle defaultChecked={defaultChecked} onChange={toggleIsActiveValue} />
        </label>
    )
}

export default function EditEntityForm({
    selectedEntity,
    parentOptions,
    parentTypeLabel,
    onClose,
    onSave
}) {
    const [editingEntity, setEditingEntity] = useState(() => selectedEntity ?? {isActive: true})

    const setParent = (parent) =>
        setEditingEntity({
            ...editingEntity,
            parentId: parent.value,
            parentName: parent.label
        })

    const setName = (name) => setEditingEntity({...editingEntity, name})

    const setIsActive = (isActive) => setEditingEntity({...editingEntity, isActive})

    const saveDisabled = !editingEntity.name || !editingEntity.parentId

    return (
        <div className="list-group-item edit-mode">
            <button
                className="btn btn-primary pull-right"
                onClick={() => onSave(editingEntity)}
                disabled={saveDisabled}
                type="button"
            >
                Save
            </button>
            <button type="button" className="btn btn-default pull-right" onClick={() => onClose()}>
                Cancel
            </button>
            <div className="form-group">
                <div className="input-group col-xs-6">
                    <div className="input-group-addon form-tag">Name</div>
                    <input
                        type="text"
                        className="form-control"
                        defaultValue={editingEntity?.name}
                        onChange={(e) => setName(e.target.value)}
                    />
                </div>
            </div>
            <div className="form-group">
                <div className="input-group col-xs-6">
                    <div className="input-group-addon form-tag">{parentTypeLabel}</div>
                    <Select
                        clearable={false}
                        onChange={setParent}
                        options={parentOptions}
                        value={
                            editingEntity && editingEntity.parentId
                                ? {
                                      value: editingEntity.parentId,
                                      label: editingEntity.parentName
                                  }
                                : null
                        }
                    />
                </div>
            </div>

            <IsActiveToggle
                defaultChecked={editingEntity.isActive}
                toggleIsActiveValue={(e) => setIsActive(e.target.checked)}
            />
        </div>
    )
}
