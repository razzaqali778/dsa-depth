import React from 'react'
import {Dialog, DialogContent, DialogActions} from '@rmwc/dialog'
import '../../styles/components/EntityListStyles.css'

function ChildEntityTable({childEntities}) {
    return (
        <table className="table table-striped table-bordered table-condensed">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Id</th>
                </tr>
            </thead>
            <tbody>
                {childEntities.map((c) => (
                    <tr key={c.id}>
                        <td>{c.name}</td>
                        <td>{c.id}</td>
                    </tr>
                ))}
            </tbody>
        </table>
    )
}

export default function ChildEntitiesModal({open, onClose, data, entityType}) {
    const childEntityLabel = entityType === 'platform' ? 'Communities' : 'Teams'
    const title = entityType === 'platform' ? 'Communities under platform' : 'Teams under community'
    const noChildEntitiesMessage =
        entityType === 'platform'
            ? 'communities under this platform.'
            : 'teams under this community.'

    const active = data.childEntities.filter((c) => c.isActive)
    const inactive = data.childEntities.filter((c) => !c.isActive)

    return (
        <Dialog open={open} onClose={() => onClose()}>
            <div className="modal-header">
                <h4 className="modal-title">
                    {title} {data.entityName}
                </h4>
            </div>
            <DialogContent className="modal-body">
                {active.length ? (
                    <div>
                        <h5>
                            <b>Active {childEntityLabel}: </b>
                        </h5>
                        <ChildEntityTable childEntities={active} />
                    </div>
                ) : (
                    <h5>
                        <b>No active {noChildEntitiesMessage}</b>
                    </h5>
                )}
                {inactive.length ? (
                    <div>
                        <h5>
                            <b>Inactive {childEntityLabel}: </b>
                        </h5>
                        <ChildEntityTable childEntities={inactive} />
                    </div>
                ) : (
                    <h5>
                        <b>No inactive {noChildEntitiesMessage}</b>
                    </h5>
                )}
            </DialogContent>
            <DialogActions className="modal-footer">
                <button
                    type="button"
                    className="btn btn-primary pull-right"
                    onClick={() => onClose()}
                >
                    Close
                </button>
            </DialogActions>
        </Dialog>
    )
}
