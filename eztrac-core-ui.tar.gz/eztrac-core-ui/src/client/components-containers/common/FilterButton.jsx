import React, {useState, useEffect, useRef} from 'react'
import '../../styles/components/EntityListStyles.css'

function DropdownItem({value, handleClick}) {
    return (
        <li>
            <a onClick={() => handleClick(value)}>{value}</a>
        </li>
    )
}

function FilterButton({value, options, onSelect}) {
    const [isOpen, setIsOpen] = useState(false)
    const dropdownRef = useRef(null)

    const toggleDropdown = () => {
        setIsOpen(!isOpen)
    }

    const selectFilter = (filter) => {
        toggleDropdown()
        onSelect(filter)
    }

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false)
            }
        }

        document.addEventListener('mousedown', handleClickOutside)
        return () => {
            document.removeEventListener('mousedown', handleClickOutside)
        }
    }, [dropdownRef])

    return (
        <div className={isOpen ? 'open' : ''} ref={dropdownRef}>
            <button type="button" className="btn btn-default no-outline" onClick={toggleDropdown}>
                {value}
                <span className="caret" />
            </button>
            {isOpen && (
                <ul className="dropdown-menu">
                    {options.map((option) => (
                        <DropdownItem key={option} value={option} handleClick={selectFilter} />
                    ))}
                </ul>
            )}
        </div>
    )
}

export default FilterButton
