import {Dialog, DialogActions, DialogButton, DialogContent, DialogTitle} from '@rmwc/dialog'
import React from 'react'
import {useDispatch} from 'react-redux'

const ConfirmationModal = ({open, title, body, onSaveAction, onClose}) => {
    const dispatch = useDispatch()

    return (
        <Dialog open={open}>
            <DialogTitle>{title}</DialogTitle>
            <DialogContent>{body} Do you want to proceed?</DialogContent>
            <DialogActions>
                <DialogButton
                    action="save"
                    onClick={() => {
                        dispatch(onSaveAction)
                        onClose()
                    }}
                >
                    Save
                </DialogButton>
                <DialogButton action="cancel" isDefaultAction onClick={onClose}>
                    Cancel
                </DialogButton>
            </DialogActions>
        </Dialog>
    )
}

export default ConfirmationModal
