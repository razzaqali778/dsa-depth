import {useEffect} from 'react'

// component for dynamically loading velocity stylesheet in a way that they won't take precedence over the app's styles

const LoadVelocityStylesheet = () => {
    useEffect(() => {
        const link = document.createElement('link')
        link.rel = 'stylesheet'
        link.href = 'https://static-assets.velocity.ag/styles/1.0.1/velocity.css'
        link.type = 'text/css'

        const appMainStyles = document.getElementById('peadmin-mat-style')

        if (appMainStyles && appMainStyles.parentNode) {
            appMainStyles.parentNode.insertBefore(link, appMainStyles.nextSibling)
        } else {
            document.head.appendChild(link)
        }

        return () => {
            // `link` may have been inserted next to `appMainStyles` rather than appended directly
            // to `document.head`; unconditionally calling `document.head.removeChild(link)` throws
            // a NotFoundError if that node isn't a direct child of `<head>` (or was already removed).
            link.parentNode?.removeChild(link)
        }
    }, [])

    return null
}

export default LoadVelocityStylesheet
