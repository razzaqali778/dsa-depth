import {Button} from '@rmwc/button'
import React, {useState} from 'react'
import ConfirmDialog from './ConfirmDialog'

function InitiativeCopyForwardMonthConfirmButton({
    copyForwardToTimeFrame,
    copyForwardFunction,
    overwrittenMonths,
    setCopyCalendarModalBool,
    disabledBoolean,
    buttonName,
    classNm,
    copyForwardFromTimeFrame
}) {
    const [open, setOpen] = useState(false)

    return (
        <div>
            <ConfirmDialog
                copyForwardFromTimeFrame={copyForwardFromTimeFrame}
                copyForwardFunction={copyForwardFunction}
                copyForwardToTimeFrame={copyForwardToTimeFrame}
                open={open}
                overwrittenMonths={overwrittenMonths}
                setCopyCalendarModalBool={setCopyCalendarModalBool}
                setOpen={setOpen}
            />
            <Button
                className={classNm}
                disabled={disabledBoolean}
                onClick={() => {
                    if (overwrittenMonths.length === 0) {
                        copyForwardFunction({copyForwardFromTimeFrame, copyForwardToTimeFrame})

                        if (setCopyCalendarModalBool) {
                            setCopyCalendarModalBool(false)
                        }
                    } else {
                        setOpen(true)
                    }
                }}
                outlined
            >
                {' '}
                {buttonName}
            </Button>
        </div>
    )
}

export default InitiativeCopyForwardMonthConfirmButton
