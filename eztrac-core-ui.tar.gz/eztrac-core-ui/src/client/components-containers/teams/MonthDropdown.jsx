import {Button} from '@rmwc/button'
import {Card, CardActionButtons, CardActions} from '@rmwc/card'
import {DataTable} from '@rmwc/data-table'
import {findIndex, map, slice} from 'lodash'
import React, {useRef} from 'react'
import find from 'lodash/find'
import {useListenForOutsideClicks} from '../utils/useListenForOutsideClicks'
import InitiativeCopyForwardMonthConfirmButtonContainer from './InitiativeCopyForwardMonthConfirmButtonContainer'

const MonthDropdown = ({
    timeFrames,
    setCopyForwardTimeFrame,
    copyForwardTimeFrame,
    clearCopyForwardTimeFrame,
    selectedTimeFrameId,
    setCopyCalendarModalBool,
    monthsFromYears,
    overwrittenMonths,
    copyForwardFunction
}) => {
    const handleClickOutside = () => {
        clearCopyForwardTimeFrame()
        setCopyCalendarModalBool(false)
    }

    const monthDropdownRef = useRef(null)
    useListenForOutsideClicks(monthDropdownRef, () => handleClickOutside())

    const calculateTimeFrame = (monthId) => {
        const index = findIndex(timeFrames, (timeFrame) => timeFrame.id === monthId)
        const startIndex = findIndex(
            timeFrames,
            (startTimeFrame) => startTimeFrame.id === selectedTimeFrameId
        )

        return slice(timeFrames, startIndex + 1, index + 1)
    }

    const selectedClass = (month) => {
        if (
            find(copyForwardTimeFrame, (currentTimeFrame) => currentTimeFrame.id === month) ||
            selectedTimeFrameId === month
        ) {
            return 'month highlighted'
        }

        return ' '
    }

    return (
        <div ref={monthDropdownRef}>
            <Card className="copy-forward-dropdown">
                {map(monthsFromYears, (monthsInYear) => (
                    <div key={monthsInYear.year}>
                        <h3 style={{textAlign: 'center'}}>{monthsInYear.year}</h3>
                        <CardActions>
                            <CardActionButtons>
                                <DataTable>
                                    {map(monthsInYear.months, (month) => (
                                        <div
                                            className={selectedClass(month.id)}
                                            key={month.id}
                                            style={{
                                                display: 'inline-block'
                                            }}
                                        >
                                            <Button
                                                onClick={() => {
                                                    clearCopyForwardTimeFrame()
                                                    map(
                                                        calculateTimeFrame(month.id),
                                                        (timeframe) => {
                                                            setCopyForwardTimeFrame(timeframe)
                                                        }
                                                    )
                                                }}
                                                value={month.id}
                                            >
                                                {month.month}
                                            </Button>
                                        </div>
                                    ))}
                                </DataTable>
                            </CardActionButtons>
                        </CardActions>
                    </div>
                ))}
                <div
                    style={{
                        padding: '8px',
                        paddingTop: '0px'
                    }}
                >
                    <InitiativeCopyForwardMonthConfirmButtonContainer
                        buttonName="Confirm"
                        classNm="copy-forward-button"
                        copyForwardFunction={copyForwardFunction}
                        copyForwardToTimeFrame={copyForwardTimeFrame}
                        disabledBoolean={copyForwardTimeFrame.length === 0}
                        overwrittenMonths={overwrittenMonths}
                        setCopyCalendarModalBool={setCopyCalendarModalBool}
                    />
                </div>
            </Card>
        </div>
    )
}

export default MonthDropdown
