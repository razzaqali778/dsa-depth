import {Dialog, DialogActions, DialogButton, DialogContent, DialogTitle} from '@rmwc/dialog'
import React, {useState} from 'react'

const SaveLockedTimeFrameWarningModal = ({saveLockedTimeFrameData, setSaveLockedTimeFrameData}) => {
    const [open, setOpen] = useState(true)

    return (
        <Dialog
            onClose={(evt) => {
                if (evt.detail.action === 'save') {
                    saveLockedTimeFrameData.saveAction()
                }
                setOpen(false)
                setSaveLockedTimeFrameData({
                    showWarning: false
                })
            }}
            onStateChange={(evt) => {
                if (evt === 'closed') {
                    setOpen(false)
                }
            }}
            open={open}
        >
            <DialogTitle
                style={{
                    textAlign: 'left'
                }}
            >
                Closed time frame modification
            </DialogTitle>
            <DialogContent
                style={{
                    textAlign: 'left'
                }}
            >
                You are modifying a closed time frame. Do you want to proceed?
            </DialogContent>
            <DialogActions>
                <DialogButton action="save" isDefaultAction>
                    Save
                </DialogButton>
                <DialogButton action="cancel" isDefaultAction>
                    Cancel
                </DialogButton>
            </DialogActions>
        </Dialog>
    )
}

export default SaveLockedTimeFrameWarningModal
