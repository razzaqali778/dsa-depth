import '../../styles/containers/DatePickerContainer.scss'
import '../../styles/containers/InitiativeContainer.scss'
import '../../styles/containers/PeopleContainer.scss'

import {connect} from 'react-redux'
import {getTeamInitiatives} from '../../redux/selectors/initiatives'
import {initiativeActions} from '../../redux/actions'
import InitiativeCopyForwardMonthConfirmButton from './InitiativeCopyForwardMonthConfirmButton'

const mapStateToProps = (state) => ({
    teamInitiatives: getTeamInitiatives(state)
})

const mapDispatchToProps = (dispatch) => ({
    copyInitiativesForward: (payload) => dispatch(initiativeActions.copyInitiativesForward(payload))
})

export default connect(mapStateToProps, mapDispatchToProps)(InitiativeCopyForwardMonthConfirmButton)
