import '../../styles/containers/DatePickerContainer.scss'
import {connect} from 'react-redux'
import {
    getCalendarModalBool,
    getEndTimeFrame,
    getStartEndSelector,
    getStartTimeFrame,
    getTimeFrames
} from '../../redux/selectors'
import {timeFrameActions} from '../../redux/actions'
import DatePicker from './DatePicker'

const mapStateToProps = (state) => ({
    timeFrames: getTimeFrames(state),
    endTimeFrame: getEndTimeFrame(state),
    startTimeFrame: getStartTimeFrame(state),
    calendarModalBool: getCalendarModalBool(state),
    startEndSelector: getStartEndSelector(state)
})

const mapDispatchToProps = (dispatch) => ({
    setAppropriateTimeFrames: (chosenTimeFrame, startTimeCode) =>
        dispatch(timeFrameActions.setAppropriateTimeFrames({chosenTimeFrame, startTimeCode})),
    setCalendarModalBool: (boolean) => dispatch(timeFrameActions.setCalendarModalBool(boolean)),
    setStartEndSelector: (boolean) => dispatch(timeFrameActions.setStartEndSelector(boolean))
})

export default connect(mapStateToProps, mapDispatchToProps)(DatePicker)
