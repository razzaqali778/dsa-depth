import {connect} from 'react-redux'
import {establishInitialSortOrderPeople} from '../../redux/sagas/helpers/teamPeople'
import {getSortOrderPreferencePeopleLocal, getUnsavedDataModalBool} from '../../redux/selectors'
import {getTeamForecastedPeople, getTeamPeople} from '../../redux/selectors/people'
import {peopleActions, teamActions, timeFrameActions} from '../../redux/actions'
import UnsavedDataModal from './UnsavedDataModal'

const mapStateToProps = (state) => ({
    unsavedDataModalBool: getUnsavedDataModalBool(state),
    teamPeople: getTeamPeople(state),
    forecastedPeople: getTeamForecastedPeople(state),
    sortOrderPreferencePeopleLocal: getSortOrderPreferencePeopleLocal(state)
})

const mapDispatchToProps = (dispatch) => ({
    setUnsavedDataModalBool: (payload) => dispatch(teamActions.setUnsavedDataModalBool(payload)),
    setSelectedTimeFrameId: (timeframe) =>
        dispatch(timeFrameActions.setSelectedTimeFrameId(timeframe)),
    establishInitialSortOrderPeople: (
        selectedTimeFramePeople,
        sortOrderPreferencePeople,
        forecasted
    ) =>
        dispatch(
            establishInitialSortOrderPeople(
                selectedTimeFramePeople,
                sortOrderPreferencePeople,
                forecasted
            )
        ),
    clearNewPersonData: (people) => dispatch(peopleActions.clearNewPersonData(people)),
    clearNewForecastedPersonData: (people) =>
        dispatch(peopleActions.clearNewForecastedPersonData(people))
})

export default connect(mapStateToProps, mapDispatchToProps)(UnsavedDataModal)
