import {connect} from 'react-redux'
import {getSaveLockedTimeFrameData} from '../../redux/selectors'
import {timeFrameActions} from '../../redux/actions'
import SaveLockedTimeFrameWarningModal from './SaveLockedTimeFrameWarningModal'

const mapStateToProps = (state) => ({
    saveLockedTimeFrameData: getSaveLockedTimeFrameData(state)
})

const mapDispatchToProps = (dispatch) => ({
    setSaveLockedTimeFrameData: (payload) =>
        dispatch(timeFrameActions.setSaveLockedTimeFrameData(payload))
})

export default connect(mapStateToProps, mapDispatchToProps)(SaveLockedTimeFrameWarningModal)
