import React from 'react'
import '../../styles/containers/AppContainerStyles.css'
import {GridCell} from '@rmwc/grid'
import Select from 'react-select-plus'

const TeamFilters = ({
    setSelectedOrgId,
    setSelectedPlatformId,
    setSelectedCommunityId,
    filtersOptions: {orgs, platforms, communities},
    selectedOrgId,
    selectedPlatformId,
    selectedCommunityId
}) => (
    <>
        <GridCell desktop="4" phone="1" tablet="2">
            <Select
                id="orgSelect"
                onChange={(org) => {
                    setSelectedOrgId(org.value)
                    setSelectedPlatformId(undefined)
                    setSelectedCommunityId(undefined)
                }}
                options={orgs}
                placeholder="Filter by org..."
                resetValue
                value={selectedOrgId}
            />
        </GridCell>
        <GridCell desktop="4" phone="1" tablet="3">
            <Select
                id="platformSelect"
                onChange={(platform) => {
                    setSelectedPlatformId(platform?.value)
                    setSelectedCommunityId(undefined)
                }}
                options={platforms}
                placeholder="Filter by platform..."
                resetValue
                value={selectedPlatformId}
            />
        </GridCell>
        <GridCell desktop="4" phone="2" tablet="3">
            <Select
                id="communitySelect"
                onChange={(community) => setSelectedCommunityId(community?.value)}
                options={communities}
                placeholder="Filter by community..."
                resetValue
                value={selectedCommunityId}
            />
        </GridCell>
    </>
)

export default TeamFilters
