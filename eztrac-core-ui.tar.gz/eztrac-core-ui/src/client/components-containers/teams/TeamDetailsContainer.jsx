import {connect} from 'react-redux'
import {
    getFavoriteTeams,
    getSaveLockedTimeFrameData,
    getSelectedCommunityId,
    getSelectedPlatformId,
    getSelectedOrgId,
    getSelectedTeam,
    getSelectedTeamTab,
    getSelectedTimeFrameId,
    getUnsavedChangesBool,
    getUnsavedDataModalBool
} from '../../redux/selectors'
import {getIsShowingHistoricEngagements} from '../../redux/selectors/engagements'
import {
    getSelectedTimeFrameForecastedPeople,
    getSelectedTimeFrameTeamPeople,
    getTeamForecastedPeople,
    getTeamPeople
} from '../../redux/selectors/people'
import {
    getSelectedTimeFrameTeamInitiatives,
    getTeamInitiatives
} from '../../redux/selectors/initiatives'
import {peopleActions, preferencesActions, teamActions, timeFrameActions} from '../../redux/actions'
import TeamDetails from './TeamDetails'
import getCurrentMonthTimeFrame from '../../redux/selectors/getCurrentMonthTimeFrame'
import getFavoriteTeamSelectOptions from '../../redux/selectors/preferences/getFavoriteTeamSelectOptions'
import getGroupedAndSortedEngagements from '../../redux/selectors/engagements/getGroupedAndSortedEngagements'
import getHasManageTeams from '../../redux/selectors/getHasManageTeams'
import getRelevantTimeFrames from '../../redux/selectors/getRelevantTimeFrames'
import getTeamFiltersOptions from '../../redux/selectors/teams/getTeamFiltersOptions'

const mapStateToProps = (state) => ({
    teamSelectOptions: getFavoriteTeamSelectOptions(state),
    teamFiltersOptions: getTeamFiltersOptions(state),
    favoriteTeams: getFavoriteTeams(state),
    selectedTeamTab: getSelectedTeamTab(state),
    selectedTeam: getSelectedTeam(state),
    selectedCommunityId: getSelectedCommunityId(state),
    selectedPlatformId: getSelectedPlatformId(state),
    selectedOrgId: getSelectedOrgId(state),
    hasManageTeams: getHasManageTeams(state),
    currentMonth: getCurrentMonthTimeFrame(state),
    teamInitiatives: getTeamInitiatives(state),
    selectedTimeFrameId: getSelectedTimeFrameId(state),
    selectedTimeFrameInitiatives: getSelectedTimeFrameTeamInitiatives(state),
    groupedAndSortedEngagements: getGroupedAndSortedEngagements(state),
    isShowingHistoricEngagements: getIsShowingHistoricEngagements(state),
    teamPeople: getTeamPeople(state),
    relevantTimeFrames: getRelevantTimeFrames(state),
    selectedTimeFrameTeamPeople: getSelectedTimeFrameTeamPeople(state),
    unsavedChangesBool: getUnsavedChangesBool(state),
    unsavedDataModalBool: getUnsavedDataModalBool(state),
    saveLockedTimeFrameData: getSaveLockedTimeFrameData(state),
    teamForecastedPeople: getTeamForecastedPeople(state),
    selectedTimeFrameForecastedPeople: getSelectedTimeFrameForecastedPeople(state)
})

const mapDispatchToProps = (dispatch) => ({
    setSelectedTeam: (team) => dispatch(teamActions.setSelectedTeam(team)),
    setSelectedCommunityId: (community) => dispatch(teamActions.setSelectedCommunityId(community)),
    setSelectedPlatformId: (platform) => dispatch(teamActions.setSelectedPlatformId(platform)),
    setSelectedOrgId: (org) => dispatch(teamActions.setSelectedOrgId(org)),
    setSelectedTeamTab: (tab) => dispatch(preferencesActions.setSelectedTeamTab(tab)),
    favoriteButtonClickedSaga: (value) => dispatch(preferencesActions.favoriteButtonClicked(value)),
    setSelectedTimeFrameId: (timeFrame) =>
        dispatch(timeFrameActions.setSelectedTimeFrameId(timeFrame)),
    setSelectedTimeFrameTeamPeople: (people) =>
        dispatch(peopleActions.setSelectedTimeFrameTeamPeople(people)),
    setUnsavedDataModalBool: (team) => dispatch(teamActions.setUnsavedDataModalBool(team))
})

export default connect(mapStateToProps, mapDispatchToProps)(TeamDetails)
