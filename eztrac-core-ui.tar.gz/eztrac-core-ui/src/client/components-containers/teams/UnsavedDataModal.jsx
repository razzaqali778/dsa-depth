import {Dialog, DialogActions, DialogButton, DialogContent, DialogTitle} from '@rmwc/dialog'
import React, {useState} from 'react'

const UnsavedDataModal = ({setUnsavedDataModalBool}) => {
    const [open, setOpen] = useState(true)

    return (
        <Dialog
            onClose={(evt) => {
                if (evt.detail.action === 'accept') {
                    setOpen(false)
                }
                setOpen(false)
            }}
            onStateChange={(evt) => {
                if (evt === 'closed') {
                    setUnsavedDataModalBool(false)
                }
            }}
            open={open}
        >
            <DialogTitle
                style={{
                    textAlign: 'left'
                }}
            >
                Unsaved Data
            </DialogTitle>
            <DialogContent
                style={{
                    textAlign: 'left'
                }}
            >
                You have unsaved data, please <b>save</b> before continuing.
            </DialogContent>
            <DialogActions>
                <DialogButton action="accept" isDefaultAction>
                    Go Back
                </DialogButton>
            </DialogActions>
        </Dialog>
    )
}

export default UnsavedDataModal
