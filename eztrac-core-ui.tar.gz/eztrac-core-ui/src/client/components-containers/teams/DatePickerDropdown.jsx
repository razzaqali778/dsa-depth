import {Button} from '@rmwc/button'
import {Card, CardActionButtons, CardActions} from '@rmwc/card'
import {DataTable} from '@rmwc/data-table'
import {filter, find, includes, map, uniq} from 'lodash'
import React, {useRef} from 'react'
import {useListenForOutsideClicks} from '../utils/useListenForOutsideClicks'

const DatePickerDropdown = ({
    endTimeFrame,
    startTimeFrame,
    calendarModalBool,
    setCalendarModalBool,
    startEndSelector,
    setAppropriateTimeFrames,
    timeFrames
}) => {
    const datePickerRef = useRef(null)
    useListenForOutsideClicks(datePickerRef, () => setCalendarModalBool(false))

    const years = uniq(map(timeFrames, (timeFrame) => timeFrame.name.split(' ')[1]))
    const dates = map(years, (year) => ({
        year,
        months: filter(
            map(timeFrames, (timeFrame) =>
                includes(timeFrame.name, year)
                    ? {
                          month: timeFrame.name.split(' ')[0],
                          id: timeFrame.id,
                          isActive: timeFrame.isActive,
                          startTime: timeFrame.startDate
                      }
                    : undefined
            ),
            undefined
        )
    }))

    const validDate = filter(
        map(dates, (year) => (find(year.months, {isActive: true}) ? year.year : undefined)),
        undefined
    )

    const tooltip = (isActive) => {
        if (isActive) {
            return startEndSelector ? 'Select Start' : 'Select End'
        }

        return 'Inactive'
    }

    const selectedClass = (startCode, isActive) => {
        if (startTimeFrame.startCode === startCode || endTimeFrame.startCode === startCode) {
            return 'month selected'
        } else if (startTimeFrame.startCode < startCode && startCode < endTimeFrame.startCode) {
            return 'month highlighted'
        } else if (isActive) {
            if (startEndSelector && startCode > endTimeFrame.startCode) {
                return 'month outOfScope'
            } else if (!startEndSelector && startCode < startTimeFrame.startCode) {
                return 'month outOfScope'
            }
        } else if (!isActive) {
            return 'month inactive'
        }

        return 'month'
    }

    const handleDateSelect = (id, startTime) => {
        setAppropriateTimeFrames(id, startTime)
        setCalendarModalBool(false)
    }

    return (
        <div ref={datePickerRef}>
            <Card
                style={{
                    maxWidth: '275px',
                    position: 'absolute',
                    zIndex: '1',
                    visibility: calendarModalBool ? 'visible' : 'hidden'
                }}
            >
                {map(
                    dates,
                    (date) =>
                        includes(validDate, date.year) && (
                            <div key={date.year}>
                                <h3 className="year">{date.year}</h3>
                                <CardActions>
                                    <CardActionButtons>
                                        <DataTable>
                                            {map(date.months, (month) => (
                                                <div
                                                    className={selectedClass(
                                                        month.startTime,
                                                        month.isActive
                                                    )}
                                                    key={month.id}
                                                >
                                                    <Button
                                                        disabled={
                                                            !month.isActive ||
                                                            (startEndSelector
                                                                ? month.startTime >
                                                                  endTimeFrame.startCode
                                                                : month.startTime <
                                                                  startTimeFrame.startCode)
                                                        }
                                                        onClick={() =>
                                                            handleDateSelect(
                                                                month.id,
                                                                month.startTime
                                                            )
                                                        }
                                                        value={month.id}
                                                    >
                                                        {month.month}
                                                        <span className="tooltip">
                                                            {tooltip(month.isActive)}
                                                        </span>
                                                    </Button>
                                                </div>
                                            ))}
                                        </DataTable>
                                    </CardActionButtons>
                                </CardActions>
                            </div>
                        )
                )}
            </Card>
        </div>
    )
}

export default DatePickerDropdown
