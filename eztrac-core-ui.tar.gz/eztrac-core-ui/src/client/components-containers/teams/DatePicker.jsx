import {Button} from '@rmwc/button'
import {Icon} from '@rmwc/icon'
import {find} from 'lodash'
import React from 'react'
import DatePickerDropdownContainer from './DatePickerDropdownContainer'

const DatePicker = ({
    timeFrames,
    endTimeFrame,
    startTimeFrame,
    calendarModalBool,
    setCalendarModalBool,
    setStartEndSelector
}) => {
    const changeDate = (name) => {
        if (name === 'startDateButton') {
            setStartEndSelector(true)
        } else {
            setStartEndSelector(false)
        }
        setCalendarModalBool(!calendarModalBool)
    }

    const start = find(timeFrames, ['id', startTimeFrame.id])
    const end = find(timeFrames, ['id', endTimeFrame.id])

    return timeFrames.length > 0 ? (
        <div className="calendar">
            <div className="headerDiv" style={{backgroundColor: calendarModalBool && '#E8F2F1'}}>
                <span>
                    {start && (
                        <Button
                            className="dateButton"
                            onClick={() => changeDate('startDateButton')}
                        >
                            {start.name}
                            <Icon
                                icon="keyboard_arrow_down"
                                onClick={() => changeDate('startDateButton')}
                            />
                        </Button>
                    )}
                    &nbsp;&nbsp;&nbsp; to &nbsp;&nbsp;&nbsp;
                    {end && (
                        <Button className="dateButton" onClick={() => changeDate('endDateButton')}>
                            {end.name}
                            <Icon icon="keyboard_arrow_down" />
                        </Button>
                    )}
                </span>
            </div>
            <div>{calendarModalBool && <DatePickerDropdownContainer />}</div>
        </div>
    ) : (
        <div />
    )
}

export default DatePicker
