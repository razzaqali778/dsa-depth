import {connect} from 'react-redux'
import {getCopyCalendarModalBool, getSelectedTimeFrameId} from '../../redux/selectors'
import {getCopyForwardTimeFrame, getTeamInitiatives} from '../../redux/selectors/initiatives'
import {initiativeActions, timeFrameActions} from '../../redux/actions'
import MonthDropdown from './MonthDropdown'
import getMonthsFromYears from '../../redux/selectors/initiatives/getMonthsFromYears'
import getRelativeFutureTimeFrames from '../../redux/selectors/getRelativeFutureTimeFrames'

const mapStateToProps = (state) => ({
    copyCalendarModalBool: getCopyCalendarModalBool(state),
    timeFrames: getRelativeFutureTimeFrames(state),
    copyForwardTimeFrame: getCopyForwardTimeFrame(state),
    teamInitiatives: getTeamInitiatives(state),
    selectedTimeFrameId: getSelectedTimeFrameId(state),
    monthsFromYears: getMonthsFromYears(state)
})

const mapDispatchToProps = (dispatch) => ({
    setCopyForwardTimeFrame: (payload) =>
        dispatch(initiativeActions.setCopyForwardTimeFrame(payload)),
    clearCopyForwardTimeFrame: (payload) =>
        dispatch(initiativeActions.clearCopyForwardTimeFrame(payload)),
    setCopyCalendarModalBool: (payload) =>
        dispatch(timeFrameActions.setCopyCalendarModalBool(payload))
})

export default connect(mapStateToProps, mapDispatchToProps)(MonthDropdown)
