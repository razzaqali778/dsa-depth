import {Dialog, DialogActions, DialogButton, DialogContent, DialogTitle} from '@rmwc/dialog'
import React from 'react'

function ConfirmDialog({
    open,
    setOpen,
    copyForwardFunction,
    copyForwardToTimeFrame,
    overwrittenMonths,
    setCopyCalendarModalBool,
    copyForwardFromTimeFrame
}) {
    return (
        <Dialog
            onClose={(evt) => {
                if (evt.detail.action === 'accept') {
                    setOpen(false)
                    copyForwardFunction({copyForwardFromTimeFrame, copyForwardToTimeFrame})
                }
                setOpen(false)
            }}
            onStateChange={(evt) => {
                if (setCopyCalendarModalBool && evt === 'closed') {
                    setCopyCalendarModalBool(false)
                }
            }}
            open={open}
        >
            <DialogTitle
                style={{
                    textAlign: 'left'
                }}
            >
                Warning:
            </DialogTitle>
            <DialogContent
                style={{
                    textAlign: 'left'
                }}
            >
                Overwriting data in <b>{overwrittenMonths && overwrittenMonths.join(', ')}</b>.
                <br />
                Click Confirm to continue.
            </DialogContent>
            <DialogActions>
                <DialogButton action="close">Cancel</DialogButton>
                <DialogButton action="accept" isDefaultAction>
                    Confirm
                </DialogButton>
            </DialogActions>
        </Dialog>
    )
}

export default ConfirmDialog
