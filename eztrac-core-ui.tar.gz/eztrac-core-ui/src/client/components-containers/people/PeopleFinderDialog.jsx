import {Dialog, DialogButton, DialogContent} from '@rmwc/dialog'
import React from 'react'
import PeopleFinderContainer from './PeopleFinderContainer'

const PeopleFinderDialog = ({isPeopleModifyFinderOpen, setIsPeopleModifyFinderOpen}) => (
    <Dialog
        fullwidth="true"
        onClose={() => setIsPeopleModifyFinderOpen(false)}
        open={isPeopleModifyFinderOpen}
    >
        <DialogContent>
            <PeopleFinderContainer />
        </DialogContent>
        <DialogButton onClick={() => setIsPeopleModifyFinderOpen(false)}>close</DialogButton>
    </Dialog>
)

export default PeopleFinderDialog
