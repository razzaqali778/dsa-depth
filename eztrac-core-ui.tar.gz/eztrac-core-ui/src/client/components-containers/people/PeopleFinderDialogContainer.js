import '../../styles/containers/PeopleContainer.scss'
import {connect} from 'react-redux'
import {getIsPeopleModifyFinderOpen} from '../../redux/selectors/people'
import PeopleFinderDialog from './PeopleFinderDialog'
import getSelectableInitiatives from '../../redux/selectors/initiatives/getSelectableInitiatives'
import peopleActions from '../../redux/actions/peopleActions'

const mapStateToProps = (state) => ({
    isPeopleModifyFinderOpen: getIsPeopleModifyFinderOpen(state),
    selectableInitiatives: getSelectableInitiatives(state)
})

const mapDispatchToProps = (dispatch) => ({
    setIsPeopleModifyFinderOpen: (isPeopleModifyFinderOpen) =>
        dispatch(peopleActions.setIsPeopleModifyFinderOpen(isPeopleModifyFinderOpen))
})

export default connect(mapStateToProps, mapDispatchToProps)(PeopleFinderDialog)
