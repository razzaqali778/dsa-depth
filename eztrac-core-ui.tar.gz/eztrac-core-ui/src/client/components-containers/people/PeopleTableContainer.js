import {connect} from 'react-redux'
import {establishInitialSortOrderPeople} from '../../redux/sagas/helpers/teamPeople'
import {
    getAllActivePeople,
    getNewPersonData,
    getPersonProfileDetails,
    getSelectedTimeFrameForecastedPeople,
    getSelectedTimeFrameTeamPeople,
    getTeamForecastedPeople
} from '../../redux/selectors/people'
import {
    getSelectedTimeFrameId,
    getSortOrderPreferencePeopleLocal,
    getTimeFrames
} from '../../redux/selectors'
import {peopleActions, timeFrameActions} from '../../redux/actions'
import getCurrentMonthTimeFrame from '../../redux/selectors/getCurrentMonthTimeFrame'
import getIsAdmin from '../../redux/selectors/getIsAdmin'
import getRelevantTimeFrames from '../../redux/selectors/getRelevantTimeFrames'
import getSelectedTimeFrame from '../../redux/selectors/getSelectedTimeFrame'
import peopleTable from './PeopleTable'
import preferencesActions from '../../redux/actions/preferencesActions'

const mapStateToProps = (state) => ({
    relevantTimeFrames: getRelevantTimeFrames(state),
    selectedTimeFrameId: getSelectedTimeFrameId(state),
    selectedTimeFrame: getSelectedTimeFrame(state),
    newPersonData: getNewPersonData(state),
    selectedTimeFrameTeamPeople: getSelectedTimeFrameTeamPeople(state),
    forecastedPeople: getTeamForecastedPeople(state),
    selectedTimeFrameForecastedPeople: getSelectedTimeFrameForecastedPeople(state),
    sortOrderPreferencePeopleLocal: getSortOrderPreferencePeopleLocal(state),
    allActivePeople: getAllActivePeople(state),
    currentTimeFrame: getCurrentMonthTimeFrame(state),
    timeFrames: getTimeFrames(state),
    isAdmin: getIsAdmin(state),
    userProfileDetails: getPersonProfileDetails(state)
})
const mapDispatchToProps = (dispatch) => ({
    setSelectedTimeFrameId: (timeFrame) =>
        dispatch(timeFrameActions.setSelectedTimeFrameId(timeFrame)),
    setIsPeopleModifyFinderOpen: (isPeopleModifyFinderOpen) =>
        dispatch(peopleActions.setIsPeopleModifyFinderOpen(isPeopleModifyFinderOpen)),
    setSelectedTimeFrameTeamPeople: (people) =>
        dispatch(peopleActions.setSelectedTimeFrameTeamPeople(people)),
    setNewPersonData: (person) => dispatch(peopleActions.setNewPersonData(person)),
    clearNewPersonData: (person) => dispatch(peopleActions.clearNewPersonData(person)),
    deletePersonFromTeamState: (person) =>
        dispatch(peopleActions.deletePersonFromTeamState(person)),
    setSelectedTimeFrameForecastedPeople: (forecastedPeople) =>
        dispatch(peopleActions.setSelectedTimeFrameForecastedPeople(forecastedPeople)),
    setSortOrderPreferencePeopleLocal: (payload) =>
        dispatch(preferencesActions.setSortOrderPreferencePeopleLocal(payload)),
    establishInitialSortOrderPeople: (selectedTeamPeople, sortOrderPreferencePeople) =>
        dispatch(establishInitialSortOrderPeople(selectedTeamPeople, sortOrderPreferencePeople)),
    addNewPerson: (person) => dispatch(peopleActions.addNewPerson(person)),
    userDetailsHoveredSaga: (person) => dispatch(peopleActions.fetchUserProfileDetails(person))
})

export default connect(mapStateToProps, mapDispatchToProps)(peopleTable)
