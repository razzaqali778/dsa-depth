import '../../styles/containers/PeopleContainer.scss'
import {connect} from 'react-redux'
import {establishInitialSortOrder} from '../../redux/sagas/helpers/teamInitiatives'
import {establishInitialSortOrderPeople} from '../../redux/sagas/helpers/teamPeople'
import {
    getCopyCalendarModalBool,
    getSelectedTimeFrameId,
    getSelectedTimeFrameTeamCost,
    getSortOrderPreferenceLocal,
    getSortOrderPreferencePeopleLocal,
    getTeamCostData,
    getTimeFrames,
    getUnsavedDataModalBool
} from '../../redux/selectors'
import {
    getSelectedTimeFrameForecastedPeople,
    getSelectedTimeFrameTeamPeople,
    getTeamForecastedPeople,
    getTeamPeople
} from '../../redux/selectors/people'
import {getTeamInitiatives} from '../../redux/selectors/initiatives'
import {initiativeActions, peopleActions, teamActions, timeFrameActions} from '../../redux/actions'
import PeopleTab from './PeopleTab'
import getCurrentMonthTimeFrame from '../../redux/selectors/getCurrentMonthTimeFrame'
import getIsAdmin from '../../redux/selectors/getIsAdmin'
import getOverwrittenPeopleMonths from '../../redux/selectors/getOverwrittenPeopleMonths'
import getRelevantTimeFrames from '../../redux/selectors/getRelevantTimeFrames'
import getSelectedTimeFrame from '../../redux/selectors/getSelectedTimeFrame'

const mapStateToProps = (state) => ({
    selectedTimeFrameId: getSelectedTimeFrameId(state),
    timeFrames: getTimeFrames(state),
    selectedTimeFrameForecastedPeople: getSelectedTimeFrameForecastedPeople(state),
    forecastedPeople: getTeamForecastedPeople(state),
    teamPeople: getTeamPeople(state),
    selectedTimeFrameTeamPeople: getSelectedTimeFrameTeamPeople(state),
    relevantTimeFrames: getRelevantTimeFrames(state),
    sortOrderPreferencePeopleLocal: getSortOrderPreferencePeopleLocal(state),
    unsavedDataModalBool: getUnsavedDataModalBool(state),
    teamInitiatives: getTeamInitiatives(state),
    sortOrderPreference: getSortOrderPreferenceLocal(state),
    teamCostData: getTeamCostData(state),
    currentMonthTimeFrame: getCurrentMonthTimeFrame(state),
    selectedTimeFrame: getSelectedTimeFrame(state),
    copyCalendarModalBool: getCopyCalendarModalBool(state),
    overwrittenMonths: getOverwrittenPeopleMonths(state),
    selectedTimeFrameTeamCost: getSelectedTimeFrameTeamCost(state),
    isAdmin: getIsAdmin(state)
})

const mapDispatchToProps = (dispatch) => ({
    setSelectedTimeFrameForecastedPeople: (forecastedPeople) =>
        dispatch(peopleActions.setSelectedTimeFrameForecastedPeople(forecastedPeople)),
    setSelectedTimeFrameTeamPeople: (people) =>
        dispatch(peopleActions.setSelectedTimeFrameTeamPeople(people)),
    setSelectedTimeFrameId: (timeframe) =>
        dispatch(timeFrameActions.setSelectedTimeFrameId(timeframe)),
    clearNewPersonData: (people) => dispatch(peopleActions.clearNewPersonData(people)),
    clearNewForecastedPersonData: (people) =>
        dispatch(peopleActions.clearNewForecastedPersonData(people)),
    establishInitialSortOrderPeople: (
        selectedTimeFramePeople,
        sortOrderPreferencePeople,
        forecasted
    ) =>
        dispatch(
            establishInitialSortOrderPeople(
                selectedTimeFramePeople,
                sortOrderPreferencePeople,
                forecasted
            )
        ),
    setUnsavedDataModalBool: (team) => dispatch(teamActions.setUnsavedDataModalBool(team)),
    setSelectedTimeFrameTeamCost: (cost) =>
        dispatch(teamActions.setSelectedTimeFrameTeamCost(cost)),
    clearNewInitiativeData: () => dispatch(initiativeActions.clearNewInitiativeData()),
    establishInitialSortOrder: (selectedTeamInitiatives, sortOrderPreference) =>
        dispatch(establishInitialSortOrder(selectedTeamInitiatives, sortOrderPreference)),
    updatePeople: (people) => dispatch(peopleActions.updatePeople(people)),
    setCopyCalendarModalBool: (payload) =>
        dispatch(timeFrameActions.setCopyCalendarModalBool(payload)),
    setSaveLockedTimeFrameData: (payload) =>
        dispatch(timeFrameActions.setSaveLockedTimeFrameData(payload))
})

export default connect(mapStateToProps, mapDispatchToProps)(PeopleTab)
