import {map, sortBy} from 'lodash'
import React from 'react'
import ReactTable from 'react-table'
import selectTableHOC from 'react-table/lib/hoc/selectTable'
import {isPersonSelected} from '../../redux/utils/newInitiative'

const SelectTable = selectTableHOC(ReactTable)

const addParticipationPct = (person) => {
    const updatedRow = {
        ...person,
        participationPct: 100
    }

    return updatedRow
}

const columns = [
    {
        Header: 'Name',
        accessor: 'nameId',
        minWidth: 350
    }
]

const processData = (allPeople) =>
    map(sortBy(allPeople, ['personName']), (person) => ({
        key: person.personId,
        nameId: `${person.personName} (${person.personId})`,
        data: person
    }))
const defaultFilterMethod = (filterObj, row) => {
    const id = filterObj.pivotId || filterObj.id
    const searchString = String(filterObj.value).toLowerCase()

    return row[id] !== undefined
        ? String(row[id]).toLowerCase().startsWith(searchString) ||
              String(row[id]).toLowerCase().includes(searchString)
        : true
}

const PeopleFinder = ({
    allPeople,
    addNewPerson,
    selectedTimeFrameTeamPeople,
    deletePersonFromTeamState,
    clearNewPersonData
}) => (
    <SelectTable
        columns={columns}
        data={processData(allPeople)}
        defaultFilterMethod={defaultFilterMethod}
        defaultPageSize={10}
        filterable
        getTrProps={(state, rowInfo) => {
            if (
                rowInfo !== undefined &&
                isPersonSelected(rowInfo.original.key, selectedTimeFrameTeamPeople)
            ) {
                return {
                    style: {
                        background: 'rgba(229, 229, 229, .7)'
                    }
                }
            }

            return {}
        }}
        isSelected={(key) => isPersonSelected(key, selectedTimeFrameTeamPeople)}
        keyField="key"
        resizable={false}
        selectType="checkbox"
        showPageSizeOptions={false}
        toggleSelection={(_, __, row) => {
            if (isPersonSelected(row.key, selectedTimeFrameTeamPeople)) {
                deletePersonFromTeamState(row.data)
            } else {
                addNewPerson(addParticipationPct(row.data))
                clearNewPersonData()
            }
        }}
    />
)

export default PeopleFinder
