import '../../styles/containers/PeopleContainer.scss'
import {connect} from 'react-redux'
import {getAllPeople, getSelectedTimeFrameTeamPeople} from '../../redux/selectors/people'
import PeopleFinder from './PeopleFinder'
import peopleActions from '../../redux/actions/peopleActions'

const mapStateToProps = (state) => ({
    allPeople: getAllPeople(state),
    selectedTimeFrameTeamPeople: getSelectedTimeFrameTeamPeople(state)
})

const mapDispatchToProps = (dispatch) => ({
    addNewPerson: (person) => dispatch(peopleActions.addNewPerson(person)),
    deletePersonFromTeamState: (person) =>
        dispatch(peopleActions.deletePersonFromTeamState(person)),
    clearNewPersonData: (person) => dispatch(peopleActions.clearNewPersonData(person))
})

export default connect(mapStateToProps, mapDispatchToProps)(PeopleFinder)
