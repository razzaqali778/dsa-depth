import {connect} from 'react-redux'
import {
    getAllCostGroups,
    getAllRates,
    getNewForecastedPersonData,
    getSelectedTimeFrameForecastedPeople,
    getTeamPeople
} from '../../redux/selectors/people'
import {getSortOrderPreferencePeopleLocal} from '../../redux/selectors'
import {peopleActions, timeFrameActions} from '../../redux/actions'
import forecastedPeopleTable from './ForecastedPeopleTable'
import getIsAdmin from '../../redux/selectors/getIsAdmin'
import getRelevantTimeFrames from '../../redux/selectors/getRelevantTimeFrames'
import getSelectedTimeFrame from '../../redux/selectors/getSelectedTimeFrame'
import preferencesActions from '../../redux/actions/preferencesActions'

const mapStateToProps = (state) => ({
    teamPeople: getTeamPeople(state),
    relevantTimeFrames: getRelevantTimeFrames(state),
    selectedTimeFrame: getSelectedTimeFrame(state),
    selectedTimeFrameForecastedPeople: getSelectedTimeFrameForecastedPeople(state),
    allRates: getAllRates(state),
    allCostGroups: getAllCostGroups(state),
    newForecastedPersonData: getNewForecastedPersonData(state),
    sortOrderPreferencePeopleLocal: getSortOrderPreferencePeopleLocal(state),
    isAdmin: getIsAdmin(state)
})

const mapDispatchToProps = (dispatch) => ({
    setSelectedTimeFrameId: (timeFrame) =>
        dispatch(timeFrameActions.setSelectedTimeFrameId(timeFrame)),
    setSelectedTimeFrameTeamPeople: (people) =>
        dispatch(peopleActions.setSelectedTimeFrameTeamPeople(people)),
    setSelectedTimeFrameForecastedPeople: (forecastedPeople) =>
        dispatch(peopleActions.setSelectedTimeFrameForecastedPeople(forecastedPeople)),
    deleteForecastedPersonFromTeamState: (person) =>
        dispatch(peopleActions.deleteForecastedPersonFromTeamState(person)),
    setNewForecastedPersonData: (person) =>
        dispatch(peopleActions.setNewForecastedPersonData(person)),
    addNewForecastedPersonFromState: (person) =>
        dispatch(peopleActions.addNewForecastedPersonFromState(person)),
    setSortOrderPreferencePeopleLocal: (payload) =>
        dispatch(preferencesActions.setSortOrderPreferencePeopleLocal(payload))
})

export default connect(mapStateToProps, mapDispatchToProps)(forecastedPeopleTable)
