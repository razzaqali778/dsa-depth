import {Button} from '@rmwc/button'
import {
    DataTable,
    DataTableBody,
    DataTableCell,
    DataTableContent,
    DataTableHead,
    DataTableHeadCell,
    DataTableRow
} from '@rmwc/data-table'
import {Icon} from '@rmwc/icon'
import {cloneDeep, filter, find, isEmpty, map, sortBy} from 'lodash'
import React from 'react'
import Select from 'react-select'
import {canEditTimeFrame} from '../utils/canEditTimeFrame'
import {setSorting} from '../../utils/sortingHelper'
import {
    validateNewForecastedPerson,
    validateNumberOfPeople
} from '../../redux/utils/validatorsForPeople'

const sortDir = [null, -1, 1]

const mapThroughOptions = (allOptions) => {
    const activeOptions = filter(allOptions, ['isActive', true])
    const mapOptions = map(activeOptions, (option) => ({value: option.id, label: `${option.name}`}))

    return sortBy(mapOptions, 'label')
}

const getName = (data, id) => {
    const matchingElement = find(data, ['id', id])

    return matchingElement ? matchingElement.name : id
}

const ForecastedPeopleTable = ({
    selectedTimeFrameForecastedPeople,
    setSelectedTimeFrameForecastedPeople,
    setSortOrderPreferencePeopleLocal,
    sortOrderPreferencePeopleLocal,
    allRates,
    allCostGroups,
    newForecastedPersonData,
    setNewForecastedPersonData,
    addNewForecastedPersonFromState,
    deleteForecastedPersonFromTeamState,
    selectedTimeFrame,
    isAdmin
}) => {
    const allowEditing = canEditTimeFrame(selectedTimeFrame, isAdmin)

    return (
        <DataTable style={{width: '100%', marginLeft: '10px'}}>
            <DataTableContent style={{width: '100%'}}>
                <DataTableHead>
                    <DataTableRow>
                        <DataTableCell>Placeholders</DataTableCell>
                    </DataTableRow>
                    {allowEditing && (
                        <DataTableRow>
                            <DataTableCell style={{width: '30%'}}>
                                <Select
                                    isSearchable
                                    onChange={(evt) => {
                                        const newForecastedPerson =
                                            cloneDeep(newForecastedPersonData)
                                        newForecastedPerson.rateId = evt.value
                                        newForecastedPerson.rateName = evt.label
                                        setNewForecastedPersonData(newForecastedPerson)
                                    }}
                                    onKeyDown={(evt) => {
                                        if (
                                            evt.key === 'Enter' &&
                                            !validateNewForecastedPerson(
                                                newForecastedPersonData,
                                                selectedTimeFrameForecastedPeople
                                            )
                                        ) {
                                            addNewForecastedPersonFromState()
                                        }
                                    }}
                                    options={mapThroughOptions(allRates)}
                                    placeholder="Select Rate"
                                    value={
                                        newForecastedPersonData.rateName
                                            ? {label: newForecastedPersonData.rateName}
                                            : null
                                    }
                                />
                            </DataTableCell>
                            <DataTableCell style={{width: '70%'}}>
                                <Select
                                    isSearchable
                                    onChange={(evt) => {
                                        const newForecastedPerson =
                                            cloneDeep(newForecastedPersonData)
                                        newForecastedPerson.costGroupId = evt.value
                                        newForecastedPerson.costGroupName = evt.label
                                        setNewForecastedPersonData(newForecastedPerson)
                                    }}
                                    onKeyDown={(evt) => {
                                        if (
                                            evt.key === 'Enter' &&
                                            !validateNewForecastedPerson(
                                                newForecastedPersonData,
                                                selectedTimeFrameForecastedPeople
                                            )
                                        ) {
                                            addNewForecastedPersonFromState()
                                        }
                                    }}
                                    options={mapThroughOptions(allCostGroups)}
                                    placeholder="Select Cost Group"
                                    value={
                                        newForecastedPersonData.costGroupName
                                            ? {label: newForecastedPersonData.costGroupName}
                                            : null
                                    }
                                />
                            </DataTableCell>
                            <DataTableCell style={{width: '20%'}}>
                                <Button
                                    disabled={validateNewForecastedPerson(
                                        newForecastedPersonData,
                                        selectedTimeFrameForecastedPeople
                                    )}
                                    onClick={() => {
                                        if (
                                            !validateNewForecastedPerson(
                                                newForecastedPersonData,
                                                selectedTimeFrameForecastedPeople
                                            )
                                        ) {
                                            addNewForecastedPersonFromState()
                                        }
                                    }}
                                    raised
                                >
                                    Add Rate
                                </Button>
                            </DataTableCell>
                        </DataTableRow>
                    )}
                    <DataTableRow>
                        <DataTableHeadCell
                            onClick={() => {
                                if (!isEmpty(selectedTimeFrameForecastedPeople)) {
                                    setSorting(
                                        setSortOrderPreferencePeopleLocal,
                                        setSelectedTimeFrameForecastedPeople,
                                        selectedTimeFrameForecastedPeople,
                                        sortOrderPreferencePeopleLocal.rateNum,
                                        'rateNum',
                                        'rateId',
                                        {
                                            ...sortOrderPreferencePeopleLocal,
                                            rateNum: 0,
                                            costGroupNum: 0,
                                            numberOfPeopleNum: 0
                                        }
                                    )
                                }
                            }}
                            sort={sortDir[sortOrderPreferencePeopleLocal.rateNum]}
                        >
                            Rate
                        </DataTableHeadCell>
                        <DataTableHeadCell
                            onClick={() => {
                                if (!isEmpty(selectedTimeFrameForecastedPeople)) {
                                    setSorting(
                                        setSortOrderPreferencePeopleLocal,
                                        setSelectedTimeFrameForecastedPeople,
                                        selectedTimeFrameForecastedPeople,
                                        sortOrderPreferencePeopleLocal.costGroupNum,
                                        'costGroupNum',
                                        'costGroupId',
                                        {
                                            ...sortOrderPreferencePeopleLocal,
                                            rateNum: 0,
                                            costGroupNum: 0,
                                            numberOfPeopleNum: 0
                                        }
                                    )
                                }
                            }}
                            sort={sortDir[sortOrderPreferencePeopleLocal.costGroupNum]}
                        >
                            Cost Group
                        </DataTableHeadCell>
                        <DataTableHeadCell
                            alignEnd
                            onClick={() => {
                                if (!isEmpty(selectedTimeFrameForecastedPeople)) {
                                    setSorting(
                                        setSortOrderPreferencePeopleLocal,
                                        setSelectedTimeFrameForecastedPeople,
                                        selectedTimeFrameForecastedPeople,
                                        sortOrderPreferencePeopleLocal.numberOfPeopleNum,
                                        'numberOfPeopleNum',
                                        'numberOfPeople',
                                        {
                                            ...sortOrderPreferencePeopleLocal,
                                            rateNum: 0,
                                            costGroupNum: 0,
                                            numberOfPeopleNum: 0
                                        }
                                    )
                                }
                            }}
                            sort={sortDir[sortOrderPreferencePeopleLocal.numberOfPeopleNum]}
                        >
                            {' '}
                            Number of People
                        </DataTableHeadCell>
                        <DataTableHeadCell />
                    </DataTableRow>
                </DataTableHead>
                <DataTableBody>
                    {map(selectedTimeFrameForecastedPeople, (forecastedPerson, index) => (
                        <DataTableRow
                            key={`${forecastedPerson.costGroupId} ${forecastedPerson.rateId}`}
                            style={{width: '100%'}}
                        >
                            <DataTableCell>
                                {getName(allRates, forecastedPerson.rateId)}
                            </DataTableCell>
                            <DataTableCell>
                                {getName(allCostGroups, forecastedPerson.costGroupId)}
                            </DataTableCell>
                            <DataTableCell className="table-input input-table-column-numbers">
                                <input
                                    onChange={(evt) => {
                                        if (validateNumberOfPeople(evt.target.value)) {
                                            const updatedNumPeople = cloneDeep(
                                                selectedTimeFrameForecastedPeople
                                            )
                                            updatedNumPeople[index].numberOfPeople =
                                                evt.target.value
                                            setSelectedTimeFrameForecastedPeople(updatedNumPeople)
                                        }
                                    }}
                                    type="text"
                                    value={
                                        `${selectedTimeFrameForecastedPeople[index].numberOfPeople}` ||
                                        ''
                                    }
                                />
                            </DataTableCell>
                            <DataTableCell>
                                <Icon
                                    className="delete-person-button"
                                    icon="delete_forever"
                                    onClick={() => {
                                        deleteForecastedPersonFromTeamState(forecastedPerson)
                                    }}
                                />
                            </DataTableCell>
                        </DataTableRow>
                    ))}
                </DataTableBody>
            </DataTableContent>
        </DataTable>
    )
}

export default ForecastedPeopleTable
