import React from 'react'

const entitlementUrl = `https://${window.phoenix.serviceBindings['phoenix-home']}/entitlements/eztrac`

const InvalidEntitlement = (props) => (
    <div className="text-center">
        <div className="row">
            <div className="col-lg-12">
                <h2>
                    You do not have access to Ez-Trac <i>{props.missingEntitlement}</i>
                </h2>
            </div>
        </div>
        <div className="row">
            <div className="col-lg-12">
                <h4>
                    Please <a href={entitlementUrl}>request</a> access to the proper entitlement(s).
                </h4>
            </div>
        </div>
    </div>
)

export default InvalidEntitlement
