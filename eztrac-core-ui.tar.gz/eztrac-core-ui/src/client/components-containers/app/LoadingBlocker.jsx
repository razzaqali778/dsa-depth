import '../../styles/components/LoadingBlockerStyles.css'
import {connect} from 'react-redux'
import React from 'react'
import {getIsLoading} from '../../redux/selectors'

const LoadingBlocker = ({isLoading}) =>
    isLoading ? (
        <div className="blocker">
            <div className="block-message">
                <span className="inner-text">
                    <i className="spinner" />
                    Loading....
                </span>
            </div>
        </div>
    ) : null

const mapStateToProps = (state) => ({
    isLoading: getIsLoading(state)
})

export default connect(mapStateToProps, null)(LoadingBlocker)
