import {Route, Switch} from 'react-router-dom'
import {connect} from 'react-redux'
import React, {Suspense, lazy} from 'react'
import InvalidEntitlement from './InvalidEntitlement'
import LoadingBlocker from './LoadingBlocker'
import getHasReadAccess from '../../redux/selectors/getHasReadAccess'
import withLocationHandler from './withLocationHandler'

// Each route's container is loaded in its own chunk instead of the main bundle. Previously
// every route (teams, team-maintenance, platforms, communities, GETExport) shipped in a single
// ~1.7MB JS bundle, so the browser had to download/parse code for all five routes before the
// very first page could render. This cuts the initial bundle down to only what the current
// route needs, and browsers cache each chunk independently between visits.
const TeamMaintenanceContainer = lazy(() => import('../teamMaintenance/TeamMaintenanceContainer'))
const TeamDetailsContainer = lazy(() => import('../teams/TeamDetailsContainer'))
const GETExportContainer = lazy(() => import('../get/GetExportContainer'))
const PlatformList = lazy(() => import('../platforms/PlatformList'))
const CommunityList = lazy(() => import('../communities/CommunityList'))

const RouteLoadingFallback = () => (
    <div className="blocker">
        <div className="block-message">
            <span className="inner-text">
                <i className="spinner" />
                Loading....
            </span>
        </div>
    </div>
)

const AppContainer = (hasReadAccess) => (
    <div>
        {!hasReadAccess ? (
            <InvalidEntitlement />
        ) : (
            <Suspense fallback={<RouteLoadingFallback />}>
                <Switch>
                    <Route
                        render={(props) => <TeamMaintenanceContainer {...props} />}
                        exact
                        path="/team-maintenance"
                    />
                    <Route
                        render={(props) => <TeamDetailsContainer {...props} />}
                        exact
                        path="/teams"
                    />
                    <Route
                        render={(props) => <GETExportContainer {...props} />}
                        exact
                        path="/GETExport"
                    />
                    <Route component={PlatformList} exact path="/platforms" />
                    <Route component={CommunityList} exact path="/communities" />
                </Switch>
            </Suspense>
        )}
        <LoadingBlocker />
    </div>
)

const mapStateToProps = (state) => ({
    hasReadAccess: getHasReadAccess(state)
})

const withConnect = connect(mapStateToProps)

export default withLocationHandler(withConnect(AppContainer))
