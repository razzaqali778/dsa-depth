import {connect} from 'react-redux'
import React, {Component} from 'react'
import isEqual from 'lodash/isEqual'
import queryString from 'query-string'
import {updateQuery} from '../../utils/locationQueryHelpers'
import {locationActions, userActions} from '../../redux/actions'

const mapStateToProps = (state) => ({
    reduxLocation: state.location
})

const withLocationHandler = (WrappedComponent) =>
    connect(mapStateToProps, {...locationActions, ...userActions})(
        class extends Component {
            constructor(props) {
                super(props)
                this.updateLocation = this.props.updateLocation
                this.fetchCurrentUser = this.props.fetchCurrentUser
            }

            componentDidMount() {
                this.fetchCurrentUser()
                this.updateLocation({
                    query: queryString.parse(this.props.location.search),
                    pathname: this.props.location.pathname,
                    firstLoad: true,
                    queryString: this.props.location.search
                })
            }

            UNSAFE_componentWillUpdate(nextProps) {
                // if redux state changed
                const locationIsInvalidated = !isEqual(
                    nextProps.reduxLocation,
                    this.props.reduxLocation
                )
                if (locationIsInvalidated) {
                    const oldSearch = queryString.parse(this.props.location.search)
                    const newSearch = nextProps.reduxLocation.query

                    const pathIsInvalidated = !isEqual(oldSearch, newSearch)

                    if (pathIsInvalidated) {
                        const newQuery = updateQuery(
                            oldSearch,
                            newSearch,
                            this.props.location.search
                        )
                        this.props.history.push(`${nextProps.reduxLocation.pathname}?${newQuery}`)
                    }
                }
            }

            render() {
                return <WrappedComponent />
            }
        }
    )

export default withLocationHandler
