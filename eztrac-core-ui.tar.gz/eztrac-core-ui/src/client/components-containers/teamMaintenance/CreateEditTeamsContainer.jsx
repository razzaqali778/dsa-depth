import {connect} from 'react-redux'
import {getIsCreatingTeam, getSelectedPlatformId, getSelectedOrgId} from '../../redux/selectors'
import {teamActions} from '../../redux/actions'
import CreateEditTeams from './CreateEditTeams'
import getSelectedTeamInfo from '../../redux/selectors/teams/getSelectedTeamInfo'
import getTeamFiltersOptions from '../../redux/selectors/teams/getTeamFiltersOptions'

const mapStateToProps = (state) => ({
    selectedTeamInfo: getSelectedTeamInfo(state),
    teamFiltersOptions: getTeamFiltersOptions(state),
    isCreatingTeam: getIsCreatingTeam(state),
    selectedPlatformId: getSelectedPlatformId(state),
    selectedOrgId: getSelectedOrgId(state)
})

const mapDispatchToProps = (dispatch) => ({
    saveTeamSaga: (payload) => {
        dispatch(teamActions.saveTeam(payload))
    },
    setIsEditing: (boolean) => {
        dispatch(teamActions.setIsEditing(boolean))
    },
    setSelectedTeam: (team) => {
        dispatch(teamActions.setSelectedTeam(team))
    },
    toggleIsCreatingTeam: (boolean) => {
        dispatch(teamActions.toggleIsCreatingTeam(boolean))
    },
    setSelectedPlatformId: (platform) => dispatch(teamActions.setSelectedPlatformId(platform)),
    setSelectedOrgId: (org) => dispatch(teamActions.setSelectedOrgId(org))
})

export default connect(mapStateToProps, mapDispatchToProps)(CreateEditTeams)
