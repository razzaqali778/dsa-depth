import {Button, ButtonIcon} from '@rmwc/button'
import {Elevation} from '@rmwc/elevation'
import {Grid, GridCell} from '@rmwc/grid'
import {connect} from 'react-redux'
import React from 'react'
import isEmpty from 'lodash/isEmpty'
import {getIsCreatingTeam} from '../../redux/selectors'
import {teamActions} from '../../redux/actions'
import CreateEditTeamsContainer from './CreateEditTeamsContainer'
import getSelectedTeamInfo from '../../redux/selectors/teams/getSelectedTeamInfo'

const mapStateToProps = (state) => ({
    selectedTeamInfo: getSelectedTeamInfo(state),
    selectedTeam: state.team.selectedTeam,
    isCreatingTeam: getIsCreatingTeam(state)
})

const actions = {
    setIsEditing: teamActions.setIsEditing
}

const withConnect = connect(mapStateToProps, actions)

const IsActiveLabel = ({isActive}) => {
    const label = isActive ? 'Active Team' : 'Inactive Team'
    const labelClassName = isActive ? 'active' : 'inactive'

    return (
        <Elevation className={`is-active-tag ${labelClassName}`} z={2}>
            {label}
        </Elevation>
    )
}

const ExistingTeam = withConnect(({selectedTeamInfo, setIsEditing}) => (
    <Grid className="team-pane mdc-card">
        <GridCell span="10">
            <h2>{selectedTeamInfo.name}</h2>

            <ul className="team-characteristics">
                <li>
                    <strong>Community </strong>
                    <span>{selectedTeamInfo.communityName}</span>
                </li>
                <li>
                    <strong>Platform </strong>
                    <span>{selectedTeamInfo.platformName}</span>
                </li>
                <li>
                    <strong>Org</strong>
                    <span>{selectedTeamInfo.orgName}</span>
                </li>
                <li>
                    <IsActiveLabel isActive={selectedTeamInfo.isActive} />
                </li>
            </ul>
        </GridCell>
        <GridCell align="top" span="2">
            <Button
                className="edit-button pull-right"
                onClick={() => {
                    setIsEditing(true)
                }}
                outlined
            >
                <ButtonIcon icon="edit" />
                Edit Team
            </Button>
        </GridCell>
    </Grid>
))

const TeamDetails = withConnect(({isCreatingTeam}) =>
    isCreatingTeam ? <CreateEditTeamsContainer /> : <ExistingTeam />
)

const TeamInfoContainer = ({selectedTeam}) => (!isEmpty(selectedTeam) ? <TeamDetails /> : null)

export default withConnect(TeamInfoContainer)
