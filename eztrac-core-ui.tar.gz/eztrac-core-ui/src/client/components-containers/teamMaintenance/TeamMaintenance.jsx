import '../../styles/containers/AppContainerStyles.css'
import {Fab} from '@rmwc/fab'
import {Grid, GridCell, GridInner} from '@rmwc/grid'
import {Icon} from '@rmwc/icon'
import {includes, isEmpty} from 'lodash'
import React from 'react'
import Select from 'react-select'
import CreateEditTeamsContainer from './CreateEditTeamsContainer'
import InvalidEntitlement from '../app/InvalidEntitlement'
import TeamInfoContainer from './TeamInfoContainer'

const RenderDetail = ({selectedTeam, isCreatingTeam}) => {
    if (selectedTeam) {
        return selectedTeam.isEditing || isCreatingTeam ? (
            <CreateEditTeamsContainer />
        ) : (
            <TeamInfoContainer />
        )
    }

    return null
}

const TeamMaintenance = ({
    teamOptions,
    setSelectedTeam,
    selectedTeam,
    isCreatingTeam,
    toggleIsCreatingTeam,
    hasManageTeams,
    favoriteTeams,
    favoriteButtonClickedSaga
}) => {
    document.title = selectedTeam && selectedTeam.name ? selectedTeam.name : 'EZ Trac Core'

    return (
        <div className="app-container container">
            {hasManageTeams ? (
                <div>
                    <Grid>
                        <GridCell span="12">
                            <h2>Team Maintenance</h2>
                            <GridInner>
                                <GridCell className="teamSelect" span="5">
                                    <Select
                                        onChange={(team) => {
                                            setSelectedTeam({id: team.value, name: team.label})
                                        }}
                                        options={teamOptions}
                                        placeholder="Select a team..."
                                        value={
                                            !isEmpty(selectedTeam) && {
                                                value: selectedTeam.id,
                                                label: selectedTeam.name
                                            }
                                        }
                                    />
                                </GridCell>
                                {isEmpty(selectedTeam) || isEmpty(selectedTeam.id) ? (
                                    <GridCell span="2">
                                        <Fab
                                            className="team-maintenance-add-button"
                                            icon="add"
                                            onClick={() => {
                                                setSelectedTeam({id: null, name: null})
                                                toggleIsCreatingTeam(true)
                                            }}
                                        />
                                    </GridCell>
                                ) : (
                                    <GridCell className="buttonContainer" span="2">
                                        <Icon
                                            className="favoriteButton"
                                            icon={
                                                includes(favoriteTeams, selectedTeam.id)
                                                    ? 'star'
                                                    : 'star_border'
                                            }
                                            onClick={() =>
                                                favoriteButtonClickedSaga({
                                                    [selectedTeam.id]: selectedTeam.id
                                                })
                                            }
                                            title="Favorite"
                                        />
                                        <Fab
                                            className="team-maintenance-add-button"
                                            icon="add"
                                            onClick={() => {
                                                setSelectedTeam({id: null, name: null})
                                                toggleIsCreatingTeam(true)
                                            }}
                                        />
                                    </GridCell>
                                )}
                                <GridCell span="3" />
                                <GridCell align="bottom" span="2">
                                    <a
                                        href={
                                            selectedTeam?.id
                                                ? `/ez-trac-core/teams?teamId=${selectedTeam.id}`
                                                : '/ez-trac-core/teams'
                                        }
                                    >
                                        Return to Team Details
                                    </a>
                                </GridCell>
                            </GridInner>
                        </GridCell>
                    </Grid>
                    <Grid>
                        <GridCell span="12">
                            <RenderDetail
                                isCreatingTeam={isCreatingTeam}
                                selectedTeam={selectedTeam}
                            />
                        </GridCell>
                    </Grid>
                </div>
            ) : (
                <InvalidEntitlement missingEntitlement="Manage Teams" />
            )}
        </div>
    )
}

export default TeamMaintenance
