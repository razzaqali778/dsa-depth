import {connect} from 'react-redux'
import {getFavoriteTeams, getIsCreatingTeam, getSelectedTeam} from '../../redux/selectors'
import {preferencesActions, teamActions} from '../../redux/actions'
import TeamMaintenance from './TeamMaintenance'
import getActiveTeamSelectOptions from '../../redux/selectors/teams/getActiveTeamSelectOptions'
import getHasManageTeams from '../../redux/selectors/getHasManageTeams'

const mapStateToProps = (state) => ({
    teamOptions: getActiveTeamSelectOptions(state),
    selectedTeam: getSelectedTeam(state),
    isCreatingTeam: getIsCreatingTeam(state),
    hasManageTeams: getHasManageTeams(state),
    favoriteTeams: getFavoriteTeams(state)
})

const mapDispatchToProps = (dispatch) => ({
    setSelectedTeam: (team) => {
        dispatch(teamActions.setSelectedTeam(team))
    },
    toggleIsCreatingTeam: (boolean) => {
        dispatch(teamActions.toggleIsCreatingTeam(boolean))
    },
    favoriteButtonClickedSaga: (value) => dispatch(preferencesActions.favoriteButtonClicked(value))
})

export default connect(mapStateToProps, mapDispatchToProps)(TeamMaintenance)
