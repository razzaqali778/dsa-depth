import '../../styles/containers/AppContainerStyles.css'
import {Button} from '@rmwc/button'
import {Grid, GridCell} from '@rmwc/grid'
import {Switch} from '@rmwc/switch'
import {TextField} from '@rmwc/textfield'
import React from 'react'
import isUndefined from 'lodash/isUndefined'
import {isTeamSaveDisabled} from '../../redux/utils/validatorsForTeamMaintenance'
import FilteredCommunitySelector from './FilteredCommunitySelector'

class CreateEditTeams extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            teamName: this.props.selectedTeamInfo.name,
            communityId: this.props.selectedTeamInfo.communityId,
            selectedTeamId: this.props.selectedTeamInfo.id,
            isActive: isUndefined(this.props.selectedTeamInfo.isActive)
                ? true
                : this.props.selectedTeamInfo.isActive
        }
    }

    componentDidMount() {
        const {setSelectedOrgId, setSelectedPlatformId, selectedTeamInfo} = this.props
        if (selectedTeamInfo) {
            setSelectedOrgId(selectedTeamInfo.orgId)
            setSelectedPlatformId(selectedTeamInfo.platformId)
        }
    }

    render() {
        const {
            teamFiltersOptions,
            selectedPlatformId,
            selectedOrgId,
            setSelectedPlatformId,
            setSelectedOrgId,
            saveTeamSaga,
            setIsEditing,
            toggleIsCreatingTeam,
            setSelectedTeam,
            isCreatingTeam
        } = this.props

        const {communityId, isActive, selectedTeamId, teamName} = this.state

        return (
            <Grid className="mdc-card">
                <GridCell span="7">
                    <div className="form-section">
                        <span className="team-name-textfield">Team Name:</span>
                        <TextField
                            defaultValue={teamName || ''}
                            onChange={(evt) => this.setState({teamName: evt.target.value})}
                            placeholder="Enter team name..."
                            type="text"
                        />
                    </div>
                    <div className="form-section">
                        <span className="team-name-textfield">Community:</span>
                        <FilteredCommunitySelector
                            filtersOptions={teamFiltersOptions}
                            selectedOrgId={selectedOrgId}
                            selectedPlatformId={selectedPlatformId}
                            selectedCommunityId={communityId}
                            setSelectedCommunityId={(id) => this.setState({communityId: id})}
                            setSelectedPlatformId={setSelectedPlatformId}
                            setSelectedOrgId={setSelectedOrgId}
                        />
                    </div>
                    <div className="form-section">
                        <Switch
                            checked={isActive}
                            label="Active"
                            onChange={(evt) => this.setState({isActive: evt.target.checked})}
                        />
                    </div>
                </GridCell>
                <GridCell align="bottom" span="5">
                    <Button
                        className="btn btn-primary pull-right save-team-button"
                        disabled={isTeamSaveDisabled(communityId, teamName)}
                        onClick={() =>
                            saveTeamSaga({
                                selectedTeamId,
                                teamName,
                                communityId,
                                isActive
                            })
                        }
                        raised
                    >
                        Save
                    </Button>
                    <Button
                        className="btn btn-default pull-right"
                        onClick={() => {
                            setIsEditing(false)
                            toggleIsCreatingTeam(false)
                            if (isCreatingTeam) setSelectedTeam(null)
                        }}
                    >
                        Cancel
                    </Button>
                </GridCell>
            </Grid>
        )
    }
}

export default CreateEditTeams
