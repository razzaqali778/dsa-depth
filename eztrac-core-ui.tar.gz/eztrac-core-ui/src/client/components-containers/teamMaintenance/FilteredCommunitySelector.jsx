import React from 'react'
import {Select} from '@rmwc/select'
import {GridCell, GridInner} from '@rmwc/grid'

const FilteredCommunitySelector = ({
    filtersOptions: {orgs, platforms, communities},
    selectedCommunityId,
    selectedPlatformId,
    selectedOrgId,
    setSelectedCommunityId,
    setSelectedPlatformId,
    setSelectedOrgId
}) => (
    <div className="team-filters-section">
        <GridInner>
            <GridCell span="6">
                <Select
                    enhanced
                    label="Filter by org"
                    options={orgs}
                    value={selectedOrgId}
                    onChange={(event) => {
                        setSelectedOrgId(event.target.value)
                        setSelectedPlatformId(undefined)
                        setSelectedCommunityId(undefined)
                    }}
                />
            </GridCell>
            <GridCell span="6">
                <Select
                    enhanced
                    label="Filter by platform"
                    options={platforms}
                    value={selectedPlatformId}
                    onChange={(event) => {
                        setSelectedPlatformId(event.target.value)
                        setSelectedCommunityId(undefined)
                    }}
                />
            </GridCell>
        </GridInner>
        <GridInner>
            <GridCell span="8">
                <Select
                    enhanced
                    label="Select community"
                    options={communities}
                    value={selectedCommunityId}
                    onChange={(event) => setSelectedCommunityId(event.target.value)}
                />
            </GridCell>
        </GridInner>
    </div>
)

export default FilteredCommunitySelector
