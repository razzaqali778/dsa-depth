import {Dialog, DialogButton, DialogContent, DialogTitle} from '@rmwc/dialog'
import React from 'react'

const SaveWarningModal = ({message, title, open, closeWarning, handleContinue}) => (
    <>
        <Dialog open={open}>
            <DialogTitle>{title}</DialogTitle>
            <DialogContent>{message}</DialogContent>
            <DialogButton onClick={closeWarning}>Cancel</DialogButton>
            <DialogButton onClick={handleContinue}>Continue</DialogButton>
        </Dialog>
    </>
)
export default SaveWarningModal
