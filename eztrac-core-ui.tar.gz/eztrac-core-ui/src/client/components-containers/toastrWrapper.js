import toastr from 'toastr'
import {makeErrorMsgUserFriendly} from '../utils/errorDisplayHelper'

export const popupError = (message, title = null) => {
    toastr.error(makeErrorMsgUserFriendly(message), title)
}
