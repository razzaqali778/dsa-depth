import React, {useCallback, useState} from 'react'
import {useSelector, useDispatch} from 'react-redux'
import {getCommunities} from '../../redux/selectors'
import ChildEntitiesModal from '../common/ChildEntitiesModal'
import EntityList from '../common/EntityList'
import actions from '../../redux/actions'
import ConfirmationModal from '../common/ConfirmationModal'
import LoadVelocityStylesheet from '../common/LoadVelocityStylesheet'
import getOrgsSelectOptions from '../../redux/selectors/teams/getOrgsSelectOptions'
import getPlatformsExtended from '../../redux/selectors/teams/getPlatformsExtended'

export default function PlatformList() {
    const [showCommunitiesModal, setShowCommunitiesModal] = useState(false)
    const [modalData, setModalData] = useState({childEntities: [], entityName: ''})
    const [showConfirmationModal, setShowConfirmationModal] = useState(false)
    const [confirmationModalSaveAction, setConfirmationModalSaveAction] = useState(null)

    const platforms = useSelector(getPlatformsExtended)
    const orgSelectOptions = useSelector(getOrgsSelectOptions)
    const communities = useSelector(getCommunities)

    const dispatch = useDispatch()

    const handleShowCommunities = useCallback(
        (platform) => {
            setShowCommunitiesModal(true)
            const platformsCommunities = communities.filter((c) => c.platformId === platform.id)
            setModalData({childEntities: platformsCommunities, entityName: platform.name})
        },
        [communities]
    )

    const handleSaveEditedPlatform = useCallback(
        (editedPlatform) => {
            const selectedPlatform = platforms.find((p) => p.id === editedPlatform.id)
            const platformDeactivated = selectedPlatform.isActive && !editedPlatform.isActive
            const activePlatformCommunities = communities.filter(
                (c) => c.platformId === editedPlatform.id && c.isActive
            )
            if (platformDeactivated && activePlatformCommunities.length) {
                setConfirmationModalSaveAction(
                    actions.savePlatform({platform: editedPlatform, isCreating: false})
                )
                setShowConfirmationModal(true)
                return
            }
            dispatch(actions.savePlatform({platform: editedPlatform, isCreating: false}))
        },
        [communities, platforms]
    )

    const mapToListItem = (platform) => ({
        id: platform.id,
        name: platform.name,
        isActive: platform.isActive,
        parentId: platform.orgId,
        parentName: platform.orgName
    })

    const mapListItemToPlatform = (listItem) => ({
        id: listItem.id,
        name: listItem.name,
        isActive: listItem.isActive,
        orgId: listItem.parentId
    })

    return (
        <>
            <LoadVelocityStylesheet />
            <div className="container">
                <h1>Platforms</h1>
                <ConfirmationModal
                    open={showConfirmationModal}
                    onClose={() => setShowConfirmationModal(false)}
                    onSaveAction={confirmationModalSaveAction}
                    title="Deactivating platform"
                    body="There are active communities under this platform."
                />
                <ChildEntitiesModal
                    open={showCommunitiesModal}
                    onClose={() => setShowCommunitiesModal(false)}
                    data={modalData}
                    entityType="platform"
                />
                <EntityList
                    entities={platforms.map((p) => mapToListItem(p))}
                    handleShowChildrenClick={handleShowCommunities}
                    entityType="platform"
                    parentOptions={orgSelectOptions}
                    onNewEntitySave={(newEntity) => {
                        dispatch(
                            actions.savePlatform({
                                platform: mapListItemToPlatform(newEntity),
                                isCreating: true
                            })
                        )
                    }}
                    onEditedEntitySave={(editedEntity) =>
                        handleSaveEditedPlatform(mapListItemToPlatform(editedEntity))
                    }
                />
            </div>
        </>
    )
}
