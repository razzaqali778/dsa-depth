import _ from 'lodash'

const getExtendedStartTimeFrameId = (engagement, timeFrames) => {
    const existingEndTimeFrameId = engagement[engagement.length - 1].timeFrameId
    const startTimeFrameIndex = timeFrames.findIndex((f) => f.id === existingEndTimeFrameId) + 1

    return timeFrames[startTimeFrameIndex].id
}

const createFixedAmountEngagement = (
    engagement,
    timeFrames,
    endTimeFrameId,
    createEngagementSaga
) => {
    createEngagementSaga({
        selectedStartTimeFrameId: getExtendedStartTimeFrameId(engagement, timeFrames),
        selectedEndTimeFrameId: endTimeFrameId,
        selectedEngagementId: _.last(engagement).engagementId,
        engagementCost: _.last(engagement).amount,
        comment: _.last(engagement).comment
    })
}

const createCalculatedEngagement = (
    engagement,
    timeFrames,
    endTimeFrameId,
    createCalculatedEngagementSaga
) => {
    createCalculatedEngagementSaga({
        selectedStartTimeFrameId: getExtendedStartTimeFrameId(engagement, timeFrames),
        selectedEndTimeFrameId: endTimeFrameId,
        selectedEngagementId: _.last(engagement).engagementId,
        amountDetails: _.last(engagement).amountDetails,
        comment: _.last(engagement).comment
    })
}

const endEngagement = (engagement, timeFrameId, selectedTeam, endEngagementSaga) => {
    endEngagementSaga({
        endTimeFrame: timeFrameId,
        engagement,
        selectedTeam
    })
}

export const saveEditedEngagement = (
    timeFrameId,
    endEngagementSaga,
    createEngagementSaga,
    createCalculatedEngagementSaga,
    selectedTeam,
    engagement,
    timeFrames
) => {
    const endTimeFrameIndex = engagement.findIndex((e) => e.timeFrameId === timeFrameId)
    if (endTimeFrameIndex === engagement.length - 1) return
    if (endTimeFrameIndex !== -1) {
        endEngagement(engagement, timeFrameId, selectedTeam, endEngagementSaga)
    } else if (_.last(engagement).amountDetails) {
        createCalculatedEngagement(
            engagement,
            timeFrames,
            timeFrameId,
            createCalculatedEngagementSaga
        )
    } else {
        createFixedAmountEngagement(engagement, timeFrames, timeFrameId, createEngagementSaga)
    }
}
