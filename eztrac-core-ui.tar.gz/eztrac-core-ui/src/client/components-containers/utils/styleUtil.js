export const customStyles = {
    control: (base, state) => ({
        ...base,
        backgroundColor: state.isFocused ? 'E1E1E1' : 'f5f5f5',
        borderRadius: '4px 4px 0 0',
        border: 'none',
        borderBottom: state.isFocused ? '#009688 solid 2px' : '#c5c5c5 solid 1px',
        boxShadow: state.isFocused ? null : null,
        boxSizing: 'border-box',
        caretColor: '#009688',
        cursor: 'pointer',
        padding: '10px 0px 10px',
        '&:hover': {
            backgroundColor: 'EEEEEE'
        }
    })
}

const firstLineStyle = (isSelected = false) => ({
    color: isSelected ? 'inherit' : 'grey',
    fontSize: '12px'
})

const singleValue = (base) => ({
    ...base,
    width: '100%',
    whiteSpace: 'pre'
})

const singleValueMultiline = (base) => ({
    ...singleValue(base),
    ':first-line': firstLineStyle()
})

const valueContainer = (base) => ({
    ...base,
    overflow: 'inherit'
})

const option = (base) => ({
    ...base,
    whiteSpace: 'pre-wrap'
})

const optionMultiline = (base, isSelected) => ({
    ...option(base),
    ':first-line': firstLineStyle(isSelected)
})

export const multiLineOptionStyles = {
    singleValue: (base) => singleValueMultiline(base),
    valueContainer: (base) => valueContainer(base),
    option: (base, {isSelected}) => optionMultiline(base, isSelected)
}

export const conditionalMultilineOptionStyle = {
    singleValue: (base, {data}) => (data.isLocked ? singleValueMultiline(base) : singleValue(base)),
    valueContainer: (base) => valueContainer(base),
    option: (base, {data, isSelected}) =>
        data.isLocked ? optionMultiline(base, isSelected) : option(base, isSelected)
}
