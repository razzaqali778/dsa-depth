import {useEffect, useRef} from 'react'

export function useListenForOutsideClicks(ref, handleClickOutside) {
    // Keep the latest callback in a ref instead of putting it in the effect's dependency array:
    // callers pass a new inline arrow function on every render, so depending on it directly would
    // either tear down/re-add the listener every render, or (as before, with `[ref]` only) run the
    // effect once and permanently use the very first render's (potentially stale) callback.
    const handleClickOutsideRef = useRef(handleClickOutside)
    handleClickOutsideRef.current = handleClickOutside

    useEffect(() => {
        function handleClick(event) {
            if (ref.current && !ref.current.contains(event.target)) {
                handleClickOutsideRef.current()
            }
        }
        document.addEventListener('mousedown', handleClick)

        return () => {
            document.removeEventListener('mousedown', handleClick)
        }
    }, [ref])
}
