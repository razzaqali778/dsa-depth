export function removeNonDigitCharacters(value) {
    return value.replace(/\D/g, '')
}
