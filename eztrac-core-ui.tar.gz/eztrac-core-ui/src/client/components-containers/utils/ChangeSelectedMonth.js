import {filter, find} from 'lodash'

export function changeSelectedMonthData(
    setSelectedTimeFrameId,
    timeFrameSelected,
    teamPeople,
    forecastedPeople,
    establishInitialSortOrderPeople,
    sortOrderPreferencePeopleLocal,
    clearNewPersonData,
    clearNewForecastedPersonData,
    teamInitiatives,
    sortOrderPreference,
    setSelectedTimeFrameTeamCost,
    teamCostData,
    clearNewInitiativeData,
    establishInitialSortOrder
) {
    setSelectedTimeFrameId(Number(timeFrameSelected))
    const newTimeFramePeople = filter(teamPeople, {timeFrameId: Number(timeFrameSelected)})
    establishInitialSortOrderPeople(newTimeFramePeople, sortOrderPreferencePeopleLocal, false)
    const newTimeFrameForecastedPeople = filter(forecastedPeople, {
        timeFrameId: Number(timeFrameSelected)
    })
    establishInitialSortOrderPeople(
        newTimeFrameForecastedPeople,
        sortOrderPreferencePeopleLocal,
        true
    )
    clearNewPersonData()
    clearNewForecastedPersonData()
    const newTimeFrameInitiatives = filter(teamInitiatives, {
        timeFrameId: Number(timeFrameSelected)
    })
    establishInitialSortOrder(newTimeFrameInitiatives, sortOrderPreference)
    setSelectedTimeFrameTeamCost(
        find(teamCostData, (timeframe) => timeframe.timeFrameId === Number(timeFrameSelected))
    )
    clearNewInitiativeData()
}
