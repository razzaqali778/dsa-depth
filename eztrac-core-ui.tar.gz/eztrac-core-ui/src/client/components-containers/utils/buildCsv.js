const DownloadCSV = (data, fileName) => {
    const headers = `${Object.keys(data[0]).join(',')}\n`
    const rows = data
        .map((row) =>
            Object.values(row)
                .map((value) => `"${value}"`)
                .join(',')
        )
        .join('\n')

    const csvContent = headers + rows

    const blob = new Blob([csvContent], {type: 'text/csv;charset=utf-8;'})

    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `${fileName}.csv`)
    link.click()
}

export default DownloadCSV
