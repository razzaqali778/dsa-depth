export function copyForwardButtonDisabled(currentMonthDataChanged, selectedTimeFrame, isAdmin) {
    // Disable while the selected timeframe is still loading / unresolved so callers
    // never read `.lockdown` off undefined during team/tab switches.
    if (!selectedTimeFrame || currentMonthDataChanged || (selectedTimeFrame.lockdown && !isAdmin)) {
        return true
    }
    return false
}
