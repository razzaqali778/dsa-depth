import {get} from 'lodash'

// Add margin for the case when the first day of the year in GMT is evaluated in a different timezone than GMT
const TWO_DAYS_IN_MILLISECONDS = 2 * 24 * 60 * 60 * 1000

const isDateInCurrentYear = (d) => {
    const currentDate = new Date()
    const refDate = new Date(d + TWO_DAYS_IN_MILLISECONDS)

    return currentDate.getFullYear() === refDate.getFullYear()
}

export function canEditTimeFrame(timeFrame, isAdmin) {
    if (!timeFrame || !timeFrame.startDate) {
        return false
    }

    const isTimeFrameLocked = get(timeFrame, 'lockdown', true)
    const allowEditing =
        !isTimeFrameLocked ||
        (isAdmin && timeFrame.startDate && isDateInCurrentYear(timeFrame.startDate))

    return allowEditing
}

export function canEditEngagement(engagement, isAdmin) {
    if (!engagement || !engagement.startDate) {
        return false
    }

    const isTimeFrameLocked = get(engagement, 'timeFrameLockdown', true)
    const allowEditing =
        !isTimeFrameLocked ||
        (isAdmin && engagement.startDate && isDateInCurrentYear(engagement.startDate))

    return allowEditing
}
