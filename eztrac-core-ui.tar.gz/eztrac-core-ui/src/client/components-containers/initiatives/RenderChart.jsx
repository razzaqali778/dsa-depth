import {Bar} from 'react-chartjs-2'
import React, {useMemo} from 'react'
import buildChartData from '../../redux/utils/buildChartData'

const RenderChart = ({teamInitiatives, relevantTimeFrames}) => {
    // lodash's `max` takes a single array (`_.max(array)`); it does not behave like
    // `Math.max(value, floor)`, so the `450`/`650` "minimum size" arguments below were silently
    // ignored, meaning the chart could shrink below its intended minimum on small windows.
    const chartHeight = Math.max(Math.floor(window.innerHeight * 0.45), 450)
    const chartWidth = Math.max(Math.floor(window.innerWidth * 0.45), 650)

    // buildChartData does grouping/sorting work; memoize so it only reruns when the underlying
    // data actually changes, not on every render (e.g. unrelated parent state updates).
    const chartData = useMemo(
        () => buildChartData(teamInitiatives, relevantTimeFrames),
        [teamInitiatives, relevantTimeFrames]
    )

    return (
        <div className="initiative-chart">
            <Bar
                data={chartData}
                height={chartHeight}
                options={{
                    responsive: true,
                    legend: {
                        position: 'top'
                    },
                    maintainAspectRatio: false,
                    tooltips: {
                        callbacks: {
                            label(tooltipItem, data) {
                                let label = data.datasets[tooltipItem.datasetIndex].label || ''

                                if (label) {
                                    label += ': '
                                }
                                label += `$${Number(tooltipItem.yLabel).toLocaleString()}`

                                return label
                            }
                        }
                    }
                }}
                width={chartWidth}
            />
        </div>
    )
}

export default RenderChart
