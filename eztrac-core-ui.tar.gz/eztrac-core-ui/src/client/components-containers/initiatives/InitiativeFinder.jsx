import 'react-table/react-table.css'
import React from 'react'
import ReactTable from 'react-table'
import selectTableHOC from 'react-table/lib/hoc/selectTable'
import {isSelected} from '../../redux/utils/newInitiative'

const SelectTable = selectTableHOC(ReactTable)

const defaultFilterMethod = (filterObj, row) => {
    const id = filterObj.pivotId || filterObj.id
    const searchString = String(filterObj.value).toLowerCase()

    return row[id] !== undefined
        ? String(row[id]).toLowerCase().startsWith(searchString) ||
              String(row[id]).toLowerCase().includes(searchString)
        : true
}

const filterInput = ({filter, onChange}) => (
    <input
        onChange={(event) => onChange(event.target.value)}
        placeholder="Search..."
        style={{
            width: '100%'
        }}
        value={filter ? filter.value : ''}
    />
)

const addTeamCostPct = (row) => {
    const updatedRow = {
        ...row,
        teamCostPct: 0,
        initiativeCost: 0
    }

    return updatedRow
}

const InitiativeFinder = ({addNewInitiative, initiatives, selectedTimeFrameInitiatives}) => {
    const columns = [
        {
            Header: 'Initiative Name',
            accessor: 'initiativeName',
            minWidth: 350,
            Filter: filterInput
        },
        {
            Header: 'Financial Code',
            accessor: 'financeCodeValue',
            minWidth: 190,
            Filter: filterInput
        },
        {
            Header: 'Parent Initiative',
            accessor: 'parentName',
            minWidth: 350,
            Filter: filterInput
        },
        {
            Header: 'Region',
            accessor: 'region',
            minWidth: 120,
            Filter: filterInput
        },
        {
            Header: 'Business Unit',
            accessor: 'businessUnit',
            minWidth: 150,
            Filter: filterInput
        },
        {Header: 'Type', accessor: 'typeId', minWidth: 110, Filter: filterInput},
        {
            Header: 'Status',
            accessor: 'status',
            minWidth: 80,
            Filter: filterInput
        }
    ]

    return (
        <SelectTable
            columns={columns}
            data={initiatives}
            defaultFilterMethod={defaultFilterMethod}
            defaultPageSize={15}
            filterable
            getTrProps={(state, rowInfo) => {
                if (
                    rowInfo !== undefined &&
                    isSelected(rowInfo.original.id, selectedTimeFrameInitiatives)
                ) {
                    return {
                        style: {
                            background: 'rgba(229, 229, 229, .7)'
                        }
                    }
                }

                return {}
            }}
            isSelected={(key) => isSelected(key, selectedTimeFrameInitiatives)}
            keyField="id"
            resizable={false}
            selectionType="checkbox"
            showPageSizeOptions={false}
            toggleSelection={(_, __, row) => addNewInitiative(addTeamCostPct(row))}
        />
    )
}

export default InitiativeFinder
