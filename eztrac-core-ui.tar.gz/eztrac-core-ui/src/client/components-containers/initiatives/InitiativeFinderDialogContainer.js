import {connect} from 'react-redux'
import {
    getIsInitiativeModifyFinderOpen,
    getSelectedTimeFrameTeamInitiatives
} from '../../redux/selectors/initiatives'
import {initiativeActions} from '../../redux/actions'
import InitiativeFinderDialog from './InitiativeFinderDialog'
import getSelectableInitiatives from '../../redux/selectors/initiatives/getSelectableInitiatives'

const mapStateToProps = (state) => ({
    selectableInitiatives: getSelectableInitiatives(state),
    selectedTimeFrameInitiatives: getSelectedTimeFrameTeamInitiatives(state),
    isInitiativeModifyFinderOpen: getIsInitiativeModifyFinderOpen(state)
})

const mapDispatchToProps = (dispatch) => ({
    setIsInitiativeModifyFinderOpen: (isInitiativeModifyFinderOpen) =>
        dispatch(initiativeActions.setIsInitiativeModifyFinderOpen(isInitiativeModifyFinderOpen))
})

export default connect(mapStateToProps, mapDispatchToProps)(InitiativeFinderDialog)
