import {Card} from '@rmwc/card'
import {get as getOrElse} from 'lodash'
import React from 'react'

const typeIdToType = {
    'CAP-EXP-INIT': 'Capital Expense Initiative',
    'CAP-INIT': 'Capital Initiative',
    'CAP-PROJ': 'Capital Project',
    ENH: 'Enhancement',
    'EXP-INIT': 'Expense Initiative',
    OPS: 'Operations',
    SUP: 'Support'
}

const UNKNOWN = 'Unknown'

const InitiativeCard = ({initiative, className}) => (
    <Card className={className} key={initiative.id}>
        <div className="initiative-name">{initiative.initiativeName}</div>
        <p>
            <span>Type:</span> {getOrElse(typeIdToType, initiative.typeId, UNKNOWN)}
            <br />
            <span>Financial Code:</span> {initiative.financeCodeValue}
            <br />
            <span>Parent Name:</span> {initiative.parentName}
            <br />
            <span>Status:</span> {initiative.status}
            <br />
            <span>GET Activity ID:</span> {initiative.activityId || UNKNOWN}
            <br />
            <span>Portfolio Code:</span> {initiative.portfolioCode || UNKNOWN}
            <br />
            <span>Program Code:</span> {initiative.programCode || UNKNOWN}
        </p>
        <div className="tag-wrapper">
            {initiative.region && (
                <span className="tags" key="region">
                    {initiative.region}
                </span>
            )}
            {initiative.businessUnit && (
                <span className="tags" key="businessUnit">
                    {initiative.businessUnit}
                </span>
            )}
        </div>
    </Card>
)

export default InitiativeCard
