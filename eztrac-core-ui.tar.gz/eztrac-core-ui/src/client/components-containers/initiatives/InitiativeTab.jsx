import {Chip, ChipSet} from '@rmwc/chip'
import React from 'react'
import isEmpty from 'lodash/isEmpty'
import map from 'lodash/map'
import DatePickerContainer from '../teams/DatePickerContainer'
import InitiativeTableContainer from './InitiativeTableContainer'
import RenderChartContainer from './RenderChartContainer'
import UnsavedDataModalContainer from '../teams/UnsavedDataModalContainer'
import getTimeFrameRangeTeamCost from '../../redux/utils/getTimeFrameRangeTeamCost'

const InitiativeTab = ({
    initiativeErrors,
    initiativeWarnings,
    selectedTimeFrameId,
    startTimeFrame,
    endTimeFrame,
    teamCostData,
    unsavedDataModalBool
}) => (
    <div style={{marginTop: '3%'}}>
        <div>{unsavedDataModalBool && <UnsavedDataModalContainer />}</div>
        <div>
            {getTimeFrameRangeTeamCost(startTimeFrame.id, endTimeFrame.id, teamCostData) > 0 && (
                <div>
                    {!isEmpty(initiativeErrors) && (
                        <ChipSet>
                            {map(initiativeErrors, (error, index) => (
                                <Chip
                                    className="initiative-chip-error"
                                    key={`${index} ${selectedTimeFrameId}`}
                                >
                                    {error}
                                </Chip>
                            ))}
                        </ChipSet>
                    )}
                    {!isEmpty(initiativeWarnings) && (
                        <ChipSet>
                            {map(initiativeWarnings, (warning, index) => (
                                <Chip
                                    className="initiative-chip-warning"
                                    key={`${index} ${selectedTimeFrameId}`}
                                >
                                    {warning}
                                </Chip>
                            ))}
                        </ChipSet>
                    )}
                </div>
            )}
            <div className="flex-container">
                <div className="flex-item-table">
                    <div className="initiative-tab">
                        {/*
                            No key (or a stable one) here: a random uuid() regenerated on every
                            render forced React to unmount/remount the whole initiatives table
                            (and re-run all of its child selects/effects) on every single Redux
                            update - errors, warnings, cost, time frame, etc. - all of which are
                            already reflected via props without a remount.
                        */}
                        <InitiativeTableContainer />
                    </div>
                </div>
                <div className="flex-item-chart">
                    <DatePickerContainer style={{textAlign: 'center'}} />
                    <RenderChartContainer />
                </div>
            </div>
        </div>
    </div>
)

export default InitiativeTab
