import {Dialog, DialogButton, DialogContent} from '@rmwc/dialog'
import React from 'react'
import find from 'lodash/find'
import sortBy from 'lodash/sortBy'
import InitiativeFinderContainer from './InitiativeFinderContainer'

const InitiativeFinderDialog = ({
    isInitiativeModifyFinderOpen,
    selectableInitiatives,
    selectedTimeFrameInitiatives,
    setIsInitiativeModifyFinderOpen
}) => {
    const sortedInitiatives = sortBy(
        selectableInitiatives,
        (initiative) =>
            !find(
                selectedTimeFrameInitiatives,
                (timeFrameInitiative) => timeFrameInitiative.id === initiative.id
            )
    )

    return (
        <Dialog
            fullwidth="true"
            onClose={() => setIsInitiativeModifyFinderOpen(false)}
            open={isInitiativeModifyFinderOpen}
        >
            <DialogContent>
                <div className="initiative-table-add-dialog">
                    <InitiativeFinderContainer initiatives={sortedInitiatives} />
                </div>
            </DialogContent>
            <DialogButton onClick={() => setIsInitiativeModifyFinderOpen(false)}>
                close
            </DialogButton>
        </Dialog>
    )
}

export default InitiativeFinderDialog
