import 'react-table/react-table.css'
import {connect} from 'react-redux'
import {getSelectedTimeFrameTeamInitiatives} from '../../redux/selectors/initiatives'
import {initiativeActions} from '../../redux/actions'
import InitiativeFinder from './InitiativeFinder'

const mapStateToProps = (state) => ({
    selectedTimeFrameInitiatives: getSelectedTimeFrameTeamInitiatives(state)
})

const mapDispatchToProps = (dispatch) => ({
    addNewInitiative: (payload) => dispatch(initiativeActions.addNewInitiative(payload))
})

export default connect(mapStateToProps, mapDispatchToProps)(InitiativeFinder)
