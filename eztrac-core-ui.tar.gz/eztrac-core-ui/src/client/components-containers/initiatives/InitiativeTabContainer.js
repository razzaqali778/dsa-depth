import '../../styles/containers/InitiativeContainer.scss'
import {connect} from 'react-redux'
import {
    getEndTimeFrame,
    getSelectedTimeFrameId,
    getStartTimeFrame,
    getTeamCostData
} from '../../redux/selectors'
import {
    getInitiativeErrors,
    getInitiativeWarnings,
    getIsInitiativeCopyForwardContainerOpen
} from '../../redux/selectors/initiatives'
import {teamActions} from '../../redux/actions'
import InitiativeTab from './InitiativeTab'

const mapStateToProps = (state) => ({
    initiativeErrors: getInitiativeErrors(state),
    initiativeWarnings: getInitiativeWarnings(state),
    selectedTimeFrameId: getSelectedTimeFrameId(state),
    teamCostData: getTeamCostData(state),
    startTimeFrame: getStartTimeFrame(state),
    endTimeFrame: getEndTimeFrame(state),
    isInitiativeCopyForwardContainerOpen: getIsInitiativeCopyForwardContainerOpen(state)
})

const mapDispatchToProps = (dispatch) => ({
    setUnsavedDataModalBool: (team) => dispatch(teamActions.setUnsavedDataModalBool(team))
})
export default connect(mapStateToProps, mapDispatchToProps)(InitiativeTab)
