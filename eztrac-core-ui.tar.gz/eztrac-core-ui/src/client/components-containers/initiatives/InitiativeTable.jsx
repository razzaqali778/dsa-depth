import {Button} from '@rmwc/button'
import {
    DataTable,
    DataTableBody,
    DataTableCell,
    DataTableContent,
    DataTableHead,
    DataTableHeadCell,
    DataTableRow
} from '@rmwc/data-table'
import {Icon} from '@rmwc/icon'
import {
    cloneDeep,
    differenceBy,
    filter,
    get,
    includes,
    isEmpty,
    map,
    reverse,
    sortBy,
    sumBy
} from 'lodash'
import React from 'react'
import ReactTooltip from 'react-tooltip'
import Select from 'react-select'
import {canEditTimeFrame} from '../utils/canEditTimeFrame'
import {changeSelectedMonthData} from '../utils/ChangeSelectedMonth'
import {
    getTimeFrameIdNMonthsAway,
    getTimeFrameNameNMonthsAway
} from '../../redux/utils/timeFrameUtils'
import {
    hasInitiativeDataChanged,
    validateInitiativeCost,
    validatePct,
    validateTotalTeamCostPct
} from '../../redux/utils/validatorsForInitiatives'
import {multiLineOptionStyles} from '../utils/styleUtil'
import InitiativeCard from './InitiativeCard'
import InitiativeFinderDialogContainer from './InitiativeFinderDialogContainer'
import MonthDropdownContainer from '../teams/MonthDropdownContainer'
import SaveWarningModal from '../teamMaintenance/SaveWarningModal'
import {serviceBindings} from '../../redux/sagas/helpers/getServiceBindings'
import {copyForwardButtonDisabled} from '../utils/copyForwardButtonDisabled'

const vipUrl = `${serviceBindings.vipUI}/initiative`

class InitiativeTable extends React.Component {
    constructor(props) {
        super(props)
        this.initiativeTableRef = React.createRef()
    }

    isSaveDisabled() {
        const {
            currentMonthTimeFrame,
            teamInitiatives,
            selectedTimeFrameId,
            selectedTimeFrameInitiatives
        } = this.props

        if (!currentMonthTimeFrame) {
            return true
        }

        const initiativeInPlanningInCurrentMonth =
            selectedTimeFrameId === currentMonthTimeFrame.id &&
            includes(
                map(
                    selectedTimeFrameInitiatives,
                    (i) => currentMonthTimeFrame.id === i.timeFrameId && i.status === 'Planning'
                ),
                true
            )

        return (
            validateTotalTeamCostPct(selectedTimeFrameInitiatives) ||
            !hasInitiativeDataChanged(
                teamInitiatives,
                selectedTimeFrameInitiatives,
                selectedTimeFrameId
            ) ||
            initiativeInPlanningInCurrentMonth
        )
    }

    isCopyForwardDisabled() {
        const {
            teamInitiatives,
            selectedTimeFrameId,
            selectedTimeFrameInitiatives,
            selectedTimeFrame,
            isAdmin
        } = this.props

        const initiativeChanged = hasInitiativeDataChanged(
            teamInitiatives,
            selectedTimeFrameInitiatives,
            selectedTimeFrameId
        )

        return copyForwardButtonDisabled(initiativeChanged, selectedTimeFrame, isAdmin)
    }

    render() {
        const {
            copyCalendarModalBool,
            setCopyCalendarModalBool,
            teamInitiatives,
            hasManageTeams,
            isAdmin,
            updateInitiativesSaga,
            initiativeSelectOptions,
            newInitiativeData,
            setSelectedTimeFrameId,
            setSelectedTimeFrameTeamCost,
            selectedTimeFrame,
            selectedTimeFrameId,
            selectedTimeFrameTeamCost,
            teamCostData,
            selectedTimeFrameInitiatives,
            setSelectedTimeFrameInitiatives,
            setNewInitiativeData,
            addNewInitiative,
            clearNewInitiativeData,
            setIsInitiativeModifyFinderOpen,
            addNewInitiativeFromState,
            setSortOrderPreference,
            sortOrderPreference,
            establishInitialSortOrder,
            unsavedChangesBool,
            teamPeople,
            forecastedPeople,
            establishInitialSortOrderPeople,
            sortOrderPreferencePeopleLocal,
            clearNewPersonData,
            clearNewForecastedPersonData,
            setUnsavedDataModalBool,
            setSaveLockedTimeFrameData,
            timeFrames,
            copyInitiativesForward,
            overwrittenMonths
        } = this.props
        const {nameNum, allocationNum, costNum} = sortOrderPreference
        const totalPercentage = sumBy(selectedTimeFrameInitiatives, 'teamCostPct')

        const monthHasChanges = !hasInitiativeDataChanged(
            teamInitiatives,
            selectedTimeFrameInitiatives,
            selectedTimeFrameId
        )

        const allowEditing = canEditTimeFrame(selectedTimeFrame, isAdmin)
        const isTimeFrameLocked = get(selectedTimeFrame, 'lockdown', true)

        const sortDir = [null, -1, 1]
        const setSortDir = (index, key, sortOn) => {
            const updatedInitiativeTableSort = {
                nameNum: 0,
                allocationNum: 0,
                costNum: 0
            }
            updatedInitiativeTableSort[key] = (index + 1) % 3
            setSortOrderPreference(updatedInitiativeTableSort)

            switch (index) {
                case 0:
                    return sortOn === 'initiativeName'
                        ? setSelectedTimeFrameInitiatives(
                              sortBy(selectedTimeFrameInitiatives, [sortOn])
                          )
                        : setSelectedTimeFrameInitiatives(
                              reverse(sortBy(selectedTimeFrameInitiatives, [sortOn]))
                          )
                case 1:
                    return sortOn === 'initiativeName'
                        ? setSelectedTimeFrameInitiatives(
                              reverse(sortBy(selectedTimeFrameInitiatives, [sortOn]))
                          )
                        : setSelectedTimeFrameInitiatives(
                              sortBy(selectedTimeFrameInitiatives, [sortOn])
                          )
                default:
                    return setSelectedTimeFrameInitiatives(
                        sortBy(selectedTimeFrameInitiatives, ['id'])
                    )
            }
        }

        const newInitiativePicked = (evt) => {
            const value = {
                ...evt,
                value: {
                    ...evt.value,
                    teamCostPct: 0,
                    initiativeCost: 0
                }
            }
            setNewInitiativeData(value)
        }
        const resetAndClearSelectedInitiative = () => {
            clearNewInitiativeData()
            const newTimeFrameInitiatives = filter(
                teamInitiatives,
                (initiative) => initiative.timeFrameId === selectedTimeFrameId
            )
            establishInitialSortOrder(newTimeFrameInitiatives, sortOrderPreference)
        }

        const stageInitiative = (evt) => {
            if (evt) {
                newInitiativePicked(evt)
                if (evt.value && evt.value.initiativeName !== undefined) {
                    addNewInitiativeFromState()
                }
            }
            clearNewInitiativeData()
        }

        const validDates = filter(timeFrames, (timeFrame) => timeFrame.isActive)
        const formattedDates = map(validDates, (date) => ({label: date.name, value: date.id}))
        const selectedTimeFrameName = get(selectedTimeFrame, 'name', '')
        // Look up against the full list so a selected (possibly inactive) month still resolves;
        // only show the prev button when that previous month is active.
        const previousTimeFrameName = getTimeFrameNameNMonthsAway(
            selectedTimeFrameId,
            timeFrames,
            -1
        )
        const previousTimeFrameId = getTimeFrameIdNMonthsAway(
            selectedTimeFrameId,
            timeFrames,
            -1
        )
        const showPreviousTimeFrame =
            Boolean(previousTimeFrameName) &&
            validDates.some((timeFrame) => timeFrame.id === previousTimeFrameId)

        return (
            <>
                <SaveWarningModal
                    closeWarning={() => undefined}
                    message="You have unsaved changes."
                    open={unsavedChangesBool}
                    title="Warning!"
                />
                <InitiativeFinderDialogContainer />
                <DataTable className="initiative-table">
                    <DataTableContent>
                        <DataTableHead>
                            <DataTableRow>
                                <DataTableHeadCell>
                                    {showPreviousTimeFrame ? (
                                        <Button
                                            className="navigate_before"
                                            icon="navigate_before"
                                            label={previousTimeFrameName.split(' ')[0]}
                                            onClick={() =>
                                                changeSelectedMonthData(
                                                    setSelectedTimeFrameId,
                                                    previousTimeFrameId,
                                                    teamPeople,
                                                    forecastedPeople,
                                                    establishInitialSortOrderPeople,
                                                    sortOrderPreferencePeopleLocal,
                                                    clearNewPersonData,
                                                    clearNewForecastedPersonData,
                                                    teamInitiatives,
                                                    sortOrderPreference,
                                                    setSelectedTimeFrameTeamCost,
                                                    teamCostData,
                                                    clearNewInitiativeData,
                                                    establishInitialSortOrder
                                                )
                                            }
                                        />
                                    ) : null}
                                </DataTableHeadCell>
                                <DataTableHeadCell className="header-cell-left" colSpan="1">
                                    <Select
                                        className="select-month"
                                        onChange={(evt) => {
                                            if (monthHasChanges) {
                                                setUnsavedDataModalBool(true)
                                            } else {
                                                changeSelectedMonthData(
                                                    setSelectedTimeFrameId,
                                                    evt.value,
                                                    teamPeople,
                                                    forecastedPeople,
                                                    establishInitialSortOrderPeople,
                                                    sortOrderPreferencePeopleLocal,
                                                    clearNewPersonData,
                                                    clearNewForecastedPersonData,
                                                    teamInitiatives,
                                                    sortOrderPreference,
                                                    setSelectedTimeFrameTeamCost,
                                                    teamCostData,
                                                    clearNewInitiativeData,
                                                    establishInitialSortOrder
                                                )
                                            }
                                        }}
                                        options={formattedDates}
                                        placeholder={selectedTimeFrameName}
                                        value={selectedTimeFrameName}
                                    />
                                </DataTableHeadCell>
                                <DataTableHeadCell>
                                    {getTimeFrameNameNMonthsAway(
                                        selectedTimeFrameId,
                                        timeFrames,
                                        1
                                    ) ? (
                                        <Button
                                            className="navigate_next"
                                            label={
                                                getTimeFrameNameNMonthsAway(
                                                    selectedTimeFrameId,
                                                    timeFrames,
                                                    1
                                                ).split(' ')[0]
                                            }
                                            onClick={() =>
                                                changeSelectedMonthData(
                                                    setSelectedTimeFrameId,
                                                    getTimeFrameIdNMonthsAway(
                                                        selectedTimeFrameId,
                                                        timeFrames,
                                                        1
                                                    ),
                                                    teamPeople,
                                                    forecastedPeople,
                                                    establishInitialSortOrderPeople,
                                                    sortOrderPreferencePeopleLocal,
                                                    clearNewPersonData,
                                                    clearNewForecastedPersonData,
                                                    teamInitiatives,
                                                    sortOrderPreference,
                                                    setSelectedTimeFrameTeamCost,
                                                    teamCostData,
                                                    clearNewInitiativeData,
                                                    establishInitialSortOrder
                                                )
                                            }
                                            trailingIcon="navigate_next"
                                        />
                                    ) : null}
                                </DataTableHeadCell>
                                <DataTableHeadCell className="header-cell-right" colSpan="2">
                                    <ReactTooltip />
                                    <span
                                        data-tip="Please save initiative allocations before copying forward."
                                        data-tip-disable={monthHasChanges}
                                    >
                                        <Button
                                            disabled={this.isCopyForwardDisabled()}
                                            onClick={() =>
                                                setCopyCalendarModalBool(!copyCalendarModalBool)
                                            }
                                            outlined
                                        >
                                            Copy Forward To
                                        </Button>
                                    </span>

                                    <div>
                                        {copyCalendarModalBool && (
                                            <MonthDropdownContainer
                                                copyForwardFunction={copyInitiativesForward}
                                                overwrittenMonths={overwrittenMonths}
                                            />
                                        )}
                                    </div>
                                </DataTableHeadCell>
                            </DataTableRow>
                        </DataTableHead>
                        <DataTableHead>
                            {allowEditing && (
                                <DataTableRow>
                                    <DataTableCell colSpan="4">
                                        <Select
                                            isClearable
                                            onChange={(evt) => stageInitiative(evt)}
                                            onKeyDown={(evt) => {
                                                if (
                                                    evt.key === 'Enter' &&
                                                    !this.initiativeTableRef.current.state
                                                        .menuIsOpen &&
                                                    !isEmpty(newInitiativeData)
                                                ) {
                                                    addNewInitiativeFromState()
                                                }
                                            }}
                                            options={differenceBy(
                                                initiativeSelectOptions,
                                                map(selectedTimeFrameInitiatives, ({id}) => ({
                                                    value: {id}
                                                })),
                                                'value.id'
                                            )}
                                            placeholder="Add New Initiative"
                                            ref={this.initiativeTableRef}
                                            styles={multiLineOptionStyles}
                                            value={
                                                newInitiativeData.value.initiativeName
                                                    ? newInitiativeData
                                                    : null
                                            }
                                        />
                                    </DataTableCell>
                                    <DataTableCell alignStart>
                                        <Icon
                                            className="modify-initiative-button"
                                            icon="search_rounded"
                                            onClick={() => setIsInitiativeModifyFinderOpen(true)}
                                        />
                                    </DataTableCell>
                                </DataTableRow>
                            )}
                        </DataTableHead>
                        <DataTableHead>
                            <DataTableRow>
                                <DataTableHeadCell className="status-column">
                                    {allowEditing && 'Status'}
                                </DataTableHeadCell>
                                <DataTableHeadCell
                                    className="initiative-name-column"
                                    onClick={() => {
                                        setSortDir(nameNum, 'nameNum', 'initiativeName')
                                    }}
                                    sort={sortDir[nameNum]}
                                >
                                    Initiative
                                </DataTableHeadCell>
                                <DataTableHeadCell
                                    className="allocation-column"
                                    onClick={() =>
                                        setSortDir(allocationNum, 'allocationNum', 'teamCostPct')
                                    }
                                    sort={sortDir[allocationNum]}
                                >
                                    Allocation %
                                </DataTableHeadCell>
                                <DataTableHeadCell
                                    className="cost-column"
                                    onClick={() => setSortDir(costNum, 'costNum', 'initiativeCost')}
                                    sort={sortDir[costNum]}
                                >
                                    Monthly Cost
                                </DataTableHeadCell>
                                <DataTableHeadCell className="initiative-table-icon-column" />
                            </DataTableRow>
                        </DataTableHead>
                        <DataTableBody>
                            {teamInitiatives &&
                                map(selectedTimeFrameInitiatives, (initiative, index) => (
                                    <DataTableRow key={initiative.id}>
                                        {allowEditing ? (
                                            <DataTableCell
                                                className={
                                                    initiative.status === 'Funded'
                                                        ? 'status-cell-funded'
                                                        : 'status-cell-planning'
                                                }
                                            >
                                                {initiative.status === 'Funded' ? (
                                                    <span>
                                                        F
                                                        <span className="status-tooltip">
                                                            Funded
                                                        </span>
                                                    </span>
                                                ) : (
                                                    <span>
                                                        P
                                                        <span className="status-tooltip">
                                                            Planning
                                                        </span>
                                                    </span>
                                                )}
                                            </DataTableCell>
                                        ) : (
                                            <DataTableCell />
                                        )}
                                        <DataTableCell className="initiative-name-cell">
                                            <span className="info-span">
                                                <InitiativeCard
                                                    className="initiative-card"
                                                    initiative={initiative}
                                                />
                                                <Icon className="info-button" icon="info_outline" />
                                            </span>
                                            <a
                                                className="initiatives-link"
                                                href={`${vipUrl}/${initiative.id}`}
                                                rel="noopener noreferrer"
                                                target="_blank"
                                            >
                                                {`${initiative.initiativeName}`}
                                            </a>
                                        </DataTableCell>
                                        {allowEditing ? (
                                            <DataTableCell className="allocation-input">
                                                <input
                                                    onChange={(evt) => {
                                                        if (validatePct(evt.target.value)) {
                                                            const newInitiatives = cloneDeep(
                                                                selectedTimeFrameInitiatives
                                                            )
                                                            newInitiatives[index].teamCostPct =
                                                                Number(evt.target.value)
                                                            newInitiatives[index].initiativeCost =
                                                                Math.round(
                                                                    selectedTimeFrameTeamCost *
                                                                        (Number(evt.target.value) /
                                                                            100)
                                                                )
                                                            setSelectedTimeFrameInitiatives(
                                                                newInitiatives
                                                            )
                                                        }
                                                    }}
                                                    type="text"
                                                    value={
                                                        `${selectedTimeFrameInitiatives[index].teamCostPct}` ||
                                                        ''
                                                    }
                                                />
                                                %
                                            </DataTableCell>
                                        ) : (
                                            <DataTableCell className="allocation-display">
                                                {selectedTimeFrameInitiatives[index].teamCostPct}%
                                            </DataTableCell>
                                        )}
                                        <DataTableCell className="allocation-input">
                                            $
                                            <input
                                                className="new-allocation-input"
                                                onChange={(evt) => {
                                                    if (validateInitiativeCost(evt.target.value)) {
                                                        const newInitiatives = cloneDeep(
                                                            selectedTimeFrameInitiatives
                                                        )
                                                        // Guard against dividing by a $0 team
                                                        // cost (e.g. a team with no people yet),
                                                        // which previously produced
                                                        // Infinity/NaN percentages that got saved
                                                        // to the backend.
                                                        newInitiatives[index].teamCostPct =
                                                            selectedTimeFrameTeamCost > 0
                                                                ? Math.round(
                                                                      (Number(evt.target.value) /
                                                                          selectedTimeFrameTeamCost) *
                                                                          100
                                                                  )
                                                                : 0
                                                        newInitiatives[index].initiativeCost =
                                                            Number(evt.target.value)
                                                        setSelectedTimeFrameInitiatives(
                                                            newInitiatives
                                                        )
                                                    }
                                                }}
                                                type="text"
                                                value={
                                                    `${selectedTimeFrameInitiatives[index].initiativeCost}` ||
                                                    ''
                                                }
                                            />
                                        </DataTableCell>
                                        <DataTableCell>
                                            {allowEditing && (
                                                <Icon
                                                    className="delete-initiative-button"
                                                    icon="delete_forever"
                                                    onClick={() => {
                                                        addNewInitiative(initiative)
                                                    }}
                                                />
                                            )}
                                        </DataTableCell>
                                    </DataTableRow>
                                ))}
                            {allowEditing && hasManageTeams && (
                                <DataTableRow>
                                    <DataTableCell />
                                    <DataTableCell>Total</DataTableCell>
                                    <DataTableCell
                                        className={
                                            totalPercentage > 100
                                                ? 'allocation-total-invalid'
                                                : 'allocation-display'
                                        }
                                    >
                                        {totalPercentage}%
                                    </DataTableCell>
                                    <DataTableCell className="allocation-display">
                                        $
                                        {sumBy(selectedTimeFrameInitiatives, (initiative) =>
                                            Math.round(
                                                selectedTimeFrameTeamCost *
                                                    (initiative.teamCostPct / 100)
                                            )
                                        ).toLocaleString()}
                                    </DataTableCell>
                                    <DataTableCell />
                                </DataTableRow>
                            )}
                            {allowEditing && hasManageTeams && (
                                <DataTableRow>
                                    <DataTableCell alignEnd colSpan="5">
                                        <Button
                                            className="initiative-reset-button"
                                            disabled={monthHasChanges}
                                            onClick={() => resetAndClearSelectedInitiative()}
                                            outlined
                                        >
                                            cancel
                                        </Button>
                                        <Button
                                            disabled={this.isSaveDisabled()}
                                            onClick={() => {
                                                const saveAction = () => {
                                                    updateInitiativesSaga({
                                                        selectedTimeFrameId,
                                                        selectedTimeFrameInitiatives
                                                    })
                                                    setSaveLockedTimeFrameData({
                                                        showWarning: false
                                                    })
                                                }
                                                if (isTimeFrameLocked && allowEditing) {
                                                    setSaveLockedTimeFrameData({
                                                        showWarning: true,
                                                        saveAction
                                                    })
                                                } else {
                                                    saveAction()
                                                }
                                            }}
                                            raised
                                        >
                                            save
                                        </Button>
                                    </DataTableCell>
                                </DataTableRow>
                            )}
                            {isTimeFrameLocked && (
                                <DataTableRow>
                                    <DataTableCell
                                        colSpan="5"
                                        style={{textAlign: 'center', color: 'Grey'}}
                                    >
                                        LOCKED
                                        {allowEditing && ' - only admin users are allowed to edit'}
                                    </DataTableCell>
                                </DataTableRow>
                            )}
                        </DataTableBody>
                    </DataTableContent>
                </DataTable>
            </>
        )
    }
}

export default InitiativeTable
