import {connect} from 'react-redux'
import RenderChart from './RenderChart'
import getRelevantTimeFrames from '../../redux/selectors/getRelevantTimeFrames'
import getTimeFrameTeamInitiatives from '../../redux/selectors/getTimeFrameTeamInitiatives'

const mapStateToProps = (state) => ({
    teamInitiatives: getTimeFrameTeamInitiatives(state),
    relevantTimeFrames: getRelevantTimeFrames(state)
})

export default connect(mapStateToProps)(RenderChart)
