import {connect} from 'react-redux'
import {establishInitialSortOrder} from '../../redux/sagas/helpers/teamInitiatives'
import {establishInitialSortOrderPeople} from '../../redux/sagas/helpers/teamPeople'
import {
    getAllInitiatives,
    getInitiativeErrors,
    getInitiativesTableSort,
    getIsInitiativeCopyForwardContainerOpen,
    getNewInitiativeData,
    getSelectedTimeFrameTeamInitiatives,
    getTeamInitiatives
} from '../../redux/selectors/initiatives'
import {
    getCopyCalendarModalBool,
    getSaveLockedTimeFrameData,
    getSelectedTimeFrameId,
    getSelectedTimeFrameTeamCost,
    getSortOrderPreferenceLocal,
    getSortOrderPreferencePeopleLocal,
    getTeamCostData,
    getTimeFrames,
    getUnsavedChangesBool,
    getUnsavedDataModalBool
} from '../../redux/selectors'
import {getTeamForecastedPeople, getTeamPeople} from '../../redux/selectors/people'
import {initiativeActions, peopleActions, teamActions, timeFrameActions} from '../../redux/actions'
import InitiativeTable from './InitiativeTable'
import getCurrentMonthTimeFrame from '../../redux/selectors/getCurrentMonthTimeFrame'
import getHasManageTeams from '../../redux/selectors/getHasManageTeams'
import getInitiativeSelectOptions from '../../redux/selectors/initiatives/getInitiativeSelectOptions'
import getIsAdmin from '../../redux/selectors/getIsAdmin'
import getOverwrittenMonths from '../../redux/selectors/getOverwrittenMonths'
import getRelevantTimeFrames from '../../redux/selectors/getRelevantTimeFrames'
import getSelectedTimeFrame from '../../redux/selectors/getSelectedTimeFrame'
import preferencesActions from '../../redux/actions/preferencesActions'

const mapStateToProps = (state) => ({
    teamInitiatives: getTeamInitiatives(state),
    currentMonthTimeFrame: getCurrentMonthTimeFrame(state),
    initiativeSelectOptions: getInitiativeSelectOptions(state),
    hasManageTeams: getHasManageTeams(state),
    isAdmin: getIsAdmin(state),
    selectedTimeFrameId: getSelectedTimeFrameId(state),
    selectedTimeFrameTeamCost: getSelectedTimeFrameTeamCost(state),
    teamCostData: getTeamCostData(state),
    selectedTimeFrame: getSelectedTimeFrame(state),
    initiatives: getAllInitiatives(state),
    initiativeErrors: getInitiativeErrors(state),
    relevantTimeFrames: getRelevantTimeFrames(state),
    selectedTimeFrameInitiatives: getSelectedTimeFrameTeamInitiatives(state),
    newInitiativeData: getNewInitiativeData(state),
    isInitiativeCopyForwardContainerOpen: getIsInitiativeCopyForwardContainerOpen(state),
    initiativesTableSort: getInitiativesTableSort(state),
    copyCalendarModalBool: getCopyCalendarModalBool(state),
    sortOrderPreference: getSortOrderPreferenceLocal(state),
    timeFrames: getTimeFrames(state),
    unsavedChangesBool: getUnsavedChangesBool(state),
    saveLockedTimeFrameData: getSaveLockedTimeFrameData(state),
    teamPeople: getTeamPeople(state),
    forecastedPeople: getTeamForecastedPeople(state),
    sortOrderPreferencePeopleLocal: getSortOrderPreferencePeopleLocal(state),
    overwrittenMonths: getOverwrittenMonths(state),
    unsavedDataModal: getUnsavedDataModalBool(state)
})

const mapDispatchToProps = (dispatch) => ({
    updateInitiativesSaga: (payload) => dispatch(initiativeActions.updateInitiatives(payload)),
    setSelectedTimeFrameId: (timeframe) =>
        dispatch(timeFrameActions.setSelectedTimeFrameId(timeframe)),
    setSelectedTimeFrameTeamCost: (cost) =>
        dispatch(teamActions.setSelectedTimeFrameTeamCost(cost)),
    setSelectedTimeFrameInitiatives: (initiatives) =>
        dispatch(initiativeActions.setSelectedTimeFrameTeamInitiatives(initiatives)),
    setNewInitiativeData: (newInitiativeData) =>
        dispatch(initiativeActions.setNewInitiativeData(newInitiativeData)),
    addNewInitiative: (initiative) => dispatch(initiativeActions.addNewInitiative(initiative)),
    addNewInitiativeFromState: () => dispatch(initiativeActions.addNewInitiativeFromState()),
    clearNewInitiativeData: () => dispatch(initiativeActions.clearNewInitiativeData()),
    setIsInitiativeCopyForwardContainerOpen: (isInitiativeCopyForwardContainerOpen) =>
        dispatch(
            initiativeActions.setIsInitiativeCopyForwardContainerOpen(
                isInitiativeCopyForwardContainerOpen
            )
        ),
    setIsInitiativeModifyFinderOpen: (isInitiativeModifyFinderOpen) =>
        dispatch(initiativeActions.setIsInitiativeModifyFinderOpen(isInitiativeModifyFinderOpen)),
    setInitiativesTableSort: (payload) =>
        dispatch(initiativeActions.setInitiativesTableSort(payload)),
    setCopyCalendarModalBool: (payload) =>
        dispatch(timeFrameActions.setCopyCalendarModalBool(payload)),
    setSortOrderPreference: (payload) =>
        dispatch(preferencesActions.setSortOrderPreference(payload)),
    establishInitialSortOrder: (selectedTeamInitiatives, sortOrderPreference) =>
        dispatch(establishInitialSortOrder(selectedTeamInitiatives, sortOrderPreference)),
    setUnsavedChangesBool: (payload) => dispatch(teamActions.setUnsavedChangesBool(payload)),
    setSaveLockedTimeFrameData: (payload) =>
        dispatch(timeFrameActions.setSaveLockedTimeFrameData(payload)),
    establishInitialSortOrderPeople: (
        selectedTimeFramePeople,
        sortOrderPreferencePeople,
        forecasted
    ) =>
        dispatch(
            establishInitialSortOrderPeople(
                selectedTimeFramePeople,
                sortOrderPreferencePeople,
                forecasted
            )
        ),
    clearNewPersonData: (people) => dispatch(peopleActions.clearNewPersonData(people)),
    clearNewForecastedPersonData: (people) =>
        dispatch(peopleActions.clearNewForecastedPersonData(people)),
    setUnsavedDataModalBool: (team) => dispatch(teamActions.setUnsavedDataModalBool(team)),
    copyInitiativesForward: (payload) => dispatch(initiativeActions.copyInitiativesForward(payload))
})

export default connect(mapStateToProps, mapDispatchToProps)(InitiativeTable)
