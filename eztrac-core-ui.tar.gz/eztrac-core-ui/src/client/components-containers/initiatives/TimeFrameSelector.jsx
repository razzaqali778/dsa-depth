import {Select as RMWCSelect} from '@rmwc/select'
import React from 'react'

const TimeFrameSelector = ({
    timeFrameRangeOptions,
    startTimeFrame,
    endTimeFrame,
    setAppropriateTimeFrames
}) => (
    <div>
        <RMWCSelect
            className="time_frame_selectors_start"
            onChange={(evt) => {
                if (Number(evt.target.value) <= endTimeFrame) {
                    setAppropriateTimeFrames(true, Number(evt.target.value))
                }
            }}
            options={timeFrameRangeOptions}
            value={startTimeFrame}
        />
        <span className="time_frame_selectors_description_text">to</span>
        <RMWCSelect
            className="time_frame_selectors_end"
            onChange={(evt) => {
                if (Number(evt.target.value) >= startTimeFrame) {
                    setAppropriateTimeFrames(false, Number(evt.target.value))
                }
            }}
            options={timeFrameRangeOptions}
            value={endTimeFrame}
        />
    </div>
)

export default TimeFrameSelector
