import {connect} from 'react-redux'
import {getEndTimeFrame, getStartTimeFrame} from '../../redux/selectors'
import {timeFrameActions} from '../../redux/actions'
import TimeFrameSelector from './TimeFrameSelector'
import getInitiativeTimeFrameSelectOptions from '../../redux/selectors/initiatives/getInitiativeTimeFrameSelectOptions'

const mapStateToProps = (state) => ({
    startTimeFrame: getStartTimeFrame(state),
    endTimeFrame: getEndTimeFrame(state),
    timeFrameRangeOptions: getInitiativeTimeFrameSelectOptions(state)
})

const mapDispatchToProps = (dispatch) => ({
    setAppropriateTimeFrames: (settingStartTimeFrame, chosenTimeFrame) =>
        dispatch(
            timeFrameActions.setAppropriateTimeFrames({settingStartTimeFrame, chosenTimeFrame})
        )
})

export default connect(mapStateToProps, mapDispatchToProps)(TimeFrameSelector)
