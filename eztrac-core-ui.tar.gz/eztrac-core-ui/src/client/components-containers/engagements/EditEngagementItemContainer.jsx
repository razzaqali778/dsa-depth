import {connect} from 'react-redux'
import {engagementActions, timeFrameActions} from '../../redux/actions'
import {getSaveLockedTimeFrameData} from '../../redux/selectors'
import EditEngagementItem from './EditEngagementItem'
import getHasManageEfforts from '../../redux/selectors/getHasManageEfforts'
import getIsAdmin from '../../redux/selectors/getIsAdmin'

const mapStateToProps = (state) => ({
    hasManageEfforts: getHasManageEfforts(state),
    saveLockedTimeFrameData: getSaveLockedTimeFrameData(state),
    isAdmin: getIsAdmin(state)
})

const mapDispatchToProps = (dispatch) => ({
    updateEngagementSaga: (payload) => dispatch(engagementActions.updateEngagement(payload)),
    clearCalculatorRows: () => dispatch(engagementActions.clearCalculatorRows()),
    toggleIsCreatingEngagement: (boolean) =>
        dispatch(engagementActions.toggleIsCreatingEngagement(boolean)),
    setIsCalculating: (boolean) => dispatch(engagementActions.setIsCalculating(boolean)),
    setSelectedCalendar: (calendarId) =>
        dispatch(engagementActions.setSelectedCalendar(calendarId)),
    updateCalculatorSaga: (payload) => dispatch(engagementActions.updateCalculator(payload)),
    setSaveLockedTimeFrameData: (payload) =>
        dispatch(timeFrameActions.setSaveLockedTimeFrameData(payload))
})

export default connect(mapStateToProps, mapDispatchToProps)(EditEngagementItem)
