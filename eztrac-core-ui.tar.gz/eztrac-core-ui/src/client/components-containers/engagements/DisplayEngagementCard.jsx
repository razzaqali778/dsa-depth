import {
    Card,
    CardActionButtons,
    CardActionIcons,
    CardActions,
    CardActionButton,
    CardActionIcon
} from '@rmwc/card'
import {Icon} from '@rmwc/icon'
import React from 'react'
import _ from 'lodash'
import findIndex from 'lodash/findIndex'
import map from 'lodash/map'
import EditEngagementItemContainer from './EditEngagementItemContainer'
import CalculatedEngagementEditContainer from './CalculatedEngagementEditContainer'
import {canEditEngagement} from '../utils/canEditTimeFrame'

const engagementTimeFrameDisplay = (engagements) =>
    map(engagements, (e) => (
        <div className="engagement-timeframe-item" key={e.timeFrameId}>
            <EditEngagementItemContainer engagement={e} key={`${e.timeFrameId} ${e.amount}`} />
        </div>
    ))

const getDefaultEngagementMonths = (engagement, currentMonthTimeFrameId) => {
    const currentMonthIndex = findIndex(
        engagement,
        (timeFrame) => timeFrame.timeFrameId === currentMonthTimeFrameId.id
    )

    const timeFrameDisplayArray =
        currentMonthIndex > 0
            ? engagement.slice(currentMonthIndex - 1, currentMonthIndex + 3)
            : engagement.slice(0, 4)

    return timeFrameDisplayArray ? engagementTimeFrameDisplay(timeFrameDisplayArray) : null
}

const hasChangedSinceInitialState = (initialState, currentState) => initialState === currentState

class DisplayEngagementCard extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            showAll: false,
            isEditingComment: false,
            updatedComment: ''
        }
    }

    render() {
        const {
            openEditEngagementDialog,
            openRemoveEngagementDialog,
            engagement,
            updateEngagementSaga,
            updateCalculatedEngagementSaga,
            hasManageEfforts,
            currentMonthTimeFrameId,
            calculatorEngagementItem,
            groupedAndSortedEngagements,
            setSelectedEngagement,
            isCreatingEngagement,
            isAdmin,
            isEditing,
            setIsEditing
        } = this.props

        const {showAll, isEditingComment, updatedComment} = this.state

        if (isEditingComment && isEditing === false) {
            this.setState({isEditingComment: false})
        }

        const allowEditing = engagement.some((e) => canEditEngagement(e, isAdmin))
        const anyTimeFrameLocked = engagement.some((e) => e.timeFrameLockdown)
        const engagementWithComment = _.last(engagement)
        const displayAllTimeFrames =
            engagement.length <= 2 ||
            (engagement.length === 3 &&
                engagement[engagement.length - 1].timeFrameId !== currentMonthTimeFrameId.id)

        return (
            <Card className="display-engagement-card" key={engagement[0].engagementId}>
                <div>
                    <div className="engagement-card-heading">
                        {engagement[0].engagementName}
                        {!allowEditing && (
                            <p className="historicEngagement">Historic engagement, read only</p>
                        )}
                        {isAdmin && anyTimeFrameLocked && allowEditing && (
                            <p className="historicEngagement">
                                Only admin users are allowed to edit values for locked months
                            </p>
                        )}
                    </div>
                    <div>
                        <div className="engagement-card-purchase-order">
                            <span>{'Purchase Order: '}</span>
                            {`${engagement[0].purchaseOrder}`}
                        </div>

                        <div className="engagement-card-comment">
                            <label htmlFor="editComment">{'Comment: '}</label>
                            {isEditingComment ? (
                                <div>
                                    <input
                                        autoFocus // eslint-disable-line jsx-a11y/no-autofocus
                                        className="editComment"
                                        defaultValue={engagementWithComment?.comment}
                                        id="editComment"
                                        onChange={(event) => {
                                            this.setState({updatedComment: event.target.value})
                                        }}
                                        type="text"
                                    />
                                    <CardActions>
                                        <CardActionButtons>
                                            <CardActionButton
                                                className="cancelEditingComment"
                                                onClick={() => {
                                                    setIsEditing(false)
                                                    this.setState({isEditingComment: false})
                                                    this.setState({
                                                        updatedComment:
                                                            engagementWithComment?.comment
                                                    })
                                                }}
                                                outlined
                                            >
                                                Cancel
                                            </CardActionButton>
                                            <CardActionButton
                                                className="saveComment"
                                                disabled={hasChangedSinceInitialState(
                                                    engagementWithComment?.comment,
                                                    this.state.updatedComment
                                                )}
                                                onClick={() => {
                                                    const saveFixedAmountAction = (row) => {
                                                        updateEngagementSaga({
                                                            isUpdatingAll: false,
                                                            engagementCost: row.amount,
                                                            selectedTimeFrameId: row.timeFrameId,
                                                            selectedEngagementId: row.engagementId,
                                                            comment: updatedComment
                                                        })
                                                    }

                                                    const saveCalculatedAction = (row) => {
                                                        updateCalculatedEngagementSaga({
                                                            selectedTimeFrameId: row.timeFrameId,
                                                            selectedEngagementId: row.engagementId,
                                                            isUpdatingAll: false,
                                                            comment: updatedComment,
                                                            amountDetails: row.amountDetails
                                                        })
                                                    }

                                                    const rows = engagement
                                                    rows.forEach((row) => {
                                                        if (!row.amountDetails) {
                                                            saveFixedAmountAction(row)
                                                        } else {
                                                            saveCalculatedAction(row)
                                                        }
                                                    })
                                                }}
                                                outlined
                                                raised
                                            >
                                                Save
                                            </CardActionButton>
                                        </CardActionButtons>
                                    </CardActions>
                                </div>
                            ) : (
                                <div>
                                    <span className="comment-text">
                                        {engagementWithComment?.comment}
                                    </span>
                                    <Icon
                                        className="engagementIconButton editCommentIconButton"
                                        icon="edit"
                                        onClick={() => {
                                            setIsEditing(true)
                                            this.setState({isEditingComment: true})
                                        }}
                                        title="Edit Comment"
                                    />
                                </div>
                            )}
                        </div>

                        <div className="engagement-card-dates">
                            <h5>{`Start Date: ${engagement[0].timeFrameName}`}</h5>
                            <h5>
                                {`End Date: ${engagement[engagement.length - 1].timeFrameName}`}
                                {!hasManageEfforts || !allowEditing ? null : (
                                    <Icon
                                        className="engagementIconButton editEndIconButton"
                                        icon="edit"
                                        onClick={() => {
                                            setSelectedEngagement(engagement)
                                            openEditEngagementDialog()
                                        }}
                                        title="Edit End Date"
                                    />
                                )}
                            </h5>
                        </div>
                        {groupedAndSortedEngagements &&
                        calculatorEngagementItem &&
                        !isCreatingEngagement &&
                        engagement[0].engagementId === calculatorEngagementItem.engagementId ? (
                            <CalculatedEngagementEditContainer />
                        ) : (
                            <div>
                                <div className="engagement-timeframe-container">
                                    {showAll
                                        ? engagementTimeFrameDisplay(engagement)
                                        : getDefaultEngagementMonths(
                                              engagement,
                                              currentMonthTimeFrameId
                                          )}
                                </div>
                                {engagement.length < 4 &&
                                (!hasManageEfforts || !allowEditing) ? null : (
                                    <CardActions>
                                        {displayAllTimeFrames ? null : (
                                            <CardActionButtons>
                                                <CardActionButton
                                                    onClick={() =>
                                                        showAll
                                                            ? this.setState({showAll: false})
                                                            : this.setState({showAll: true})
                                                    }
                                                >
                                                    {' '}
                                                    {showAll ? 'Show Less' : 'Show More'}
                                                </CardActionButton>
                                            </CardActionButtons>
                                        )}
                                        {!hasManageEfforts || !allowEditing ? null : (
                                            <CardActionIcons>
                                                <CardActionIcon
                                                    className="remove-engagement-button"
                                                    icon="delete_forever"
                                                    onClick={() => {
                                                        setSelectedEngagement(engagement)
                                                        openRemoveEngagementDialog()
                                                    }}
                                                    title="Delete Engagement"
                                                />
                                            </CardActionIcons>
                                        )}
                                    </CardActions>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </Card>
        )
    }
}

export default DisplayEngagementCard
