import {connect} from 'react-redux'
import {
    getCloseEditEngagementDialog,
    getEditDialogOpened,
    getSelectedEngagement
} from '../../redux/selectors/engagements'
import {getSaveLockedTimeFrameData, getSelectedTeam} from '../../redux/selectors'
import EditEngagementDialog from './EditEngagementDialog'
import {engagementActions} from '../../redux/actions'
import getCurrentAndFutureYearTimeFrames from '../../redux/selectors/getCurrentAndFutureYearTimeFrames'
import getEndTimeFrameSelectOptions from '../../redux/selectors/engagements/getEndTimeFrameSelectOptions'
import getIsAdmin from '../../redux/selectors/getIsAdmin'
import getSelectedTimeFrame from '../../redux/selectors/getSelectedTimeFrame'
import timeFrameActions from '../../redux/actions/timeFramesActions'

const mapStateToProps = (state) => ({
    isAdmin: getIsAdmin(state),
    editDialogOpened: getEditDialogOpened(state),
    closeEditEngagementDialog: getCloseEditEngagementDialog(state),
    selectedTeam: getSelectedTeam(state),
    endTimeFrameSelectOptions: getEndTimeFrameSelectOptions(state),
    engagement: getSelectedEngagement(state),
    timeFrames: getCurrentAndFutureYearTimeFrames(state),
    selectedTimeFrame: getSelectedTimeFrame(state),
    saveLockedTimeFrameData: getSaveLockedTimeFrameData(state)
})

const mapDispatchToProps = (dispatch) => ({
    closeEditEngagementDialog: (boolean) => {
        dispatch(engagementActions.closeEditEngagementDialog(boolean))
    },
    endEngagementSaga: (payload) => {
        dispatch(engagementActions.endEngagement(payload))
    },
    createEngagementSaga: (payload) => {
        dispatch(engagementActions.createEngagement(payload))
    },
    createCalculatedEngagementSaga: (payload) => {
        dispatch(engagementActions.createCalculatedEngagement(payload))
    },
    setSelectedTimeFrameId: (timeframe) =>
        dispatch(timeFrameActions.setSelectedTimeFrameId(timeframe)),
    setSaveLockedTimeFrameData: (payload) =>
        dispatch(timeFrameActions.setSaveLockedTimeFrameData(payload))
})

export default connect(mapStateToProps, mapDispatchToProps)(EditEngagementDialog)
