import {Dialog, DialogActions, DialogButton, DialogContent, DialogTitle} from '@rmwc/dialog'
import React from 'react'

const RemoveEngagementDialog = ({
    removeEngagementSaga,
    closeRemoveEngagementDialog,
    removeDialogOpened,
    currentEngagement
}) => (
    <Dialog open={removeDialogOpened}>
        <DialogTitle>Removing {currentEngagement.engagementName}</DialogTitle>
        <DialogContent>
            Please confirm if you would like to remove this engagement for the current month and all
            future months. This will not remove data for historical months.
        </DialogContent>
        <DialogActions>
            <DialogButton
                onClick={() => {
                    closeRemoveEngagementDialog()
                }}
                outlined
            >
                Cancel
            </DialogButton>
            <DialogButton
                onClick={() => {
                    removeEngagementSaga({currentEngagement})
                    closeRemoveEngagementDialog()
                }}
                raised
            >
                Confirm
            </DialogButton>
        </DialogActions>
    </Dialog>
)

export default RemoveEngagementDialog
