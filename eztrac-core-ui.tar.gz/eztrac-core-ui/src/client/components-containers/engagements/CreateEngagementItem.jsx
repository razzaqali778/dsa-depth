import {Card, CardActionButtons, CardActions, CardActionButton} from '@rmwc/card'
import {Radio} from '@rmwc/radio'
import {TextField} from '@rmwc/textfield'
import React from 'react'
import Select from 'react-select'
import {
    conditionalMultilineOptionStyle,
    customStyles,
    multiLineOptionStyles
} from '../utils/styleUtil'
import {
    isDuplicateEngagement,
    isEngagementSaveDisabled,
    validateEngagementCost
} from '../../redux/utils/validatorsForEngagement'
import {removeNonDigitCharacters} from '../utils/numberFormatting'
import ScratchPadContainer from './scratchPad/ScratchPadContainer'

const getFilteredEndTimeFrameOptions = (startTimeFrameOptions, startTimeFrameIdValue) => {
    const startTimeFrameIndex = startTimeFrameOptions.findIndex(
        (tf) => tf.value === startTimeFrameIdValue
    )

    return startTimeFrameOptions.slice(startTimeFrameIndex)
}

const engagementDropdownStyles = {...multiLineOptionStyles, ...customStyles}
const timeFrameDropdownStyles = {...conditionalMultilineOptionStyle, ...customStyles}

class CreateEngagementItem extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            selectedStartTimeFrame: this.props.isAdmin
                ? this.props.startTimeFrameSelectOptions.find(
                      (tf) => tf.value === this.props.currentTimeFrame.id
                  )
                : this.props.startTimeFrameSelectOptions[0],
            selectedEndTimeFrame:
                this.props.startTimeFrameSelectOptions[
                    this.props.startTimeFrameSelectOptions.length - 1
                ],
            selectedEngagementId: '',
            comment: ''
        }
    }

    changeStartTimeFrame({value, label, isLocked}) {
        this.setState({
            selectedStartTimeFrame: {
                value,
                label,
                isLocked
            }
        })
        if (value > this.state.selectedEndTimeFrame.value) {
            this.setState({
                selectedEndTimeFrame: {
                    value,
                    label,
                    isLocked
                }
            })
        }
    }

    changeEndTimeFrame({value, label, isLocked}) {
        this.setState({
            selectedEndTimeFrame: {
                value,
                label,
                isLocked
            }
        })
    }

    render() {
        const {
            engagementOptions,
            toggleIsCreatingEngagement,
            createEngagementSaga,
            toggleIsCalculating,
            isCalculating,
            clearCalculatorRows,
            createCalculatedEngagement,
            allTeamEngagements,
            setTotalEngagementCost,
            totalEngagementCost,
            startTimeFrameSelectOptions,
            setSaveLockedTimeFrameData
        } = this.props

        const {selectedStartTimeFrame, selectedEndTimeFrame, selectedEngagementId, comment} =
            this.state

        const endTimeFrameOptions = getFilteredEndTimeFrameOptions(
            startTimeFrameSelectOptions,
            selectedStartTimeFrame.value
        )

        return (
            <Card className="addEngagementCard">
                <div className="engagementItem">
                    <Select
                        className="addEngagementDropdown"
                        isSearchable
                        label="Engagement to add"
                        onChange={(event) =>
                            this.setState({
                                selectedEngagementId: {
                                    value: event.value,
                                    label: event.label,
                                    isLocked: event.isLocked
                                }
                            })
                        }
                        options={engagementOptions}
                        placeholder="Engagement to add"
                        styles={engagementDropdownStyles}
                        value={this.state.selectedEngagementId}
                    />

                    <div className="timeFrameInputContainer">
                        <Select
                            className="timeFrameSelect"
                            label="Start Time Frame"
                            onChange={(event) => this.changeStartTimeFrame(event)}
                            options={startTimeFrameSelectOptions}
                            placeholder="Start Time Frame"
                            styles={timeFrameDropdownStyles}
                            value={
                                this.state.selectedStartTimeFrame
                                    ? this.state.selectedStartTimeFrame
                                    : startTimeFrameSelectOptions[0]
                            }
                        />
                    </div>

                    <div className="timeFrameInputContainer">
                        <Select
                            className="timeFrameSelect"
                            label="End Time Frame"
                            onChange={(event) => this.changeEndTimeFrame(event)}
                            options={endTimeFrameOptions}
                            placeholder="End Time Frame"
                            styles={timeFrameDropdownStyles}
                            value={
                                this.state.selectedEndTimeFrame
                                    ? this.state.selectedEndTimeFrame
                                    : startTimeFrameSelectOptions[
                                          startTimeFrameSelectOptions.length - 1
                                      ]
                            }
                        />
                    </div>

                    <span
                        className={
                            !isDuplicateEngagement(
                                allTeamEngagements,
                                selectedStartTimeFrame.value,
                                selectedEngagementId.value
                            )
                                ? 'errorBlockHidden'
                                : 'errorBlock'
                        }
                    >
                        Engagement already exists
                    </span>
                    <div className="create-engagement-item-radio-selector">
                        <Radio checked={!isCalculating} onChange={() => toggleIsCalculating(false)}>
                            Fixed Rate
                        </Radio>
                        <Radio
                            checked={isCalculating}
                            onChange={() => {
                                clearCalculatorRows()
                                toggleIsCalculating(true)
                            }}
                        >
                            Calculated Rate
                        </Radio>
                    </div>
                    {isCalculating ? (
                        <ScratchPadContainer
                            selectedEngagementId={selectedEngagementId.value}
                            selectedTimeFrameId={selectedStartTimeFrame.value}
                        />
                    ) : (
                        <div>
                            <div className="editFormGroup">
                                <div className="costInputContainer">
                                    <TextField
                                        className="createCostInput"
                                        label="Monthly Cost"
                                        onChange={(evt) => {
                                            const value = removeNonDigitCharacters(evt.target.value)
                                            if (validateEngagementCost(value)) {
                                                setTotalEngagementCost(value)
                                            }
                                        }}
                                        value={
                                            totalEngagementCost
                                                ? Number(totalEngagementCost).toLocaleString()
                                                : ''
                                        }
                                    />
                                </div>
                            </div>
                        </div>
                    )}
                    <div className="editFormGroup">
                        <div className="commentInputContainer">
                            <TextField
                                className="createCommentInput"
                                label="Add Comment (optional)"
                                onChange={(event) => this.setState({comment: event.target.value})}
                                value={comment}
                            />
                        </div>
                    </div>
                    <CardActions>
                        <CardActionButtons>
                            <CardActionButton
                                onClick={() => {
                                    toggleIsCreatingEngagement(false)
                                    clearCalculatorRows()
                                    // we may want to setSelectedCalendar back to default here
                                    setTotalEngagementCost('')
                                }}
                                outlined
                            >
                                Cancel
                            </CardActionButton>
                            <CardActionButton
                                disabled={
                                    isEngagementSaveDisabled(
                                        totalEngagementCost,
                                        selectedStartTimeFrame.value,
                                        selectedEngagementId.value
                                    ) ||
                                    isDuplicateEngagement(
                                        allTeamEngagements,
                                        selectedStartTimeFrame.value,
                                        selectedEngagementId.value
                                    )
                                }
                                onClick={() => {
                                    const saveAction = () => {
                                        const requestObject = {
                                            selectedStartTimeFrameId: selectedStartTimeFrame.value,
                                            selectedEndTimeFrameId: selectedEndTimeFrame.value,
                                            selectedEngagementId: selectedEngagementId.value,
                                            comment
                                        }

                                        if (isCalculating) {
                                            createCalculatedEngagement(requestObject)
                                            clearCalculatorRows()
                                        } else {
                                            createEngagementSaga(requestObject)
                                        }
                                        setTotalEngagementCost('')
                                    }
                                    if (
                                        selectedStartTimeFrame.isLocked ||
                                        selectedEndTimeFrame.isLocked
                                    ) {
                                        setSaveLockedTimeFrameData({
                                            showWarning: true,
                                            saveAction
                                        })
                                    } else {
                                        saveAction()
                                    }
                                }}
                                raised
                            >
                                Save
                            </CardActionButton>
                        </CardActionButtons>
                    </CardActions>
                </div>
            </Card>
        )
    }
}

export default CreateEngagementItem
