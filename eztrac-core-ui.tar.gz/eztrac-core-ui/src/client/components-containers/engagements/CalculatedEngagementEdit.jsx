import {CardActionButtons, CardActions, CardActionButton} from '@rmwc/card'
import {Checkbox} from '@rmwc/checkbox'
import React from 'react'
import {DEFAULT_RATE_CALENDAR} from '../../redux/constants/utilConstants'
import {getContractorHoursForDisplay} from '../../redux/utils/contractorHoursForDisplay'
import {isEngagementSaveDisabled} from '../../redux/utils/validatorsForEngagement'
import ScratchPadContainer from './scratchPad/ScratchPadContainer'

class CalculatedEngagementEdit extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            isUpdatingAll: false,
            engagementTimeFrames:
                this.props.groupedAndSortedEngagements[this.props.engagement.engagementId]
        }
    }

    render() {
        const {
            engagement,
            clearCalculatorRows,
            calendarHours,
            setTotalEngagementCost,
            setIsCalculating,
            updateCalculatedEngagementsSaga,
            setSelectedCalendar,
            selectedCalendarId,
            totalEngagementCost
        } = this.props

        const {isUpdatingAll, engagementTimeFrames} = this.state

        return (
            <div>
                <div>
                    <div className="calculate-edit-header">
                        <div className="calculate-edit-header-text">
                            {isUpdatingAll ? (
                                <p className="calculate-edit-timeFrame">
                                    {`Editing: ${engagement.timeFrameName} - ${engagementTimeFrames[engagementTimeFrames.length - 1].timeFrameName} `}
                                </p>
                            ) : (
                                <p className="calculate-edit-timeFrame">
                                    {`Editing: ${engagement.timeFrameName} (standard hours ${getContractorHoursForDisplay(
                                        calendarHours,
                                        selectedCalendarId,
                                        engagement.timeFrameId
                                    )})`}
                                </p>
                            )}
                            <div className="engagement-amount">
                                <p className="engagement-amount">
                                    Current Cost: ${Number(engagement.amount).toLocaleString()}
                                </p>
                            </div>
                        </div>
                    </div>
                    <ScratchPadContainer
                        selectedEngagementId={engagement.engagementId}
                        selectedTimeFrameId={engagement.timeFrameId}
                    />
                </div>
                <div className="updating-all-alert">
                    {isUpdatingAll &&
                        'ALERT! You are updating the cost for the current and all future months'}
                </div>
                <div>
                    <Checkbox
                        checked={isUpdatingAll}
                        label="Apply to future"
                        onChange={(evt) => {
                            this.setState({isUpdatingAll: evt.target.checked})
                        }}
                    />
                </div>
                <div>
                    <CardActions>
                        <CardActionButtons>
                            <CardActionButton
                                onClick={() => {
                                    clearCalculatorRows()
                                    setTotalEngagementCost(null)
                                    setIsCalculating({timeFrameId: null, engagementId: null})
                                    setSelectedCalendar(DEFAULT_RATE_CALENDAR)
                                }}
                                outlined
                            >
                                Cancel
                            </CardActionButton>
                            <CardActionButton
                                disabled={isEngagementSaveDisabled(
                                    totalEngagementCost,
                                    engagement.timeFrameId,
                                    engagement.engagementId
                                )}
                                onClick={() => {
                                    updateCalculatedEngagementsSaga({
                                        isUpdatingAll,
                                        selectedTimeFrameId: engagement.timeFrameId,
                                        selectedEngagementId: engagement.engagementId,
                                        comment: engagement.comment
                                    })
                                }}
                                raised
                            >
                                Save
                            </CardActionButton>
                        </CardActionButtons>
                    </CardActions>
                </div>
            </div>
        )
    }
}

export default CalculatedEngagementEdit
