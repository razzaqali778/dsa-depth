import {connect} from 'react-redux'
import {
    getCalendarHours,
    getSelectedRateCalendar,
    getTotalEngagementCost
} from '../../redux/selectors/engagements'
import CalculatedEngagementEdit from './CalculatedEngagementEdit'
import {engagementActions} from '../../redux/actions'
import getCalculatedEngagementEditItem from '../../redux/selectors/engagements/getCalculatedEngagementEditItem'
import getGroupedAndSortedEngagements from '../../redux/selectors/engagements/getGroupedAndSortedEngagements'

const mapStateToProps = (state) => ({
    engagement: getCalculatedEngagementEditItem(state),
    totalEngagementCost: getTotalEngagementCost(state),
    groupedAndSortedEngagements: getGroupedAndSortedEngagements(state),
    selectedCalendarId: getSelectedRateCalendar(state),
    calendarHours: getCalendarHours(state)
})

const mapDispatchToProps = (dispatch) => ({
    clearCalculatorRows: () => {
        dispatch(engagementActions.clearCalculatorRows())
    },
    setTotalEngagementCost: (cost) => {
        dispatch(engagementActions.setTotalEngagementCost(cost))
    },
    setIsCalculating: (value) => {
        dispatch(engagementActions.setIsCalculating(value))
    },
    setSelectedCalendar: (calendarId) => {
        dispatch(engagementActions.setSelectedCalendar(calendarId))
    },
    updateCalculatedEngagementsSaga: (payload) => {
        dispatch(engagementActions.updateCalculatedEngagements(payload))
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(CalculatedEngagementEdit)
