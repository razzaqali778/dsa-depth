import React from 'react'
import isEmpty from 'lodash/isEmpty'
import RenderActiveEngagements from './RenderActiveEngagements'
import RenderAllEngagements from './RenderAllEngagements'

const RenderEngagements = ({groupedAndSortedEngagements, showHistoricalEngagements}) => {
    if (!isEmpty(groupedAndSortedEngagements) && showHistoricalEngagements) {
        return <RenderAllEngagements groupedAndSortedEngagements={groupedAndSortedEngagements} />
    } else if (!isEmpty(groupedAndSortedEngagements)) {
        return <RenderActiveEngagements groupedAndSortedEngagements={groupedAndSortedEngagements} />
    } else if (isEmpty(groupedAndSortedEngagements) && showHistoricalEngagements) {
        return <h5>No historic engagements</h5>
    }

    return <h5>No active engagements</h5>
}

export default RenderEngagements
