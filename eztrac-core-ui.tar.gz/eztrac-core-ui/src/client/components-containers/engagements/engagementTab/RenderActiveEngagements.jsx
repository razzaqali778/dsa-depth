import React from 'react'
import isEmpty from 'lodash/isEmpty'
import map from 'lodash/map'
import DisplayEngagementCardContainer from '../DisplayEngagementCardContainer'
import {getActiveEngagements} from '../../../redux/utils/getActiveEngagements'

const RenderActiveEngagements = ({groupedAndSortedEngagements}) => {
    const activeEngagemments = getActiveEngagements(groupedAndSortedEngagements)

    if (isEmpty(activeEngagemments)) {
        return <h5>No active engagements</h5>
    }

    return map(activeEngagemments, (e) => (
        <DisplayEngagementCardContainer engagement={e} key={e[0].engagementId} />
    ))
}

export default RenderActiveEngagements
