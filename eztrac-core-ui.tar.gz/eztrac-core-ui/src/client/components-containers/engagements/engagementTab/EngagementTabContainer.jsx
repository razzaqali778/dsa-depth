import {connect} from 'react-redux'
import {engagementActions} from '../../../redux/actions'
import {
    getEditDialogOpened,
    getEngagementFilterPhrase,
    getIsCreatingEngagement,
    getIsShowingHistoricEngagements
} from '../../../redux/selectors/engagements'
import {getSaveLockedTimeFrameData} from '../../../redux/selectors'
import EngagementTab from './EngagementTab'
import getFilteredEngagements from '../../../redux/selectors/engagements/getFilteredEngagements'
import getHasManageEfforts from '../../../redux/selectors/getHasManageEfforts'
import getSelectedTimeFrame from '../../../redux/selectors/getSelectedTimeFrame'

const mapStateToProps = (state) => ({
    isCreatingEngagement: getIsCreatingEngagement(state),
    hasManageEfforts: getHasManageEfforts(state),
    filteredEngagements: getFilteredEngagements(state),
    editDialogOpened: getEditDialogOpened(state),
    isShowingHistoricEngagements: getIsShowingHistoricEngagements(state),
    filterPhrase: getEngagementFilterPhrase(state),
    selectedTimeFrame: getSelectedTimeFrame(state),
    saveLockedTimeFrameData: getSaveLockedTimeFrameData(state)
})

const mapDispatchToProps = (dispatch) => ({
    toggleIsCalculating: (boolean) => {
        dispatch(engagementActions.toggleIsCalculating(boolean))
    },
    toggleIsCreatingEngagement: (boolean) => {
        dispatch(engagementActions.toggleIsCreatingEngagement(boolean))
    },
    toggleHistoricEngagements: (boolean) => {
        dispatch(engagementActions.toggleHistoricEngagements(boolean))
    },
    setEngagementFilterPhrase: (string) => {
        dispatch(engagementActions.setEngagementFilterPhrase(string))
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(EngagementTab)
