import React from 'react'
import map from 'lodash/map'
import sortBy from 'lodash/sortBy'
import DisplayEngagementCardContainer from '../DisplayEngagementCardContainer'

const RenderAllEngagements = ({groupedAndSortedEngagements}) => {
    const groupedByHistoricEngagements = sortBy(
        groupedAndSortedEngagements,
        (engagement) => engagement[engagement.length - 1].timeFrameLockdown === true
    )

    return map(groupedByHistoricEngagements, (engagement) => (
        <DisplayEngagementCardContainer engagement={engagement} key={engagement[0].engagementId} />
    ))
}

export default RenderAllEngagements
