import {Fab} from '@rmwc/fab'
import {GridCell, GridInner} from '@rmwc/grid'
import {Switch} from '@rmwc/switch'
import React from 'react'
import CreateEngagementItemContainer from '../CreateEngagementItemContainer'
import EditEngagementDialogContainer from '../EditEngagementDialogContainer'
import RemoveEngagementDialogContainer from '../RemoveEngagementDialogContainer'
import RenderEngagements from './RenderEngagements'

const EngagementTab = ({
    toggleIsCreatingEngagement,
    isCreatingEngagement,
    hasManageEfforts,
    filteredEngagements,
    editDialogOpened,
    toggleIsCalculating,
    toggleHistoricEngagements,
    isShowingHistoricEngagements,
    setEngagementFilterPhrase,
    filterPhrase
}) => (
    <GridCell span="12">
        <EditEngagementDialogContainer key={editDialogOpened} />
        <RemoveEngagementDialogContainer />
        <GridInner>
            <GridCell span="4">
                <h3>
                    Engagements&nbsp;&nbsp;
                    {hasManageEfforts && (
                        <Fab
                            className="add-button"
                            icon="add"
                            onClick={() => {
                                toggleIsCalculating(false)
                                toggleIsCreatingEngagement(true)
                            }}
                            title="Add Engagement"
                        />
                    )}
                </h3>
            </GridCell>
            <GridCell span="4" />
            <GridCell align="bottom" span="2">
                <div className="container-input float-right">
                    <i aria-hidden="true" className="fa fa-search" />
                    <input
                        className="input-field"
                        id="searchBox"
                        onChange={(evt) => setEngagementFilterPhrase(evt.target.value)}
                        placeholder="Search..."
                        type="search"
                        value={filterPhrase}
                    />
                </div>
            </GridCell>
            <GridCell align="bottom" span="2">
                <h5 className="float-right">
                    Show Historic Engagements&nbsp;&nbsp;&nbsp;
                    <Switch
                        checked={isShowingHistoricEngagements}
                        className="float-right"
                        onClick={(evt) => {
                            toggleHistoricEngagements(evt.target.checked)
                        }}
                    />
                </h5>
            </GridCell>
        </GridInner>

        {isCreatingEngagement && <CreateEngagementItemContainer />}

        <div className="render-engagements">
            <RenderEngagements
                groupedAndSortedEngagements={filteredEngagements}
                showHistoricalEngagements={isShowingHistoricEngagements}
            />
        </div>
    </GridCell>
)

export default EngagementTab
