import {connect} from 'react-redux'
import {engagementActions, timeFrameActions} from '../../redux/actions'
import {
    getAllTeamEngagements,
    getIsCalculating,
    getTotalEngagementCost
} from '../../redux/selectors/engagements'
import {getSaveLockedTimeFrameData} from '../../redux/selectors'
import CreateEngagementItem from './CreateEngagementItem'
import getCurrentMonthTimeFrame from '../../redux/selectors/getCurrentMonthTimeFrame'
import getEngagementOptionsSelectValue from '../../redux/selectors/engagements/getEngagementSelectOptions'
import getIsAdmin from '../../redux/selectors/getIsAdmin'
import getStartTimeFrameSelectOptions from '../../redux/selectors/engagements/getStartTimeFrameSelectOptions'

const mapStateToProps = (state) => ({
    isAdmin: getIsAdmin(state),
    currentTimeFrame: getCurrentMonthTimeFrame(state),
    engagementOptions: getEngagementOptionsSelectValue(state),
    isCalculating: getIsCalculating(state),
    allTeamEngagements: getAllTeamEngagements(state),
    totalEngagementCost: getTotalEngagementCost(state),
    startTimeFrameSelectOptions: getStartTimeFrameSelectOptions(state),
    saveLockedTimeFrameData: getSaveLockedTimeFrameData(state)
})

const mapDispatchToProps = (dispatch) => ({
    createEngagementSaga: (payload) => {
        dispatch(engagementActions.createEngagement(payload))
    },
    toggleIsCreatingEngagement: (boolean) => {
        dispatch(engagementActions.toggleIsCreatingEngagement(boolean))
    },
    toggleIsCalculating: (value) => {
        dispatch(engagementActions.toggleIsCalculating(value))
    },
    clearCalculatorRows: () => {
        dispatch(engagementActions.clearCalculatorRows())
    },
    createCalculatedEngagement: (payload) => {
        dispatch(engagementActions.createCalculatedEngagement(payload))
    },
    setSelectedRateCalendar: (calendarId) => {
        dispatch(engagementActions.setSelectedCalendar(calendarId))
    },
    setTotalEngagementCost: (cost) => {
        dispatch(engagementActions.setTotalEngagementCost(cost))
    },
    setSaveLockedTimeFrameData: (payload) => {
        dispatch(timeFrameActions.setSaveLockedTimeFrameData(payload))
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(CreateEngagementItem)
