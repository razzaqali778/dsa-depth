import {connect} from 'react-redux'
import {engagementActions} from '../../redux/actions'
import {
    getCloseRemoveEngagementDialog,
    getRemoveDialogOpened
} from '../../redux/selectors/engagements'
import RemoveEngagementDialog from './RemoveEngagementDialog'
import getCurrentEngagement from '../../redux/selectors/engagements/getCurrentEngagement'

const mapStateToProps = (state) => ({
    closeRemoveEngagementDialog: getCloseRemoveEngagementDialog(state),
    removeDialogOpened: getRemoveDialogOpened(state),
    currentEngagement: getCurrentEngagement(state)
})

const mapDispatchToProps = (dispatch) => ({
    removeEngagementSaga: (payload) => {
        dispatch(engagementActions.removeEngagement(payload))
    },
    closeRemoveEngagementDialog: (boolean) => {
        dispatch(engagementActions.closeRemoveEngagementDialog(boolean))
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(RemoveEngagementDialog)
