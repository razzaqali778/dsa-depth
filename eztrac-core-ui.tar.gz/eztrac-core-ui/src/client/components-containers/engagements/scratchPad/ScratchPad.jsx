import {Button, ButtonIcon} from '@rmwc/button'
import {Elevation} from '@rmwc/elevation'
import {Select} from '@rmwc/select'
import {TextField} from '@rmwc/textfield'
import React from 'react'
import forEach from 'lodash/forEach'
import isEmpty from 'lodash/isEmpty'
import CalculatorTable from './CalculatorTable'
import {
    isAddRateDisabled,
    validateHourlyRate,
    validatePeopleField
} from '../../../redux/utils/validatorsForEngagement'

class ScratchPad extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            hourlyRate: null,
            numberOfPeople: null
        }
    }

    render() {
        const {
            calculatorRows,
            updateCalculator,
            calendarSelectOptions,
            selectedTimeFrameId,
            selectedEngagementId,
            selectedCalendarId,
            totalEngagementCost,
            setSelectedCalendarId
        } = this.props

        const {hourlyRate, numberOfPeople} = this.state

        return (
            <div>
                <div>
                    <Select
                        label="Rate Calendar"
                        onChange={(evt) => {
                            setSelectedCalendarId(evt.target.value)
                            forEach(calculatorRows, (row) => {
                                updateCalculator({
                                    hourlyRate: row.hourlyRate,
                                    numberOfPeople: row.people,
                                    selectedTimeFrameId,
                                    timeStamp: row.timeStamp
                                })
                            })
                        }}
                        options={calendarSelectOptions}
                        value={selectedCalendarId}
                    />
                    <br />
                    <Elevation className="calculator" z="1">
                        <div className="calculator-field">
                            <TextField
                                label="Hourly Rate"
                                onChange={(evt) => {
                                    const {value} = evt.target
                                    if (validateHourlyRate(value)) {
                                        this.setState({hourlyRate: value})
                                    }
                                }}
                                value={hourlyRate || ''}
                            />
                        </div>
                        <div className="calculator-field">
                            <TextField
                                label="Number Of People"
                                onChange={(evt) => {
                                    const {value} = evt.target
                                    if (validatePeopleField(value)) {
                                        this.setState({numberOfPeople: value})
                                    }
                                }}
                                value={numberOfPeople || ''}
                            />
                        </div>
                        <div className="calculator-field total">
                            <Button
                                disabled={isAddRateDisabled({
                                    selectedCalendarId,
                                    hourlyRate,
                                    numberOfPeople,
                                    selectedTimeFrameId,
                                    selectedEngagementId
                                })}
                                onClick={() => {
                                    updateCalculator({
                                        hourlyRate,
                                        numberOfPeople,
                                        selectedTimeFrameId
                                    })
                                }}
                                raised
                            >
                                <ButtonIcon icon="add" />
                                Add Rate
                            </Button>
                        </div>
                        {isEmpty(calculatorRows) ? null : (
                            <CalculatorTable
                                calculatorRows={calculatorRows}
                                key={selectedCalendarId}
                                selectedTimeFrameId={selectedTimeFrameId}
                                totalEngagementCost={totalEngagementCost}
                                updateCalculator={updateCalculator}
                            />
                        )}
                    </Elevation>
                </div>
            </div>
        )
    }
}

export default ScratchPad
