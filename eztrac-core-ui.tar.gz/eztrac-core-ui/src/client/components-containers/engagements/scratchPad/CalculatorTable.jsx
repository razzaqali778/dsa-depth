import '@rmwc/data-table/data-table.css'
import {
    DataTable,
    DataTableBody,
    DataTableCell,
    DataTableContent,
    DataTableHead,
    DataTableHeadCell,
    DataTableRow
} from '@rmwc/data-table'
import {Icon} from '@rmwc/icon'
import React from 'react'
import {validatePeopleField} from '../../../redux/utils/validatorsForEngagement'

const CalculatorTable = ({
    calculatorRows,
    totalEngagementCost,
    selectedTimeFrameId,
    updateCalculator
}) => (
    <DataTable>
        <DataTableContent>
            <DataTableHead>
                <DataTableRow>
                    <DataTableHeadCell />
                    <DataTableHeadCell>Hourly Rate</DataTableHeadCell>
                    <DataTableHeadCell>People</DataTableHeadCell>
                    <DataTableHeadCell>Monthly Cost</DataTableHeadCell>
                    <DataTableHeadCell>Comment (optional)</DataTableHeadCell>
                </DataTableRow>
            </DataTableHead>
            <DataTableBody className="calculator-table-body">
                {calculatorRows &&
                    calculatorRows.map((row) => (
                        <DataTableRow key={row.timeStamp}>
                            <DataTableCell>
                                <Icon
                                    icon="remove_circle_outlined"
                                    onClick={() => {
                                        updateCalculator({
                                            rowToRemove: row,
                                            isRemoving: true
                                        })
                                    }}
                                />
                            </DataTableCell>
                            <DataTableCell>{`$${row.hourlyRate}`}</DataTableCell>
                            <DataTableCell>
                                <input
                                    className="people-input"
                                    onChange={(evt) => {
                                        let {value} = evt.target
                                        if (value === '') {
                                            value = 0
                                        }
                                        if (validatePeopleField(value) || value === 0) {
                                            const updatedRow = {
                                                ...row,
                                                numberOfPeople: evt.target.value,
                                                selectedTimeFrameId
                                            }
                                            updateCalculator({...updatedRow})
                                        }
                                    }}
                                    type="text"
                                    value={row.people}
                                />
                            </DataTableCell>
                            <DataTableCell>{`$${Number(Math.round(row.startingCost)).toLocaleString()}`}</DataTableCell>
                            <DataTableCell>
                                <input
                                    className="comment-input"
                                    defaultValue={row.comment}
                                    onChange={(evt) => {
                                        const updatedRow = {
                                            ...row,
                                            numberOfPeople: row.people,
                                            comment: evt.target.value,
                                            selectedTimeFrameId
                                        }
                                        updateCalculator({...updatedRow})
                                    }}
                                    type="text"
                                />
                            </DataTableCell>
                        </DataTableRow>
                    ))}
                <DataTableRow>
                    <DataTableCell />
                    <DataTableCell />
                    <DataTableCell />
                    <DataTableCell className="calculator-total">
                        Total: ${Number(Math.round(totalEngagementCost)).toLocaleString()}
                    </DataTableCell>
                </DataTableRow>
            </DataTableBody>
        </DataTableContent>
    </DataTable>
)

export default CalculatorTable
