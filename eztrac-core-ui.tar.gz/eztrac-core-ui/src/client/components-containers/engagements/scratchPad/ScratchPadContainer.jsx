import {connect} from 'react-redux'
import {
    getCalculatorRows,
    getSelectedRateCalendar,
    getTotalEngagementCost
} from '../../../redux/selectors/engagements'
import ScratchPad from './ScratchPad'
import engagementActions from '../../../redux/actions/engagementActions'
import getCalendarSelectOptions from '../../../redux/selectors/engagements/getCalendarSelectOptions'

const mapStateToProps = (state) => ({
    calculatorRows: getCalculatorRows(state),
    calendarSelectOptions: getCalendarSelectOptions(state),
    totalEngagementCost: getTotalEngagementCost(state),
    selectedCalendarId: getSelectedRateCalendar(state)
})

const mapDispatchToProps = (dispatch) => ({
    updateCalculator: (payload) => {
        dispatch(engagementActions.updateCalculator(payload))
    },
    setSelectedCalendarId: (payload) => {
        dispatch(engagementActions.setSelectedCalendar(payload))
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(ScratchPad)
