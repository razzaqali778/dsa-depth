import {Dialog, DialogActions, DialogButton, DialogContent, DialogTitle} from '@rmwc/dialog'
import {Select} from '@rmwc/select'
import React from 'react'
import {saveEditedEngagement} from '../utils/editEngagement'

class EditEngagementDialog extends React.Component {
    constructor() {
        super()
        this.state = {
            endTimeFrame: ''
        }
    }

    displayEngagementName() {
        const engagementNameExists =
            this.props.engagement && this.props.engagement[0].engagementName

        return engagementNameExists ? this.props.engagement[0].engagementName : ''
    }

    handleSave(timeFrameId) {
        const {
            closeEditEngagementDialog,
            endEngagementSaga,
            createEngagementSaga,
            createCalculatedEngagementSaga,
            selectedTeam,
            engagement,
            timeFrames,
            setSaveLockedTimeFrameData
        } = this.props

        const saveAction = () => {
            saveEditedEngagement(
                timeFrameId,
                endEngagementSaga,
                createEngagementSaga,
                createCalculatedEngagementSaga,
                selectedTeam,
                engagement,
                timeFrames
            )
        }

        const selectedTimeFrameIndex = timeFrames.findIndex((tf) => tf.id === timeFrameId)

        const currentEndTimeFrameId = engagement[engagement.length - 1].timeFrameId
        const currentEndTimeFrameIndex = timeFrames.findIndex(
            (tf) => tf.id === currentEndTimeFrameId
        )

        const timeFramesToModify =
            selectedTimeFrameIndex > currentEndTimeFrameIndex
                ? timeFrames.slice(currentEndTimeFrameIndex + 1, selectedTimeFrameIndex + 1)
                : timeFrames.slice(selectedTimeFrameIndex + 1, currentEndTimeFrameIndex + 1)

        const shouldShowWarning = timeFramesToModify.some((timeFrame) => timeFrame.lockdown)

        closeEditEngagementDialog()

        if (shouldShowWarning) {
            setSaveLockedTimeFrameData({showWarning: true, saveAction})
        } else {
            saveAction()
        }
    }

    render() {
        const {closeEditEngagementDialog, editDialogOpened, engagement, endTimeFrameSelectOptions} =
            this.props

        const currentEndIndex = endTimeFrameSelectOptions?.findIndex(
            (tf) => tf.value === engagement[engagement.length - 1].timeFrameId
        )

        const currentEndTimeFrameValue = endTimeFrameSelectOptions[currentEndIndex]?.value

        const {endTimeFrame, invalidCost, engagementCost} = this.state

        return (
            <Dialog open={editDialogOpened}>
                <DialogTitle>Edit: {this.displayEngagementName()}</DialogTitle>
                <DialogContent>
                    <span>Please amend engagement details below.</span>
                    <br />
                    <br />
                    <Select
                        className="timeFrameEndSelect"
                        label="Edit end date"
                        onChange={(event) =>
                            this.setState({endTimeFrame: Number(event.target.value)})
                        }
                        options={endTimeFrameSelectOptions}
                        value={
                            this.state.endTimeFrame
                                ? this.state.endTimeFrame
                                : currentEndTimeFrameValue
                        }
                    />
                </DialogContent>
                <DialogActions>
                    <DialogButton
                        className="cancel-button"
                        onClick={() => {
                            closeEditEngagementDialog()
                        }}
                        outlined
                    >
                        Cancel
                    </DialogButton>
                    <DialogButton
                        disabled={!endTimeFrame && (invalidCost || !engagementCost)}
                        onClick={() => {
                            this.handleSave(this.state.endTimeFrame)
                        }}
                        raised
                    >
                        Save
                    </DialogButton>
                </DialogActions>
            </Dialog>
        )
    }
}

export default EditEngagementDialog
