import {Button} from '@rmwc/button'
import {Checkbox} from '@rmwc/checkbox'
import {Icon} from '@rmwc/icon'
import {get} from 'lodash'
import React from 'react'
import forEach from 'lodash/forEach'
import {canEditEngagement} from '../utils/canEditTimeFrame'
import {
    isEngagementSaveDisabled,
    validateEditCostInput
} from '../../redux/utils/validatorsForEngagement'
import {removeNonDigitCharacters} from '../utils/numberFormatting'

const calculatorIcon = (
    <svg style={{width: 24, height: 24}} viewBox="0 0 24 24">
        <path
            d="M7,2H17A2,2 0 0,1 19,4V20A2,2 0 0,1 17,22H7A2,2 0 0,1 5,20V4A2,2 0 0,1 7,2M7,4V8H17V4H7M7,10V12H9V10H7M11,10V12H13V10H11M15,10V12H17V10H15M7,14V16H9V14H7M11,14V16H13V14H11M15,14V16H17V14H15M7,18V20H9V18H7M11,18V20H13V18H11M15,18V20H17V18H15Z"
            fill="#2880B9"
        />
    </svg>
)

const setScratchPadData = (engagement, setSelectedCalendar, updateCalculatorSaga) => {
    if (engagement.amountDetails) {
        setSelectedCalendar(engagement.amountDetails.calendarId)

        forEach(engagement.amountDetails.rates, (rate) => {
            updateCalculatorSaga({
                hourlyRate: rate.hourlyRate,
                numberOfPeople: rate.people,
                selectedTimeFrameId: engagement.timeFrameId,
                comment: rate.comment
            })
        })
    }
}

class EditEngagementItem extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            isUpdatingAll: false,
            engagementCost: this.props.engagement.amount
                ? this.props.engagement.amount.toString()
                : '',
            isEditing: false
        }
    }

    render() {
        const {
            engagement,
            updateEngagementSaga,
            hasManageEfforts,
            clearCalculatorRows,
            toggleIsCreatingEngagement,
            setIsCalculating,
            updateCalculatorSaga,
            setSelectedCalendar,
            setSaveLockedTimeFrameData,
            isAdmin
        } = this.props

        const {isUpdatingAll, engagementCost, isEditing} = this.state

        const allowEditing = canEditEngagement(engagement, isAdmin)
        const isTimeFrameLocked = get(engagement, 'timeFrameLockdown', false)

        return (
            <div>
                <div className="editEngagementLabel pull-left">
                    {`${engagement.timeFrameName}:`}
                </div>
                <div className="editContainer pull-right">
                    {!hasManageEfforts || !allowEditing ? (
                        <p className="engagement-amount">
                            ${Number(engagement.amount).toLocaleString()}
                        </p>
                    ) : (
                        <div>
                            <div className="cost-input">
                                <input
                                    onChange={(evt) => {
                                        const value = removeNonDigitCharacters(evt.target.value)
                                        if (validateEditCostInput(value) || value === '') {
                                            this.setState({engagementCost: value})
                                        }
                                    }}
                                    onFocus={() => this.setState({isEditing: true})}
                                    value={`$${Number(removeNonDigitCharacters(engagementCost)).toLocaleString()}`}
                                />
                            </div>
                            <div className="pull-right">
                                {!isEditing ? (
                                    <div>
                                        <Icon
                                            className="engagementCalculatorIcon"
                                            icon={calculatorIcon}
                                            onClick={() => {
                                                clearCalculatorRows()
                                                setScratchPadData(
                                                    engagement,
                                                    setSelectedCalendar,
                                                    updateCalculatorSaga
                                                )
                                                toggleIsCreatingEngagement(false)
                                                setIsCalculating({
                                                    timeFrameId: engagement.timeFrameId,
                                                    engagementId: engagement.engagementId
                                                })
                                            }}
                                            title="Cost Calculator"
                                        />
                                    </div>
                                ) : (
                                    <div>
                                        <Button
                                            className="engagementBtn"
                                            onClick={() => {
                                                this.setState({isEditing: false})
                                                this.setState({
                                                    engagementCost: engagement.amount.toString()
                                                })
                                            }}
                                        >
                                            Cancel
                                        </Button>
                                        <Button
                                            className="engagementBtn"
                                            disabled={isEngagementSaveDisabled(
                                                engagementCost,
                                                engagement.timeFrameId,
                                                engagement.engagementId
                                            )}
                                            onClick={() => {
                                                const saveAction = () => {
                                                    updateEngagementSaga({
                                                        isUpdatingAll,
                                                        engagementCost,
                                                        selectedTimeFrameId: engagement.timeFrameId,
                                                        selectedEngagementId:
                                                            engagement.engagementId,
                                                        comment: engagement.comment
                                                    })
                                                }
                                                if (isTimeFrameLocked && allowEditing) {
                                                    setSaveLockedTimeFrameData({
                                                        showWarning: true,
                                                        saveAction
                                                    })
                                                } else {
                                                    saveAction()
                                                }
                                                this.setState({isEditing: false})
                                            }}
                                            raised
                                        >
                                            Save
                                        </Button>
                                        <div className="apply-to-all">
                                            <Checkbox
                                                checked={isUpdatingAll}
                                                label="Apply to future"
                                                onChange={(evt) => {
                                                    this.setState({
                                                        isUpdatingAll: evt.target.checked
                                                    })
                                                }}
                                            />
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        )
    }
}

export default EditEngagementItem
