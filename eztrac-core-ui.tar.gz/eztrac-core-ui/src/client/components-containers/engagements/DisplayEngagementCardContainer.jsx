import {connect} from 'react-redux'
import {engagementActions} from '../../redux/actions'
import {getIsCreatingEngagement, getIsEditingEngagement} from '../../redux/selectors/engagements'
import DisplayEngagementCard from './DisplayEngagementCard'
import getCalculatedEngagementEditItem from '../../redux/selectors/engagements/getCalculatedEngagementEditItem'
import getCurrentMonthTimeFrame from '../../redux/selectors/getCurrentMonthTimeFrame'
import getGroupedAndSortedEngagements from '../../redux/selectors/engagements/getGroupedAndSortedEngagements'
import getHasManageEfforts from '../../redux/selectors/getHasManageEfforts'
import getIsAdmin from '../../redux/selectors/getIsAdmin'

const mapStateToProps = (state) => ({
    hasManageEfforts: getHasManageEfforts(state),
    currentMonthTimeFrameId: getCurrentMonthTimeFrame(state),
    calculatorEngagementItem: getCalculatedEngagementEditItem(state),
    groupedAndSortedEngagements: getGroupedAndSortedEngagements(state),
    isCreatingEngagement: getIsCreatingEngagement(state),
    isAdmin: getIsAdmin(state),
    isEditing: getIsEditingEngagement(state)
})

const mapDispatchToProps = (dispatch) => ({
    setSelectedEngagement: (engagement) =>
        dispatch(engagementActions.setSelectedEngagement(engagement)),
    openEditEngagementDialog: (boolean) =>
        dispatch(engagementActions.openEditEngagementDialog(boolean)),
    openRemoveEngagementDialog: (boolean) =>
        dispatch(engagementActions.openRemoveEngagementDialog(boolean)),
    updateEngagementSaga: (payload) => dispatch(engagementActions.updateEngagement(payload)),
    updateCalculatedEngagementSaga: (payload) =>
        dispatch(engagementActions.updateCalculatedEngagements(payload)),
    setIsEditing: (payload) => {
        dispatch(engagementActions.setIsEditingEngagement(payload))
    }
})

export default connect(mapStateToProps, mapDispatchToProps)(DisplayEngagementCard)
