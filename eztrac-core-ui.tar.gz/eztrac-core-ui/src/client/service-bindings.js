import {setupServiceBindings} from '@bayerit/phoenix-static-site-helpers'

const defaultBindings = {
    'phoenix-home': 'phoenix-tools-np.io',
    'profile-url': 'https://profile.phoenix-tools-np.io',
    'ez-trac-vip-ui': 'https://peadmin-np.monsanto.net/ez-trac-vip',
    'ez-trac-core': 'https://ez-trac-core-services.velocity-np.ag',
    'ez-trac-costing': 'https://ez-trac-costing-services.velocity-np.ag',
    'ez-trac-vip': 'https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services'
}

const bindingMap = {
    prod: {
        ...defaultBindings,
        'phoenix-home': 'phoenix-tools.io',
        'profile-url': 'https://profile.phoenix-tools.io',
        'ez-trac-vip-ui': 'https://peadmin.monsanto.net/ez-trac-vip',
        'ez-trac-core': 'https://ez-trac-core-services.velocity.ag',
        'ez-trac-costing': 'https://ez-trac-costing-services.velocity.ag',
        'ez-trac-vip': 'https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services'
    },
    local: {
        ...defaultBindings,
        'ez-trac-core': 'http://127.0.0.1:3560'
    },
    default: {
        ...defaultBindings
    }
}

setupServiceBindings({autoDetect: true, bindingMap})
