import {createSelector} from 'reselect'
import includes from 'lodash/includes'
import map from 'lodash/map'
import {getCurrentUser} from '.'

const isAdmin = (user) => {
    if (user && user.entitlements) {
        const entitlementCodes = map(user.entitlements, (e) => e.code)

        return includes(entitlementCodes, 'eztrac-admin-user')
    }

    return false
}

export default createSelector(getCurrentUser, (user) => isAdmin(user))
