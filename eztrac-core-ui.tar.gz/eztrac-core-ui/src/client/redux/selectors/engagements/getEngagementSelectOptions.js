import {createSelector} from 'reselect'
import filter from 'lodash/filter'
import map from 'lodash/map'
import sortBy from 'lodash/sortBy'
import {getEngagementOptions} from '.'

export default createSelector(getEngagementOptions, (engagements) => {
    const activeEngagements = filter(engagements, {isActive: true})
    const sortedEngagements = sortBy(activeEngagements, 'name')

    return map(sortedEngagements, ({id, name, purchaseOrder}) => ({
        value: id,
        label: `PO ${purchaseOrder}\n${name}`
    }))
})
