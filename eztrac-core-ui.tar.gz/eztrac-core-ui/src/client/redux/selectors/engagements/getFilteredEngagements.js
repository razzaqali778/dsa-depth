import {createSelector} from 'reselect'
import _ from 'lodash'
import {getEngagementFilterPhrase} from '.'
import getGroupedAndSortedEngagements from './getGroupedAndSortedEngagements'

const filterEngagements = (engagements, filterPhrase) => {
    let filteredEngagements = {}

    Object.keys(engagements).forEach((key) => {
        const {engagementName, purchaseOrder} = engagements[key][0]
        if (
            _.some(
                [engagementName, purchaseOrder],
                (property) =>
                    property && _.includes(property.toUpperCase(), filterPhrase.toUpperCase())
            )
        ) {
            filteredEngagements = {
                ...filteredEngagements,
                [key]: engagements[key]
            }
        }
    })

    return filteredEngagements
}

export default createSelector(
    getGroupedAndSortedEngagements,
    getEngagementFilterPhrase,
    (engagements, filterPhrase) => filterEngagements(engagements, filterPhrase.trim())
)
