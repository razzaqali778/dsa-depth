import {createSelector} from 'reselect'
import groupBy from 'lodash/groupBy'
import sortBy from 'lodash/sortBy'
import {getAllTeamEngagements, getEngagementOptions} from '.'
import {getTimeFrames} from '..'
import denormalize from '../../utils/denormalizeTimeFrameEngagementUtil'

const arrayIsEmpty = (array) => !array || array.length === 0

const groupAndSort = (engagements, timeFrames, engagementOptions) => {
    if (arrayIsEmpty(timeFrames) || arrayIsEmpty(engagementOptions)) return {}
    const denormalizedData = denormalize(engagements, timeFrames, engagementOptions)
    const sortedEngagements = sortBy(denormalizedData, 'startDate')
    const groupedEngagements = groupBy(sortedEngagements, (engagement) => engagement.engagementId)

    return groupedEngagements
}

export default createSelector(
    getAllTeamEngagements,
    getTimeFrames,
    getEngagementOptions,
    (engagements, timeFrames, engagementOptions) =>
        groupAndSort(engagements, timeFrames, engagementOptions)
)
