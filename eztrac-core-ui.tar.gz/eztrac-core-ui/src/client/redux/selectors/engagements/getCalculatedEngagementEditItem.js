import {createSelector} from 'reselect'
import find from 'lodash/find'
import {getIsCalculating} from '.'
import getGroupedAndSortedEngagements from './getGroupedAndSortedEngagements'

export default createSelector(
    getGroupedAndSortedEngagements,
    getIsCalculating,
    (groupedAndSorted, isCalculating) =>
        find(
            groupedAndSorted[isCalculating.engagementId],
            (timeframe) => timeframe.timeFrameId === isCalculating.timeFrameId
        )
)
