import {createSelector} from 'reselect'
import {getSelectedEngagement} from './index'
import getCurrentAndFutureYearTimeFrames from '../getCurrentAndFutureYearTimeFrames'
import getIsAdmin from '../getIsAdmin'

const mapToDropdownOptions = (timeFrames) =>
    timeFrames.map(({id, name, lockdown}) => ({
        value: id,
        label: lockdown ? `${name} (locked)` : name
    }))

export default createSelector(
    getSelectedEngagement,
    getCurrentAndFutureYearTimeFrames,
    getIsAdmin,
    (selectedEngagement, currentYearTimeFrames, isAdmin) => {
        if (selectedEngagement) {
            const startTimeFrameIndex = currentYearTimeFrames.findIndex(
                (tf) => tf.id === selectedEngagement[0].timeFrameId
            )
            const engagementStartsInPreviousYear = startTimeFrameIndex === -1

            let dropdownOptions = []

            if (isAdmin && engagementStartsInPreviousYear) {
                dropdownOptions = mapToDropdownOptions(currentYearTimeFrames)
            } else if (isAdmin) {
                const filteredTimeFrames = currentYearTimeFrames.slice(startTimeFrameIndex)
                dropdownOptions = mapToDropdownOptions(filteredTimeFrames)
            } else {
                const filteredTimeFrames = currentYearTimeFrames
                    .slice(startTimeFrameIndex)
                    .filter((timeFrame) => !timeFrame.lockdown)
                dropdownOptions = mapToDropdownOptions(filteredTimeFrames)
            }

            return dropdownOptions
        }

        return []
    }
)
