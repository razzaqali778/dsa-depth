import {createSelector} from 'reselect'
import isEmpty from 'lodash/isEmpty'
import isNull from 'lodash/isNull'
import isUndefined from 'lodash/isUndefined'
import {getEngagementFormValues} from '.'

const isInvalid = (value) => value === '' || isNull(value) || isUndefined(value)

export default createSelector(
    getEngagementFormValues,
    (formValues) =>
        isInvalid(formValues.amount) ||
        (isInvalid(formValues.timeFrameId) && isInvalid(formValues.editCostTimeFrameId)) ||
        isEmpty(formValues.selectedEngagement) ||
        formValues.timeFrameId === 0
)
