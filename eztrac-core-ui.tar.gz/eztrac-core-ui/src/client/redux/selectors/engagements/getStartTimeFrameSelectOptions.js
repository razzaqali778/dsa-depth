import {createSelector} from 'reselect'
import getCurrentAndFutureYearTimeFrames from '../getCurrentAndFutureYearTimeFrames'
import getIsAdmin from '../getIsAdmin'

export default createSelector(
    getCurrentAndFutureYearTimeFrames,
    getIsAdmin,
    (currentYearTimeFrames, isAdmin) => {
        const filteredTimeFrames = isAdmin
            ? currentYearTimeFrames
            : currentYearTimeFrames.filter((timeFrame) => !timeFrame.lockdown)

        return filteredTimeFrames.map(({id, name, lockdown}) => ({
            value: id,
            label: lockdown ? `LOCKED\n${name}` : name,
            isLocked: lockdown
        }))
    }
)
