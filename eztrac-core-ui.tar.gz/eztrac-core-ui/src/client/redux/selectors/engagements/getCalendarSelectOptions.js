import {createSelector} from 'reselect'
import map from 'lodash/map'
import uniqBy from 'lodash/uniqBy'
import {getCalendarHours} from '.'

export default createSelector(getCalendarHours, (calendars) => {
    const calendarList = map(calendars, ({calendarId, name}) => ({value: calendarId, label: name}))
    const uniqList = uniqBy(calendarList, 'value')

    return uniqList
})
