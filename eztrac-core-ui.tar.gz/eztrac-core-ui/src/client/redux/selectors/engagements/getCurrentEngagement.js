import {createSelector} from 'reselect'
import find from 'lodash/find'
import {getSelectedEngagement} from './index'
import getCurrentMonthTimeFrame from '../getCurrentMonthTimeFrame'

export default createSelector(
    getCurrentMonthTimeFrame,
    getSelectedEngagement,
    (currentMonthTimeFrame, selectedEngagement) => {
        const currentMonth = find(
            selectedEngagement,
            (e) => e.timeFrameId === currentMonthTimeFrame.id
        )

        if (currentMonth) {
            return currentMonth
        } else if (selectedEngagement) {
            return selectedEngagement[0]
        }

        return selectedEngagement
    }
)
