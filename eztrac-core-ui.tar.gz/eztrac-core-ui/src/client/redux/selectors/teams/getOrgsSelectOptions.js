import {createSelector} from 'reselect'
import {getOrgs} from '..'

export default createSelector(getOrgs, (orgs = []) =>
    orgs
        .filter((o) => o.isActive)
        .map(({id, name}) => ({
            label: name,
            value: id
        }))
)
