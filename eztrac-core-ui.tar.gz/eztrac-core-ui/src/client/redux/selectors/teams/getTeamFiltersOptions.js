import {createSelector} from 'reselect'
import {getCommunities, getOrgs, getPlatforms, getSelectedOrgId, getSelectedPlatformId} from '..'

export default createSelector(
    getCommunities,
    getPlatforms,
    getOrgs,
    getSelectedOrgId,
    getSelectedPlatformId,
    (communities = [], platforms = [], orgs = [], selectedOrgId, selectedPlatformId) => {
        const mapToOptions = (arr) =>
            arr.filter(({isActive}) => isActive).map(({id, name}) => ({label: name, value: id}))

        const filteredPlatforms = selectedOrgId
            ? platforms.filter((p) => p.orgId === selectedOrgId)
            : platforms

        const filteredCommunities = selectedPlatformId
            ? communities.filter((c) => c.platformId === selectedPlatformId)
            : communities.filter((c) => filteredPlatforms.some((p) => p.id === c.platformId))

        return {
            orgs: mapToOptions(orgs),
            platforms: mapToOptions(filteredPlatforms),
            communities: mapToOptions(filteredCommunities)
        }
    }
)
