import {createSelector} from 'reselect'
import {getPlatforms} from '..'

export default createSelector(getPlatforms, (platforms = []) =>
    platforms
        .filter((p) => p.isActive)
        .map(({id, name}) => ({
            label: name,
            value: id
        }))
)
