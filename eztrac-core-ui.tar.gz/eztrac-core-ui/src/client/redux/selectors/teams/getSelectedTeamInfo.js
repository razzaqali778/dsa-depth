import {createSelector} from 'reselect'
import find from 'lodash/find'
import {
    getCommunities,
    getIsCreatingTeam,
    getPlatforms,
    getSelectedTeam,
    getTeams,
    getOrgs
} from '..'

export default createSelector(
    getSelectedTeam,
    getTeams,
    getCommunities,
    getPlatforms,
    getOrgs,
    getIsCreatingTeam,
    (selectedTeam, teams, communities, platforms, orgs, isCreatingTeam) => {
        if (isCreatingTeam) {
            return {
                id: '',
                name: selectedTeam.name
            }
        }

        const team = find(teams, ({id}) => id === selectedTeam.id) || {}
        const community = find(communities, ({id}) => id === team.communityId) || {}
        const platform = find(platforms, ({id}) => id === community.platformId) || {}
        const org = find(orgs, ({id}) => id === platform.orgId) || {}

        const info = {
            id: team.id,
            name: team.name,
            isActive: team.isActive,
            communityId: community.id,
            communityName: community.name,
            platformId: platform.id,
            platformName: platform.name,
            orgId: org.id,
            orgName: org.name
        }

        return info
    }
)
