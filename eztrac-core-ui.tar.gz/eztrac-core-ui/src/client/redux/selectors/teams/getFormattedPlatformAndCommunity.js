import {createSelector} from 'reselect'
import concat from 'lodash/concat'
import find from 'lodash/find'
import map from 'lodash/map'
import sortBy from 'lodash/sortBy'
import {getCommunities, getPlatforms} from '..'

export default createSelector(getPlatforms, getCommunities, (platforms, communities) => {
    const formatedPlatform = map(platforms, (platform) => ({
        value: platform.id,
        label: `${platform.name} Platform`,
        type: 'Platform'
    }))

    const formatedCommunities = map(
        communities.filter((c) => c.isActive),
        (community) => {
            const currentPlatform = find(platforms, ['id', community.platformId])

            return {
                value: community.id,
                label: `${currentPlatform ? currentPlatform.name : '?'} - ${community.name}`,
                type: 'Community'
            }
        }
    )
    const x = concat(formatedPlatform, formatedCommunities)

    return sortBy(x, ['label'])
})
