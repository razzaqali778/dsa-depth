import {createSelector} from 'reselect'
import map from 'lodash/map'
import {getTeams} from '..'

export default createSelector(getTeams, (teams) =>
    map(teams, ({id, name, isActive, communityId}) => ({
        value: id,
        label: name,
        active: isActive,
        communityId
    }))
)
