import {createSelector} from 'reselect'
import filter from 'lodash/filter'
import includes from 'lodash/includes'
import map from 'lodash/map'
import getTeamSelectOptions from './getTeamSelectOptions'
import {getFavoriteTeams} from '..'
import mapToTeamSelectOptions from '../../utils/mapToTeamSelectOptions'

export default createSelector(getTeamSelectOptions, getFavoriteTeams, (teams, favoriteTeams) => {
    if (teams.length > 0) {
        const favoriteTeamSelectOptions = mapToTeamSelectOptions(teams, favoriteTeams)
        const favoriteTeamSelectIds = map(favoriteTeamSelectOptions, 'value')

        const remainingTeams = filter(teams, (team) => !includes(favoriteTeamSelectIds, team.value))

        const activeTeam = filter(remainingTeams, (team) => team.active)

        const inActiveTeams = filter(remainingTeams, (team) => !team.active)

        const teamDropDown = [
            {
                label: 'Favorites',
                options: favoriteTeamSelectOptions
            },
            {
                label: 'Active',
                options: activeTeam
            },
            {
                label: 'Inactive',
                options: inActiveTeams
            }
        ]

        return teamDropDown
    }

    return []
})
