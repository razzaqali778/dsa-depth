import {createSelector} from 'reselect'
import {getOrgs, getPlatforms} from '..'

export default createSelector(getPlatforms, getOrgs, (platforms = [], orgs = []) => {
    const platformsExtended = platforms.map((platform) => {
        const org = orgs.find(({id}) => id === platform.orgId)

        return {
            ...platform,
            orgId: org ? org.id : 'UNKNOWN-ORG',
            orgName: org ? org.name : 'Unknown Org'
        }
    })

    return platformsExtended
})
