import {createSelector} from 'reselect'
import {getCommunities, getPlatforms} from '..'

export default createSelector(getCommunities, getPlatforms, (communities = [], platforms = []) => {
    const communitiesWithPlatformInfo = communities.map((community) => {
        const platform = platforms.find(({id}) => id === community.platformId)

        return {
            ...community,
            platformId: platform ? platform.id : 'UNKNOWN-PLATFORM',
            platformName: platform ? platform.name : 'Unknown Platform'
        }
    })

    return communitiesWithPlatformInfo
})
