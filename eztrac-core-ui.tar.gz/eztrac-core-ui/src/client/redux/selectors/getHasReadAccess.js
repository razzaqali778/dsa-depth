import {createSelector} from 'reselect'
import includes from 'lodash/includes'
import map from 'lodash/map'
import {getCurrentUser} from '.'

const hasReadAccess = (user) => {
    if (user && user.entitlements) {
        const entitlementCodes = map(user.entitlements, (e) => e.code)

        return (
            includes(entitlementCodes, 'eztrac-read-user') ||
            includes(entitlementCodes, 'eztrac-write-user') ||
            includes(entitlementCodes, 'ez-trac-admin')
        )
    }

    return false
}

export default createSelector(getCurrentUser, (user) => hasReadAccess(user))
