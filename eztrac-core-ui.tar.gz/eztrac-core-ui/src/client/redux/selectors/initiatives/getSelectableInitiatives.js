import {createSelector} from 'reselect'
import filter from 'lodash/filter'
import {getAllInitiatives} from '.'
import {getSelectedTimeFrameId} from '..'
import getCurrentMonthTimeFrame from '../getCurrentMonthTimeFrame'

export default createSelector(
    getAllInitiatives,
    getCurrentMonthTimeFrame,
    getSelectedTimeFrameId,
    (initiatives, currentMonthTimeFrame, selectedTimeFrameId) => {
        const isCurrentMonth = currentMonthTimeFrame.id === selectedTimeFrameId
        const validTypeInitiatives = filter(
            initiatives,
            ({typeId}) => typeId && typeId !== 'UNKNOWN'
        )
        const validStatusInitiatives = filter(
            validTypeInitiatives,
            ({status}) => status === 'Funded' || (!isCurrentMonth && status === 'Planning')
        )

        return validStatusInitiatives
    }
)
