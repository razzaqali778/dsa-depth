import {createSelector} from 'reselect'
import {filter, findIndex, includes, map, slice, uniq} from 'lodash'
import {getSelectedTimeFrameId} from '..'
import getRelativeFutureTimeFrames from '../getRelativeFutureTimeFrames'

export default createSelector(
    getRelativeFutureTimeFrames,
    getSelectedTimeFrameId,
    (relativeFutureTimeFrames, selectedTimeFrameId) => {
        const startIndex = findIndex(
            relativeFutureTimeFrames,
            (startTimeFrame) => startTimeFrame.id === selectedTimeFrameId
        )
        const futureTimeFrames =
            startIndex === -1
                ? relativeFutureTimeFrames
                : slice(relativeFutureTimeFrames, startIndex)
        const years = uniq(map(futureTimeFrames, (timeFrame) => timeFrame.name.split(' ')[1]))

        return map(years, (year) => ({
            year,
            months: filter(
                map(futureTimeFrames, (timeFrame) =>
                    includes(timeFrame.name, year)
                        ? {
                              month: timeFrame.name.split(' ')[0],
                              id: timeFrame.id,
                              isActive: timeFrame.isActive,
                              startTime: timeFrame.startDate
                          }
                        : undefined
                ),
                undefined
            )
        }))
    }
)
