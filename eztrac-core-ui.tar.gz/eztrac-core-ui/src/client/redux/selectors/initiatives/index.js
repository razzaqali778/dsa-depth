export const getAllInitiatives = (state) => state.initiative.allInitiatives
export const getTeamInitiatives = (state) => state.initiative.teamInitiatives
export const getInitiativeWarnings = (state) => state.initiative.initiativeWarnings
export const getInitiativeErrors = (state) => state.initiative.initiativeErrors
export const getSelectedTimeFrameTeamInitiatives = (state) =>
    state.initiative.selectedTimeFrameTeamInitiatives
export const getNewInitiativeData = (state) => state.initiative.newInitiativeData
export const getIsInitiativeCopyForwardContainerOpen = (state) =>
    state.initiative.isInitiativeCopyForwardContainerOpen
export const getIsInitiativeModifyFinderOpen = (state) =>
    state.initiative.isInitiativeModifyFinderOpen
export const getInitiativesTableSort = (state) => state.initiative.initiativesTableSort
export const getCopyForwardTimeFrame = (state) => state.initiative.copyForwardTimeFrame
