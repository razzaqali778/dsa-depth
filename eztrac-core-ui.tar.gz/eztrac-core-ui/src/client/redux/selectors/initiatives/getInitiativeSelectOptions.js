import {createSelector} from 'reselect'
import map from 'lodash/map'
import sortBy from 'lodash/sortBy'
import {getNewInitiativeData} from '.'
import getSelectableInitiatives from './getSelectableInitiatives'

export default createSelector(
    getSelectableInitiatives,
    getNewInitiativeData,
    (initiatives, newInitiativeData) => {
        if (initiatives.length > 0) {
            const unsortedSelectOptions = map(initiatives, (initiative) => {
                const initiativeName = initiative.parentId
                    ? `${initiative.initiativeName} [${initiative.parentName}]`
                    : initiative.initiativeName

                const PORTFOLIO_CODE = 'Portfolio Code'
                const portfolioCode = initiative.portfolioCode
                    ? `${initiative.portfolioCode}`
                    : 'N/A'

                const sortableLabel = initiativeName

                const value = {
                    ...initiative,
                    initiativeCost: 0,
                    teamCostPct: newInitiativeData.value.teamCostPct
                }

                return {
                    label: `${PORTFOLIO_CODE}: ${portfolioCode}\n${initiativeName}`,
                    sortableLabel,
                    value
                }
            })

            const sortedSelectOptions = sortBy(unsortedSelectOptions, 'sortableLabel')

            return map(sortedSelectOptions, (option) => ({
                label: option.label,
                value: option.value
            }))
        }

        return []
    }
)
