import {createSelector} from 'reselect'
import map from 'lodash/map'
import {getTimeFrames} from '..'
import getCurrentMonthTimeFrame from '../getCurrentMonthTimeFrame'
import getTimeFrameRange from '../../utils/getTimeFrameRange'

export default createSelector(
    getTimeFrames,
    getCurrentMonthTimeFrame,
    (timeFrames, currentMonthTimeFrame) => {
        const timeFrameRange = getTimeFrameRange(timeFrames, currentMonthTimeFrame)

        return map(timeFrameRange, ({id, name}) => ({value: id, label: name}))
    }
)
