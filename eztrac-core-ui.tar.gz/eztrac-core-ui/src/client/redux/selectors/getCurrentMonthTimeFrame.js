import {createSelector} from 'reselect'
import find from 'lodash/find'
import {getTimeFrames} from '.'

export default createSelector(getTimeFrames, (timeFrames) => {
    const todaysMonth = new Date()
    todaysMonth.setUTCHours(0, 0, 0, 0)
    todaysMonth.setUTCDate(1)

    return find(timeFrames, (timeframe) => timeframe.startDate === Date.parse(todaysMonth))
})
