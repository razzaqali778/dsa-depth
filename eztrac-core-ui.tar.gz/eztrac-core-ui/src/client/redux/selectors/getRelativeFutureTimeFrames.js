import {createSelector} from 'reselect'
import filter from 'lodash/filter'
import {getTimeFrames} from '.'
import getSelectedTimeFrame from './getSelectedTimeFrame'

export default createSelector(
    getTimeFrames,
    getSelectedTimeFrame,
    (timeFrames, selectedTimeFrame) =>
        filter(timeFrames, (timeFrame) => timeFrame.startDate > selectedTimeFrame.endDate)
)
