import {createSelector} from 'reselect'
import filter from 'lodash/filter'
import includes from 'lodash/includes'
import map from 'lodash/map'
import {getFavoriteTeams, getSelectedCommunityId} from '..'
import getTeamSelectOptions from '../teams/getTeamSelectOptions'
import mapToTeamSelectOptions from '../../utils/mapToTeamSelectOptions'
import getTeamFiltersOptions from '../teams/getTeamFiltersOptions'

export default createSelector(
    getTeamSelectOptions,
    getFavoriteTeams,
    getSelectedCommunityId,
    getTeamFiltersOptions,
    (teams, favoriteTeams, selectedCommunityId, teamFilters) => {
        const filteredTeams = selectedCommunityId
            ? teams.filter((t) => t.communityId === selectedCommunityId)
            : teams.filter((t) => teamFilters.communities.some((c) => c.value === t.communityId))

        if (filteredTeams.length > 0) {
            const favoriteTeamSelectOptions = mapToTeamSelectOptions(filteredTeams, favoriteTeams)

            const favoriteTeamSelectIds = map(favoriteTeamSelectOptions, 'value')

            const remainingTeams = filter(
                filteredTeams,
                (team) => !includes(favoriteTeamSelectIds, team.value) && team.active
            )
            const teamDropDown = [
                {
                    label: 'Favorites',
                    options: favoriteTeamSelectOptions
                },
                {
                    label: 'Teams',
                    options: remainingTeams
                }
            ]

            return teamDropDown
        }

        return []
    }
)
