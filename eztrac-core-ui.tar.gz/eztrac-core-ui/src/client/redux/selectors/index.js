export const getCommunities = (state) => state.team.communities
export const getCurrentUser = (state) => state.users.currentUser
export const getFavoriteTeams = (state) => state.preference.preferences
export const getFormValues = (state) => state.team.formValues
export const getIsCreatingTeam = (state) => state.team.isCreatingTeam
export const getIsLoading = (state) => state.isLoading
export const getPlatforms = (state) => state.team.platforms
export const getOrgs = (state) => state.team.orgs
export const getSelectedTeam = (state) => state.team.selectedTeam
export const getSelectedCommunityId = (state) => state.team.selectedCommunityId
export const getSelectedPlatformId = (state) => state.team.selectedPlatformId
export const getSelectedOrgId = (state) => state.team.selectedOrgId
export const getSelectedTeamTab = (state) => state.preference.selectedTeamTab
export const getSelectedTimeFrameId = (state) => state.timeFrame.selectedTimeFrameId
export const getSelectedTimeFrameTeamCost = (state) =>
    state.team.selectedTeam.selectedTimeFrameTeamCost
export const getTeamCostData = (state) => state.team.selectedTeam.teamCostData
export const getTeams = (state) => state.team.teams
export const getTimeFrames = (state) => state.timeFrame.timeFrames
export const getSaveLockedTimeFrameData = (state) => state.timeFrame.saveLockedTimeFrameData
export const getStartTimeFrame = (state) => state.timeFrame.startTimeFrame
export const getEndTimeFrame = (state) => state.timeFrame.endTimeFrame
export const getCalendarModalBool = (state) => state.timeFrame.calendarModalBool
export const getStartEndSelector = (state) => state.timeFrame.startEndSelector
export const getCopyCalendarModalBool = (state) => state.timeFrame.copyCalendarModalBool
export const getSortOrderPreferenceLocal = (state) => state.preference.sortOrderPreferences
export const getSortOrderPreferencePeopleLocal = (state) =>
    state.preference.sortOrderPreferencesPeople
export const getUnsavedDataModalBool = (state) => state.team.unsavedDataModalBool

export const getUnsavedChangesBool = (state) => state.team.unsavedChangesBool
export const getCsvDownload = (state) => state.get.csvDownload
export const getSelectedCommunityPlatform = (state) => state.get.selectedCommunityPlatform
export const getSelectedTeams = (state) => state.get.selectedTeams
export const getSelectedRegion = (state) => state.get.selectedRegion
export const getDownloadAll = (state) => state.get.downloadAll
