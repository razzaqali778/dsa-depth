import {createSelector} from 'reselect'
import findIndex from 'lodash/findIndex'
import map from 'lodash/map'
import slice from 'lodash/slice'
import getTimeFrameRange from '../utils/getTimeFrameRange'
import {getEndTimeFrame, getStartTimeFrame, getTimeFrames} from '.'

export default createSelector(
    getTimeFrames,
    getStartTimeFrame,
    getEndTimeFrame,
    (allTimeFrames, startTimeFrame, endTimeFrame) => {
        const timeFrameDisplayArray = getTimeFrameRange(allTimeFrames)

        const timeFrames = slice(
            timeFrameDisplayArray,
            findIndex(timeFrameDisplayArray, (timeFrame) => timeFrame.id === startTimeFrame.id),
            findIndex(timeFrameDisplayArray, (timeFrame) => timeFrame.id === endTimeFrame.id) + 1
        )

        return map(timeFrames, (timeFrame) => ({label: timeFrame.name, value: timeFrame.id}))
    }
)
