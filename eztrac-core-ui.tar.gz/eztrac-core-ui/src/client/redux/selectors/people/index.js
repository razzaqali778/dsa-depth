export const getAllPeople = (state) => state.people.people
export const getIsPeopleModifyFinderOpen = (state) => state.people.isPeopleModifyFinderOpen
export const getSelectedTimeFrameTeamPeople = (state) => state.people.selectedTimeFrameTeamPeople
export const getNewPersonData = (state) => state.people.newPersonData
export const getTeamPeople = (state) => state.people.teamPeople
export const getSelectedTimeFrameForecastedPeople = (state) =>
    state.people.selectedTimeFrameForecastedPeople
export const getTeamForecastedPeople = (state) => state.people.teamForecastedPeople
export const getAllRates = (state) => state.people.rates
export const getAllCostGroups = (state) => state.people.costGroups
export const getNewForecastedPersonData = (state) => state.people.newForecastedPersonData
export const getAllActivePeople = (state) => state.people.activePeople
export const getPersonProfileDetails = (state) => state.people.currentUserProfileDetails
