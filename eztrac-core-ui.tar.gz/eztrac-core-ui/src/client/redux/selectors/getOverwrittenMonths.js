import {createSelector} from 'reselect'
import find from 'lodash/find'
import forEach from 'lodash/forEach'
import map from 'lodash/map'
import {getCopyForwardTimeFrame, getTeamInitiatives} from './initiatives'

export default createSelector(
    getTeamInitiatives,
    getCopyForwardTimeFrame,
    (teamInitiatives, copyForwardTimeFrame) => {
        const overwrittenMonths = []
        const initiativeTimeFrames = map(
            teamInitiatives,
            (currentInitiative) => currentInitiative.timeFrameId
        )
        forEach(copyForwardTimeFrame, (month) => {
            if (find(initiativeTimeFrames, (currentTimeFrame) => currentTimeFrame === month.id)) {
                overwrittenMonths.push(month.name)
            }
        })

        return overwrittenMonths
    }
)
