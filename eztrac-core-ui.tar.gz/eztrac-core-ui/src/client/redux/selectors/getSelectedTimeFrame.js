import {createSelector} from 'reselect'
import find from 'lodash/find'
import {getSelectedTimeFrameId, getTimeFrames} from '.'

export default createSelector(
    getTimeFrames,
    getSelectedTimeFrameId,
    (timeFrames, selectedTimeFrameId) => {
        if (!selectedTimeFrameId || !timeFrames || !timeFrames.length) {
            return undefined
        }
        // API timeframe ids are strings; some call sites/history can pass numbers.
        return find(
            timeFrames,
            (timeFrame) => String(timeFrame.id) === String(selectedTimeFrameId)
        )
    }
)
