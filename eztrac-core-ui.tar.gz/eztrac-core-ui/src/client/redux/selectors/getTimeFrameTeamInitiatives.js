import {createSelector} from 'reselect'
import filter from 'lodash/filter'
import {getEndTimeFrame, getStartTimeFrame} from '.'
import {getTeamInitiatives} from './initiatives'

export default createSelector(
    getStartTimeFrame,
    getEndTimeFrame,
    getTeamInitiatives,
    (startTimeFrame, endTimeFrame, teamInitiatives) =>
        filter(
            teamInitiatives,
            (teamInitiative) =>
                teamInitiative.timeFrameId <= endTimeFrame.id &&
                teamInitiative.timeFrameId >= startTimeFrame.id
        )
)
