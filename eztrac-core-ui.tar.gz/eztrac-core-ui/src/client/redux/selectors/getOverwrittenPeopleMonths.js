import {createSelector} from 'reselect'
import {groupBy, isUndefined, reduce} from 'lodash'
import {getCopyForwardTimeFrame} from './initiatives'
import {getTeamPeople} from './people'

export default createSelector(
    getTeamPeople,
    getCopyForwardTimeFrame,
    (teamPeople, copyForwardTimeFrames) => {
        const groupedTimeFrames = groupBy(teamPeople, 'timeFrameId')
        const overwrittenTimeFrames = reduce(
            copyForwardTimeFrames,
            (acc, {id, name}) => {
                if (!isUndefined(groupedTimeFrames[id])) acc.push(name)

                return acc
            },
            []
        )

        return overwrittenTimeFrames
    }
)
