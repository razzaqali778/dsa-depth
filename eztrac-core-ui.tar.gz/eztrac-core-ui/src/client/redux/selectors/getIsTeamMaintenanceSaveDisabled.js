import {createSelector} from 'reselect'
import isNull from 'lodash/isNull'
import {getFormValues} from '.'

const isInvalid = (value) => value === '' || isNull(value)

export default createSelector(
    getFormValues,
    (formValues) => isInvalid(formValues.communityId) || isInvalid(formValues.teamName)
)
