import {createSelector} from 'reselect'
import _ from 'lodash'
import {getTimeFrames} from '.'

export default createSelector(getTimeFrames, (timeFrames) => {
    const currentYear = new Date().getUTCFullYear()

    return _(timeFrames)
        .filter((timeFrame) => new Date(timeFrame.startDate).getUTCFullYear() >= currentYear)
        .sortBy((timeFrame) => timeFrame.startDate)
        .value()
})
