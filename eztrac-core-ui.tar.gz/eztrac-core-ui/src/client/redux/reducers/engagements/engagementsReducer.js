import {combineReducers} from 'redux'
import {
    CLOSE_EDIT_ENGAGEMENT_DIALOG,
    CLOSE_REMOVE_ENGAGEMENT_DIALOG,
    OPEN_EDIT_ENGAGEMENT_DIALOG,
    OPEN_REMOVE_ENGAGEMENT_DIALOG,
    SET_ALL_TEAM_ENGAGEMENTS,
    SET_ENGAGEMENT_FILTER_PHRASE,
    SET_ENGAGEMENT_OPTIONS,
    SET_GROUPED_AND_SORTED_ENGAGEMENTS,
    SET_IS_EDITING_ENGAGEMENT,
    SET_SELECTED_ENGAGEMENT,
    SET_TOTAL_ENGAGEMENT_COST,
    TOGGLE_HISTORIC_ENGAGEMENTS,
    TOGGLE_IS_CREATING_ENGAGEMENT
} from '../../constants/engagementConstants'
import scratchPad from './scratchPadReducer'

export const allTeamEngagements = (state = [], action = {}) => {
    switch (action.type) {
        case SET_ALL_TEAM_ENGAGEMENTS:
            return action.payload
        default:
            return state
    }
}

export const engagementOptions = (state = [], action = {}) => {
    switch (action.type) {
        case SET_ENGAGEMENT_OPTIONS:
            return action.payload
        default:
            return state
    }
}

export const selectedEngagement = (state = '', action = {}) => {
    switch (action.type) {
        case SET_SELECTED_ENGAGEMENT:
            return action.payload
        default:
            return state
    }
}

const editDialogOpened = (state = false, action = {}) => {
    switch (action.type) {
        case OPEN_EDIT_ENGAGEMENT_DIALOG:
            return true
        case CLOSE_EDIT_ENGAGEMENT_DIALOG:
            return false
        default:
            return state
    }
}

const removeDialogOpened = (state = false, action = {}) => {
    switch (action.type) {
        case OPEN_REMOVE_ENGAGEMENT_DIALOG:
            return true
        case CLOSE_REMOVE_ENGAGEMENT_DIALOG:
            return false
        default:
            return state
    }
}

export const totalEngagementCost = (state = null, action = {}) => {
    switch (action.type) {
        case SET_TOTAL_ENGAGEMENT_COST:
            return action.payload
        default:
            return state
    }
}

export const isEditing = (state = '', action = {}) => {
    switch (action.type) {
        case SET_IS_EDITING_ENGAGEMENT:
            return action.payload
        default:
            return state
    }
}

export const isCreatingEngagement = (state = false, action = {}) => {
    switch (action.type) {
        case TOGGLE_IS_CREATING_ENGAGEMENT:
            return action.payload
        default:
            return state
    }
}

export const toggleHistoricEngagements = (state = false, action = {}) => {
    switch (action.type) {
        case TOGGLE_HISTORIC_ENGAGEMENTS:
            return action.payload
        default:
            return state
    }
}

export const engagementFilterPhrase = (state = '', action = {}) => {
    switch (action.type) {
        case SET_ENGAGEMENT_FILTER_PHRASE:
            return action.payload
        default:
            return state
    }
}

export const groupedAndSortedEngagements = (state = {}, action = {}) => {
    switch (action.type) {
        case SET_GROUPED_AND_SORTED_ENGAGEMENTS:
            return action.payload
        default:
            return state
    }
}

export default combineReducers({
    allTeamEngagements,
    engagementOptions,
    selectedEngagement,
    editDialogOpened,
    totalEngagementCost,
    isEditing,
    isCreatingEngagement,
    scratchPad,
    groupedAndSortedEngagements,
    removeDialogOpened,
    toggleHistoricEngagements,
    engagementFilterPhrase
})
