import {combineReducers} from 'redux'
import map from 'lodash/map'
import without from 'lodash/without'
import {
    ADD_CALCULATOR_ROW,
    CLEAR_CALCULATOR_ROWS,
    REMOVE_CALCULATOR_ROW,
    SET_CALENDARS,
    SET_IS_CALCULATING,
    SET_SELECTED_CALENDAR,
    TOGGLE_IS_CALCULATING,
    UPDATE_CALCULATOR_ROW
} from '../../constants/engagementConstants'

export const calculatorRows = (state = [], action = {}) => {
    switch (action.type) {
        case ADD_CALCULATOR_ROW:
            return [...state, action.payload]
        case UPDATE_CALCULATOR_ROW: {
            const updatedCalculatorRows = map(state, (row) =>
                row.timeStamp === action.payload.timeStamp ? action.payload : row
            )

            return updatedCalculatorRows
        }
        case REMOVE_CALCULATOR_ROW:
            return without(state, action.payload)
        case CLEAR_CALCULATOR_ROWS:
            return []

        default:
            return state
    }
}

export const calendarHours = (state = [], action = {}) => {
    switch (action.type) {
        case SET_CALENDARS:
            return action.payload
        default:
            return state
    }
}

export const selectedRateCalendar = (state = 'US-VARIABLE', action = {}) => {
    switch (action.type) {
        case SET_SELECTED_CALENDAR:
            return action.payload
        default:
            return state
    }
}

export const isCalculating = (state = false, action = {}) => {
    switch (action.type) {
        case TOGGLE_IS_CALCULATING:
            return action.payload
        case SET_IS_CALCULATING:
            return action.payload
        default:
            return state
    }
}

export default combineReducers({
    calculatorRows,
    calendarHours,
    isCalculating,
    selectedRateCalendar
})
