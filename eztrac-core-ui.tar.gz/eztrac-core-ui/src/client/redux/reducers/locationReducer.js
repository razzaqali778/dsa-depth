import {combineReducers} from 'redux'
import omit from 'lodash/omit'
import {
    REMOVE_LOCATION_QUERY,
    SET_LOCATION,
    UPDATE_LOCATION_QUERY
} from '../constants/locationConstants'

const pathname = (state = '', action = '') => {
    switch (action.type) {
        case SET_LOCATION:
            return action.payload.pathname
        default:
            return state
    }
}
const query = (state = {}, action = '') => {
    switch (action.type) {
        case SET_LOCATION:
            return action.payload.query
        case UPDATE_LOCATION_QUERY:
            return {...state, ...action.payload}
        case REMOVE_LOCATION_QUERY:
            return omit(state, action.payload)
        default:
            return state
    }
}
export default combineReducers({
    pathname,
    query
})
