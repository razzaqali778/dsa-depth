import {combineReducers} from 'redux'
import isUndefined from 'lodash/isUndefined'
import sortBy from 'lodash/sortBy'
import {
    SET_COMMUNITIES,
    SET_FORM_COMMUNITY_ID,
    SET_FORM_IS_ACTIVE,
    SET_FORM_TEAM_NAME,
    SET_IS_EDITING,
    SET_PLATFORMS,
    SET_ORGS,
    SET_SELECTED_COMMUNITY_ID,
    SET_SELECTED_PLATFORM_ID,
    SET_SELECTED_ORG_ID,
    SET_SELECTED_TEAM,
    SET_SELECTED_TEAM_FROM_URL,
    SET_SELECTED_TEAM_TAB_FROM_URL,
    SET_SELECTED_TIME_FRAME_TEAM_COST,
    SET_TEAMS,
    SET_TEAM_COST_DATA,
    SET_UNSAVED_CHANGES_BOOL,
    SET_UNSAVED_DATA_MODAL_BOOL,
    TOGGLE_IS_CREATING_TEAM
} from '../constants/teamConstants'

export const teams = (state = [], action = {}) => {
    switch (action.type) {
        case SET_TEAMS:
            return sortBy(action.payload, ({name}) => name)
        default:
            return state
    }
}

export const selectedTeamTab = (state = '', action = {}) => {
    switch (action.type) {
        case SET_SELECTED_TEAM_TAB_FROM_URL:
            return action.payload
        default:
            return state
    }
}

export const selectedCommunityId = (state = '', action = {}) => {
    switch (action.type) {
        case SET_SELECTED_COMMUNITY_ID: {
            return isUndefined(action.payload) ? '' : action.payload
        }
        default:
            return state
    }
}

export const selectedPlatformId = (state = '', action = {}) => {
    switch (action.type) {
        case SET_SELECTED_PLATFORM_ID: {
            return isUndefined(action.payload) ? '' : action.payload
        }
        default:
            return state
    }
}

export const selectedOrgId = (state = '', action = {}) => {
    switch (action.type) {
        case SET_SELECTED_ORG_ID: {
            return isUndefined(action.payload) ? '' : action.payload
        }
        default:
            return state
    }
}

export const selectedTeam = (state = {}, action = {}) => {
    switch (action.type) {
        case SET_SELECTED_TEAM:
            return isUndefined(action.payload)
                ? {...state, id: '', name: ''}
                : {...state, ...action.payload}
        case SET_IS_EDITING:
            return {
                ...state,
                isEditing: action.payload
            }
        case SET_SELECTED_TEAM_FROM_URL:
            return isUndefined(action.payload)
                ? {...state, id: '', name: ''}
                : {...state, ...action.payload}
        case SET_TEAM_COST_DATA:
            return {
                ...state,
                teamCostData: action.payload
            }
        case SET_SELECTED_TIME_FRAME_TEAM_COST:
            return {
                ...state,
                selectedTimeFrameTeamCost: isUndefined(action.payload) ? 0 : action.payload.teamCost
            }
        default:
            return state
    }
}

export const unsavedDataModalBool = (state = false, action = {}) => {
    switch (action.type) {
        case SET_UNSAVED_DATA_MODAL_BOOL:
            return action.payload
        default:
            return state
    }
}

export const communities = (state = [], action = {}) => {
    switch (action.type) {
        case SET_COMMUNITIES:
            return action.payload
        default:
            return state
    }
}
export const platforms = (state = [], action = {}) => {
    switch (action.type) {
        case SET_PLATFORMS:
            return action.payload
        default:
            return state
    }
}

export const orgs = (state = [], action = {}) => {
    switch (action.type) {
        case SET_ORGS:
            return action.payload
        default:
            return state
    }
}

const initialFormState = {
    communityId: '',
    isActive: false,
    teamName: ''
}

export const formValues = (state = initialFormState, action = {}) => {
    switch (action.type) {
        case SET_FORM_COMMUNITY_ID:
            return {...state, communityId: action.payload}
        case SET_FORM_IS_ACTIVE:
            return {...state, isActive: action.payload}
        case SET_FORM_TEAM_NAME:
            return {...state, teamName: action.payload}
        default:
            return state
    }
}

export const isCreatingTeam = (state = false, action = {}) => {
    switch (action.type) {
        case TOGGLE_IS_CREATING_TEAM:
            return action.payload
        default:
            return state
    }
}

export const unsavedChanges = (state = false, action = {}) => {
    switch (action.type) {
        case SET_UNSAVED_CHANGES_BOOL:
            return action.payload
        default:
            return state
    }
}

export default combineReducers({
    teams,
    selectedTeam,
    selectedPlatformId,
    selectedCommunityId,
    selectedOrgId,
    selectedTeamTab,
    communities,
    formValues,
    platforms,
    orgs,
    isCreatingTeam,
    unsavedDataModalBool,
    unsavedChanges
})
