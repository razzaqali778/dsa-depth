import {combineReducers} from 'redux'
import sortBy from 'lodash/sortBy'
import {
    CLEAR_COPY_FORWARD_TIME_FRAME,
    CLEAR_INITIATIVE_ERRORS,
    CLEAR_INITIATIVE_WARNINGS,
    CLEAR_NEW_INITIATIVE_DATA,
    SET_COPY_FORWARD_TIME_FRAME,
    SET_INITIATIVES,
    SET_INITIATIVES_TABLE_SORT,
    SET_INITIATIVE_ERRORS,
    SET_INITIATIVE_WARNINGS,
    SET_IS_INITIATIVE_COPY_FORWARD_CONTAINER_OPEN,
    SET_IS_INITIATIVE_MODIFY_FINDER_OPEN,
    SET_NEW_INITIATIVE_DATA,
    SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES,
    SET_TEAM_INITIATIVES
} from '../constants/initiativeConstants'

export const allInitiatives = (state = [], action = {}) => {
    switch (action.type) {
        case SET_INITIATIVES:
            return sortBy(action.payload, ({initiativeName}) => initiativeName)
        default:
            return state
    }
}

export const teamInitiatives = (state = [], action = {}) => {
    switch (action.type) {
        case SET_TEAM_INITIATIVES:
            return sortBy(action.payload, ({timeFrameId}) => timeFrameId)
        default:
            return state
    }
}

export const selectedTimeFrameTeamInitiatives = (state = [], action = {}) => {
    switch (action.type) {
        case SET_SELECTED_TIME_FRAME_TEAM_INITIATIVES:
            return action.payload
        default:
            return state
    }
}

export const initiativeWarnings = (state = [], action = {}) => {
    switch (action.type) {
        case SET_INITIATIVE_WARNINGS:
            return [...state, action.payload]
        case CLEAR_INITIATIVE_WARNINGS:
            return []
        default:
            return state
    }
}

export const initiativeErrors = (state = [], action = {}) => {
    switch (action.type) {
        case SET_INITIATIVE_ERRORS:
            return [...state, action.payload]
        case CLEAR_INITIATIVE_ERRORS:
            return []
        default:
            return state
    }
}

export const newInitiativeData = (
    state = {value: {teamCostPct: 0, initiativeCost: 0}},
    action = {}
) => {
    switch (action.type) {
        case SET_NEW_INITIATIVE_DATA:
            return action.payload
        case CLEAR_NEW_INITIATIVE_DATA:
            return {value: {teamCostPct: 0, initiativeCost: 0}}
        default:
            return state
    }
}

export const isInitiativeCopyForwardContainerOpen = (state = false, action = {}) => {
    switch (action.type) {
        case SET_IS_INITIATIVE_COPY_FORWARD_CONTAINER_OPEN:
            return action.payload
        default:
            return state
    }
}

export const isInitiativeModifyFinderOpen = (state = false, action = {}) => {
    switch (action.type) {
        case SET_IS_INITIATIVE_MODIFY_FINDER_OPEN:
            return action.payload
        default:
            return state
    }
}

export const initiativesTableSort = (
    state = {nameNum: 1, allocationNum: 0, costNum: 0},
    action = {}
) => {
    switch (action.type) {
        case SET_INITIATIVES_TABLE_SORT:
            return action.payload
        default:
            return state
    }
}

export const copyForwardTimeFrame = (state = [], action = {}) => {
    switch (action.type) {
        case SET_COPY_FORWARD_TIME_FRAME:
            return [...state, action.payload]
        case CLEAR_COPY_FORWARD_TIME_FRAME:
            return []
        default:
            return state
    }
}

export default combineReducers({
    allInitiatives,
    teamInitiatives,
    initiativeWarnings,
    initiativeErrors,
    selectedTimeFrameTeamInitiatives,
    newInitiativeData,
    isInitiativeCopyForwardContainerOpen,
    isInitiativeModifyFinderOpen,
    initiativesTableSort,
    copyForwardTimeFrame
})
