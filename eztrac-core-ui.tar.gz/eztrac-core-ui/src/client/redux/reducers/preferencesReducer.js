import {combineReducers} from 'redux'
import {
    SET_FAVORITE_TEAMS_PREFERENCE,
    SET_SELECTED_TEAM_TAB,
    SET_SORT_ORDER_PREFERENCE,
    SET_SORT_ORDER_PREFERENCE_PEOPLE_LOCAL
} from '../constants/preferencesConstants'
import {
    setLastTabPreferenceServer,
    setPeopleSortOrderPreferenceServer,
    setSortOrderPreferenceServer
} from '../sagas/helpers/preferences'

export const preferences = (state = {}, action = {}) => {
    switch (action.type) {
        case SET_FAVORITE_TEAMS_PREFERENCE:
            return action.payload
        default:
            return state
    }
}

export const sortOrderPreferences = (
    state = {nameNum: 1, allocationNum: 0, costNum: 0},
    action = {}
) => {
    switch (action.type) {
        case SET_SORT_ORDER_PREFERENCE:
            setSortOrderPreferenceServer('sort', action.payload)

            return action.payload
        default:
            return state
    }
}

export const sortOrderPreferencesPeople = (
    state = {nameNum: 0, participationNum: 0, rateNum: 0, costGroupNum: 0, numberOfPeopleNum: 0},
    action = {}
) => {
    switch (action.type) {
        case SET_SORT_ORDER_PREFERENCE_PEOPLE_LOCAL:
            setPeopleSortOrderPreferenceServer('sort', action.payload)

            return action.payload
        default:
            return state
    }
}

export const selectedTeamTab = (state = '', action = {}) => {
    switch (action.type) {
        case SET_SELECTED_TEAM_TAB:
            setLastTabPreferenceServer('lastTab', action.payload)

            return action.payload
        default:
            return state
    }
}

export default combineReducers({
    preferences,
    sortOrderPreferences,
    sortOrderPreferencesPeople,
    selectedTeamTab
})
