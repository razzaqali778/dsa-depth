import {combineReducers} from 'redux'
import {
    CLEAR_NEW_FORECASTED_PERSON_DATA,
    CLEAR_NEW_PERSON_DATA,
    SET_ACTIVE_PEOPLE,
    SET_COST_GROUPS,
    SET_IS_PEOPLE_MODIFY_FINDER_OPEN,
    SET_NEW_FORECASTED_PERSON_DATA,
    SET_NEW_PERSON_DATA,
    SET_PEOPLE,
    SET_RATES,
    SET_SELECTED_TIME_FRAME_FORECASTED_PEOPLE,
    SET_SELECTED_TIME_FRAME_TEAM_PEOPLE,
    SET_TEAM_FORECASTED_PEOPLE,
    SET_TEAM_PEOPLE,
    SET_USER_PROFILE_DETAILS
} from '../constants/peopleConstants'

const people = (state = [], action = {}) => {
    switch (action.type) {
        case SET_PEOPLE:
            return action.payload
        default:
            return state
    }
}
const activePeople = (state = [], action = {}) => {
    switch (action.type) {
        case SET_ACTIVE_PEOPLE:
            return action.payload
        default:
            return state
    }
}
const rates = (state = [], action = {}) => {
    switch (action.type) {
        case SET_RATES:
            return action.payload
        default:
            return state
    }
}

const costGroups = (state = [], action = {}) => {
    switch (action.type) {
        case SET_COST_GROUPS:
            return action.payload
        default:
            return state
    }
}

const isPeopleModifyFinderOpen = (state = false, action = {}) => {
    switch (action.type) {
        case SET_IS_PEOPLE_MODIFY_FINDER_OPEN:
            return action.payload
        default:
            return state
    }
}

const selectedTimeFrameTeamPeople = (state = [], action = {}) => {
    switch (action.type) {
        case SET_SELECTED_TIME_FRAME_TEAM_PEOPLE:
            return action.payload
        default:
            return state
    }
}
const newPersonData = (state = {participationPct: 100}, action = {}) => {
    switch (action.type) {
        case SET_NEW_PERSON_DATA:
            return action.payload
        case CLEAR_NEW_PERSON_DATA:
            return {participationPct: 100}
        default:
            return state
    }
}

const newForecastedPersonData = (
    state = {rateId: '', costGroupId: '', numberOfPeople: 1},
    action = {}
) => {
    switch (action.type) {
        case SET_NEW_FORECASTED_PERSON_DATA:
            return action.payload
        case CLEAR_NEW_FORECASTED_PERSON_DATA:
            return {
                rateId: '',
                rateName: '',
                costGroupId: '',
                costGroupName: '',
                numberOfPeople: 1
            }
        default:
            return state
    }
}

const teamPeople = (state = [], action = {}) => {
    switch (action.type) {
        case SET_TEAM_PEOPLE:
            return action.payload
        default:
            return state
    }
}

const selectedTimeFrameForecastedPeople = (state = [], action = {}) => {
    switch (action.type) {
        case SET_SELECTED_TIME_FRAME_FORECASTED_PEOPLE:
            return action.payload
        default:
            return state
    }
}

const teamForecastedPeople = (state = [], action = {}) => {
    switch (action.type) {
        case SET_TEAM_FORECASTED_PEOPLE:
            return action.payload
        default:
            return state
    }
}

export const currentUserProfileDetails = (state = {}, action = {}) => {
    switch (action.type) {
        case SET_USER_PROFILE_DETAILS: {
            return action.payload
        }
        default:
            return state
    }
}

export default combineReducers({
    people,
    isPeopleModifyFinderOpen,
    selectedTimeFrameTeamPeople,
    newPersonData,
    teamPeople,
    selectedTimeFrameForecastedPeople,
    teamForecastedPeople,
    rates,
    costGroups,
    newForecastedPersonData,
    activePeople,
    currentUserProfileDetails
})
