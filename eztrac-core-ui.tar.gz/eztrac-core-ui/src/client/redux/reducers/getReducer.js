import {combineReducers} from 'redux'
import {
    SET_DOWNLOAD_ALL,
    SET_GET_CSV_DOWNLOAD,
    SET_SELECTED_COMMUNITY_PLATFORM,
    SET_SELECTED_REGION,
    SET_SELECTED_TEAMS
} from '../constants/getConstants'

export const csvDownload = (state = [], action = {}) => {
    switch (action.type) {
        case SET_GET_CSV_DOWNLOAD:
            return action.payload
        case SET_SELECTED_COMMUNITY_PLATFORM:
            return []
        case SET_SELECTED_TEAMS:
            return []
        case SET_DOWNLOAD_ALL:
            return []
        default:
            return state
    }
}

export const selectedCommunityPlatform = (state = [], action = {}) => {
    switch (action.type) {
        case SET_SELECTED_COMMUNITY_PLATFORM:
            return action.payload
        default:
            return state
    }
}

export const selectedTeams = (state = [], action = {}) => {
    switch (action.type) {
        case SET_SELECTED_TEAMS:
            return action.payload
        default:
            return state
    }
}

export const selectedRegion = (state = '', action = {}) => {
    switch (action.type) {
        case SET_SELECTED_REGION:
            return action.payload
        default:
            return state
    }
}

export const downloadAll = (state = false, action = {}) => {
    switch (action.type) {
        case SET_DOWNLOAD_ALL:
            return action.payload
        default:
            return state
    }
}

export default combineReducers({
    csvDownload,
    selectedCommunityPlatform,
    selectedTeams,
    downloadAll,
    selectedRegion
})
