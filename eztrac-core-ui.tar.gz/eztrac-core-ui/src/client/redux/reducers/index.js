import {combineReducers} from 'redux'
import {SET_IS_LOADING} from '../constants'
import engagement from './engagements/engagementsReducer'
import get from './getReducer'
import initiative from './initiativeReducer'
import location from './locationReducer'
import people from './peopleReducer'
import preference from './preferencesReducer'
import team from './teamReducer'
import timeFrame from './timeFrameReducer'
import users from './userReducer'

export const isLoading = (state = false, action = {}) => {
    switch (action.type) {
        case SET_IS_LOADING:
            return action.payload
        default:
            return state
    }
}

export default combineReducers({
    location,
    preference,
    team,
    timeFrame,
    isLoading,
    engagement,
    users,
    initiative,
    people,
    get
})
