import {combineReducers} from 'redux'
import isUndefined from 'lodash/isUndefined'
import sortBy from 'lodash/sortBy'
import {
    SET_CALENDAR_MODAL_BOOL,
    SET_COPY_CALENDAR_MODAL_BOOL,
    SET_END_TIME_FRAME,
    SET_SAVE_LOCKED_TIME_FRAME_DATA,
    SET_SELECTED_TIME_FRAME_ID,
    SET_START_END_SELECTOR,
    SET_START_TIME_FRAME,
    SET_TIME_FRAMES
} from '../constants/timeFramesConstants'

export const timeFrames = (state = [], action = {}) => {
    switch (action.type) {
        case SET_TIME_FRAMES:
            return sortBy(action.payload, 'startTimeFrame')
        default:
            return state
    }
}

export const selectedTimeFrameId = (state = '', action = {}) => {
    switch (action.type) {
        case SET_SELECTED_TIME_FRAME_ID:
            return action.payload
        default:
            return state
    }
}

export const saveLockedTimeFrameData = (state = {showWarning: false}, action = {}) => {
    switch (action.type) {
        case SET_SAVE_LOCKED_TIME_FRAME_DATA:
            return action.payload
        default:
            return state
    }
}

export const startTimeFrame = (state = {}, action = {}) => {
    switch (action.type) {
        case SET_START_TIME_FRAME:
            return isUndefined(action.payload) ? {value: '', label: ''} : action.payload
        default:
            return state
    }
}

export const endTimeFrame = (state = {}, action = {}) => {
    switch (action.type) {
        case SET_END_TIME_FRAME:
            return isUndefined(action.payload) ? {value: '', label: ''} : action.payload
        default:
            return state
    }
}

export const calendarModalBool = (state = false, action = {}) => {
    switch (action.type) {
        case SET_CALENDAR_MODAL_BOOL:
            return action.payload
        default:
            return state
    }
}

export const startEndSelector = (state = true, action = {}) => {
    switch (action.type) {
        case SET_START_END_SELECTOR:
            return action.payload
        default:
            return state
    }
}

export const copyCalendarModalBool = (state = false, action = {}) => {
    switch (action.type) {
        case SET_COPY_CALENDAR_MODAL_BOOL:
            return action.payload
        default:
            return state
    }
}

export default combineReducers({
    timeFrames,
    selectedTimeFrameId,
    startTimeFrame,
    endTimeFrame,
    calendarModalBool,
    startEndSelector,
    copyCalendarModalBool,
    saveLockedTimeFrameData
})
