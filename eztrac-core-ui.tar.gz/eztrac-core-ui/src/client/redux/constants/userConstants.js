const namespace = 'user'

export const FETCH_CURRENT_USER = `${namespace}/FETCH_CURRENT_USER`
export const SET_CURRENT_USER = `${namespace}/SET_CURRENT_USER`
