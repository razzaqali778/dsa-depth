const namespace = 'timeFrames'

export const FETCH_TIME_FRAMES = `${namespace}/FETCH_TIME_FRAMES`
export const SET_TIME_FRAMES = `${namespace}/SET_TIME_FRAMES`
export const SET_START_TIME_FRAME = `${namespace}/SET_START_TIME_FRAME`
export const SET_END_TIME_FRAME = `${namespace}/SET_END_TIME_FRAME`
export const SET_SELECTED_TIME_FRAME_ID = `${namespace}/SET_SELECTED_TIME_FRAME_ID`
export const SET_APPROPRIATE_TIME_FRAMES = `${namespace}/SET_APPROPRIATE_TIME_FRAMES`
export const SET_CALENDAR_MODAL_BOOL = `${namespace}/SET_CALENDAR_MODAL_BOOL`
export const SET_START_END_SELECTOR = `${namespace}/SET_START_END_SELECTOR`
export const SET_COPY_CALENDAR_MODAL_BOOL = `${namespace}/SET_COPY_CALENDAR_MODAL_BOOL`
export const SET_SAVE_LOCKED_TIME_FRAME_DATA = `${namespace}/SET_SAVE_LOCKED_TIME_FRAME_DATA`
