const namespace = 'location'

export const SET_LOCATION = `${namespace}/SET_LOCATION`
export const UPDATE_LOCATION = `${namespace}/UPDATE_LOCATION`
export const UPDATE_LOCATION_QUERY = `${namespace}/UPDATE_LOCATION_QUERY`
export const REMOVE_LOCATION_QUERY = `${namespace}/REMOVE_LOCATION_QUERY`
