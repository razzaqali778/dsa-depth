const namespace = 'getExport'

export const FETCH_GET_EXPORT = `${namespace}/FETCH_GET_EXPORT`
export const SET_GET_CSV_DOWNLOAD = `${namespace}/SET_GET_CSV_DOWNLOAD`
export const SET_SELECTED_COMMUNITY_PLATFORM = `${namespace}/SET_SELECTED_COMMUNITY_PLATFORM`
export const SET_SELECTED_TEAMS = `${namespace}/SET_SELECTED_TEAMS`
export const SET_DOWNLOAD_ALL = `${namespace}/SET_DOWNLOAD_ALL`
export const SET_SELECTED_REGION = `${namespace}/SET_SELECTED_REGION`
