const namespace = 'team'

export const SET_TEAMS = `${namespace}/SET_TEAMS`
export const SET_COMMUNITIES = `${namespace}/SET_COMMUNITIES`
export const SET_SELECTED_COMMUNITY_ID = `${namespace}/SET_SELECTED_COMMUNITY_ID`
export const SET_SELECTED_PLATFORM_ID = `${namespace}/SET_SELECTED_PLATFORM_ID`
export const SET_SELECTED_ORG_ID = `${namespace}/SET_SELECTED_ORG_ID`
export const SET_PLATFORMS = `${namespace}/SET_PLATFORMS`
export const SET_ORGS = `${namespace}/SET_ORGS`
export const SET_SELECTED_TEAM = `${namespace}/SET_SELECTED_TEAM`
export const SET_TEAM_COST_DATA = `${namespace}/SET_TEAM_COST_DATA`
export const SET_IS_EDITING = `${namespace}/SET_IS_EDITING`
export const SET_SELECTED_TIME_FRAME_TEAM_COST = `${namespace}/SET_SELECTED_TIME_FRAME_TEAM_COST`
export const SET_SELECTED_TEAM_FROM_URL = `${namespace}/SET_SELECTED_TEAM_FROM_URL`
export const SET_SELECTED_TEAM_TAB_FROM_URL = `${namespace}/SET_SELECTED_TEAM_TAB_FROM_URL`

export const FETCH_TEAMS = `${namespace}/FETCH_TEAMS`
export const FETCH_TEAM_DATA = `${namespace}/FETCH_TEAM_DATA`
export const FETCH_COMMUNITIES = `${namespace}/FETCH_COMMUNITIES`
export const FETCH_PLATFORMS = `${namespace}/FETCH_PLATFORMS`
export const FETCH_ORGS = `${namespace}/FETCH_ORGS`
export const FETCH_TEAM_COST_DATA = `${namespace}/FETCH_TEAM_COST_DATA`

/* FORM CONSTANTS */
export const SET_FORM_COMMUNITY_ID = `${namespace}/SET_FORM_COMMUNITY_ID`
export const SET_FORM_IS_ACTIVE = `${namespace}/SET_FORM_IS_ACTIVE`
export const SET_FORM_TEAM_NAME = `${namespace}/SET_FORM_TEAM_NAME`
export const SET_FORM_PLATFORM_NAME = `${namespace}/SET_FORM_PLATFORM_NAME`

export const SAVE_TEAM = `${namespace}/SAVE_TEAM`
export const SAVE_COMMUNITY = `${namespace}/SAVE_COMMUNITY`
export const SAVE_PLATFORM = `${namespace}/SAVE_PLATFORM`

export const TOGGLE_IS_CREATING_TEAM = `${namespace}/TOGGLE_IS_CREATING_TEAM`

export const SET_UNSAVED_DATA_MODAL_BOOL = `${namespace}/SET_UNSAVED_DATA_MODAL_BOOL`
export const SET_UNSAVED_CHANGES_BOOL = `${namespace}/SET_UNSAVED_CHANGES_BOOL`
export const SET_LOCKDOWN_CHANGES_BOOL = `${namespace}/SET_LOCKDOWN_CHANGES_BOOL`
export const SET_LOCKDOWN_CHANGES_ACTION = `${namespace}/SET_LOCKDOWN_CHANGES_ACTION`
