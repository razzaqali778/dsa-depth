import createSagaMiddleware from 'redux-saga'
import {createLogger} from 'redux-logger'
import sagas from '../sagas'

const sagaMiddleware = createSagaMiddleware()

const makeReduxMiddleware = () => {
    const middlewares = [sagaMiddleware]

    if (import.meta.env.MODE !== 'production') {
        const loggerMiddleware = createLogger({
            collapsed: true,
            duration: true,
            timestamp: true,
            logErrors: true
        })

        middlewares.push(loggerMiddleware)
    }

    return middlewares
}

export const runSagas = () => sagaMiddleware.run(sagas)

export default makeReduxMiddleware()
