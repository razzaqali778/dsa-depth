import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants/peopleConstants'

export default makeActions(constants)
