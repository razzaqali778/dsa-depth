import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants/timeFramesConstants'

export default makeActions(constants)
