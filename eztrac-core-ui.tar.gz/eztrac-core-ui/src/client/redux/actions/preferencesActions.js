import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants/preferencesConstants'

export default makeActions(constants)
