import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants/initiativeConstants'

export default makeActions(constants)
