import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants/userConstants'

export default makeActions(constants)
