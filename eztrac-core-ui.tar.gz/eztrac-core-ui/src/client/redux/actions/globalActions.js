import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants'

export default makeActions(constants)
