import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants/getConstants'

export default makeActions(constants)
