import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants/locationConstants'

export default makeActions(constants)
