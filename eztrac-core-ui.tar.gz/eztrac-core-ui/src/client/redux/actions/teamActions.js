import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants/teamConstants'

export default makeActions(constants)
