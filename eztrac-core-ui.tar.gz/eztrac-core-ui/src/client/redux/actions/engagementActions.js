import makeActions from '@monsantoit/redux-make-actions'
import * as constants from '../constants/engagementConstants'

export default makeActions(constants)
