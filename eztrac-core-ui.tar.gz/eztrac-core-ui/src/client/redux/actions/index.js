import engagement from './engagementActions'
import gActions from './globalActions'
import get from './getActions'
import initiative from './initiativeActions'
import location from './locationActions'
import people from './peopleActions'
import preferences from './preferencesActions'
import team from './teamActions'
import timeFrames from './timeFramesActions'
import user from './userActions'

export const engagementActions = engagement
export const locationActions = location
export const teamActions = team
export const globalActions = gActions
export const preferencesActions = preferences
export const timeFrameActions = timeFrames
export const userActions = user
export const initiativeActions = initiative
export const peopleActions = people
export const getActions = get

export default {
    ...engagement,
    ...location,
    ...team,
    ...globalActions,
    ...initiative,
    ...preferences,
    ...timeFrames,
    ...user,
    ...people,
    ...get
}
