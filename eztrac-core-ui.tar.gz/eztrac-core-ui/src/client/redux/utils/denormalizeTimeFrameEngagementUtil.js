import find from 'lodash/find'
import map from 'lodash/map'

export default function denormalizeTimeFrameEngagement(
    teamEngagements,
    timeFrames,
    engagementOptions
) {
    const denormalizedEngagement = map(teamEngagements, (teamEngagement) => {
        if (teamEngagement.timeFrameId) {
            const matchedTimeFrame = find(
                timeFrames,
                (timeFrame) => timeFrame.id === teamEngagement.timeFrameId
            )
            const matchEngagementOption = find(
                engagementOptions,
                (engagement) => engagement.id === teamEngagement.engagementId
            )

            if (matchedTimeFrame && matchEngagementOption) {
                const {
                    startDate,
                    endDate,
                    name: timeFrameName,
                    lockdown: timeFrameLockdown,
                    isActive: isTimeFrameActive
                } = matchedTimeFrame

                const {
                    name: engagementName,
                    isActive: isEngagementActive,
                    purchaseOrder
                } = matchEngagementOption

                return {
                    ...teamEngagement,
                    startDate,
                    timeFrameLockdown,
                    endDate,
                    timeFrameName,
                    isTimeFrameActive,
                    engagementName,
                    isEngagementActive,
                    purchaseOrder
                }
            }

            return teamEngagement
        }

        return teamEngagement
    })

    return denormalizedEngagement
}
