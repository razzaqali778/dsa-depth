import isNull from 'lodash/isNull'
import isUndefined from 'lodash/isUndefined'

const isInvalid = (value) => value === '' || isNull(value) || isUndefined(value)

export function isTeamSaveDisabled(communityId, teamName) {
    return isInvalid(communityId) || isInvalid(teamName)
}
