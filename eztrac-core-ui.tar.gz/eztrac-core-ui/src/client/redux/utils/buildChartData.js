import _ from 'lodash/'
import concat from 'lodash/concat'
import difference from 'lodash/difference'
import filter from 'lodash/filter'
import find from 'lodash/find'
import findIndex from 'lodash/findIndex'
import map from 'lodash/map'
import orderBy from 'lodash/orderBy'
import reverse from 'lodash/reverse'
import slice from 'lodash/slice'
import sumBy from 'lodash/sumBy'

const colors = [
    'rgba(255, 57, 53, 0.5)',
    'rgba(30, 136, 229, 0.5)',
    'rgba(67, 160, 71, 0.5)',
    'rgba(255, 216, 53, 0.5)',
    'rgba(156, 39, 176, 0.5)',
    'rgba(255, 140, 0, 0.5)'
]

const borderColor = 'rgba(0, 0, 0, .4)'

const borderWidth = 1
let colorIndex = -1

function getColor() {
    colorIndex += 1

    return colors[colorIndex]
}

function buildDataSets(initiative, label, trimmedTimeFrames) {
    const data = map(trimmedTimeFrames, (timeFrame) => {
        const matchedInitiative = find(
            initiative,
            (initiativeMonth) => initiativeMonth.timeFrameId === timeFrame.value
        )

        return matchedInitiative ? matchedInitiative.initiativeCost : 0
    })
    const backgroundColor = getColor()

    return {label, data, stack: 'stack1', backgroundColor, borderColor, borderWidth}
}

function buildInitiativeData(teamInitiatives) {
    const groupedInitiatives = _(teamInitiatives).groupBy('id').value()

    if (Object.keys(groupedInitiatives).length > 5) {
        const initiativesOrderedByCost = orderBy(
            map(groupedInitiatives, (initiative) => ({
                id: initiative[0].id,
                initiativeName: initiative[0].initiativeName,
                initiativeCost: sumBy(initiative, 'initiativeCost'),
                timeFrameId: initiative[0].timeFrameId
            })),
            'initiativeCost',
            'desc'
        )

        const detailedInitiatives = slice(initiativesOrderedByCost, 0, 5)
        const formattedDetailedInitiatives = filter(teamInitiatives, (teamInitiative) =>
            find(
                detailedInitiatives,
                (detailedInitiative) => teamInitiative.id === detailedInitiative.id
            )
        )

        const otherInitiatives = difference(teamInitiatives, formattedDetailedInitiatives)

        const formattedOtherInitiatives = _(otherInitiatives)
            .groupBy('timeFrameId')
            .map((timeFrame) => ({
                initiativeCost: sumBy(timeFrame, 'initiativeCost'),
                initiativeName: 'Other',
                timeFrameId: timeFrame[0].timeFrameId
            }))
            .value()

        return concat(formattedDetailedInitiatives, formattedOtherInitiatives)
    }

    return teamInitiatives
}

export default function buildChartData(teamInitiatives, relevantTimeFrames) {
    const labels = map(relevantTimeFrames, 'label')
    colorIndex = -1

    const sortedTeamInitiatives = buildInitiativeData(teamInitiatives)
    const filteredTeamInitiatives = filter(
        sortedTeamInitiatives,
        (initiative) => initiative.initiativeCost > 0
    )
    const preliminaryDatasets = _(filteredTeamInitiatives)
        .groupBy('id')
        .map((initiative) =>
            buildDataSets(initiative, initiative[0].initiativeName, relevantTimeFrames)
        )
        .value()

    let index = 1
    const datasets = reverse(
        map(reverse(preliminaryDatasets), (dataset) => {
            const isFound = findIndex(
                slice(preliminaryDatasets, index),
                (dataAtIndex) => dataAtIndex.label === dataset.label
            )
            index += 1
            if (isFound !== -1) {
                return {...dataset, label: `${dataset.label} (${isFound + 1})`}
            }

            return dataset
        })
    )

    const chartData = {
        labels,
        datasets
    }

    return chartData
}
