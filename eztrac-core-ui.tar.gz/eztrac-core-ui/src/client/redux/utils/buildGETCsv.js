import get from 'lodash/get'
import isArray from 'lodash/isArray'
import isEmpty from 'lodash/isEmpty'
import sortBy from 'lodash/sortBy'

const delimitWithQuotes = (e) => (e ? `"${e}"` : '')

const csvHeader = [
    delimitWithQuotes('CWID'),
    delimitWithQuotes('GET ID'),
    delimitWithQuotes('Date'),
    delimitWithQuotes('Hours'),
    delimitWithQuotes(''),
    delimitWithQuotes('Person'),
    delimitWithQuotes('Manager'),
    delimitWithQuotes('Cost Group'),
    delimitWithQuotes('Team')
]

const buildCsvRow = (row) => [
    delimitWithQuotes(get(row, 'person.id', '')),
    delimitWithQuotes(get(row, 'initiative.activityId', '')),
    delimitWithQuotes(new Date(row.date).toISOString().split('T')[0].replace(/-/g, '.')),
    row.hours,
    delimitWithQuotes(''),
    delimitWithQuotes(get(row, 'person.name', '')),
    delimitWithQuotes(get(row, 'person.manager.name', '')),
    delimitWithQuotes(get(row, 'costingData.costGroupName', '')),
    delimitWithQuotes(get(row, 'team.teamName', ''))
]

const hasRequiredObjects = (row) => {
    if (row.person && row.date && row.hours && row.initiative) {
        return true
    }

    return false
}

export default function buildGETCsv(jsonReport) {
    if (isEmpty(jsonReport)) {
        return []
    }
    if (!isArray(jsonReport)) {
        throw new Error('Expected GET export array')
    }
    let csvText = csvHeader.join(',')
    const sortedJson = sortBy(jsonReport, ['person.id', 'date'])
    sortedJson.forEach((row) => {
        if (hasRequiredObjects(row)) {
            const csvFields = buildCsvRow(row)
            csvText += `\n${csvFields.join(',')}`
        }
    })

    if (csvText.length === csvHeader.join(',').length) {
        console.error('Records must contain person, hours, date, and initiative', jsonReport)

        throw new Error('Records must contain person, hours, date, and initiative')
    }

    return csvText
}
