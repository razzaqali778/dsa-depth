import filter from 'lodash/filter'

export const getActiveEngagements = (groupedAndSortedEngagements) =>
    filter(
        groupedAndSortedEngagements,
        (engagement) => engagement[engagement.length - 1].timeFrameLockdown === false
    )
