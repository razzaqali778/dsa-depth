import find from 'lodash/find'
import forEach from 'lodash/forEach'
import map from 'lodash/map'

export function addCostToTimeFrameTotals(totalTable, timeFrameId, cost) {
    if (find(totalTable, (tableRow) => tableRow.timeFrameId === timeFrameId)) {
        return map(totalTable, (totalRow) => {
            if (totalRow.timeFrameId === timeFrameId) {
                return {timeFrameId, cost: totalRow.cost + cost}
            }

            return totalRow
        })
    }

    return [...totalTable, {timeFrameId, cost}]
}

export function calculatedCostsForEngagement(calculatorRows, calendar) {
    let totalTable = []

    forEach(calculatorRows, (row) => {
        map(calendar, (timeFrame) => {
            const cost = Number(row.people) * Number(row.hourlyRate) * timeFrame.contractorHours
            totalTable = addCostToTimeFrameTotals(totalTable, timeFrame.timeFrameId, cost)
        })
    })

    return totalTable
}
