import find from 'lodash/find'

export const isSelected = (key, selectedTimeFrameInitiatives) =>
    !!find(selectedTimeFrameInitiatives, ({id}) => id === key)

export const isPersonSelected = (key, people) => !!find(people, ({personId}) => personId === key)

export const isForecastedPersonSelected = (forecastedPerson, forecastedPeople) => {
    const key = forecastedPerson.rateId + forecastedPerson.costGroupId

    return !!find(forecastedPeople, (person) => person.rateId + person.costGroupId === key)
}

export const appendTimeFrameId = (object, selectedTimeFrameId) => ({
    ...object,
    timeFrameId: selectedTimeFrameId
})
