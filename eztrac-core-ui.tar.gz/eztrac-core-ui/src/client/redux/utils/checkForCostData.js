import find from 'lodash/find'
import findIndex from 'lodash/findIndex'
import isUndefined from 'lodash/isUndefined'
import map from 'lodash/map'
import slice from 'lodash/slice'
import split from 'lodash/split'
import getTimeFrameRange from './getTimeFrameRange'

export default function checkForCostData(
    teamCostData,
    allTimeFrames,
    currentMonthTimeFrame,
    endTimeFrame
) {
    const timeFrameRange = getTimeFrameRange(allTimeFrames)
    const trimmedTimeFrameRange = slice(
        timeFrameRange,
        findIndex(timeFrameRange, (timeFrame) => timeFrame.id === currentMonthTimeFrame.id),
        findIndex(timeFrameRange, (timeFrame) => timeFrame.id === endTimeFrame.id) + 1
    )
    let timeframesMissingCostData = ''

    map(trimmedTimeFrameRange, (timeFrame) => {
        const selectedTimeFrame = find(
            teamCostData,
            (initiative) => initiative.timeFrameId === timeFrame.id
        )

        if (isUndefined(selectedTimeFrame) || selectedTimeFrame.teamCost === 0) {
            timeframesMissingCostData += `, ${timeFrame.name}`
        }
    })

    if (timeframesMissingCostData === '') {
        return null
    }

    const timeframesMissingCostDataArray = split(timeframesMissingCostData, ',')

    if (timeframesMissingCostDataArray.length > 3) {
        return `WARNING! No cost data for: ${timeframesMissingCostDataArray[1]}, ${timeframesMissingCostDataArray[2]}`
    }

    return `WARNING! No cost data for${timeframesMissingCostData}`
}
