import filter from 'lodash/filter'
import isEqual from 'lodash/isEqual'
import map from 'lodash/map'
import pick from 'lodash/pick'
import sortBy from 'lodash/sortBy'
import sumBy from 'lodash/sumBy'

const normalizeNumber = (value) => Number(value)

export function validatePct(pct) {
    return pct === '' || /^\d\d?$|^100$/.test(pct)
}

export function validateInitiativeCost(initiativeCost) {
    return initiativeCost === '' || /^\d*$/.test(initiativeCost)
}

export function validateTotalTeamCostPct(initiatives) {
    const totalTeamCostPct = sumBy(initiatives, (initiative) => initiative.teamCostPct)

    return !(totalTeamCostPct <= 100)
}

export function hasInitiativeDataChanged(teamInitiatives, changedInitiatives, selectedTimeFrameId) {
    const filteredTeamInitiatives = filter(
        teamInitiatives,
        (initiative) => initiative.timeFrameId === selectedTimeFrameId
    )
    const comparableTeamInitiatives = map(filteredTeamInitiatives, (i) => ({
        ...pick(i, ['id']),
        teamCostPct: normalizeNumber(i.teamCostPct)
    }))
    const comparableChangedInitiatives = map(changedInitiatives, (i) => ({
        ...pick(i, ['id']),
        teamCostPct: normalizeNumber(i.teamCostPct)
    }))
    const sortedComparableTeamInitiatives = sortBy(comparableTeamInitiatives, ['id'])
    const sortedComparableChangedInitiatives = sortBy(comparableChangedInitiatives, ['id'])

    return !isEqual(sortedComparableTeamInitiatives, sortedComparableChangedInitiatives)
}
