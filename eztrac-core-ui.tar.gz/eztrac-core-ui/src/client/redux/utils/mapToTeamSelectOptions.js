import compact from 'lodash/compact'
import find from 'lodash/find'
import map from 'lodash/map'

export default (teamSelectOptions, favouriteTeams) => {
    const favoriteTeamSelect = compact(
        map(favouriteTeams, (favoriteTeam) => {
            const relevantTeam = find(teamSelectOptions, (team) => team.value === favoriteTeam)
            if (relevantTeam) {
                const teamDisplayText =
                    relevantTeam.active === false
                        ? `${relevantTeam.label}  (inactive)`
                        : relevantTeam.label

                return {
                    value: relevantTeam.value,
                    label: teamDisplayText,
                    active: relevantTeam.active,
                    communityId: relevantTeam.communityId
                }
            }

            return null
        })
    )

    return favoriteTeamSelect
}
