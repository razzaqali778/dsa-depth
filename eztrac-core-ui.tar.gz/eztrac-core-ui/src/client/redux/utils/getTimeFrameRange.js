import filter from 'lodash/filter'

export default function getTimeFrameRange(allTimeFrames) {
    return filter(allTimeFrames, (timeFrame) => timeFrame.isActive === true)
}
