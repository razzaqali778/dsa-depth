import find from 'lodash/find'

export function getContractorHoursForDisplay(
    calendarHours,
    selectedCalendarId,
    selectedTimeFrameId
) {
    const currentSelectedCalendarTimeFrame = find(
        calendarHours,
        (calendar) =>
            calendar.calendarId === selectedCalendarId &&
            calendar.timeFrameId === selectedTimeFrameId
    )

    if (currentSelectedCalendarTimeFrame) {
        return currentSelectedCalendarTimeFrame.contractorHours
    }

    return null
}
