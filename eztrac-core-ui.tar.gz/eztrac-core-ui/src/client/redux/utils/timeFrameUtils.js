import filter from 'lodash/filter'
import find from 'lodash/find'

function getTimeFrameNMonthsAway(selectedTimeFrameId, timeFrames, monthsAway) {
    if (!selectedTimeFrameId || !timeFrames || !timeFrames.length) {
        return undefined
    }

    const selectedTimeFrame = find(
        timeFrames,
        (timeFrame) => String(timeFrame.id) === String(selectedTimeFrameId)
    )
    // Selected id can be missing while timeframes are still loading, or when the caller
    // passes a filtered list (e.g. active-only) that does not include the current selection.
    if (!selectedTimeFrame || selectedTimeFrame.startDate == null) {
        return undefined
    }

    const selectedTimeFrameStartDate = new Date(0)
    selectedTimeFrameStartDate.setUTCMilliseconds(selectedTimeFrame.startDate)
    const selectedYear = selectedTimeFrameStartDate.getUTCFullYear()
    const selectedMonth = selectedTimeFrameStartDate.getUTCMonth()
    const selectedDate = selectedTimeFrameStartDate.getUTCDate()

    const requestedTimeFrameStartDate = Date.UTC(
        selectedYear,
        selectedMonth + monthsAway,
        selectedDate
    )
    const requestedTimeFrame = find(
        timeFrames,
        (timeFrame) => timeFrame.startDate === requestedTimeFrameStartDate
    )
    return requestedTimeFrame
}

export function getTimeFrameIdNMonthsAway(selectedTimeFrameId, timeFrames, monthsAway) {
    const requestedTimeFrame = getTimeFrameNMonthsAway(selectedTimeFrameId, timeFrames, monthsAway)

    return requestedTimeFrame ? requestedTimeFrame.id : null
}
export function getTimeFrameNameNMonthsAway(selectedTimeFrameId, timeFrames, monthsAway) {
    const requestedTimeFrame = getTimeFrameNMonthsAway(selectedTimeFrameId, timeFrames, monthsAway)

    return requestedTimeFrame ? requestedTimeFrame.name : null
}
export function getEndOfCurrentFiscalYearTimeFrameId(selectedTimeFrameId, timeFrames) {
    if (!selectedTimeFrameId || !timeFrames || !timeFrames.length) {
        return null
    }

    const selectedTimeFrame = find(
        timeFrames,
        (timeFrame) => String(timeFrame.id) === String(selectedTimeFrameId)
    )
    if (!selectedTimeFrame || selectedTimeFrame.startDate == null) {
        return null
    }

    const selectedTimeFrameStartDate = new Date(0)
    selectedTimeFrameStartDate.setUTCMilliseconds(selectedTimeFrame.startDate)
    const selectedYear = selectedTimeFrameStartDate.getUTCFullYear()
    const selectedMonth = selectedTimeFrameStartDate.getUTCMonth()
    const selectedDate = selectedTimeFrameStartDate.getUTCDate()

    const endOfFiscalYearTimeFrameStartDate = Date.UTC(
        selectedYear,
        selectedMonth + (11 - selectedMonth),
        selectedDate
    )
    const endOfFiscalYearTimeFrame = find(
        timeFrames,
        (timeFrame) => timeFrame.startDate === endOfFiscalYearTimeFrameStartDate
    )

    return endOfFiscalYearTimeFrame ? endOfFiscalYearTimeFrame.id : null
}

export function getUnlockedTimeFramesForRange(startTimeFrameId, endTimeFrameId, timeFrames) {
    const startTimeFrame = find(
        timeFrames,
        (timeFrame) => String(timeFrame.id) === String(startTimeFrameId)
    )
    const endTimeFrame = find(
        timeFrames,
        (timeFrame) => String(timeFrame.id) === String(endTimeFrameId)
    )

    if (!startTimeFrame || !endTimeFrame) {
        return []
    }

    return filter(
        timeFrames,
        (timeFrame) =>
            timeFrame.startDate >= startTimeFrame.startDate &&
            timeFrame.startDate <= endTimeFrame.startDate &&
            !timeFrame.lockdown
    )
}
