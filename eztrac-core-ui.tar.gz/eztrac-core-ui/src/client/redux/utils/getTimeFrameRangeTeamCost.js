import filter from 'lodash/filter'
import sumBy from 'lodash/sumBy'

export default function getTimeFrameRangeTeamCost(startTimeFrame, endTimeFrame, teamCostData) {
    return sumBy(
        filter(
            teamCostData,
            (costData) =>
                costData.timeFrameId >= startTimeFrame && costData.timeFrameId <= endTimeFrame
        ),
        'teamCost'
    )
}
