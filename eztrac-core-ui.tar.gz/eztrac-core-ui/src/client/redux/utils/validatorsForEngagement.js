import filter from 'lodash/filter'
import isEmpty from 'lodash/isEmpty'
import isNull from 'lodash/isNull'
import isUndefined from 'lodash/isUndefined'

export function validatePeopleField(people) {
    const regex = /^[\d]*[.]?\d{0,2}$/g

    return regex.test(people)
}

export function validateEngagementCost(totalEngagementCost) {
    const regex = /[^0-9]+/g

    return !regex.test(totalEngagementCost)
}

export function validateHourlyRate(hourlyRate) {
    const regex = /[^0-9]+/g

    return !regex.test(hourlyRate)
}

export function validateEditCostInput(engagementCost) {
    if (engagementCost === '0,') {
        return false
    }
    const regex = /[^$0-9,]+/g

    return !regex.test(engagementCost) && !isEmpty(engagementCost)
}

const isInvalid = (value) => value === '' || isNull(value) || isUndefined(value) || value === 0

export function isEngagementSaveDisabled(amount, selectedTimeFrameId, selectedEngagementId) {
    return isInvalid(amount) || isInvalid(selectedTimeFrameId) || isEmpty(selectedEngagementId)
}

export function isDuplicateEngagement(teamEngagements, selectedTimeFrameId, selectedEngagementId) {
    if (!selectedEngagementId) {
        return false
    }
    const matchObject = {timeFrameId: selectedTimeFrameId, engagementId: selectedEngagementId}
    const result = !isEmpty(filter(teamEngagements, matchObject))

    return result
}

export function isAddRateDisabled({
    selectedCalendarId,
    hourlyRate,
    numberOfPeople,
    selectedTimeFrameId,
    selectedEngagementId
}) {
    return (
        isInvalid(hourlyRate) ||
        isInvalid(numberOfPeople) ||
        isInvalid(selectedTimeFrameId) ||
        isEmpty(selectedEngagementId) ||
        isInvalid(selectedCalendarId)
    )
}
