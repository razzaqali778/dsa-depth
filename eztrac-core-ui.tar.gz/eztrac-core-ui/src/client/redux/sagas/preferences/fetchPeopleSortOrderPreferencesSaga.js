import {call, put as dispatch} from 'redux-saga/effects'
import isEmpty from 'lodash/isEmpty'
import {getPeopleSortOrderPreferenceServer} from '../helpers/preferences'
import actions from '../../actions'

export default function* fetchPeopleSortOrderPreferences() {
    const sortOrderPreference = yield call(getPeopleSortOrderPreferenceServer)
    const defaultSort = {
        costGroupNum: 0,
        nameNum: 1,
        numberOfPeopleNum: 0,
        participationNum: 0,
        rateNum: 0
    }
    if (!isEmpty(sortOrderPreference)) {
        yield dispatch(actions.setSortOrderPreferencePeopleLocal(sortOrderPreference.sort))
    } else {
        yield dispatch(actions.setSortOrderPreferencePeopleLocal(defaultSort))
    }
}
