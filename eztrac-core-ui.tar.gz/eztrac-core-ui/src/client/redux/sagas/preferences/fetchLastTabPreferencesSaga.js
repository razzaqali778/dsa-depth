import {call, put as dispatch} from 'redux-saga/effects'
import isEmpty from 'lodash/isEmpty'
import {getLastTabPreferenceServer} from '../helpers/preferences'
import actions from '../../actions'

export default function* fetchLastTabPreferences() {
    const lastTabPreference = yield call(getLastTabPreferenceServer)
    const defaultTab = 'engagements'
    if (!isEmpty(lastTabPreference)) {
        yield dispatch(actions.setSelectedTeamTab(lastTabPreference.lastTab))
    } else {
        console.log('Setting default tab to engagements')
        yield dispatch(actions.setSelectedTeamTab(defaultTab))
    }
}
