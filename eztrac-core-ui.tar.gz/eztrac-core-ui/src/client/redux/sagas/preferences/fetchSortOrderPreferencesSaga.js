import {call, put as dispatch} from 'redux-saga/effects'
import isEmpty from 'lodash/isEmpty'
import {getSortOrderPreferenceServer} from '../helpers/preferences'
import actions from '../../actions'

export default function* fetchSortOrderPreferences() {
    const sortOrderPreference = yield call(getSortOrderPreferenceServer)
    const defaultSort = {
        nameNum: 1,
        allocationNum: 0,
        costNum: 0
    }
    if (!isEmpty(sortOrderPreference)) {
        yield dispatch(actions.setSortOrderPreference(sortOrderPreference.sort))
    } else {
        yield dispatch(actions.setSortOrderPreference(defaultSort))
    }
}
