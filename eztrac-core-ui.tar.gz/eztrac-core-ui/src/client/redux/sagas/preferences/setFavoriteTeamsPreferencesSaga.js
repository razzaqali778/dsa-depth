import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import has from 'lodash/has'
import pickBy from 'lodash/pickBy'
import {deleteFavoriteTeamsPreference, setFavoriteTeamsPreference} from '../helpers/preferences'
import {getFavoriteTeams} from '../../selectors'
import actions from '../../actions'

export function* setFavoriteTeamsPreferences({payload}) {
    const key = Object.keys(payload)[0]
    const val = payload[key]
    const currentFavorites = yield select(getFavoriteTeams)
    if (has(currentFavorites, val)) {
        const newFavorites = pickBy(currentFavorites, (favorite) => favorite !== val)
        yield dispatch(actions.setFavoriteTeamsPreference(newFavorites))
        deleteFavoriteTeamsPreference(key)
    } else {
        const newFavorites = {...currentFavorites, ...payload}
        yield dispatch(actions.setFavoriteTeamsPreference(newFavorites))
        setFavoriteTeamsPreference(key, val)
    }
}

export default function* () {
    yield takeLatest([actions.favoriteButtonClicked().type], setFavoriteTeamsPreferences)
}
