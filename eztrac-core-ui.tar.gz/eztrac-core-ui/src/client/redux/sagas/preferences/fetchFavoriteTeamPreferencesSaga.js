import {call, put as dispatch} from 'redux-saga/effects'
import {getFavoriteTeamsPreference} from '../helpers/preferences'
import actions from '../../actions'

export default function* fetchPreferences() {
    const preferences = yield call(getFavoriteTeamsPreference)

    if (preferences) {
        yield dispatch(actions.setFavoriteTeamsPreference(preferences))
    }
}
