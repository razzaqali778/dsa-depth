import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

export function* fetchPlatforms() {
    const {payload, error} = yield call(get, {
        url: `${coreServicesUrl}/v2/platforms`
    })

    if (error) {
        toastr.error(payload, 'Failed to fetch platforms')
    } else {
        yield dispatch(actions.setPlatforms([...payload]))
    }
}

export default function* () {
    yield takeLatest([actions.fetchPlatforms().type], fetchPlatforms)
}
