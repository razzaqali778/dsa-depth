import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

export function* fetchOrgs() {
    const {payload, error} = yield call(get, {
        url: `${coreServicesUrl}/v2/orgs`
    })

    if (error) {
        toastr.error(payload, 'Failed to fetch orgs')
    } else {
        yield dispatch(actions.setOrgs([...payload]))
    }
}

export default function* () {
    yield takeLatest([actions.fetchOrgs().type], fetchOrgs)
}
