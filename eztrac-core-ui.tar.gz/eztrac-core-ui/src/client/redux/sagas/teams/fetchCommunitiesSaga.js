import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

export function* fetchCommunities() {
    const {payload, error} = yield call(get, {
        url: `${coreServicesUrl}/v2/communities`
    })

    if (error) {
        toastr.error(payload, 'Failed to fetch communities')
    } else {
        yield dispatch(actions.setCommunities([...payload]))
    }
}

export default function* () {
    yield takeLatest([actions.fetchCommunities().type], fetchCommunities)
}
