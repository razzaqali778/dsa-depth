import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import findIndex from 'lodash/findIndex'
import map from 'lodash/map'
import toastr from 'toastr'
import {getIsCreatingTeam, getTeams} from '../../selectors'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import {post, put} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

const getUpdatedTeams = (teams, newTeam) => {
    const {id: teamId} = newTeam
    const index = findIndex(teams, ({id}) => id === teamId)

    if (index === -1) {
        return [...teams, newTeam]
    }

    return map(teams, (team, idx) => {
        if (idx === index) {
            return newTeam
        }

        return team
    })
}

const getOptions = (selecedtTeamId, teamName, communityId, isActive, isCreatingTeam) => {
    if (isCreatingTeam) {
        return {
            verb: post,
            url: `${coreServicesUrl}/v2/team`,
            body: {
                name: teamName,
                isActive,
                communityId
            }
        }
    }

    return {
        verb: put,
        url: `${coreServicesUrl}/v2/team/${selecedtTeamId}`,
        body: {
            id: selecedtTeamId,
            name: teamName,
            isActive,
            communityId
        }
    }
}

export function* saveTeam({payload: savePayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {communityId, isActive, teamName, selectedTeamId} = savePayload
    const isCreatingTeam = yield select(getIsCreatingTeam)

    const {body, verb, url} = getOptions(
        selectedTeamId,
        teamName,
        communityId,
        isActive,
        isCreatingTeam
    )

    const {payload, error} = yield call(verb, {
        url,
        body
    })

    if (!error) {
        const teams = yield select(getTeams)
        const newTeam = {
            ...body,
            id: payload.id
        }
        const updatedTeams = getUpdatedTeams(teams, newTeam)
        const updatedSelectedTeam = {
            id: payload.id,
            name: teamName
        }

        yield dispatch(actions.setTeams(updatedTeams))
        yield dispatch(actions.setSelectedTeam(updatedSelectedTeam))
        yield dispatch(actions.setIsLoading(false))
        yield dispatch(actions.setIsEditing(false))
        yield dispatch(actions.toggleIsCreatingTeam(false))
        toastr.success('Successfully saved team')
    } else {
        yield dispatch(actions.setIsLoading(false))
        toastr.error(makeErrorMsgUserFriendly(payload), 'Failed to save team')
    }
}

export default function* () {
    yield takeLatest([actions.saveTeam().type], saveTeam)
}
