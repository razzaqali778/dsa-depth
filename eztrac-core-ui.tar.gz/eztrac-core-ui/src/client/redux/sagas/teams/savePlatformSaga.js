import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import {post, put} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

export function* savePlatform({payload: savePayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {isActive, name, id, orgId} = savePayload.platform
    const isCreating = savePayload.isCreating
    const url = isCreating
        ? `${coreServicesUrl}/v2/platforms`
        : `${coreServicesUrl}/v2/platforms/${id}`

    const {body, verb} = {
        verb: isCreating ? post : put,
        body: {
            name,
            isActive,
            orgId
        }
    }

    const {payload, error} = yield call(verb, {
        url,
        body
    })

    if (!error) {
        yield dispatch(actions.fetchPlatforms())
        yield dispatch(actions.setIsLoading(false))
        toastr.success('Successfully saved platform')
    } else {
        yield dispatch(actions.setIsLoading(false))
        toastr.error(makeErrorMsgUserFriendly(payload), 'Failed to save platform')
    }
}

export default function* () {
    yield takeLatest([actions.savePlatform().type], savePlatform)
}
