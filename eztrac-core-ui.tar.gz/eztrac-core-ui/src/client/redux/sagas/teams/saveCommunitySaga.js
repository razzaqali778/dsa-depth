import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import {post, put} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

export function* saveCommunity({payload: savePayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {platformId, isActive, name, id} = savePayload.community
    const isCreating = savePayload.isCreating
    const url = isCreating
        ? `${coreServicesUrl}/v2/communities`
        : `${coreServicesUrl}/v2/communities/${id}`

    const {body, verb} = {
        verb: isCreating ? post : put,
        body: {
            name,
            isActive,
            platformId
        }
    }

    const {payload, error} = yield call(verb, {
        url,
        body
    })

    if (!error) {
        yield dispatch(actions.fetchCommunities())
        yield dispatch(actions.setIsLoading(false))
        toastr.success('Successfully saved community')
    } else {
        yield dispatch(actions.setIsLoading(false))
        toastr.error(makeErrorMsgUserFriendly(payload), 'Failed to save community')
    }
}

export default function* () {
    yield takeLatest([actions.saveCommunity().type], saveCommunity)
}
