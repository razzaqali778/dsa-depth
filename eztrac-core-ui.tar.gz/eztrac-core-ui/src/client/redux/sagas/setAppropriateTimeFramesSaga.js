import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import find from 'lodash/find'
import {establishInitialSortOrder} from './helpers/teamInitiatives'
import {
    getSelectedTimeFrameId,
    getSortOrderPreferenceLocal,
    getStartEndSelector
} from '../selectors'
import {getSelectedTimeFrameTeamInitiatives} from '../selectors/initiatives'
import actions from '../actions'
import getRelevantTimeFrames from '../selectors/getRelevantTimeFrames'
import timeFramesActions from '../actions/timeFramesActions'

export function* setAppropriateTimeFrames({payload}) {
    const {chosenTimeFrame, startTimeCode} = payload
    const selectedTeamInitiativesData = yield select(getSelectedTimeFrameTeamInitiatives)
    const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
    const startEndSelector = yield select(getStartEndSelector)

    if (startEndSelector) {
        yield dispatch(
            timeFramesActions.setStartTimeFrame({id: chosenTimeFrame, startCode: startTimeCode})
        )
    } else {
        yield dispatch(
            timeFramesActions.setEndTimeFrame({id: chosenTimeFrame, startCode: startTimeCode})
        )
    }

    const relevantTimeFrames = yield select(getRelevantTimeFrames)

    if (!find(relevantTimeFrames, (timeFrame) => timeFrame.value === selectedTimeFrameId)) {
        yield dispatch(timeFramesActions.setSelectedTimeFrameId(chosenTimeFrame))
        yield dispatch(actions.fetchTeamData())
    }

    const sortOrderPreference = yield select(getSortOrderPreferenceLocal)

    yield dispatch(establishInitialSortOrder(selectedTeamInitiativesData, sortOrderPreference))
}

export default function* () {
    yield takeLatest([actions.setAppropriateTimeFrames().type], setAppropriateTimeFrames)
}
