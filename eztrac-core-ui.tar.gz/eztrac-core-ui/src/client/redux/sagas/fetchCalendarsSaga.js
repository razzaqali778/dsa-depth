import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from './helpers/makeFetchCall'
import {serviceBindings} from './helpers/getServiceBindings'
import actions from '../actions'

const costingServicesUrl = serviceBindings.costingServices

export function* fetchCalendars() {
    const {payload, error} = yield call(get, {
        url: `${costingServicesUrl}/v1/calendars/hours`
    })

    if (error) {
        toastr.error(payload, 'Failed to fetch calendar hours')
    } else {
        yield dispatch(actions.setCalendars(payload))
    }
}

export default function* () {
    yield takeLatest([actions.fetchCalendars().type], fetchCalendars)
}
