import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import {getUserProfileDetails} from './helpers/papi'
import actions from '../actions'

export function* fetchUserProfileDetailsById({payload}) {
    if (!payload?.personId) {
        yield dispatch(actions.setUserProfileDetails({status: 'EMPTY'}))

        return
    }

    yield dispatch(actions.setUserProfileDetails({status: 'LOADING'}))
    const data = yield call(getUserProfileDetails, {userId: payload.personId})
    if (!data) {
        yield dispatch(
            actions.setUserProfileDetails({
                status: 'ERROR'
            })
        )
    } else {
        yield dispatch(
            actions.setUserProfileDetails({
                status: 'OK',
                ...data
            })
        )
    }
}

export default function* () {
    yield takeLatest([actions.fetchUserProfileDetails().type], fetchUserProfileDetailsById)
}
