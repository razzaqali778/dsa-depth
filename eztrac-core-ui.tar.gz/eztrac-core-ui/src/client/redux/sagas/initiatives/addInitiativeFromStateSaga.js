import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {appendTimeFrameId} from '../../utils/newInitiative'
import {establishInitialSortOrder} from '../helpers/teamInitiatives'
import {
    getNewInitiativeData,
    getSelectedTimeFrameTeamInitiatives
} from '../../selectors/initiatives'
import {getSelectedTimeFrameId, getSortOrderPreferenceLocal} from '../../selectors'
import actions from '../../actions'

export function* addNewInitiativeFromState() {
    const newInitiativeData = yield select(getNewInitiativeData)
    const selectedTimeFrameInitiatives = yield select(getSelectedTimeFrameTeamInitiatives)
    const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
    const {value} = newInitiativeData
    const newSelectedTimeFrameInitiatives = [
        ...selectedTimeFrameInitiatives,
        appendTimeFrameId(value, selectedTimeFrameId)
    ]

    const sortOrderPreference = yield select(getSortOrderPreferenceLocal)

    yield dispatch(establishInitialSortOrder(newSelectedTimeFrameInitiatives, sortOrderPreference))
    yield dispatch(actions.clearNewInitiativeData())
}

export default function* () {
    yield takeLatest([actions.addNewInitiativeFromState().type], addNewInitiativeFromState)
}
