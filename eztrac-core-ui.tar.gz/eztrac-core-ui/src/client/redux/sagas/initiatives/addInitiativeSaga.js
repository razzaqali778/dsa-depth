import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import filter from 'lodash/filter'
import {appendTimeFrameId, isSelected} from '../../utils/newInitiative'
import {establishInitialSortOrder} from '../helpers/teamInitiatives'
import {getSelectedTimeFrameId, getSortOrderPreferenceLocal} from '../../selectors'
import {getSelectedTimeFrameTeamInitiatives} from '../../selectors/initiatives'
import actions from '../../actions'

export function* addNewInitiative({payload}) {
    try {
        const selectedTimeFrameInitiatives = yield select(getSelectedTimeFrameTeamInitiatives)
        const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
        const newSelectedTimeFrameInitiatives = [
            ...selectedTimeFrameInitiatives,
            appendTimeFrameId(payload, selectedTimeFrameId)
        ]
        if (isSelected(payload.id, selectedTimeFrameInitiatives)) {
            yield dispatch(
                actions.setSelectedTimeFrameTeamInitiatives(
                    filter(selectedTimeFrameInitiatives, ({id}) => id !== payload.id)
                )
            )
        } else {
            const sortOrderPreference = yield select(getSortOrderPreferenceLocal)

            yield dispatch(
                establishInitialSortOrder(newSelectedTimeFrameInitiatives, sortOrderPreference)
            )
            yield dispatch(actions.clearNewInitiativeData())
        }
    } catch (err) {
        console.error('error in addNewInitiative: ', err)
    }
}

export default function* () {
    yield takeLatest([actions.addNewInitiative().type], addNewInitiative)
}
