import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import includes from 'lodash/includes'
import map from 'lodash/map'
import {getSelectedTimeFrameId} from '../../selectors'
import {getTeamInitiatives} from '../../selectors/initiatives'
import actions from '../../actions'
import getCurrentMonthTimeFrame from '../../selectors/getCurrentMonthTimeFrame'

export function* updateInitiativeErrors() {
    const currentMonthTimeFrame = yield select(getCurrentMonthTimeFrame)
    const teamInitiatives = yield select(getTeamInitiatives)
    const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
    const planningInitiativeError = "Error! Initiatives cannot be 'Planning' in the current month"

    yield dispatch(actions.clearInitiativeErrors())

    if (
        selectedTimeFrameId === currentMonthTimeFrame.id &&
        includes(
            map(
                teamInitiatives,
                (i) => currentMonthTimeFrame.id === i.timeFrameId && i.status === 'Planning'
            ),
            true
        )
    ) {
        yield dispatch(actions.setInitiativeErrors(planningInitiativeError))
    }
}

export default function* () {
    yield takeLatest(
        [
            actions.updateInitiativeErrors().type,
            actions.setTeamCostData().type,
            actions.setSelectedTimeFrameId().type
        ],
        updateInitiativeErrors
    )
}
