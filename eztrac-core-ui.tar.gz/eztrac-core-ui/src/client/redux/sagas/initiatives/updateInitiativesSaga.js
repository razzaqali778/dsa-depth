import {call, put as dispatch, select, takeEvery} from 'redux-saga/effects'
import find from 'lodash/find'
import map from 'lodash/map'
import toastr from 'toastr'
import {getSelectedTeam, getTimeFrames} from '../../selectors'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import {patch} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

const buildUpdateRequest = (teamId, initiativeData) => ({
    verb: patch,
    url: `${coreServicesUrl}/v2/efforts/allocations/team/${teamId}`,
    body: initiativeData,
    headers: {Accept: '*/*'}
})

export function* updateInitiatives({payload: updatePayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {selectedTimeFrameId, selectedTimeFrameInitiatives} = updatePayload
    const selectedTeam = yield select(getSelectedTeam)

    const allocations = map(selectedTimeFrameInitiatives, (initiative) => {
        const {id, teamCostPct} = initiative

        return {initiativeId: id, percentageOfTeamCost: teamCostPct}
    })

    const initiativeData = [
        {
            timeFrameId: selectedTimeFrameId,
            allocations
        }
    ]

    const {body, verb, url, headers} = buildUpdateRequest(selectedTeam.id, initiativeData)

    const {payload, error} = yield call(verb, {
        url,
        body,
        headers
    })

    if (error) {
        yield dispatch(actions.setIsLoading(false))
        const timeFrames = yield select(getTimeFrames)
        const currentSelectedTimeFrame = find(
            timeFrames,
            (timeframe) => selectedTimeFrameId === timeframe.id
        )
        toastr.error(
            makeErrorMsgUserFriendly(payload),
            `Failed to save initiatives for ${currentSelectedTimeFrame.name}`
        )
    } else {
        yield dispatch(actions.fetchTeamData())
        toastr.success('Successfully saved initiatives')
    }
}

export default function* () {
    yield takeEvery([actions.updateInitiatives().type], updateInitiatives)
}
