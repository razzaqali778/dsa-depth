import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import filter from 'lodash/filter'
import sumBy from 'lodash/sumBy'
import {getEndTimeFrame, getSelectedTimeFrameId, getTeamCostData} from '../../selectors'
import {getTeamInitiatives} from '../../selectors/initiatives'
import actions from '../../actions'
import checkForCostData from '../../utils/checkForCostData'
import getCurrentMonthTimeFrame from '../../selectors/getCurrentMonthTimeFrame'
import getTimeFrames from '../takes/getTimeFrames'

export function* updateInitiativeWarnings() {
    const allTimeFrames = yield call(getTimeFrames)
    const currentMonthTimeFrame = yield select(getCurrentMonthTimeFrame)
    const teamInitiatives = yield select(getTeamInitiatives)
    const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
    const teamCostData = yield select(getTeamCostData)
    const endTimeFrame = yield select(getEndTimeFrame)

    yield dispatch(actions.clearInitiativeWarnings())

    const costDataWarning = checkForCostData(
        teamCostData,
        allTimeFrames,
        currentMonthTimeFrame,
        endTimeFrame
    )
    const totalPercentageWarning = 'Warning! Total percent is under 100%'

    const selectedTimeFrameInitiatives = filter(
        teamInitiatives,
        (initiative) => initiative.timeFrameId === selectedTimeFrameId
    )

    const totalPercentage = sumBy(selectedTimeFrameInitiatives, 'teamCostPct')

    if (costDataWarning) {
        yield dispatch(actions.setInitiativeWarnings(costDataWarning))
    }
    if (totalPercentage < 100) {
        yield dispatch(actions.setInitiativeWarnings(totalPercentageWarning))
    }
}

export default function* () {
    yield takeLatest(
        [
            actions.updateInitiativeWarnings().type,
            actions.setTeamCostData().type,
            actions.setSelectedTimeFrameId().type,
            actions.setStartTimeFrame().type,
            actions.setEndTimeFrame().type
        ],
        updateInitiativeWarnings
    )
}
