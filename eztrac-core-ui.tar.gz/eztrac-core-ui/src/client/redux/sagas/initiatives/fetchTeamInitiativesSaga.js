import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {filter, isEmpty} from 'lodash'
import * as Toastr from '../../../components-containers/toastrWrapper'
import {buildInitiativeData, establishInitialSortOrder} from '../helpers/teamInitiatives'
import {getSelectedTimeFrameId, getSortOrderPreferenceLocal} from '../../selectors'
import actions from '../../actions'
import getInitiatives from '../takes/getInitiatives'

export function* fetchTeamInitiatives({payload}) {
    const allInitiatives = yield call(getInitiatives)
    const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
    const sortOrderPreference = yield select(getSortOrderPreferenceLocal)
    if (isEmpty(allInitiatives)) {
        Toastr.popupError('Error loading initiative names')
    } else {
        const initiativeData = buildInitiativeData(allInitiatives, payload)

        yield dispatch(actions.setTeamInitiatives(initiativeData))
        const selectedTeamInitiativesData = filter(
            initiativeData,
            (initiative) => initiative.timeFrameId === selectedTimeFrameId
        )
        yield dispatch(establishInitialSortOrder(selectedTeamInitiativesData, sortOrderPreference))
    }
}

export default function* () {
    yield takeLatest([actions.fetchTeamInitiatives().type], fetchTeamInitiatives)
}
