import {fork} from 'redux-saga/effects'
import addNewForecastedPersonFromStateSagaListener from './people/addNewForecastedPersonFromStateSaga'
import addNewInitiativeFromStateListener from './initiatives/addInitiativeFromStateSaga'
import addNewInitiativeListener from './initiatives/addInitiativeSaga'
import addNewPersonSagaListener from './people/addNewPersonSaga'
import copyInitiativesForwardListener from './initiatives/copyInitiativesForwardSaga'
import copyPeopleForwardListener from './people/copyPeopleForwardSaga'
import createCalculatedEngagementListener from './engagements/createCalculatedEngagementSaga'
import createEngagementListener from './engagements/createEngagementSaga'
import deleteForecastedPersonFromTeamStateSagaListener from './people/deleteForecastedPersonFromTeamStateSaga'
import deletePersonFromTeamStateSagaListener from './people/deletePersonFromTeamStateSaga'
import endEngagementListener from './engagements/endEngagementSaga'
import fetchAllCostGroupsSagaListener from './people/fetchAllCostGroupsSaga'
import fetchAllPeopleSagaListener from './people/fetchAllPeopleSaga'
import fetchAllRatesSagaListener from './people/fetchAllRatesSaga'
import fetchAllTeamEngagementsListener from './engagements/fetchAllTeamEngagementsSaga'
import fetchCalendarsListener from './fetchCalendarsSaga'
import fetchCommunitiesListener from './teams/fetchCommunitiesSaga'
import fetchOrgsListener from './teams/fetchOrgsSaga'
import fetchCurrentUserListener from './fetchCurrentUserSaga'
import fetchEngagementOptionsListener from './engagements/fetchEngagementOptionsSaga'
import fetchFavoriteTeamPreferencesListener from './preferences/fetchFavoriteTeamPreferencesSaga'
import fetchGetExportListener from './fetchGetExportSaga'
import fetchGroupedAndSortedEngagementsListener from './engagements/fetchGroupedAndSortedEngagementsSaga'
import fetchInitiativesListener from './initiatives/fetchInitiativesSaga'
import fetchLastTabPreferencesListener from './preferences/fetchLastTabPreferencesSaga'
import fetchPeopleSortOrderPreference from './preferences/fetchPeopleSortOrderPreferencesSaga'
import fetchPlatformsListener from './teams/fetchPlatformsSaga'
import fetchSortOrderPreferencesListener from './preferences/fetchSortOrderPreferencesSaga'
import fetchTeamCostDataListener from './fetchTeamCostDataSaga'
import fetchTeamDataListener from './fetchTeamDataSaga'
import fetchTeamForecastedPeopleListener from './people/fetchTeamForecastedPeopleSaga'
import fetchTeamInitiativesListener from './initiatives/fetchTeamInitiativesSaga'
import fetchTeamPeopleListener from './people/fetchTeamPeopleSaga'
import fetchTeamsListener from './teams/fetchTeamsSaga'
import fetchTimeFramesListener from './fetchTimeFramesSaga'
import fetchUserProfileDetailsListener from './fetchUserProfileDetailsSaga'

import handleLocationChangeListener from './handleLocationChange'
import handleLocationStateChangeListener from './handleLocationStateChange'
import handleTeamFormListener from './handleTeamForm'
import removeEngagementListener from './engagements/removeEngagementSaga'
import saveTeamListener from './teams/saveTeamSaga'
import saveCommunityListener from './teams/saveCommunitySaga'
import savePlatformSagaListener from './teams/savePlatformSaga'
import setAppropriateTimeFramesListener from './setAppropriateTimeFramesSaga'
import setFavoriteTeamsPreferencesListener from './preferences/setFavoriteTeamsPreferencesSaga'
import updateCalculatedEngagementsListener from './engagements/updateCalculatedEngagementsSaga'
import updateCalculatorListener from './engagements/updateCalculatorSaga'
import updateEngagementListener from './engagements/updateEngagementSaga'
import updateInitiativeErrorsListener from './initiatives/updateInitiativeErrorsSaga'
import updateInitiativeWarningsListener from './initiatives/updateInitiativeWarningsSaga'
import updateInitiativesListener from './initiatives/updateInitiativesSaga'
import updatePeopleListener from './people/updatePeopleSaga'

export default function* sagasMain() {
    yield fork(handleLocationStateChangeListener)
    yield fork(handleLocationChangeListener)
    yield fork(fetchTeamsListener)
    yield fork(fetchCommunitiesListener)
    yield fork(fetchOrgsListener)
    yield fork(fetchPlatformsListener)
    yield fork(fetchFavoriteTeamPreferencesListener)
    yield fork(removeEngagementListener)
    yield fork(handleTeamFormListener)
    yield fork(createEngagementListener)
    yield fork(saveTeamListener)
    yield fork(saveCommunityListener)
    yield fork(savePlatformSagaListener)
    yield fork(setFavoriteTeamsPreferencesListener)
    yield fork(fetchTimeFramesListener)
    yield fork(fetchEngagementOptionsListener)
    yield fork(fetchAllTeamEngagementsListener)
    yield fork(fetchCurrentUserListener)
    yield fork(endEngagementListener)
    yield fork(fetchGroupedAndSortedEngagementsListener)
    yield fork(updateCalculatorListener)
    yield fork(updateEngagementListener)
    yield fork(fetchCalendarsListener)
    yield fork(createCalculatedEngagementListener)
    yield fork(updateCalculatedEngagementsListener)
    yield fork(fetchInitiativesListener)
    yield fork(fetchTeamDataListener)
    yield fork(updateInitiativeWarningsListener)
    yield fork(updateInitiativesListener)
    yield fork(updateInitiativeErrorsListener)
    yield fork(setAppropriateTimeFramesListener)
    yield fork(addNewInitiativeListener)
    yield fork(addNewInitiativeFromStateListener)
    yield fork(copyInitiativesForwardListener)
    yield fork(fetchSortOrderPreferencesListener)
    yield fork(fetchLastTabPreferencesListener)
    yield fork(fetchAllPeopleSagaListener)
    yield fork(deletePersonFromTeamStateSagaListener)
    yield fork(addNewPersonSagaListener)
    yield fork(updatePeopleListener)
    yield fork(deleteForecastedPersonFromTeamStateSagaListener)
    yield fork(fetchAllRatesSagaListener)
    yield fork(fetchAllCostGroupsSagaListener)
    yield fork(addNewForecastedPersonFromStateSagaListener)
    yield fork(fetchPeopleSortOrderPreference)
    yield fork(copyPeopleForwardListener)
    yield fork(fetchTeamInitiativesListener)
    yield fork(fetchTeamPeopleListener)
    yield fork(fetchTeamForecastedPeopleListener)
    yield fork(fetchTeamCostDataListener)
    yield fork(fetchGetExportListener)
    yield fork(fetchUserProfileDetailsListener)
}
