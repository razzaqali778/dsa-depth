import {find, findKey, forEach, map, reverse, sumBy} from 'lodash'
import sortBy from 'lodash/sortBy'
import actions from '../../actions'

const setSortDir = (index, sortOn, selectedTimeFrameTeamInitiatives) => {
    switch (index) {
        case 1:
            return sortOn === 'initiativeName'
                ? actions.setSelectedTimeFrameTeamInitiatives(
                      sortBy(selectedTimeFrameTeamInitiatives, [sortOn])
                  )
                : actions.setSelectedTimeFrameTeamInitiatives(
                      reverse(sortBy(selectedTimeFrameTeamInitiatives, [sortOn]))
                  )
        case 2:
            return sortOn === 'initiativeName'
                ? actions.setSelectedTimeFrameTeamInitiatives(
                      reverse(sortBy(selectedTimeFrameTeamInitiatives, [sortOn]))
                  )
                : actions.setSelectedTimeFrameTeamInitiatives(
                      sortBy(selectedTimeFrameTeamInitiatives, [sortOn])
                  )
        default:
            return actions.setSelectedTimeFrameTeamInitiatives(
                sortBy(selectedTimeFrameTeamInitiatives, ['id'])
            )
    }
}

export const establishInitialSortOrder = (selectedTeamInitiatives, sortOrderPreference) => {
    const {nameNum, allocationNum, costNum} = sortOrderPreference
    const key = findKey(sortOrderPreference, (column) => column !== 0)
    switch (key) {
        case 'nameNum':
            return setSortDir(nameNum, 'initiativeName', selectedTeamInitiatives)

        case 'allocationNum':
            return setSortDir(allocationNum, 'teamCostPct', selectedTeamInitiatives)

        case 'costNum':
            return setSortDir(costNum, 'initiativeCost', selectedTeamInitiatives)

        default:
            return setSortDir(nameNum, 'initiativeName', selectedTeamInitiatives)
    }
}

const getTotalCost = (breakdowns) => sumBy(breakdowns, 'cost')

export const buildInitiativeData = (allInitiatives, fetchCallResults) => {
    const allocationData = []
    forEach(fetchCallResults, ({allocations, timeFrameId, costBreakdowns}) => {
        map(allocations, (allocation) => {
            const matchingInitiative = find(
                allInitiatives,
                (initiative) => initiative.id === allocation.initiativeId
            )

            if (matchingInitiative) {
                allocationData.push({
                    ...matchingInitiative,
                    teamCostPct: allocation.percentageOfTeamCost,
                    initiativeCost: Math.round(
                        getTotalCost(costBreakdowns) * (allocation.percentageOfTeamCost / 100)
                    ),
                    timeFrameId
                })
            }
        })
    })

    return allocationData
}

export const buildTeamCostData = (fetchCallResults) =>
    map(fetchCallResults, (result) => ({
        timeFrameId: result.timeFrameId,
        teamCost: getTotalCost(result.costBreakdowns)
    }))
