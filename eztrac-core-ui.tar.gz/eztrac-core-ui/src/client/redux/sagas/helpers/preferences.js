import preferencesClient from '@bayerit/preferences-client'

const favoriteTeamsClient = preferencesClient('ez-trac', 'favorite-teams')
const sortOrderClient = preferencesClient('ez-trac', 'sort-order')
const lastTabClient = preferencesClient('ez-trac', 'last-tab')
const peopleSortOrderClient = preferencesClient('ez-trac', 'people-sort-order')

export const getFavoriteTeamsPreference = (client = favoriteTeamsClient) =>
    new Promise((resolve) => {
        client.promise().then(() => resolve(client.get()))
    })
export const setFavoriteTeamsPreference = (key, val, client = favoriteTeamsClient) =>
    client.put(key, val)

export const deleteFavoriteTeamsPreference = async (id, client = favoriteTeamsClient) =>
    client.remove(id)

export const getSortOrderPreferenceServer = (client = sortOrderClient) =>
    new Promise((resolve) => {
        client.promise().then(() => resolve(client.get()))
    })
export const setSortOrderPreferenceServer = (key, val, client = sortOrderClient) => {
    client.put(key, val)
}

export const getLastTabPreferenceServer = (client = lastTabClient) =>
    new Promise((resolve) => {
        client.promise().then(() => resolve(client.get()))
    })
export const setLastTabPreferenceServer = (key, val, client = lastTabClient) => {
    client.put(key, val)
}

export const getPeopleSortOrderPreferenceServer = (client = peopleSortOrderClient) =>
    new Promise((resolve) => {
        client.promise().then(() => resolve(client.get()))
    })

export const setPeopleSortOrderPreferenceServer = (key, val, client = peopleSortOrderClient) => {
    client.put(key, val)
}
