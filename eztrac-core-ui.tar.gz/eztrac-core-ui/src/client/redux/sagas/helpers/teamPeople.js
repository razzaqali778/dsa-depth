import {find, findKey, forEach, isEmpty, map, reverse, sortBy} from 'lodash'
import actions from '../../actions'

const setPeopleSortDir = (index, sortOn, selectedTimeFramePeople) => {
    switch (index) {
        case 1:
            return sortOn === 'personName'
                ? actions.setSelectedTimeFrameTeamPeople(sortBy(selectedTimeFramePeople, [sortOn]))
                : actions.setSelectedTimeFrameTeamPeople(
                      reverse(sortBy(selectedTimeFramePeople, [sortOn]))
                  )
        case 2:
            return sortOn === 'personName'
                ? actions.setSelectedTimeFrameTeamPeople(
                      reverse(sortBy(selectedTimeFramePeople, [sortOn]))
                  )
                : actions.setSelectedTimeFrameTeamPeople(sortBy(selectedTimeFramePeople, [sortOn]))
        default:
            return actions.setSelectedTimeFrameTeamPeople(sortBy(selectedTimeFramePeople, ['name']))
    }
}
const setForecastedPeopleSortDir = (index, sortOn, selectedTimeFrameForecastedPeople) => {
    switch (index) {
        case 1:
            return sortOn === 'costGroupId' || sortOn === 'rateId'
                ? actions.setSelectedTimeFrameForecastedPeople(
                      sortBy(selectedTimeFrameForecastedPeople, [sortOn])
                  )
                : actions.setSelectedTimeFrameForecastedPeople(
                      reverse(sortBy(selectedTimeFrameForecastedPeople, [sortOn]))
                  )
        case 2:
            return sortOn === 'costGroupId' || sortOn === 'rateId'
                ? actions.setSelectedTimeFrameForecastedPeople(
                      reverse(sortBy(selectedTimeFrameForecastedPeople, [sortOn]))
                  )
                : actions.setSelectedTimeFrameForecastedPeople(
                      sortBy(selectedTimeFrameForecastedPeople, [sortOn])
                  )
        default:
            return actions.setSelectedTimeFrameForecastedPeople(
                sortBy(selectedTimeFrameForecastedPeople, ['name'])
            )
    }
}

export const establishInitialSortOrderPeople = (
    selectedTeamPeople,
    sortOrderPreferencePeople,
    forecasted
) => {
    const {nameNum, participationNum, numberOfPeopleNum, rateNum, costGroupNum} =
        sortOrderPreferencePeople
    const key = findKey(sortOrderPreferencePeople, (column) => column !== 0)

    if (forecasted) {
        switch (key) {
            case 'costGroupNum':
                return setForecastedPeopleSortDir(costGroupNum, 'costGroupId', selectedTeamPeople)
            case 'numberOfPeopleNum':
                return setForecastedPeopleSortDir(
                    numberOfPeopleNum,
                    'numberOfPeople',
                    selectedTeamPeople
                )
            case 'rateNum':
                return setForecastedPeopleSortDir(rateNum, 'rateId', selectedTeamPeople)
            default:
                return setForecastedPeopleSortDir(costGroupNum, 'costGroupId', selectedTeamPeople)
        }
    } else {
        switch (key) {
            case 'nameNum':
                return setPeopleSortDir(nameNum, 'personName', selectedTeamPeople)
            case 'participationNum':
                return setPeopleSortDir(participationNum, 'participationPct', selectedTeamPeople)
            default:
                return setPeopleSortDir(nameNum, 'personName', selectedTeamPeople)
        }
    }
}

export const buildPeopleData = (allPeople, fetchCallResults) => {
    const allTeamMembers = []
    forEach(fetchCallResults, ({members, timeFrameId}) => {
        map(members, (teamMember) => {
            const matchingPerson = find(
                allPeople,
                (person) => teamMember.userId === person.personId
            )

            if (matchingPerson) {
                allTeamMembers.push({
                    ...matchingPerson,
                    timeFrameId,
                    participationPct: teamMember.percent
                })
            }
        })
    })

    return allTeamMembers
}

export const buildForecastedPeopleData = (fetchCallResults) => {
    const allForecastedPeople = []
    forEach(fetchCallResults, ({forecastPeople, timeFrameId}) => {
        map(forecastPeople, (forecastPerson) => {
            if (!isEmpty(forecastPerson)) {
                allForecastedPeople.push({
                    ...forecastPerson,
                    timeFrameId
                })
            }
        })
    })

    return allForecastedPeople
}
