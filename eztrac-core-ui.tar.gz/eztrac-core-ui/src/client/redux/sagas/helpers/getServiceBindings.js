const serviceUrls = window.phoenix.serviceBindings

export const serviceBindings = {
    coreServices: serviceUrls['ez-trac-core'],
    costingServices: serviceUrls['ez-trac-costing'],
    vipUI: serviceUrls['ez-trac-vip-ui'],
    vipServices: serviceUrls['ez-trac-vip']
}
