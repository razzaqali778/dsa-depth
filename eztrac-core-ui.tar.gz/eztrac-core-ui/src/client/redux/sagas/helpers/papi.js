const serviceBindingUrl = (service) => {
    if (!window.phoenix || !window.phoenix.serviceBindings)
        return console.warn(`Service binding for ${service} not found`)
    if (!service) return console.warn('Service binding not provided')

    return window.phoenix.serviceBindings[service]
}

const userProfileDetailsQuery = `
  query($userId: String!) {
    user: getUserById(id: $userId) {
        id
        preferredName { first last }
        email
        employeeType
        jobTitle
        manager {
            id
            preferredName { full }
        }
    }
} `

export const getUserProfileDetails = async (variables) => {
    const profileUrl = `${serviceBindingUrl('profile-url')}/v3/graphql`
    const response = await fetch(profileUrl, {
        headers: {
            ...(phoenix.authHeader ? phoenix.authHeader() : {}),
            'Content-Type': 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({query: userProfileDetailsQuery, variables})
    })
    const body = await response.json()
    return body.data.user
}
