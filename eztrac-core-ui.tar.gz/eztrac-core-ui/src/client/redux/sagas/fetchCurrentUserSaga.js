import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import {queries, queryProfile} from '@bayerit/profile-client'
import actions from '../actions'

const EZ_TRAC_APP_ID = 'eztrac'

export function* fetchCurrentUser() {
    const currentUserQuery = queries.currentUserWithEntitlements(EZ_TRAC_APP_ID)
    const userProfile = yield call(queryProfile, currentUserQuery)
    yield dispatch(actions.setCurrentUser(userProfile.getCurrentUser))
}

export default function* () {
    yield takeLatest([actions.fetchCurrentUser().type], fetchCurrentUser)
}
