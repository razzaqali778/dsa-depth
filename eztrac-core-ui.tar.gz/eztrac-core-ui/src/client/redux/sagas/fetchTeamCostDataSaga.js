import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {find} from 'lodash'
import {buildTeamCostData} from './helpers/teamInitiatives'
import {getSelectedTimeFrameId} from '../selectors'
import actions from '../actions'

export function* fetchTeamCostData({payload}) {
    const teamCostData = buildTeamCostData(payload)
    const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
    yield dispatch(actions.setTeamCostData(teamCostData))
    const selectedTimeFrameData = find(teamCostData, (tf) => tf.timeFrameId === selectedTimeFrameId)
    yield dispatch(actions.setSelectedTimeFrameTeamCost(selectedTimeFrameData))
}

export default function* () {
    yield takeLatest([actions.fetchTeamCostData().type], fetchTeamCostData)
}
