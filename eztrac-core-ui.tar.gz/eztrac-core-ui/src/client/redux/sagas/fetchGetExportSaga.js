import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import isEmpty from 'lodash/isEmpty'
import map from 'lodash/map'
import toastr from 'toastr'
import {get} from './helpers/makeFetchCall'
import {serviceBindings} from './helpers/getServiceBindings'
import actions from '../actions'
import buildGETCsv from '../utils/buildGETCsv'

const coreServicesUrl = serviceBindings.coreServices

const buildURL = ({timeframe, teams, communityPlatform, downloadAll, region}) => {
    if (downloadAll) {
        return `${coreServicesUrl}/v2/getExport/timeFrameId/${timeframe.id}/all?countryCode=${region}`
    }
    if (isEmpty(teams)) {
        if (communityPlatform.type === 'Platform') {
            return `${coreServicesUrl}/v2/getExport/timeFrameId/${timeframe.id}/platformId/${communityPlatform.value}?countryCode=${region}`
        }

        return `${coreServicesUrl}/v2/getExport/timeFrameId/${timeframe.id}/communityId/${communityPlatform.value}?countryCode=${region}`
    }

    const teamParams = map(teams, (team) => `teamId=${team.value}`)

    return `${coreServicesUrl}/v2/getExport/timeFrameId/${timeframe.id}/teams?countryCode=${region}&${teamParams.join('&')}`
}

export function* fetchGetExport(params) {
    const url = buildURL(params.payload)
    yield dispatch(actions.setIsLoading(true))
    const {payload, error} = yield call(get, {url})
    yield dispatch(actions.setIsLoading(false))
    if (error) {
        toastr.error(payload, 'Failed to fetch teams')
        toastr.error('Error calling GET Export', error)
    } else {
        try {
            if (isEmpty(payload)) {
                toastr.options.timeOut = 0
                toastr.options.extendedTimeOut = 0
                toastr.options.closeButton = true
                toastr.warning('No data found for selected timeframe and teams.')
            }
            const csv = buildGETCsv(payload)
            yield dispatch(actions.setGetCsvDownload(csv))
        } catch (err) {
            console.error('Problem converting GET export payload', err)
            toastr.error('Problem converting GET export payload', err)
        }
    }
}

export default function* () {
    yield takeLatest([actions.fetchGetExport().type], fetchGetExport)
}
