import {put as dispatch, takeLatest} from 'redux-saga/effects'
import actions from '../actions'

export function* handleLocationStateChange({type, payload}) {
    switch (type) {
        case actions.setSelectedTeam().type: {
            if (payload && payload.id) {
                return yield dispatch(actions.updateLocationQuery({teamId: payload.id}))
            }

            return yield dispatch(actions.removeLocationQuery('teamId'))
        }
        case actions.setSelectedTeamTab().type: {
            if (payload) {
                return yield dispatch(actions.updateLocationQuery({teamTab: payload}))
            }

            return yield dispatch(actions.removeLocationQuery('teamTab'))
        }

        default:
            return null
    }
}

export default function* () {
    yield takeLatest(
        [actions.setSelectedTeam().type, actions.setSelectedTeamTab().type],
        handleLocationStateChange
    )
}
