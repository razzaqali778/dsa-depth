import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {buildEndRequest} from './buildEngagementRequests'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import actions from '../../actions'

export function* endEngagement({payload: savePayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {endTimeFrame, engagement, selectedTeam} = savePayload

    const nextMonthTimeFrameIndex =
        engagement.findIndex((tf) => tf.timeFrameId === endTimeFrame) + 1
    const nextMonthTimeFrame = engagement[nextMonthTimeFrameIndex]

    const {body, verb, url} = buildEndRequest(
        selectedTeam.id,
        nextMonthTimeFrame,
        engagement[0].engagementId
    )

    const {payload, error} = yield call(verb, {
        url,
        body
    })

    if (!error) {
        yield dispatch(actions.fetchAllTeamEngagements())
        yield dispatch(actions.setIsLoading(false))
        toastr.success('Successfully saved engagement')
    } else {
        yield dispatch(actions.setIsLoading(false))
        toastr.error(makeErrorMsgUserFriendly(payload), 'Failed to save engagement')
    }
}

export default function* () {
    yield takeLatest([actions.endEngagement().type], endEngagement)
}
