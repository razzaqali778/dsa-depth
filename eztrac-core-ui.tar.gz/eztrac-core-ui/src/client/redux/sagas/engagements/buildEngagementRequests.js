import {del, patch, post} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'

const coreServicesUrl = serviceBindings.coreServices

export const buildCreateRequest = (
    teamId,
    startTimeFrameId,
    endTimeFrameId,
    amount,
    amountType,
    selectedEngagement,
    comment
) => ({
    verb: post,
    url: `${coreServicesUrl}/v2/efforts/engagements`,
    body: {
        teamId,
        startTimeFrameId,
        endTimeFrameId,
        amount,
        amountType,
        engagementId: selectedEngagement,
        comment
    }
})

export const buildCreateCalculatedRequest = (
    teamId,
    startTimeFrameId,
    endTimeFrameId,
    selectedEngagement,
    calendarId,
    rates,
    comment
) => ({
    verb: post,
    url: `${coreServicesUrl}/v2/efforts/engagements/team/${teamId}/timeFrame/${startTimeFrameId}/engagement/${selectedEngagement}/calculated`,
    body: {
        endTimeFrameId,
        engagementCalcInfo: {
            calendarId,
            rates
        },
        comment
    }
})

export const buildUpdateRequest = (
    teamId,
    timeFrameId,
    amount,
    selectedEngagement,
    isUpdatingAll,
    comment
) => ({
    verb: patch,
    url: `${coreServicesUrl}/v2/efforts/engagements/team/${teamId}/timeFrame/${timeFrameId}/engagement/${selectedEngagement}?all=${isUpdatingAll}`,
    body: {
        amount,
        comment
    }
})

export const buildUpdateCalculatedRequest = (
    teamId,
    timeFrameId,
    selectedEngagement,
    calendarId,
    rates,
    isUpdatingAll,
    comment,
    amountDetails
) => ({
    verb: patch,
    url: `${coreServicesUrl}/v2/efforts/engagements/team/${teamId}/timeFrame/${timeFrameId}/engagement/${selectedEngagement}/calculated?all=${isUpdatingAll}`,
    body: {
        calcInfo: amountDetails || {
            calendarId,
            rates
        },
        comment
    }
})

export const buildRemoveRequest = (teamId, engagementId, selectedTimeFrameId) => ({
    verb: del,
    url: `${coreServicesUrl}/v2/efforts/engagements/team/${teamId}/timeFrame/${selectedTimeFrameId}/engagement/${engagementId}`,
    body: {
        teamId,
        timeFrameId: selectedTimeFrameId,
        engagementId
    }
})

export const buildEndRequest = (teamId, nextMonthTimeFrame, engagementId) => ({
    verb: del,
    url: `${coreServicesUrl}/v2/efforts/engagements/team/${teamId}/timeFrame/${nextMonthTimeFrame.timeFrameId}/engagement/${engagementId}`,
    body: {
        teamId,
        timeFrameId: nextMonthTimeFrame.timeFrameId,
        engagementId
    }
})
