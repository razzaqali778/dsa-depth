import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import map from 'lodash/map'
import toastr from 'toastr'
import {DEFAULT_RATE_CALENDAR} from '../../constants/utilConstants'
import {buildUpdateCalculatedRequest} from './buildEngagementRequests'
import {getCalculatorRows, getSelectedRateCalendar} from '../../selectors/engagements'
import {getSelectedTeam} from '../../selectors'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import actions from '../../actions'

export function* updateCalculatedEngagements({payload: updatePayload}) {
    yield dispatch(actions.setIsLoading(true))

    const {selectedTimeFrameId, selectedEngagementId, isUpdatingAll, comment, amountDetails} =
        updatePayload
    const selectedTeam = yield select(getSelectedTeam)
    const calculatorRows = yield select(getCalculatorRows)
    const selectedCalendarId = yield select(getSelectedRateCalendar)
    const rates = map(calculatorRows, (row) => ({
        people: Number(row.people),
        hourlyRate: Number(row.hourlyRate),
        comment: row.comment
    }))

    const {body, verb, url} = buildUpdateCalculatedRequest(
        selectedTeam.id,
        selectedTimeFrameId,
        selectedEngagementId,
        selectedCalendarId,
        rates,
        isUpdatingAll,
        comment,
        amountDetails
    )

    const {payload, error} = yield call(verb, {
        url,
        body
    })

    if (error) {
        yield dispatch(actions.setIsLoading(false))
        toastr.error(makeErrorMsgUserFriendly(payload), 'Failed to save engagement')
    } else {
        yield dispatch(actions.setIsLoading(false))
        yield dispatch(actions.setIsEditingEngagement(false))
        yield dispatch(actions.fetchAllTeamEngagements())
        yield dispatch(actions.setSelectedCalendar(DEFAULT_RATE_CALENDAR))
        yield dispatch(actions.clearCalculatorRows())
        yield dispatch(actions.setTotalEngagementCost(null))
        yield dispatch(actions.setIsCalculating({timeFrameId: null, engagementId: null}))
        toastr.success('Successfully saved engagement')
    }
}

export default function* () {
    yield takeLatest([actions.updateCalculatedEngagements().type], updateCalculatedEngagements)
}
