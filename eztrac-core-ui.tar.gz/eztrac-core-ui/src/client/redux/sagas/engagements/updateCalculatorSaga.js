import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import find from 'lodash/find'
import now from 'lodash/now'
import sumBy from 'lodash/sumBy'
import actions from '../../actions'
import {
    getCalculatorRows,
    getCalendarHours,
    getSelectedRateCalendar
} from '../../selectors/engagements'

export function* updateCalculator({payload}) {
    const {
        hourlyRate,
        numberOfPeople,
        comment,
        selectedTimeFrameId,
        rowToRemove,
        isRemoving,
        timeStamp
    } = payload

    if (isRemoving) {
        yield dispatch(actions.removeCalculatorRow(rowToRemove))
    } else {
        const calendarHours = yield select(getCalendarHours)
        const selectedCalendarId = yield select(getSelectedRateCalendar)
        const selectedCalendarTimeFrame = find(
            calendarHours,
            (calendarItem) =>
                calendarItem.timeFrameId === selectedTimeFrameId &&
                calendarItem.calendarId === selectedCalendarId
        )
        const cost =
            Number(hourlyRate) *
            Number(numberOfPeople) *
            Number(selectedCalendarTimeFrame.contractorHours)

        if (timeStamp) {
            yield dispatch(
                actions.updateCalculatorRow({
                    people: numberOfPeople,
                    hourlyRate,
                    startingCost: cost,
                    comment,
                    timeStamp
                })
            )
        } else {
            yield dispatch(
                actions.addCalculatorRow({
                    people: numberOfPeople,
                    hourlyRate,
                    startingCost: cost,
                    comment,
                    timeStamp: now()
                })
            )
        }
    }

    const calculatorRows = yield select(getCalculatorRows)
    yield dispatch(actions.setTotalEngagementCost(sumBy(calculatorRows, 'startingCost')))
}

export default function* () {
    yield takeLatest([actions.updateCalculator().type], updateCalculator)
}
