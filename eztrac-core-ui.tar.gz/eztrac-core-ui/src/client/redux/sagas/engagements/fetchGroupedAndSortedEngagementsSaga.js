import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import actions from '../../actions'
import getGroupedAndSortedEngagements from '../../selectors/engagements/getGroupedAndSortedEngagements'

export function* fetchGroupedAndSortedEngagements() {
    const groupedAndSortedEngagements = yield select(getGroupedAndSortedEngagements)

    yield dispatch(actions.setGroupedAndSortedEngagements(groupedAndSortedEngagements))
}

export default function* () {
    yield takeLatest(
        [actions.fetchGroupedAndSortedEngagements().type, actions.setAllTeamEngagements().type],
        fetchGroupedAndSortedEngagements
    )
}
