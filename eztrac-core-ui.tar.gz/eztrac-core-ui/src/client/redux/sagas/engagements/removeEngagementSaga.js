import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {buildRemoveRequest} from './buildEngagementRequests'
import {getSelectedTeam} from '../../selectors'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import actions from '../../actions'

export function* removeEngagement({payload: removePayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {currentEngagement} = removePayload
    const selectedTeam = yield select(getSelectedTeam)

    const {body, verb, url} = buildRemoveRequest(
        selectedTeam.id,
        currentEngagement.engagementId,
        currentEngagement.timeFrameId
    )
    const {payload, error} = yield call(verb, {
        url,
        body
    })

    if (!error) {
        yield dispatch(actions.fetchAllTeamEngagements())
        yield dispatch(actions.setIsLoading(false))
        toastr.success('Successfully ended engagement')
    } else {
        yield dispatch(actions.setIsLoading(false))
        toastr.error(makeErrorMsgUserFriendly(payload), 'Failed to end engagement')
    }
}

export default function* () {
    yield takeLatest([actions.removeEngagement().type], removeEngagement)
}
