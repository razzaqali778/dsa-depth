import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {buildCreateRequest} from './buildEngagementRequests'
import {getTotalEngagementCost} from '../../selectors/engagements'
import {getSelectedTeam} from '../../selectors'
import actions from '../../actions'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'

export function* createEngagement({payload: createPayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {
        selectedStartTimeFrameId,
        selectedEndTimeFrameId,
        selectedEngagementId,
        engagementCost,
        comment
    } = createPayload
    const amountUnparsed = engagementCost || (yield select(getTotalEngagementCost))
    const amount =
        typeof amountUnparsed === 'string'
            ? parseInt(amountUnparsed.replace(/[,]/g, ''), 10)
            : amountUnparsed

    const selectedTeam = yield select(getSelectedTeam)
    const amountType = 'Monthly'

    const {body, verb, url} = buildCreateRequest(
        selectedTeam.id,
        selectedStartTimeFrameId,
        selectedEndTimeFrameId,
        amount,
        amountType,
        selectedEngagementId,
        comment
    )

    const {payload, error} = yield call(verb, {
        url,
        body
    })

    if (!error) {
        yield dispatch(actions.fetchAllTeamEngagements())
        yield dispatch(actions.setIsLoading(false))
        yield dispatch(actions.toggleIsCreatingEngagement(false))
        toastr.success('Successfully saved engagement')
    } else {
        yield dispatch(actions.setIsLoading(false))
        toastr.error(makeErrorMsgUserFriendly(payload), 'Failed to save engagement')
    }
}

export default function* () {
    yield takeLatest([actions.createEngagement().type], createEngagement)
}
