import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {buildUpdateRequest} from './buildEngagementRequests'
import {getSelectedTeam} from '../../selectors'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import actions from '../../actions'

export function* updateEngagement({payload: updatePayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {selectedEngagementId, selectedTimeFrameId, engagementCost, isUpdatingAll, comment} =
        updatePayload
    const amount =
        typeof engagementCost === 'string'
            ? parseInt(engagementCost.replace(/[$,]/g, ''), 10)
            : engagementCost
    const selectedTeam = yield select(getSelectedTeam)

    const {body, verb, url} = buildUpdateRequest(
        selectedTeam.id,
        selectedTimeFrameId,
        amount,
        selectedEngagementId,
        isUpdatingAll,
        comment
    )

    const {payload, error} = yield call(verb, {
        url,
        body
    })

    if (error) {
        yield dispatch(actions.setIsLoading(false))
        toastr.error(makeErrorMsgUserFriendly(payload), 'Failed to save engagement')
    } else {
        yield dispatch(actions.fetchAllTeamEngagements())
        yield dispatch(actions.setIsLoading(false))
        yield dispatch(actions.setIsEditingEngagement(false))
        toastr.success('Successfully saved engagement')
    }
}

export default function* () {
    yield takeLatest([actions.updateEngagement().type], updateEngagement)
}
