import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import map from 'lodash/map'
import toastr from 'toastr'
import {DEFAULT_RATE_CALENDAR} from '../../constants/utilConstants'
import {buildCreateCalculatedRequest} from './buildEngagementRequests'
import {getCalculatorRows, getSelectedRateCalendar} from '../../selectors/engagements'
import {getSelectedTeam} from '../../selectors'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import actions from '../../actions'

export function* createCalculatedEngagement({payload: calculatedPayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {
        selectedStartTimeFrameId,
        selectedEndTimeFrameId,
        selectedEngagementId,
        amountDetails,
        comment
    } = calculatedPayload
    const selectedTeam = yield select(getSelectedTeam)
    let selectedCalendarId
    let rates
    if (amountDetails) {
        ;({rates, calendarId: selectedCalendarId} = amountDetails)
    } else {
        const calculatorRows = yield select(getCalculatorRows)
        selectedCalendarId = yield select(getSelectedRateCalendar)
        rates = map(calculatorRows, (row) => ({
            people: Number(row.people),
            hourlyRate: Number(row.hourlyRate),
            comment: row.comment
        }))
    }

    const {body, verb, url} = buildCreateCalculatedRequest(
        selectedTeam.id,
        selectedStartTimeFrameId,
        selectedEndTimeFrameId,
        selectedEngagementId,
        selectedCalendarId,
        rates,
        comment
    )
    const result = yield call(verb, {url, body})

    if (result.error) {
        yield dispatch(actions.setIsLoading(false))
        toastr.error(
            makeErrorMsgUserFriendly(result.error.payload),
            'Warning: an error has occurred'
        )
    } else {
        yield dispatch(actions.setIsLoading(false))
        yield dispatch(actions.fetchAllTeamEngagements())
        yield dispatch(actions.toggleIsCreatingEngagement(false))
        yield dispatch(actions.setSelectedCalendar(DEFAULT_RATE_CALENDAR))
        toastr.success('Successfully saved engagement')
    }
}

export default function* () {
    yield takeLatest([actions.createCalculatedEngagement().type], createCalculatedEngagement)
}
