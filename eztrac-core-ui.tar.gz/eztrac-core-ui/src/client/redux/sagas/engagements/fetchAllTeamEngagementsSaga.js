import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../helpers/makeFetchCall'
import {getSelectedTeam} from '../../selectors'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

export function* fetchAllTeamEngagements() {
    const selectedTeam = yield select(getSelectedTeam)

    if (selectedTeam) {
        const {payload, error} = yield call(get, {
            url: `${coreServicesUrl}/v2/efforts/engagements/team/${selectedTeam.id}`
        })

        if (error) {
            toastr.error(payload, 'Failed to fetch engagements')
        } else {
            yield dispatch(actions.setAllTeamEngagements(payload))
        }
    }
}

export default function* () {
    yield takeLatest(
        [
            actions.fetchAllTeamEngagements().type,
            actions.setSelectedTeam().type,
            actions.setSelectedTeamFromUrl().type
        ],
        fetchAllTeamEngagements
    )
}
