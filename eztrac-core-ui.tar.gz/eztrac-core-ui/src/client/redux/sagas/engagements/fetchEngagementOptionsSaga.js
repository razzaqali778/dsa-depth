import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import {get} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const costingServicesUrl = serviceBindings.costingServices

export function* fetchEngagementOptions() {
    const {payload, error} = yield call(get, {
        url: `${costingServicesUrl}/v1/engagements`
    })

    if (error) {
        toastr.error(payload, 'Failed to fetch engagement options')
    } else {
        yield dispatch(actions.setEngagementOptions(payload))
    }
}

export default function* () {
    yield takeLatest([actions.fetchEngagementOptions().type], fetchEngagementOptions)
}
