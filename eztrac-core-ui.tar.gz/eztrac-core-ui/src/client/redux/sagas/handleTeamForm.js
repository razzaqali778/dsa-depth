import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import find from 'lodash/find'
import {getIsCreatingTeam, getSelectedTeam, getTeams} from '../selectors'
import actions from '../actions'

export function* handleTeamForm() {
    const {id: selectedId, name} = yield select(getSelectedTeam)
    const teams = yield select(getTeams)
    const isCreatingTeam = yield select(getIsCreatingTeam)
    const {
        name: teamName,
        communityId,
        isActive
    } = isCreatingTeam
        ? {name, isActive: true, communityId: null}
        : find(teams, ({id}) => id === selectedId) || {}

    yield dispatch(actions.setFormTeamName(teamName))
    yield dispatch(actions.setFormCommunityId(communityId))
    yield dispatch(actions.setFormIsActive(isActive))
}

export default function* () {
    yield takeLatest(
        [actions.setIsEditing().type, actions.toggleIsCreatingTeam().type],
        handleTeamForm
    )
}
