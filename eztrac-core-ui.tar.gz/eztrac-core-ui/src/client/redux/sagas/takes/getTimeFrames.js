import {select, take} from 'redux-saga/effects'
import actions from '../../actions'

function* getTimeFrames() {
    const timeFrames = yield select((state) => state.timeFrame.timeFrames)

    if (timeFrames.length === 0) {
        yield take(actions.setTimeFrames().type)

        return yield select((state) => state.timeFrame.timeFrames)
    }

    return timeFrames
}

export default getTimeFrames
