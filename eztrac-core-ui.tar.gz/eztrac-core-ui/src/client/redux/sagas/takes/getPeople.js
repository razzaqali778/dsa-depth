import {select, take} from 'redux-saga/effects'
import actions from '../../actions'

function* getPeople() {
    const people = yield select((state) => state.people.people)

    if (people.length === 0) {
        yield take(actions.setPeople().type)

        return yield select((state) => state.people.people)
    }

    return people
}

export default getPeople
