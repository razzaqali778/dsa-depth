import {select, take} from 'redux-saga/effects'
import actions from '../../actions'

function* getInitiatives() {
    const initiatives = yield select((state) => state.initiative.allInitiatives)

    if (initiatives.length === 0) {
        yield take(actions.setInitiatives().type)

        return yield select((state) => state.initiative.allInitiatives)
    }

    return initiatives
}

export default getInitiatives
