import {put as dispatch, select, takeEvery} from 'redux-saga/effects'
import filter from 'lodash/filter'
import {getTeamPeople} from '../../selectors/people'
import actions from '../../actions'

export function* copyPeopleForward({payload}) {
    const teamPeople = yield select(getTeamPeople)
    const {copyForwardFromTimeFrame, copyForwardToTimeFrame} = payload
    const peopleToBeCopied = filter(
        teamPeople,
        (person) => person.timeFrameId === copyForwardFromTimeFrame
    )
    yield dispatch({
        payload: {
            selectedTimeFrameId: copyForwardToTimeFrame,
            peopleToBeCopied
        },
        type: actions.updatePeople().type
    })
}

export default function* () {
    yield takeEvery([actions.copyPeopleForward().type], copyPeopleForward)
}
