import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import uniqBy from 'lodash/uniqBy'
import {get} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const costingServicesUrl = serviceBindings.costingServices

export function* fetchAllRates() {
    const {payload, error} = yield call(get, {
        url: `${costingServicesUrl}/v1/rates`
    })
    if (error) {
        toastr.error(payload, 'Failed to fetch rates')
    } else {
        yield dispatch(actions.setRates(uniqBy(payload, 'id')))
    }
}

export default function* () {
    yield takeLatest([actions.fetchRates().type], fetchAllRates)
}
