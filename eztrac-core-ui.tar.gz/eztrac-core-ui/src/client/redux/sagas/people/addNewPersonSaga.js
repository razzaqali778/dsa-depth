import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import isEmpty from 'lodash/isEmpty'
import toastr from 'toastr'
import {appendTimeFrameId} from '../../utils/newInitiative'
import {establishInitialSortOrderPeople} from '../helpers/teamPeople'
import {getSelectedTimeFrameId, getSortOrderPreferencePeopleLocal} from '../../selectors'
import {getSelectedTimeFrameTeamPeople} from '../../selectors/people'
import actions from '../../actions'

export function* addNewPerson({payload}) {
    try {
        const selectedTimeFrameTeamPeople = yield select(getSelectedTimeFrameTeamPeople)
        const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
        const newSelectedTimeFrameTeamPeople = [
            ...selectedTimeFrameTeamPeople,
            appendTimeFrameId(payload, selectedTimeFrameId)
        ]
        if (!isEmpty(payload)) {
            const sortOrderPreferencePeople = yield select(getSortOrderPreferencePeopleLocal)
            yield dispatch(
                establishInitialSortOrderPeople(
                    newSelectedTimeFrameTeamPeople,
                    sortOrderPreferencePeople,
                    false
                )
            )
        } else {
            console.error('error in addNewPerson')
        }
    } catch (err) {
        console.error('error in addNewPerson: ', err)
        toastr.error('Person not found')
    }
}

export default function* () {
    yield takeLatest([actions.addNewPerson().type], addNewPerson)
}
