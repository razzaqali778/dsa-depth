import {call, put as dispatch, select, takeEvery} from 'redux-saga/effects'
import {find, map} from 'lodash'
import toastr from 'toastr'
import {getSelectedTeam, getTimeFrames} from '../../selectors'
import {
    getSelectedTimeFrameForecastedPeople,
    getSelectedTimeFrameTeamPeople
} from '../../selectors/people'
import {makeErrorMsgUserFriendly} from '../../../utils/errorDisplayHelper'
import {patch} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const coreServicesUrl = serviceBindings.coreServices

export function* updatePeople({payload: updatePayload}) {
    yield dispatch(actions.setIsLoading(true))
    const {selectedTimeFrameId, copyForwardToTimeFrame} = updatePayload
    const selectedTimeFrameTeamPeople = yield select(getSelectedTimeFrameTeamPeople)
    const selectedTimeFrameForecastedPeople = yield select(getSelectedTimeFrameForecastedPeople)
    const selectedTeam = yield select(getSelectedTeam)
    const timeFrameIdsToUpdate = copyForwardToTimeFrame
        ? map(copyForwardToTimeFrame, 'id')
        : [selectedTimeFrameId]

    const teamMembers = map(selectedTimeFrameTeamPeople, (person) => {
        const {personId, participationPct} = person

        return {userId: personId, percent: participationPct}
    })
    const forecastedTeamMembers = map(selectedTimeFrameForecastedPeople, (forecastedPerson) => {
        const {costGroupId, numberOfPeople, rateId} = forecastedPerson

        // it might be worth doing a check if type coercion is successful
        return {costGroupId, numberOfPeople: Number(numberOfPeople), rateId}
    })

    const {payload, error} = yield call(patch, {
        url: `${coreServicesUrl}/v2/efforts/members/team/${selectedTeam.id}`,
        body: {
            specificPeople: teamMembers,
            genericPeople: forecastedTeamMembers,
            timeFrameIds: timeFrameIdsToUpdate
        },
        headers: {Accept: '*/*'}
    })

    if (error) {
        yield dispatch(actions.setIsLoading(false))
        const timeFrames = yield select(getTimeFrames)
        const currentSelectedTimeFrame = find(
            timeFrames,
            (timeframe) => selectedTimeFrameId === timeframe.id
        )
        toastr.error(
            makeErrorMsgUserFriendly(payload),
            `Failed to save people for ${currentSelectedTimeFrame.name}`
        )
    } else {
        yield dispatch(actions.fetchTeamData())
        toastr.success('Successfully saved people')
    }
}

export default function* () {
    yield takeEvery([actions.updatePeople().type], updatePeople)
}
