import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {filter} from 'lodash'
import {buildForecastedPeopleData, establishInitialSortOrderPeople} from '../helpers/teamPeople'
import {getSelectedTimeFrameId, getSortOrderPreferencePeopleLocal} from '../../selectors'
import actions from '../../actions'

export function* fetchTeamForecastedPeople({payload}) {
    const forecastedPeopleData = buildForecastedPeopleData(payload)
    const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
    const sortOrderPreferencePeopleLocal = yield select(getSortOrderPreferencePeopleLocal)

    const selectedForecastedTeamPeopleData = filter(
        forecastedPeopleData,
        (forecastedPerson) => forecastedPerson.timeFrameId === selectedTimeFrameId
    )

    yield dispatch(actions.setTeamForecastedPeople(forecastedPeopleData))

    yield dispatch(
        establishInitialSortOrderPeople(
            selectedForecastedTeamPeopleData,
            sortOrderPreferencePeopleLocal,
            true
        )
    )
}

export default function* () {
    yield takeLatest([actions.fetchTeamForecastedPeople().type], fetchTeamForecastedPeople)
}
