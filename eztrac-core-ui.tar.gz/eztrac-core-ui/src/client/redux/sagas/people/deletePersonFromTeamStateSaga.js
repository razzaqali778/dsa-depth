import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {filter} from 'lodash'
import {getSelectedTimeFrameTeamPeople} from '../../selectors/people'
import {isPersonSelected} from '../../utils/newInitiative'
import actions from '../../actions'

export function* deletePersonFromTeamState({payload}) {
    try {
        const selectedTimeFrameTeamPeople = yield select(getSelectedTimeFrameTeamPeople)

        if (isPersonSelected(payload.personId, selectedTimeFrameTeamPeople)) {
            yield dispatch(
                actions.setSelectedTimeFrameTeamPeople(
                    filter(
                        selectedTimeFrameTeamPeople,
                        ({personId}) => personId !== payload.personId
                    )
                )
            )
        }
    } catch (err) {
        console.error('error in deletePersonFromTeamState: ', err)
    }
}
export default function* () {
    yield takeLatest([actions.deletePersonFromTeamState().type], deletePersonFromTeamState)
}
