import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {filter, isEmpty} from 'lodash'
import * as Toastr from '../../../components-containers/toastrWrapper'
import {buildPeopleData, establishInitialSortOrderPeople} from '../helpers/teamPeople'
import {getSelectedTimeFrameId, getSortOrderPreferencePeopleLocal} from '../../selectors'
import actions from '../../actions'
import getPeople from '../takes/getPeople'

export function* fetchTeamPeople({payload}) {
    const allPeople = yield call(getPeople)
    const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
    const sortOrderPreferencePeopleLocal = yield select(getSortOrderPreferencePeopleLocal)

    if (isEmpty(allPeople)) {
        Toastr.popupError('Error loading people')
    } else {
        const peopleData = buildPeopleData(allPeople, payload)
        yield dispatch(actions.setTeamPeople(peopleData))

        const selectedTeamPeopleData = filter(
            peopleData,
            (person) => person.timeFrameId === selectedTimeFrameId
        )
        yield dispatch(
            establishInitialSortOrderPeople(
                selectedTeamPeopleData,
                sortOrderPreferencePeopleLocal,
                false
            )
        )
    }
}
export default function* () {
    yield takeLatest([actions.fetchTeamPeople().type], fetchTeamPeople)
}
