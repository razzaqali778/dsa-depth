import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {appendTimeFrameId} from '../../utils/newInitiative'
import {establishInitialSortOrderPeople} from '../helpers/teamPeople'
import {
    getNewForecastedPersonData,
    getSelectedTimeFrameForecastedPeople
} from '../../selectors/people'
import {getSelectedTimeFrameId, getSortOrderPreferencePeopleLocal} from '../../selectors'
import actions from '../../actions'

export function* addNewForecastedPersonFromState() {
    const newForecastedPersonData = yield select(getNewForecastedPersonData)
    const selectedTimeFrameId = yield select(getSelectedTimeFrameId)
    const selectedTimeFrameForecastedPeople = yield select(getSelectedTimeFrameForecastedPeople)
    const newSelectedTimeFrameForecastedPeople = [
        ...selectedTimeFrameForecastedPeople,
        appendTimeFrameId(newForecastedPersonData, selectedTimeFrameId)
    ]
    const sortOrderPreferencePeople = yield select(getSortOrderPreferencePeopleLocal)
    yield dispatch(
        establishInitialSortOrderPeople(
            newSelectedTimeFrameForecastedPeople,
            sortOrderPreferencePeople,
            true
        )
    )
    yield dispatch(actions.clearNewForecastedPersonData())
}
export default function* () {
    yield takeLatest(
        [actions.addNewForecastedPersonFromState().type],
        addNewForecastedPersonFromState
    )
}
