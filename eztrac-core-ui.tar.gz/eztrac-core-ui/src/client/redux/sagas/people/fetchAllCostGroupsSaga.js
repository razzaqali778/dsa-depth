import {call, put as dispatch, takeLatest} from 'redux-saga/effects'
import toastr from 'toastr'
import uniqBy from 'lodash/uniqBy'
import {get} from '../helpers/makeFetchCall'
import {serviceBindings} from '../helpers/getServiceBindings'
import actions from '../../actions'

const costingServicesUrl = serviceBindings.costingServices

export function* fetchAllCostGroups() {
    const {payload, error} = yield call(get, {
        url: `${costingServicesUrl}/v1/costGroups`
    })
    if (error) {
        toastr.error(payload, 'Failed to fetch cost groups')
    } else {
        yield dispatch(actions.setCostGroups(uniqBy(payload, 'id')))
    }
}

export default function* () {
    yield takeLatest([actions.fetchCostGroups().type], fetchAllCostGroups)
}
