import {put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {filter} from 'lodash'
import {getSelectedTimeFrameForecastedPeople} from '../../selectors/people'
import {isForecastedPersonSelected} from '../../utils/newInitiative'
import actions from '../../actions'

export function* deleteForecastedPersonFromTeamState({payload}) {
    try {
        const selectedTimeFrameForecastedPeople = yield select(getSelectedTimeFrameForecastedPeople)

        if (isForecastedPersonSelected(payload, selectedTimeFrameForecastedPeople)) {
            yield dispatch(
                actions.setSelectedTimeFrameForecastedPeople(
                    filter(
                        selectedTimeFrameForecastedPeople,
                        (person) =>
                            person.rateId + person.costGroupId !==
                            payload.rateId + payload.costGroupId
                    )
                )
            )
        }
    } catch (err) {
        console.error('error in deleteForecastedPersonFromTeamState: ', err)
    }
}
export default function* () {
    yield takeLatest(
        [actions.deleteForecastedPersonFromTeamState().type],
        deleteForecastedPersonFromTeamState
    )
}
