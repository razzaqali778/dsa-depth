import {call, put as dispatch, select, takeLatest} from 'redux-saga/effects'
import {head, last} from 'lodash'
import * as Toastr from '../../components-containers/toastrWrapper'
import * as makeFetchCall from './helpers/makeFetchCall'
import {getSelectedTeam} from '../selectors'
import {serviceBindings} from './helpers/getServiceBindings'
import actions from '../actions'
import getTimeFrameRange from '../utils/getTimeFrameRange'
import getTimeFrames from './takes/getTimeFrames'

const coreServicesUrl = serviceBindings.coreServices

export function* fetchTeamData() {
    yield dispatch(actions.setIsLoading(true))
    const selectedTeam = yield select(getSelectedTeam)

    if (selectedTeam.id) {
        const allTimeFrames = yield call(getTimeFrames)
        const timeFrameDisplayArray = getTimeFrameRange(allTimeFrames)
        const startTimeFrameId = head(timeFrameDisplayArray).id
        const endTimeFrameId = last(timeFrameDisplayArray).id

        const {payload, error} = yield call(makeFetchCall.get, {
            url: `${coreServicesUrl}/v2/efforts/full/team/${selectedTeam.id}?startTimeFrame=${startTimeFrameId}&endTimeFrame=${endTimeFrameId}`
        })

        if (error) {
            Toastr.popupError('Failed to fetch team initiatives')
        } else {
            yield dispatch(actions.fetchTeamInitiatives(payload))
            yield dispatch(actions.fetchTeamPeople(payload))
            yield dispatch(actions.fetchTeamForecastedPeople(payload))
            yield dispatch(actions.fetchTeamCostData(payload))
        }
    }
    yield dispatch(actions.setIsLoading(false))
}

export default function* () {
    yield takeLatest(
        [
            actions.fetchTeamData().type,
            actions.setSelectedTeam().type,
            actions.setSelectedTeamFromUrl().type
        ],
        fetchTeamData
    )
}
