import {put as dispatch, select, take, takeLatest} from 'redux-saga/effects'
import find from 'lodash/find'
import includes from 'lodash/includes'
import toLower from 'lodash/toLower'
import actions from '../actions'

// example handler for a query var changing
// Call this in handleLocationChange with a yield
// Only dispatches action if value in query param changed
// function* handleThing(val) {
//   if ( val ) {
//     const cur = yield select(state => state.data)
//     if ( !isEqual(val, cur) ) {
//       yield dispatch(actions.someAction(val))
//     }
//   }
// }

export function* getTeams() {
    const teams = yield select((state) => state.team.teams)

    if (teams.length === 0) {
        yield take(actions.setTeams().type)

        return yield select((state) => state.team.teams)
    }

    return teams
}

export function* handleLocationChange({payload}) {
    const {query, pathname, firstLoad} = payload
    const {teamId, teamTab} = query
    if (includes(pathname, 'team') && firstLoad) {
        yield dispatch(actions.setLocation({query, pathname}))
        yield dispatch(actions.fetchTimeFrames())
        yield dispatch(actions.fetchTeams())
        yield dispatch(actions.fetchCommunities())
        yield dispatch(actions.fetchPlatforms())
        yield dispatch(actions.fetchOrgs())
        yield dispatch(actions.fetchEngagementOptions())
        yield dispatch(actions.fetchCalendars())
        yield dispatch(actions.fetchInitiatives())
        yield dispatch(actions.fetchPeople())
        yield dispatch(actions.fetchRates())
        yield dispatch(actions.fetchCostGroups())
        yield take(actions.setTimeFrames().type)

        if (teamId) {
            const teams = yield getTeams()
            const selectedTeam = find(teams, ({id}) => id === teamId)

            yield dispatch(actions.setSelectedTeamFromUrl(selectedTeam))
        }

        if (teamTab) {
            yield dispatch(actions.setSelectedTeamTab(teamTab))
        }
    } else if (includes(toLower(pathname), 'getexport') && firstLoad) {
        yield dispatch(actions.fetchTimeFrames())
        yield dispatch(actions.fetchTeams())
        yield dispatch(actions.fetchCommunities())
        yield dispatch(actions.fetchPlatforms())
    } else if (includes(toLower(pathname), 'platforms') && firstLoad) {
        yield dispatch(actions.fetchOrgs())
        yield dispatch(actions.fetchPlatforms())
        yield dispatch(actions.fetchCommunities())
    } else if (includes(toLower(pathname), 'communities') && firstLoad) {
        yield dispatch(actions.fetchCommunities())
        yield dispatch(actions.fetchPlatforms())
        yield dispatch(actions.fetchTeams())
    }
}

export default function* () {
    yield takeLatest([actions.updateLocation().type], handleLocationChange)
}
