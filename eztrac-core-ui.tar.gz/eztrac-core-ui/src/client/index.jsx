import './service-bindings'
import {Provider} from 'react-redux'
import {RMWCProvider} from '@rmwc/provider'
import {Route, BrowserRouter as Router} from 'react-router-dom'
import {enableAuthTokenSupport, getAuthHeader} from '@bayerit/profile-client'
import React from 'react'
import ReactDOM from 'react-dom'
import navbar from '@monsantoit/phoenix-navbar'
import AppContainer from './components-containers/app/AppContainer'
import makeReduxStore from './redux'
import pkg from '../../package.json'

import '@rmwc/data-table/data-table.css'

import reducers from './redux/reducers'

navbar.install(
    {
        element: document.querySelector('.nav'),
        suiteId: 'pe-admin',
        productId: 'ez-trac',
        cookieName: 'ez-trac',
        React,
        ReactDOM
    },
    pkg
)
async function startup() {
    const basename = '/ez-trac-core'
    await enableAuthTokenSupport()
    getAuthHeader()

    const store = makeReduxStore(reducers)

    ReactDOM.render(
        <div>
            <Provider store={store}>
                <RMWCProvider>
                    <Router basename={basename}>
                        <Route component={(props) => <AppContainer {...props} />} />
                    </Router>
                </RMWCProvider>
            </Provider>
        </div>,
        document.querySelector('.contents')
    )
}

startup()
