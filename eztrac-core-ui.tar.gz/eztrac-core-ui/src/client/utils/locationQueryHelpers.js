import concat from 'lodash/concat'
import find from 'lodash/find'
import includes from 'lodash/includes'
import reduce from 'lodash/reduce'
import uniq from 'lodash/uniq'

const findDiff = (oldSearch, newSearch) => {
    const allKeys = uniq(concat(Object.keys(oldSearch), Object.keys(newSearch)))

    return reduce(
        allKeys,
        (memo, key) => {
            if (!oldSearch[key]) {
                memo.toAdd.push(`${key}=${newSearch[key]}`)
            } else if (!newSearch[key]) {
                memo.toRemove.push(`${key}=${oldSearch[key]}`)
            } else if (oldSearch[key] !== newSearch[key]) {
                memo.toUpdate.push({
                    oldValue: `${key}=${oldSearch[key]}`,
                    newValue: `${key}=${newSearch[key]}`
                })
            }

            return memo
        },
        {toAdd: [], toRemove: [], toUpdate: []}
    )
}

export const updateQuery = (oldSearch, newSearch, query) => {
    const {toAdd, toRemove, toUpdate} = findDiff(oldSearch, newSearch)

    const queryList = query.replace(/\?/g, '').split('&')

    const newList = reduce(
        queryList,
        (memo, val) => {
            if (includes(toRemove, val)) {
                return memo
            }

            const updateVal = find(toUpdate, ({oldValue}) => oldValue === val)

            if (updateVal) {
                memo.push(updateVal.newValue)
            } else {
                memo.push(val)
            }

            return memo
        },
        []
    )

    return [...newList, ...toAdd].join('&').replace(/^&/, '')
}
