import {clone, reverse, sortBy} from 'lodash'

export const setSorting = (
    setSortOrderLocal,
    setTableData,
    tableData,
    index,
    key,
    sortOn,
    currentTableSort
) => {
    const tableSort = clone(currentTableSort)
    const isString = typeof tableData[0][sortOn]
    if (index === 2) {
        tableSort[key] = 1
    } else {
        tableSort[key] = (index + 1) % 3
    }
    setSortOrderLocal(tableSort)

    switch (index) {
        case 1:
            return isString === 'string'
                ? setTableData(reverse(sortBy(tableData, [sortOn])))
                : setTableData(sortBy(tableData, [sortOn]))
        default:
            return isString === 'string'
                ? setTableData(sortBy(tableData, [sortOn]))
                : setTableData(reverse(sortBy(tableData, [sortOn])))
    }
}
