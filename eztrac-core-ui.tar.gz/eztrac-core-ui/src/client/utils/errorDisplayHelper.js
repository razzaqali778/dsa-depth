export const makeErrorMsgUserFriendly = (msg) =>
    msg && msg.includes && msg.includes('CertPathValidatorException')
        ? 'Please repeat your action'
        : msg
