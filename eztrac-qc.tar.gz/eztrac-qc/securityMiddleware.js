const { createRedirectToRestrictedPageAction, createProfileMiddleware } = require('@monsantoit/profile-middleware')

const READ_ROLE = 'eztrac-read-user'
const READ_WRITE_ROLE = 'eztrac-write-user'
const ADMIN_ROLE = 'eztrac-admin-user'

const localDevProfile = {
  id: process.env.USER || 'MSKEMM',
  entitlements: { 'ez-trac': [ READ_ROLE, READ_WRITE_ROLE, ADMIN_ROLE ] },
}

const unauthorizedRedirect =
  createRedirectToRestrictedPageAction('ez-trac-qc&roles=eztrac-read-user or eztrac-write-user')
const unauthorizedResponse = (req, res) =>
  res.status(403).json('Unauthorized')
const unauthorizedAction = (req, res, next) => {
  if ( req.path.includes('services') ) {
    return unauthorizedResponse(req, res, next)
  }

  return unauthorizedRedirect(req, res, next)
}

const writeSecurityMiddleware = createProfileMiddleware({
  localDevProfile,
  entitlements: [ READ_WRITE_ROLE, ADMIN_ROLE ],
  unauthorizedAction,
  methods: [ 'put', 'post', 'delete' ],
})

const readSecurityMiddleware = createProfileMiddleware({
  localDevProfile,
  entitlements: [ READ_ROLE, READ_WRITE_ROLE, ADMIN_ROLE ],
  unauthorizedAction,
  methods: [ 'get' ],
})

module.exports = { writeSecurityMiddleware, readSecurityMiddleware }
