export const value = (functionOrValue = null) => typeof functionOrValue === 'function' ? value(functionOrValue()) : functionOrValue

export const velocityNamespace = () => (typeof window !== 'undefined' ? window.phoenix || {} : {})

export const authHeader = () => value(velocityNamespace().authHeader) || {}

export const serviceBinding = service => {
  if ( window.phoenix && window.phoenix.serviceBindings && service ) {
    return window.phoenix.serviceBindings[service]
  }
  const message = !service
    ? 'Service binding not provided.'
    : `Service binding for '${service}' not found.`
  console.warn(`Velocity Get: ${message}`)

  return null
}
