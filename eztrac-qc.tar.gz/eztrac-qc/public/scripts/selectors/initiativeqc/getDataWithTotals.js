import { createSelector } from 'reselect'
import map from 'lodash/map'
import orderBy from 'lodash/orderBy'
import reduce from 'lodash/reduce'
import {
  getInitiativeIssues, getSortBy, getSortOrder, getTeamStructure,
} from '.'

export const getData = createSelector(
  getInitiativeIssues,
  getSortBy,
  getSortOrder,
  getTeamStructure,
  (initiativeIssues, sortBy, sortOrder, teamStructure) => {
    const sortedInitiatives = orderBy(initiativeIssues, [ sortBy ], [ sortOrder ])

    return map(sortedInitiatives, issue => ({
      ...issue,
      allocations: orderBy(
        issue.allocations,
        [ ({ status }) => status.toLowerCase() === 'funded', 'name' ],
        [ 'asc', 'asc' ],
      ),
      platformId: teamStructure.find(t => t.teamId === issue.teamId).platformId,
      communityId: teamStructure.find(t => t.teamId === issue.teamId).communityId,
    }))
  },
)

export const getTotals = createSelector(
  getInitiativeIssues,
  initiativeIssues => map(initiativeIssues, issue => ({
    ...issue,
    allocations: [
      {
        percentageOfTeamCost: '', initiativeId: '', status: '', name: '',
      },
      reduce(issue.allocations, (memo, val) => {
        memo.percentageOfTeamCost += val.status.toLowerCase() !== 'funded' // eslint-disable-line no-param-reassign
          ? val.percentageOfTeamCost
          : 0

        return memo
      }, {
        percentageOfTeamCost: 0, initiativeId: '', status: 'Not Funded', name: 'Total',
      }),
      reduce(issue.allocations, (memo, val) => {
        memo.percentageOfTeamCost += val.status.toLowerCase() === 'funded' // eslint-disable-line no-param-reassign
          ? val.percentageOfTeamCost
          : 0

        return memo
      }, {
        percentageOfTeamCost: 0, initiativeId: '', status: 'Funded', name: 'Total',
      }),
    ],
  })),
)
