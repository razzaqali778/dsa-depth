export const getInitiativeIssues = state => state.initiativeIssues
export const getSortOrder = state => state.sortOrder
export const getSortBy = state => state.sortBy
export const getTeamStructure = state => state.teamStructure
export const getPlatforms = state => state.getPlatforms
export const getCommunities = state => state.getCommunities
