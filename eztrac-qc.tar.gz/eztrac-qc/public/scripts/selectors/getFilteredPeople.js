import { createSelector } from 'reselect'
import reject from 'lodash/reject'
import { filterPeople } from '../Util/tableFilterUtil'
import { filterUnderUserId, getManagerHierarchy } from '../Util/buttonFilterUtil'

const getTotalPeople = state => state.totalPeopleDiscrepancies
const getAllPeople = state => state.allPeople
const getShowReasons = state => state.showReasons
export const getShowUnderUserFlag = state => state.showUnderUserFlag || state.showUnderMeFlag
export const getShowUnderUserField = state => state.showUnderUserFlag
  ? state.showUnderUserSearchField || ''
  : state.userId || ''

const getSearchText = state => state.searchText

const getTextFilteredPeople = createSelector(getTotalPeople, getSearchText, ( fullList, searchText ) => filterPeople(searchText, fullList))

const getReasonFilteredPeople = createSelector(getTextFilteredPeople, getShowReasons, ( people, showReasons ) => showReasons ? people : reject(people, ({ reason }) => reason))

const getSubordinates = createSelector(getShowUnderUserField, getAllPeople, ( showUnderUserField, people ) => getManagerHierarchy(showUnderUserField, people))

const getFilteredUnderManagerPeople = createSelector(
  getReasonFilteredPeople,
  getShowUnderUserFlag,
  getShowUnderUserField,
  getSubordinates,
  ( people, showUnderFlag, showUnderField, subordinates ) => showUnderFlag ? filterUnderUserId(showUnderField, people, subordinates) : people,
)

export const getFilteredPeople = createSelector(getFilteredUnderManagerPeople, people => people)


export default getFilteredPeople
