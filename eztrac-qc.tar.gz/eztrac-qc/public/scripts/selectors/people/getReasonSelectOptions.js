import { createSelector } from 'reselect'
import flow from 'lodash/flow'
import map from 'lodash/fp/map'
import sortBy from 'lodash/sortBy'
import {
  getReasons,
} from '.'

const getReasonSelectOptions = createSelector(getReasons, reasons => flow(
  sortBy(({ reasonName }) => reasonName),
  map(({ reasonName }) => ({ label: reasonName, value: reasonName })),
)(reasons))

export default getReasonSelectOptions
