export const getTotalPeople = state => state.totalPeopleDiscrepancies
export const getAllPeople = state => state.allPeople
export const getInactivePeopleWithReasons = state => state.inactivePeopleWithReasons
export const getShowReasons = state => state.showReasons
export const getShowUnderUserFlag = state => state.showUnderUserFlag || state.showUnderMeFlag
export const getShowUnderUserField = state => state.showUnderUserFlag ? state.showUnderUserSearchField : state.userId
export const getSearchText = state => state.searchText
export const getArchiveMonth = state => state.archiveMonth
export const getSelectedTimeframe = state => state.selectedTimeframe
export const getReasons = state => state.reasons
