import { createSelector } from 'reselect'
import reduce from 'lodash/reduce'
import { getReasons } from '.'

const getReasonSelectOptions = createSelector(getReasons, reasons => reduce(reasons, (memo, { reasonName, description }) => {
  memo[reasonName] = description // eslint-disable-line no-param-reassign

  return memo
}, {}))

export default getReasonSelectOptions
