import { createSelector } from 'reselect'
import {
  getArchiveMonth,
  getSelectedTimeframe,
} from '.'

const selector = createSelector(
  getArchiveMonth,
  getSelectedTimeframe,
  (archiveMonth, selectedTimeframe) => archiveMonth.id === selectedTimeframe.id,
)

export default selector
