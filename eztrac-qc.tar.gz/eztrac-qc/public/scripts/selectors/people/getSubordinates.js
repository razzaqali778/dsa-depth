import { createSelector } from 'reselect'
import {
  getAllPeople,
  getShowUnderUserField,
} from '.'
import { getManagerHierarchy } from '../../Util/buttonFilterUtil'

const getSubordinates = createSelector(getShowUnderUserField, getAllPeople, ( showUnderUserField, people ) => getManagerHierarchy(showUnderUserField, people))


export default getSubordinates
