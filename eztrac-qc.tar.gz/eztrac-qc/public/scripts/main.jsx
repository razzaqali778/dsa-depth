import React from 'react'
import ReactDOM from 'react-dom'
import navbar from '@monsantoit/phoenix-navbar'
import RootContainer from './RootContainer'

const render = Container => {
  ReactDOM.render(
    <div className="root">
      <Container />
    </div>,
    document.querySelector('.contents'),
  )
}

navbar.install({
  element: document.querySelector('.nav'),
  suiteId: 'pe-admin',
  productId: 'ez-trac',
  cookieName: 'ez-trac-qc',
})
  .then(() => {
    // eslint-disable-next-line global-require
    render(RootContainer)
  })
  .catch(err => {
    // Errors thrown as part of installation will likely be from invalid
    // auth tokens. Be sure to run a local ocelot instance to avoid this.
    console.error(err)
  })

if ( module.hot ) {
  module.hot.accept('./RootContainer', () => {
    const NextContainer = require('./RootContainer').default // eslint-disable-line global-require

    render(NextContainer)
  })
}
