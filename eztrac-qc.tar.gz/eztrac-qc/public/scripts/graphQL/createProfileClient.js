const { createClient } = require('@monsantoit/apollo-graphql-client-factory').web
const { serviceBinding } = require('../windowUtils')

const createProfileClient = () => createClient(`${serviceBinding('profile-url')}/v3/graphql`)

export default createProfileClient
