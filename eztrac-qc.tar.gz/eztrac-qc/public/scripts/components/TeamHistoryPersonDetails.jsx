import React, { useState, useEffect } from 'react'
import { fetchUserDetails } from './utils/personDetailsUtils'

const notFound = 'unknown'

const createEmailLink = emailAddress => <a href={`mailto:${emailAddress}`}>{emailAddress}</a>

const renderDetails = userData => userData || notFound

const renderJobDetails = (employeeType, jobTitle) => employeeType.toUpperCase() === 'CONTRACTOR' ? employeeType : renderDetails(jobTitle)

const renderEmail = email => email ? createEmailLink(email) : notFound

const renderManagerDetails = (managerId, managerName, managerUrl) => managerId
  ? (
    <span>
      <a href={managerUrl}>{managerName}</a>
      <span className="italic">
        {' '}
        (
        {managerId}
        )
      </span>
    </span>
  ) : notFound

const renderUserDetailsBox = ({
  selectedPersonId, cwid, name, url, mCwid, mName, mUrl, employeeType, jobTitle, email, costGroup,
}) => {
  if ( cwid !== selectedPersonId ) {
    return (
      <div className="col-md-2">
        <div className="person-details-container">
          <p className="error">
            Cannot find user with id
            {selectedPersonId}
            {' '}
            in profile API
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="col-md-2">
      <div className="person-details-container">
        <div className="person-details">
          <p>
            <a href={url}>{name}</a>
            <span className="italic">
              {' '}
              (
              {cwid}
              )
            </span>
          </p>
        </div>
        <div className="person-details">
          <span className="bold">Manager: </span>
          <span>{renderManagerDetails(mCwid, mName, mUrl)}</span>
        </div>
        <div className="person-details">
          <span className="bold">Title: </span>
          <span>{renderJobDetails(employeeType, jobTitle)}</span>
        </div>
        <div className="person-details">
          <span className="bold">Email: </span>
          <span>{renderEmail(email)}</span>
        </div>
        <div className="person-details">
          <span className="bold">Cost Group: </span>
          <span>{renderDetails(costGroup)}</span>
        </div>
      </div>
    </div>
  )
}

export default function PersonDetailsComponent({ selectedPersonId }) {
  const [ userDetails, setUserDetails ] = useState({})
  const [ loading, setLoading ] = useState(true)

  useEffect(() => {
    setLoading(true)
    fetchUserDetails()
      .then(response => {
        setUserDetails(response)
        setLoading(false)
      })
      .catch(error => {
        console.log(error)
      })
  }, [ selectedPersonId ])

  const {
    id: cwid, name, url, managerId: mCwid, managerName: mName, managerUrl: mUrl,
    employeeType, jobTitle, email, costGroup,
  } = userDetails

  return (
    loading
      ? (
        <div className="col-md-2">
          <div className="velocity-spinner-container">
            <i className="velocity-spinner-small-inline" />
            <span>Loading user details...</span>
          </div>
        </div>
      )
      : renderUserDetailsBox({
        selectedPersonId,
        cwid,
        name,
        url,
        mCwid,
        mName,
        mUrl,
        employeeType,
        jobTitle,
        email,
        costGroup,
      })
  )
}
