import {
  Button, Col, Modal, Row,
} from 'react-bootstrap'
import React from 'react'
import PeopleSearch from './PeopleSearch'

class ShowUnderManagerModal extends React.Component {
  constructor( props ) {
    super(props)
    this.timer = null
  }

  render() {
    return (
      <Modal onHide={this.props.close} show={this.props.show}>
        <Modal.Header closeButton>
          <Modal.Title>Show Under ...</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Row>
            <Col sm={10}>
              <PeopleSearch
                allPeople={this.props.allPeople}
                onChange={({ userId }) => this.props.onChange(userId)}
              />
            </Col>
            <Col sm={2}>
              <Button onClick={() => { this.props.searchForUnderUser() }}>Search</Button>
            </Col>
          </Row>
        </Modal.Body>
      </Modal>
    )
  }
}

export default ShowUnderManagerModal
