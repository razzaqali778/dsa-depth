import React from 'react'
import { Button } from 'react-bootstrap'
import sortBy from 'lodash/sortBy'
import { getAllPeople } from '../Util/Network/papiPeopleUtil'
import { getCurrentTimeframe } from '../Util/Network/timeframeUtil'
import { makeDeactivateUrl } from '../Util/Network/deactivatePersonUtil'
import LoadingBlocker from './LoadingBlocker'
import Navbar from './Navbar'
import PeopleSearch from './PeopleSearch'
import {
  fetchAmountOfTimeframesForUserAndTimeframeId, getStorage, setStorage,
  DEACTIVATE_BUTTON_TEXT, possibleTimeframeStatuses, reasonNames,
} from './utils/teamUtils'
import TeamList from './TeamList'
import PersonDetailsComponent from './TeamHistoryPersonDetails'
import { TeamHistoryPath } from './routes'

class TeamHistory extends React.Component {
  constructor( props ) {
    super(props)
    this.state = {
      allPeople: [],
      selectedPerson: JSON.parse(getStorage('selectedPerson')) || {},
      previousTeams: [],
      loading: false,
      availableTimeframes: {},
      currentTimeframe: {},
      selectedPersonId: '',
    }
    this.onNameSelected = this.onNameSelected.bind(this)
    this.changeYearButtonClick = this.changeYearButtonClick.bind(this)
  }

  componentWillMount() {
    this.mounting()
  }

  async onNameSelected( person ) {
    const currentDate = new Date()

    if ( !person ) {
      return this.setState({
        previousTeams: [],
        pickedYear: currentDate.getFullYear(),
        availableTimeframes: [],
        selectedPerson: {},
        selectedPersonId: '',
      })
    }

    setStorage('selectedPerson', JSON.stringify(person))

    const selectedPerson = typeof person === 'string' ? JSON.parse(person) : person

    this.setState({ previousTeams: [], loading: true })
    const currentTimeframe = await getCurrentTimeframe()
    const selectedPersonId = selectedPerson.userId

    const teams = await fetchAmountOfTimeframesForUserAndTimeframeId(selectedPersonId, currentTimeframe.id, currentDate.getMonth() + 1)
    const futureTeams = await fetchAmountOfTimeframesForUserAndTimeframeId(selectedPersonId, currentTimeframe.id, currentDate.getMonth() - 12)
      .then(fTeams => fTeams
        .map(team => ({ ...team, status: possibleTimeframeStatuses.Forecasted })))

    const allTeams = teams.concat(futureTeams.slice(1))

    return this.setState({
      selectedPersonId,
      previousTeams: allTeams,
      loading: false,
      availableTimeframes: { [currentDate.getFullYear()]: allTeams },
      pickedYear: currentDate.getFullYear(),
      currentTimeframe,
    })
  }

  async mounting() {
    this.setState({ loading: true })
    const allPeople = await getAllPeople()
    if ( this.state.selectedPerson ) { this.onNameSelected(this.state.selectedPerson) }
    this.setState({ allPeople, loading: false })
  }

  async changeYearButtonClick(year) {
    if ( year === this.state.pickedYear ) return
    this.setState({ pickedYear: year })

    let data = this.state.availableTimeframes[year]

    if ( !data ) {
      this.setState({ previousTeamsLoading: true })
      const firstTimeframeIdOfNewYear = (this.state.availableTimeframes[year + 1] || [])[0].timeframe.id
      if ( !firstTimeframeIdOfNewYear ) return
      data = await fetchAmountOfTimeframesForUserAndTimeframeId(this.state.selectedPersonId, firstTimeframeIdOfNewYear, 13)
        .then(timeframes => timeframes.slice(1).reverse())

      this.setState({
        availableTimeframes: {
          ...this.state.availableTimeframes,
          [year]: data,
        },
      })
    }

    this.setState({
      previousTeamsLoading: false,
      previousTeams: data,
    })
  }

  showDeactivateButton() {
    const person = this.state.allPeople.find(p => p.userId === this.state.selectedPersonId)
    if ( !person || !person.isActive ) return null

    return (
      <Button
        className="deactivateButton"
        onClick={() => {
          setStorage('deactivatePrevSite', TeamHistoryPath)
          window.location.href = makeDeactivateUrl(this.state.selectedPersonId, reasonNames.LeftPE, 3)
        }}
        type="button"
      >
        {DEACTIVATE_BUTTON_TEXT}
      </Button>
    )
  }

  showPersonDetails() {
    if ( !this.state.selectedPersonId ) return null

    return <PersonDetailsComponent selectedPersonId={this.state.selectedPersonId} />
  }

  render() {
    return (
      <div>
        <LoadingBlocker isLoading={this.state.loading} />
        <div className="row navComponent">
          <div className="col-md-9 col-md-offset-2">
            <Navbar />
          </div>
        </div>
        <div className="row row-padding">
          <div className="col-md-4 col-md-offset-1">
            <h3>Previous Team History</h3>
          </div>
        </div>
        <div className="row row-padding">
          <div className="col-md-4 col-md-offset-1">
            <PeopleSearch
              allPeople={sortBy(this.state.allPeople, [ 'userId' ])}
              onChange={this.onNameSelected}
            />
          </div>
          {this.showPersonDetails()}
          <div className="col-md-2">
            {this.showDeactivateButton()}
          </div>
        </div>
        <div className="row row-padding">
          <div className="col-md-10 col-md-offset-1">
            <TeamList
              currentTimeframe={this.state.currentTimeframe}
              onChangeYearClick={this.changeYearButtonClick}
              pickedYear={this.state.pickedYear}
              previousTeams={this.state.previousTeams}
              previousTeamsLoading={this.state.previousTeamsLoading}
              selectedPersonId={this.state.selectedPersonId}
            />
          </div>
        </div>
      </div>
    )
  }
}

export default TeamHistory
