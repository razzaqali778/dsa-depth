import { Button, ButtonGroup } from 'react-bootstrap'
import React from 'react'

const TimeframeButtons = ({
  archiveMonth,
  archiveMonthButtonPressed,
  timeframes,
  selectedTimeframe,
  timeFrameButtonPressed,
}) => timeframes && timeframes.length > 0 ? (
  <div className="timeframe-buttons">
    <ButtonGroup className="timeFrameButtonGroup row-padding">
      {archiveMonth ? (
        <Button
          bsStyle={selectedTimeframe === archiveMonth ? 'primary' : 'default'}
          onClick={() => archiveMonthButtonPressed(archiveMonth)}
        >
          {archiveMonth.name}
        </Button>
      ) : null}
      {timeframes.map(tF => (
        <Button
          bsStyle={selectedTimeframe === tF ? 'primary' : 'default'}
          key={tF.id}
          onClick={() => timeFrameButtonPressed(tF)}
        >
          {tF.name}
        </Button>
      ))}
    </ButtonGroup>
  </div>
) : null

export default TimeframeButtons
