import React from 'react'

const TimeframeLockedWarning = ({ isLocked }) => isLocked
  ? (
    <div>
      <h4 className="locked-warning">This Timeframe Is Locked</h4>
    </div>
  )
  : null

export default TimeframeLockedWarning
