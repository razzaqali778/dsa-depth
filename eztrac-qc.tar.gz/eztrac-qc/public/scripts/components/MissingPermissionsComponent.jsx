import React from 'react'

const entitlementUrl = window.phoenix.serviceBindings['ez-trac-entitlements']

const MissingPermissionsComponent = () => (
  <div>
    <div className="row">
      <div className="col-md-8 col-md-offset-3">
        <h1>You do not have access to EZ-QC</h1>
      </div>
    </div>
    <div className="row">
      <div className="col-md-4 col-md-offset-4">
        <h4>
          Please
          <a href={entitlementUrl}>request</a>
          {' '}
          the proper entitlements.
        </h4>
      </div>
    </div>
  </div>
)

export default MissingPermissionsComponent
