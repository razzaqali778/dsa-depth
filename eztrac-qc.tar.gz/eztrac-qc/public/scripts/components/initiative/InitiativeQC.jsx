import { Glyphicon, OverlayTrigger, Tooltip } from 'react-bootstrap'
import { createSink } from 'recompose'
import AutoSizer from 'react-virtualized/dist/commonjs/AutoSizer/'
import Grid from 'react-virtualized/dist/commonjs/Grid/'
import React from 'react'
import Select from 'react-select'
import isEmpty from 'lodash/isEmpty'
import map from 'lodash/map'
import { getCurrentAndNextTimeframes } from '../../Util/Network/timeframeUtil'
import { getData, getTotals } from '../../selectors/initiativeqc/getDataWithTotals'
import { getInitiativeIssues } from '../../Util/Network/initiativeUtil'
import { getTeamStructure, getPlatforms, getCommunities } from '../../Util/Network/teamStructureUtil'
import LoadingBlocker from '../LoadingBlocker'
import Navbar from '../Navbar'
import TimeframeButtons from '../TimeframeButtons'

const peadminEzTracHome = window.phoenix.serviceBindings['peadmin-ez-trac-home']
const vipUrl = window.phoenix.serviceBindings['vip-ui']
let header
let body

const makeSink = ref => createSink((v => () => {
  if ( v ) {
    try {
      v.recomputeGridSize()
    } catch ( err ) {
      console.error(err) // eslint-disable-line no-console
    }
  }
})(ref))

const updateInitiativeIssues = (initiativeIssues, teamStructure) => initiativeIssues.map(issue => {
  const { teamId } = issue
  const { platformId, communityId } = teamStructure.find(t => t.teamId === teamId)

  return { ...issue, platformId, communityId }
})

const createSelectFilter = (selected, selectName, onChangeHandler, options, placeholder) => (
  <Select
    className="filter-select"
    defaultValue={selected}
    multi
    name={selectName}
    onChange={onChangeHandler}
    options={options}
    placeholder={placeholder}
    value={selected}
  />
)

class InitiativeQC extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      timeframes: [],
      initiativeIssues: [],
      sortOrder: 'asc',
      sortBy: 'Team',
      loading: true,
      teamStructure: [],
      platforms: [],
      allCommunities: [],
      communities: [],
      selectedPlatforms: [],
      selectedCommunities: [],
    }
    this.timeFrameButtonPressed = this.timeFrameButtonPressed.bind(this)
    this.handlePlatformChange = this.handlePlatformChange.bind(this)
    this.handleCommunityChange = this.handleCommunityChange.bind(this)
  }

  async componentDidMount() {
    const timeframes = await getCurrentAndNextTimeframes()
    const initiativeIssues = await getInitiativeIssues(timeframes[0].id)
    const teamStructure = await getTeamStructure()
    const mappedPlatforms = await getPlatforms()
      .then(platforms => platforms.map(p => ({ value: p.id, label: p.name })))
    const mappedCommunities = await getCommunities()
      .then(communities => communities.map(c => ({ value: c.id, platformId: c.platformId, label: c.name })))

    const updatedInitiativeIssues = updateInitiativeIssues(initiativeIssues, teamStructure)
    this.loadIntoState(
      timeframes[0],
      timeframes,
      teamStructure,
      mappedPlatforms,
      mappedCommunities,
      updatedInitiativeIssues,
    )
  }

  async loadIntoState(currentTimeframe, timeframes, teamStructure, platforms, communities, initiativeIssues) {
    this.setState({
      currentTimeframe,
      timeframes,
      initiativeIssues,
      loading: 0,
      teamStructure,
      platforms,
      allCommunities: communities,
      communities,
    })
  }

  async timeFrameButtonPressed(timeframe) {
    this.setState({ loading: true })
    const initiativeIssues = await getInitiativeIssues(timeframe.id)
    const updatedInitiativeIssues = updateInitiativeIssues(initiativeIssues, this.state.teamStructure)
    this.setState({ currentTimeframe: timeframe, initiativeIssues: updatedInitiativeIssues, loading: false })
    if ( !isEmpty(this.state.selectedCommunities) ) {
      this.handleCommunityChange(this.state.selectedCommunities, this.state.selectedPlatforms)
    } else if ( !isEmpty(this.state.selectedPlatforms) ) {
      this.handlePlatformChange(this.state.selectedPlatforms)
    }
  }

  changeCommunityAvailability(selectedPlatforms) {
    const selectedPlatformsIds = selectedPlatforms.map(p => (p.value))
    const filteredCommunities = this.state.allCommunities
      .filter(c => selectedPlatformsIds.some(id => id === c.platformId))
    this.setState({ communities: filteredCommunities })
  }

  handlePlatformChange(selectedPlatforms) {
    this.setState({ selectedPlatforms })
    if ( isEmpty(selectedPlatforms) ) {
      this.setState({ communities: this.state.allCommunities })
      this.handleCommunityChange([], [])

      return
    }
    this.changeCommunityAvailability(selectedPlatforms)
    if ( isEmpty(this.state.selectedCommunities) ) {
      this.filterIssuesBySelection('platformId', selectedPlatforms)

      return
    }
    const selectedPlatformsIds = selectedPlatforms.map(p => (p.value))
    const compatibleOptions = this.state.selectedCommunities
      .filter(c => selectedPlatformsIds.some(id => id === c.platformId))
    this.handleCommunityChange(compatibleOptions, [])
    if ( isEmpty(compatibleOptions) ) {
      this.filterIssuesBySelection('platformId', selectedPlatforms)
    }
  }

  handleCommunityChange(selectedCommunities, selectedPlatforms) {
    this.setState({ selectedCommunities })
    if ( isEmpty(selectedCommunities) ) {
      this.filterIssuesBySelection('platformId', selectedPlatforms)

      return
    }
    this.filterIssuesBySelection('communityId', selectedCommunities)
  }

  async filterIssuesBySelection(propName, selection) {
    const initiativeIssues = await getInitiativeIssues(this.state.currentTimeframe.id)
    const updatedInitiativeIssues = updateInitiativeIssues(initiativeIssues, this.state.teamStructure)

    if ( isEmpty(selection) ) {
      this.setState({ initiativeIssues: updatedInitiativeIssues })
    } else {
      const filteredIssues = updatedInitiativeIssues
        .filter(issue => selection.some(obj => issue[propName] === obj.value))
      this.setState({ initiativeIssues: filteredIssues })
    }
  }

  renderPlatformFilter() {
    return createSelectFilter(
      this.state.selectedPlatforms,
      'platform-select',
      this.handlePlatformChange,
      this.state.platforms,
      'Filter by platform...',
    )
  }

  renderCommunityFilter() {
    return createSelectFilter(
      this.state.selectedCommunities,
      'community-select',
      this.handleCommunityChange,
      this.state.communities,
      'Filter by community...',
    )
  }

  render() {
    const tooltipText = <Tooltip id="tooltip">View teams allocated to initiatives without funding.</Tooltip> // eslint-disable-line max-len
    const HeaderSink = makeSink(header)
    const BodySink = makeSink(body)
    const rows = getData(this.state)
    const totalRows = getTotals(this.state)
    const columns = [
      { sortByProp: 'platformId', header: 'Platform' },
      { sortByProp: 'communityId', header: 'Community' },
      { sortByProp: 'teamName', header: 'Team' },
      { header: 'Allocations' },
    ]

    const makeSymbol = name => name === '' ? '-----' : '%'

    const getRowHeight = ({ index }) => rows.length > 0 && rows[index]
      ? (rows[index].allocations.length * 20) + 80
      : 120

    const Header = ({ key, style, columnIndex }) => {
      const handleSortClick = columnName => {
        this.setState({ sortBy: `${columnName}` })

        if ( columnName === this.state.sortBy ) {
          this.setState({ sortOrder: this.state.sortOrder === 'asc' ? 'desc' : 'asc' })
        } else {
          this.setState({ sortOrder: this.state.sortOrder === 'asc' ? 'asc' : 'desc' })
        }
      }

      if ( columnIndex === 3 ) {
        return (<div key={key} style={{ ...style, padding: '10px' }}><h4>{columns[columnIndex].header}</h4></div>)
      }

      return (
        <div className="grid-cell" key={key} style={{ ...style, padding: '10px ' }}>
          <h4>
            {columns[columnIndex].header}
            <Glyphicon
              aria-hidden="true"
              glyph="glyphicon glyphicon-sort"
              onClick={() => handleSortClick(columns[columnIndex].sortByProp)}
              style={{ float: 'right', paddingRight: '20px', cursor: 'pointer' }}
            />
          </h4>
        </div>
      )
    }

    const Cell = ({
      columnIndex, key, rowIndex, style,
    }) => {
      const row = rows[rowIndex]
      const totalsRow = totalRows[rowIndex]

      if ( !row ) { return null }
      switch ( columnIndex ) {
        case 0:
          return (
            (
              <div className="grid-cell" key={key} style={{ ...style, padding: '10px' }}>
                <span>{this.state.teamStructure.find(t => t.teamId === row.teamId).platformName}</span>
              </div>
            )
          )
        case 1:
          return (
            <div className="grid-cell" key={key} style={{ ...style, padding: '10px' }}>
              <span>{this.state.teamStructure.find(t => t.teamId === row.teamId).communityName}</span>
            </div>
          )
        case 2:
          return (
            <a
              className="grid-cell"
              href={`${peadminEzTracHome}/teams/?teamTab=engagements&teamId=${row.teamId}`}
              key={key}
              style={{ ...style, color: '#3498db', padding: '10px' }}
            >
              <span>{row.teamName}</span>
            </a>

          )
        default:
          return (
            <div className="grid-cell" key={key} style={{ ...style, padding: '10px', borderRight: 'none' }}>
              {
                map(row.allocations, ({
                  status, name, percentageOfTeamCost, initiativeId,
                }) => (
                  <span
                    className={status.toLowerCase() === 'funded' || status === '' ? 'initiative-blue' : 'initiative-red'}
                    key={`${key}-${initiativeId}-${name}-${status}-${percentageOfTeamCost}`}
                  >
                    <a
                      className="col-md-9"
                      href={`${vipUrl}/initiative/${initiativeId}`}
                      style={{ color: 'inherit' }}
                    >
                      {name}
                    </a>
                    <span className="col-md-2">{status}</span>
                    <span className="col-md-1">{`${percentageOfTeamCost}${makeSymbol(name)}`}</span>
                  </span>
                ))
}
              {
                map(totalsRow.allocations, ({ status, name, percentageOfTeamCost }) => (
                  <span
                    className={status.toLowerCase() === 'funded' || status === '' ? 'initiative-blue' : 'initiative-red'}
                    key={`total${key}-${name}-${status}`}
                  >
                    <span className="col-md-9" style={{ color: 'inherit' }}>{name}</span>
                    <span className="col-md-2">{status}</span>
                    <span className="col-md-1">{`${percentageOfTeamCost}${makeSymbol(name)}`}</span>
                  </span>
                ))
}
            </div>
          )
      }
    }

    const computeColumnWidth = width => ({ index }) => index === 3 ? width / 2 : (width / 6)

    return (
      <div className="initiative-page">
        <div className="col-md-9 col-md-offset-2">
          <Navbar />
        </div>
        <LoadingBlocker isLoading={this.state.loading} />
        <div className="row-padding">
          <div className="col-md-4 col-md-offset-1 row-padding">
            <h3>
              Initiative Quality Control
              <OverlayTrigger overlay={tooltipText} placement="right">
                <Glyphicon aria-hidden="true" data-toggle="tooltip" glyph="glyphicon glyphicon-question-sign" />
              </OverlayTrigger>
            </h3>
          </div>
        </div>
        <div className="qc-table">
          <div className="col-md-10 col-md-offset-1 full-height">
            <TimeframeButtons
              archiveMonth=""
              archiveMonthButtonPressed={null}
              selectedTimeframe={this.state.currentTimeframe}
              timeFrameButtonPressed={this.timeFrameButtonPressed}
              timeframes={this.state.timeframes}
            />
            {this.renderPlatformFilter()}
            {this.renderCommunityFilter()}
            <AutoSizer>
              {({ width, height }, tableWidth = width) => (
                <div>
                  <HeaderSink props={{
                    ...this.state.initiativeIssues,
                    ...this.state.sortOrder,
                    height,
                    width,
                  }}
                  />
                  <BodySink props={{
                    ...this.state.initiativeIssues,
                    ...this.state.sortOrder,
                    height,
                    width,
                  }}
                  />
                  <Grid
                    cellRenderer={Header}
                    className="grid-outer"
                    columnCount={4}
                    columnWidth={computeColumnWidth(tableWidth)}
                    height={50}
                    ref={ref => {
                      if ( ref ) { header = ref }
                    }}
                    rowCount={1}
                    rowHeight={50}
                    width={width}
                  />
                  <Grid
                    cellRenderer={Cell}
                    className="grid-outer"
                    columnCount={4}
                    columnWidth={computeColumnWidth(tableWidth)}
                    height={height - 50}
                    ref={ref => {
                      if ( ref ) { body = ref }
                    }}
                    rowCount={this.state.initiativeIssues.length}
                    rowHeight={getRowHeight}
                    width={width}
                  />
                </div>
              )}
            </AutoSizer>
          </div>
        </div>
      </div>
    )
  }
}

export default InitiativeQC
