import React from 'react'

const costDisplay = ( showUnderMeFlag, showUnderUserFlag, managerCost, totalCost ) => showUnderMeFlag
  || showUnderUserFlag
  ? managerCost
  : totalCost

const className = ({ managerCost, showUnderMeFlag, showUnderUserFlag }) => ( managerCost > 1 || !(showUnderMeFlag || showUnderUserFlag) )
  ? 'highlight'
  : 'good-job'

const TextDisplay = ({ showUnderMeFlag, showUnderUserFlag }) => showUnderMeFlag
  || showUnderUserFlag
  ? <text>Cost Under Manager: </text>
  : <text>Total P&E Cost: </text>

const Cost = ({
  loadingCalculations, managerCost, totalCost, showUnderMeFlag, showUnderUserFlag,
}) => loadingCalculations
  ? <i className="velocity-spinner-small-inline" />
  : (
    <span>
      $
      {costDisplay(showUnderMeFlag, showUnderUserFlag, managerCost, totalCost).toLocaleString()}
    </span>
  )

const CostCalculation = props => ( !props.showReasons && props.searchText.length < 1 )
  ? (
    <p className={className(props)}>
      <TextDisplay showUnderMeFlag={props.showUnderMeFlag} showUnderUserFlag={props.showUnderUserFlag} />
      <Cost {...props} />
    </p>
  ) : null


export default CostCalculation
