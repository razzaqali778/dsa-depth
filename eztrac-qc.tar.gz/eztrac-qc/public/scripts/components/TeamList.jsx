import React from 'react'
import { Button } from 'react-bootstrap'
import chunk from 'lodash/chunk'
import map from 'lodash/map'
import { enrichTeamWithStatus, makeTeamUrl } from './utils/teamUtils'

const Team = ({
  effortTeam,
}) => {
  const { teamName: effortTeamName, teamId, percent } = effortTeam
  const teamName = effortTeamName || teamId

  return (
    teamName && teamId
      ? (
        <li>
          <span>{`${percent}% `}</span>
          <a href={makeTeamUrl(teamId)}>{teamName}</a>
        </li>
      )
      : null
  )
}

export const TeamListComponent = ({
  effortTeams,
  timeframe: { id: timeframeId },
}) => (
  <ul className="undecoratedList">
    {effortTeams.length ? map(effortTeams, (effortTeam, teamIdx) => (
      <Team
        effortTeam={effortTeam}
        key={`${timeframeId}-${teamIdx}`}
      />
    )) : <li>No Team for Timeframe</li>}
  </ul>
)


class TeamList extends React.Component {
  constructor( props ) {
    super(props)
    this.state = {
      pickedYear: new Date().getFullYear(),
    }
  }

  renderYearButton(year) {
    return (
      <Button
        className={`btn btn-lg buttonWrapper ${this.props.pickedYear === year ? 'btn-primary' : ''}`}
        onClick={() => this.props.onChangeYearClick(year)}
        type="button"
      >
        {year}
      </Button>
    )
  }

  render() {
    if ( !this.props.selectedPersonId ) return null
    if ( this.props.previousTeamsLoading ) {
      return (
        <span>
          <i className="velocity-spinner-inline" />
          Loading....
        </span>
      )
    }
    if ( !this.props.previousTeams.length ) {
      return ( <p>No information for selected user.</p> )
    }

    const currentYear = new Date().getFullYear()
    const preparedContent = this.props.previousTeams
      .map(data => enrichTeamWithStatus(data, this.props.currentTimeframe.id))

    return (
      <div>
        {this.renderYearButton(currentYear - 1)}
        {this.renderYearButton(currentYear)}
        {chunk(preparedContent, 3).map(teamChunk => (
          <div className="row" key={teamChunk.map(t => t.timeframe.id).flat()}>
            {teamChunk.map(( { effortTeams, timeframe, status } ) => (
              <div className="col-md-4" key={`header-${timeframe.name}`}>
                <div className="panel panel-default">
                  <div className="panel-heading headerMultipleItems">
                    <span>{timeframe.name}</span>
                    <span className="italic">{status}</span>
                  </div>
                  <div className="panel-body">
                    <TeamListComponent effortTeams={effortTeams} timeframe={timeframe} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    )
  }
}

export default TeamList
