import { createSink } from 'recompose'
import AutoSizer from 'react-virtualized/dist/commonjs/AutoSizer/'
import Grid from 'react-virtualized/dist/commonjs/Grid/'
import React from 'react'
import max from 'lodash/max'
import orderBy from 'lodash/orderBy'
import reduce from 'lodash/reduce'
import { BodyCell, HeaderCell } from './Cells'

let header
let body

const makeSink = ref => createSink((v => () => {
  if ( v ) {
    try {
      v.recomputeGridSize()
    } catch ( err ) {
      console.error(err) // eslint-disable-line no-console
    }
  }
})(ref))

class PeopleQCTable extends React.Component {
  constructor( props ) {
    super(props)
    this.state = {
      sortOrder: { order: {} },
    }

    this.setSortOrder = this.setSortOrder.bind(this)
  }

  setSortOrder(col, sortOrder) {
    this.setState({
      sortOrder: {
        col,
        order: {
          ...this.state.sortOrder.order,
          [col]: sortOrder,
        },
      },
    })
  }

  render() {
    const rows = orderBy(this.props.rows, [ this.state.sortOrder.col ], [ this.state.sortOrder.order[this.state.sortOrder.col] ] )

    const HeaderSink = makeSink(header)
    const BodySink = makeSink(body)

    const headerRenderer = ({ key, style, columnIndex }) => (
      <HeaderCell
        columnIndex={columnIndex}
        key={key}
        setSortOrder={this.setSortOrder}
        sortOrder={this.state.sortOrder}
        style={style}
      />
    )

    const bodyRenderer = ({
      columnIndex, key, rowIndex, style,
    }) => (
      rowIndex < rows.length ? (
        <BodyCell
          columnIndex={columnIndex}
          key={key}
          keyProp={key}
          reasons={this.props.reasons}
          rowIndex={rowIndex}
          rows={rows}
          setReason={this.props.setReason}
          style={{ ...style, backgroundColor: rowIndex % 2 === 0 ? '#ecf0f1' : 'fff' }}
          timeframeMap={reduce(this.props.timeframes, (memo, { id, name, lockdown }) => {
            memo[id] = { name, lockdown } // eslint-disable-line no-param-reassign

            return memo
          }, {})}
        />
      ) : <div key={key} style={style} />
    )

    const computeColumnWidth = (width, scrollbarOffset = 0) => ({ index }) => {
      switch ( index ) {
        case 0:
        case 1: return 200
        case 4: return 200 - scrollbarOffset
        default: return ( width - 600 ) / 2
      }
    }

    const computeRowHeight = ({ index }) => {
      const row = rows[index]
      const defaultHeight = 60
      if ( row ) {
        const prevTeams = row.previousTeams.length
        const curTeams = row.currentTeams.length

        const teams = max([ prevTeams, curTeams, 0 ])
        const teamHeight = teams >= 2 ? ( teams - 2 ) * 20 : 0

        const height = defaultHeight + teamHeight

        return height
      }

      return defaultHeight
    }

    return (
      <div className="qc-table">
        <div className="full-height">
          <AutoSizer>
            {({ width, height }) => (
              <div>
                <HeaderSink props={{ ...this.state.sortOrder, height, width }} rows={rows} />
                <BodySink props={{ ...this.state.sortOrder, height, width }} rows={rows} />
                <Grid
                  cellRenderer={headerRenderer}
                  className="grid-outer"
                  columnCount={5}
                  columnWidth={computeColumnWidth(width, 0)}
                  height={50}
                  ref={ref => {
                    if ( ref ) { header = ref }
                  }}
                  rowCount={1}
                  rowHeight={50}
                  width={width}
                />
                <Grid
                  cellRenderer={bodyRenderer}
                  className="grid-outer"
                  columnCount={5}
                  columnWidth={computeColumnWidth(width, 9)}
                  height={max([ height - 50, 300 ])}
                  ref={ref => {
                    if ( ref ) { body = ref }
                  }}
                  rowCount={rows.length}
                  rowHeight={computeRowHeight}
                  width={width}
                />
              </div>
            )}
          </AutoSizer>
        </div>
      </div>
    )
  }
}

export default PeopleQCTable
