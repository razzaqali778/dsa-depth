import React from 'react'
import filter from 'lodash/filter'
import reduce from 'lodash/reduce'
import InactivePersonLabel from '../InactivePersonLabel'
import LinkCell from '../table/cells/LinkCell'
import ListLinkCell from '../table/cells/ListLinkCell'
import ModalCell from '../table/cells/ModalCell'
import SortableHeader from '../table/cells/SortableHeader'
import TextCell from '../table/cells/TextCell'
import getReasonDescriptionMap from '../../selectors/people/getReasonDescriptionMap'
import getReasonSelectOptions from '../../selectors/people/getReasonSelectOptions'

const peadminHome = window.phoenix.serviceBindings['peadmin-home']
const peadminEzTracHome = window.phoenix.serviceBindings['peadmin-ez-trac-home']

const colMap = {
  0: 'managerName',
  1: 'userName',
  2: 'previousTeams',
  3: 'currentTeams',
  4: 'reason',
}

export const HeaderCell = ({
  style, columnIndex, setSortOrder, sortOrder,
}) => {
  switch ( columnIndex ) {
    case 0: return (
      <SortableHeader
        setSortOrder={order => setSortOrder('managerName', order)}
        sortOrder={sortOrder.order.managerName}
        style={style}
        text="Manager"
      />
    )
    case 1: return (
      <SortableHeader
        setSortOrder={order => setSortOrder('userName', order)}
        sortOrder={sortOrder.order.userName}
        style={style}
        text="Name"
      />
    )
    case 2: return <TextCell style={style} text="Previous Teams" />
    case 3: return <TextCell style={style} text="Current Teams" />
    case 4: return <TextCell style={style} text="Reason" />
    default: return null
  }
}

export const BodyCell = ({
  rows,
  columnIndex,
  rowIndex,
  style,
  keyProp,
  reasons,
  setReason,
  timeframeMap,
}) => {
  const row = rows[rowIndex]
  const colKey = colMap[columnIndex]
  const data = row[colKey]

  if ( !row ) { return null }
  switch ( columnIndex ) {
    case 0: return <LinkCell style={style} text={data} url={`https://${peadminHome}/profile/users/${row.managerId}`} />
    case 1: return (
      <LinkCell
        style={style}
        text={data}
        url={`https://${peadminHome}/profile/users/${row.userId}`}
      >
        {row.isActive ? null : <InactivePersonLabel />}
      </LinkCell>
    )
    case 2:
    case 3: return (
      <ListLinkCell
        generateText={({ teamName, percent }) => `${percent}% - ${teamName}`}
        generateUrl={({ teamId }) => `${peadminEzTracHome}/teams/?teamTab=engagements&teamId=${teamId}`}
        keyProp={keyProp}
        listData={data}
        style={style}
      />
    )
    // TODO move logic to selector or util
    case 4: {
      const totalParticipation = reduce( row.currentTeams, (memo, val) => memo + val.percent, 0 )
      const filteredReasons = (totalParticipation === 100 || totalParticipation === 0 )
        ? filter(reasons, reason => reason.reasonName !== 'Part Time')
        : reasons

      return (
        <ModalCell
          options={getReasonSelectOptions({ reasons: filteredReasons })}
          reasonDescriptionMap={getReasonDescriptionMap({ reasons: filteredReasons })}
          row={row}
          setReason={setReason}
          style={{
            ...style, paddingRight: 15, paddingLeft: 15, paddingTop: 10,
          }}
          timeframeMap={timeframeMap}
          value={data}
        />
      )
    }
    default: return <div className="grid-cell" style={{ ...style, padding: '10px' }}>{data}</div>
  }
}
