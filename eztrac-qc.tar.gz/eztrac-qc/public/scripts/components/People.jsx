import {
  Button, ButtonGroup, Glyphicon, OverlayTrigger, Tooltip,
} from 'react-bootstrap'
import React from 'react'
import getOrElse from 'lodash/get'
import { changeReason, getReasons } from '../Util/Network/reasonUtil'
import { getAllPeople, getInactivePeopleWithReasons, getPeopleByTimeframe } from '../Util/Network/papiPeopleUtil'
import { getArchiveMonth } from '../Util/Network/archiveUtil'
import { getCostCalculations } from '../Util/rateUtil'
import { getCurrentAndNextTimeframes, getOffsetTimeframe } from '../Util/Network/timeframeUtil'
import { getFilteredPeople, getShowUnderUserField, getShowUnderUserFlag } from '../selectors/getFilteredPeople'
import { makeDeactivateUrl, shouldDeactivate } from '../Util/Network/deactivatePersonUtil'
import { renderToastrPopOver, toggleSession } from './utils/peopleUtils'
import CostCalculation from './CostCalculation'
import LoadingBlocker from './LoadingBlocker'
import Navbar from './Navbar'
import PeopleQCTable from './people/PeopleQCTable'
import RedirectModal from './RedirectModal'
import SearchComponent from './SearchComponent'
import ShowUnderManagerModal from './ShowUnderManagerModal'
import TimeframeButtons from './TimeframeButtons'
import TimeframeLockedWarning from './TimeframeLockedWarning'
import isArchiveMonthSelected from '../selectors/people/isArchiveMonthSelected'
import userRolesUtil from '../Util/userRolesUtil'
import CSVDownloadButton from './CSVDownloadButton'

/* eslint-disable max-len */

const parseValue = value => {
  if ( value.toLowerCase() === 'true' ) { return true }
  if ( value.toLowerCase() === 'false' ) { return false }

  return value
}
const getStorage = key => {
  const value = window.sessionStorage.getItem(key) || 'false'

  return parseValue(value)
}
const setStorage = ( key, value ) => window.sessionStorage.setItem(key, value)

class People extends React.Component {
  constructor( props ) {
    super(props)
    const query = getOrElse(props, 'location.query', {})
    this.handleInputChange = this.handleInputChange.bind(this)
    this.clearFilterButtons = this.clearFilterButtons.bind(this)
    this.state = {
      allPeople: [],
      archiveMonth: {},
      costCalculation: {
        managerCost: 0,
        totalCost: 0,
      },
      currentTimeframe: {},
      loadingCalculations: false,
      loading: false,
      reasons: [],
      searchText: query.q || getStorage('searchText') || '',
      selectedTimeframe: {},
      showReasons: query.showWithReasons || getStorage('showReasons') || false,
      showUnderMeFlag: query.showUnderMe || getStorage('showUnderMeFlag') || false,
      showUnderUserFlag: getStorage('showUnderUserFlag') || false,
      showUnderUserSearchField: getStorage('showUnderUserSearchField') || '',
      timeframes: [],
      totalPeopleDiscrepancies: [],
      userId: '',
      redirectModal: {},
      showShowUnderModal: false,
    }

    this.setReason = this.setReason.bind(this)
    this.timeFrameButtonPressed = this.timeFrameButtonPressed.bind(this)
    this.clearShowUnderUserButton = this.clearShowUnderUserButton.bind(this)
    this.setCostCalculation = this.setCostCalculation.bind(this)
    this.archiveMonthButtonPressed = this.archiveMonthButtonPressed.bind(this)

    this.closeShowUnderModal = this.closeShowUnderModal.bind(this)
    this.handleShowUnderManagerClicked = this.handleShowUnderManagerClicked.bind(this)
    this.handleShowUnderModalChange = this.handleShowUnderModalChange.bind(this)
  }

  componentWillMount() {
    this.timer = null
    this.mounting()
  }

  getButtonStyle( btnName ) {
    return this.state[btnName] ? 'btn-primary' : ''
  }

  async setReason( currentDiscrepancy, val ) {
    if ( !currentDiscrepancy.isActive ) { return }

    if ( val && shouldDeactivate(this.state.reasons, val.value) ) {
      this.setState({
        redirectModal: {
          show: true,
          url: makeDeactivateUrl(currentDiscrepancy.userId, val.value),
          app: 'Deactivate Person Workflow',
        },
      })

      return
    }

    const updatedPeopleDiscrepancies = await changeReason(currentDiscrepancy, val, this.state.userId, this.state.totalPeopleDiscrepancies)

    this.setState({ totalPeopleDiscrepancies: updatedPeopleDiscrepancies })
  }

  setOppositeState( item ) { this.setState({ [item]: !this.state[item] }) }

  async setCostCalculation( id ) {
    this.setState({ loadingCalculations: true })
    const costCalculation = await getCostCalculations(id, this.state.selectedTimeframe.id)

    this.setState({ costCalculation, loadingCalculations: false })
  }

  async timeFrameButtonPressed( timeframe ) {
    this.setState({ loading: true })
    const totalPeopleDiscrepancies = await getPeopleByTimeframe(timeframe.id)
    const inactivePeopleWithReasons = await getInactivePeopleWithReasons(timeframe.id)
    const showUnder = getShowUnderUserFlag(this.state)
    const showUnderId = getShowUnderUserField(this.state)

    this.setState({
      totalPeopleDiscrepancies,
      selectedTimeframe: timeframe,
      loading: false,
      inactivePeopleWithReasons,
    })
    this.setCostCalculation(showUnder ? showUnderId : '')
  }

  async archiveMonthButtonPressed( archiveMonth ) {
    this.setState({ loading: true })

    const archivedPeople = await getArchiveMonth(archiveMonth.id)

    this.setState({
      totalPeopleDiscrepancies: archivedPeople,
      loading: 0,
      selectedTimeframe: archiveMonth,
    })
  }

  handleInputChange( target ) { this.setState({ searchText: target.value }) }

  async handleShowUnderModalChange( selectedUserId ) {
    setStorage('showUnderMeFlag', false)
    setStorage('showUnderUserSearchField', selectedUserId)
    setStorage('showUnderUserFlag', true)

    this.setCostCalculation(selectedUserId)
    this.setState({
      showUnderUserSearchField: selectedUserId,
      showUnderUserFlag: true,
      showUnderMeFlag: false,
      showShowUnderModal: false,
    })
  }

  clearShowUnderUserButton() {
    setStorage('showUnderUserFlag', false)
    setStorage('showUnderUserSearchField', '')
    this.setCostCalculation(null)
    this.setState({ showUnderUserFlag: false, showUnderUserSearchField: '', loadingCalculations: true })
  }

  async showPeopleUnderMe() {
    setStorage('showUnderUserFlag', false)
    toggleSession('showUnderMeFlag')
    this.setCostCalculation(this.state.userId)

    this.setState({ showUnderMeFlag: !this.state.showUnderMeFlag, showUnderUserFlag: false })
  }

  hidePeopleWithReason() {
    toggleSession('showReasons')
    this.setOppositeState('showReasons')
  }

  clearFilterButtons() {
    window.sessionStorage.clear()

    this.setState({
      showReasons: false,
      searchText: '',
      showUnderMeFlag: false,
      showUnderUserSearchField: '',
      showUnderUserFlag: false,
    })
  }

  closeShowUnderModal() {
    this.setState({ showShowUnderModal: false })
  }

  handleShowUnderManagerClicked() {
    if ( this.state.showUnderUserFlag ) {
      this.clearShowUnderUserButton()
    } else {
      this.setState({ showShowUnderModal: true })
    }
  }

  async mounting() {
    try {
      this.setState({ loading: true })

      const user = await userRolesUtil.getUser()
      const reasons = await getReasons()
      const showUnder = getShowUnderUserFlag(this.state)
      const showUnderId = getShowUnderUserField(this.state)

      const allPeople = await getAllPeople()
      const timeframes = await getCurrentAndNextTimeframes()
      const archiveMonth = await getOffsetTimeframe(-1)
      const totalPeopleDiscrepancies = await getPeopleByTimeframe(timeframes[0].id)

      this.setState({
        allPeople,
        reasons,
        timeframes,
        totalPeopleDiscrepancies,
        currentTimeframe: timeframes[0],
        user,
        userId: user.id,
        archiveMonth,
        selectedTimeframe: timeframes[0],
        loading: false,
      })
      this.setCostCalculation(showUnder ? showUnderId : '')
    } catch ( err ) {
      renderToastrPopOver('Error loading', 'failure')
      console.error(err) // eslint-disable-line no-console
    }
  }

  render() {
    const infoTooltip = (
      <Tooltip id="tooltip">
        View employees who are over or under allocated and assign a reason.
      </Tooltip>
    )

    const visiblePeopleDiscrepancies = getFilteredPeople(this.state)
    const archiveMonthSelected = isArchiveMonthSelected(this.state)

    if ( this.state.loading ) {
      return <LoadingBlocker isLoading />
    }

    return (
      <div className="people-qc">
        <RedirectModal
          app={this.state.redirectModal.app}
          closeModal={() => this.setState({ redirectModal: { ...this.state.redirectModal, show: false } })}
          show={this.state.redirectModal.show}
          url={this.state.redirectModal.url}
        />
        <div className="row navComponent">
          <div className="col-md-9 col-md-offset-2">
            <Navbar user={this.state.user} />
          </div>
        </div>
        <div className="row row-padding">
          <div className="col-md-4 col-md-offset-1">
            <h3>
              Participation Quality Control
              <OverlayTrigger overlay={infoTooltip} placement="right">
                <Glyphicon aria-hidden="true" data-toggle="tooltip" glyph="glyphicon glyphicon-question-sign" />
              </OverlayTrigger>
            </h3>
            <TimeframeLockedWarning isLocked={this.state.selectedTimeframe.lockdown || archiveMonthSelected} />
          </div>
        </div>
        <div className="row form-group">
          <div className="col-md-4 col-md-offset-1">
            <TimeframeButtons
              archiveMonth={this.state.archiveMonth}
              archiveMonthButtonPressed={this.archiveMonthButtonPressed}
              selectedTimeframe={this.state.selectedTimeframe}
              timeFrameButtonPressed={this.timeFrameButtonPressed}
              timeframes={this.state.timeframes}
            />
          </div>
        </div>
        <div className="row row-padding form-group">
          <div className="col-md-6 col-md-offset-1">
            <ButtonGroup>
              <Button className={this.getButtonStyle('showReasons')} onClick={() => { this.hidePeopleWithReason() }}>
                {this.state.showReasons ? 'Hide With Reasons' : 'Show With Reasons'}
              </Button>
              <Button className={this.getButtonStyle('showUnderMeFlag')} onClick={() => { this.showPeopleUnderMe() }}>
                Show Under Me
              </Button>
              <Button
                className={this.getButtonStyle('showUnderUserFlag')}
                onClick={this.handleShowUnderManagerClicked}
              >
                Show Under Manager
              </Button>
            </ButtonGroup>
            <Button className="clearButton" onClick={() => this.clearFilterButtons()}>
              Reset
            </Button>
            <CSVDownloadButton csvFileName={`Participation QC ${JSON.stringify(this.state.selectedTimeframe.name)}`} rows={visiblePeopleDiscrepancies} />
          </div>
          <div className="col-md-4">
            <SearchComponent searchAction={this.handleInputChange} searchText={this.state.searchText} />
          </div>
        </div>
        <div className="row">
          <div className="col-sm-3 col-sm-offset-1">
            {this.state.showReasons
              ? ''
              : (
                <p>
                  <strong>{visiblePeopleDiscrepancies.length}</strong>
                  {' '}
                  Unallocated People
                </p>
              )}
          </div>
          <div className="col-sm-3 col-sm-offset-4">
            {archiveMonthSelected
              ? null
              : (
                <CostCalculation
                  loadingCalculations={this.state.loadingCalculations}
                  managerCost={this.state.costCalculation.managerCost}
                  searchText={this.state.searchText}
                  showReasons={this.state.showReasons}
                  showUnderMeFlag={this.state.showUnderMeFlag}
                  showUnderUserFlag={this.state.showUnderUserFlag}
                  totalCost={this.state.costCalculation.totalCost}
                />
              )}
          </div>
        </div>
        <div className="row qc-table-container">
          <div className="col-md-10 col-md-offset-1 full-height">
            <PeopleQCTable
              reasons={this.state.reasons}
              rows={visiblePeopleDiscrepancies}
              setReason={this.setReason}
              timeframes={this.state.timeframes}
            />
          </div>
        </div>
        <ShowUnderManagerModal
          allPeople={this.state.allPeople}
          close={this.closeShowUnderModal}
          onChange={this.handleShowUnderModalChange}
          searchForUnderUser={this.searchForUnderUser}
          show={this.state.showShowUnderModal}
        />
      </div>
    )
  }
}

export default People
