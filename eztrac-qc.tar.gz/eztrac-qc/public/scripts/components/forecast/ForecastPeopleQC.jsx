import React, { useEffect, useState } from 'react'
import {
  getCurrentAndNextTimeframes,
  getCurrentYearFutureTimeFrames,
} from '../../Util/Network/timeframeUtil'
import TimeframeButtons from '../TimeframeButtons'
import TimeframeLockedWarning from '../TimeframeLockedWarning'
import ForecastPeopleQCTable from './ForecastPeopleQCTable'
import Navbar from '../Navbar'
import userRolesUtil from '../../Util/userRolesUtil'
import { fetch } from '../../Util/Network/fetchUtil'

export const FullYearTimeFrame = 'Full Year'

const costingUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/proxies/cost-calc/v1`
const makePlaceholdersUrl = timeFrameId => `${window.phoenix.serviceBindings['ez-trac-qc-services']}/proxies/core-services/v2/efforts/timeframes/${timeFrameId}/placeholders` // eslint-disable-line max-len

function ForecastPeopleQC() {
  const [ user, setUser ] = useState({})
  const [ timeFrames, setTimeFrames ] = useState([])
  const [ selectedTimeFrame, setSelectedTimeFrame ] = useState({})
  const [ forecastPeople, setForecastPeople ] = useState([])
  const [ costGroups, setCostGroups ] = useState(null)
  const [ rates, setRates ] = useState(null)
  const [ fullYearTimeFrames, setFullYearTimeFrames ] = useState(null)
  const [ loading, setLoading ] = useState(true)
  const [ cachedTimeframesData, setCachedTimeframesData ] = useState({})

  const extendForecastPeopleProperties = (
    _costGroups,
    _rates,
    people,
    timeFramesData = [],
  ) => {
    const extended = people.map(p => ({
      ...p,
      rate: _rates.find(r => r.id === p.rateId).name,
      costGroup: _costGroups.find(g => g.id === p.costGroupId).name,
      ...(timeFramesData.find(tF => tF.id === p.timeFrameId) && timeFramesData.find(tF => tF.id === p.timeFrameId)),
    }))

    setForecastPeople(extended)

    return extended
  }

  useEffect(() => {
    const fullYearTimeFrame = {
      id: FullYearTimeFrame,
      name: FullYearTimeFrame,
    }
    userRolesUtil.getUser().then(u => setUser(u))
    getCurrentAndNextTimeframes().then(tf => {
      setTimeFrames(tf.concat(fullYearTimeFrame))
      setSelectedTimeFrame(tf[0])
    })
  }, [])

  useEffect(async () => {
    let currRates = rates
    let currTimeframes = fullYearTimeFrames
    let currCostGroups = costGroups

    if ( timeFrames.length > 0 ) {
      setLoading(true)
      const cachedDataExists = cachedTimeframesData[selectedTimeFrame.id]
      if ( cachedDataExists ) {
        setForecastPeople(cachedDataExists)
        setLoading(false)

        return
      }

      if (
        !currRates
        || !currCostGroups
        || (!currTimeframes && selectedTimeFrame.id === FullYearTimeFrame)
      ) {
        await Promise.all([
          !currRates ? fetch(`${costingUrl}/rates`) : rates,
          !currCostGroups ? fetch(`${costingUrl}/costGroups`) : costGroups,
          !currTimeframes && selectedTimeFrame.id === FullYearTimeFrame
            ? getCurrentYearFutureTimeFrames()
            : fullYearTimeFrames,
        ]).then(([ _rates, _costGroups, _timeframes ]) => {
          setRates(_rates)
          currRates = _rates

          setCostGroups(_costGroups)
          currCostGroups = _costGroups

          setFullYearTimeFrames(_timeframes)
          currTimeframes = _timeframes
        })
      }

      if ( selectedTimeFrame.id === FullYearTimeFrame ) {
        getCurrentYearFutureTimeFrames().then(allTimeframes => {
          Promise.all(
            allTimeframes.map(timeFrame => fetch(makePlaceholdersUrl(timeFrame.id))),
          ).then(people => {
            const extendedDataForTimeframe = extendForecastPeopleProperties(
              currCostGroups,
              currRates,
              people.flat(),
              currTimeframes,
            )
            const updatedCache = {
              ...cachedTimeframesData,
              [selectedTimeFrame.id]: extendedDataForTimeframe,
            }
            setCachedTimeframesData(updatedCache)
            setLoading(false)
          })
        })
      } else {
        fetch(makePlaceholdersUrl(selectedTimeFrame.id)).then(people => {
          const extendedDataForTimeframe = extendForecastPeopleProperties(
            currCostGroups,
            currRates,
            people,
          )
          const updatedCache = {
            ...cachedTimeframesData,
            [selectedTimeFrame.id]: extendedDataForTimeframe,
          }
          setCachedTimeframesData(updatedCache)
          setLoading(false)
        })
      }
    }
  }, [ selectedTimeFrame ])

  const timeFrameButtonPressed = timeFrame => setSelectedTimeFrame(timeFrame)

  return (
    <div className="people-qc">
      <div className="row navComponent">
        <div className="col-md-9 col-md-offset-2">
          <Navbar user={user} />
        </div>
      </div>
      <div className="row row-padding">
        <div className="col-md-4 col-md-offset-1">
          <h3>Placeholders Quality Control</h3>
          <TimeframeLockedWarning isLocked={selectedTimeFrame.lockdown} />
        </div>
      </div>
      <div className="row form-group">
        <div className="col-md-4 col-md-offset-1">
          <TimeframeButtons
            selectedTimeframe={selectedTimeFrame}
            timeFrameButtonPressed={timeFrameButtonPressed}
            timeframes={timeFrames}
          />
        </div>
      </div>
      <div className="row qc-table-container">
        <div className="col-md-10 col-md-offset-1 full-height">
          <ForecastPeopleQCTable
            displayMonth={selectedTimeFrame.id === FullYearTimeFrame}
            forecastPeople={forecastPeople}
            loading={loading}
            selectedTimeFrame={selectedTimeFrame}
          />
        </div>
      </div>
    </div>
  )
}

export default ForecastPeopleQC
