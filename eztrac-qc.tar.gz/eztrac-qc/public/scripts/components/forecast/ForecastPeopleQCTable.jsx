import React from 'react'
import { DataGrid, GridToolbar } from '@mui/x-data-grid'

const peadminEzTracHome = window.phoenix.serviceBindings['peadmin-ez-trac-home']
const makeTeamUrl = teamId => `${peadminEzTracHome}/teams/?teamTab=people&teamId=${teamId}`

const columnStylingProperties = {
  flex: 1,
  headerClassName: 'data-grid-column-header',
}

const columns = [
  {
    ...columnStylingProperties,
    field: 'teamName',
    headerName: 'Team name',
    renderCell: params => (
      <a href={makeTeamUrl(params.row.teamId)}>{params.value}</a>
    ),
  },
  { ...columnStylingProperties, field: 'rate', headerName: 'Rate' },
  { ...columnStylingProperties, field: 'costGroup', headerName: 'Cost group' },
  {
    ...columnStylingProperties,
    field: 'numberOfPeople',
    headerName: 'Number of people',
  },
]

const monthsNumbersMap = {
  January: 'a',
  February: 'b',
  March: 'c',
  April: 'd',
  May: 'e',
  June: 'f',
  July: 'g',
  August: 'h',
  September: 'i',
  October: 'j',
  November: 'k',
  December: 'l',
}

const columnsWithMonth = columns.concat({
  ...columnStylingProperties,
  field: 'month',
  sortComparator: (val1, val2, node) => {
    const sortOrder = node.api.state.sorting.sortModel[0].sort
    if ( sortOrder === 'asc' ) { return monthsNumbersMap[val1] <= monthsNumbersMap[val2] }

    return monthsNumbersMap[val1] >= monthsNumbersMap[val2]
  },
  headerName: 'Month',
})

const csvFileName = timeFrame => `Placeholder_QC_${timeFrame.name}`

function ForecastPeopleQCTable({
  forecastPeople,
  loading,
  selectedTimeFrame,
  displayMonth,
}) {
  return (
    <div style={{ height: '100%', width: '100%' }}>
      <div style={{ display: 'flex', height: '100%' }}>
        <div style={{ flexGrow: 1 }}>
          <DataGrid
            columns={displayMonth ? columnsWithMonth : columns}
            components={{ Toolbar: GridToolbar }}
            componentsProps={{
              toolbar: {
                csvOptions: { fileName: csvFileName(selectedTimeFrame) },
              },
            }}
            disableSelectionOnClick
            getRowClassName={() => 'data-grid-column-header'}
            getRowId={row => `${row.teamId}_${row.costGroupId}_${row.rateId}_${row.timeFrameId}`}
            loading={loading}
            rows={forecastPeople}
          />
        </div>
      </div>
    </div>
  )
}

export default ForecastPeopleQCTable
