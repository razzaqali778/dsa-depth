import toastr from 'toastr'

export const renderToastrPopOver = ( message, type ) => {
  toastr.options.closeButton = true
  toastr.options.closeMethod = 'fadeOut'
  toastr.options.closeDuration = 300
  toastr.options.closeEasing = 'swing'
  toastr.options.positionClass = 'toast-top-right'
  if ( type === 'success' ) { toastr.success(message) } else { toastr.error(message) }
}
export const toggleSession = itemName => {
  const value = JSON.parse(window.sessionStorage.getItem(itemName) || 'false')

  window.sessionStorage.setItem(itemName, !value)
}
