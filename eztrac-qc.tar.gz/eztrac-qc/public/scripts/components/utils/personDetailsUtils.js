import { fetch } from '../../Util/Network/fetchUtil'
import getUserDetailsFromPapi from '../../Util/papiDetailsUtil'

const peadminHome = window.phoenix.serviceBindings['peadmin-home']
const qcServices = window.phoenix.serviceBindings['ez-trac-qc-services']
const costingServices = window.phoenix.serviceBindings['ez-trac-costing-services']

const getStorage = key => window.sessionStorage.getItem(key)


const getPersonCostGroup = (costGroups, person) => {
  let cgName = ''
  if ( person.costGroupName !== undefined ) {
    cgName = costGroups.filter(cg => cg.name === person.costGroupName)[0].name
  }

  return cgName
}

export const fetchUserDetails = async () => {
  const personFromStorage = getStorage('selectedPerson')
  const currentSelection = typeof personFromStorage === 'string' ? JSON.parse(personFromStorage) : personFromStorage
  let costGroup = ''

  if ( currentSelection ) {
    const userDetails = await getUserDetailsFromPapi(currentSelection.userId)

    if ( userDetails.id ) {
      await Promise.all([
        fetch(`${qcServices}/proxies/cost-calc/v1/costGroups`),
        fetch(`${costingServices}/v1/person/${currentSelection.userId}`),
      ]).then(([ costGroups, personWithCostGroupField ]) => {
        costGroup = getPersonCostGroup(costGroups, personWithCostGroupField)
      })
    }

    return {
      id: userDetails.id,
      name: `${userDetails.firstName} ${userDetails.lastName}`,
      jobTitle: userDetails.jobTitle,
      email: userDetails.email,
      employeeType: userDetails.employeeType,
      url: `https://${peadminHome}/profile/users/${userDetails.id}`,
      managerId: userDetails.managerId,
      managerName: userDetails.managerName,
      managerUrl: `https://${peadminHome}/profile/users/${userDetails.managerId}`,
      costGroup,
    }
  }

  return {}
}
