import { getPreviousTeams } from '../../Util/Network/papiPeopleUtil'
import { getNumTimeframes } from '../../Util/Network/timeframeUtil'

export const DEACTIVATE_BUTTON_TEXT = 'Deactivate'

export const getStorage = key => window.sessionStorage.getItem(key)
export const setStorage = ( key, value ) => window.sessionStorage.setItem(key, value)

export const peadminEzTracHome = window.phoenix.serviceBindings['peadmin-ez-trac-home']

export const makeTeamUrl = teamId => `${peadminEzTracHome}/teams/?teamTab=engagements&teamId=${teamId}`


export const reasonNames = {
  CoOp: 'Co-Op',
  LeftPE: 'Left P&E',
  SOW: 'SOW (External',
  ContractorAbsence: 'Contractor Absence',
  PartTime: 'Part Time',
  EmployeeAbsenca: 'Employee Absence',
  New: 'New to P&E',
}

export const possibleTimeframeStatuses = {
  Closed: 'Closed',
  Current: 'Current',
  Forecasted: 'Forecasted',
}

export const enrichTeamWithStatus = (team, currentTimeframeId) => {
  if ( team.status ) return team
  if ( team.timeframe.id === currentTimeframeId ) return { ...team, status: possibleTimeframeStatuses.Current }
  if ( team.timeframe.lockdown ) return { ...team, status: possibleTimeframeStatuses.Closed }

  return team
}


export const fetchAmountOfTimeframesForUserAndTimeframeId = async (userId, timeframeId, amount) => {
  try {
    const timeframes = await getNumTimeframes(timeframeId, amount)
    if ( !timeframes ) return []
    const userTeams = timeframes.map(timeframe => getPreviousTeams(userId, timeframe.id))

    return await Promise.all(userTeams).then(teams => teams.map(( result, idx ) => ({
      effortTeams: result.effortTeams,
      timeframe: timeframes[idx],
    })))
  } catch ( e ) {
    console.error(e)

    return []
  }
}
