import { Nav, NavItem } from 'react-bootstrap'
import React from 'react'
import map from 'lodash/map'
import userRolesUtil from '../Util/userRolesUtil'

const peadminEzTracHome = window.phoenix.serviceBindings['peadmin-ez-trac-home']
const ezQcBaseUrl = window.phoenix.serviceBindings['ez-trac-qc-ui']
const ezReportingUrl = window.phoenix.serviceBindings['ez-trac-reporting-ui']

class Navbar extends React.Component {
  constructor( props ) {
    super(props)
    this.state = {
      assignNav: '',

      readPermissionsLinkInformation: [
        { name: 'Home', url: peadminEzTracHome },
        { name: 'Participation QC', url: `${ezQcBaseUrl}/participation` },
        { name: 'Placeholder QC', url: `${ezQcBaseUrl}/placeholders` },
        { name: 'Reporting', url: `${ezReportingUrl}/initiatives` },

      ],

      linkInformation: [
        {
          name: 'Home',
          url: peadminEzTracHome,
        }, {
          name: 'Participation QC',
          url: `${ezQcBaseUrl}/participation`,
        }, {
          name: 'Placeholder QC',
          url: `${ezQcBaseUrl}/placeholders`,
        }, {
          name: 'Initiative QC',
          url: `${ezQcBaseUrl}/initiative`,
        }, {
          name: 'Reporting',
          url: `${ezReportingUrl}/initiatives`,
        },
      ],
    }
  }

  componentWillMount() {
    this.checkReadWrite()
  }

  checkReadWrite() {
    const navLogic = userRolesUtil.hasWriteRole(this.props.user)
      ? this.state.linkInformation
      : this.state.readPermissionsLinkInformation
    this.setState({ assignNav: navLogic })
  }

  renderNav() {
    return map(this.state.assignNav, ( link, index ) => (
      <NavItem eventKey={index} href={link.url} key={index}>{link.name}</NavItem>
    ))
  }


  render() {
    return (
      <div>
        <Nav bsStyle="pills">
          {this.renderNav()}
        </Nav>
      </div>
    )
  }
}

export default Navbar
