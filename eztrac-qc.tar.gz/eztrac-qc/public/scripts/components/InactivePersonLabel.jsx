import React from 'react'

const InactivePersonLabel = () => (
  <span className="label label-danger inactive-label">
    Inactive Person
  </span>
)

export default InactivePersonLabel
