import React from 'react'
import { CSVLink } from 'react-csv'
import { Glyphicon } from 'react-bootstrap'

const CSVDownloadButton = ({ csvFileName, rows }) => (
  <CSVLink
    className="downloadButton"
    data={rows.map(row => ({
      currentTeams: row.currentTeams.map(currentTeam => currentTeam.teamName).join(', '),
      managerName: row.managerName,
      previousTeams: row.previousTeams.map(previousTeam => previousTeam.teamName).join(', '),
      reason: row.reason,
      userId: row.userId,
      userName: row.userName,
    }))}
    filename={csvFileName}
    headers={[
      { label: 'Manager', key: 'managerName' },
      { label: 'Name', key: 'userName' },
      { label: 'CWID', key: 'userId' },
      { label: 'Previous Teams', key: 'previousTeams' },
      { label: 'Current Teams', key: 'currentTeams' },
      { label: 'Reason', key: 'reason' },
    ]}
    target="_blank"
  >
    <Glyphicon glyph="glyphicon glyphicon-download-alt" />
  </CSVLink>
)

export default CSVDownloadButton
