import PropTypes from 'prop-types'
import React from 'react'

class SearchComponent extends React.Component {
  constructor( props ) {
    super(props)
    this.timer = null
    this.state = {
      searchAction: props.searchAction,
      searchText: props.searchText,
    }

    this.handleChange = this.handleChange.bind(this)
  }

  componentWillReceiveProps( nextProps ) {
    this.setState({
      searchAction: nextProps.searchAction,
      searchText: nextProps.searchText,
    })
  }

  handleChange({ target }) {
    clearTimeout(this.timer)
    window.sessionStorage.setItem('searchText', target.value)
    this.setState({ searchText: target.value })
    this.timer = setTimeout(() => { this.state.searchAction(target) }, 500)
  }

  render() {
    return (
      <div className="filter-search-options">
        <div className="input-group">
          <div className="input-group-addon">
            <span aria-hidden="true" className="glyphicon glyphicon-search" />
          </div>
          <input
            className="form-control"
            id="searchBox"
            onChange={this.handleChange}
            placeholder="Search..."
            type="search"
            value={this.state.searchText}
          />
        </div>
      </div>
    )
  }
}

export default SearchComponent

SearchComponent.propTypes = {
  searchAction: PropTypes.func,
  searchText: PropTypes.string,
}
