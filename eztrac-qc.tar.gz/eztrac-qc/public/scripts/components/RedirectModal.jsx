import { Button, Modal } from 'react-bootstrap'
import React from 'react'
import { PeoplePath } from './routes'

const redirect = url => {
  window.sessionStorage.setItem('deactivatePrevSite', PeoplePath)
  window.location.href = url
}

class FilterButton extends React.Component {
  constructor( props ) {
    super(props)
    this.state = {
      showModal: false,
    }
  }

  render() {
    return (
      <div>
        <Modal onHide={this.props.closeModal} show={this.props.show}>
          <Modal.Header closeButton>
            <Modal.Title>Redirect Required</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {`In order to complete this action, you will be redirected to
            ${this.props.app || this.props.url}.`}

            <br />
            Continue?
          </Modal.Body>
          <Modal.Footer>
            <Button className="btn btn-primary" onClick={() => redirect(this.props.url)}>OK</Button>
            <Button onClick={this.props.closeModal}>Cancel</Button>
          </Modal.Footer>
        </Modal>
      </div>
    )
  }
}
export default FilterButton
