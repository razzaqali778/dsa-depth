import React from 'react'
import map from 'lodash/map'


const ListLinkCell = ({
  generateText, generateUrl, listData, style, keyProp,
}) => (
  <span className="grid-cell" style={style}>
    <ul style={{ padding: '5px 0 0 10px' }}>
      {map(listData, (d, i) => {
        const text = generateText(d)
        const url = generateUrl(d)
        const height = 20

        return (
          <li
            key={keyProp + i}
            style={{
              height,
              whiteSpace: 'nowrap',
              overflowX: 'hidden',
              textOverflow: 'ellipsis',
              listStylePosition: 'inside',
            }}
          >
            <a href={url}>{text}</a>
          </li>
        )
      })}
    </ul>
  </span>
)

export default ListLinkCell
