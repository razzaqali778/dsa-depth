import { Glyphicon } from 'react-bootstrap'
import React from 'react'

const SortableHeader = ({
  text, setSortOrder, sortOrder, style,
}) => (
  <div className="grid-cell" style={{ ...style, padding: '10px' }}>
    <h4>
      {text}
      <Glyphicon
        aria-hidden="true"
        glyph="glyphicon glyphicon-sort"
        onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
        style={{ float: 'right', paddingRight: '20px' }}
      />
    </h4>
  </div>
)

export default SortableHeader
