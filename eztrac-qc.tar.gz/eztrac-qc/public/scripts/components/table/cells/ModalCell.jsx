import { Button, Glyphicon, Modal } from 'react-bootstrap'
import React from 'react'
import Select from 'react-select'
import getOrElse from 'lodash/get'
import isUndefined from 'lodash/isUndefined'

class ModalCell extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      showModal: false,
    }
    this.saveAndClose = this.saveAndClose.bind(this)
  }

  saveAndClose() {
    this.props.setReason(this.props.row, this.state.newReason)
    this.setState({ newReason: undefined, showModal: false })
  }

  render() {
    const reasonToShow = isUndefined(this.state.newReason) ? this.props.value : this.state.newReason
    const selectedTimeframe = this.props.row.timeFrameId

    return (
      <div className="grid-cell" style={this.props.style}>
        <Button
          disabled={getOrElse(this.props.timeframeMap[selectedTimeframe], 'lockdown', true)}
          onClick={() => this.setState({ showModal: true })}
          style={{ width: '100%', fontSize: '90%' }}
        >
          {this.props.value || <em>Add a reason...</em>}
          <Glyphicon glyph="pencil" style={{ float: 'right' }} />
        </Button>
        { this.state.showModal && (
          <Modal
            onHide={() => this.setState({ showModal: false, newReason: undefined })}
            show
            style={{ margin: '15% 0 0 0' }}
          >
            <Modal.Header>
              Select a reason for:
              {' '}
              <b>
                {this.props.row.userName}
                {' '}
              </b>
              for
              {' '}
              <b>{this.props.timeframeMap[selectedTimeframe].name}</b>
            </Modal.Header>
            <Modal.Body>
              <Select
                onChange={value => this.setState({ newReason: value })}
                options={this.props.options}
                placeholder="(No Reason)"
                value={reasonToShow}
              />
              <p id="reason-description">
                { reasonToShow
                  ? this.props.reasonDescriptionMap[getOrElse(reasonToShow, 'value', reasonToShow)]
                  : null }
              </p>
            </Modal.Body>
            <Modal.Footer>
              <Button onClick={() => this.setState({ showModal: false, newReason: undefined })}>Cancel</Button>
              <Button bsStyle="primary" onClick={this.saveAndClose}>Save</Button>
            </Modal.Footer>
          </Modal>
        ) }
      </div>
    )
  }
}
export default ModalCell
