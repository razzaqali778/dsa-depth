import React from 'react'

const TextCell = ({ text, style }) => (
  <div className="grid-cell" style={{ ...style, padding: '10px' }}><h4>{text}</h4></div>
)

export default TextCell
