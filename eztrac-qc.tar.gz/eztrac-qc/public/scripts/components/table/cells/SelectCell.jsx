import React from 'react'
import Select from 'react-select'

const SelectCell = ({
  onChange, style, options, value,
}) => (
  <div className="grid-cell" style={style}>
    <Select
      onChange={onChange}
      options={options}
      value={value}
    />
  </div>
)
export default SelectCell
