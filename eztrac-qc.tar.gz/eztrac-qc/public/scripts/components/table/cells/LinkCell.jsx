import React from 'react'

const LinkCell = ({
  url, text, style, children,
}) => (
  <div
    className="grid-cell"
    style={{ ...style, padding: '10px' }}
  >
    <a href={url}>{text}</a>
    {children}
  </div>
)

export default LinkCell
