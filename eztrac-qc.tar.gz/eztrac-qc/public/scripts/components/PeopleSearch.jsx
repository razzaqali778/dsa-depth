import React from 'react'
import Select from 'react-virtualized-select'
import createFilterOptions from 'react-select-fast-filter-options'
import map from 'lodash/map'

const getStorage = key => window.sessionStorage.getItem(key)


const getSelectOptions = allPeople => allPeople.length
  ? map(allPeople, person => {
    const { userName, userId } = person

    return {
      ...person,
      label: `${userName} (${userId})`,
      value: userId,
    }
  })
  : []

class PeopleSearch extends React.Component {
  constructor( props ) {
    super(props)
    this.state = {
      selectOptions: [],
      selectValue: JSON.parse(getStorage('selectedPerson')),
    }
    this.handleChange = this.handleChange.bind(this)
  }

  handleChange( val ) {
    if ( !val ) {
      this.setState({ selectValue: null })
      this.props.onChange(null)
    } else {
      const { label, value } = val
      this.setState({ selectValue: { label, value } })
      this.props.onChange(val)
    }
  }

  render() {
    const filterOptions = createFilterOptions({ options: getSelectOptions(this.props.allPeople) })

    return (
      <Select
        autofocus
        cache={false}
        className="modalSearchBar"
        filterOptions={filterOptions}
        onChange={this.handleChange}
        options={getSelectOptions(this.props.allPeople)}
        placeholder="Enter Name or ID"
        type="text"
        value={this.state.selectValue}
      />
    )
  }
}

export default PeopleSearch
