import { Route } from 'react-router'
import React from 'react'
import InitiativeQC from './initiative/InitiativeQC'
import People from './People'
import RootComponent from './RootComponent'
import TeamHistory from './TeamHistory'
import ForecastPeopleQC from './forecast/ForecastPeopleQC'

export const TeamHistoryPath = 'team-history'
export const PeoplePath = 'participation'

const routes = (
  <Route component={RootComponent} path="/ez-trac-qc">
    <Route component={People} path={PeoplePath} />
    <Route component={InitiativeQC} path="initiative" />
    <Route component={TeamHistory} path={TeamHistoryPath} />
    <Route component={ForecastPeopleQC} path="placeholders" />
  </Route>
)

export default routes
