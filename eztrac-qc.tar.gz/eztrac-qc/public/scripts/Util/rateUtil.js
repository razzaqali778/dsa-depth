import { get } from '../../../common/Agent'
import { authHeader } from '../windowUtils'

const getRateInfo = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/rate/costCalculations/`

export const getAllRates = async function f( userId, timeFrameId ) {
  const url = `${getRateInfo}${userId}?timeFrameId=${timeFrameId}`

  const tokenHeader = authHeader()
  const { body: rates } = await get(url, tokenHeader)

  return rates
}

export const getCostCalculations = async function f( userId, timeFrameId ) {
  try {
    const costResponse = await getAllRates( userId || null, timeFrameId || null )

    return costResponse
  } catch ( error ) {
    console.log(error) // eslint-disable-line no-console
  }

  return null
}
