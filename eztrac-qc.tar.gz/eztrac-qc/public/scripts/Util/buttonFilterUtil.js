import filter from 'lodash/filter'
import get from 'lodash/get'
import includes from 'lodash/includes'
import map from 'lodash/map'


export const getManagerHierarchy = ( userId, peopleList ) => {
  let newList = []
  map(peopleList, person => {
    if ( get(person, 'managerId', '').toLowerCase() === userId.toLowerCase() ) {
      newList.push(person.userId.toLowerCase())
      newList = newList.concat(getManagerHierarchy(person.userId, peopleList))
    }
  })

  return newList
}

export const filterUnderUserId = ( userId, totalPeopleDiscrepancies, subordinateList ) => filter(totalPeopleDiscrepancies, element => includes(subordinateList, element.userId.toLowerCase()))
