import cloneDeep from 'lodash/cloneDeep'
import indexOf from 'lodash/indexOf'
import { del, get, put } from '../../../../common/Agent'
import { renderToastrPopOver } from '../../components/utils/peopleUtils'
import { authHeader } from '../../windowUtils'

const getReasonsUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v2/reasons`
const deleteReasonUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/qc/discrepancy/`
const saveReasonUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/qc/discrepancy`

export const getAllReasons = async function f() {
  const tokenHeader = authHeader()
  const reasons = await get(getReasonsUrl, tokenHeader)

  return reasons.body
}

export const getReasons = async function f() {
  try {
    const reasonsResponse = await getAllReasons()

    return reasonsResponse
  } catch ( error ) {
    console.log(error) // eslint-disable-line no-console
  }

  return null
}

export const deleteReason = async discrepancy => {
  const modifiedDeleteUrl = `${deleteReasonUrl}${discrepancy.timeFrameId}/${discrepancy.userId}`
  try {
    const tokenHeader = authHeader()
    await del(modifiedDeleteUrl, tokenHeader)
    renderToastrPopOver(`Reason was deleted for: ${discrepancy.userName}.`, 'success')
  } catch ( error ) {
    renderToastrPopOver(`Reason was not deleted for: ${discrepancy.userName}.`, 'failure')
    console.log(error) // eslint-disable-line no-console

    return false
  }

  return true
}

export const saveReason = async discrepancy => {
  const { reason, userName } = discrepancy
  try {
    const tokenHeader = authHeader()
    await put( saveReasonUrl, discrepancy, tokenHeader)
    renderToastrPopOver(`Reason "${reason}" saved successfully for: ${userName}.`, 'success')

    return true
  } catch ( error ) {
    renderToastrPopOver(`Reason "${reason}" was not saved for: ${userName}.`, 'error')
    console.error('Failed to save reason: ', error) // eslint-disable-line no-console

    return false
  }
}

export const changeReason = async function f( currentDiscrepancy, val, userId, totalPeopleDiscrepancies ) {
  const people = cloneDeep(totalPeopleDiscrepancies)
  const discrepancyIndex = indexOf(totalPeopleDiscrepancies, currentDiscrepancy)

  const deletedReason = val === null
  const reason = deletedReason ? '' : val.value
  const isActive = { currentDiscrepancy }

  const discrepancy = {
    ...currentDiscrepancy,
    reason,
    lastUpdateUser: userId,
    isActive,
  }

  if ( discrepancyIndex !== -1 ) {
    people.splice(discrepancyIndex, 1, discrepancy)
  }

  try {
    if ( deletedReason ) {
      await deleteReason(discrepancy)
    } else {
      await saveReason(discrepancy, userId)
    }

    return people
  } catch ( error ) {
    console.log(error) // eslint-disable-line no-console

    return people
  }
}
