import find from 'lodash/find'

export const makeDeactivateUrl = (userId, reason, step = 2) =>
   `${window.phoenix.serviceBindings['ez-trac-workflows']}/deactivate-person?id=${encodeURIComponent(userId)}&reason=${encodeURIComponent(reason)}&step=${step}` // eslint-disable-line

export const shouldDeactivate = (reasons, reasonText) => {
  const reason = find(reasons, ({ reasonName }) => reasonName === reasonText)

  if ( reason && reason.deactivatable ) {
    return true
  }

  return false
}
