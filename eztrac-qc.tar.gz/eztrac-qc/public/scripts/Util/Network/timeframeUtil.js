import { fetch } from './fetchUtil'

const timeFrameUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/proxies/core-services/v2/timeframes`

export const getOffsetTimeframe = offset => fetch(`${timeFrameUrl}/current/offset/${offset}`)

export const getCurrentTimeframe = () => getOffsetTimeframe(0)

export const getCurrentAndNextTimeframes = async () => {
  const current = await getOffsetTimeframe(0)
  const next = await getOffsetTimeframe(1)

  return [ current, next ]
}

const monthsMap = {
  Jan: 'January',
  Feb: 'February',
  Mar: 'March',
  Apr: 'April',
  May: 'May',
  Jun: 'June',
  Jul: 'July',
  Aug: 'August',
  Sep: 'September',
  Oct: 'October',
  Nov: 'November',
  Dec: 'December',
}

export const getCurrentYearFutureTimeFrames = async () => {
  const currentMonth = new Date().getMonth()
  const timeframes = [ ...Array(12 - currentMonth).keys() ]

  return Promise.all(timeframes.map(tF => getOffsetTimeframe(tF))).then(
    timeFrames => timeFrames.map(tF => ({
      id: tF.id,
      month: monthsMap[tF.name.replace(/[0-9 ]/g, '')],
    })),
  )
}

export const getAllTimeframes = async () => fetch(timeFrameUrl)

export const getTimeframeNames = async function f() {
  const timeframes = await getAllTimeframes()

  return timeframes.map(timeframe => timeframe.name)
}

export const getNumTimeframes = async function f(currentTimeframeId, num) {
  const timeframesToBe = Array(Math.abs(num)).fill(0)
  const timeframePromises = timeframesToBe.map((item, ix) => getOffsetTimeframe(num < 0 ? ix : -ix))

  return Promise.all(timeframePromises)
}
