import { get } from '../../../../common/Agent'
import { authHeader } from '../../windowUtils'

export const fetch = async function f(url) {
  const tokenHeader = authHeader()
  const data = await get(url, tokenHeader)

  return data.body
}

export const fetchWithCatch = async function f(url) {
  try {
    const tokenHeader = authHeader()
    const data = await get(url, tokenHeader)

    return data.body
  } catch ( error ) {
    console.error(error)

    return []
  }
}
