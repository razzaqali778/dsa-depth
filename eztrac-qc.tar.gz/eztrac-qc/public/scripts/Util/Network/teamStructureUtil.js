import { fetchWithCatch } from './fetchUtil'

const servicesUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/proxies/core-services/v2`

export const getTeamStructure = () => fetchWithCatch(
  `${servicesUrl}/teamStructure`,
)

export const getPlatforms = () => fetchWithCatch(`${servicesUrl}/platforms`)

export const getCommunities = () => fetchWithCatch(`${servicesUrl}/communities`)
