import { get, put } from '../../../../common/Agent'
import { authHeader } from '../../windowUtils'

const archiveUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/archive`

export const archiveMonth = async timeframeId => {
  const namedArchiveUrl = `${archiveUrl}/${timeframeId}`
  const tokenHeader = authHeader()
  put(namedArchiveUrl, {}, tokenHeader)
}

export const getArchiveMonth = async timeframeId => {
  try {
    const namedArchiveUrl = `${archiveUrl}/${timeframeId}`
    const tokenHeader = authHeader()
    const archiveResponse = await get(namedArchiveUrl, tokenHeader)

    return archiveResponse.body
  } catch ( error ) {
    console.error(error)

    return []
  }
}
