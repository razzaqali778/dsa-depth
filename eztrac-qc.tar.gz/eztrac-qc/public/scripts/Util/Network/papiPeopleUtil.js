import { fetch } from './fetchUtil'

const servicesUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1`
const papiPeopleUrl = `${servicesUrl}/qc/people/papiPeople`
const inactivePeopleUrl = `${servicesUrl}/qc/people/inactivePeople`

export const getAllPeople = () => fetch(papiPeopleUrl)

export const getPeopleByTimeframe = timeframeId => fetch(`${servicesUrl}/qc/people/timeframe/${timeframeId}`)

export const getPreviousTeams = ( userId, timeframeId ) => fetch(`${servicesUrl}/people/all-teams-by-timeframe?timeFrameId=${timeframeId}&userId=${userId}`)

export const getInactivePeopleWithReasons = timeframeId => fetch(`${inactivePeopleUrl}?timeframeId=${timeframeId}`)
