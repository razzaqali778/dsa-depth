import { get } from '../../../../common/Agent'
import { authHeader } from '../../windowUtils'

export const getInitiativeIssues = async timeframeId => {
  try {
    const initUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/qc/initiative/timeframe/${timeframeId}` // eslint-disable-line max-len
    const tokenHeader = authHeader()
    const { body: initiatives } = await get(initUrl, tokenHeader)

    return initiatives
  } catch ( error ) {
    console.error(error)

    return []
  }
}
