
import intersection from 'lodash/intersection'
import profileClient from '@monsantoit/profile-client'

const hasEntitlements = (user, entitlements) => {
  if ( user && user.entitlements ) {
    const userEntitlements = user.entitlements.map(({ code }) => code)

    return intersection(userEntitlements, entitlements).length > 0
  }

  return false
}

const readEntitlements = [ 'eztrac-write-user', 'eztrac-read-user', 'eztrac-admin-user' ]
const writeEntitlements = [ 'eztrac-write-user', 'eztrac-admin-user' ]
const adminEntitlements = [ 'eztrac-admin-user' ]

const userRolesUtil = {
  async getUser() {
    try {
      const { getCurrentUser: user } = await
      profileClient.queryProfile(profileClient.queries.currentUserWithEntitlements('eztrac'))
      userRolesUtil.user = user

      return user
    } catch ( error ) {
      if ( window.phoenix.localDevelopment ) {
        userRolesUtil.user = { entitlements: [{ code: 'eztrac-read-user' }] }
      } else {
        userRolesUtil.user = { entitlements: [] }
      }

      return error
    }
  },

  hasReadRole: user => hasEntitlements(user || userRolesUtil.user, readEntitlements),
  hasWriteRole: user => hasEntitlements(user || userRolesUtil.user, writeEntitlements),
  hasAdminRole: user => hasEntitlements(user || userRolesUtil.user, adminEntitlements),
}


export default userRolesUtil
