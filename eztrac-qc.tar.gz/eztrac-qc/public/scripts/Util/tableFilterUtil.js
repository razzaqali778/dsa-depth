import filter from 'lodash/fp/filter'
import find from 'lodash/find'
import flatMap from 'lodash/flatMap'
import flow from 'lodash/flow'
import includes from 'lodash/includes'
import isArray from 'lodash/isArray'
import isPlainObject from 'lodash/isPlainObject'
import isUndefined from 'lodash/isUndefined'
import uniqBy from 'lodash/fp/uniqBy'
import values from 'lodash/values'

const determineString = value => {
  if ( isPlainObject(value) ) {
    return values(value).join(' ')
  } if ( isArray(value) ) {
    const flattened = flatMap(value, val => values(val))

    return flattened.join(' ')
  }


  return value
}
const filterTable = {
  filterPeople: ( searchText, initialList ) => {
    if ( isUndefined(searchText) || searchText.length === 0 ) {
      return initialList
    }

    return flow(
      filter(item => find(values(item), value => {
        const val = determineString(value)

        return val && includes(val.toString().toLowerCase(), searchText.toLowerCase())
      })),
      uniqBy(item => item.userId),
    )(initialList)
  },
}

export const { filterPeople } = filterTable
export default filterTable
