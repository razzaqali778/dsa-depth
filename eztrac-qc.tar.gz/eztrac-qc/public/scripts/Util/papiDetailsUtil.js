import gql from 'graphql-tag'
import createProfileClient from '../graphQL/createProfileClient'

const query = gql`
        query($userId: String!) {
            user: getUserById(id: $userId) {
                id
                preferredName { first last }
                email
                employeeType
                jobTitle
                manager {
                    id
                    preferredName { full }
                }
            }
        } 
    `

export default async userId => {
  const { data } = await createProfileClient().query({ query, variables: { userId } })
  let papiDetails = {}
  if ( data.user ) {
    papiDetails = {
      id: data.user.id,
      firstName: data.user.preferredName.first,
      lastName: data.user.preferredName.last,
      email: data.user.email,
      employeeType: data.user.employeeType,
      jobTitle: data.user.jobTitle,
      managerId: data.user.manager.id,
      managerName: data.user.manager.preferredName.full,
    }
  }

  return papiDetails
}
