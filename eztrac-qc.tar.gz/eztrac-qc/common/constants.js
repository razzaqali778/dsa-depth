export const DEFAULT_MANAGER = 'Manager not in Ez-trac'
