import each from 'lodash/each'
import promise from 'superagent-promise'
import superagent from 'superagent'

const http = promise(superagent, Promise)

const handleSuccess = response => response
const handleError = error => {
  console.error('agent call errored -- ', error)

  throw error
}

const setHeaders = ( request, headers ) => {
  request.set( 'Accepts', 'application/json' )
  request.set( 'Content-Type', 'application/json' )
  each(headers, ( value, key ) => {
    request.set( key, value )
  })

  return request
}
const getReq = ( url, headers ) =>
  setHeaders(http.get(url), headers)
    .then(handleSuccess)
    .catch(handleError)

export const get = async (url, headers, retryAmount = 0) => {
  try {
    return await getReq(url, headers)
  } catch ( err ) {
    if ( retryAmount ) {
      console.log(`GET ${url} failed, retrying -- ${retryAmount - 1} attempts left`)

      return get(url, headers, retryAmount - 1)
    }

    return Promise.reject(err)
  }
}

export const post = ( url, body, headers ) =>
  setHeaders(http.post(url, body), headers)
    .then(handleSuccess)
    .catch(handleError)
export const put = ( url, body, headers ) =>
  setHeaders(http.put(url, body), headers)
    .then(handleSuccess)
    .catch(handleError)

export const del = ( url, headers ) =>
  setHeaders(http.del(url), headers)
  .then(handleSuccess)
  .catch(handleError)

export const patch = ( url, body, headers ) =>
  setHeaders(http.patch(url, body), headers)
  .then(handleSuccess)
  .catch(handleError)

export default { get, put, post, del, patch }
