const webpack = require('webpack')
const CompressionPlugin = require('compression-webpack-plugin')
const path = require('path')

const isProd = process.env.NODE_ENV === 'production'

const getPlugins = () => {
  const plugins = []

  if ( isProd ) {
    plugins.push(new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: '"production"',
      },
    }))

    plugins.push(new webpack.IgnorePlugin({
      resourceRegExp: /regenerator|nodent|js-beautify/,
      contextRegExp: /ajv/,
    }))

    plugins.push(new CompressionPlugin({
      algorithm: 'gzip',
      filename: '[path][base].gz[query]',
      test: /\.jsx?$|\.css$|\.html$/,
    }))
  } else {
    plugins.push(new webpack.HotModuleReplacementPlugin())
  }

  return plugins
}

const getDevTool = () => isProd ? 'source-map' : 'cheap-module-source-map'
const getEntry = () => {
  const entry = []

  if ( !isProd ) {
    entry.push('webpack-hot-middleware/client')
  }

  entry.push('./public/scripts/main')

  return entry
}
module.exports = {
  devtool: getDevTool(),
  entry: getEntry(),
  module: {
    rules: [
      { test: /\.m?js$/, resolve: { fullySpecified: false } },
      { test: /\.jsx?$/, use: 'babel-loader', exclude: /node_modules/ },
      { test: /@?(mui).*\.(ts|js)x?$/, use: 'babel-loader' }
    ],
  },
  output: { filename: 'bundle.js', path: path.resolve(__dirname, 'public/scripts'), publicPath: '/ez-trac-qc/scripts' },
  plugins: getPlugins(),
  resolve: {
    extensions: [
      '.js',
      '.json',
      '.jsx',
      '.css',
      '.less',
    ],
  },
}
