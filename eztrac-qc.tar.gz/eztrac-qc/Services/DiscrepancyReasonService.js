import map from 'lodash/map'
import { getAllReasons, getReasonsByDeactivatable } from './dao/discrepancyReasonDao'

export const getDiscrepancyReasons = async ( req, res ) => {
  try {
    const reasons = await getAllReasons()

    return res.json(map(reasons, reason => reason.reason_name))
  } catch ( error ) {
    return res.status(500).send(error)
  }
}

export const fetchDiscrepancyReasons = async (req, res) => {
  const mapReasons = reasons => map(reasons, ({ reason_name, deactivatable, description }) => ({ reasonName: reason_name, deactivatable, description }))
  try {
    const { deactivatable } = req.query

    if ( deactivatable !== undefined ) {
      const reasons = await getReasonsByDeactivatable(deactivatable)

      return res.json(mapReasons(reasons))
    }
    const reasons = await getAllReasons()

    return res.json(mapReasons(reasons))
  } catch ( err ) {
    return res.status(500).json(err)
  }
}
