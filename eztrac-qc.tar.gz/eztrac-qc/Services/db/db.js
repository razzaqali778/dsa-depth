import config from '../../config'

const { Pool } = require('pg')

let pool

function getPool() {
  const dbConfig = config.get('ez-trac-qc-db')
  if ( !pool ) {
    pool = process.env.NODE_ENV === 'test' ? undefined : new Pool(dbConfig)
  }

  return pool
}

const queryWithResults = (queryStr, params) => getPool().connect()
  .then(client => client.query(queryStr, params)
    .then(result => result.rows)
    .catch(error => { throw error })
    .finally(client.release()))

const queryWithOneResult = (queryStr, params) => getPool().connect()
  .then(client => client.query(queryStr, params)
    .then(result => result.rows[0] )
    .catch(error => { throw error })
    .finally(client.release()))

const queryWithNoResult = (queryStr, params) => getPool().connect()
  .then(client => client.query(queryStr, params)
    .then(result => result )
    .catch(error => { throw error })
    .finally(client.release()))

const noop = () => null

const client = process.env.NODE_ENV === 'test'
  ? { any: noop, one: noop, none: noop }
  : { any: queryWithResults, one: queryWithOneResult, none: queryWithNoResult }

module.exports = client
