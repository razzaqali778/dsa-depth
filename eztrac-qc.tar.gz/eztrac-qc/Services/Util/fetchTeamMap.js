import reduce from 'lodash/reduce'
import config from '../../config'
import { get } from '../../common/Agent'
import { makeTokenHeaders } from './makeHeaders'

export default async teamIdList => {
  const coreUrl = config.get('ez-trac-urls').services['ez-trac-core']

  const headers = await makeTokenHeaders()
  const { body: teams } = await get(`${coreUrl}/v2/teams`, headers)

  const teamMap = reduce(teams, (memo, { id, name }) => {
    memo[id] = name // eslint-disable-line no-param-reassign

    return memo
  }, {})

  const retVal = reduce(teamIdList, (memo, val) => {
    memo[val] = teamMap[val] // eslint-disable-line no-param-reassign

    return memo
  }, {})

  return retVal
}
