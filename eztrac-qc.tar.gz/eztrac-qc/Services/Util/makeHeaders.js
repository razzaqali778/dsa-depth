import { getAzureToken } from './AzureTokenUtil'

const makeUserHeader = ( user = '' ) => {
  if ( process.env.NODE_ENV !== 'production' ) {
    return { 'user-id': process.env.USER }
  }

  if ( user !== '' ) {
    return { 'user-id': user }
  }

  return {}
}
const makeHeaders = (token, user = '') => ({
  Authorization: `Bearer ${token}`,
  ...makeUserHeader(user),
})

export const makeTokenHeaders = async (user = '') => {
  const token = await getAzureToken()

  return makeHeaders(token, user)
}

export default makeHeaders
