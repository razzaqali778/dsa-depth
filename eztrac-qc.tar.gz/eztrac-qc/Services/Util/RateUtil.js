import concat from 'lodash/concat'
import filter from 'lodash/filter'
import get from 'lodash/get'
import includes from 'lodash/includes'
import map from 'lodash/map'
import sumBy from 'lodash/sumBy'
import { getActivePeople } from './EZPeopleUtil'

const RateUtil = {
  async costCalculations( peopleList, userId ) {
    try {
      const papiPeople = await getActivePeople()
      const directSubordinatesList = RateUtil.getDirectSubordinates(papiPeople, userId)
      const totalCostUnderCurrentUser = RateUtil.totalUnderX(userId, peopleList, papiPeople)
      const totalCost = RateUtil.totalForUsers(peopleList)
      const totalSubordinateCosts = RateUtil.assignCostDirectSubordinates(directSubordinatesList, peopleList, papiPeople)

      return {
        totalCost: Math.ceil(totalCost / 1000) * 1000,
        managerCost: Math.ceil(totalCostUnderCurrentUser / 1000) * 1000,
        subordinateNames: totalSubordinateCosts.subordinateNames,
        costs: totalSubordinateCosts.theCosts,
        percentCosts: totalSubordinateCosts.percentCosts,
      }
    } catch ( err ) { console.log('Error: ', err) } // eslint-disable-line no-console

    return null
  },

  totalForUsers: users => {
    const monthlyHours = 160

    const totalArray = map(users, user => {
      if ( user.totalParticipationInTimeFrame !== undefined ) {
        return ((user.rateValue * Math.abs(user.totalParticipationInTimeFrame - 100)) / 100) * monthlyHours
      }

      return user.rateValue * monthlyHours
    })

    return totalArray.reduce(( acc, val ) => acc + val, 0)
  },

  totalUnderX: ( userId, missingPeople, papiPeople ) => {
    const peopleWeCareAbout = RateUtil.getManagerHierarchy(userId, papiPeople)

    const usersUnderX = filter(missingPeople, element => includes(peopleWeCareAbout, element.userId.toLowerCase()))

    return RateUtil.totalForUsers(usersUnderX)
  },

  getDirectSubordinates: ( papiPeople, managerId ) => {
    const directSubordinates = []

    map(papiPeople, person => {
      if ( person.managerId ) {
        if ( person.managerId.toUpperCase() === managerId.toUpperCase() ) {
          directSubordinates.push(person)
        }
      }
    })

    return directSubordinates
  },

  assignCostDirectSubordinates: ( subordinates, missingPeople, papiPeople ) => {
    const subordinateList = map(subordinates, currentSub => {
      const currentSubordinate = { ...currentSub }
      currentSubordinate.cost = RateUtil.totalUnderX(currentSubordinate.userId, missingPeople, papiPeople)

      return currentSubordinate
    })

    const totalCostOfSubordinates = sumBy(subordinateList, person => person.cost)

    const subordinatesWithPercentageAndCost = map(subordinateList, sub => {
      const subordinate = { ...sub }
      subordinate.percentageCost = Math.round(subordinate.cost / totalCostOfSubordinates) * 100

      return subordinate
    })

    const costList = []
    const percentList = []
    const personList = []
    map(subordinatesWithPercentageAndCost, person => {
      if ( person.cost > 0 ) {
        personList.push(person.userName)
        costList.push(person.cost)
        percentList.push(person.percentageCost)
      }
    })

    const newObject = {
      subordinateNames: personList,
      theCosts: costList,
      percentCosts: percentList,
    }

    return newObject
  },

  getManagerHierarchy: ( userId, papiPeople ) => {
    let newList = []
    map(papiPeople, person => {
      if ( get(person, 'managerId', '').toLowerCase() === userId.toLowerCase() ) {
        newList.push(person.userId.toLowerCase())
        newList = concat(newList, RateUtil.getManagerHierarchy(person.userId, papiPeople))
      }
    })

    return newList
  },
}
module.exports = RateUtil
