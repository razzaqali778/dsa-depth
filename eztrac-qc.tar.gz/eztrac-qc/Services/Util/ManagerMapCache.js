import NodeCache from 'node-cache'
import winston from 'winston'
import { fetchAllEztracPeople } from './EZPeopleUtil'
import { fetchManagerMap } from './fetchPapiMaps'
import { get } from '../../common/Agent'
import { getAzureToken } from './AzureTokenUtil'

const makeHeaders = token => ({
  Authorization: `Bearer ${token}`,
  ...process.env.NODE_ENV !== 'production' ? { 'user-id': process.env.USER } : {},
})

export const managerMapCache = new NodeCache()

export const setManagerMapCache = async () => {
  winston.info('Setting manager map cache')
  try {
    const people = await fetchAllEztracPeople()
    const peopleIds = people.map(p => p.userId || p.personId)
    const managerMapPromise = fetchManagerMap(peopleIds)

    managerMapCache.set('managerMap', managerMapPromise)

    return managerMapPromise
  } catch ( err ) {
    winston.error('Error setting manager map cache: ', err)
    throw err
  }
}

export const getManagerMapFromNP = async () => {
  try {
    const token = await getAzureToken()
    const headers = makeHeaders(token)
    const { body: people } = await get('https://velocity-np.ag/ez-trac-qc/services/v1/manager-map', headers)

    return people
  } catch ( err ) {
    winston.error('Error getting manager map from nonprod: ', err)

    return {}
  }
}

export const getManagerMapFromCache = async () => {
  try {
    const cachedMapPromise = managerMapCache.get('managerMap')
    if ( !(cachedMapPromise) ) {
      return setManagerMapCache()
    }
    const managerMap = await cachedMapPromise
    if ( !managerMap ) { return await setManagerMapCache() }

    return managerMap
  } catch ( err ) {
    console.log('Error getting map from cache: ', err)
    throw err
  }
}

export const getManagerMap = async () => {
  if ( process.env.NODE_ENV !== 'production' ) {
    return getManagerMapFromNP()
  }

  return getManagerMapFromCache()
}

export const getManagerMapEndpoint = async ( req, res ) => {
  try {
    const managerMap = await getManagerMapFromCache()

    res.json(managerMap)
  } catch ( err ) {
    res.status(500).json(err)
  }
}

export const rebuildManagerMapCache = () => {
  managerMapCache.flushAll()
  setManagerMapCache()
}
