import filter from 'lodash/fp/filter'
import flow from 'lodash/flow'
import getOrElse from 'lodash/get'
import groupBy from 'lodash/fp/groupBy'
import map from 'lodash/fp/map'
import reduce from 'lodash/reduce'
import sortBy from 'lodash/fp/sortBy'
import sumBy from 'lodash/sumBy'

export const findInitiativeIssues = (teamList, initiativeList, teamMap) => {
  const initiativeMap = reduce(initiativeList, (memo, { id, status, initiativeName }) => {
    memo[id] = { status, name: initiativeName } // eslint-disable-line no-param-reassign

    return memo
  }, {})

  return flow(
    groupBy('teamId'),
    map(teamGroup => {
      const sum = sumBy(
        teamGroup,
        ({ initiativeId, percentageOfTeamCost }) => initiativeMap[initiativeId].status.toLowerCase() === 'funded' ? percentageOfTeamCost : 0,
      )
      const teamId = getOrElse(teamGroup[0], 'teamId', 'UNKNOWN')

      return sum === 100 ? false : {
        teamId,
        teamName: getOrElse(teamMap, teamId, 'UNKNOWN'),
        allocations: map(({ initiativeId, percentageOfTeamCost }) => ({
          initiativeId,
          percentageOfTeamCost,
          status: initiativeMap[initiativeId].status,
          name: initiativeMap[initiativeId].name,
        }), teamGroup),
      }
    }),
    filter(t => t),
    sortBy(obj => obj.teamName),
  )(teamList)
}
