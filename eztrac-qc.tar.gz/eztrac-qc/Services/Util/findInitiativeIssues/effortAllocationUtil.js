import { extractUserId } from '../extractRequestData'
import config from '../../../config'
import { findInitiativeIssues } from './findIssues'
import { get } from '../../../common/Agent'
import { makeTokenHeaders } from '../makeHeaders'
import fetchTeamMap from '../fetchTeamMap'
import log from '../logger'

export const getEffortAllocation = async (timeframe, user) => {
  const coreUrl = config.get('ez-trac-urls').services['ez-trac-core']
  try {
    const effortAllocationsUrl = `${coreUrl}/v2/efforts/allocations/timeframes/${timeframe}`
    const headers = await makeTokenHeaders(user)
    const { body: allocationList } = await get(effortAllocationsUrl, headers)

    return allocationList
  } catch ( err ) {
    log.error('Error getting effort allocations -- ', err)

    throw err
  }
}
export const getInitiativeList = async user => {
  const vipUrl = config.get('ez-trac-urls').services['ez-trac-vip']
  try {
    const initiativesUrl = `${vipUrl}/v2/initiatives`
    const headers = await makeTokenHeaders(user)
    const { body: initiativeList } = await get(initiativesUrl, headers)

    return initiativeList
  } catch ( err ) {
    log.error('Error getting initiative list -- ', err)

    throw err
  }
}

export const getEffortAllocationIssues = async (req, res) => {
  try {
    const user = extractUserId(req)
    const effortAllocationPromise = getEffortAllocation(req.params.timeFrameId, user)
    const initiativeListPromise = getInitiativeList(user)
    const effortAllocation = await effortAllocationPromise
    const teamIdList = effortAllocation.map(({ teamId }) => teamId)

    const teamMap = await fetchTeamMap(teamIdList)

    const initiativeList = await initiativeListPromise
    const issues = findInitiativeIssues(effortAllocation, initiativeList, teamMap)

    return res.json(issues)
  } catch ( error ) {
    log.error('Error getting allocation issues -- ', error)

    return res.status(500).json(error)
  }
}
