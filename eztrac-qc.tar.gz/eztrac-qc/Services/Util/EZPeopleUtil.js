import NodeCache from 'node-cache'
import filter from 'lodash/filter'
import isEmpty from 'lodash/isEmpty'
import isUndefined from 'lodash/isUndefined'
import winston from 'winston'
import config from '../../config'
import { get } from '../../common/Agent'
import { getManagerMap } from './ManagerMapCache'
import { getAzureToken } from './AzureTokenUtil'
import logger from './logger'
import makeHeaders from './makeHeaders'

const peopleCache = new NodeCache({ stdTTL: 0, checkperiod: 0 })
export const fetchPersonById = async userId => {
  const costingServices = config.get('ez-trac-urls').services['ez-trac-costing']
  const token = await getAzureToken()
  const headers = makeHeaders(token)
  const { body: person } = await get(`${costingServices}/v1/person/${userId}`, headers)

  return person
}
export const fetchAllEztracPeople = async () => {
  const costingServices = config.get('ez-trac-urls').services['ez-trac-costing']
  const peopleUrl = `${costingServices}/v1/people`
  try {
    const token = await getAzureToken()
    const headers = makeHeaders(token)
    const { body: people } = await get(peopleUrl, headers)
    if ( isEmpty(people) ) { throw new Error('People result is empty') }

    return people
  } catch ( err ) {
    winston.error('Error fetching people from costing services: ', err)
    throw err
  }
}
export const fetchActiveEztracPeople = async () => {
  const costingServices = config.get('ez-trac-urls').services['ez-trac-costing']
  const peopleUrl = `${costingServices}/v1/people`
  try {
    const token = await getAzureToken()
    const headers = makeHeaders(token)
    const { body: people } = await get(`${peopleUrl}?isActive=true`, headers)

    if ( isEmpty(people) ) { throw new Error('People result is empty') }

    return people
  } catch ( err ) {
    winston.error('Error fetching people from costing services: ', err)
    throw err
  }
}

const setPeopleCache = () => {
  const peoplePromise = fetchAllEztracPeople()

  peopleCache.set('people', peoplePromise)

  return peoplePromise
}

export const getPeopleFromCache = async () => {
  const cachedPeoplePromise = peopleCache.get('people')
  if ( isUndefined(cachedPeoplePromise) ) {
    winston.log('Setting people cache')

    return setPeopleCache()
  }

  return cachedPeoplePromise
}

const mapPeople = async peopleList => {
  const managerMap = await getManagerMap()

  return peopleList.map(({
    personId,
    rateName,
    personName,
    isActive,
  }) => ({
    userId: personId,
    userName: personName || personId,
    rateName,
    isActive,
    managerId: managerMap[personId] || 'UNKNOWN',
  }))
}

export const filterPeople = ( peopleList, activeFlag ) => filter(peopleList, person => person.isActive === activeFlag)

export const getAllPeople = async () => {
  const now = require('performance-now') // eslint-disable-line global-require
  const start = now()
  const ezTracPeople = await fetchAllEztracPeople()
  logger.log(`fetched people in: ', ${now() - start}`)

  const mappedPeeps = mapPeople(ezTracPeople)

  return mappedPeeps
}

export const getActivePeople = async () => {
  const people = await getAllPeople()

  return filterPeople(people, true)
}
