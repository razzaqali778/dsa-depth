import { CronJob } from 'cron'
import { automateMessages } from '../MessageService'
import { rebuildManagerMapCache } from './ManagerMapCache'

export const buildMidnightJob = ( onTick, days = '1-5' ) => new CronJob({
  cronTime: `0 0 0 * * ${days}`, // 0th second, 0th minute, 0th hour, any day of month, any month, only Monday-Friday
  onTick,
  timeZone: 'America/Chicago',
  start: true,
})

export const messageJob = () => buildMidnightJob(automateMessages)
export const managerMapJob = () => buildMidnightJob(rebuildManagerMapCache, '*')
