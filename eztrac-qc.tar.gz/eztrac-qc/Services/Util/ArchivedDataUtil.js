import { combineParticipationDiscrepancies } from './findParticipationIssues/combineParticipationDiscrepancies'
import { getArchivedDataByTimeframe, upsertArchivedDataByTimeframe } from '../dao/archivedDataDao'

export const putArchivedData = async ( req, res ) => {
  const { timeframeId } = req.params
  const timeframeAsInt = parseInt(timeframeId, 10)
  if ( isNaN(timeframeAsInt) ) {
    return res.status(400).json('Invalid timeframeId type')
  }
  try {
    const list = await combineParticipationDiscrepancies(timeframeAsInt)
    await upsertArchivedDataByTimeframe(timeframeAsInt, JSON.stringify(list))

    return res.json('OK')
  } catch ( error ) {
    return res.status(500).json(`Promise rejected by pg. Error: ${JSON.stringify(error)}`)
  }
}
export const fetchArchivedData = async (req, res ) => {
  const { timeframeId } = req.params
  const timeframeAsInt = parseInt(timeframeId, 10)
  if ( isNaN(timeframeAsInt) ) {
    return res.status(400).json('Invalid timeframeId type')
  }
  try {
    const result = await getArchivedDataByTimeframe(timeframeAsInt)

    return res.json(result)
  } catch ( error ) {
    return res.status(500).json(`Fetch promise rejected by pg. Error: ${JSON.stringify(error)}`)
  }
}
