import Moment from 'moment'
import find from 'lodash/find'
import config from '../../config'
import { get } from '../../common/Agent'
import { getAzureToken } from './AzureTokenUtil'

const makeHeaders = token => ({
  Authorization: `Bearer ${token}`,
  ...process.env.NODE_ENV !== 'production' ? { 'user-id': process.env.USER } : {},
})

export const getOffsetTimeframe = async offset => {
  const url = config.get('ez-trac-urls').services['ez-trac-core']
  const token = await getAzureToken()
  const headers = makeHeaders(token)
  const { body: tf } = await get(`${url}/v2/timeframes/current/offset/${offset}`, headers)

  return tf
}

export const getAllTimeframes = async () => {
  const url = config.get('ez-trac-urls').services['ez-trac-core']
  const token = await getAzureToken()
  const headers = makeHeaders(token)
  const { body: tfs } = await get(`${url}/v2/timeframes`, headers)

  return tfs
}

export const getPreviousTimeframe = async timeFrameId => {
  const allTimeframes = await getAllTimeframes()
  // Core returns timeframe ids as strings; coerce so number/string both match.
  const targetId = Number(timeFrameId)
  const tf = find(allTimeframes, ({ id }) => Number(id) === targetId)

  if ( !tf ) {
    throw { status: 404, message: `Unable to find time frame with id ${timeFrameId}` } // eslint-disable-line no-throw-literal
  }

  const startDate = new Moment(tf.startDate).subtract(1, 'months')
  const endDate = new Moment(tf.endDate).subtract(1, 'months')

  const tfIWant = find(allTimeframes, t => {
    const start = new Moment(t.startDate)
    const end = new Moment(t.endDate)

    return end.isAfter(startDate) && start.isBefore(endDate)
  })

  if ( !tfIWant ) {
    throw { status: 404, message: `Unable to find previous time frame for id ${timeFrameId}` } // eslint-disable-line no-throw-literal
  }

  return tfIWant
}

export default () => getOffsetTimeframe(0)
