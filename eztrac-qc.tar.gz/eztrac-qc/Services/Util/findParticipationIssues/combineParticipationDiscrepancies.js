import concat from 'lodash/concat'
import map from 'lodash/map'
import uniqBy from 'lodash/uniqBy'
import { convertObjects, filterInactiveWithoutReasons } from '../PeopleUtil'
import {
  fetchDataForDiscrepancies,
  fetchMaps,
} from './fetchDataForDiscrepancies'
import findParticipationIssues from './findParticipationIssues'
import getTeamIdList from './getTeamIdList'
import logger from '../logger'

const now = require('performance-now')

export const combineParticipationDiscrepancies = async timeFrameId => { // eslint-disable-line max-statements
  try {
    const start = now()
    const {
      peopleWithReasons,
      allPeople,
      effortMembers,
      previousEffortMembers,
      previousTimeFrameId,
      rateValue,
    } = await fetchDataForDiscrepancies(timeFrameId)
    logger.log(`Fetched all data in : ${now() - start}`)
    const {
      people: peopleWithDiscrepancies,
      effortMap,
      previousEffortMap,
    } = findParticipationIssues({
      allPeople,
      effortMembers,
      previousEffortMembers,
    })
    const inactivePeopleWithReasons = filterInactiveWithoutReasons(allPeople, peopleWithReasons)

    const people = uniqBy(
      concat(peopleWithDiscrepancies, inactivePeopleWithReasons),
      person => person.userId || person.userId,
    )

    const peopleIds = map(people, ({ userId }) => userId)
    const teamIds = getTeamIdList(peopleIds, effortMap, previousEffortMap)
    const mapStart = now()
    const { teamMap, managerMap } = await fetchMaps({ teamIds })
    logger.log(`Fetched maps in: ${now() - mapStart} -- total: ${now() - start}`)
    const o = convertObjects({
      peopleWithDiscrepancies: people,
      allPeople,
      peopleWithReasons,
      teamMap,
      managerMap,
      effortMap,
      previousEffortMap,
      timeFrameId,
      previousTimeFrameId,
      rateValue,
    })

    logger.log(`Total time to fetch and map data: ${now() - start}`)

    return o
  } catch ( error ) {
    console.log('Error getting data for combining discrepancies -- ', error)
    throw error
  }
}
