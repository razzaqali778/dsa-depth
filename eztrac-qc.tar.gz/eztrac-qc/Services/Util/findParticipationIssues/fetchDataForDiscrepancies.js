import config from '../../../config'
import { get } from '../../../common/Agent'
import { getAllPeople } from '../EZPeopleUtil'
import { getDiscrepancyByTimeFrameId } from '../../dao/personDiscrepancyDao'
import { getManagerMap } from '../ManagerMapCache'
import { getPreviousTimeframe } from '../getCurrentTimeframe'
import fetchTeamMap from '../fetchTeamMap'
import logger from '../logger'
import makeHeaders from '../makeHeaders'
import { getAzureToken } from '../AzureTokenUtil'

const now = require('performance-now')

export const getRate = async () => {
  const costingUrl = config.get('ez-trac-urls').services['ez-trac-costing']
  const ezTracRateUrl = `${costingUrl}/v1/rates?active=true`
  const token = await getAzureToken()
  const rate = await get(ezTracRateUrl, makeHeaders(token))

  return rate.body
}

export const getStandardRate = async () => {
  const costingUrl = config.get('ez-trac-urls').services['ez-trac-costing']
  const token = await getAzureToken()
  const url = `${costingUrl}/v1/rate/STANDARD`
  const rate = await get(url, makeHeaders(token))

  return rate.body
}

const getEffortMembers = async (timeFrameId, headers) => {
  const coreUrl = config.get('ez-trac-urls').services['ez-trac-core']
  const start = now()
  const url = `${coreUrl}/v2/efforts/timeframes/${timeFrameId}`
  const { body: members } = await get(url, headers)
  logger.log(`Fetched effort members for timeframeId ${timeFrameId} in ${now() - start}`)

  return members
}

export const fetchDataForDiscrepancies = async timeFrameId => {
  const token = await getAzureToken()
  const headers = makeHeaders(token)

  const { id: previousTimeFrameId } = await getPreviousTimeframe(timeFrameId)


  const peoplePromise = getAllPeople()
  const currentEffortMembersPromise = getEffortMembers(timeFrameId, headers)
  const previousEffortMembersPromise = getEffortMembers(previousTimeFrameId, headers)
  const peopleWithReasonsPromise = getDiscrepancyByTimeFrameId(timeFrameId)
  const standardRatePromise = getStandardRate()

  const effortMembers = await currentEffortMembersPromise
  const previousEffortMembers = await previousEffortMembersPromise
  const peopleWithReasons = await peopleWithReasonsPromise
  const allPeople = await peoplePromise
  const { hourlyRate: rateValue } = await standardRatePromise

  return {
    peopleWithReasons,
    allPeople,
    effortMembers,
    previousEffortMembers,
    previousTimeFrameId,
    rateValue,
  }
}

export const fetchMaps = async ({ teamIds }) => {
  const teamMapPromise = fetchTeamMap(teamIds)
  // const managerMapPromise = fetchManagerMap(peopleIds)
  const managerMapPromise = getManagerMap()


  const teamMap = await teamMapPromise
  const managerMap = await managerMapPromise

  return { teamMap, managerMap }
}
