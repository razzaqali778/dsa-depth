import concat from 'lodash/concat'
import flatMap from 'lodash/flatMap'
import getOrElse from 'lodash/get'
import map from 'lodash/map'
import uniq from 'lodash/uniq'

const getTeamIdList = (peopleIdList, effortMap, previousEffortMap) => {
  const getTeams = personId => {
    const mapFun = ({ teamId }) => teamId

    const currentTeams = map(getOrElse(effortMap, `${personId}.teams`, []), mapFun)
    const previousTeams = map(getOrElse(previousEffortMap, `${personId}.teams`, []), mapFun)

    return uniq(concat(currentTeams, previousTeams))
  }

  const list = uniq(flatMap(peopleIdList, personId => getTeams(personId))).sort()

  return list
}

export default getTeamIdList
