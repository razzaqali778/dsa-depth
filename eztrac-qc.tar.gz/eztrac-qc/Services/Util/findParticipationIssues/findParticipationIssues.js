import concat from 'lodash/concat'
import differenceBy from 'lodash/differenceBy'
import flow from 'lodash/flow'
import fpFilter from 'lodash/fp/filter'
import fpKeys from 'lodash/fp/keys'
import intersectionBy from 'lodash/intersectionBy'
import isUndefined from 'lodash/isUndefined'

const makeParticipationMap = (list1, list2 = []) => {
  const mapFun = ({ teamId, userId, percent }) => ({
    teamId,
    userId,
    percent: isUndefined(percent) ? 100 : percent,
  })

  const list = concat(list1.map(mapFun), list2.map(mapFun))

  return list.reduce((memo, { teamId, userId, percent }) => {
    const newObj = { teamId, percent }
    if ( memo[userId] ) {
      memo[userId].teams.push(newObj)
      memo[userId].total = memo[userId].total + percent // eslint-disable-line no-param-reassign,operator-assignment
    } else {
      memo[userId] = { teams: [ newObj ], total: percent } // eslint-disable-line no-param-reassign
    }

    return memo
  }, {})
}

const findIssues = participationMap => flow(
  fpKeys,
  fpFilter(user => {
    const { total } = participationMap[user]

    return total < 95 || total > 100
  }),
)(participationMap)

const findOverUnderIssues = (allPeople, participationMap) => {
  const peopleWithIssues = findIssues(participationMap)

  return intersectionBy(allPeople, peopleWithIssues, p => {
    if ( typeof p === 'string' ) {
      return p
    }

    return p.personId || p.userId
  })
}

export const findOverUnderParticipation = (allPeople, effortMembers = []) => {
  const participationMap = makeParticipationMap(effortMembers)

  return findOverUnderIssues(allPeople, participationMap)
}

export const findNotAllocated = (allPeople, effortMembers = []) => {
  const activePeople = fpFilter(
    ({ isActive }) => isActive,
    allPeople,
  )
  const difference = differenceBy(
    activePeople,
    effortMembers,
    ({ userId = '', personId = '' }) => userId.toUpperCase() || personId.toUpperCase(),
  )

  return difference
}

export default ({
  allPeople, effortMembers, previousEffortMembers,
}) => {
  const effortMap = makeParticipationMap(effortMembers)
  const previousEffortMap = makeParticipationMap(previousEffortMembers)
  const people = concat(
    findOverUnderIssues(allPeople, effortMap),
    findNotAllocated(allPeople, effortMembers),
  )

  return ({
    people,
    effortMap,
    previousEffortMap,
  })
}
