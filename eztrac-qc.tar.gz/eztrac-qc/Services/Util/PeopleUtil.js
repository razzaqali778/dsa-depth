import filter from 'lodash/filter'
import find from 'lodash/find'
import getOrElse from 'lodash/get'
import map from 'lodash/map'
import { DEFAULT_MANAGER } from '../../common/constants'
import config from '../../config'
import { get } from '../../common/Agent'
import fetchTeamMap from './fetchTeamMap'
import makeHeaders from './makeHeaders'
import { getAzureToken } from './AzureTokenUtil'

export const assignManagerName = ( personId, allPeople ) => {
  const person = find(allPeople, p => p.userId === personId)

  if ( person && person.manager ) {
    const manager = find(allPeople, ({ userId }) => userId === person.manager )

    return manager ? [ manager.userName, person.manager ] : [ person.manager, person.manager ]
  }

  return [ DEFAULT_MANAGER, '' ]
}
export const getAllTeamsForPersonAndTimeframe = async ( userId, timeFrameId ) => {
  const { services: { 'ez-trac-core': coreUrl } } = config.get('ez-trac-urls')
  const token = await getAzureToken()
  const effortTeamUrl = `${coreUrl}/v2/efforts/timeframes/${timeFrameId}/user/${userId}`
  const effortTeamPromise = get(effortTeamUrl, makeHeaders(token))

  const { body: effortTeams } = await effortTeamPromise
  const teamIdList = effortTeams.map(({ teamId }) => teamId)
  const teamMap = await fetchTeamMap(teamIdList)

  return {
    effortTeams: effortTeams.map(t => ({ ...t, teamName: teamMap[t.teamId] })),
  }
}

const findPerson = (allPeople, id) => find(allPeople, ({ userId }) => userId === id)
const getManagerInfo = (allPeople, userId, managerMap) => {
  const managerId = getOrElse(managerMap, userId, '')

  if ( managerId ) {
    const manager = findPerson(allPeople, managerId)

    return {
      managerId,
      managerName: getOrElse(manager, 'userName', DEFAULT_MANAGER),
    }
  }

  return { managerId: 'UNKNOWN', managerName: DEFAULT_MANAGER }
}
export const convertObjects = async ({
  peopleWithDiscrepancies,
  allPeople,
  peopleWithReasons,
  managerMap,
  teamMap,
  effortMap,
  previousEffortMap,
  timeFrameId,
  previousTimeFrameId,
  rateValue,
}) => map(peopleWithDiscrepancies, person => {
  const id = person.personId || person.userId
  const discrepancyReason = find(peopleWithReasons, { user_id: person.userId })
  const reason = getOrElse(discrepancyReason, 'reason_name', '')
  const lastUpdateUser = getOrElse(discrepancyReason, 'last_updated_user_id', '')
  const { managerId, managerName } = getManagerInfo(allPeople, id, managerMap)

  return ({
    ...person,
    rateValue, // Setting Standard Rate
    isActive: getOrElse(person, 'isActive', true),
    reason,
    lastUpdateUser,
    previousTeams: getOrElse(previousEffortMap, `${id}.teams`, [])
      .map(t => ({ ...t, timeFrameId: previousTimeFrameId, teamName: teamMap[t.teamId] || t.teamId })),
    currentTeams: getOrElse(effortMap, `${id}.teams`, [])
      .map(t => ({ ...t, timeFrameId, teamName: teamMap[t.teamId] || t.teamId })),
    timeFrameId,
    managerId,
    managerName,
  })
})

export const filterInactiveWithoutReasons = ( peopleInCache, peopleInDatabase ) => filter(peopleInCache, cachePerson => find(peopleInDatabase, dbPerson => dbPerson.user_id === cachePerson.userId ))

export const getInactivePeopleWithReasons = async ( peopleInCache, peopleInDatabase, allPeople ) => convertObjects(
  filterInactiveWithoutReasons(peopleInCache, peopleInDatabase),
  allPeople,
  peopleInDatabase,
)


export default ({
  getAllTeamsForPersonAndTimeframe,
  assignManagerName,
  convertObjects,
})
