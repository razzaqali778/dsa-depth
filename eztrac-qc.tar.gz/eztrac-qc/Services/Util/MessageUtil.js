import each from 'lodash/each'
import filter from 'lodash/filter'
import groupBy from 'lodash/groupBy'
import { DEFAULT_MANAGER } from '../../common/constants'
import {
  combineParticipationDiscrepancies,
} from './findParticipationIssues/combineParticipationDiscrepancies'
import config from '../../config'
import { post } from '../../common/Agent'
import logger from './logger'

const azureTokenUtil = require('./AzureTokenUtil')

const MessageUtil = {
  async getManagerGroupedPeopleWithoutReasons( timeframeId ) {
    const allPeople = await combineParticipationDiscrepancies(timeframeId)
    const unallocatedPeople = filter(
      allPeople,
      ({ reason, managerName }) => reason === '' && managerName !== DEFAULT_MANAGER,
    )

    return groupBy(unallocatedPeople, 'managerId')
  },
  async sendVelocityMessage( manager, peopleList ) {
    try {
      const velocityMessageUrl = `${config.get('messaging-url')}/v5/messages`
      const qcParticipationLink = `https://${config.get('peadmin-home').value}/ez-trac-qc/participation?showUnderMe=true`
      const token = await azureTokenUtil.getAzureToken()
      const link = 'Ez-trac Participation QC'.link(qcParticipationLink)
      const { managerName } = peopleList[0]
      const numberPeople = peopleList.length > 1 ? 'people' : 'person'
      const message = `${managerName}, you have ${peopleList.length} unallocated ${numberPeople}.`
      const markdown = `${message} ${link}`
      const velocityMessage = {
        title: 'Unallocated people in EZ-Trac',
        recipients: [ manager ],
        body: {
          text: message,
          markdown,
        },
        tags: [ 'Ez Trac' ],
      }
      if ( !velocityMessageUrl.includes('-np') ) {
        logger.log(`POSTing message for ${manager} -- ${message}`)
        await post(velocityMessageUrl, velocityMessage, { Authorization: `Bearer ${token}` })
      } else {
        logger.log(`NOT POSTing message for ${manager} -- ${message} -- qc link ${qcParticipationLink}`)
      }

      return {}
    } catch ( error ) {
      return error
    }
  },
  async sendUnallocatedMessages( timeframeId ) {
    const unallocatedPeopleList = await MessageUtil.getManagerGroupedPeopleWithoutReasons(timeframeId)

    each(unallocatedPeopleList, ( unallocatedPeople, managerId ) => {
      MessageUtil.sendVelocityMessage(managerId, unallocatedPeople)
    })
  },
}
module.exports = MessageUtil
