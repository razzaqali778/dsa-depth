const winston = require('winston')

const appName = 'ez-trac-qc'

const shouldLog = true

const makeLogStr = (level, args) => `app="${appName}" log_level="${level}" message="${args.reduce((memo, val) => `${memo}${val}`, '')}"`

const noop = () => null
const log = (...args) => shouldLog
  ? winston.info(makeLogStr('log', args))
  : noop()

const error = (...args) => winston.error(makeLogStr('error', args))

const warn = (...args) => shouldLog
  ? winston.warn(makeLogStr('warn', args))
  : noop()

const info = (...args) => shouldLog
  ? winston.info(makeLogStr('info', args))
  : noop()

export default {
  log, error, warn, info,
}
