import flatMap from 'lodash/flatMap'
import getOrElse from 'lodash/get'
import reduce from 'lodash/reduce'
import winston from 'winston'
import config from '../../config'
import { getAzureToken } from './AzureTokenUtil'
import { post } from '../../common/Agent'
import makeHeaders from './makeHeaders'

export const fetchPapiGraphQLMap = async ({
  list,
  makeQuery,
  pathToData,
  reducer,
}) => {
  try {
    const thresh = 200
    const callsToMake = Math.ceil(list.length / thresh)

    const velocityHome = config.get('velocity-home').value
    const papiUrl = `https://profile.${velocityHome}/v3/graphql`
    const token = await getAzureToken()
    winston.log('Fetched token: ', token)
    const headers = makeHeaders(token)

    const promises = new Array(callsToMake).fill(0).map((_, idx) => {
      const start = idx * thresh
      const end = start + thresh
      const subList = list.slice(start, end + 1)
      const query = makeQuery(subList)

      return post(papiUrl, query, headers)
    })
    const resolvedPromises = await Promise.all(promises)
    const results = flatMap(resolvedPromises, d => getOrElse(d, pathToData, d))
    winston.log(`Resolved all papi promises, reducing to ${pathToData} map`)


    return reduce(results, reducer, {})
  } catch ( err ) {
    winston.error('Error creating map: ', err)

    return null
  }
}

export const fetchManagerMap = async peopleIdList => {
  const makeQuery = list => ({ query: `{ getUsersById(ids: ["${list.join('","')}"]) { id manager { id } } }` })

  const reducer = (memo, val) => {
    if ( !val ) { return memo }

    const { id, manager } = val
    memo[id] = manager ? manager.id : 'UNKNOWN' // eslint-disable-line no-param-reassign

    return memo
  }
  const pathToData = 'body.data.getUsersById'

  return fetchPapiGraphQLMap({
    list: peopleIdList, makeQuery, reducer, pathToData,
  })
}
