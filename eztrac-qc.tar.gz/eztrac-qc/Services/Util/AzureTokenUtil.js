import { httpGetToken } from '@monsantoit/oauth-azure'
import config from '../../config'

const getAzureToken = () => {
  const { clientId, clientSecret } = config.get('qc-services-oauth-client')
  const getToken = httpGetToken({ clientId, clientSecret })

  return getToken()
}

const AzureTokenUtil = {
  getAzureToken,
}

module.exports = AzureTokenUtil
