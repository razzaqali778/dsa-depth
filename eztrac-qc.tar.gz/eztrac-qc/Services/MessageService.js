import MessageUtil from './Util/MessageUtil'
import getCurrentTimeframe from './Util/getCurrentTimeframe'

export const automateMessages = async function f() {
  if ( process.env.CF_INSTANCE_INDEX === '0' ) {
    try {
      const currentTime = await getCurrentTimeframe()
      await MessageUtil.sendUnallocatedMessages(currentTime.id)
    } catch ( error ) {
      console.log('error', error) // eslint-disable-line no-console
    }
  }
}
