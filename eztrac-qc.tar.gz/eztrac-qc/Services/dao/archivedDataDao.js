import winston from 'winston'

const client = require('../db/db')

const getArchivedDataByTimeframeQuery = 'SELECT data FROM previous_timeframe_data WHERE timeframe_id = $1;'
const storeArchivedDataQuery = 'INSERT INTO previous_timeframe_data (timeframe_id, data) VALUES ($1, $2);'
const updateArchivedDataByTimeframeQuery = 'UPDATE previous_timeframe_data SET data = $2 where timeframe_id = $1;'
const countTimeframesQuery = 'SELECT COUNT(timeframe_id) FROM previous_timeframe_data WHERE timeframe_id = $1;'

export const getArchivedDataByTimeframe = async timeframe => {
  try {
    const result = await client.any(getArchivedDataByTimeframeQuery, [ timeframe ])

    if ( result.length === 0 ) return []

    return result[0].data
  } catch ( error ) {
    winston.error(`Failed to get archived timeframe data with timeframe_id: ${timeframe} -- ${error}`)
    throw error
  }
}

export const storeArchivedData = async (timeframe, data) => {
  try {
    await client.none(storeArchivedDataQuery, [ timeframe, data ])
  } catch ( error ) {
    winston.error(`Failed to store timeframe data with timeframe_id: ${timeframe} -- ${error}`)
    throw error
  }
}
export const updateArchivedDataByTimeframe = async (timeframe, data) => {
  try {
    await client.none(updateArchivedDataByTimeframeQuery, [ timeframe, data ])
  } catch ( error ) {
    winston.error(`Failed to update database with timeframe_id: ${timeframe} -- ${error}`)
    throw error
  }
}
export const upsertArchivedDataByTimeframe = async (timeframe, data) => {
  const timeframeCount = await client.one(countTimeframesQuery, [ timeframe ])
  if ( timeframeCount.count === '0' ) {
    return storeArchivedData(timeframe, data)
  }

  return updateArchivedDataByTimeframe(timeframe, data)
}
