const client = require('../db/db')

const getAllDiscrepancyReasonsQuery = 'SELECT * FROM discrepancy_reason'

export const getAllReasons = async () => {
  try {
    const result = await client.any(getAllDiscrepancyReasonsQuery, [])

    return result
  } catch ( error ) {
    console.log('Error fetching reasons: ', error) // eslint-disable-line no-console
    throw error
  }
}

export const getReasonsByDeactivatable = async deactivatable => {
  try {
    const result = await client.any(`SELECT * FROM discrepancy_reason WHERE deactivatable = ${deactivatable}`)

    return result
  } catch ( error ) {
    console.log('Error fetching reasons by deactivatable: ', error) // eslint-disable-line no-console
    throw error
  }
}
