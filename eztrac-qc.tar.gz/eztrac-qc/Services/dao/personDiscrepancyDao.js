const client = require('../db/db')

/* eslint-disable max-len */
const getDiscrepancyByTimeFrameAndUserQuery = 'SELECT * FROM timeframe_person_discrepancy WHERE user_id = $1 AND timeframe_id = $2;'
const getDiscrepancyByTimeFrameIdQuery = 'SELECT * FROM timeframe_person_discrepancy WHERE timeframe_id = $1'

const createDiscrepancyReasonQuery = 'INSERT INTO timeframe_person_discrepancy(timeframe_id, user_id, reason_name, last_updated_time, last_updated_user_id) VALUES($1, $2, $3, $4, $5) RETURNING last_updated_time;'
const updateDiscrepancyReasonQuery = 'UPDATE timeframe_person_discrepancy SET reason_name = $1, last_updated_time = $2, last_updated_user_id = $3 where user_id = $4 AND timeframe_id = $5 RETURNING last_updated_time;'
const deleteDiscrepancyReasonQuery = 'DELETE FROM timeframe_person_discrepancy WHERE timeframe_id = $1 AND user_id = $2;'
const getAllDiscrepanciesQuery = 'SELECT * FROM timeframe_person_discrepancy'
/* eslint-enable */


const PersonDiscrepancyDao = {
  async getAllDiscrepancies() {
    try {
      const result = await client.any(getAllDiscrepanciesQuery, [])

      return result
    } catch ( error ) {
      throw error
    }
  },

  async getDiscrepancyByTimeFrameAndUser( timeFrameId, userId ) {
    try {
      const result = await client.any(getDiscrepancyByTimeFrameAndUserQuery, [ userId, timeFrameId ])

      return result
    } catch ( error ) {
      throw error
    }
  },

  async getDiscrepancyByTimeFrameId( timeFrameId ) {
    try {
      const result = await client.any(getDiscrepancyByTimeFrameIdQuery, [ timeFrameId ])

      return result
    } catch ( error ) {
      throw error
    }
  },


  async createDiscrepancyReason( discrepancyReason ) {
    try {
      const result = await
      client.one(
        createDiscrepancyReasonQuery,
        [
          discrepancyReason.timeFrameId,
          discrepancyReason.userId,
          discrepancyReason.reason,
          discrepancyReason.updatedTime,
          discrepancyReason.updatedUserId,
        ],
      )

      return result
    } catch ( error ) {
      throw error
    }
  },

  async updateDiscrepancyReason( discrepancyReason ) {
    try {
      const result = await client.one(
        updateDiscrepancyReasonQuery,
        [
          discrepancyReason.reason,
          discrepancyReason.updatedTime,
          discrepancyReason.updatedUserId,
          discrepancyReason.userId,
          discrepancyReason.timeFrameId,
        ],
      )

      return result
    } catch ( error ) {
      throw error
    }
  },
  async deleteDiscrepancyReason( timeFrameId, userId ) {
    try {
      await client.none(deleteDiscrepancyReasonQuery, [ timeFrameId, userId ])

      return 'deleted'
    } catch ( error ) {
      throw error
    }
  },
}

module.exports = PersonDiscrepancyDao
