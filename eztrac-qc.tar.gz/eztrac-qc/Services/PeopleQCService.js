import Moment from 'moment'
import getOrElse from 'lodash/get'
import { combineParticipationDiscrepancies } from './Util/findParticipationIssues/combineParticipationDiscrepancies'
import {
  createDiscrepancyReason,
  deleteDiscrepancyReason,
  getDiscrepancyByTimeFrameAndUser,
  getDiscrepancyByTimeFrameId,
  updateDiscrepancyReason,
} from './dao/personDiscrepancyDao'
import { fetchPersonById, filterPeople, getAllPeople } from './Util/EZPeopleUtil'
import { getInactivePeopleWithReasons } from './Util/PeopleUtil'

const timestampFormatString = 'YYYY-MM-DDTHH:mm:ss.SSSSZ'

export const getParticipationDiscrepancies = async ( req, res ) => {
  try {
    const participationDiscrepancies = await combineParticipationDiscrepancies(req.params.timeFrameId)

    return res.json(participationDiscrepancies)
  } catch ( error ) {
    console.log(`Error getting participation discrepancies: ${error}`) // eslint-disable-line no-console

    return res.status(error.status || 500).send(error)
  }
}

export const putDiscrepancyReason = async ( req, res ) => {
  try {
    try {
      await fetchPersonById(getOrElse(req, 'body.userId', '').toUpperCase())
    } catch ( err ) {
      throw { status: err.status || 500, text: `Error verifying person -- ${err.response && err.response.text}` } // eslint-disable-line no-throw-literal
    }
    const data = {
      ...req.body,
      updatedTime: new Moment().format(timestampFormatString),
      updatedUserId: req.body.user || getOrElse(req, 'userProfile.id', ''),
    }
    const existingReason = await getDiscrepancyByTimeFrameAndUser(data.timeFrameId, data.userId)

    if ( existingReason.length === 0 ) {
      await createDiscrepancyReason(data)
    } else {
      await updateDiscrepancyReason(data)
    }

    return res.status(204).json()
  } catch ( error ) {
    console.log(`Error putting discrepancy reason: ${error}`) // eslint-disable-line no-console

    return res.status(error.status || 500).json(error)
  }
}

export const deleteReason = async ( req, res ) => {
  try {
    const { timeFrameId } = req.params
    const { userId } = req.params

    const existingReason = await getDiscrepancyByTimeFrameAndUser(timeFrameId, userId)

    if ( existingReason.length === 0 ) {
      return res.status(404).send(`No discrepancy found for user ${userId} for the given time frame`)
    }
    await deleteDiscrepancyReason(timeFrameId, userId)

    return res.status(204).send()
  } catch ( err ) {
    console.log(`Error deleting discrepancy reasons: ${err}`) // eslint-disable-line no-console

    return res.status(500).send(err)
  }
}

export const getPapiPeople = async ( req, res ) => {
  try {
    const papiPeople = await getAllPeople()

    return res.json(papiPeople)
  } catch ( err ) {
    console.log(`Error getting papi people: ${err}`) // eslint-disable-line no-console

    return res.status(500).send(err)
  }
}

export const fetchInactivePeople = async ( req, res ) => {
  try {
    const allPeople = await getAllPeople()
    const inactivePeople = await filterPeople(allPeople, false)
    const databasePeople = await getDiscrepancyByTimeFrameId(req.query.timeframeId)

    const withReasons = await getInactivePeopleWithReasons(inactivePeople, databasePeople, allPeople)

    return res.json(withReasons)
  } catch ( err ) {
    console.log(`Error getting active inactivePeople: ${err}`) // eslint-disable-line no-console

    return res.status(500).send(err)
  }
}

export default ({
  getPapiPeople,
  deleteDiscrepancyReason: deleteReason,
  putDiscrepancyReason,
  getParticipationDiscrepancies,
})
