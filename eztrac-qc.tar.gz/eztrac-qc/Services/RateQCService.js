import filter from 'lodash/filter'
import getOrElse from 'lodash/get'
import {
  combineParticipationDiscrepancies,
} from './Util/findParticipationIssues/combineParticipationDiscrepancies'
import getCurrentTimeframe from './Util/getCurrentTimeframe'
import rateUtil from './Util/RateUtil'

const RateQCService = {
  async getCostCalculations( req, res ) {
    try {
      const currentTimeframe = await getCurrentTimeframe()

      const timeframeId = getOrElse(req, 'query.timeFrameId', currentTimeframe.id)
      const missingPeople = await combineParticipationDiscrepancies(timeframeId)
      const missingPeopleWithoutReasons = filter(missingPeople, { reason: '' })

      const costs = await rateUtil.costCalculations(missingPeopleWithoutReasons, req.params.userId)

      return res.json(costs)
    } catch ( error ) {
      return res.status(500).send(error)
    }
  },
}
module.exports = RateQCService
