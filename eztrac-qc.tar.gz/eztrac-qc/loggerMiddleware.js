const logger = require('./Services/Util/logger').default
const { extractUserId, extractUserEntitlements } = require('./Services/Util/extractRequestData')

const now = require('performance-now') // eslint-disable-line global-require

const loggerMiddleware = (req, res, next) => {
  const start = now()
  const url = req.url
  const user = `user: ${extractUserId(req) || 'unknown'} entitlements: ${extractUserEntitlements(req)}`
  const getUsage = () => JSON.stringify(process.memoryUsage())
  if ( url.includes('metrics') || url.includes('ping') ) { return next() }
  logger.info(`Request - ${req.method} ${url} - ${user} -- memory: ${getUsage()}`)
  res.on('finish', () => {
    const message =
      `Response ${res.statusCode} - ${req.method} ${url} - ${user} -- memory: ${getUsage()} -- duration: ${now() - start}` // eslint-disable-line max-len
    if ( parseInt(res.statusCode, 10) >= 400 ) {
      logger.error(message)
    } else {
      logger.info(message)
    }
  })

  res.on('close', () => {
    const message =
      `Response ${res.statusCode} - ${req.method} ${url} - ${user} -- memory: ${getUsage()} -- duration: ${now() - start}` // eslint-disable-line max-len
    logger.error(message, 'Socket abruptly closed')
  })

  return next()
}

export default loggerMiddleware

