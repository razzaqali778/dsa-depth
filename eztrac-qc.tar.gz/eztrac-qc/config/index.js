const { Config, source, processor, env } = require("@monsantoit/config");
const {
  determineEnvironmentFileName,
  isFargate,
} = require("@monsantoit/config-velocity-store");

console.info(
  `NODE_ENV: ${process.env.NODE_ENV}, FARGATE_ENV: ${process.env.FARGATE_ENV}, isFargate: ${isFargate}`
);

const environmentFileName =
  process.env.NODE_ENV === "production" && isFargate
    ? `${determineEnvironmentFileName()}`
    : `${process.env.CONFIG_ENV || process.env.NODE_ENV || "default"}.js`;

console.info(
  `Configuration Environment - IsFargate: ${isFargate}, environmentFileName: ${environmentFileName}`
);

const config = new Config({
  sources: [
    source.fromJS({ src: `${__dirname}/files/${environmentFileName}` }),
  ],
  processors: [
    processor.readVaultFromConfig({
      enabled: env.inDevelopment,
      auth: { type: "local" },
    }),
    processor.readVaultFromConfig({
      enabled: env.inProduction,
      auth: {
        type: "auto",
        roleName: { inConfig: "workforce-approle.role_name" },
      },
    }),
  ],
  required: [],
});

module.exports = config;
