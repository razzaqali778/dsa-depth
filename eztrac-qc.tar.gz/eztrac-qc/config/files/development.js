const _ = require("lodash");
const defaultConfig = require("./default");

module.exports = _.merge(defaultConfig, {
    "ez-trac-qc-db": {
        user: "vault://secret/ez-trac/qc-services/np/db/app-user-name",
        password: "vault://secret/ez-trac/qc-services/np/db/app-user-password",
        host: "localhost",
        port: "5435",
        database: "vault://secret/ez-trac/qc-services/np/db/db-name",
    },
    "ez-trac-urls": {
        services: {
          "ez-trac-core": "https://ez-trac-core-services.velocity-np.ag",
          "ez-trac-costing": "https://ez-trac-costing-services.velocity-np.ag",
          "ez-trac-qc": "http://localhost:3000/ez-trac-qc/services",
          "ez-trac-reporting": "https://ez-trac-reporting-services.velocity-np.ag",
          "ez-trac-suggestion": "https://ez-trac-suggestion.velocity-np.ag",
          "ez-trac-vip":
            "https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services",
          "peadmin-home": "peadmin-np.monsanto.net",
        },
        ui: {
          "ez-trac-costing": "https://peadmin-np.monsanto.net/ez-trac-costing",
          "ez-trac-qc": "http://localhost:3000/ez-trac-qc",
          "ez-trac-reporting": "https://peadmin-np.monsanto.net/ez-trac-reporting",
          "ez-trac-vip": "https://peadmin-np.monsanto.net/ez-trac-vip",
          "ez-trac-workflows": "https://peadmin-np.monsanto.net/ez-trac-workflows",
          "peadmin-ez-trac-home": "https://peadmin-np.monsanto.net/ez-trac-core",
        },
      },
});
