const config = {
    "ez-trac-urls": {
      services: {
        "ez-trac-core": "https://ez-trac-core-services.velocity-np.ag",
        "ez-trac-costing": "https://ez-trac-costing-services.velocity-np.ag",
        "ez-trac-qc": "https://ez-trac-qc-services.velocity-np.ag/ez-trac-qc/services",
        "ez-trac-reporting": "https://ez-trac-reporting-services.velocity-np.ag",
        "ez-trac-suggestion": "https://ez-trac-suggestion.velocity-np.ag",
        "ez-trac-vip":
          "https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services",
        "peadmin-home": "peadmin-np.monsanto.net",
      },
      ui: {
        "ez-trac-costing": "https://peadmin-np.monsanto.net/ez-trac-costing",
        "ez-trac-qc": "https://peadmin-np.monsanto.net/ez-trac-qc",
        "ez-trac-reporting": "https://peadmin-np.monsanto.net/ez-trac-reporting",
        "ez-trac-vip": "https://peadmin-np.monsanto.net/ez-trac-vip",
        "ez-trac-workflows": "https://peadmin-np.monsanto.net/ez-trac-workflows",
        "peadmin-ez-trac-home": "https://peadmin-np.monsanto.net/ez-trac-core",
      },
    },
    "qc-services-oauth-client": {
      clientId:
        "vault://secret/ez-trac/qc-services/np/oauth-azure/client-id",
      clientSecret:
        "vault://secret/ez-trac/qc-services/np/oauth-azure/client-secret",
    },
    "profile-url": "https://profile.velocity-np.ag",
    "phoenix-home": {value: 'phoenix-tools-np.io', env: 'NonProd'},
    "velocity-home": {value: "velocity-np.ag"},
    "peadmin-home": {value:"peadmin-np.monsanto.net"},
    "workforce-approle": {
      role_name: '',
    },
    "messaging-url": "https://messaging.velocity-np.ag",
    "ez-trac-qc-db": {
      user: "vault://secret/ez-trac/qc-services/np/db/app-user-name",
      password: "vault://secret/ez-trac/qc-services/np/db/app-user-password",
      host: "vault://secret/ez-trac/np/db/new-host",
      port: "5432",
      database: "vault://secret/ez-trac/qc-services/np/db/db-name",
      ssl: {rejectUnauthorized: false}
    }
  };

  module.exports = config;
