const _ = require("lodash");
const defaultConfig = require("./default");

module.exports = _.merge(defaultConfig, {
    "workforce-approle": {
        role_name: "workforce-dev-admins-eztrac-prod",
      },
      "phoenix-home": {value: 'phoenix-tools.io', env: 'Prod'},
      "ez-trac-urls": {
        services: {
          "ez-trac-core": "https://ez-trac-core-services.velocity.ag",
          "ez-trac-costing": "https://ez-trac-costing-services.velocity.ag",
          "ez-trac-qc": "https://ez-trac-qc-services.velocity.ag/ez-trac-qc/services",
          "ez-trac-reporting": "https://ez-trac-reporting-services.velocity.ag",
          "ez-trac-suggestion": "https://ez-trac-suggestion.velocity.ag",
          "ez-trac-vip":
            "https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services",
          "peadmin-home": "peadmin.monsanto.net",
        },
        ui: {
          "ez-trac-costing": "https://peadmin.monsanto.net/ez-trac-costing",
          "ez-trac-qc": "https://peadmin.monsanto.net/ez-trac-qc",
          "ez-trac-reporting": "https://peadmin.monsanto.net/ez-trac-reporting",
          "ez-trac-vip": "https://peadmin.monsanto.net/ez-trac-vip",
          "ez-trac-workflows": "https://peadmin.monsanto.net/ez-trac-workflows",
          "peadmin-ez-trac-home": "https://peadmin.monsanto.net/ez-trac-core",
        },
      },
      "qc-services-oauth-client": {
        clientId:
          "vault://secret/ez-trac/qc-services/prod/oauth-azure/client-id",
        clientSecret:
          "vault://secret/ez-trac/qc-services/prod/oauth-azure/client-secret",
      },
      "profile-url": "https://profile.velocity.ag",
      "velocity-home": { value: "velocity.ag" },
      "peadmin-home": { value: "peadmin.monsanto.net" },
      "messaging-url": "https://messaging.velocity.ag",
      "ez-trac-qc-db": {
        user: "vault://secret/ez-trac/qc-services/prod/db/app-user-name",
        password: "vault://secret/ez-trac/qc-services/prod/db/app-user-password",
        host: "vault://secret/ez-trac/prod/db/new-host",
        port: "5432",
        database: "vault://secret/ez-trac/qc-services/prod/db/db-name",
      }
});
