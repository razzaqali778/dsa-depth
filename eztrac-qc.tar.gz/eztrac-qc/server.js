require('@babel/register')

const express = require('express')

const compression = require('compression')
const bodyParser = require('body-parser')
const proxy = require('http-proxy')
const winston = require('winston')
const bindingsMiddleware = require('@monsantoit/phoenix-service-bindings-middleware')
const { setManagerMapCache } = require('./Services/Util/ManagerMapCache')
const { managerMapJob, messageJob } = require('./Services/Util/Cron')
const { readSecurityMiddleware, writeSecurityMiddleware } = require('./securityMiddleware')
const { getDefaultBindings } = require('./defaultBindings')

const config = require('./config')

const useMetrics = require('./metrics')

const appBaseUrl = '/ez-trac-qc'
const proxies = require('./proxies').default
const loggerMiddleware = require('./loggerMiddleware').default

console.log('Configuration check')
console.log(`velocity-home: ${config.get('velocity-home').value}`)
console.log(`peadmin-home: ${config.get('peadmin-home').value}`)
/* eslint-disable global-require */
messageJob()

const app = express()

useMetrics(app)


app.use(loggerMiddleware)
if ( process.env.NODE_ENV !== 'production' ) {
  const webpackDevMiddleware = require('webpack-dev-middleware')
  const webpack = require('webpack')
  const webpackConfig = require('./webpack.config')
  const compiler = webpack(webpackConfig)
  const middlewareOptions = {
    stats: { colors: true },
    publicPath: webpackConfig.output.publicPath,
  }

  const webpackDevMiddlewareInstance = webpackDevMiddleware(compiler, middlewareOptions)
  app.use(webpackDevMiddlewareInstance)

  const webpackHotMiddleware = require('webpack-hot-middleware')

  app.use(webpackHotMiddleware(compiler))

  const lessMiddleware = require('less-middleware')
  app.use(`${appBaseUrl}/styles`, lessMiddleware('./public/styles'))

  const cors = require('cors')
  const corsMiddleware = cors({
    origin: ( origin, corsCb ) => corsCb(null, true),
  })

  app.use(( req, res, next ) => {
    res.set('Access-Control-Allow-Credentials', true)
    corsMiddleware(req, res, next)
  })
} else {
  setManagerMapCache() // set the manager cache on app start when not local
  managerMapJob()
}

app.use(compression())

const addPingPage = () => {
  const createPingPage = require('@monsantoit/ping-page')
  const pingPage = createPingPage(require('./package.json'))
  app.get('/ping', pingPage)
  app.get(`${appBaseUrl}/ping`, pingPage)
}

addPingPage()

app.use('/', readSecurityMiddleware, writeSecurityMiddleware)

const { ui, services } = config.get('ez-trac-urls')

const serviceBindingsRouter = bindingsMiddleware(
  {
    'phoenix-home': config.get('phoenix-home'),
    'peadmin-home': config.get('peadmin-home'),
    'velocity-home': config.get('velocity-home'),
    ...getDefaultBindings(ui, services),
  },
)

app.use(`${appBaseUrl}/service-bindings`, serviceBindingsRouter)

app.use(bodyParser.json())
app.use(`${appBaseUrl}/styles`, express.static('./public/styles'))
app.use(`${appBaseUrl}/scripts`, express.static('./public/scripts'))
proxy.createProxyServer()
app.use(`${appBaseUrl}/services/proxies`, proxies)
app.use(`${appBaseUrl}/services/v1`, require('./routes/V1Services'))
app.use(`${appBaseUrl}/services/v2`, require('./routes/V2Services'))


app.get('/*', ( req, res ) => {
  res.send(`<!DOCTYPE html>
    <html>
      <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>EZTrac QC</title>
        <link rel="stylesheet" href="//static-assets.velocity.ag/styles/1.0.1/velocity.css">
        <link rel="stylesheet" type="text/css" href="https://phoenix-tools.io/assets/cached/peadmin/styles/navbar.css">
        <link rel="stylesheet" type="text/css" href="https://phoenix-tools.io/assets/cached/peadmin/styles/mat1.1.1.css">
        <link rel="stylesheet" href="${appBaseUrl}/styles/style.css">
        <link rel="stylesheet" href="${appBaseUrl}/styles/toggle.css">
        <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
      </head>
      <body>
        <div class="nav"></div>
        <div class="contents"></div>
        <script type="text/javascript" src="${appBaseUrl}/service-bindings"></script>
        <script type="text/javascript" src="${appBaseUrl}/scripts/bundle.js"></script>
        <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
      </body>
    </html>
  `)
})

const port = parseInt(process.env.PORT || 3000, 10)

const server = app.listen(port, () => {
  const address = server.address()
  const url = `http://${address.host || 'localhost'}:${port}`
  winston.info(`Listening at ${url}`)
})
