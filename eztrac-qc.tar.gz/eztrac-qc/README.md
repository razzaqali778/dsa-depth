# EZ-Trac Core Services

## Cloud Foundry App Name
  `ez-trac-qc`

## Description
  Node server serving up the QC UI and an express layer for handling service requests.
  Handles displaying improperly allocated people and initiatives on efforts

## Dependencies
  * QC postgres -- RDS Instance in AWS
  * ez-trac-core-services
  * ez-trac-vip
  * papi

## .env file
This application requires a .env file to run, the env.sample can be renamed to do this.
cp "$PWD/env.sample" "$PWD/.env"
Replace the vault path with the secret value in the .env file.
  
## Kibana logging
  This app has requests logged in a way that kibana can pick them up through the syslog drain.
  
  * [Non Prod Logs][kibana-nonprod]

  * [Prod Logs][kibana-prod]

## Vault 

### Paths
  * `/secret/ez-trac/qc-services/np` -- non prod values for server
  * `/secret/ez-trac/qc-services/prod` -- prod values for server
  * `/secret/ez-trac/qc-ui/np` -- non prod values for UI
  * `/secret/ez-trac/qc-ui/prod` -- prod values for UI
### Values
  * `oauth` -- Contains `client-id` and `client-secret`, present in all
  * `db` -- Contains `db-user` and `db-password` as well as `default-db` for the RDS instance, present for server only

Ex:
  `vault read secret/ez-trac/qc-services/np/oauth` -- Would show you `client-id` and `client-secret` for this app's server
 


[kibana-nonprod]: https://awskibana.velocity.ag/_plugin/kibana/#/discover?_g=()&_a=(columns:!(_source),index:%5Bcf_app-%5DYYYY.MM.DD,interval:auto,query:(query_string:(analyze_wildcard:!t,query:'app:%22ez-trac-qc%22%20AND%20NonProd')),sort:!('@timestamp',desc))
[kibana-prod]: https://awskibana.velocity.ag/_plugin/kibana/#/discover?_g=()&_a=(columns:!(_source),index:%5Bcf_app-%5DYYYY.MM.DD,interval:auto,query:(query_string:(analyze_wildcard:!t,query:'app:%22ez-trac-qc%22%20AND%20Prod')),sort:!('@timestamp',desc))
