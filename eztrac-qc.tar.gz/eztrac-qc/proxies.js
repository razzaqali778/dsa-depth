const config = require('./config')

const express = require('express')
const proxy = require('express-http-proxy')
const { getAzureToken } = require('./Services/Util/AzureTokenUtil')

const router = express.Router()

const urlParser = require('url')

const proxyReqOptDecorator = async req => {
  if ( process.env.NODE_ENV !== 'production' ) {
    req.headers['user-id'] = process.env.USER
  }
  const token = await getAzureToken()
  req.headers.Authorization = `Bearer ${token}`

  return req
}
const proxyReqPathResolver = req => {
  const path = urlParser.parse(req.url).path

  return path
}

const { services } = config.get('ez-trac-urls')
const costingUrl = services['ez-trac-costing']
router.use('/cost-calc', proxy(costingUrl, {
  proxyReqPathResolver,
  proxyReqOptDecorator,
}))

const coreUrl = services['ez-trac-core']
router.use('/core-services', proxy(coreUrl, {
  proxyReqPathResolver,
  proxyReqOptDecorator,
}))

const velocityHome = config.get('velocity-home').value
router.use('/papi', proxy(`https://profile.${velocityHome}`, {
  proxyReqPathResolver,
  proxyReqOptDecorator,
}))

/* eslint-enable */

export default router
