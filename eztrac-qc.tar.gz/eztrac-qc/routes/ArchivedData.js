import express from 'express'
import { fetchArchivedData, putArchivedData } from '../Services/Util/ArchivedDataUtil'

// defining /archive routes

const router = express.Router()

router.get('/:timeframeId', fetchArchivedData)

router.put('/:timeframeId', putArchivedData)

export default router
