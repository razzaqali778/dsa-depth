import express from 'express'
import { fetchDiscrepancyReasons } from '../Services/DiscrepancyReasonService'

const router = express.Router()

router.get('/reasons', fetchDiscrepancyReasons)

module.exports = router
