import express from 'express'
import {
  deleteReason,
  fetchInactivePeople,
  getPapiPeople,
  getParticipationDiscrepancies,
  putDiscrepancyReason,
} from '../Services/PeopleQCService'
import { getDiscrepancyReasons } from '../Services/DiscrepancyReasonService'
import { getEffortAllocationIssues } from '../Services/Util/findInitiativeIssues/effortAllocationUtil'
import { getManagerMapEndpoint } from '../Services/Util/ManagerMapCache'
import RateQCService from '../Services/RateQCService'
import archivedData from './ArchivedData'
import people from './People'

const router = express.Router()

router.use('/archive', archivedData)
router.use('/people', people)
router.get('/qc/people/timeframe/:timeFrameId', getParticipationDiscrepancies)
router.get('/qc/initiative/timeframe/:timeFrameId', getEffortAllocationIssues)
router.get('/qc/people/papiPeople', getPapiPeople)
router.get('/qc/people/inactivePeople', fetchInactivePeople)
router.get('/discrepancyReasons', getDiscrepancyReasons)
router.get('/rate/costCalculations/:userId', RateQCService.getCostCalculations)
router.get('/manager-map', getManagerMapEndpoint)

router.put('/qc/discrepancy', putDiscrepancyReason)

router.delete('/qc/discrepancy/:timeFrameId/:userId', deleteReason)

module.exports = router
