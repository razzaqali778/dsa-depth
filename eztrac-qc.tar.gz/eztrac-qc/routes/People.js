import express from 'express'
import {
  getAllTeamsForPersonAndTimeframe,
} from '../Services/Util/PeopleUtil'
import {
  getPapiPeople,
} from '../Services/PeopleQCService'

// defining /people routes

const router = express.Router()

router.get('/all', getPapiPeople)

router.get('/all-teams-by-timeframe', async ( req, res ) => {
  try {
    const { userId, timeFrameId } = req.query
    const teams = await getAllTeamsForPersonAndTimeframe(userId, timeFrameId)

    res.json(teams)
  } catch ( err ) {
    res.status(500).json(err)
  }
})


export default router
