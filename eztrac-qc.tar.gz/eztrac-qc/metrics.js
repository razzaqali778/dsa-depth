const promMetrics = require('@monsantoit/prom-metrics')
const client = require('./Services/db/db')

const setupMetrics = app => {
  const promClient = promMetrics(app)

  const databaseUp = promClient.newGauge({
    namespace: 'nodejs',
    name: 'database_up',
    help: 'Requests to database working',
  })

  const setDatabaseUp = v => databaseUp.set({ period: '15min', cf_instance_index: process.env.CF_INSTANCE_INDEX }, v )
  const intervalLen = 15 * 60 * 1000
  const checkDatabase = () => {
    client.any('SELECT * FROM timeframe_person_discrepancy WHERE timeframe_id = 0')
    .then(() => setDatabaseUp(1))
    .catch(() => setDatabaseUp(0))
  }
  checkDatabase()
  setInterval(checkDatabase, intervalLen)
}

module.exports = setupMetrics
