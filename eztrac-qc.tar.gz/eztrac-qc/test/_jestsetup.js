import sinon from 'sinon'
import testConfig from '../config/files/test'
import { getDefaultBindings } from '../defaultBindings'

// Polyfill TextEncoder/TextDecoder for jest-environment-jsdom compatibility
if (typeof globalThis.TextEncoder === 'undefined') {
  const { TextEncoder, TextDecoder } = require('util') // eslint-disable-line global-require
  globalThis.TextEncoder = TextEncoder
  globalThis.TextDecoder = TextDecoder
}

const { ui, services } = testConfig['ez-trac-urls']

global.sinon = sinon
global.isTesting = true
global.phoenix = {
  serviceBindings: getDefaultBindings(ui, services), // eslint-disable-line global-require
  authHeader: () => ({ Authorization: 'token' }),
}

global.console.error = jest.fn(() => null)
