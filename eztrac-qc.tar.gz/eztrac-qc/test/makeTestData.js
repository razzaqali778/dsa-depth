export const makeMockPeople = () => [
  {
    userId: 'KWOLT',
    name: 'Test User',
    rateName: '',
    manager: 'JREARH',
  },
  {
    userId: 'JREARH',
    name: 'Test User',
    rateName: '',
    manager: 'KWOLT',
  },
  {
    userName: 'Robert Larson',
    userId: 'RCLARS1',
    rateName: '',
    manager: 'RMURPH',
  },
]

export const makeMockTimeframePeople = () => [
  {
    userId: 'SBHAT5',
    name: 'Bhatraju, Sreevani',
    rateName: '',
    managerId: 'PPUMA',
  },
  {
    userId: 'SBILL',
    name: 'Billakanti, Srikanth',
    rateName: '',
    managerId: 'VFUPAMA',
  },
  {
    userId: 'SBKOMM',
    name: 'Kommera, Suresh',
    rateName: '',
    managerId: 'PPUMA',
  },
]

export const makeUnallocatedPeopleManager = () => ({
  JSCHU: [{
    userId: 'SDHOL',
    userName: 'Dholakia, Shreyash',
    timeFrameId: 32006,
    previousTeams: [],
    currentTeams: [],
    managerName: 'Schulte, James',
    managerId: 'JSCHU',
    reason: '',
  }],

  DMISRA: [{
    userId: 'SDILT',
    userName: 'Diltz, Shaun',
    timeFrameId: 32006,
    previousTeams: [],
    currentTeams: [],
    managerName: 'Israelitt, David',
    managerId: 'DMISRA',
    reason: '',
  },
  {
    userId: 'MTLIND1',
    userName: 'Lindner, Matt',
    timeFrameId: 32006,
    previousTeams: [],
    currentTeams: [],
    managerName: 'Israelitt, David',
    managerId: 'DMISRA',
    reason: '',
  }],
})

export const makeUnallocatedPeople = () => [
  {
    userId: 'SDHOL',
    userName: 'Dholakia, Shreyash',
    timeFrameId: 32006,
    previousTeams: [],
    currentTeams: [],
    managerName: 'Schulte, James',
    managerId: 'JSCHU',
    reason: 'Part Time',
  },

  {
    userId: 'SDILT',
    userName: 'Diltz, Shaun',
    timeFrameId: 32006,
    previousTeams: [],
    currentTeams: [],
    managerName: 'Israelitt, David',
    managerId: 'DMISRA',
    reason: '',
  },
  {
    userId: 'MTLIND1',
    userName: 'Lindner, Matt',
    timeFrameId: 32006,
    previousTeams: [],
    currentTeams: [],
    managerName: 'Israelitt, David',
    managerId: 'DMISRA',
    reason: '',
  },
]

export const makeMockTimeframes = () => ([
  {
    endDate: 123,
    id: 'borkrkrkrk',
    lockdown: true,
    name: 'Mar 14',
    startDate: 121,
  },
  {
    endDate: 456,
    id: 32008,
    lockdown: true,
    name: 'April 14',
    startDate: 120,
  },
  {
    endDate: 678,
    id: 32009,
    lockdown: true,
    name: 'May 14',
    startDate: 119,
  },
  {
    endDate: 890,
    id: 32010,
    lockdown: true,
    name: 'Jun 15',
    startDate: 118,
  },
  {
    endDate: 112,
    id: 32011,
    lockdown: true,
    name: 'Jul 14',
    startDate: 117,
  },
  {
    endDate: 234,
    id: 32012,
    lockdown: true,
    name: 'Aug 14',
    startDate: 116,
  },
])

it('has a test so jest is happy', () => expect(1).toBe(1))
