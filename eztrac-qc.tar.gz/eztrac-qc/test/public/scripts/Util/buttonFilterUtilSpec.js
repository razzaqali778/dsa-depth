/**
 * @jest-environment jsdom
 */
import cloneDeep from 'lodash/cloneDeep'
import {
  filterUnderUserId,
  getManagerHierarchy,
} from '../../../../public/scripts/Util/buttonFilterUtil'

describe('buttonFilterUtilSpec', () => {
  const sandbox = sinon.createSandbox()

  afterEach(() => {
    sandbox.restore()
  })

  const sampleData = [
    {
      userId: 'rclars1',
      userName: 'Larson, Cory',
      manager: 'Alex',
      managerId: 'adbowm',
    },
    {
      userId: 'adbowm',
      userName: 'Bowman, Alex',
      manager: 'Channon',
      managerId: 'crgood',
    },
    {
      userId: 'crgood',
      userName: 'Goodram, Channon',
      manager: 'The Top Dog',
      managerId: 'dog',
    },
    {
      userId: 'jrearh',
      userName: 'Earheart, Jess',
      manager: 'Bowman, Alex',
      managerId: 'adbowm',
    },
    {
      userId: 'ACBELZ',
      userName: 'Andrew',
      manager: 'Ryan',
      managerId: 'rmurphy',
    },
  ]

  const papiPeopleSample = [
    {
      userId: 'rclars1',
      name: 'Cory Larson',
      rateName: 'wedontcare',
      managerId: 'adbowm',
    },
    {
      userId: 'adBOwm',
      name: 'Alex Bowman',
      rateName: 'wedontcare',
      managerId: 'CrGooD',
    },
    {
      userId: 'cRgood',
      name: 'Channon Goodrum',
      rateName: 'wedontcare',
      managerId: 'dog',
    },
    {
      userId: 'jrearh',
      name: 'Jess',
      rateName: 'wedontcare',
      managerId: 'adbowm',
    },
    {
      userId: 'ACBELZ',
      name: 'Andrew',
      rateName: 'wedontcare',
      managerId: 'rmurphy',
    },
  ]

  const testDataFactorySample = () => cloneDeep(sampleData)

  const testDataFactoryPapi = () => cloneDeep(papiPeopleSample)

  it('getManagerHierarchy given a userId and list of papiPeople, returns everyone under that userId', () => {
    const userIdMock = 'crgood'
    const papiMock = testDataFactoryPapi()

    const expectedValue = [ 'adbowm', 'rclars1', 'jrearh' ]

    const obtainedHierarchy = getManagerHierarchy(userIdMock, papiMock)

    expect(obtainedHierarchy).toEqual(expectedValue)
  })


  describe('filterUnderUserID', () => {
    it('given a userId, list of papiPeople, and list of unallocated users, returns unallocated users', () => {
      const userIdMock = 'crgood'
      const papiMock = testDataFactoryPapi()
      // TODO: Make this suboordinate a pre-made list
      const subordinates = getManagerHierarchy(userIdMock, papiMock)

      const discrepancyMock = testDataFactorySample()

      const expectedValue = [ discrepancyMock[0], discrepancyMock[1], discrepancyMock[3] ]

      try {
        const result = filterUnderUserId(userIdMock, discrepancyMock, subordinates)
        expect(result).toEqual(expectedValue)
      } catch ( error ) {
        throw error
      }
    })
  })
})
