/**
 * @jest-environment jsdom
 */
import * as Agent from '../../../../../common/Agent'
import { getAllPeople, getPeopleByTimeframe } from '../../../../../public/scripts/Util/Network/papiPeopleUtil'
import { makeMockPeople, makeMockTimeframePeople } from '../../../../makeTestData'

const qcUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/qc`
const papiPeopleUrl = `${qcUrl}/people/papiPeople`

describe('papiPeopleUtilSpec', () => {
  const sandbox = sinon.createSandbox()

  let getStub = {}

  beforeEach(() => {
    getStub = sandbox.stub(Agent, 'get')
  })

  afterEach(() => {
    sandbox.restore()
  })


  it('Gets all people given a timeframe id', async () => {
    const expected = makeMockPeople()
    getStub.resolves({})
    getStub
      .withArgs(papiPeopleUrl)
      .resolves({ body: makeMockPeople() })

    try {
      const response = await getAllPeople()
      expect(response).toEqual(expected)
    } catch ( error ) {
      throw error
    }
  })

  it('Gets all people given a valid timeframeId', async () => {
    const timeframeId = '32007'
    const expected = makeMockTimeframePeople()
    getStub.resolves({})
    getStub
      .withArgs(`${qcUrl}/people/timeframe/32007`)
      .resolves({ body: makeMockTimeframePeople() })

    try {
      const response = await getPeopleByTimeframe(timeframeId)
      expect(response).toEqual(expected)
    } catch ( error ) {
      throw error
    }
  })
})
