/**
 * @jest-environment jsdom
 */
import * as Agent from '../../../../../common/Agent'
import { archiveMonth, getArchiveMonth } from '../../../../../public/scripts/Util/Network/archiveUtil'

const archiveUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/archive`

describe('archiveUtil', () => {
  it('archives the current month of people data successfully with the archiveUtil function', async () => {
    const sandbox = sinon.createSandbox()
    const putStub = sandbox.stub(Agent, 'put')

    try {
      const testCostingUrl = `${archiveUrl}/32009`
      await archiveMonth('32009')
      expect(putStub.firstCall.args).toEqual([ testCostingUrl, {}, { Authorization: 'token' }])
    } finally {
      sandbox.restore()
    }
  })

  it('retrieves the previous month of people data successfully with the archiveUtil function', async () => {
    const sandbox = sinon.createSandbox()
    const getStub = sandbox.stub(Agent, 'get')

    getStub.resolves({ body: 'bork' })

    try {
      const result = await getArchiveMonth('32009')
      expect(result).toEqual('bork')
    } finally {
      sandbox.restore()
    }
  })
})
