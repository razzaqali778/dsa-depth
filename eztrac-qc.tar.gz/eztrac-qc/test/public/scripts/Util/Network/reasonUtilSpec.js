/**
 * @jest-environment jsdom
 */
import * as Agent from '../../../../../common/Agent'
import { deleteReason, getAllReasons, saveReason } from '../../../../../public/scripts/Util/Network/reasonUtil'
import { makeUnallocatedPeople } from '../../../../makeTestData'

const reasonUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v2/reasons`
const saveReasonUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/qc/discrepancy`
const deleteReasonUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/qc/discrepancy/`

describe('reasonUtilSpec', () => {
  const sandbox = sinon.createSandbox()

  let putStub = {}
  let getStub = {}
  let delStub = {}

  beforeEach(() => {
    putStub = sandbox.stub(Agent, 'put')
    getStub = sandbox.stub(Agent, 'get')
    delStub = sandbox.stub(Agent, 'del')
  })

  afterEach(() => {
    sandbox.restore()
  })


  const makeMockData = () => ({
    body: 'abc',
  })

  it('gets reasons', async () => {
    const mockData = makeMockData()

    getStub
      .withArgs(reasonUrl)
      .resolves({ body: mockData })

    try {
      const response = await getAllReasons()
      expect(response).toEqual(mockData)
    } catch ( error ) {
      throw error
    }
  })

  it('saves a reason when passed valid arguments', async () => {
    const mockPeople = makeUnallocatedPeople()
    const mockDiscrepancy = mockPeople[1]
    const mockVal = {
      thing: 'wee',
      value: 'Part Time',
    }
    const mockUserId = 'MGOAT' // tips fedora

    putStub
      .withArgs(saveReasonUrl)
      .resolves({ body: 'doesnt matter' })

    try {
      const response = await saveReason(mockDiscrepancy, mockPeople, mockVal, mockUserId)
      expect(response).toEqual(true)
    } catch ( error ) {
      throw error
    }
  })

  it('deletes a reason when passed valid arguments', async () => {
    const mockPeople = makeUnallocatedPeople()
    const mockDiscrepancy = mockPeople[1]

    delStub
      .withArgs(deleteReasonUrl)
      .resolves({ body: 'bork bork' })

    try {
      const response = await deleteReason(mockDiscrepancy, mockPeople)
      expect(response).toEqual(true)
    } catch ( error ) {
      throw error
    }
  })
})
