import { shouldDeactivate } from '../../../../../public/scripts/Util/Network/deactivatePersonUtil'


const reasons = [
  { reasonName: 'Co-Op', deactivatable: true },
  { reasonName: 'Left P&E', deactivatable: true },
  { reasonName: 'SOW (External)', deactivatable: true },
  { reasonName: 'Contractor Absence', deactivatable: false },
  { reasonName: 'Part Time', deactivatable: false },
  { reasonName: 'Employee Absence', deactivatable: false },
  { reasonName: 'New to P&E', deactivatable: false },
]
describe('deactivatePersonUtilSpec', () => {
  it('shouldDeactivate returns true if the person should be deactivated', () => {
    expect(shouldDeactivate(reasons, 'Co-Op')).toBe(true)
    expect(shouldDeactivate(reasons, 'Left P&E')).toBe(true)
    expect(shouldDeactivate(reasons, 'SOW (External)')).toBe(true)
    expect(shouldDeactivate(reasons, 'Contractor Absence')).toBe(false)
    expect(shouldDeactivate(reasons, 'Part Time')).toBe(false)
    expect(shouldDeactivate(reasons, 'Employee Absence')).toBe(false)
    expect(shouldDeactivate(reasons, 'This shouldnt work')).toBe(false)
    expect(shouldDeactivate(reasons, '')).toBe(false)
    expect(shouldDeactivate([], '')).toBe(false)
    expect(shouldDeactivate([], [])).toBe(false)
    expect(shouldDeactivate([], {})).toBe(false)
    expect(shouldDeactivate('', '')).toBe(false)
  })
})
