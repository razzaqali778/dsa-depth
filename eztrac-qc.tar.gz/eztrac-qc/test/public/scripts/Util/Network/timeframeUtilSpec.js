/**
 * @jest-environment jsdom
 */
import * as Agent from '../../../../../common/Agent'
import {
  getAllTimeframes,
  getCurrentTimeframe,
  getNumTimeframes,
  getTimeframeNames,
} from '../../../../../public/scripts/Util/Network/timeframeUtil' // eslint-disable-line max-len
import { makeMockTimeframes } from '../../../../makeTestData'

const timeframeUrl = `${window.phoenix.serviceBindings['ez-trac-qc-services']}/proxies/core-services/v2/timeframes`

describe('timeframe util', () => {
  let getStub = {}

  beforeEach(() => {
    getStub = sinon.stub(Agent, 'get')
  })

  afterEach(() => {
    getStub.restore()
  })

  it('gets timeframes', async () => {
    const mockData = makeMockTimeframes()
    getStub
      .withArgs(timeframeUrl)
      .resolves({ body: mockData })

    const response = await getAllTimeframes()

    expect(response).toEqual(mockData)
  })

  it('gets current timeframe', async () => {
    const mockData = makeMockTimeframes()

    getStub
      .withArgs(`${timeframeUrl}/current/offset/0`)
      .resolves({ body: mockData[0] })

    const response = await getCurrentTimeframe()

    expect(response).toEqual(mockData[0])
  })

  it('gets timeframe names', async () => {
    const mockData = makeMockTimeframes()
    const expectedValue = [ 'Mar 14', 'April 14', 'May 14', 'Jun 15', 'Jul 14', 'Aug 14' ]

    getStub
      .withArgs(timeframeUrl)
      .resolves({ body: mockData })

    const response = await getTimeframeNames()

    expect(response).toEqual(expectedValue)
  })

  it('gets last n number of timeframes starting from current timeframe', async () => {
    const mockData = makeMockTimeframes()
    getStub
      .withArgs(timeframeUrl)
      .resolves({ body: mockData })

    getStub
      .withArgs(`${timeframeUrl}/current/offset/0`)
      .resolves({ body: mockData[5] })

    getStub
      .withArgs(`${timeframeUrl}/current/offset/-1`)
      .resolves({ body: mockData[4] })

    getStub
      .withArgs(`${timeframeUrl}/current/offset/-2`)
      .resolves({ body: mockData[3] })

    const response = await getNumTimeframes(32012, 3)

    const expected = [ mockData[5], mockData[4], mockData[3] ]

    expect(response).toEqual(expected)
  })
})
