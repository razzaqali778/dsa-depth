/**
 * @jest-environment jsdom
 */
import * as Agent from '../../../../../common/Agent'
import { getInitiativeIssues } from '../../../../../public/scripts/Util/Network/initiativeUtil'

describe('getInitiativeIssues', () => {
  const sandbox = sinon.createSandbox()
  let getStub = {}

  beforeEach(() => {
    getStub = sandbox.stub(Agent, 'get')
  })

  afterEach(() => sandbox.restore() )

  it('gets initiatives with issues by timeframe from core services', async () => {
    getStub.resolves({})
    getStub
      .withArgs(`${window.phoenix.serviceBindings['ez-trac-qc-services']}/v1/qc/initiative/timeframe/12345`)
      .resolves({ body: [ 'issues' ] })

    try {
      const result = await getInitiativeIssues(12345)
      expect(result).toEqual([ 'issues' ])
    } catch ( error ) {
      throw error
    }
  })
})
