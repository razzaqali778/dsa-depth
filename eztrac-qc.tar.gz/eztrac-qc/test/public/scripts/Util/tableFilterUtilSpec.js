import cloneDeep from 'lodash/cloneDeep'
import filterTable from '../../../../public/scripts/Util/tableFilterUtil'

describe('tableFilterUtilSpec', () => {
  const sampleData = [
    {
      userId: 'ACBELZ',
      userName: 'Belzer, Andrew',
      timeFrameId: 32005,
      totalParticipationInTimeFrame: 400,
      reason: null,
      lastUpdateTime: null,
      lastUpdateUser: null,
      manager: 'Cory',
      currentTeams: [
        {
          teamName: 'ELD Blue Dev Team',
          teamId: 'ELD-BLUE-DEV-TEAM',
          percentOfParticipation: 100,
          inactiveStartDate: null,
        },
        {
          teamName: 'Alcatraz Dev Team',
          teamId: 'ALCATRAZ-DEV-TEAM',
          percentOfParticipation: 100,
          inactiveStartDate: null,
        },
        {
          teamName: 'ACS2 B2B Dev Team',
          teamId: 'ACS2-B2B-DEV-TEAM',
          percentOfParticipation: 100,
          inactiveStartDate: null,
        },
        {
          teamName: 'Jess Earhart (service team)',
          teamId: '1489004768124',
          percentOfParticipation: 100,
          inactiveStartDate: null,
        },
      ],
      previousTeams: [],
    },
    {
      userId: 'tsime',
      userName: 'Simeroth, Thomas',
      timeFrameId: 32005,
      totalParticipationInTimeFrame: 35,
      reason: null,
      lastUpdateTime: null,
      lastUpdateUser: null,
      manager: 'Andrew',
      currentTeams: [
        {
          teamName: 'Ricochet',
          teamId: 'RICOCHET ELD',
          percentOfParticipation: 35,
          inactiveStartDate: null,
        },
      ],
      previousTeams: [],
    }, {
      userId: 'SEANDE1',
      userName: 'Andersen, Scott',
      timeFrameId: 32005,
      totalParticipationInTimeFrame: 400,
      reason: null,
      lastUpdateTime: null,
      lastUpdateUser: null,
      manager: 'Andrew Belzer',
      currentTeams: [],
      previousTeams: [
        {
          teamId: '8',
          teamName: 'Lab Platform Service Team (service team)',
          timeFrameId: 32004,
        },
      ],
    },
  ]

  const testDataFactory = () => cloneDeep(sampleData)


  it('returns the input if no arguments are passed in with it', () => {
    const searchTextMock = ''
    const initialValue = testDataFactory()

    const filteredValue = filterTable.filterPeople(searchTextMock, initialValue)

    expect(filteredValue).toEqual(initialValue)
  })

  it('accepts a list, string, and argument, and returns filtered list', () => {
    const searchTextMock = 'ACBE'
    const initialValue = testDataFactory()
    const expectedValue = [ initialValue[0] ]

    const filteredValue = filterTable.filterPeople(searchTextMock, initialValue)

    expect(filteredValue).toEqual(expectedValue)
  })

  it('Ignores case when filtering', () => {
    const initialValue = testDataFactory()
    const expectedValue = [ initialValue[0] ]
    const searchTextMock = 'aCb'

    const filteredValue = filterTable.filterPeople(searchTextMock, initialValue)

    expect(filteredValue).toEqual(expectedValue)
  })
  it('correctly filters based on currentTeams and previousTeams', () => {
    const initialValue = testDataFactory()
    const expectedValue = [ initialValue[1] ]
    const searchTextMock = 'ricochet'

    const filteredValue = filterTable.filterPeople(searchTextMock, initialValue)

    expect(filteredValue).toEqual(expectedValue)
  })
})
