import selector from '../../../../../public/scripts/selectors/people/isArchiveMonthSelected'

describe('isArchiveMonthSelected', () => {
  it('returns true is current month is archive month.', () => {
    const mockState = {
      archiveMonth: { id: 1337 },
      selectedTimeframe: { id: 1337 },
    }

    const result = selector(mockState)
    expect(result).toBe(true)
  })

  it('returns false if the current month is not the archive month', () => {
    const mockState = {
      archiveMonth: { id: 1234 },
      selectedTimeframe: { id: 8675309 },
    }

    const result = selector(mockState)
    expect(result).toBe(false)
  })
})
