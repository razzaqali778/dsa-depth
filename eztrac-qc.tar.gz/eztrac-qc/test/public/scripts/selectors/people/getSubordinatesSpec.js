import selector from '../../../../../public/scripts/selectors/people/getSubordinates'

const makePerson = ( num, manager ) => ({
  userId: `USERID${num}`,
  name: `Lastname${num}, Firstname${num}`,
  rateName: '',
  managerId: manager || `MGR${num}`,
})
const makePeople = () => [
  makePerson(1),
  makePerson(2),
  makePerson(3),
  makePerson(4, 'MGR3'),
  makePerson(5, 'MGR3'),
]

describe('get manager hierarchy', () => {
  it('works for single case', () => {
    const state = {
      allPeople: makePeople(),
      userId: 'mgr1',
    }
    const expected = [ 'userid1' ]
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })
  it('works recursively', () => {
    const state = {
      allPeople: makePeople(),
      userId: 'mgr3',
    }
    const expected = [ 'userid3', 'userid4', 'userid5' ]
    const actual = selector(state)
    expect(actual).toEqual(expected)
  })
})
