import selector from '../../../../../public/scripts/selectors/people/getReasonDescriptionMap'

describe('getReasonDescriptionMap', () => {
  it('returns an object of reason descriptions mapped to names', () => {
    const mockState = {
      reasons: [
        { reasonName: 'Part Time', description: 'some description', deactivatable: false },
        { reasonName: 'Employee Absence', description: 'some other description', deactivatable: true },
      ],
    }
    const expected = { 'Part Time': 'some description', 'Employee Absence': 'some other description' }
    const actual = selector(mockState)
    expect(actual).toEqual(expected)
  })
})
