import { getData } from '../../../../../public/scripts/selectors/initiativeqc/getDataWithTotals'

describe('getOrderedIssues', () => {
  const allTeamsStructure = [
    {
      teamId: 'Apple-Team',
      teamName: 'Apple Team',
      platformId: 'platform-2',
      communityId: 'community-3',
    },
    {
      teamId: 'Banana-Team',
      teamName: 'Banana Team',
      platformId: 'platform-3',
      communityId: 'community-2',
    },
    {
      teamId: 'Cantaloupe-Team',
      teamName: 'Cantaloupe Team',
      platformId: 'platform-2',
      communityId: 'community-1',
    },
  ]
  it('gets initiatives in descending order by team', () => {
    const mockState = {
      initiativeIssues: [
        {
          teamId: 'Banana-Team',
          teamName: 'Banana Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-3',
          communityId: 'community-2',
        },
        {
          teamId: 'Apple-Team',
          teamName: 'Apple Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-3',
        },
        {
          teamId: 'Cantaloupe-Team',
          teamName: 'Cantaloupe Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-1',
        },
      ],
      sortOrder: 'desc',
      sortBy: 'teamName',
      teamStructure: allTeamsStructure,
    }
    const expected = [
      {
        teamId: 'Cantaloupe-Team',
        teamName: 'Cantaloupe Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-1',
      },
      {
        teamId: 'Banana-Team',
        teamName: 'Banana Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-3',
        communityId: 'community-2',
      },
      {
        teamId: 'Apple-Team',
        teamName: 'Apple Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-3',
      },
    ]
    const actual = getData(mockState)
    expect(actual).toEqual(expected)
  })
  it('gets initiatives in ascending order by team', () => {
    const mockState = {
      initiativeIssues: [
        {
          teamId: 'Banana-Team',
          teamName: 'Banana Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-3',
          communityId: 'community-2',
        },
        {
          teamId: 'Apple-Team',
          teamName: 'Apple Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-3',
        },
        {
          teamId: 'Cantaloupe-Team',
          teamName: 'Cantaloupe Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-1',
        },
      ],
      sortOrder: 'asc',
      sortBy: 'teamName',
      teamStructure: allTeamsStructure,
    }
    const expected = [
      {
        teamId: 'Apple-Team',
        teamName: 'Apple Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-3',
      },
      {
        teamId: 'Banana-Team',
        teamName: 'Banana Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-3',
        communityId: 'community-2',
      },
      {
        teamId: 'Cantaloupe-Team',
        teamName: 'Cantaloupe Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-1',
      },
    ]
    const actual = getData(mockState)
    expect(actual).toEqual(expected)
  })

  it('gets initiatives in ascending order by platform', () => {
    const mockState = {
      initiativeIssues: [
        {
          teamId: 'Banana-Team',
          teamName: 'Banana Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-3',
          communityId: 'community-2',
        },
        {
          teamId: 'Apple-Team',
          teamName: 'Apple Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-3',
        },
        {
          teamId: 'Cantaloupe-Team',
          teamName: 'Cantaloupe Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-1',
        },
      ],
      sortOrder: 'asc',
      sortBy: 'platformId',
      teamStructure: allTeamsStructure,
    }
    const expected = [
      {
        teamId: 'Apple-Team',
        teamName: 'Apple Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-3',
      },
      {
        teamId: 'Cantaloupe-Team',
        teamName: 'Cantaloupe Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-1',
      },
      {
        teamId: 'Banana-Team',
        teamName: 'Banana Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-3',
        communityId: 'community-2',
      },
    ]
    const actual = getData(mockState)
    expect(actual).toEqual(expected)
  })

  it('gets initiatives in descending order by platform', () => {
    const mockState = {
      initiativeIssues: [
        {
          teamId: 'Banana-Team',
          teamName: 'Banana Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-3',
          communityId: 'community-2',
        },
        {
          teamId: 'Apple-Team',
          teamName: 'Apple Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-3',
        },
        {
          teamId: 'Cantaloupe-Team',
          teamName: 'Cantaloupe Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-1',
        },
      ],
      sortOrder: 'desc',
      sortBy: 'platformId',
      teamStructure: allTeamsStructure,
    }
    const expected = [
      {
        teamId: 'Banana-Team',
        teamName: 'Banana Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-3',
        communityId: 'community-2',
      },
      {
        teamId: 'Apple-Team',
        teamName: 'Apple Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-3',
      },
      {
        teamId: 'Cantaloupe-Team',
        teamName: 'Cantaloupe Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-1',
      },
    ]
    const actual = getData(mockState)
    expect(actual).toEqual(expected)
  })

  it('gets initiatives in ascending order by community', () => {
    const mockState = {
      initiativeIssues: [
        {
          teamId: 'Banana-Team',
          teamName: 'Banana Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-3',
          communityId: 'community-2',
        },
        {
          teamId: 'Apple-Team',
          teamName: 'Apple Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-3',
        },
        {
          teamId: 'Cantaloupe-Team',
          teamName: 'Cantaloupe Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-1',
        },
      ],
      sortOrder: 'asc',
      sortBy: 'communityId',
      teamStructure: allTeamsStructure,
    }
    const expected = [
      {
        teamId: 'Cantaloupe-Team',
        teamName: 'Cantaloupe Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-1',
      },
      {
        teamId: 'Banana-Team',
        teamName: 'Banana Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-3',
        communityId: 'community-2',
      },
      {
        teamId: 'Apple-Team',
        teamName: 'Apple Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-3',
      },
    ]
    const actual = getData(mockState)
    expect(actual).toEqual(expected)
  })

  it('gets initiatives in descending order by community', () => {
    const mockState = {
      initiativeIssues: [
        {
          teamId: 'Banana-Team',
          teamName: 'Banana Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-3',
          communityId: 'community-2',
        },
        {
          teamId: 'Apple-Team',
          teamName: 'Apple Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-3',
        },
        {
          teamId: 'Cantaloupe-Team',
          teamName: 'Cantaloupe Team',
          allocations: [{ status: 'Funded', data: 'other stuff' }],
          platformId: 'platform-2',
          communityId: 'community-1',
        },
      ],
      sortOrder: 'desc',
      sortBy: 'communityId',
      teamStructure: allTeamsStructure,
    }
    const expected = [
      {
        teamId: 'Apple-Team',
        teamName: 'Apple Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-3',
      },
      {
        teamId: 'Banana-Team',
        teamName: 'Banana Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-3',
        communityId: 'community-2',
      },
      {
        teamId: 'Cantaloupe-Team',
        teamName: 'Cantaloupe Team',
        allocations: [{ status: 'Funded', data: 'other stuff' }],
        platformId: 'platform-2',
        communityId: 'community-1',
      },
    ]
    const actual = getData(mockState)
    expect(actual).toEqual(expected)
  })


  it('sorts allocations by funded/not funded then alphabetically', () => {
    const mockState = {
      initiativeIssues: [
        {
          teamId: 'Apple-Team',
          teamName: 'Apple Team',
          allocations: [
            { status: 'Funded', name: 'Banana Initiative', data: 'other stuff' },
            { status: 'Funded', name: 'Orange Initiative', data: 'other stuff' },
            { status: 'Bad Status', name: 'Boo Initiative', data: 'other stuff' },
            { status: 'Funded', name: 'Apple Initiative', data: 'other stuff' },
            { status: 'Planning', name: 'Some Initiative', data: 'other stuff' },
            { status: 'Complete', name: 'An Initiative', data: 'other stuff' },
          ],
          platformId: 'platform-2',
          communityId: 'community-3',
        },
      ],
      sortOrder: 'asc',
      sortBy: 'teamName',
      teamStructure: allTeamsStructure,
    }
    const expected = [
      {
        teamId: 'Apple-Team',
        teamName: 'Apple Team',
        allocations: [
          { status: 'Complete', name: 'An Initiative', data: 'other stuff' },
          { status: 'Bad Status', name: 'Boo Initiative', data: 'other stuff' },
          { status: 'Planning', name: 'Some Initiative', data: 'other stuff' },
          { status: 'Funded', name: 'Apple Initiative', data: 'other stuff' },
          { status: 'Funded', name: 'Banana Initiative', data: 'other stuff' },
          { status: 'Funded', name: 'Orange Initiative', data: 'other stuff' },
        ],
        platformId: 'platform-2',
        communityId: 'community-3',
      },
    ]
    const actual = getData(mockState)
    expect(actual).toEqual(expected)
  })
})
