import rateUtil from '../../../Services/Util/RateUtil'
import config from '../../../config'

const makeMockPeople = () => [
  {
    userId: 'USERID1',
    name: 'Lastname1, Firstname1',
    rateName: '',
    managerId: 'MGR1',
  },
  {
    userId: 'USERID2',
    name: 'Lastname2, Firstname2',
    rateName: '',
    managerId: 'MGR2',
  },
  {
    userId: 'USERID3',
    name: 'Lastname3, Firstname3',
    rateName: '',
    managerId: 'MGR3',
  },
  {
    userId: 'USERID4',
    name: 'Lastname4, Firstname4',
    rateName: '',
    managerId: 'USERID3',
  },
  {
    userId: 'USERID5',
    name: 'Lastname5, Firstname5',
    rateName: '',
    managerId: 'USERID4',
  },
]

describe('RateUtilSpec', () => {
  const sampleData = [
    {
      userId: 'rclars1',
      totalParticipationInTimeFrame: 400,
      managerId: 'adbowm',
      rateValue: 100,
    },
    {
      userId: 'acbelz',
      totalParticipationInTimeFrame: 75,
      managerId: 'rmurphy',
      rateValue: 100,
    },
    {
      userId: 'rmurphy',
      managerId: 'sgarc2',
      rateValue: 100,
    },
  ]

  const monthlyHours = 160
  const standardRate = 100

  beforeAll(() => config.init())

  describe('rateCalcTotal', () => {
    it('returns $0 if given empty list of people', () => {
      const testUsers = []
      const expected = 0
      const actual = rateUtil.totalForUsers(testUsers)
      expect(actual).toBe(expected)
    })

    it('returns total for a single person', () => {
      const computedVal = 48000
      const expected = (( standardRate
        * (sampleData[0].totalParticipationInTimeFrame - 100)) / 100 ) * monthlyHours

      const initialValue = [ sampleData[0] ]
      const actual = rateUtil.totalForUsers(initialValue)
      expect(computedVal).toBe(expected)
      expect(actual).toBe(expected)
    })

    it('returns total for multiple people', () => {
      const computedVal = 68000
      const rate1 = (( standardRate
        * (sampleData[0].totalParticipationInTimeFrame - 100)) / 100 ) * monthlyHours
      const rate2 = (( standardRate
        * (100 - sampleData[1].totalParticipationInTimeFrame)) / 100 ) * monthlyHours

      const expected = rate1 + rate2 + (standardRate * monthlyHours)

      const actual = rateUtil.totalForUsers(sampleData)
      expect(computedVal).toBe(expected)
      expect(actual).toBe(expected)
    })
  })

  describe('get manager hierarchy', () => {
    it('works for single case', () => {
      const mockPeople = [ makeMockPeople()[0] ]
      const expected = [ 'userid1' ]
      const actual = rateUtil.getManagerHierarchy('mgr1', mockPeople)
      expect(actual).toEqual(expected)
    })
    it('works recursively', () => {
      const mockPeople = makeMockPeople()
      const expected = [ 'userid3', 'userid4', 'userid5' ]
      const actual = rateUtil.getManagerHierarchy('mgr3', mockPeople)
      expect(actual).toEqual(expected)
    })
  })
})
