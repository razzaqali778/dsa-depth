import * as Agent from '../../../common/Agent'
import config from '../../../config'
import { getPreviousTimeframe } from '../../../Services/Util/getCurrentTimeframe'
import AzureTokenUtil from '../../../Services/Util/AzureTokenUtil'

it('gets previous timeframe', async () => {
  await config.init()
  const url = config.get('ez-trac-urls').services['ez-trac-core']
  const sandbox = sinon.createSandbox()
  const getStub = sandbox.stub(Agent, 'get')
  const tokenStub = sandbox.stub(AzureTokenUtil, 'getAzureToken')
  tokenStub.resolves()

  const timeframes = [
    {
      name: 'Sep 2015',
      endDate: 1443657599000,
      employeeWorkDays: 20,
      id: '17226',
      contractorWorkDays: 20,
      startDate: 1441065600000,
      lockdown: false,
    },
    {
      name: 'Oct 2015',
      endDate: 1446335999000,
      employeeWorkDays: 20,
      id: '17227',
      contractorWorkDays: 20,
      startDate: 1443657600000,
      lockdown: false,
    },
    {
      name: 'Dec 2015',
      endDate: 1451606399000,
      employeeWorkDays: 20,
      id: '17229',
      contractorWorkDays: 20,
      startDate: 1448928000000,
      lockdown: false,
    },
    {
      name: 'Jan 2016',
      endDate: 1454284799000,
      employeeWorkDays: 20,
      id: '17230',
      contractorWorkDays: 20,
      startDate: 1451606400000,
      lockdown: false,
    },
    {
      name: 'Feb 2016',
      endDate: 1456790399000,
      employeeWorkDays: 20,
      id: '17231',
      contractorWorkDays: 20,
      startDate: 1454284800000,
      lockdown: false,
    },
  ]
  getStub
    .withArgs(`${url}/v2/timeframes`)
    .resolves({ body: timeframes })

  try {
    const previous = await getPreviousTimeframe(17231)
    const expected = {
      name: 'Jan 2016',
      endDate: 1454284799000,
      employeeWorkDays: 20,
      id: '17230',
      contractorWorkDays: 20,
      startDate: 1451606400000,
      lockdown: false,
    }
    expect(previous).toEqual(expected)
  } finally { sandbox.restore() }
})
