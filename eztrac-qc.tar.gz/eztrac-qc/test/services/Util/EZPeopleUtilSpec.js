import * as Agent from '../../../common/Agent'
import * as ManagerMapCache from '../../../Services/Util/ManagerMapCache'
import { fetchAllEztracPeople, getActivePeople, getAllPeople } from '../../../Services/Util/EZPeopleUtil'
import config from '../../../config'
import AzureTokenUtil from '../../../Services/Util/AzureTokenUtil'
import makeHeaders from '../../../Services/Util/makeHeaders'

describe( 'EZPeopleUtil', () => {
  let costingServices
  let peopleUrl
  beforeAll(async () => {
    await config.init()
    costingServices = config.get('ez-trac-urls').services['ez-trac-costing']
    peopleUrl = `${costingServices}/v1/people`
  })

  describe( 'fetchAllEztracPeople ', () => {
    it( 'Successfully fetches people', async () => {
      const sandbox = sinon.createSandbox()
      const getStub = sandbox.stub(Agent, 'get')
      const tokenStub = sandbox.stub(AzureTokenUtil, 'getAzureToken')

      const mockPeople = {
        body: [ 2 ],
      }
      const mockToken = 'goCubsGo'
      const headers = makeHeaders(mockToken)

      getStub
        .withArgs(peopleUrl, headers)
        .resolves(mockPeople)
      tokenStub
        .resolves(mockToken)

      const expected = mockPeople.body

      const result = await fetchAllEztracPeople()
      expect(result).toEqual(expected)
      sandbox.restore()
    })

    it( 'Handles error for getting people', async () => {
      const sandbox = sinon.createSandbox()
      const getStub = sandbox.stub(Agent, 'get')
      const tokenStub = sandbox.stub(AzureTokenUtil, 'getAzureToken')

      const mockPeopleError = {
        error: 'Broken',
      }
      const mockToken = 'goCubsGo'
      const headers = makeHeaders(mockToken)

      getStub
        .withArgs(peopleUrl, headers)
        .rejects(mockPeopleError)
      tokenStub
        .resolves(mockToken)
      try {
        await fetchAllEztracPeople()
      } catch ( err ) {
        expect(err).toEqual(mockPeopleError)
      } finally {
        sandbox.restore()
      }
    })
    it( 'Handles error for getting people with empty body', async () => {
      const sandbox = sinon.createSandbox()
      const getStub = sandbox.stub(Agent, 'get')
      const tokenStub = sandbox.stub(AzureTokenUtil, 'getAzureToken')

      const mockPeople = {
        body: [],
      }
      const mockPeopleError = new Error('People result is empty')
      const mockToken = 'goCubsGo'
      const headers = makeHeaders(mockToken)

      getStub
        .withArgs(peopleUrl, headers)
        .resolves(mockPeople)
      tokenStub
        .resolves(mockToken)
      try {
        await fetchAllEztracPeople()
      } catch ( err ) {
        expect(err).toEqual(mockPeopleError)
      } finally {
        sandbox.restore()
      }
    })
  })
  const makePerson = ( num, isActive ) => ({
    personId: `UID${num}`,
    rateName: `Rate${num}`,
    personName: `Name${num}`,
    isActive,
  })

  const makeMappedPerson = ( num, isActive ) => ({
    userId: `UID${num}`,
    rateName: `Rate${num}`,
    userName: `Name${num}`,
    managerId: `Mgr${num}`,
    isActive,
  })

  it( 'Gets all people', async () => {
    const mockManagerMap = {
      UID1: 'Mgr1',
      UID2: 'Mgr2',
      UID3: 'Mgr3',
    }

    const mockPeopleList = [ makePerson(1, true), makePerson(2, true), makePerson(3, false) ]
    const expectedPeople = [ makeMappedPerson(1, true), makeMappedPerson(2, true), makeMappedPerson(3, false) ]

    const sandbox = sinon.createSandbox()
    const getStub = sandbox.stub(Agent, 'get')
    const tokenStub = sandbox.stub(AzureTokenUtil, 'getAzureToken')
    const managerMapStub = sandbox.stub(ManagerMapCache, 'getManagerMap')

    const mockPeople = {
      body: mockPeopleList,
    }

    const mockToken = 'goCubsGo'
    const headers = makeHeaders(mockToken)

    getStub
      .withArgs(peopleUrl, headers)
      .resolves(mockPeople)
    tokenStub
      .resolves(mockToken)
    managerMapStub
      .resolves(mockManagerMap)

    try {
      const result = await getAllPeople()
      expect(result).toEqual(expectedPeople)
    } finally {
      sandbox.restore()
    }
  })

  it( 'Gets active people', async () => {
    const mockManagerMap = {
      UID1: 'Mgr1',
      UID2: 'Mgr2',
      UID3: 'Mgr3',
    }

    const mockPeopleList = [ makePerson(1, true), makePerson(2, true), makePerson(3, false) ]
    const expectedPeople = [ makeMappedPerson(1, true), makeMappedPerson(2, true) ]

    const sandbox = sinon.createSandbox()
    const getStub = sandbox.stub(Agent, 'get')
    const tokenStub = sandbox.stub(AzureTokenUtil, 'getAzureToken')
    const managerMapStub = sandbox.stub(ManagerMapCache, 'getManagerMap')

    const mockPeople = {
      body: mockPeopleList,
    }

    const mockToken = 'goCubsGo'
    const headers = makeHeaders(mockToken)

    getStub
      .withArgs(peopleUrl, headers)
      .resolves(mockPeople)
    tokenStub
      .resolves(mockToken)
    managerMapStub
      .resolves(mockManagerMap)

    try {
      const result = await getActivePeople()
      expect(result).toEqual(expectedPeople)
    } finally {
      sandbox.restore()
    }
  })
})
