import * as Agent from '../../../common/Agent'
import * as Combine from '../../../Services/Util/findParticipationIssues/combineParticipationDiscrepancies'
import config from '../../../config'
import { DEFAULT_MANAGER } from '../../../common/constants'
import { makeUnallocatedPeopleManager } from '../../makeTestData'
import AzureTokenUtil from '../../../Services/Util/AzureTokenUtil'
import messageUtil from '../../../Services/Util/MessageUtil'

describe('MessageUtilSpec', () => {
  const sandbox = sinon.createSandbox()

  let agentStub = {}

  let resStub = {}

  let azureTokenUtilStub = {}

  let peopleUtilStub = {}
  let configGetStub = null

  beforeAll(() => config.init())

  beforeEach( () => {
    agentStub = {
      post: sandbox.stub(Agent, 'post'),
    }

    azureTokenUtilStub = {
      getAzureToken: sandbox.stub(AzureTokenUtil, 'getAzureToken'),
    }

    resStub = {
      json: sandbox.stub(),
      status: sandbox.stub(),
      send: sandbox.stub(),
    }
    resStub.status.returns(resStub)

    peopleUtilStub = {
      combineParticipationDiscrepancies: sandbox.stub(Combine, 'combineParticipationDiscrepancies'),
    }
    configGetStub = sandbox.stub(config, 'get')
    configGetStub.withArgs('messaging-url').returns('messaging.velocity.ag')
  })

  afterEach( () => {
    sandbox.restore()
  })
  it('sends no messages in nonprod', async () => {
    const token = 'azureToken'
    azureTokenUtilStub.getAzureToken.resolves(token)
    configGetStub.withArgs('messaging-url').returns('messaging.velocity-np.ag')

    const peopleMock = makeUnallocatedPeopleManager()
    try {
      await messageUtil.sendVelocityMessage('JSCHU', peopleMock.JSCHU)
      expect(agentStub.post.called).toBe(false)
    } catch ( error ) {
      throw error
    }
  })
  it('sends no messages when passed an empty object', () => {
    messageUtil.sendVelocityMessage('', [])
    expect(agentStub.post.called).toBe(false)
  })

  it('sends a message when passed valid argument in prod', async () => {
    configGetStub.withArgs('peadmin-home').returns({ value: 'peadmin-np.monsanto.net' })
    const token = 'azureToken'
    const messageText = 'Schulte, James, you have 1 unallocated person.'

    azureTokenUtilStub.getAzureToken.resolves(token)

    const peopleMock = makeUnallocatedPeopleManager()
    try {
      await messageUtil.sendVelocityMessage('JSCHU', peopleMock.JSCHU)
      expect(agentStub.post.getCall(0).args[1].body.text).toEqual(messageText)
      expect(agentStub.post.getCall(0).args[1].body.markdown).toEqual(
        'Schulte, James, you have 1 unallocated person. <a href="https://peadmin-np.monsanto.net/ez-trac-qc/participation?showUnderMe=true">Ez-trac Participation QC</a>',
      )
    } catch ( error ) {
      throw error
    }
  })
  describe('generates list of people without reasons or default manager', () => {
    const makePerson = (num, reason = '', managerId = 'SOMEMANAGER', managerName = DEFAULT_MANAGER) => ({
      userId: `USER${num}`,
      userName: `NAME${num}`,
      managerName,
      managerId,
      reason,
    })
    const token = 'azureToken'
    beforeEach( () => {
      azureTokenUtilStub.getAzureToken.resolves(token)
    })
    it('works', async () => {
      const p1 = makePerson(1)
      const p2 = makePerson(2, '', 'USER1', 'NAME1')
      const p3 = makePerson(3, '', 'USER1', 'NAME1')
      const p4 = makePerson(4, 'SOMEREASON', 'USER1', 'NAME1')
      const p5 = makePerson(5, '', 'USER1', 'NAME1')

      const people = [ p1, p2, p3, p4, p5 ]

      const expected = { USER1: [ p2, p3, p5 ] }
      peopleUtilStub.combineParticipationDiscrepancies.resolves(people)

      try {
        const response = await messageUtil.getManagerGroupedPeopleWithoutReasons(32006)
        expect(response).toEqual(expected)
      } catch ( error ) {
        throw error
      }
    })
    it('works', async () => {
      const p1 = makePerson(1) // unallocated with default manager
      const p2 = makePerson(2, '', 'USER1', 'NAME1') // suboordinate of p1
      const p3 = makePerson(3, 'SOMEREASON', 'USER1', 'NAME1') // suboordinate of p2 with a reason
      const p4 = makePerson(4, '') // new manager person
      const p5 = makePerson(5, '', 'USER4', 'NAME4') // suboordinate of p2
      const p6 = makePerson(6, '', 'USER4', 'NAME4') // suboordinate of p2
      const p7 = makePerson(7, 'SOMEREASON', 'USER4', 'NAME4') // suboordinate of p2 w/ reason
      const p8 = makePerson(8, '', 'USER4', 'NAME4') // suboordinate of p2

      const people = [ p1, p2, p3, p4, p5, p6, p7, p8 ]
      const expected = {
        USER1: [ p2 ],
        USER4: [ p5, p6, p8 ],
      }
      peopleUtilStub.combineParticipationDiscrepancies.resolves(people)
      try {
        const response = await messageUtil.getManagerGroupedPeopleWithoutReasons(32006)
        expect(response).toEqual(expected)
      } catch ( error ) {
        throw error
      }
    })
    it('works', async () => {
      const p1 = makePerson(1)
      const p2 = makePerson(2, '', 'USER1', 'NAME1')
      const p3 = makePerson(3, '', 'USER1', 'NAME1')
      const p4 = makePerson(4, 'SOMEREASON', 'USER1', 'NAME1')
      const p5 = makePerson(5, '', 'USER1', 'NAME1')
      const p6 = makePerson(5, '', 'SOMEMANAGER', DEFAULT_MANAGER)
      const people = [ p1, p2, p3, p4, p5, p6 ]

      const expected = { USER1: [ p2, p3, p5 ] }
      peopleUtilStub.combineParticipationDiscrepancies.resolves(people)

      try {
        const response = await messageUtil.getManagerGroupedPeopleWithoutReasons(32006)
        expect(response).toEqual(expected)
      } catch ( error ) {
        throw error
      }
    })
  })
  describe('sendUnallocatedMessages', () => {
    let getManagerGroupedPeopleWithoutReasonsStub = {}

    let sendVelocityMessageStub = {}

    beforeEach( () => {
      getManagerGroupedPeopleWithoutReasonsStub = sandbox.stub(messageUtil, 'getManagerGroupedPeopleWithoutReasons')

      sendVelocityMessageStub = sandbox.stub(messageUtil, 'sendVelocityMessage')
    })

    it("sends message to unallocated peoples' manager", async () => {
      getManagerGroupedPeopleWithoutReasonsStub.resolves(makeUnallocatedPeopleManager())

      try {
        await messageUtil.sendUnallocatedMessages(32006)
        expect(sendVelocityMessageStub.callCount).toEqual(2)
      } catch ( error ) {
        throw error
      }
    })
  })
})
