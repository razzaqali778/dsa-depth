import * as Agent from '../../../common/Agent'
import * as EZPeopleUtil from '../../../Services/Util/EZPeopleUtil'
import { DEFAULT_MANAGER } from '../../../common/constants'
import {
  assignManagerName,
  filterInactiveWithoutReasons,
} from '../../../Services/Util/PeopleUtil'
import {
  combineParticipationDiscrepancies,
} from '../../../Services/Util/findParticipationIssues/combineParticipationDiscrepancies'
import AzureTokenUtil from '../../../Services/Util/AzureTokenUtil'
import personDiscrepancyDao from '../../../Services/dao/personDiscrepancyDao'
import config from '../../../config'

describe('PeopleUtil', () => {
  const sandbox = sinon.createSandbox()

  let azureTokenUtilStub = {}
  let agentStub = {}
  let resStub = {}
  let personDiscrepancyDaoStub = {}
  let getAllPeopleStub

  beforeAll(() => config.init())

  beforeEach( () => {
    azureTokenUtilStub = {
      getAzureToken: sandbox.stub(AzureTokenUtil, 'getAzureToken'),
    }

    personDiscrepancyDaoStub = sandbox.stub(personDiscrepancyDao, 'getDiscrepancyByTimeFrameId')

    getAllPeopleStub = sandbox.stub(EZPeopleUtil, 'getAllPeople')

    agentStub = {
      get: sandbox.stub(Agent, 'get'),
    }

    resStub = {
      json: sandbox.stub(),
      status: sandbox.stub(),
      send: sandbox.stub(),
    }
    resStub.status.returns(resStub)
  })

  afterEach( () => {
    sandbox.restore()
  })


  describe.skip('combineParticipationDiscrepancies', () => {
    it('given the timeFrameId, returns list of people from that Id', async () => {
      const timeFrameIdMock = '32005'
      const token = 'azureToken'
      const overUnderMock = {
        username: 'Robert Larson',
        userId: 'RCLARS1',
        timeFrameId: timeFrameIdMock,
        currentTeams: [{
          teamName: 'fake_team',
        }],
      }
      const missingPeopleMock = [{
        username: 'Jess Earhart',
        userId: 'JREARH',
        timeFrameId: timeFrameIdMock,
        previousTeams: [{
          teamName: 'fake_team',
          timeFrameId: '32004',
        }],
      },
      {
        username: 'Kara',
        userId: 'KWOLT',
        timeFrameId: timeFrameIdMock,
        previousTeams: [{
          teamName: 'fake_team',
          timeFrameId: '32004',
        }],
      }, {
        ...overUnderMock,
        other: 'stuff',
      }]

      const allPeopleList = [{
        userId: 'KWOLT',
        name: 'Test User',
        rateName: '',
        manager: 'JREARH',
        isActive: true,
      },
      {
        userId: 'JREARH',
        name: 'Test User',
        rateName: '',
        manager: 'KWOLT',
        isActive: true,
      },
      {
        userName: 'Robert Larson',
        userId: 'RCLARS1',
        rateName: '',
        manager: 'RMURPH',
        isActive: true,
      },
      {
        userName: 'Inactive Person To Be Filtered',
        userId: 'IPTBF',
        rateName: '',
        manager: 'DOESNTMATTER',
        isActive: false,
      }]

      const reasons = [ 'Part Time', 'Co-Op' ]

      azureTokenUtilStub.getAzureToken.resolves(token)
      getAllPeopleStub.resolves(allPeopleList)
      personDiscrepancyDaoStub.resolves(timeFrameIdMock)

      agentStub.get.onCall(0).resolves({ body: [ overUnderMock ] })
      agentStub.get.onCall(1).resolves({ body: missingPeopleMock })
      agentStub.get.onCall(2).resolves({ body: reasons })

      try {
        const response = await combineParticipationDiscrepancies(timeFrameIdMock)
        expect(response.length).toEqual(3)
        expect(response[0].currentTeams).not.toEqual(undefined)
        expect(response[1].previousTeams).not.toEqual(undefined)
      } catch ( error ) {
        throw error
      }
    })
  })

  const makeCachePerson = num => ({
    userId: `UID${num}`,
    name: `Name${num}`,
    manager: `MGR${num}`,
    rateName: 'Standard',
    isActive: false,
  })
  const makeDatabasePerson = num => ({
    timeframe_id: 32009,
    user_id: `UID${num}`,
    reason_name: 'SomeReason',
    last_updated_time: null,
    last_updated_user_id: null,
  })

  describe('showInactivePeople', () => {
    it('compares the list of people in the database and people in the cache and returns those who are inactive.', async () => { // eslint-disable-line max-len
      try {
        const sharedPerson = makeCachePerson(1)
        const peopleInCache = [ sharedPerson, makeCachePerson(2), makeCachePerson(3) ]
        const peopleInDatabase = [ makeDatabasePerson(1) ]


        const response = await filterInactiveWithoutReasons(peopleInCache, peopleInDatabase )

        expect(response).toEqual([ sharedPerson ])
      } catch ( error ) {
        throw error
      }
    })
  })

  const mockPeople = [ makeCachePerson(1), makeCachePerson(2), makeCachePerson(3) ]

  describe('assignManagerName', () => {
    it('finds a persons manager and returns it if it exists.', () => {
      const mockManager = {
        userId: 'MGR1',
        userName: 'menegeh',
        manager: 'MGR-1337',
        rateName: 'Mega',
        isActive: true,
      }

      const mockPerson = mockPeople[0]
      const mockUserId = mockPerson.userId
      const expected = [ mockManager.userName, mockPerson.manager ]

      const result = assignManagerName(mockUserId, mockPeople.concat(mockManager))

      expect(result).toEqual(expected)
    })

    it('Returns an alternative if the manager is not in EZ-TRAC.', () => {
      const result = assignManagerName('notRealId', mockPeople)
      const expected = [ DEFAULT_MANAGER, '' ]

      expect(result).toEqual(expected)
    })
  })
})
