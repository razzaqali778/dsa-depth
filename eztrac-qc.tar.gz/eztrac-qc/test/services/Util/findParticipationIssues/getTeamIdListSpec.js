import getTeamIdList
  from '../../../../Services/Util/findParticipationIssues/getTeamIdList'

it('get team id list from effort maps', () => {
  const effortMap = {
    user1: { teams: [{ teamId: 'team1' }] },
    user2: { teams: [{ teamId: 'team2' }, { teamId: 'team3' }] },
    user3: { teams: [] },
  }
  const previousEffortMap = {
    user1: { teams: [{ teamId: 'team4' }] },
    user2: { teams: [{ teamId: 'team2' }, { teamId: 'team3' }] },
    user3: { teams: [] },
  }
  // const peopleList = [{ userId: 'user1' }, { userId: 'user2' }, { userId: 'user3' }, { userId: 'user4' }]
  const peopleIdList = [ 'user1', 'user2', 'user3', 'user4', 'user5' ]

  const expected = [ 'team1', 'team2', 'team3', 'team4' ]
  const actual = getTeamIdList(peopleIdList, effortMap, previousEffortMap)

  expect(actual).toEqual(expected)
})

