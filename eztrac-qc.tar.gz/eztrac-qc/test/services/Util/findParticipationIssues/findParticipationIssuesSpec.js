import findIssues, { findNotAllocated, findOverUnderParticipation }
  from '../../../../Services/Util/findParticipationIssues/findParticipationIssues'

const makeEffortMember = (userId, teamId, percent) => ({
  timeFrameId: 1,
  teamId,
  percent,
  userId,
})

const makePerson = (userId, isActive = true) => ({
  userId,
  isActive,
})

describe('find over/under issues', () => {
  const p1 = makePerson('user1')
  const p2 = makePerson('user2')
  const p3 = makePerson('user3')
  const p4 = makePerson('user4')
  const p5 = makePerson('user5', false)

  const allPeople = [ p1, p2, p3, p4, p5 ]

  it('finds people who are under allocated', () => {
    const m1 = makeEffortMember('user1', 'team1', 30)
    const m2 = makeEffortMember('user1', 'team2', 30)
    const m3 = makeEffortMember('user2', 'team1', 100)
    const m4 = makeEffortMember('user3', 'team1', 50)
    const m5 = makeEffortMember('user3', 'team2', 50)
    const m6 = makeEffortMember('user4', 'team5', 80)

    const effortMembers = [ m1, m2, m3, m4, m5, m6 ]
    const expected = [ p1, p4 ]
    const actual = findOverUnderParticipation(allPeople, effortMembers)

    expect(actual).toEqual(expected)
  })

  it('finds people who are over allocated', () => {
    const m1 = makeEffortMember('user1', 'team1', 30)
    const m2 = makeEffortMember('user1', 'team2', 90)
    const m3 = makeEffortMember('user2', 'team1', 100)
    const m4 = makeEffortMember('user3', 'team1', 50)
    const m5 = makeEffortMember('user3', 'team2', 50)
    const m6 = makeEffortMember('user4', 'team5', 150)

    const effortMembers = [ m1, m2, m3, m4, m5, m6 ]
    const expected = [ p1, p4 ]
    const actual = findOverUnderParticipation(allPeople, effortMembers)

    expect(actual).toEqual(expected)
  })

  it('finds people who are not allocated', () => {
    const expected = [ p1, p2, p3, p4 ]
    const actual = findNotAllocated(allPeople, [])

    expect(actual).toEqual(expected)
  })

  it('finds people who are not allocated', () => {
    const expected = [ p1, p2 ]
    const effortMembers = [
      makeEffortMember('user3', 'team1', 10),
      makeEffortMember('user4', 'team2', 1),
      makeEffortMember('user10', 'team5', 100),
    ]
    const actual = findNotAllocated(allPeople, effortMembers)

    expect(actual).toEqual(expected)
  })


  it('finds all people with issues and maps them', () => {
    const currentEffortMembers = [
      makeEffortMember('user3', 'team1', 10),
      makeEffortMember('user4', 'team2', 1),
      makeEffortMember('user10', 'team5', 100),
      makeEffortMember('user2', 'team2', 50),
      makeEffortMember('user2', 'team3', 50),
    ]
    const previousEffortMembers = [
      makeEffortMember('user3', 'team1', 20),
      makeEffortMember('user4', 'team2', 2),
      makeEffortMember('user10', 'team5', 100),
      makeEffortMember('user1', 'team4', 100),
    ]

    const expected = {
      people: [ p3, p4, p1 ],
      effortMap: {
        user3: {
          teams: [{ teamId: 'team1', percent: 10 }],
          total: 10,
        },
        user4: {
          teams: [{ teamId: 'team2', percent: 1 }],
          total: 1,
        },
        user10: {
          teams: [{ teamId: 'team5', percent: 100 }],
          total: 100,
        },
        user2: {
          teams: [{ teamId: 'team2', percent: 50 }, { teamId: 'team3', percent: 50 }],
          total: 100,
        },
      },
      previousEffortMap: {
        user3: {
          teams: [{ teamId: 'team1', percent: 20 }],
          total: 20,
        },
        user4: {
          teams: [{ teamId: 'team2', percent: 2 }],
          total: 2,
        },
        user10: {
          teams: [{ teamId: 'team5', percent: 100 }],
          total: 100,
        },
        user1: {
          teams: [{ teamId: 'team4', percent: 100 }],
          total: 100,
        },
      },
    }

    const actual = findIssues({
      allPeople,
      effortMembers: currentEffortMembers,
      previousEffortMembers,
      teamMap: {
        team1: 'Team 1',
        team2: 'Team 2',
        team3: 'Team 3',
        team4: 'Team 4',
        team5: 'Team 5',
      },
    })

    expect(actual).toEqual(expected)
  })
})
