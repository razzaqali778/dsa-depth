import * as Combine from '../../../Services/Util/findParticipationIssues/combineParticipationDiscrepancies'
import * as dao from '../../../Services/dao/archivedDataDao'
import { fetchArchivedData, putArchivedData } from '../../../Services/Util/ArchivedDataUtil'
import config from '../../../config'

describe('ArchivedDataUtil', () => {
  beforeAll(() => config.init())

  it('puts archived data', async () => {
    const sandbox = sinon.createSandbox()
    const combinedStub = sandbox.stub(Combine, 'combineParticipationDiscrepancies' )
    combinedStub.resolves([ 'strings' ])
    const req = {
      params: { timeframeId: '30009' },
    }
    const res = {
      status: sinon.stub(),
      json: sinon.spy(),
    }
    res.status.returns(res)

    const upsertStub = sandbox.stub(dao, 'upsertArchivedDataByTimeframe')
    upsertStub.resolves()
    try {
      await putArchivedData(req, res)
      expect(upsertStub.args[0]).toEqual([ 30009, '["strings"]' ])
      expect(res.json.calledWith('OK')).toBe(true)
    } catch ( error ) {
      throw error
    } finally {
      sandbox.restore()
    }
  })
  it('does not try to put if given an invalid timeframeId', async () => {
    const sandbox = sinon.createSandbox()
    const combinedStub = sandbox.stub(Combine, 'combineParticipationDiscrepancies' )
    combinedStub.resolves([ 'strings' ])
    const req = {
      params: { timeframeId: 'banana' },
    }
    const res = {
      status: sinon.stub(),
      json: sinon.spy(),
    }
    res.status.returns(res)

    const upsertStub = sandbox.stub(dao, 'upsertArchivedDataByTimeframe')
    upsertStub.resolves()
    try {
      await putArchivedData(req, res)
      expect(upsertStub.callCount).toEqual(0)
      expect(res.status.calledWith(400)).toBe(true)
      expect(res.json.calledWith('Invalid timeframeId type')).toBe(true)
    } catch ( error ) {
      throw error
    } finally {
      sandbox.restore()
    }
  })
  it('returns an error if the upsert promise fails', async () => {
    const sandbox = sinon.createSandbox()
    const combinedStub = sandbox.stub(Combine, 'combineParticipationDiscrepancies' )
    combinedStub.resolves([ 'strings' ])
    const req = {
      params: { timeframeId: '123' },
    }
    const res = {
      status: sinon.stub(),
      json: sinon.spy(),
    }
    res.status.returns(res)

    const upsertStub = sandbox.stub(dao, 'upsertArchivedDataByTimeframe')
    const mockError = { error: "it didn't work" }
    upsertStub.rejects(mockError)
    try {
      await putArchivedData(req, res)
      expect(upsertStub.args[0]).toEqual([ 123, '["strings"]' ])
      expect(res.status.calledWith(500)).toBe(true)
      expect(res.json.calledWith(`Promise rejected by pg. Error: ${JSON.stringify(mockError)}`)).toBe(true)
    } catch ( error ) {
      throw error
    } finally {
      sandbox.restore()
    }
  })
  it('fetches Archived Data from the database successfully', async () => {
    const sandbox = sinon.createSandbox()
    const req = {
      params: { timeframeId: '30009' },
    }
    const res = {
      status: sinon.stub(),
      json: sinon.spy(),
    }
    res.status.returns(res)

    const getStub = sandbox.stub(dao, 'getArchivedDataByTimeframe')
    getStub.resolves('data')
    try {
      await fetchArchivedData(req, res)
      expect(getStub.args[0]).toEqual([ 30009 ])
      expect(res.json.calledWith('data')).toBe(true)
    } catch ( error ) {
      throw error
    } finally {
      sandbox.restore()
    }
  })
  it('does not try to get data if given an invalid timeframeId', async () => {
    const sandbox = sinon.createSandbox()
    const req = {
      params: { timeframeId: 'banana' },
    }
    const res = {
      status: sinon.stub(),
      json: sinon.spy(),
    }
    res.status.returns(res)

    const getStub = sandbox.stub(dao, 'getArchivedDataByTimeframe')
    getStub.resolves({ body: 'data' })
    try {
      await putArchivedData(req, res)
      expect(getStub.callCount).toEqual(0)
      expect(res.status.calledWith(400)).toBe(true)
      expect(res.json.calledWith('Invalid timeframeId type')).toBe(true)
    } catch ( error ) {
      throw error
    } finally {
      sandbox.restore()
    }
  })
  it('returns an error if the get promise fails', async () => {
    const sandbox = sinon.createSandbox()
    const req = {
      params: { timeframeId: '32009' },
    }
    const res = {
      status: sinon.stub(),
      json: sinon.spy(),
    }
    res.status.returns(res)

    const getStub = sandbox.stub(dao, 'getArchivedDataByTimeframe')
    const mockError = { error: "it didn't work" }
    getStub.rejects(mockError)
    try {
      await fetchArchivedData(req, res)
      expect(getStub.args[0]).toEqual([ 32009 ])
      expect(res.status.calledWith(500)).toBe(true)
      expect(res.json.calledWith(`Fetch promise rejected by pg. Error: ${JSON.stringify(mockError)}`)).toBe(true)
    } catch ( error ) {
      throw error
    } finally {
      sandbox.restore()
    }
  })
})
