import * as Agent from '../../../../common/Agent'
import * as makeHeaders from '../../../../Services/Util/makeHeaders'
import config from '../../../../config'
import { getEffortAllocation, getInitiativeList } from
  '../../../../Services/Util/findInitiativeIssues/effortAllocationUtil'

describe('getEffortAllocation', () => {
  beforeAll(() => config.init())

  it('calls the core-services with the correct url', async () => {
    const getStub = sinon.stub(Agent, 'get')
    const makeHeadersStub = sinon.stub(makeHeaders, 'makeTokenHeaders')
    makeHeadersStub.resolves({ auth: 'stuff' })
    const mockTimeframe = 12345
    const coreUrl = config.get('ez-trac-urls').services['ez-trac-core']

    getStub.resolves({ body: '' })
    getStub.withArgs(`${coreUrl}/v2/efforts/allocations/timeframes/${mockTimeframe}`, { auth: 'stuff' }).resolves({ body: 'someStuff' })
    try {
      const result = await getEffortAllocation(mockTimeframe)
      expect(result).toEqual('someStuff')
    } finally {
      getStub.restore()
      makeHeadersStub.restore()
    }
  })

  it('calls vip with the correct url', async () => {
    const vipUrl = config.get('ez-trac-urls').services['ez-trac-vip']

    const getStub = sinon.stub(Agent, 'get')
    const makeHeadersStub = sinon.stub(makeHeaders, 'makeTokenHeaders')
    makeHeadersStub.resolves({ auth: 'authStuff' })

    getStub.resolves({ body: '' })
    getStub.withArgs(`${vipUrl}/v2/initiatives`, { auth: 'authStuff' }).resolves({ body: 'someStuff' })
    try {
      const result = await getInitiativeList()
      expect(result).toEqual('someStuff')
    } finally {
      getStub.restore()
      makeHeadersStub.restore()
    }
  })
})

