import { findInitiativeIssues } from '../../../../Services/Util/findInitiativeIssues/findIssues'

describe( 'findIssues', () => {
  it('returns a list of teams whose allocation is not 100 percent funded', () => {
    const teamList = [
      { teamId: 'teamId1', initiativeId: 'initiativeA', percentageOfTeamCost: 50 },
      { teamId: 'teamId1', initiativeId: 'initiativeB', percentageOfTeamCost: 50 },
      { teamId: 'teamId2', initiativeId: 'initiativeC', percentageOfTeamCost: 100 },
    ]
    const initiativeList = [
      { id: 'initiativeA', initiativeName: 'Initiative A', status: 'Funded' },
      { id: 'initiativeB', initiativeName: 'Initiative B', status: 'Funded' },
      { id: 'initiativeC', initiativeName: 'Initiative C', status: 'Planning' },
    ]
    const mockTeamMap = { teamId1: 'Team 1', teamId2: 'Team 2', teamId3: 'Team 3' }

    const expected = [
      {
        teamId: 'teamId2',
        teamName: 'Team 2',
        allocations: [
          {
            name: 'Initiative C',
            initiativeId: 'initiativeC',
            percentageOfTeamCost: 100,
            status: 'Planning',
          },
        ],
      },
    ]
    const actual = findInitiativeIssues(teamList, initiativeList, mockTeamMap)
    expect(actual).toEqual(expected)
  })
  it('returns a list of teams whose allocation is not 100 percent funded', () => {
    const teamList = [
      { teamId: 'teamId1', initiativeId: 'initiativeA', percentageOfTeamCost: 50 },
      { teamId: 'teamId1', initiativeId: 'initiativeB', percentageOfTeamCost: 50 },
      { teamId: 'teamId2', initiativeId: 'initiativeC', percentageOfTeamCost: 80 },
      { teamId: 'teamId3', initiativeId: 'initiativeC', percentageOfTeamCost: 100 },
    ]
    const initiativeList = [
      { id: 'initiativeA', initiativeName: 'Initiative A', status: 'Funded' },
      { id: 'initiativeB', initiativeName: 'Initiative B', status: 'Completed' },
      { id: 'initiativeC', initiativeName: 'Initiative C', status: 'Funded' },
    ]
    const mockTeamMap = { teamId1: 'Team 1', teamId2: 'Team 2', teamId3: 'Team 3' }

    const expected = [
      {
        teamId: 'teamId1',
        teamName: 'Team 1',
        allocations: [
          {
            initiativeId: 'initiativeA', name: 'Initiative A', percentageOfTeamCost: 50, status: 'Funded',
          },
          {
            initiativeId: 'initiativeB', name: 'Initiative B', percentageOfTeamCost: 50, status: 'Completed',
          },
        ],
      },
      {
        teamId: 'teamId2',
        teamName: 'Team 2',
        allocations: [
          {
            initiativeId: 'initiativeC', name: 'Initiative C', percentageOfTeamCost: 80, status: 'Funded',
          },
        ],
      },
    ]
    const actual = findInitiativeIssues(teamList, initiativeList, mockTeamMap)
    expect(actual).toEqual(expected)
  })
})
