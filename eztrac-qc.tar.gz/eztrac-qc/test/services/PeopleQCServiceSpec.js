import * as Combine from '../../Services/Util/findParticipationIssues/combineParticipationDiscrepancies'
import * as EZPeopleUtil from '../../Services/Util/EZPeopleUtil'
import * as PeopleUtil from '../../Services/Util/PeopleUtil'

import {
  deleteReason,
  getPapiPeople,
  getParticipationDiscrepancies,
  putDiscrepancyReason,
} from '../../Services/PeopleQCService'
import PersonDiscrepancyDao from '../../Services/dao/personDiscrepancyDao'

describe(('PeopleQCService'), () => {
  const sandbox = sinon.createSandbox()

  let peopleUtilStub = {}
  let personDiscrepancyDaoStub = {}
  let resStub = {}
  let getPeopleStub = {}
  let fetchPersonStub

  beforeEach(() => {
    peopleUtilStub = {
      combineParticipationDiscrepancies: sandbox.stub(Combine, 'combineParticipationDiscrepancies'),
      convertObjects: sandbox.stub(PeopleUtil, 'convertObjects'),
    }

    sandbox.stub(EZPeopleUtil, 'getActivePeople')
    getPeopleStub = sandbox.stub(EZPeopleUtil, 'getAllPeople')

    personDiscrepancyDaoStub = {
      getDiscrepancyByTimeFrameAndUser: sandbox.stub(PersonDiscrepancyDao, 'getDiscrepancyByTimeFrameAndUser'),
      createDiscrepancyReason: sandbox.stub(PersonDiscrepancyDao, 'createDiscrepancyReason'),
      updateDiscrepancyReason: sandbox.stub(PersonDiscrepancyDao, 'updateDiscrepancyReason'),
      deleteDiscrepancyReason: sandbox.stub(PersonDiscrepancyDao, 'deleteDiscrepancyReason'),
    }

    fetchPersonStub = sandbox.stub(EZPeopleUtil, 'fetchPersonById')
    fetchPersonStub.resolves()

    resStub = {
      json: sandbox.stub(),
      status: sandbox.stub(),
      send: sandbox.stub(),
    }
    resStub.status.returns(resStub)
  })

  afterEach( () => {
    sandbox.restore()
  })

  describe(('getParticipationDiscrepancies'), () => {
    it(('returns participationDescrepancies and resolves promise'), async () => {
      const participationDescrepanciesMock = [{ name: 'john doe', id: 'jhndo' }]
      const request = { params: { timeFrameId: '32005' } }
      peopleUtilStub.combineParticipationDiscrepancies.resolves(participationDescrepanciesMock)

      try {
        await getParticipationDiscrepancies(request, resStub)
        expect(resStub.json.getCall(0).args[0]).toEqual(participationDescrepanciesMock)
      } catch ( error ) {
        throw error
      }
    })
    it('handles rejected promise', async () => {
      const errorMock = 'mock input'
      const request = { params: { timeFrameId: '32005' } }

      peopleUtilStub.combineParticipationDiscrepancies.rejects(new Error(errorMock))

      try {
        await getParticipationDiscrepancies(request, resStub)
        expect(resStub.status.getCall(0).args[0]).toEqual(500)
        expect(resStub.send.getCall(0).args[0].toString()).toEqual(`Error: ${errorMock}`)
      } catch ( error ) {
        throw error
      }
    })
  })

  describe('putDiscrepancyReason', () => {
    it('updates an existing person discrepancy when one already exists', async () => {
      personDiscrepancyDaoStub.getDiscrepancyByTimeFrameAndUser.resolves([{ timeFrameId: 32005, userId: 'testUser' }])
      const request = { body: { timeFrameId: '32005', userId: 'testUser' }, userProfile: { id: 'testUser' } }

      try {
        await putDiscrepancyReason(request, resStub)
        expect(personDiscrepancyDaoStub.updateDiscrepancyReason.called).toBe(true)
        expect(resStub.status.getCall(0).args[0]).toEqual(204)
      } catch ( error ) {
        throw error
      }
    })

    it('creates a new person discrepancy when it does not yet exist', async () => {
      personDiscrepancyDaoStub.getDiscrepancyByTimeFrameAndUser.resolves([])
      const request = { body: { timeFrameId: '32005', userId: 'testUser' }, userProfile: { id: 'testUser' } }

      try {
        await putDiscrepancyReason(request, resStub)
        expect(personDiscrepancyDaoStub.createDiscrepancyReason.called).toBe(true)
        expect(resStub.status.getCall(0).args[0]).toEqual(204)
      } catch ( error ) {
        throw error
      }
    })

    it('handles query errors', async () => {
      const errorMock = 'mock input'
      const request = { body: { timeFrameId: '32005', userId: 'testUser' } }

      personDiscrepancyDaoStub.getDiscrepancyByTimeFrameAndUser.rejects(new Error(errorMock))

      try {
        await putDiscrepancyReason(request, resStub)
        expect(resStub.status.firstCall.args[0]).toEqual(500)
        expect(resStub.json.firstCall.args[0].toString()).toEqual(`Error: ${errorMock}`)
      } catch ( error ) {
        throw error
      }
    })
    it('returns error when person doesnt exist', async () => {
      const request = { body: { timeFrameId: '32005', userId: 'testUser' } }
      fetchPersonStub.withArgs('TESTUSER').rejects({ status: 404, response: { text: 'NOT FOUND' } } )
      try {
        await putDiscrepancyReason(request, resStub)
        expect(resStub.status.firstCall.args[0]).toEqual(404)
        expect(resStub.json.firstCall.args[0]).toEqual({ status: 404, text: 'Error verifying person -- NOT FOUND' })
      } catch ( error ) {
        throw error
      }
    })
  })

  describe('deleteDiscrepancyReason', () => {
    it('deleted a selected reason from our table', async () => {
      personDiscrepancyDaoStub.getDiscrepancyByTimeFrameAndUser.resolves([{ timeFrameId: 32005, userId: 'testUser' }])
      const request = { params: { timeFrameId: '32005', userId: 'testUser' } }

      try {
        await deleteReason(request, resStub)
        expect(personDiscrepancyDaoStub.deleteDiscrepancyReason.called).toBe(true)
        expect(resStub.status.getCall(0).args[0]).toEqual(204)
      } catch ( error ) {
        throw error
      }
    })

    it('handles a non-existing reason being deleted', async () => {
      personDiscrepancyDaoStub.getDiscrepancyByTimeFrameAndUser.resolves([])
      const request = { params: { timeFrameId: '32005', userId: 'testUser' } }

      try {
        await deleteReason(request, resStub)
        expect(personDiscrepancyDaoStub.deleteDiscrepancyReason.called).toBe(false)
        expect(resStub.status.getCall(0).args[0]).toEqual(404)
        expect(resStub.send.getCall(0).args[0])
          .toEqual(`No discrepancy found for user ${request.params.userId} for the given time frame`)
      } catch ( error ) {
        throw error
      }
    })

    it('handles query errors', async () => {
      const errorMock = 'mock input'
      const request = { params: { timeFrameId: '32005', userId: 'testUser' } }

      personDiscrepancyDaoStub.getDiscrepancyByTimeFrameAndUser.rejects(new Error(errorMock))

      try {
        await deleteReason(request, resStub)
        expect(resStub.status.getCall(0).args[0]).toEqual(500)
        expect(resStub.send.getCall(0).args[0].toString()).toEqual(`Error: ${errorMock}`)
      } catch ( error ) {
        throw error
      }
    })
  })

  describe(('getPeopleFromCache'), () => {
    it('returns list of papiPeople and resolves promise', async () => {
      const papiPeopleSample = [
        {
          userId: 'rclars1',
          name: 'Cory Larson',
          rateName: 'wedontcare',
          manager: 'adbowm',
        }]

      const request = {}

      getPeopleStub.resolves(papiPeopleSample)

      try {
        await getPapiPeople(request, resStub)
        expect(resStub.json.getCall(0).args[0]).toEqual(papiPeopleSample)
      } catch ( error ) {
        throw error
      }
    })

    it('handles rejected promise', async () => {
      const errorMock = 'error'
      getPeopleStub.rejects(new Error(errorMock))

      const request = {}

      try {
        await getPapiPeople(request, resStub)
        expect(resStub.status.getCall(0).args[0]).toEqual(500)
        expect(resStub.send.getCall(0).args[0].toString()).toEqual(`Error: ${errorMock}`)
      } catch ( error ) {
        throw error
      }
    })
  })
})
