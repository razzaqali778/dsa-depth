import {
  getArchivedDataByTimeframe,
  storeArchivedData,
  updateArchivedDataByTimeframe,
  upsertArchivedDataByTimeframe,
} from '../../../Services/dao/archivedDataDao'

const client = require('../../../Services/db/db')

describe('ArchivedDataDao', () => {
  const sandbox = sinon.createSandbox()
  let clientStub = {}

  beforeEach(() => {
    clientStub = {
      any: sandbox.stub(client, 'any'),
      one: sandbox.stub(client, 'one'),
      none: sandbox.stub(client, 'none'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('getArchivedDataByTimeframe', () => {
    it('returns archived data successfully', async () => {
      const mockData = [{ data: 'huzzah' }]
      const getArchivedDataByTimeframeQuery = 'SELECT data FROM previous_timeframe_data WHERE timeframe_id = $1;'
      clientStub.any.resolves(mockData)

      try {
        const result = await getArchivedDataByTimeframe(100)
        expect(result).toEqual('huzzah')
        expect(clientStub.any.args[0]).toEqual([ getArchivedDataByTimeframeQuery, [ 100 ] ])
      } catch ( error ) {
        throw error
      }
    })
  })
  describe('storeArchivedData', () => {
    it('stores data in the database table successfully', async () => {
      const mockData = { data: 'huzzah' }
      const storeArchivedDataQuery = 'INSERT INTO previous_timeframe_data (timeframe_id, data) VALUES ($1, $2);'
      clientStub.none.resolves()

      try {
        await storeArchivedData(100, mockData)
        expect(clientStub.none.calledWith(storeArchivedDataQuery, [ 100, mockData ])).toBe(true)
      } catch ( error ) {
        throw error
      }
    })
  })
  describe('updateArchivedDataByTimeframe', () => {
    it('updates the data in the table sucessfully', async () => {
      const mockNewData = { data: 'data' }
      const updateArchivedDataByTimeframeQuery = 'UPDATE previous_timeframe_data SET data = $2 where timeframe_id = $1;'
      clientStub.none.resolves()

      try {
        await updateArchivedDataByTimeframe(123, mockNewData)
        expect(clientStub.none.calledWith(updateArchivedDataByTimeframeQuery, [ 123, mockNewData ])).toBe(true)
      } catch ( error ) {
        throw error
      }
    })
  })
  describe('upsertArchivedDataByTimeframe', () => {
    it('updates existing data in the database if data was previously stored', async () => {
      const mockData = { data: 'data' }
      const mockTimeframe = 123
      const countTimeframesQuery = 'SELECT COUNT(timeframe_id) FROM previous_timeframe_data WHERE timeframe_id = $1;'
      const updateArchivedDataByTimeframeQuery = 'UPDATE previous_timeframe_data SET data = $2 where timeframe_id = $1;'

      clientStub.one
        .withArgs(countTimeframesQuery, [ mockTimeframe ])
        .resolves({ count: '1' })
      try {
        await upsertArchivedDataByTimeframe(mockTimeframe, mockData)
        expect(clientStub.none.calledWith(updateArchivedDataByTimeframeQuery, [ mockTimeframe, mockData ])).toBe(true)
      } catch ( error ) {
        throw error
      }
    })
    it('adds  data to the database if data was not previously stored', async () => {
      const mockData = { data: 'data' }
      const mockTimeframe = 123
      const countTimeframesQuery = 'SELECT COUNT(timeframe_id) FROM previous_timeframe_data WHERE timeframe_id = $1;'
      const updateArchivedDataByTimeframeQuery = 'UPDATE previous_timeframe_data SET data = $2 where timeframe_id = $1;'
      const storeArchivedDataQuery = 'INSERT INTO previous_timeframe_data (timeframe_id, data) VALUES ($1, $2);'

      clientStub.one
        .withArgs(countTimeframesQuery, [ mockTimeframe ])
        .resolves({ count: '0' })
      try {
        await upsertArchivedDataByTimeframe(mockTimeframe, mockData)
        expect(clientStub.none.calledWith(updateArchivedDataByTimeframeQuery, [ mockTimeframe, mockData ])).toBe(false)
        expect(clientStub.none.calledWith(storeArchivedDataQuery, [ mockTimeframe, mockData ])).toBe(true)
      } catch ( error ) {
        throw error
      }
    })
  })
})
