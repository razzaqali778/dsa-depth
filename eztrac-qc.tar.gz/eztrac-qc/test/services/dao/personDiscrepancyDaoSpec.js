import {
  createDiscrepancyReason,
  deleteDiscrepancyReason,
  getDiscrepancyByTimeFrameAndUser,
  updateDiscrepancyReason,
} from '../../../Services/dao/personDiscrepancyDao'

const client = require('../../../Services/db/db')

describe('PersonDiscrepancyDao', () => {
  const sandbox = sinon.createSandbox()
  let clientStub = {}

  beforeEach(() => {
    clientStub = {
      any: sandbox.stub(client, 'any'),
      one: sandbox.stub(client, 'one'),
      none: sandbox.stub(client, 'none'),
    }
  })

  afterEach(() => {
    sandbox.restore()
  })

  describe('getDiscrepancyByTimeFrameAndUser', () => {
    it.skip('returns an error when the query fails', () => {
      clientStub.any.rejects('Bad Request')
      try {
        getDiscrepancyByTimeFrameAndUser(123, 'testUser')
      } catch ( error ) {
        expect(error.toString()).toEqual('Error: Bad Request')
      }
    })

    it('returns a list of discrepancy reasons for the given initiative when the query succeeds', async () => {
      const discrepancyReasons = [{ timeframe_id: 123, user_id: 'kwolt' }]
      clientStub.any.resolves(discrepancyReasons)

      try {
        const response = await getDiscrepancyByTimeFrameAndUser(123, 'kwolt')
        expect(response).toEqual(discrepancyReasons)
      } catch ( error ) {
        throw error
      }
    })
  })

  describe('createDiscrepancyReason', () => {
    it.skip('returns an error when the query fails', () => {
      const errorMock = 'Bad Request'
      clientStub.one.rejects(errorMock)
      try {
        createDiscrepancyReason({ timeFrameId: 123, userId: 'kwolt' })
      } catch ( error ) {
        expect(error.toString()).toEqual(`Error: ${errorMock}`)
      }
    })

    it('returns a the updatedTime for the discrepancy reason when the query succeeds', async () => {
      const updateTime = 'time'
      clientStub.one.resolves(updateTime)

      try {
        const response = await createDiscrepancyReason({ timeFrameId: 123, userId: 'kwolt' })
        expect(response).toEqual(updateTime)
      } catch ( error ) {
        throw error
      }
    })
  })

  describe('updateDiscrepancyReason', () => {
    it.skip('returns an error when the query fails', () => {
      const errorMock = 'Bad Request'
      clientStub.one.rejects(errorMock)
      try {
        updateDiscrepancyReason({ timeFrameId: 123, userId: 'kwolt' })
      } catch ( error ) {
        expect(error.toString()).toEqual(`Error: ${errorMock}`)
      }
    })

    it('returns a the updatedTime for the discrepancy reason when the query succeeds', async () => {
      const updateTime = 'time'
      clientStub.one.resolves(updateTime)

      try {
        const response = await updateDiscrepancyReason({ timeFrameId: 123, userId: 'kwolt' })
        expect(response).toEqual(updateTime)
      } catch ( error ) {
        throw error
      }
    })
  })

  describe('deleteDiscrepancyReason', () => {
    it.skip('returns an error when the query fails', () => {
      const errorMock = 'Bad Request'
      clientStub.none.rejects(errorMock)
      try {
        deleteDiscrepancyReason(123, 'kwolt')
      } catch ( error ) {
        expect(error.toString()).toEqual(`Error: ${errorMock}`)
      }
    })

    it('returns a the updatedTime for the discrepancy reason when the query succeeds', async () => {
      clientStub.none.resolves()

      try {
        const response = await deleteDiscrepancyReason(123, 'kwolt')
        expect(response).toEqual('deleted')
      } catch ( error ) {
        throw error
      }
    })
  })
})
