export function getDefaultBindings(ui, services) {
  return {
    "ez-trac-workflows": { url: ui["ez-trac-workflows"] },
    "ez-trac-qc-services": { url: services["ez-trac-qc"] },
    "vip-ui": { url: ui["ez-trac-vip"] },
    "peadmin-ez-trac-home": { url: ui["peadmin-ez-trac-home"] },
    "ez-trac-qc-ui": { url: ui["ez-trac-qc"] },
    "ez-trac-reporting-ui": { url: ui["ez-trac-reporting"] },
    "ez-trac-costing-services": { url: services["ez-trac-costing"] },
  };
}
