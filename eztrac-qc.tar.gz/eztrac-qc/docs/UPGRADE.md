# eztrac-qc — Node 22 / Toolchain Upgrade

This document summarizes the **uncommitted local changes** on `main` (as of the upgrade work) compared to `origin/main`. It is intended for reviewers, deployers, and anyone running the app locally via `eztrac-local-setup`.

**App version:** `1.3.3` (unchanged in `package.json`)  
**Baseline:** `origin/main` @ `38c3b5b`  
**Target Node:** `22.x` (was `18.x`)

---

## Executive summary

The upgrade modernizes the full JavaScript toolchain while keeping **React 17** and the existing Express/webpack-dev-middleware architecture:

| Area | Before | After |
|------|--------|-------|
| Node | 18.x | **22.x** |
| Babel | 6.x (`babel-preset-es2015`, `stage-2`) | **7.x** (`@babel/preset-env`, `@babel/preset-react`) |
| Webpack | 3.x | **5.x** |
| Jest | 21.x | **29.x** |
| ESLint | 3.x + `eslint-plugin-wyze` | **8.x** (Airbnb 19, wyze removed) |
| Hot reload | `react-hot-loader` + `piping` | **webpack-hot-middleware only** |
| Polyfills | `babel-polyfill`, `es6-promise` | **`core-js` 3** via `@babel/preset-env` `useBuiltIns: "usage"` |
| `@monsantoit/config` | ~2.1.0 | **~3.1.6** |
| Lockfile | `package-lock.json` committed | **Removed** (`preinstall` deletes lockfile; `legacy-peer-deps` in `.npmrc`) |

---

## Files changed

### Configuration & build

| File | Change |
|------|--------|
| `package.json` | Dependency major upgrades, `engines.node`, `overrides`, Jest/babel-jest config |
| `package-lock.json` | **Deleted** (repo uses `preinstall` to drop lockfiles) |
| `.babelrc` | Babel 7 presets/plugins; separate `env.test` block |
| `.npmrc` | Added `legacy-peer-deps=true` |
| `webpack.config.js` | Webpack 5 API (`rules`, `IgnorePlugin`, `CompressionPlugin`, MUI `.mjs` handling) |
| `.eslintrc` | ESLint 8 rules; removed `eslint-plugin-wyze`; `id-blacklist` → `id-denylist` |
| `test/.eslintrc` | Removed wyze rule |

### Application runtime

| File | Change |
|------|--------|
| `server.js` | `@babel/register` instead of `babel-register` + `babel-polyfill`; dropped webpack `noInfo` |
| `bin/www` | Removed `babel-polyfill` and deprecated `piping` server-side reload |
| `public/scripts/main.jsx` | Removed `react-hot-loader` / `AppContainer` / `es6-promise`; simplified `ReactDOM.render` |
| `public/scripts/Util/tableFilterUtil.js` | Added ES module `export` alongside existing CommonJS usage |

### Tests (all under `test/`)

| Pattern | Change |
|---------|--------|
| Async tests | Removed Jest 21 `done` callbacks; use `async () => { ... }` and `throw error` |
| Sinon | `sinon.sandbox.create()` → **`sinon.createSandbox()`** (Sinon 15 API) |
| DOM tests | Added `@jest-environment jsdom` docblock where `window` is used |
| Reject stubs | String rejects → **`new Error(...)`** where error message assertions expect `Error:` prefix |
| `test/_jestsetup.js` | Removed `sinon-as-promised`, `babel-polyfill`, `babel-register`; added `TextEncoder`/`TextDecoder` polyfill |

### New / generated artifacts

| File | Notes |
|------|--------|
| `public/scripts/bundle.js.LICENSE.txt` | Webpack 5 license extraction (untracked; typical after dev build) |

---

## Detailed changes by area

### 1. Node.js 18 → 22

```json
"engines": { "node": "22.x" }
```

**Impact:**

- Aligns with `eztrac-local-setup` `compose.yaml`, which builds the QC container with **Node 22** on `linux/amd64`.
- Local dev: use `nvm use 22` before `npm install` / `npm run dev`.
- CI/CD pipelines and Fargate base images must use Node 22.

---

### 2. Babel 6 → 7

**Removed:** `babel-cli`, `babel-core`, `babel-preset-es2015`, `babel-preset-stage-2`, `babel-polyfill`, `babel-plugin-transform-runtime` (v6)

**Added:**

- `@babel/core`, `@babel/cli`, `@babel/preset-env`, `@babel/preset-react`, `@babel/plugin-transform-runtime`, `@babel/register`, `@babel/runtime`
- `core-js@3` for automatic polyfills (`useBuiltIns: "usage"`)

**`.babelrc` highlights:**

- Production/dev: `@babel/preset-env` with browser targets `> 0.25%, not dead`
- Test: `BABEL_ENV=test` uses `targets: { node: "current" }`
- `@babel/plugin-transform-runtime` replaces inline Babel 6 runtime helpers

**Runtime entry points:**

- `server.js`: `require('@babel/register')` before loading JSX/server code
- `bin/www`: no longer imports `babel-polyfill` at startup

---

### 3. Webpack 3 → 5

| Item | Before | After |
|------|--------|-------|
| Module config | `loaders` | `rules` + `use` |
| JSON | `json-loader` | Built into Webpack 5 |
| `IgnorePlugin` | Legacy two-arg form | `{ resourceRegExp, contextRegExp }` |
| `CompressionPlugin` | `asset: '[path].gz[query]'` | `filename: '[path][base].gz[query]'` |
| Dev entry | `react-hot-loader/patch`, `babel-polyfill` | `webpack-hot-middleware/client` only |
| MUI / `.mjs` | — | `fullySpecified: false` for `.m?js` (fixes ESM/CJS interop) |

**Added:** `webpack-cli` (required for Webpack 5 CLI usage in production `webpack` script)

**Dev notes:**

- First webpack compile in dev can take **2–4+ minutes** (especially under Podman `linux/amd64` emulation on Apple Silicon).
- Webpack may warn that `mode` is unset (defaults to `production`); consider setting `mode: 'development'` in webpack config for clearer dev defaults.
- Bundle size warnings (~1.88 MiB) are expected; unchanged functionally from pre-upgrade behavior.

---

### 4. Hot module replacement (HMR)

**Removed:**

- `react-hot-loader` and `AppContainer` wrapper in `main.jsx`
- `piping` in `bin/www` (deprecated server-side reload)
- `react-hot-loader/babel` plugin from `.babelrc`

**Kept:**

- `webpack-hot-middleware` + `webpack-dev-middleware` in `server.js` (dev only)
- `webpack.HotModuleReplacementPlugin` in dev webpack config

**Local setup integration:** `eztrac-local-setup` applies `apply_qc_webpack_patch()` so HMR client targets `http://localhost:3040/__webpack_hmr` when using Ocelot on `:8080`. No change required in this repo for that patch to remain valid.

---

### 5. Jest 21 → 29

**`package.json` jest config additions:**

```json
"testEnvironment": "node",
"transform": { "^.+\\.jsx?$": "babel-jest" },
"moduleNameMapper": { "^sinon$": "<rootDir>/node_modules/sinon/lib/sinon.js" }
```

**Dev dependencies added:** `babel-jest`, `jest-environment-jsdom`, `jest-environment-node`

**Removed:** `sinon-as-promised` (promises work natively with Sinon 15 + async/await)

**Test migration patterns:**

```javascript
// Before (Jest 21)
it('does something', async done => {
  try {
    await fn()
    done()
  } catch (err) {
    done(err)
  }
})

// After (Jest 29)
it('does something', async () => {
  await fn()
})
```

```javascript
// Before
const sandbox = sinon.sandbox.create()

// After
const sandbox = sinon.createSandbox()
```

**Browser/DOM tests** — add at top of file:

```javascript
/**
 * @jest-environment jsdom
 */
```

Files updated with `@jest-environment jsdom`:

- `test/public/scripts/Util/Network/*.js` (archive, initiative, papiPeople, reason, timeframe)
- `test/public/scripts/Util/buttonFilterUtilSpec.js`

**`test/_jestsetup.js`:**

- Polyfills `TextEncoder` / `TextDecoder` from Node `util` for jsdom compatibility

---

### 6. ESLint 3 → 8

- Upgraded to `eslint@8`, `eslint-config-airbnb@19`, matching import/jsx-a11y/react plugins
- Added `eslint-plugin-react-hooks` (peer of Airbnb 19)
- **Removed `eslint-plugin-wyze`** and all `wyze/*` rules
- Renamed rule: `id-blacklist` → `id-denylist` (ESLint 8 deprecation)

---

### 7. Internal Bayer/Monsanto packages

| Package | Before | After |
|---------|--------|-------|
| `@monsantoit/config` | ~2.1.0 | **~3.1.6** |
| `@monsantoit/config-velocity-store` | ~1.1.0 | **~2.0.1** |
| `@monsantoit/ping-page` | 2.0.2 | **~2.0.11** |

`@monsantoit/config` v3 may change config loading, Vault integration, or Joi validation behavior. Verify:

- Local/dev config in `config/files/development.js`
- Fargate configs (`fargate-np.js`, `fargate-prod.js`)
- DB credentials via Vault paths

---

### 8. npm `overrides` (security & transitive deps)

A large `overrides` block was added to pin vulnerable or incompatible transitive dependencies, including:

- `lodash`, `js-yaml`, `joi`, `minimatch`, `brace-expansion`, `follow-redirects`, `validator`, `underscore`
- Nested overrides for `@monsantoit/config`, `@monsantoit/config-velocity-store`, `@monsantoit/phoenix-navbar`, `@monsantoit/oauth-azure`, `superagent`, `less-middleware`, `har-validator`

**Requires npm 8+** (Node 22 ships with npm 10). Overrides are ignored by older npm versions.

---

### 9. Other dependency changes

| Package | Notes |
|---------|--------|
| `express` | ~4.18.2 → **~4.22.0** |
| `lodash` | ~4.17.21 → **~4.18.0** |
| `less` / `less-middleware` | Bumped; `less-middleware` override pins compatible `less@^4.6.0` |
| `compression-webpack-plugin` | ~1.0.1 → **~12.0.0** |
| `sinon` | 1.17.4 → **~15.2.0** |
| `rimraf` | 2.5.2 → **~5.0.5** |
| `cross-env` | 1.0.8 → **~7.0.3** |
| `ajv` (dev) | ~7.2.4 → **~8.18.0** |

**Removed packages:** `es6-promise`, `promise`, `react-hot-loader`, `piping`, `json-loader`, `babel-polyfill`, all Babel 6 packages, `sinon-as-promised`, `eslint-plugin-wyze`

---

### 10. Application source (`tableFilterUtil.js`)

`public/scripts/Util/tableFilterUtil.js` now exports:

```javascript
export const { filterPeople } = filterTable
export default filterTable
```

Webpack/Babel transpile this for the bundle. Confirm no mixed import/require breakage in files that still `require()` this module.

---

## Local development (`eztrac-local-setup`)

Relevant container settings (in `eztrac-notes/eztrac-local-setup`):

| Setting | Value |
|---------|--------|
| Service | `qc` |
| Node image | **22-bookworm-slim** |
| Platform | **linux/amd64** (costing-ui also amd64; QC matches compose) |
| Port | **3040** |
| Command | `node --max-http-header-size=64000 ./bin/www` |
| `NODE_ENV` | `development` |

**Operational notes from local setup testing:**

1. **First `npm install` in container** is memory-heavy (~2 GB); increase Podman VM RAM to **8 GB** if install is `Killed`.
2. **Webpack compile** can take several minutes on emulated amd64.
3. **Ocelot SSO** requires corporate CA certs in `eztrac-local-setup/docker/certs/` (e.g. Bayer Group Root CA, **BAYER InternetProxy** for Vault TLS).
4. Access UI via **http://localhost:8080/ez-trac-qc/** (Ocelot), not raw `:3040`, for auth cookies.

Entrypoint patches applied at container start (not in this repo): `apply_qc_local_patch`, `apply_qc_webpack_patch`, `apply_phoenix_listen_patch`, `apply_db_container_patch`.

---

## Upgrade verification checklist

Run on **Node 22** with VPN (for Artifactory/Vault):

```bash
nvm use 22
npm install --legacy-peer-deps
npm run lint
npm run test:only
npm run dev          # dev server on PORT (default 3000; compose uses 3040)
```

**Manual smoke tests:**

- [ ] http://localhost:8080/ez-trac-qc/ping (or `:3040` direct)
- [ ] http://localhost:8080/ez-trac-qc/participation — page loads after Azure AD login
- [ ] Participation / reasons / archive API calls return data (not 500 DB errors)
- [ ] Webpack HMR / page refresh without console errors
- [ ] Production build: `npm run package` produces `public/scripts/bundle.js`

**Container smoke test** (from `eztrac-local-setup`):

```bash
make test   # includes qc ping, ocelot qc route, platforms proxy
```

---

## Known issues & follow-up work

### Incomplete test cleanup

Some tests still reference `done(err)` in `catch` blocks after removing the `done` parameter (will throw `ReferenceError` if those branches run):

- `test/public/scripts/Util/Network/archiveUtilSpec.js` (lines with `done(err)`)
- `test/services/Util/timeframeSpec.js`
- `test/services/Util/EZPeopleUtilSpec.js`

**Fix:** Remove `done(err)` and use `throw err` (or remove try/catch).

### Webpack `mode` warning

Dev builds log that `mode` is not set. Consider adding to `webpack.config.js`:

```javascript
mode: isProd ? 'production' : 'development',
```

### `package-lock.json`

Lockfile is intentionally not committed (`preinstall` removes it). Teams should rely on `overrides` + `legacy-peer-deps` for reproducible installs, or revisit lockfile policy if CI requires pinned trees.

### Runtime log noise

- `NODE_TLS_REJECT_UNAUTHORIZED=0` in local setup — expected for corporate TLS
- Intermittent `Socket abruptly closed` in QC logs during HMR — monitor; may be webpack-dev-middleware client disconnects

---

## Rollback

To discard all upgrade changes and return to `origin/main`:

```bash
git restore .
git clean -fd   # removes untracked files e.g. bundle.js.LICENSE.txt
```

To rollback only toolchain while keeping app fixes, revert `package.json` and config files selectively via `git checkout origin/main -- <file>`.

---

## Related documentation

- EZTrac local setup guide: `eztrac-notes/eztrac-local-setup/docs/GUIDE.md`
- QC Ocelot route source: `ocelot-config.json` (rewritten to `qc:3040` in container mode)
- Config / Vault: `config/files/development.js`, `config/files/fargate-np.js`

---

*Generated from working tree diff against `origin/main`. Update this document when the upgrade is committed or when additional changes land.*
