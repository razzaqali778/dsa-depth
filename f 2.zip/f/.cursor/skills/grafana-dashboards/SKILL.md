---
name: grafana-dashboards
description: Create and maintain Grafana dashboards for the FLEX observability stack (Tempo, Prometheus, Loki). Use when adding panels, exporting dashboard JSON, or troubleshooting traces/metrics visualization.
---

# FLEX Grafana Dashboards

## When to use

- Adding or modifying observability dashboards for flex-api
- Exporting a panel from Grafana Explore into version-controlled JSON
- Troubleshooting missing traces or metrics in Grafana

## Local stack

Start with `make observability`. Key URLs:

| Service | URL |
|---------|-----|
| Grafana | http://localhost:3001 |
| Prometheus | http://localhost:9090 |
| Tempo | http://localhost:3200 |

## Datasource UIDs (pre-provisioned)

| UID | Type | Use for |
|-----|------|---------|
| `tempo` | Tempo | Distributed traces |
| `prometheus` | Prometheus | RED metrics from OTEL collector |
| `loki` | Loki | Logs (future) |

Config: [`infra/grafana/provisioning/datasources/datasources.yaml`](../../../infra/grafana/provisioning/datasources/datasources.yaml)

## Workflow: add a new dashboard

1. Start stack: `make observability`
2. Generate traffic: `curl http://localhost:3000/api/auth/summary`
3. Open Grafana → **Explore** → pick **Tempo** or **Prometheus**
4. Build and validate the query
5. **Dashboards → New → Import from panel** or save full dashboard
6. **Share → Export → Save to file**
7. Save JSON to `infra/grafana/dashboards/<name>.json`
8. Reload Grafana (or restart `grafana` container) — file provider auto-loads from `/var/lib/grafana/dashboards`

Provisioning entry: [`infra/grafana/provisioning/dashboards/dashboards.yaml`](../../../infra/grafana/provisioning/dashboards/dashboards.yaml)

## Example queries

### Tempo (TraceQL)

```traceql
{ resource.service.name = "flex-api" }
```

```traceql
{ resource.service.name = "flex-api" && status = error }
```

### Prometheus (OTEL HTTP metrics)

```promql
sum(rate(http_server_duration_milliseconds_count{job="otel-collector"}[5m]))
```

```promql
histogram_quantile(0.95, sum(rate(http_server_duration_milliseconds_bucket{job="otel-collector"}[5m])) by (le))
```

## Existing dashboards (copy patterns from these)

| File | Purpose |
|------|---------|
| `infra/grafana/dashboards/flex-api-traces.json` | Trace search + error traces |
| `infra/grafana/dashboards/flex-api-metrics.json` | Request rate, p95, 5xx |
| `infra/grafana/dashboards/flex-platform-overview.json` | Landing overview with links |

## NestJS span attributes

Custom instrumentation sets:

- `controller.class`, `controller.handler`, `user.id` — HTTP layer
- `service.method` — `@Traced()` service layer

Auto-instrumentation adds standard `http.*` and `db.*` attributes when DB clients are active.

## Correlations

Datasources are linked for trace → log drill-down (Loki ready for future log shipping). Use Grafana's **Explore** trace view → **Logs for this span** when Loki is populated.

## Docs

- [docs/observability.md](../../../docs/observability.md)
- [plans/sonar_otel_grafana.md](../../../plans/sonar_otel_grafana.md)
