const packageJson = require('./package.json')

const config = {
    projectId: 'ab233cde-d859-4eaa-a486-c749833582a7',
    projectName: packageJson.name,
    contextRoot: 'ez-trac-costing',
    team: 'WORKFORCE-DEV-ADMINS',
    pipelineClientId: 'fc5e8fa2-cae2-4b2b-a958-da09257cc72c',
    deployableVersion: packageJson.version,
    quiet: true,
}
module.exports = config
