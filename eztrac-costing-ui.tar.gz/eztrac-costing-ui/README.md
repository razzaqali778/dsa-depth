# EZ-Trac Costing UI

## AWS App Name
  `eztrac-costing-ui`

## Description
  React/redux UI for adding people, cost groups, or rates, and editing attributes on people, including isActive, their cost group, and/or their rate.

## Dependencies
  * ez-trac-costing-services
  * papi

## Running as localhost

  This project was setup before running local Ocelot.  It should work by hitting it's port directly on your localhost.
  In your browser you will now hit the URL: http://localhost:3031/ez-trac-costing
  
