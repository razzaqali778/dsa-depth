#!/bin/bash

# Set script path and set common env vars
SCRIPT_PATH="${BASH_SOURCE%/*}"
source "$SCRIPT_PATH/vars.sh"

# Install/Set nvm version and run build commands
/bin/bash "$SCRIPT_PATH/nvm-install-use.sh"
/bin/bash "$SCRIPT_PATH/build.sh"

# Copy .cfignore to dist, move to dist, and prune
cp .cfignore dist/.
pushd dist
npm prune --production || exit 1

# Login to cloud foundry and deploy
/util/cf login -a api.mcf-np.threega.com -o workforce -s workforce -u velocity -p $CF_INTERNAL_PW --skip-ssl-validation
NODE_ENV=deploy cf-deploy --color=always --buildpack='https://github.com/cloudfoundry/buildpack-nodejs#v1.7.52' --domain mcf-np.local || exit 1


