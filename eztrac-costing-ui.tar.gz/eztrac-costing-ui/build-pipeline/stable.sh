#!/bin/bash

# Set script path and set common env vars
SCRIPT_PATH="${BASH_SOURCE%/*}"
source "$SCRIPT_PATH/vars.sh"

# Install/Set nvm version, push version, and run build commands
/bin/bash "$SCRIPT_PATH/nvm-install-use.sh"
/bin/bash "$SCRIPT_PATH/version-push.sh"
/bin/bash "$SCRIPT_PATH/build.sh"  || exit 1

# Move back to project root and determine version
popd
VERSION=$(node ./app-version.js)

# Copy .cfignore to dist, move to dist, and prune
cp .cfignore dist/.
pushd dist
npm prune --production || exit 1

# Login to cloud foundry and deploy
/util/cf login -a api.mcf-np.threega.com -o workforce -s workforce -u velocity -p $CF_INTERNAL_PW --skip-ssl-validation
NODE_ENV=deploy cf-deploy --color=always --buildpack='https://github.com/cloudfoundry/buildpack-nodejs#v1.7.42' --domain mcf-np.local || exit 1

# Pack artifact and upload to S3
npm pack || exit 1
aws s3 cp --sse AES256 *.tgz "$S3_PATH"/ || exit 1

# Call Release Approval CLI to add deployable to document
npm install @monsantoit/deploytool-cli
node_modules/.bin/deploytool add -d "$RELEASE_NAME" -t "$TEAM_ID" -c "$CMDB_ID" -v "$VERSION" --features "$RELEASE_FEATURES" --purpose "New Features" --platform "Transformation & Excellence" --clientId $CLIENT_ID --clientSecret $CLIENT_SECRET
