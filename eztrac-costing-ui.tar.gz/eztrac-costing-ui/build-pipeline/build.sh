#!/bin/bash

npm i -g @monsantoit/velocity-node-project-scanner
scan-nodejs-project . -g ez-trac --preferName true

npm config set registry https://registry.npmjs.org/
npm install || exit 1
npm run test || exit 1
npm run build || exit 1

