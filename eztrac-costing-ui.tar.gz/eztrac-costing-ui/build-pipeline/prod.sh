#!/bin/bash

# Set script path and set common env vars
SCRIPT_PATH="${BASH_SOURCE%/*}"
source "$SCRIPT_PATH/vars.sh"

# Signal to Release Approval Tool that the deployment has started
npm install -g @monsantoit/deploytool-cli@latest
deploytool deployed -t "$TEAM_ID" -c "$CMDB_ID" -v "$VERSION"

# Install/Set nvm version
/bin/bash "$SCRIPT_PATH/nvm-install-use.sh"

# Pull down tar ball for this version from S3 and untar it
aws s3 cp --sse AES256 "$S3_PATH/$DEPLOYABLE_NAME-$VERSION.tgz" ./ball.tgz || exit 1
tar zxvf ball.tgz || exit 1

# Move to package directory and run production install
pushd ./package
npm install --production

# make sure latest version of aws token util is used
npm install -g @monsantoit/get_aws_cf_temp_token@latest

# Login to cloud foundry and deploy
cf login -a "https://api.cf.threega.com/"  -u "$USERNAME" -p "$PASSWORD" -o workforce -s workforce || exit 1
NODE_ENV=deploy cf-deploy --color=always --buildpack='https://github.com/cloudfoundry/buildpack-nodejs#v1.7.42' --domain cf.local || exit 1