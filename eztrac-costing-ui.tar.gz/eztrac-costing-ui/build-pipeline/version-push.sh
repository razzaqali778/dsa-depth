#!/bin/bash

if [ -z ${BRANCH} ]
then
  BRANCH="main"
fi

if [ -z ${USER} ]
then
  USER="EZ-Trac Deploy User";
  EMAIL=eztrac@monsanto.com
else
  EMAIL="$USER@monsanto.com"
fi

# Set git config values
git config user.email "\"$EMAIL\""
git config user.name "\"$USER\""

# I have no earthly clue why this should be needed or work, but here we are
git checkout $BRANCH
git pull

# Update version and push change
npm version patch
git push origin $BRANCH --tags --force
