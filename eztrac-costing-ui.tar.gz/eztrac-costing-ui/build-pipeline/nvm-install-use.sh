#!/bin/bash

nvm install 10
nvm use 10
