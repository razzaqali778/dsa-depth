module.exports = {
  name: 'ez-trac-costing-ui',
  setupFiles: [ './test/_jestsetup' ],
  setupFilesAfterEnv: ['./test/_jest_matchers'],
  "globals": {
    "window": {
      location: {}
    },
    location: {}
  },
  testPathIgnorePatterns: [
    "src"
  ]
}
