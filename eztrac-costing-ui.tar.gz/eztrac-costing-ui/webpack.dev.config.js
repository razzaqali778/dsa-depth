const webpack = require("webpack");

const outputPath =
  process.env.NODE_ENV === "production"
    ? `${__dirname}/public/scripts/`
    : `${__dirname}/public/scripts/`;

module.exports = {
  mode: "development",
  devtool: "source-map",
  entry: ["./src/client/styles/style.scss", "./src/client"],
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        use: [
          {
            loader: "babel-loader",
            options: {
              babelrc: true,
            },
          },
        ],
        exclude: [/node_modules/],
      },
      { test: /\.s?css$/, use: ["style-loader", "css-loader", "sass-loader"] },
    ],
  },
  output: {
    filename: "bundle.js",
    path: outputPath,
    publicPath: "/ez-trac-costing/scripts/",
  },
  plugins: [
    new webpack.DefinePlugin({
      "process.env": {
        NODE_ENV: JSON.stringify("production"),
      },
    }),
  ],
  resolve: {
    extensions: [".js", ".json", ".jsx"],
  },
};