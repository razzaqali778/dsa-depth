const LightningExpressPlugin = require("./LightningExpressPlugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");

const outputPath =
  process.env.NODE_ENV === "production"
    ? `${__dirname}/public/scripts/`
    : `${__dirname}/public/scripts/`;

module.exports = {
  mode: "production",
  devtool: false,
  entry: ["./src/client/styles/style.scss", "./src/client"],
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        use: [
          {
            loader: "babel-loader",
            options: {
              babelrc: true,
            },
          },
        ],
        exclude: [/node_modules/],
      },
      {
        test: /\.scss|\.css$/,
        use: [MiniCssExtractPlugin.loader, "css-loader", "sass-loader"],
      },
    ],
  },
  output: {
    filename: "bundle.js",
    path: outputPath,
    publicPath: "/ez-trac-costing/scripts/",
  },
  plugins: [
    new LightningExpressPlugin(),
    new MiniCssExtractPlugin({
      filename: "../styles/style.css",
    }),
  ],
  resolve: {
    extensions: [".js", ".json", ".jsx"],
  },
};
