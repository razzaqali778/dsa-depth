export const urls = {
  coreServices: 'https://ez-trac-core-services.velocity-np.ag',
  costingServices: 'https://ez-trac-costing-services.velocity-np.ag',
  qcServices: 'https://ez-trac-qc-services.velocity-np.ag/ez-trac-qc/services',
  suggestionServices: 'https://ez-trac-suggestion.velocity-np.ag',
  papiUrl: 'https://profile.velocity-np.ag',
  messagingUrl: 'https://messaging.velocity-np.ag',
  teamsHookUrl: 'teamsHookUrl',
};
