import filter from '../../src/client/helpers/filter';

describe('Filter function', () => {
  it('returns the same array if given ALL', () => {
    const testArr = [1, 2, 3, 4];

    expect(filter(testArr, 'ALL')).toEqual(testArr);
  });

  it('returns active array if given ACTIVE', () => {
    const testArr = [
      { id: 1, isActive: false },
      { id: 2, isActive: false },
      { id: 3, isActive: true },
      { id: 4, isActive: false },
      { id: 5, isActive: true },
    ];
    const expectedRes = [
      { id: 3, isActive: true },
      { id: 5, isActive: true },
    ];

    expect(filter(testArr, 'ACTIVE')).toEqual(expectedRes);
  });

  it('returns inactive array if given INACTIVE', () => {
    const testArr = [
      { id: 1, isActive: false },
      { id: 2, isActive: false },
      { id: 3, isActive: true },
      { id: 4, isActive: false },
      { id: 5, isActive: true },
    ];
    const expectedRes = [
      { id: 1, isActive: false },
      { id: 2, isActive: false },
      { id: 4, isActive: false },
    ];

    expect(filter(testArr, 'INACTIVE')).toEqual(expectedRes);
  });
});
