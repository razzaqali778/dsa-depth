import { toastr } from 'react-redux-toastr';

expect.extend({
  toToastSuccess(received) {
    const pass = received.CALL.fn === toastr.success;

    if (pass) {
      return {
        message: () => 'expected toaster error',
        pass: true,
      };
    }

    return {
      message: () => 'expected toaster success',
      pass: false,
    };
  },
  toToastError(received) {
    const pass = received.CALL.fn === toastr.error;

    if (pass) {
      return {
        message: () => 'expected toaster success',
        pass: true,
      };
    }

    return {
      message: () => 'expected toaster error',
      pass: false,
    };
  },
});
