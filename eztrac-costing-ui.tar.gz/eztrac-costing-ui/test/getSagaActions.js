const getSagaActions = listener => {
  const gen = listener();
  const step = lastYield => gen.next(lastYield).value;

  return step().TAKE.pattern;
};

export default getSagaActions;
