global.phoenix = {
  authHeader: () => {},
  serviceBindings: {
    'profile-url': 'https://profile.velocity-np.ag',
    'velocity-home': 'velocity-np.ag',
  },
  urls: {
    services: {
      'ez-trac-costing': 'https://ez-trac-costing-services.velocity-np.ag',
    },
  },
};

window.phoenix = global.phoenix;

if (!global.performance) {
  global.performance = { now: () => Date.now() };
}

if (!window.performance) {
  window.performance = global.performance;
}
