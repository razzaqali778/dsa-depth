import selector from '../../../src/client/redux/selectors/getFilteredAudits';

describe('getFilteredAudits selector', () => {
  const augustDate = 1502390565000;
  const mayDate = 1494441765000;
  const februaryDate1 = 1486752165000;
  const februaryDate2 = 1486147365000;

  const auditData = [
    {
      entityType: 'person',
      entityKey: 'MAWIN',
      modifiedTime: augustDate,
      userId: 'JASKIDI',
      entity: { key: 'value', key2: 'thing' },
    },
    {
      entityType: 'rate',
      entityKey: 'STANDARD',
      modifiedTime: mayDate,
      userId: 'CODY',
      entity: { key: true },
    },
    {
      entityType: 'person',
      entityKey: 'MDLIND1',
      modifiedTime: februaryDate1,
      userId: 'JASKIDI',
      entity: { key: 'vALUe2' },
    },
    {
      entityType: 'cost_group',
      entityKey: 'BUSINESS-OPERATIONS',
      modifiedTime: februaryDate2,
      userId: 'MJLANE',
      entity: { key: 'value' },
    },
  ];

  it('returns audits matching given matching entity type', () => {
    const state = {
      audit: {
        data: auditData,
        searchText: 'perSo',
      },
    };

    const expected = [
      {
        entityType: 'person',
        entityKey: 'MAWIN',
        modifiedTime: augustDate,
        userId: 'JASKIDI',
        entity: { key: 'value', key2: 'thing' },
      },
      {
        entityType: 'person',
        entityKey: 'MDLIND1',
        modifiedTime: februaryDate1,
        userId: 'JASKIDI',
        entity: { key: 'vALUe2' },
      },
    ];

    expect(selector(state)).toEqual(expected);
  });

  it('returns audits matching given matching entityKey', () => {
    const state = {
      audit: {
        data: auditData,
        searchText: 'busi',
      },
    };

    const expected = [
      {
        entityType: 'cost_group',
        entityKey: 'BUSINESS-OPERATIONS',
        modifiedTime: februaryDate2,
        userId: 'MJLANE',
        entity: { key: 'value' },
      },
    ];

    expect(selector(state)).toEqual(expected);
  });

  it('returns audits matching given matching userID', () => {
    const state = {
      audit: {
        data: auditData,
        searchText: 'CODy',
      },
    };

    const expected = [
      {
        entityType: 'rate',
        entityKey: 'STANDARD',
        modifiedTime: mayDate,
        userId: 'CODY',
        entity: { key: true },
      },
    ];

    expect(selector(state)).toEqual(expected);
  });

  it('returns audits matching given matching entity values', () => {
    const state = {
      audit: {
        data: auditData,
        searchText: 'vAlu',
      },
    };

    const expected = [
      {
        entityType: 'person',
        entityKey: 'MAWIN',
        modifiedTime: augustDate,
        userId: 'JASKIDI',
        entity: { key: 'value', key2: 'thing' },
      },
      {
        entityType: 'person',
        entityKey: 'MDLIND1',
        modifiedTime: februaryDate1,
        userId: 'JASKIDI',
        entity: { key: 'vALUe2' },
      },
      {
        entityType: 'cost_group',
        entityKey: 'BUSINESS-OPERATIONS',
        modifiedTime: februaryDate2,
        userId: 'MJLANE',
        entity: { key: 'value' },
      },
    ];

    expect(selector(state)).toEqual(expected);
  });

  it('returns audits matching given matching date/time values', () => {
    const state = {
      audit: {
        data: auditData,
        searchText: 'augus',
      },
    };

    const expected = [
      {
        entityType: 'person',
        entityKey: 'MAWIN',
        modifiedTime: augustDate,
        userId: 'JASKIDI',
        entity: { key: 'value', key2: 'thing' },
      },
    ];

    expect(selector(state)).toEqual(expected);
  });
});
