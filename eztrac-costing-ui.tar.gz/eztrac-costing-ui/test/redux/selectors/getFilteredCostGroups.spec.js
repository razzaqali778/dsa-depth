import selector from '../../../src/client/redux/selectors/getFilteredCostGroups';

describe('getFilteredCostGroups selector', () => {
  const costGroupsData = [
    {
      name: 'Historic-Deprecated', costCenter: 'Unknown', id: 'ABC', isActive: false, modifiedBy: 'MDLIND1',
    },
    {
      name: 'IT', costCenter: 'other', id: '123', isActive: false, modifiedBy: 'MDLIND1',
    },
    {
      name: 'Not IT', costCenter: 'Unknown', id: 'XYZ', isActive: false, modifiedBy: 'MDLIND1',
    },
  ];

  it('returns cost groups with name containing given search text', () => {
    const state = {
      costGroups: {
        data: costGroupsData,
        searchText: 'IT',
      },
    };

    const expected = [
      {
        name: 'IT', costCenter: 'other', id: '123', isActive: false, modifiedBy: 'MDLIND1',
      },
      {
        name: 'Not IT', costCenter: 'Unknown', id: 'XYZ', isActive: false, modifiedBy: 'MDLIND1',
      },
    ];

    expect(selector(state)).toEqual(expected);
  });

  it('returns cost groups with cost center containing given search text', () => {
    const state = {
      costGroups: {
        data: costGroupsData,
        searchText: 'un',
      },
    };

    const expected = [
      {
        name: 'Historic-Deprecated', costCenter: 'Unknown', id: 'ABC', isActive: false, modifiedBy: 'MDLIND1',
      },
      {
        name: 'Not IT', costCenter: 'Unknown', id: 'XYZ', isActive: false, modifiedBy: 'MDLIND1',
      },
    ];

    expect(selector(state)).toEqual(expected);
  });

  it('returns cost groups given cost group ID', () => {
    const state = {
      costGroups: {
        data: costGroupsData,
        searchText: 'ABC',
      },
    };

    const expected = [
      {
        name: 'Historic-Deprecated', costCenter: 'Unknown', id: 'ABC', isActive: false, modifiedBy: 'MDLIND1',
      },
    ];

    expect(selector(state)).toEqual(expected);
  });
});
