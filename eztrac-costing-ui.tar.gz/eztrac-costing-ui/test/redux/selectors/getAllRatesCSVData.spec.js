import selector from '../../../src/client/redux/selectors/getAllRatesCSVData';

describe('getPeopleDataCSV', () => {
  it('produces a CSV with the provided data', () => {
    const state = {
      people: {
        data: [
          {
            personId: 'CCASE',
            personName: 'Cathy',
            rateName: 'CEO',
            costGroupName: 'PROD-DEV',
            isEmployee: true,
            isActive: true,
          },
          {
            personId: 'CCASE2',
            personName: 'Other Cathy',
            rateName: 'CTO',
            costGroupName: 'PROD-DEV',
            isEmployee: false,
            isActive: true,
          },
        ],
      },
      costGroups: {
        data: [
          {
            name: 'PROD-DEV', costCenter: 'other', id: 'HISTORIC', isActive: false, modifiedBy: 'MDLIND1',
          },
        ],
        searchText: 'PROD-DEV',
      },
      rate: {
        data: [],
        searchText: '',
      },
    };

    const expected = 'Rate,Name,CWID,Cost Group\r\n'
      + 'CEO,Cathy,CCASE,PROD-DEV\r\n'
      + 'CTO,Other Cathy,CCASE2,PROD-DEV';
    const actual = selector(state);

    expect(actual).toEqual(expected);
  });
});
