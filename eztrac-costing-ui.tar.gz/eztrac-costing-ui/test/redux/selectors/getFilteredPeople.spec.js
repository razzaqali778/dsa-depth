import selector from '../../../src/client/redux/selectors/getFilteredPeople';

describe('getFilteredPeople selector', () => {
  const peopleData = [{
    costGroupName: 'IT',
    isActive: true,
    isEmployee: true,
    modifiedBy: 'automatic',
    personId: 'ACOUR',
    personName: 'Courtney, Alex',
    rateName: '1904 Labs SOW',
  }, {
    costGroupName: 'Historic-Deprecated',
    isActive: true,
    isEmployee: true,
    modifiedBy: 'automatic',
    personId: 'YTAYE',
    personName: 'Taye, Yared',
    rateName: '1904 Labs SOW',
  }, {
    costGroupName: 'IT',
    isActive: true,
    isEmployee: true,
    modifiedBy: 'automatic',
    personId: 'YTAYE',
    personName: 'Cathy',
    rateName: 'Standard',
  }];

  it('returns people filtered by cost group search text', () => {
    const state = {
      people: {
        data: peopleData,
      },
      costGroups: {
        data: [
          {
            name: 'IT', costCenter: 'other', id: 'HISTORIC', isActive: false, modifiedBy: 'MDLIND1',
          },
        ],
        searchText: 'IT',
      },
      rate: {
        data: [],
        searchText: '',
      },
    };

    const expected = [
      {
        costGroupName: 'IT',
        isActive: true,
        isEmployee: true,
        modifiedBy: 'automatic',
        personId: 'ACOUR',
        personName: 'Courtney, Alex',
        rateName: '1904 Labs SOW',
      }, {
        costGroupName: 'IT',
        isActive: true,
        isEmployee: true,
        modifiedBy: 'automatic',
        personId: 'YTAYE',
        personName: 'Cathy',
        rateName: 'Standard',
      },
    ];

    expect(selector(state)).toEqual(expected);
  });

  it('returns people filtered by rates search text', () => {
    const state = {
      people: {
        data: peopleData,
      },
      costGroups: {
        data: [],
        searchText: '',
      },
      rate: {
        data: [
          {
            name: '1904 Labs SOW', hourlyRate: 135, id: '1904-LABS-SOW', isActive: true, modifiedBy: 'CLLANG',
          },
        ],
        searchText: 'Labs',
      },
    };

    const expected = [
      {
        costGroupName: 'IT',
        isActive: true,
        isEmployee: true,
        modifiedBy: 'automatic',
        personId: 'ACOUR',
        personName: 'Courtney, Alex',
        rateName: '1904 Labs SOW',
      },
      {
        costGroupName: 'Historic-Deprecated',
        isActive: true,
        isEmployee: true,
        modifiedBy: 'automatic',
        personId: 'YTAYE',
        personName: 'Taye, Yared',
        rateName: '1904 Labs SOW',
      },
    ];

    expect(selector(state)).toEqual(expected);
  });
});
