import selector from '../../../src/client/redux/selectors/getRateCSVData';

describe('getRateCSVData', () => {
  it('produces a CSV with the provided data', () => {
    const state = {
      rate: {
        ratePeoplePopup: {
          people: [
            {
              personId: 'CCASE',
              personName: 'Cathy',
              rateName: 'Standard',
              costGroupName: 'PROD-DEV',
              isEmployee: true,
              isActive: true,
            },
            {
              personId: 'CCASE2',
              personName: 'Other Cathy',
              rateName: 'Standard',
              costGroupName: 'PROD-DEV',
              isEmployee: false,
              isActive: true,
            },
          ],
          rate: {
            calendarId: 'STD-FIXED',
            hourlyRate: 135,
            id: 'Standard',
            isActive: true,
            modifiedBy: 'CLLANG',
            name: 'Standard',
          },
        },
      },
    };

    const expected = 'Name,CWID,Cost Group\r\n'
      + 'Cathy,CCASE,PROD-DEV\r\n'
      + 'Other Cathy,CCASE2,PROD-DEV';
    const actual = selector(state);

    expect(actual).toEqual(expected);
  });
});
