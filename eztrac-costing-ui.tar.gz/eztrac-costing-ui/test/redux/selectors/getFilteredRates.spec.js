import selector from '../../../src/client/redux/selectors/getFilteredRates';

describe('getFilteredRates selector', () => {
  const ratesData = [
    {
      calendarId: 'US-VARIABLE',
      hourlyRate: 100,
      id: 'testID',
      isActive: true,
      modifiedBy: 'automatic',
      name: 'Standard',
    },
    {
      calendarId: 'STD-FIXED',
      hourlyRate: 135,
      id: '1904-LABS-SOW',
      isActive: true,
      modifiedBy: 'automatic',
      name: '1904 Labs SOW',
    },
  ];

  it('returns rates with name containing given search text', () => {
    const state = {
      rate: {
        data: ratesData,
        searchText: 'Standard',
      },
    };

    const expected = [
      {
        calendarId: 'US-VARIABLE',
        hourlyRate: 100,
        id: 'testID',
        isActive: true,
        modifiedBy: 'automatic',
        name: 'Standard',
      },
    ];

    expect(selector(state)).toEqual(expected);
  });

  it('returns rates with given ID', () => {
    const state = {
      rate: {
        data: ratesData,
        searchText: 'testID',
      },
    };

    const expected = [
      {
        calendarId: 'US-VARIABLE',
        hourlyRate: 100,
        id: 'testID',
        isActive: true,
        modifiedBy: 'automatic',
        name: 'Standard',
      },
    ];

    expect(selector(state)).toEqual(expected);
  });
});
