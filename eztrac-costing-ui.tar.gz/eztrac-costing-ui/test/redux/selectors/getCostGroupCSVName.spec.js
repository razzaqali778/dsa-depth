import selector from '../../../src/client/redux/selectors/getCostGroupCSVName';

describe('getCostGroupCSVName', () => {
  it('returns the name of the file', () => {
    const state = {
      costGroups: {
        costGroupPeoplePopup: {
          people: [
            {
              personId: 'CCASE',
              personName: 'Cathy',
              rateName: 'CEO',
              costGroupName: 'PROD-DEV',
              isEmployee: true,
              isActive: true,
            },
            {
              personId: 'CCASE2',
              personName: 'Other Cathy',
              rateName: 'CTO',
              costGroupName: 'PROD-DEV',
              isEmployee: false,
              isActive: true,
            },
          ],
          costGroup: {
            id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
          },
        },
      },
    };

    const expected = 'Cost Group Product Development';
    const actual = selector(state);

    expect(actual).toEqual(expected);
  });

  it('empty string if there is an empty cost group', () => {
    const state = {
      costGroups: {
        costGroupPeoplePopup: {},
      },
    };

    const expected = '';
    const actual = selector(state);

    expect(actual).toEqual(expected);
  });
});
