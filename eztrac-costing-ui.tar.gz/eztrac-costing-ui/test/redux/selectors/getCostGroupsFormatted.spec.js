import selector from '../../../src/client/redux/selectors/getCostGroupsFormatted';

describe('getCostGroupsFormatted selector', () => {
  it('returns active cost groups formatted for react select', () => {
    const state = {
      costGroups: {
        data: [
          {
            id: 'costCenter-1', name: 'costCenter 1', costCenter: 'cc', isActive: true,
          },
          {
            id: 'costCenter-2', name: 'costCenter 2', costCenter: 'cc', isActive: true,
          },
          {
            id: 'costCenter-3', name: 'costCenter 3', costCenter: 'cc', isActive: false,
          },
        ],
      },
    };

    const expected = [
      { value: 'costCenter-1', label: 'costCenter 1' },
      { value: 'costCenter-2', label: 'costCenter 2' },
    ];

    expect(selector(state)).toEqual(expected);
  });
});
