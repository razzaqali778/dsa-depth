import selector from '../../../src/client/redux/selectors/getRateCSVName';

describe('getRateCSVName', () => {
  it('returns the name of the file', () => {
    const state = {
      rate: {
        ratePeoplePopup: {
          people: [
            {
              personId: 'CCASE',
              personName: 'Cathy',
              rateName: 'Standard',
              costGroupName: 'PROD-DEV',
              isEmployee: true,
              isActive: true,
            },
            {
              personId: 'CCASE2',
              personName: 'Other Cathy',
              rateName: 'Standard',
              costGroupName: 'PROD-DEV',
              isEmployee: false,
              isActive: true,
            },
          ],
          rate: {
            calendarId: 'STD-FIXED',
            hourlyRate: 135,
            id: 'Standard',
            isActive: true,
            modifiedBy: 'CLLANG',
            name: 'Standard',
          },
        },
      },
    };

    const expected = 'Standard Rate';
    const actual = selector(state);

    expect(actual).toEqual(expected);
  });
});
