import selector from '../../../src/client/redux/selectors/getFilteredEngagements';

const state = {
  engagements: {
    data: [
      {
        name: 'Ramis engagement',
        costGroupId: 'BUSINESS-OPERATIONS',
        purchaseOrder: 'PO1234',
        id: '4321',
      },
      {
        name: 'AArons engagement',
        costGroupId: 'PE-PD-WORKFORCE',
        purchaseOrder: 'PO 12345',
        id: '1235',
      },

    ],
  },
  costGroups: {
    data: [
      {
        id: 'BUSINESS-OPERATIONS',
        name: 'Ramis cost group',
      },
    ],
  },

};

describe('getFilteredEngagements selector', () => {
  it('gets filtered engagements by cost group', () => {
    const costGroupState = {
      engagements: { searchText: 'Ramis cost group', ...state.engagements },
      costGroups: { ...state.costGroups },
    };

    const expected = [
      {
        name: 'Ramis engagement',
        costGroupId: 'BUSINESS-OPERATIONS',
        purchaseOrder: 'PO1234',
        id: '4321',
      },
    ];

    const actual = selector(costGroupState);

    expect(actual).toEqual(expected);
  });

  it('gets filtered engagements by purchase order', () => {
    const purchaseOrderState = {
      engagements: { searchText: 'PO 12345', ...state.engagements },
      costGroups: { ...state.costGroups },
    };

    const expected = [
      {
        name: 'AArons engagement',
        costGroupId: 'PE-PD-WORKFORCE',
        purchaseOrder: 'PO 12345',
        id: '1235',
      },
    ];

    const actual = selector(purchaseOrderState);

    expect(actual).toEqual(expected);
  });

  it('gets filtered engagements by engagement name', () => {
    const engagementNameState = {
      engagements: { searchText: 'Ramis engagement', ...state.engagements },
      costGroups: { ...state.costGroups },
    };
    const expected = [
      {
        name: 'Ramis engagement',
        costGroupId: 'BUSINESS-OPERATIONS',
        purchaseOrder: 'PO1234',
        id: '4321',
      },
    ];

    const actual = selector(engagementNameState);

    expect(actual).toEqual(expected);
  });

  it('get filtered engagement by engagement id', () => {
    const engagementIdState = {
      engagements: { searchText: '4321', ...state.engagements },
      costGroups: { ...state.costGroups },
    };

    const expected = [
      {
        name: 'Ramis engagement',
        costGroupId: 'BUSINESS-OPERATIONS',
        purchaseOrder: 'PO1234',
        id: '4321',
      },
    ];

    const actual = selector(engagementIdState);

    expect(actual).toEqual(expected);
  });
});
