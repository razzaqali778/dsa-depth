import selector from '../../../src/client/redux/selectors/getRatesFormatted';

describe('getRatesFormatted selector', () => {
  it('returns active rates formatted for react select', () => {
    const state = {
      rate: {
        data: [
          {
            id: 'rate-1', name: 'rate 1', hourlyRate: 100, isActive: true,
          },
          {
            id: 'rate-2', name: 'rate 2', hourlyRate: 75, isActive: true,
          },
          {
            id: 'rate-3', name: 'rate 3', hourlyRate: 150, isActive: false,
          },
        ],
      },
    };

    const expected = [
      { value: 'rate-1', label: 'rate 1' },
      { value: 'rate-2', label: 'rate 2' },
    ];

    expect(selector(state)).toEqual(expected);
  });
});
