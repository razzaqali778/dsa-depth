import selector from '../../../src/client/redux/selectors/getCalendarsFormatted';

describe('Get Calendars Formatted selector', () => {
  it('returns calendars formatted for react select', () => {
    const state = {
      calendar: {
        data: [
          { calendarId: 'ARG-VARIABLE', calendarName: 'Argentina Variable Month Length' },
          { calendarId: 'BRZ-VARIABLE', calendarName: 'Brazil Variable Month Length' },
        ],
      },
    };

    const expected = [
      { value: 'ARG-VARIABLE', label: 'Argentina Variable Month Length' },
      { value: 'BRZ-VARIABLE', label: 'Brazil Variable Month Length' },
    ];

    expect(selector(state)).toEqual(expected);
  });
});
