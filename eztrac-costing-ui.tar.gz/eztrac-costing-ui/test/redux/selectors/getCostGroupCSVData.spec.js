import selector from '../../../src/client/redux/selectors/getCostGroupCSVData';

describe('getCostGroupCSVData', () => {
  it('produces a CSV with the provided data', () => {
    const state = {
      costGroups: {
        costGroupPeoplePopup: {
          people: [
            {
              personId: 'CCASE',
              personName: 'Cathy',
              rateName: 'CEO',
              costGroupName: 'PROD-DEV',
              isEmployee: true,
              isActive: true,
            },
            {
              personId: 'CCASE2',
              personName: 'Other Cathy',
              rateName: 'CTO',
              costGroupName: 'PROD-DEV',
              isEmployee: false,
              isActive: true,
            },
          ],
          costGroup: {
            id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
          },
        },
      },
    };

    const expected = 'Name,CWID,Rate\r\n'
      + 'Cathy,CCASE,CEO\r\n'
      + 'Other Cathy,CCASE2,CTO';
    const actual = selector(state);

    expect(actual).toEqual(expected);
  });
});
