import reducer from '../../../src/client/redux/reducers/filterReducer';

const initialState = {
  activeFilter: 'ACTIVE',
};

describe('Filter Reducer', () => {
  it('exports the correct default state', () => {
    expect(reducer()).toEqual(initialState);
  });
  it('sets the filter correctly given a new filter', () => {
    const action = {
      type: 'filter/SET_FILTER',
      payload: 'ALL',
    };

    const expected = {
      ...initialState,
      activeFilter: 'ALL',
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });
  it('clears the filter correctly given a new filter', () => {
    const action = {
      type: 'filter/CLEAR_FILTER',
    };

    const toBeCleared = {
      ...initialState,
      activeFilter: 'INACTIVE',
    };
    const cleared = {
      ...initialState,
      activeFilter: 'ACTIVE',
    };

    expect(reducer(toBeCleared, action)).toEqual(cleared);
  });
});
