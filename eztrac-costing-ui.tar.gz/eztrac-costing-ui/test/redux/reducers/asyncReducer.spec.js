import reducer from '../../../src/client/redux/reducers/asyncReducer';

describe('Cost Center Reducer Spec', () => {
  const emptyInitialState = {
    isUpdating: false,
  };

  it('exports the correct default state', () => {
    expect(reducer()).toEqual(emptyInitialState);
  });

  it('sets isUpdating to true when initial state is false', () => {
    const action = {
      type: 'async/SET_UPDATING',
      payload: true,
    };
    const initial = {
      isUpdating: false,
    };
    const expected = {
      isUpdating: true,
    };

    expect(reducer(initial, action)).toEqual(expected);
  });

  it('sets isUpdating to true when initial state is false', () => {
    const action = {
      type: 'async/SET_UPDATING',
      payload: false,
    };
    const initial = {
      isUpdating: true,
    };
    const expected = {
      isUpdating: false,
    };

    expect(reducer(initial, action)).toEqual(expected);
  });

  it('preserves isUpdating for unrelated actions', () => {
    const action = {
      type: 'rates/SET_ALL_RATE_DATA',
      payload: [],
    };
    const initial = {
      isUpdating: true,
    };

    expect(reducer(initial, action)).toEqual(initial);
  });
});
