import reducer from '../../../src/client/redux/reducers/peopleReducer';

const initialState = {
  data: [],
  isCreating: false,
  isEditing: false,
  papiData: [],
  person: {},
  personNotFound: { value: false },
};

describe('People Reducer', () => {
  it('exports the correct default state', () => {
    expect(reducer()).toEqual(initialState);
  });

  describe('isCreating', () => {
    it('state responds to isCreating', () => {
      const action = {
        type: 'people/TOGGLE_IS_CREATING',
        payload: true,
      };

      const expected = {
        ...initialState,
        isCreating: true,
      };

      expect(reducer(initialState, action)).toEqual(expected);
    });

    it('state is reset when responding to TOGGLE_IS_EDITING', () => {
      const initialStateIsCreating = {
        ...initialState,
        isCreating: true,
      };

      const action = {
        type: 'people/TOGGLE_IS_EDITING',
        payload: true,
      };

      const expected = {
        ...initialStateIsCreating,
        isCreating: false,
        isEditing: action.payload,
      };

      expect(reducer(initialStateIsCreating, action)).toEqual(expected);
    });
  });

  describe('isEditing', () => {
    it('state responds to TOGGLE_IS_EDITING', () => {
      const action = {
        type: 'people/TOGGLE_IS_EDITING',
        payload: true,
      };

      const expected = {
        ...initialState,
        isEditing: action.payload,
      };

      expect(reducer(initialState, action)).toEqual(expected);
    });

    it('state is reset when responding to SET_PERSON_DATA', () => {
      const initialStateIsEditing = {
        ...initialState,
        isEditing: true,
      };
      const action = {
        type: 'people/SET_PERSON_DATA',
        payload: { label: 'Matt L (MDLIND1)', value: 'MDLIND1' },
      };

      const expected = {
        ...initialStateIsEditing,
        isEditing: false,
        person: action.payload,
      };

      expect(reducer(initialStateIsEditing, action)).toEqual(expected);
    });

    it('state is reset when responding to TOGGLE_IS_CREATING', () => {
      const initialStateIsEditing = {
        ...initialState,
        isEditing: true,
      };
      const action = {
        type: 'people/TOGGLE_IS_CREATING',
        payload: true,
      };

      const expected = {
        ...initialStateIsEditing,
        isEditing: false,
        isCreating: action.payload,
      };

      expect(reducer(initialStateIsEditing, action)).toEqual(expected);
    });
  });

  describe('papiData', () => {
    it('state responds to SET_PAPI_DATA', () => {
      const action = {
        type: 'people/SET_PAPI_DATA',
        payload: [{ id: 'MDLIND1', firstName: 'Matt', lastName: 'Lindner' }],
      };

      const expected = {
        ...initialState,
        papiData: action.payload,
      };

      expect(reducer(initialState, action)).toEqual(expected);
    });
  });

  describe('person', () => {
    it('state responds to SET_PERSON_DATA', () => {
      const action = {
        type: 'people/SET_PERSON_DATA',
        payload: { label: 'Matt L (MDLIND1)', value: 'MDLIND1' },
      };

      const expected = {
        ...initialState,
        person: action.payload,
      };

      expect(reducer(initialState, action)).toEqual(expected);
    });

    it('state is reset when responding to SET_NOT_FOUND_PERSON', () => {
      const initialStateFoundPerson = {
        ...initialState,
        person: {
          value: 'MDLIND1',
          label: 'Matt L (MDLIND1)',
          personName: 'Matt L',
          employeeType: 'Employee',
        },
      };
      const action = {
        type: 'people/SET_NOT_FOUND_PERSON',
        payload: {
          value: true,
          personId: initialStateFoundPerson.person.value,
          personName: initialStateFoundPerson.person.label,
          employeeType: initialStateFoundPerson.person.employeeType,
        },
      };

      const expected = {
        ...initialStateFoundPerson,
        personNotFound: action.payload,
        person: {},
      };

      expect(reducer(initialStateFoundPerson, action)).toEqual(expected);
    });
  });

  describe('personNotFound', () => {
    it('state responds to SET_NOT_FOUND_PERSON', () => {
      const action = {
        type: 'people/SET_NOT_FOUND_PERSON',
        payload: { value: true, label: 'FAKE-PERSON' },
      };

      const expected = {
        ...initialState,
        personNotFound: action.payload,
      };

      expect(reducer(initialState, action)).toEqual(expected);
    });

    it('state is reset when responding to SET_PERSON_DATA', () => {
      const initialStatePersonNotFound = {
        ...initialState,
        personNotFound: { value: true, label: 'FAKE-PERSON' },
      };

      const action = {
        type: 'people/SET_PERSON_DATA',
        payload: { label: 'Matt L (MDLIND1)', value: 'MDLIND1' },
      };

      const expected = {
        ...initialStatePersonNotFound,
        personNotFound: { value: false },
        person: action.payload,
      };

      expect(reducer(initialStatePersonNotFound, action)).toEqual(expected);
    });
  });

  describe('data', () => {
    it('response to SET_ALL_PEOPLE_DATA', () => {
      const action = {
        type: 'people/SET_ALL_PEOPLE_DATA',
        payload: [
          {
            costGroupName: 'IT Business Operations',
            isActive: true,
            isEmployee: true,
            modifiedBy: 'automatic',
            personId: 'ACOUR',
            personName: 'Courtney, Alex',
            rateName: 'Standard',
          },
          {
            costGroupName: 'P&E PD',
            isActive: true,
            isEmployee: true,
            modifiedBy: 'automatic',
            personId: 'YTAYE',
            personName: 'Taye, Yared',
            rateName: 'Standard',
          },
        ],
      };

      const expected = {
        ...initialState,
        data: action.payload,
      };

      expect(reducer(initialState, action)).toEqual(expected);
    });
  });
});
