import reducer from '../../../src/client/redux/reducers/auditsReducer.js';

describe('auditsReducerSpec', () => {
  const emptyInitialState = {
    data: [],
    searchText: '',
  };

  it('exports correct default state', () => {
    expect(reducer()).toEqual(emptyInitialState);
  });

  it('Responds to SET_ALL_AUDIT_DATA', () => {
    const action = {
      payload: [{
        entityType: 'person',
        entityKey: 'MAWEIN',
        modifiedTime: 2322342423,
        userId: 'UserId',
        entity: { key: 'value' },
      }],
      type: 'audits/SET_ALL_AUDIT_DATA',
    };

    const expected = {
      ...emptyInitialState,
      data: action.payload,
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('Responds to SET_SEARCH_TEXT', () => {
    const action = {
      type: 'audits/SET_SEARCH_TEXT',
      payload: 'per',
    };

    const initialState = {
      ...emptyInitialState,
      data: [{
        entityType: 'person',
        entityKey: 'MAWEIN',
        modifiedTime: 2322342423,
        userId: 'UserId',
        entity: { key: 'value' },
      }],
    };

    const expected = {
      ...initialState,
      searchText: action.payload,
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });
});
