import reducer from '../../../src/client/redux/reducers/costGroupsReducer' //eslint-disable-line

describe('Cost Group Reducer Spec', () => {
  const emptyInitialState = {
    data: [],
    isCreating: false,
    isEditing: '',
    isUpdating: false,
    searchText: '',
    affectedPeoplePopup: {
      showPopup: false,
      people: [],
      costGroup: undefined,
    },
    costGroupPeoplePopup: {
      showPopup: false,
      people: [],
      costGroup: undefined,
    },
  };

  it('exports the correct default state', () => {
    expect(reducer()).toEqual(emptyInitialState);
  });

  it('responds to SET_PEOPLE_WITH_COST_GROUP_ID', () => {
    const action = {
      type: 'costGroups/SET_PEOPLE_WITH_COST_GROUP_ID',
      payload: {
        costGroup: {
          id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
        },
        people: [
          {
            personId: 'BOB',
            personName: 'ROBERT',
            rateName: 'CEO',
            costGroupName: 'PROD-DEV',
            isEmployee: false,
            isActive: true,
          },
          {
            personId: 'BOB2',
            personName: 'OTHER BOBBY',
            rateName: 'CTO',
            costGroupName: 'PROD-DEV',
            isEmployee: false,
            isActive: true,
          },
        ],
      },
    };

    const expected = {
      ...emptyInitialState,
      affectedPeoplePopup: {
        showPopup: true,
        people: action.payload.people,
        costGroup: action.payload.costGroup,
      },
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('Responds to VIEW_PEOPLE_WITH_COST_GROUP', () => {
    const action = {
      type: 'costGroups/VIEW_PEOPLE_WITH_COST_GROUP',
      payload: {
        costGroup: {
          id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
        },
        people: [
          {
            personId: 'BOB',
            personName: 'ROBERT',
            rateName: 'CEO',
            costGroupName: 'PROD-DEV',
            isEmployee: false,
            isActive: true,
          },
          {
            personId: 'BOB2',
            personName: 'OTHER BOBBY',
            rateName: 'CTO',
            costGroupName: 'PROD-DEV',
            isEmployee: false,
            isActive: true,
          },
        ],
      },
    };

    const expected = {
      ...emptyInitialState,
      costGroupPeoplePopup: {
        showPopup: true,
        people: action.payload.people,
        costGroup: action.payload.costGroup,
      },
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('responds to SET_ALL_COST_GROUP_DATA', () => {
    const action = {
      type: 'costGroups/SET_ALL_COST_GROUP_DATA',
      payload: [
        {
          id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
        },
        {
          id: 'TPS', name: 'Technology Pipeline Solutions', costCenter: '82AB', isActive: false,
        },
      ],
    };

    const expected = {
      ...emptyInitialState,
      data: action.payload,
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('responds to TOGGLE_IS_EDITING', () => {
    const action = {
      type: 'costGroups/TOGGLE_IS_EDITING',
      payload: 'CostGroup18',
    };
    const expected = {
      ...emptyInitialState,
      isEditing: 'CostGroup18',
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('responds to UPDATING_COST_GROUP', () => {
    const action = {
      type: 'costGroups/UPDATING_COST_GROUP',
      payload: true,
    };
    const expected = {
      ...emptyInitialState,
      isUpdating: true,
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('responds to UPDATE_COST_GROUP', () => {
    const initialState = {
      ...emptyInitialState,
      isEditing: 'CostGroup18',
      data: [
        {
          id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
        },
        {
          id: 'TPS', name: 'Technology Pipeline Solutions', costCenter: '82AB', isActive: false,
        },
      ],
      affectedPeoplePopup: {
        showPopup: true,
        people: [{
          personId: 'Cody',
          personName: 'Matt',
          rateName: 'STANDARD',
          costGroupName: 'Mike',
          isEmployee: true,
          isActive: true,
        }],
        costGroup: {
          id: 'PROD-DEV', name: 'Prod Dev', costCenter: 'AH28', isActive: true,
        },
      },
    };

    const action = {
      type: 'costGroups/UPDATE_COST_GROUP',
      payload: {
        id: 'PROD-DEV', name: 'Prod Dev', costCenter: 'AH28', isActive: true,
      },
    };
    const expected = {
      ...emptyInitialState,
      data: [
        {
          id: 'PROD-DEV', name: 'Prod Dev', costCenter: 'AH28', isActive: true,
        },
        {
          id: 'TPS', name: 'Technology Pipeline Solutions', costCenter: '82AB', isActive: false,
        },
      ],
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });

  it('responds to ADD_COST_GROUP', () => {
    const initialState = {
      ...emptyInitialState,
      data: [
        {
          id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
        },
        {
          id: 'TPS', name: 'Technology Pipeline Solutions', costCenter: '82AB', isActive: false,
        },
      ],
    };
    const action = {
      type: 'costGroups/ADD_COST_GROUP',
      payload: {
        id: 'TECH', name: 'Tech Platforms', costCenter: 'RT86', isActive: true,
      },
    };
    const expected = {
      ...emptyInitialState,
      data: [
        {
          id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
        },
        {
          id: 'TPS', name: 'Technology Pipeline Solutions', costCenter: '82AB', isActive: false,
        },
        {
          id: 'TECH', name: 'Tech Platforms', costCenter: 'RT86', isActive: true,
        },
      ],
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });

  it('responds to  CANCEL_COST_GROUP_PEOPLE_POPUP', () => {
    const initialState = {
      ...emptyInitialState,
      costGroupPeoplePopup: {
        showPopup: true,
        people: [{
          personId: 'Cody',
          personName: 'Matt',
          rateName: 'STANDARD',
          costGroupName: 'Mike',
          isEmployee: true,
          isActive: true,
        }],
        costGroup: 'Mike',
      },
    };

    const action = {
      type: 'costGroups/CANCEL_COST_GROUP_PEOPLE_POPUP',
    };

    expect(reducer(initialState, action)).toEqual(emptyInitialState);
  });

  it('responds to  CANCEL_AFFECTED_PEOPLE_POPUP', () => {
    const initialState = {
      ...emptyInitialState,
      affectedPeoplePopup: {
        showPopup: true,
        people: [{
          personId: 'Cody',
          personName: 'Matt',
          rateName: 'STANDARD',
          costGroupName: 'Mike',
          isEmployee: true,
          isActive: true,
        }],
        costGroup: 'Mike',
      },
    };

    const action = {
      type: 'costGroups/CANCEL_AFFECTED_PEOPLE_POPUP',
    };

    expect(reducer(initialState, action)).toEqual(emptyInitialState);
  });

  it('Responds to SET_SEARCH_TEXT', () => {
    const action = {
      type: 'costGroups/SET_SEARCH_TEXT',
      payload: 'SLR',
    };

    const initialState = {
      ...emptyInitialState,
      data: [
        {
          id: 'PROD-DEV', name: 'Product Development', costCenter: 'SLR74701', isActive: true,
        },
        {
          id: 'TPS', name: 'Technology Pipeline Solutions', costCenter: 'SLR43223', isActive: false,
        },
      ],
      searchText: '',
    };

    const expected = {
      ...initialState,
      searchText: action.payload,
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });
});
