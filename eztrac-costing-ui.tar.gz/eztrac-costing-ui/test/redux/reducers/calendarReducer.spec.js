import reducer from '../../../src/client/redux/reducers/calendarReducer';

describe('Rate Reducer Spec', () => {
  const emptyInitialState = {
    data: [],
  };

  it('exports corect default state', () => {
    expect(reducer()).toEqual(emptyInitialState);
  });

  it('responds to SET_ALL_CALENDARS', () => {
    const action = {
      payload: [{
        calendarId: 'ARG-VARIABLE',
        calendarName: 'Argentina Veriable Month Length',
      }, {
        calendarId: 'BRZ-Variable',
        calendarName: 'Brazil Variable Month Length',
      }],
      type: 'calendars/SET_ALL_CALENDARS',
    };

    const expected = {
      ...emptyInitialState,
      data: action.payload,
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });
});
