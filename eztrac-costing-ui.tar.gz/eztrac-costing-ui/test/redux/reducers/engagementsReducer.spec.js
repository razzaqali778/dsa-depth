import reducer from '../../../src/client/redux/reducers/engagementsReducer' //eslint-disable-line

describe('Engagements Reducer', () => {
  const emptyInitialState = {
    data: [],
    searchText: '',
    isCreating: false,
    isEditing: '',
    isUpdating: false,
  };

  it('Responds to SET_SEARCH_TEXT', () => {
    const action = {
      type: 'engagements/SET_SEARCH_TEXT',
      payload: 'Product',
    };

    const initialState = {
      ...emptyInitialState,
      data: [
        {
          id: 'PROD-DEV', name: 'Product Development', costGroup: 'P&E Analytics', isActive: true,
        },
        {
          id: 'TPS', name: 'Technology Pipeline Solutions', costGroup: 'P&E Analytics', isActive: false,
        },
      ],
      searchText: '',
    };

    const expected = {
      ...initialState,
      searchText: action.payload,
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });

  it('responds to SET_ALL_ENGAGEMENTS_DATA', () => {
    const action = {
      type: 'engagements/SET_ALL_ENGAGEMENTS_DATA',
      payload: [{
        name: 'engagement2',
        id: 'ENGAGEMENT2',
        isActive: true,
        costGroupId: 'HISTORIC',
        modifiedBy: 'no',
      }],
    };

    const expected = {
      ...emptyInitialState,
      data: action.payload,
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('responds to TOGGLE_IS_CREATING', () => {
    const action = {
      type: 'engagements/TOGGLE_IS_CREATING',
      payload: true,
    };
    const expected = {
      ...emptyInitialState,
      isCreating: true,
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('responds to TOGGLE_IS_EDITING', () => {
    const action = {
      type: 'engagements/TOGGLE_IS_EDITING',
      payload: 'Engagement1',
    };
    const expected = {
      ...emptyInitialState,
      isEditing: 'Engagement1',
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('responds to ADD_ENGAGEMENT', () => {
    const initialState = {
      ...emptyInitialState,
      data: [
        {
          name: 'engagement2',
          id: 'ENGAGEMENT2',
          isActive: true,
          costGroupId: 'HISTORIC',
          modifiedBy: 'no',
        },
        {
          name: 'engagement3',
          id: 'ENGAGEMENT3',
          isActive: true,
          costGroupId: 'HISTORIC',
          modifiedBy: 'no',
        },
      ],
    };
    const action = {
      type: 'engagements/ADD_ENGAGEMENT',
      payload: {
        name: 'engagement4',
        id: 'ENGAGEMENT3',
        isActive: true,
        costGroupId: 'HISTORIC',
        modifiedBy: 'no',
      },
    };
    const expected = {
      ...emptyInitialState,
      data: [
        {
          name: 'engagement2',
          id: 'ENGAGEMENT2',
          isActive: true,
          costGroupId: 'HISTORIC',
          modifiedBy: 'no',
        },
        {
          name: 'engagement3',
          id: 'ENGAGEMENT3',
          isActive: true,
          costGroupId: 'HISTORIC',
          modifiedBy: 'no',
        },
        {
          name: 'engagement4',
          id: 'ENGAGEMENT3',
          isActive: true,
          costGroupId: 'HISTORIC',
          modifiedBy: 'no',
        },
      ],
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });

  it('responds to UPDATE_ENGAGEMENT', () => {
    const initialState = {
      ...emptyInitialState,
      isEditing: 'ENGAGEMENT2',
      data: [
        {
          name: 'engagement2',
          id: 'ENGAGEMENT2',
          isActive: true,
          costGroupId: 'HISTORIC',
          modifiedBy: 'no',
        },
        {
          name: 'engagement3',
          id: 'ENGAGEMENT3',
          isActive: true,
          costGroupId: 'HISTORIC',
          modifiedBy: 'no',
        },
      ],
    };

    const action = {
      type: 'engagements/UPDATE_ENGAGEMENT',
      payload: {
        name: 'New Engagement Name',
        id: 'ENGAGEMENT2',
        isActive: true,
        costGroupId: 'HISTORIC',
        modifiedBy: 'no',
      },
    };
    const expected = {
      ...emptyInitialState,
      data: [
        {
          name: 'New Engagement Name',
          id: 'ENGAGEMENT2',
          isActive: true,
          costGroupId: 'HISTORIC',
          modifiedBy: 'no',
        },
        {
          name: 'engagement3',
          id: 'ENGAGEMENT3',
          isActive: true,
          costGroupId: 'HISTORIC',
          modifiedBy: 'no',
        },
      ],
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });
});
