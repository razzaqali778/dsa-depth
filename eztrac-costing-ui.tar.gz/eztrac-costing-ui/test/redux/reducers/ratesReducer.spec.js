import reducer from '../../../src/client/redux/reducers/ratesReducer' // eslint-disable-line

describe('Rate Reducer Spec', () => {
  const emptyInitialState = {
    data: [],
    isEditing: '',
    isCreating: false,
    searchText: '',
    affectedPeoplePopup: {
      showPopup: false,
      people: [],
      rate: undefined,
    },
    ratePeoplePopup: {
      showPopup: false,
      people: [],
      rate: undefined,
    },
  };

  it('exports the correct default state', () => {
    expect(reducer()).toEqual(emptyInitialState);
  });

  it('responds to SET_ALL_RATE_DATA', () => {
    const action = {
      type: 'rates/SET_ALL_RATE_DATA',
      payload: [{
        id: 'Rate-id', name: 'Rate-name', hourlyRate: 100, isActive: true,
      }],
    };

    const expected = {
      ...emptyInitialState,
      data: action.payload,
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('responds to TOGGLE_IS_EDITING', () => {
    const action = {
      type: 'rates/TOGGLE_IS_EDITING',
      payload: 'Rate-id1',
    };
    const expected = {
      ...emptyInitialState,
      isEditing: 'Rate-id1',
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('responds to UPDATE_RATE', () => {
    const initialState = {
      ...emptyInitialState,
      isEditing: 'Rate-id1',
      data: [
        {
          id: 'Rate-id1', name: 'Rate-name', hourlyRate: 100, isActive: true,
        },
        {
          id: 'Rate-id2', name: 'Rate-name', hourlyRate: 100, isActive: true,
        },
      ],
      affectedPeoplePopup: {
        showPopup: true,
        people: [
          {
            personId: 'Cody',
            personName: 'Matt',
            rateName: 'STANDARD',
            costGroupName: 'Mike',
            isEmployee: true,
            isActive: true,
          },
          {
            personId: 'OtherCody',
            personName: 'OtherMatt',
            rateName: 'STANDARD',
            costGroupName: 'OtherMike',
            isEmployee: true,
            isActive: true,
          }],
        rate:
          {
            id: 'Rate-id1', name: 'Rate-name', hourlyRate: 100, isActive: true,
          },
      },
    };
    const action = {
      type: 'rates/UPDATE_RATE',
      payload: {
        id: 'Rate-id1', name: 'sean', hourlyRate: 11, isActive: false,
      },
    };
    const expected = {
      ...emptyInitialState,
      data: [
        {
          id: 'Rate-id1', name: 'sean', hourlyRate: 11, isActive: false,
        },
        {
          id: 'Rate-id2', name: 'Rate-name', hourlyRate: 100, isActive: true,
        },
      ],
      affectedPeoplePopup: {
        showPopup: false,
        people: [],
        rate: undefined,
      },
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });

  it('responds to TOGGLE_IS_CREATING', () => {
    const initialState = {
      ...emptyInitialState,
    };
    const action = {
      type: 'rates/TOGGLE_IS_CREATING',
      payload: true,
    };
    const expected = {
      ...initialState,
      isCreating: true,
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });

  it('responds to ADD_NEW_RATE', () => {
    const initialState = {
      ...emptyInitialState,
      data: [
        {
          id: 'Rate-id1', name: 'sean', hourlyRate: 11, isActive: false,
        },
        {
          id: 'Rate-id2', name: 'Rate-name', hourlyRate: 100, isActive: true,
        },
      ],
      isCreating: true,
    };
    const action = {
      type: 'rates/ADD_NEW_RATE',
      payload: {
        id: 'BRAND_NEW', name: 'pat', hourlyRate: 1, isActive: true,
      },
    };
    const expected = {
      ...initialState,
      data: [
        {
          id: 'Rate-id1', name: 'sean', hourlyRate: 11, isActive: false,
        },
        {
          id: 'Rate-id2', name: 'Rate-name', hourlyRate: 100, isActive: true,
        },
        {
          id: 'BRAND_NEW', name: 'pat', hourlyRate: 1, isActive: true,
        },
      ],
      isCreating: false,
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });

  it('Responds to set_people_with_rateId', () => {
    const action = {
      type: 'rates/SET_PEOPLE_WITH_RATE_ID',
      payload: {
        people: [{
          personId: 'Cody',
          personName: 'Matt',
          rateName: 'STANDARD',
          costGroupName: 'Mike',
          isEmployee: true,
          isActive: true,
        }],
        rate: {
          id: 'Rate-id1', name: 'sean', hourlyRate: 11, isActive: false,
        },
      },
    };

    const expected = {
      ...emptyInitialState,
      affectedPeoplePopup: {
        showPopup: true,
        people: action.payload.people,
        rate: action.payload.rate,
      },
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('Responds to VIEW_PEOPLE_WITH_RATE', () => {
    const action = {
      type: 'rates/VIEW_PEOPLE_WITH_RATE',
      payload: {
        people: [{
          personId: 'ID123',
          personName: 'Matt',
          rateName: 'STANDARD',
          costGroupName: 'Mikesgroup',
          isEmployee: true,
          isActive: true,
        }],
        rate: {
          id: 'Rate-id1', name: 'sean', hourlyRate: 11, isActive: false,
        },
      },
    };

    const expected = {
      ...emptyInitialState,
      ratePeoplePopup: {
        showPopup: true,
        people: action.payload.people,
        rate: action.payload.rate,
      },
    };

    expect(reducer(emptyInitialState, action)).toEqual(expected);
  });

  it('Responds to CANCEL_RATE_PEOPLE_POPUP', () => {
    const initialState = {
      ...emptyInitialState,
      ratePeoplePopup: {
        showPopup: true,
        people: [{
          personId: 'ID123',
          personName: 'Matt',
          rateName: 'STANDARD',
          costGroupName: 'Mikesgroup',
          isEmployee: true,
          isActive: true,
        }],
      },
    };
    const action = {
      type: 'rates/CANCEL_RATE_PEOPLE_POPUP',
    };

    expect(reducer(initialState, action)).toEqual(emptyInitialState);
  });

  it('Responds to CANCEL_AFFECTED_PEOPLE_POPUP', () => {
    const initialState = {
      ...emptyInitialState,
      affectedPeoplePopup: {
        showPopup: true,
        people: [{
          personId: 'Cody',
          personName: 'Matt',
          rateName: 'STANDARD',
          costGroupName: 'Mike',
          isEmployee: true,
          isActive: true,
        }],
      },
    };
    const action = {
      type: 'rates/CANCEL_AFFECTED_PEOPLE_POPUP',
    };

    expect(reducer(initialState, action)).toEqual(emptyInitialState);
  });

  it('Responds to SET_SEARCH_TEXT', () => {
    const action = {
      type: 'rates/SET_SEARCH_TEXT',
      payload: 'Standard',
    };

    const initialState = {
      ...emptyInitialState,
      data: [
        {
          calendarId: 'US-VARIABLE',
          hourlyRate: 100,
          id: 'STANDARD',
          isActive: true,
          modifiedBy: 'automatic',
          name: 'Standard',
        },
        {
          calendarId: 'STD-FIXED',
          hourlyRate: 135,
          id: '1904-LABS-SOW',
          isActive: true,
          modifiedBy: 'automatic',
          name: '1904 Labs SOW',
        },
      ],
      searchText: '',
    };

    const expected = {
      ...initialState,
      searchText: action.payload,
    };

    expect(reducer(initialState, action)).toEqual(expected);
  });
});
