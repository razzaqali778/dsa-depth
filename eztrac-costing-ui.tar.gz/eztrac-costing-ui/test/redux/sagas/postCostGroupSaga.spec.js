import { call, put as dispatch } from 'redux-saga/effects';
import { post } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { postCostGroupSaga } from '../../../src/client/redux/sagas/postCostGroupSaga';

const payload = {
  name: 'Allo',
  costCenter: 'hello',
  isActive: true,
};

const costGroupRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'costGroups',
  body: { ...payload, modifiedBy: 'Will-Be-Replaced-By-Endpoint' },
};

const setUpdatingAction = isUpdating => ({
  type: 'async/SET_UPDATING',
  payload: isUpdating,
});

describe('Post Cost Group Saga', () => {
  it('listens for the correct action fired', () => {
    expect(getSagaActions(listener)).toContain('costGroups/POST_COST_GROUP');
  });

  it('makes a post request to update the database', () => {
    const gen = postCostGroupSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const addCostGroupAction = {
      type: 'costGroups/ADD_COST_GROUP',
      payload,
    };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(post, costGroupRequest));
    expect(step(payload)).toEqual(dispatch(addCostGroupAction));
    expect(step()).toToastSuccess();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to save costgroup data', () => {
    const gen = postCostGroupSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(post, costGroupRequest));
    expect(step(mockError)).toToastError();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toEqual(true);
  });
});
