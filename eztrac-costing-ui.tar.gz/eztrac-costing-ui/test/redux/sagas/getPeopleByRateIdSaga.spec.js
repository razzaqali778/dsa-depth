import { call, put as dispatch } from 'redux-saga/effects';
import sortBy from 'lodash/sortBy';
import { get } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { getPeopleByRateIdSaga } from '../../../src/client/redux/sagas/getPeopleByRateIdSaga';

describe('Get People By Rate ID Saga', () => {
  const payloadRate = { id: 'STANDARD' };
  const peopleByRateRequest = {
    baseUrl: `${urls.costingServices}/v1/`,
    path: `people?rateId=${payloadRate.id}&isActive=true`,
  };

  it('listens for correct action fired', () => {
    const constants = [
      'rates/FETCH_PEOPLE_BY_RATE_ID',
      'rates/FETCH_RATE_PEOPLE',
    ];

    expect(getSagaActions(listener)).toEqual(constants);
  });

  it('fetches all people (sorted) by rate ID', () => {
    const gen = getPeopleByRateIdSaga({ payload: payloadRate });
    const step = lastYield => gen.next(lastYield).value;
    const mockResult = [
      {
        personId: 'BOB',
        personName: 'Bob',
        rateName: 'CEO',
        costGroupName: 'Executives',
        isEmployee: false,
        isActive: true,
      },
      {
        personId: 'ALICE',
        personName: 'Alice',
        rateName: 'Standard',
        costGroupName: 'PD',
        isEmployee: true,
        isActive: true,
      },
    ];

    const setPeopleWithRateAction = {
      type: 'rates/SET_PEOPLE_WITH_RATE_ID',
      payload: {
        rate: payloadRate,
        people: sortBy(mockResult, 'personName'),
      },
    };

    expect(step()).toEqual(call(get, peopleByRateRequest));
    expect(step(mockResult)).toEqual(dispatch(setPeopleWithRateAction));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to retrieve rates', () => {
    const gen = getPeopleByRateIdSaga({ payload: payloadRate });
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(call(get, peopleByRateRequest));
    expect(step(mockError)).toToastError();
    expect(gen.next().done).toBe(true);
  });
});
