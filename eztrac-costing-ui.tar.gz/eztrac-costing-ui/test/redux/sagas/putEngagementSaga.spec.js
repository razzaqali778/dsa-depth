import { call, put as dispatch } from 'redux-saga/effects';
import { put } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { putEngagementSaga } from '../../../src/client/redux/sagas/putEngagementSaga';

const payload = {
  id: 'NEW ENGAGEMENT',
  name: 'New Engagement',
  costGroupId: 'HISTORIC',
  isActive: true,
};

const engagementRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: `engagement/${payload.id}`,
  body: payload,
};

const setUpdatingAction = isUpdating => ({
  type: 'engagements/UPDATING_ENGAGEMENT',
  payload: isUpdating,
});

describe('Put Engagement Saga', () => {
  it('listens for the correct action fired', () => {
    expect(getSagaActions(listener)).toContain('engagements/PUT_UPDATE_ENGAGEMENT');
  });

  it('makes a put request to update the database', () => {
    const gen = putEngagementSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;

    const updateEngagementAction = {
      type: 'engagements/UPDATE_ENGAGEMENT',
      payload,
    };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(put, engagementRequest));
    expect(step(payload)).toEqual(dispatch(updateEngagementAction));
    expect(step()).toToastSuccess();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to save engagement data', () => {
    const gen = putEngagementSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(put, engagementRequest));
    expect(step(mockError)).toToastError();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toEqual(true);
  });
});
