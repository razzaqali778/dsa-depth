import { call, put as dispatch } from 'redux-saga/effects';
import { SET_ALL_PEOPLE_DATA } from '../../../src/client/redux/constants/peopleConstants';
import {
  SET_ALL_PEOPLE_FOR_COST_GROUPS_CSV,
  SET_DOWNLOAD_ALL_COST_GROUPS_CLICKED,
} from '../../../src/client/redux/constants/costGroupsConstants';
import {
  SET_ALL_PEOPLE_FOR_RATES_CSV,
  SET_DOWNLOAD_ALL_RATES_CLICKED,
} from '../../../src/client/redux/constants/ratesConstants';
import { get } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { getAllPeopleSaga } from '../../../src/client/redux/sagas/getAllPeopleSaga';

const peopleByCostGroupRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'people?isActive=true',
};

describe('Get All People Saga', () => {
  it('listens for correct action fired', () => {
    const constants = [
      SET_DOWNLOAD_ALL_COST_GROUPS_CLICKED,
      SET_DOWNLOAD_ALL_RATES_CLICKED,
    ];

    expect(getSagaActions(listener)).toEqual(constants);
  });

  it('fetches all people (sorted by cost group name)', () => {
    const gen = getAllPeopleSaga({ type: SET_DOWNLOAD_ALL_COST_GROUPS_CLICKED });
    const step = lastYield => gen.next(lastYield).value;
    const mockResult = [{
      costGroupName: 'P&E PD',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'YTAYE',
      personName: 'Taye, Yared',
      rateName: 'Standard',
    }, {
      costGroupName: 'IT Business Operations',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'ACOUR',
      personName: 'Courtney, Alex',
      rateName: 'Standard',
    }, {
      costGroupName: 'P&E PD',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'CCASE',
      personName: 'Cathy',
      rateName: 'Standard',
    }];
    const sortedMockResult = [{
      costGroupName: 'IT Business Operations',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'ACOUR',
      personName: 'Courtney, Alex',
      rateName: 'Standard',
    }, {
      costGroupName: 'P&E PD',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'CCASE',
      personName: 'Cathy',
      rateName: 'Standard',
    }, {
      costGroupName: 'P&E PD',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'YTAYE',
      personName: 'Taye, Yared',
      rateName: 'Standard',
    }];
    const setPeopleDataAction = {
      type: SET_ALL_PEOPLE_DATA,
      payload: sortedMockResult,
    };
    const setPeopleForCostGroupAction = {
      type: SET_ALL_PEOPLE_FOR_COST_GROUPS_CSV,
    };

    expect(step()).toEqual(call(get, peopleByCostGroupRequest));
    expect(step(mockResult)).toEqual(dispatch(setPeopleDataAction));
    expect(step()).toEqual(dispatch(setPeopleForCostGroupAction));
    expect(gen.next().done).toBe(true);
  });

  it('fetches all people (sorted by rate name)', () => {
    const gen = getAllPeopleSaga({ type: SET_DOWNLOAD_ALL_RATES_CLICKED });
    const step = lastYield => gen.next(lastYield).value;
    const mockResult = [{
      costGroupName: 'P&E PD',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'YTAYE',
      personName: 'Taye, Yared',
      rateName: 'B_Standard',
    }, {
      costGroupName: 'IT Business Operations',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'ACOUR',
      personName: 'Courtney, Alex',
      rateName: 'A_Standard',
    }, {
      costGroupName: 'P&E PD',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'CCASE',
      personName: 'Cathy',
      rateName: 'C_Standard',
    }];
    const sortedMockResult = [{
      costGroupName: 'IT Business Operations',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'ACOUR',
      personName: 'Courtney, Alex',
      rateName: 'A_Standard',
    }, {
      costGroupName: 'P&E PD',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'YTAYE',
      personName: 'Taye, Yared',
      rateName: 'B_Standard',
    }, {
      costGroupName: 'P&E PD',
      isActive: true,
      isEmployee: true,
      modifiedBy: 'automatic',
      personId: 'CCASE',
      personName: 'Cathy',
      rateName: 'C_Standard',
    }];
    const setPeopleDataAction = {
      type: SET_ALL_PEOPLE_DATA,
      payload: sortedMockResult,
    };
    const setPeopleForRatesAction = {
      type: SET_ALL_PEOPLE_FOR_RATES_CSV,
    };

    expect(step()).toEqual(call(get, peopleByCostGroupRequest));
    expect(step(mockResult)).toEqual(dispatch(setPeopleDataAction));
    expect(step()).toEqual(dispatch(setPeopleForRatesAction));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to retrieve people', () => {
    const gen = getAllPeopleSaga({ type: SET_DOWNLOAD_ALL_COST_GROUPS_CLICKED });
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(call(get, peopleByCostGroupRequest));
    expect(step(mockError)).toToastError();
    expect(gen.next().done).toBe(true);
  });
});
