import { call, put as dispatch } from 'redux-saga/effects';
import { put } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { putCostGroupSaga } from '../../../src/client/redux/sagas/putCostGroupSaga';

const payload = {
  id: 'Some New Cost Group Name',
  name: 'A',
  costCenter: 'Y2K',
  isActive: true,
};

const costGroupRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: `costGroup/${payload.id}`,
  body: payload,
};

const setUpdatingAction = isUpdating => ({
  type: 'costGroups/UPDATING_COST_GROUP',
  payload: isUpdating,
});

describe('Put Cost Group Saga', () => {
  it('listens for the correct action fired', () => {
    expect(getSagaActions(listener)).toContain('costGroups/PUT_UPDATE_COST_GROUP');
  });

  it('makes a put request to update the database', () => {
    const gen = putCostGroupSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;

    const updateCostGroupAction = {
      type: 'costGroups/UPDATE_COST_GROUP',
      payload,
    };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(put, costGroupRequest));
    expect(step(payload)).toEqual(dispatch(updateCostGroupAction));
    expect(step()).toToastSuccess();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to save costgroup data', () => {
    const gen = putCostGroupSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(put, costGroupRequest));
    expect(step(mockError)).toToastError();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toEqual(true);
  });
});
