import { SET_DOWNLOAD_COST_GROUP_CLICKED } from '../../../src/client/redux/constants/costGroupsConstants';
import { SET_DOWNLOAD_RATE_CLICKED } from '../../../src/client/redux/constants/ratesConstants';
import getSagaActions from '../../getSagaActions';
import listener from '../../../src/client/redux/sagas/downloadSingleCSVSaga';

describe('downloadSingleCSVSaga', () => {
  it('listens for the correct action fired', () => {
    const constants = [
      SET_DOWNLOAD_RATE_CLICKED,
      SET_DOWNLOAD_COST_GROUP_CLICKED,
    ];

    expect(getSagaActions(listener)).toEqual(constants);
  });
});
