import { call, put as dispatch } from 'redux-saga/effects';
import { post } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { postRateSaga } from '../../../src/client/redux/sagas/postRateSaga';

const payload = {
  rateName: 'A',
  hourlyRate: 50,
  isActive: true,
};

const rateRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'rates',
  body: { ...payload, modifiedBy: 'Will-Be-Replaced-By-Endpoint' },
};

const setUpdatingAction = isUpdating => ({
  type: 'async/SET_UPDATING',
  payload: isUpdating,
});

describe('Post Rate Saga', () => {
  it('listens for the correct action fired', () => {
    expect(getSagaActions(listener)).toContain('rates/POST_NEW_RATE');
  });

  it('makes a post request to update the database', () => {
    const gen = postRateSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const addRateAction = {
      type: 'rates/ADD_NEW_RATE',
      payload,
    };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(post, rateRequest));
    expect(step(payload)).toEqual(dispatch(addRateAction));
    expect(step()).toToastSuccess();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to save rate data', () => {
    const gen = postRateSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(post, rateRequest));
    expect(step(mockError)).toToastError();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toEqual(true);
  });
});
