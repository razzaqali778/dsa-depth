import { call, put as dispatch } from 'redux-saga/effects';
import omit from 'lodash/omit';
import { put } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getRouterArgs from '../../getRouterArgs';
import getSagaActions from '../../getSagaActions';
import listener, {
  putPersonSaga,
} from '../../../src/client/redux/sagas/putPersonSaga';

const updatedPerson = {
  payload: {
    personId: 'MDLIND1',
    costGroupName: 'CC',
    isActive: true,
    rateName: 'Standard',
    personName: 'Matt Lindner',
    isEmployee: true,
    photo: 'url',
  },
};

const personRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'person',
  body: {
    ...omit(updatedPerson.payload, 'photo'),
    modifiedBy: 'Will-Be-Replaced-By-Endpoint',
  },
};

describe('Put Person Saga', () => {
  const routerArgs = { pathname: '/people', search: '' };

  it('listens for PUT_PERSON or CREATE_PERSON action fired', () => {
    const constants = ['people/UPDATE_PERSON', 'people/CREATE_PERSON'];

    expect(getSagaActions(listener)).toEqual(constants);
  });

  it('updates person', () => {
    const gen = putPersonSaga(updatedPerson);
    const step = (lastYield) => gen.next(lastYield).value;
    const mockResult = updatedPerson.payload;
    const setPersonDataAction = {
      type: 'people/SET_PERSON_DATA',
      payload: mockResult,
    };
    const toggleEdditingAction = {
      type: 'people/TOGGLE_IS_EDITING',
      payload: false,
    };

    expect(step()).toEqual(call(put, personRequest));
    expect(step(mockResult)).toEqual(dispatch(setPersonDataAction));
    expect(step()).toEqual(dispatch(toggleEdditingAction));
    expect(getRouterArgs(step())).toEqual(routerArgs);
    expect(step()).toToastSuccess();
    expect(gen.next().done).toBe(true);
  });

  it('updates person and clears task', () => {
    Object.defineProperty(window.location, 'search', {
      value: '?task=true',
    });

    const gen = putPersonSaga(updatedPerson);
    const step = (lastYield) => gen.next(lastYield).value;
    const mockResult = updatedPerson.payload;
    const setPersonDataAction = {
      type: 'people/SET_PERSON_DATA',
      payload: mockResult,
    };
    const toggleEditingAction = {
      type: 'people/TOGGLE_IS_EDITING',
      payload: false,
    };
    const clearTask = {
      type: 'people/CLEAR_TASK',
      payload: updatedPerson.payload.personId,
    };

    expect(step()).toEqual(call(put, personRequest));
    expect(step(mockResult)).toEqual(dispatch(setPersonDataAction));
    expect(step()).toEqual(dispatch(toggleEditingAction));
    expect(step()).toEqual(dispatch(clearTask));
    expect(getRouterArgs(step())).toEqual(routerArgs);
    expect(step()).toToastSuccess();
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to save person data', () => {
    const gen = putPersonSaga(updatedPerson);
    const step = (lastYield) => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(call(put, personRequest));
    expect(step(mockError)).toToastError();
    expect(gen.next().done).toBe(true);
  });
});
