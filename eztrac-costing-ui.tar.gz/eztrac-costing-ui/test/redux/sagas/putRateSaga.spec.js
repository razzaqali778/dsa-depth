import { call, put as dispatch } from 'redux-saga/effects';
import { put } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { putRateSaga } from '../../../src/client/redux/sagas/putRateSaga';

const payload = {
  id: 'RATE-ID',
  rateName: 'Rate',
  hourlyRate: 50,
  isActive: true,
};

const rateRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: `rate/${payload.id}`,
  body: payload,
};

const setUpdatingAction = isUpdating => ({
  type: 'async/SET_UPDATING',
  payload: isUpdating,
});

describe('Put Rate Saga', () => {
  it('listens for the correct action fired', () => {
    expect(getSagaActions(listener)).toContain('rates/PUT_UPDATE_RATE');
  });

  it('makes a put request to update the database', () => {
    const gen = putRateSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const updateRateAction = {
      type: 'rates/UPDATE_RATE',
      payload,
    };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(put, rateRequest));
    expect(step(payload)).toEqual(dispatch(updateRateAction));
    expect(step()).toToastSuccess();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to save rate data', () => {
    const gen = putRateSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(put, rateRequest));
    expect(step(mockError)).toToastError();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toEqual(true);
  });
});
