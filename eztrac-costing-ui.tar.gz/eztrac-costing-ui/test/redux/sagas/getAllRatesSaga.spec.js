import { call, put as dispatch } from 'redux-saga/effects';
import sortBy from 'lodash/sortBy';
import { get } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { getAllRatesSaga } from '../../../src/client/redux/sagas/getAllRatesSaga';

const ratesUrl = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'rates',
};

const setUpdatingAction = isUpdating => ({
  type: 'async/SET_UPDATING',
  payload: isUpdating,
});

describe('Get All Rates Saga', () => {
  it('listens for correct action fired', () => {
    expect(getSagaActions(listener)).toContain('rates/FETCH_ALL_RATE_DATA');
  });

  it('fetches all rate data', () => {
    const gen = getAllRatesSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockResult = [
      {
        id: 'Another Rate', name: 'B', hourlyRate: 50, isActive: false,
      },
      {
        id: 'Some Rate', name: 'A', hourlyRate: 50, isActive: true,
      },
    ];
    const sortedResult = sortBy(mockResult, 'name');
    const setRateDataAction = {
      type: 'rates/SET_ALL_RATE_DATA',
      payload: sortedResult,
    };

    expect(mockResult).not.toEqual(sortedResult); // To help prove that we are sorting
    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(get, ratesUrl));
    expect(step(mockResult)).toEqual(dispatch(setRateDataAction));
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to get rate data', () => {
    const gen = getAllRatesSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(get, ratesUrl));
    expect(step(mockError)).toToastError();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toEqual(true);
  });
});
