import { call, put as dispatch } from 'redux-saga/effects';
import { post } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { postEngagementSaga } from '../../../src/client/redux/sagas/postEngagementSaga';

const payload = {
  name: 'Allo',
  costGroup: 'HISTORIC',
  isActive: true,
};

const engagementRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'engagements',
  body: { ...payload, modifiedBy: 'Will-Be-Replaced-By-Endpoint' },
};

const setUpdatingAction = isUpdating => ({
  type: 'async/SET_UPDATING',
  payload: isUpdating,
});

describe('Post Engagement Saga', () => {
  it('listens for the correct action fired', () => {
    expect(getSagaActions(listener)).toContain('engagements/POST_ENGAGEMENT');
  });

  it('makes a post request to update the database', () => {
    const gen = postEngagementSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const addEngagementAction = {
      type: 'engagements/ADD_ENGAGEMENT',
      payload,
    };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(post, engagementRequest));
    expect(step(payload)).toEqual(dispatch(addEngagementAction));
    expect(step()).toToastSuccess();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to save engagement data', () => {
    const gen = postEngagementSaga({ payload });
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(post, engagementRequest));
    expect(step(mockError)).toToastError();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toEqual(true);
  });
});
