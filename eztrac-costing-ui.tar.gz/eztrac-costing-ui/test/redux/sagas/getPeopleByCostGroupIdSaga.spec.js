import { call, put as dispatch } from 'redux-saga/effects';
import sortBy from 'lodash/sortBy';
import { get } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { getPeopleByCostGroupIdSaga } from '../../../src/client/redux/sagas/getPeopleByCostGroupIdSaga';

const payloadCostGroup = {
  id: 'PE-PRODUCT-DEVELOPMENT',
};

const peopleByCostGroupRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: `people?costGroupId=${payloadCostGroup.id}&isActive=true`,
};

describe('Get People By Cost Group ID Saga', () => {
  it('listens for correct action fired', () => {
    const constants = [
      'costGroups/FETCH_PEOPLE_BY_COST_GROUP_ID',
      'costGroups/FETCH_COST_GROUP_PEOPLE',
    ];

    expect(getSagaActions(listener)).toEqual(constants);
  });

  it('fetches all people (sorted) by cost group id', () => {
    const gen = getPeopleByCostGroupIdSaga({ payload: payloadCostGroup });
    const step = lastYield => gen.next(lastYield).value;
    const mockResult = [
      {
        personId: 'BOB',
        personName: 'Bob',
        rateName: 'CEO',
        costGroupName: 'PD',
        isEmployee: false,
        isActive: true,
      },
      {
        personId: 'ALICE',
        personName: 'Alice',
        rateName: 'Standard',
        costGroupName: 'PD',
        isEmployee: true,
        isActive: true,
      },
    ];

    const setPeopleWithCostGroupAction = {
      type: 'costGroups/SET_PEOPLE_WITH_COST_GROUP_ID',
      payload: {
        costGroup: payloadCostGroup,
        people: sortBy(mockResult, 'personName'),
      },
    };

    expect(step()).toEqual(call(get, peopleByCostGroupRequest));
    expect(step(mockResult)).toEqual(dispatch(setPeopleWithCostGroupAction));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to retrieve cost groups', () => {
    const gen = getPeopleByCostGroupIdSaga({ payload: payloadCostGroup });
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(call(get, peopleByCostGroupRequest));
    expect(step(mockError)).toToastError();
    expect(gen.next().done).toBe(true);
  });
});
