import { call, put as dispatch } from 'redux-saga/effects';
import sortBy from 'lodash/sortBy';
import { get } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { getAllEngagementsSaga } from '../../../src/client/redux/sagas/getAllEngagementsSaga';

const engagementsUrl = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'engagements',
};

const setUpdatingAction = isUpdating => ({
  type: 'async/SET_UPDATING',
  payload: isUpdating,
});

describe('Get All Engagements Saga', () => {
  it('listens for correct action fired', () => {
    expect(getSagaActions(listener)).toContain('engagements/FETCH_ALL_ENGAGEMENTS_DATA');
  });

  it('fetches all engagement data', () => {
    const gen = getAllEngagementsSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockResult = [
      {
        name: 'engagement2',
        id: 'ENGAGEMENT2',
        isActive: true,
        costGroupId: 'HISTORIC',
        modifiedBy: 'no',
      },
      {
        name: 'engagement1',
        id: 'ENGAGEMENT1',
        isActive: true,
        costGroupId: 'HISTORIC',
        modifiedBy: 'jagoec',
      },
    ];
    const sortedResult = sortBy(mockResult, 'name');
    const setEngagementDataAction = {
      type: 'engagements/SET_ALL_ENGAGEMENTS_DATA',
      payload: sortedResult,
    };

    expect(mockResult).not.toEqual(sortedResult); // To help prove that we are sorting
    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(get, engagementsUrl));
    expect(step(mockResult)).toEqual(dispatch(setEngagementDataAction));
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to get engagement data', () => {
    const gen = getAllEngagementsSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(dispatch(setUpdatingAction(true)));
    expect(step()).toEqual(call(get, engagementsUrl));
    expect(step(mockError)).toToastError();
    expect(step()).toEqual(dispatch(setUpdatingAction(false)));
    expect(gen.next().done).toEqual(true);
  });
});
