import {
  call, put as dispatch, select, take,
} from 'redux-saga/effects';
import { get } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import actions from '../../../src/client/redux/actions';
import getCostGroupsFormatted from '../../../src/client/redux/selectors/getCostGroupsFormatted';
import getRatesFormatted from '../../../src/client/redux/selectors/getRatesFormatted';
import getRouterArgs from '../../getRouterArgs';
import getSagaActions from '../../getSagaActions';
import listener, {
  getPersonDataSaga,
} from '../../../src/client/redux/sagas/getPersonDataSaga';

describe('Get Person Data Saga', () => {
  it('listens for correct action fired', () => {
    expect(getSagaActions(listener)).toContain('people/FETCH_PERSON_DATA');
  });

  it('fetches specified person data', () => {
    const papiPersonObject = {
      payload: {
        value: 'mdlind1',
        label: 'Matt L (mdlind1)',
        photo: 'url',
      },
    };
    const gen = getPersonDataSaga(papiPersonObject);
    const step = (lastYield) => gen.next(lastYield).value;
    const papiRequest = {
      baseUrl: urls.costingServices,
      path: `/v1/person/${papiPersonObject.payload.value}`,
    };
    const mockResult = {
      personId: 'mdlind1',
      personName: 'Matt L',
      rateName: 'Standard',
      costGroupName: 'PD',
      isEmploy: true,
      isActive: false,
      photo: 'url',
    };
    const setPersonAction = {
      type: 'people/SET_PERSON_DATA',
      payload: mockResult,
    };
    const routerArgs = {
      pathname: '/people',
      search: `?personId=${papiPersonObject.payload.value}`,
    };

    expect(step()).toEqual(select(getCostGroupsFormatted));
    expect(step()).toEqual(take(actions.setAllCostGroupData().type));
    expect(step()).toEqual(select(getRatesFormatted));
    expect(step()).toEqual(take(actions.setAllRateData().type));
    expect(step()).toEqual(call(get, papiRequest));
    expect(step(mockResult)).toEqual(dispatch(setPersonAction));
    expect(getRouterArgs(step())).toEqual(routerArgs);
    expect(gen.next().done).toBe(true);
  });

  it('sets personNotFound flag if 404', () => {
    const papiPersonObject = {
      payload: {
        value: 'FAKE-PERSON',
        label: 'Name (FAKE-PERSON)',
        personName: 'Name',
        employeeType: 'E4mployee',
        photo: 'url',
      },
    };
    const gen = getPersonDataSaga(papiPersonObject);
    const step = (lastYield) => gen.next(lastYield).value;
    const papiRequest = {
      baseUrl: urls.costingServices,
      path: `/v1/person/${papiPersonObject.payload.value}`,
    };
    const setPersonAction = {
      type: 'people/SET_NOT_FOUND_PERSON',
      payload: {
        value: true,
        personId: papiPersonObject.payload.value,
        personName: papiPersonObject.payload.personName,
        employeeType: papiPersonObject.payload.employeeType,
        photo: 'url',
      },
    };
    const routerArgs = {
      pathname: '/people',
      search: `?personId=${papiPersonObject.payload.value}`,
    };

    expect(step()).toEqual(select(getCostGroupsFormatted));
    expect(step()).toEqual(take(actions.setAllCostGroupData().type));
    expect(step()).toEqual(select(getRatesFormatted));
    expect(step()).toEqual(take(actions.setAllRateData().type));
    expect(step()).toEqual(call(get, papiRequest));
    expect(step({ error: true })).toEqual(dispatch(setPersonAction));
    expect(getRouterArgs(step())).toEqual(routerArgs);
    expect(gen.next().done).toBe(true);
  });

  it('loads person in edit mode', () => {
    const papiPersonObject = {
      payload: {
        edit: true,
        value: 'mdlind1',
        label: 'Matt L (mdlind1)',
        photo: 'url',
      },
    };
    const gen = getPersonDataSaga(papiPersonObject);
    const step = (lastYield) => gen.next(lastYield).value;
    const papiRequest = {
      baseUrl: urls.costingServices,
      path: `/v1/person/${papiPersonObject.payload.value}`,
    };
    const mockResult = {
      personId: 'mdlind1',
      personName: 'Matt L',
      rateName: 'Standard',
      costGroupName: 'PD',
      isEmploy: true,
      isActive: false,
      photo: 'url',
    };
    const setPersonAction = {
      type: 'people/SET_PERSON_DATA',
      payload: mockResult,
    };
    const setEditModeAction = {
      type: 'people/TOGGLE_IS_EDITING',
      payload: papiPersonObject.payload.edit,
    };
    const routerArgs = {
      pathname: '/people',
      search: `?personId=${papiPersonObject.payload.value}`,
    };

    expect(step()).toEqual(select(getCostGroupsFormatted));
    expect(step()).toEqual(take(actions.setAllCostGroupData().type));
    expect(step()).toEqual(select(getRatesFormatted));
    expect(step()).toEqual(take(actions.setAllRateData().type));
    expect(step()).toEqual(call(get, papiRequest));
    expect(step(mockResult)).toEqual(dispatch(setPersonAction));
    expect(step()).toEqual(dispatch(setEditModeAction));
    expect(getRouterArgs(step())).toEqual(routerArgs);
    expect(gen.next().done).toBe(true);
  });
});
