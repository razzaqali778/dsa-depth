import { call } from 'redux-saga/effects';
import { post, put } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getRouterArgs from '../../getRouterArgs';
import getSagaActions from '../../getSagaActions';
import listener, {
  putCompletedTaskSaga,
} from '../../../src/client/redux/sagas/putCompletedTaskSaga';

const person = { payload: 'MKTESS' };

const completionObject = {
  complete: true,
  completedBy: 'Matt Lame',
  tag: 'Ez Trac',
  tagKey: person.payload,
  result: 'Task Completed.',
};

const taskRequest = {
  baseUrl: '/ez-trac-costing/messaging-api',
  path: '/v5/tasks/complete',
  body: completionObject,
};

const getUserRequest = {
  baseUrl: urls.papiUrl,
  path: '/v3/graphql',
  body: { query: '{ getCurrentUser { legalName { full } } }' },
};

const user = {
  data: {
    getCurrentUser: {
      legalName: {
        full: 'Matt Lame',
      },
    },
  },
};

describe('Put Completed Task Saga', () => {
  it('listens for clearTask action', () => {
    expect(getSagaActions(listener)).toContain('people/CLEAR_TASK');
  });

  it('Completes task with user ID', () => {
    Object.defineProperty(window.location, 'search', {
      value: '?task=true',
    });

    const gen = putCompletedTaskSaga(person);
    const step = (lastYield) => gen.next(lastYield).value;
    const mockResult = { body: {} };
    const routerArgs = { pathname: '/people', search: '' };

    expect(step()).toEqual(call(post, getUserRequest));
    expect(step(user)).toEqual(call(put, taskRequest));
    expect(getRouterArgs(step(mockResult))).toEqual(routerArgs);
    expect(step()).toToastSuccess();
    expect(gen.next().done).toBe(true);
  });

  it('pops toastr if failed it complete task', () => {
    const gen = putCompletedTaskSaga(person);
    const step = (lastYield) => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(call(post, getUserRequest));
    expect(step(user)).toEqual(call(put, taskRequest));
    expect(step(mockError)).toToastError();
    expect(gen.next().done).toBe(true);
  });
});
