import { all, call, put as dispatch } from 'redux-saga/effects';
import { get, post } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import defaultPhoto from '../../../src/client/helpers/defaultPhoto';
import getSagaActions from '../../getSagaActions';
import listener, { getPapiPeopleSaga } from '../../../src/client/redux/sagas/getPapiPeopleSaga';

const papiSearchObject = { payload: 'matt' };

const query = '{ searchUsers(query: "matt") { members { id, legalName { first middle last } employeeType photo } } }'; // eslint-disable-line max-len
const papiRequest = {
  baseUrl: urls.papiUrl,
  path: '/v3/graphql',
  body: { query },
};

const costEngineRequest = {
  baseUrl: urls.costingServices,
  path: `/v1/people?q=${papiSearchObject.payload}`,
};

describe('Get Papi People Saga', () => {
  it('listens for correct action fired', () => {
    expect(getSagaActions(listener)).toContain('people/SET_PAPI_SEARCH_TEXT');
  });

  it('fetches all papi data', () => {
    const gen = getPapiPeopleSaga(papiSearchObject);
    const step = lastYield => gen.next(lastYield).value;

    const mockPapiResult = {
      data: {
        searchUsers: {
          members: [
            {
              id: 'MDLIND1', legalName: { first: 'Matt', middle: 'Money', last: 'Lindner' }, employeeType: 'Employee', photo: 'url-to-photo',
            }, // eslint-disable-line max-len
            { id: 'FAKE-MATT', legalName: { first: 'Kevin', last: 'Ou' }, employeeType: 'Contractor' },
            { id: 'POTUS', legalName: { first: 'Donald', middle: 'J', last: 'Trump' }, employeeType: 'Employee' },
            { id: 'Some-External-Person', legalName: { first: 'Some', last: 'Dude' }, employeeType: 'External' },
            { id: 'Some-Mechanical-Person', legalName: { first: 'Mechanical', last: 'Person' }, employeeType: 'Mechanical' }, // eslint-disable-line max-len
          ],
        },
      },
    };

    const mockCostEngineResult = [
      {
        personId: 'MDLIND1', personName: 'Lindner, Matthew', isEmployee: true, isActive: true,
      },
      {
        personId: 'Not-In-Papi', personName: 'Not in Papi', isEmployee: false, isActive: true,
      },
    ];

    const mappedResult = [
      {
        value: 'MDLIND1',
        label: 'Lindner, Matt Money (MDLIND1)',
        personName: 'Lindner, Matt Money',
        employeeType: 'Employee',
        photo: 'url-to-photo',
      },
      {
        value: 'FAKE-MATT',
        label: 'Ou, Kevin (FAKE-MATT)',
        personName: 'Ou, Kevin',
        employeeType: 'Contractor',
        photo: defaultPhoto,
      },
      {
        value: 'POTUS',
        label: 'Trump, Donald J (POTUS)',
        personName: 'Trump, Donald J',
        employeeType: 'Employee',
        photo: defaultPhoto,
      },
      {
        value: 'Not-In-Papi',
        label: 'Not in Papi (Not-In-Papi)',
        personName: 'Not in Papi',
        employeeType: 'Contractor',
        photo: defaultPhoto,
      },
    ];

    const setPapiDataAction = {
      type: 'people/SET_PAPI_DATA',
      payload: mappedResult,
    };

    expect(step()).toEqual(all([call(post, papiRequest), call(get, costEngineRequest)]));
    expect(step([mockPapiResult, mockCostEngineResult])).toEqual(dispatch(setPapiDataAction));
    expect(gen.next().done).toBe(true);
  });

  it('does not fetch any data if search text is empty', () => {
    const emptySearch = { payload: '' };
    const gen = getPapiPeopleSaga(emptySearch);

    expect(gen.next().done).toBe(true);
  });

  it('does not fetch any data if papiSearchText is undefined', () => {
    const undefinedSearch = { payload: undefined };
    const gen = getPapiPeopleSaga(undefinedSearch);

    expect(gen.next().done).toBe(true);
  });

  it('does not set papi data if papi call fails', () => {
    const gen = getPapiPeopleSaga(papiSearchObject);
    const step = lastYield => gen.next(lastYield).value;

    const mockPapiResult = { error: 'ERROR!' };
    const mockCostEngineResult = [{ id: 'someone' }];

    expect(step()).toEqual(all([call(post, papiRequest), call(get, costEngineRequest)]));
    expect(step([mockPapiResult, mockCostEngineResult])).toToastError();
    expect(gen.next().done).toBe(true);
  });

  it('does not set papi data if cost calc call fails', () => {
    const gen = getPapiPeopleSaga(papiSearchObject);
    const step = lastYield => gen.next(lastYield).value;

    const mockPapiResult = [{ id: 'someone' }];
    const mockCostEngineResult = null;

    expect(step()).toEqual(all([call(post, papiRequest), call(get, costEngineRequest)]));
    expect(step([mockPapiResult, mockCostEngineResult])).toToastError();
    expect(gen.next().done).toBe(true);
  });
});
