import { call, put as dispatch } from 'redux-saga/effects';
import sortBy from 'lodash/sortBy';
import { get } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { getAllCalendarsSaga } from '../../../src/client/redux/sagas/getAllCalendarsSaga';

const calendarsUrl = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'calendars',
};

describe('Get All Calendars Saga', () => {
  it('listens for correct action fired', () => {
    expect(getSagaActions(listener)).toContain('calendars/GET_ALL_CALENDARS');
  });

  it('fetches all calendar data', () => {
    const gen = getAllCalendarsSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockResult = [
      { calendarId: 'BRZ-Variable', calendarName: 'Brazil Variable Month Length' },
      { calendarId: 'ARG-VARIABLE', calendarName: 'Argentina Veriable Month Length' },
    ];
    const sortedResult = sortBy(mockResult, 'calendarName');
    const setCalendarDataAction = {
      type: 'calendars/SET_ALL_CALENDARS',
      payload: sortedResult,
    };

    expect(mockResult).not.toEqual(sortedResult); // To help prove that we are sorting
    expect(step()).toEqual(call(get, calendarsUrl));
    expect(step(mockResult)).toEqual(dispatch(setCalendarDataAction));
    expect(gen.next().done).toBe(true);
  });

  it('pops erorr toastr if failed to get calendars', () => {
    const gen = getAllCalendarsSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(call(get, calendarsUrl));
    expect(step(mockError)).toToastError();
    expect(gen.next().done).toEqual(true);
  });
});
