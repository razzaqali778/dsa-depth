import { call, put as dispatch } from 'redux-saga/effects';
import sortBy from 'lodash/sortBy';
import { get } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { getAllCostGroupsSaga } from '../../../src/client/redux/sagas/getAllCostGroupsSaga';

const costGroupRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'costGroups',
};

describe('Get All Cost Group Saga', () => {
  it('listens for correct action fired', () => {
    expect(getSagaActions(listener)).toContain('costGroups/FETCH_ALL_COST_GROUP_DATA');
  });

  it('fetches all cost group data', () => {
    const gen = getAllCostGroupsSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockResult = [
      {
        id: 'TPS', name: 'Technology Pipeline Solutions', costCenter: '82AB', isActive: false,
      },
      {
        id: 'PROD-DEV', name: 'Product Development', costCenter: 'AH24', isActive: true,
      },
    ];
    const sortedResult = sortBy(mockResult, 'name');
    const setCostGroupDataAction = {
      type: 'costGroups/SET_ALL_COST_GROUP_DATA',
      payload: sortedResult,
    };

    expect(mockResult).not.toEqual(sortedResult); // To help prove that we are sorting
    expect(step()).toEqual(call(get, costGroupRequest));
    expect(step(mockResult)).toEqual(dispatch(setCostGroupDataAction));
    expect(gen.next().done).toBe(true);
  });

  it('pops error toastr if failed to retrieve cost groups', () => {
    const gen = getAllCostGroupsSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(call(get, costGroupRequest));
    expect(step(mockError)).toToastError();
    expect(gen.next().done).toBe(true);
  });
});
