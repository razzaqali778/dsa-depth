import { call, put as dispatch } from 'redux-saga/effects';
import { get } from '../../../src/client/redux/sagas/helpers/network';
import { urls } from '../../urlConsts';
import getSagaActions from '../../getSagaActions';
import listener, { getAllAuditsSaga } from '../../../src/client/redux/sagas/getAllAuditsSaga';

const auditRequest = {
  baseUrl: `${urls.costingServices}/v1/`,
  path: 'audits',
};

describe('Get All Audits Saga', () => {
  it('listens for correct action fired', () => {
    expect(getSagaActions(listener)).toContain('audits/FETCH_ALL_AUDIT_DATA');
  });

  it('fetches all audits data', () => {
    const gen = getAllAuditsSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockResult = [
      {
        entityType: 'person', entityKey: 'MAWIN', modifiedTime: 18509740, userId: 'JASKIDI', entity: { key: 'value' },
      },
      {
        entityType: 'rate', entityKey: 'STANDARD', modifiedTime: 17401740, userId: 'CODY', entity: { key: 'value' },
      },
    ];
    const action = {
      type: 'audits/SET_ALL_AUDIT_DATA',
      payload: mockResult,
    };

    expect(step()).toEqual(call(get, auditRequest));
    expect(step(mockResult)).toEqual(dispatch(action));
    expect(gen.next().done).toEqual(true);
  });

  it('pops error toastr if failed to retrieve audit data', () => {
    const gen = getAllAuditsSaga();
    const step = lastYield => gen.next(lastYield).value;
    const mockError = { error: {} };

    expect(step()).toEqual(call(get, auditRequest));
    expect(step(mockError)).toToastError();
    expect(gen.next().done).toEqual(true);
  });
});
