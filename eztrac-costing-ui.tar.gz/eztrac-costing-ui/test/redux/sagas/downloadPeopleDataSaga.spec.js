import { SET_ALL_PEOPLE_FOR_COST_GROUPS_CSV } from '../../../src/client/redux/constants/costGroupsConstants';
import { SET_ALL_PEOPLE_FOR_RATES_CSV } from '../../../src/client/redux/constants/ratesConstants';
import getSagaActions from '../../getSagaActions';
import listener from '../../../src/client/redux/sagas/downloadPeopleDataSaga';

describe('downloadPeopleDataSaga', () => {
  it('listens for the correct action fired', () => {
    const constants = [
      SET_ALL_PEOPLE_FOR_COST_GROUPS_CSV,
      SET_ALL_PEOPLE_FOR_RATES_CSV,
    ];

    expect(getSagaActions(listener)).toEqual(constants);
  });
});
