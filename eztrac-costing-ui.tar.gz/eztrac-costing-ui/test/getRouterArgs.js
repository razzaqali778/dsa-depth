const getRouterArgs = lastYield => lastYield.PUT.action.payload.args[0];

export default getRouterArgs;
