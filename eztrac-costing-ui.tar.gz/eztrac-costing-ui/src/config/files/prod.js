const _ = require('lodash');
const defaultConfig = require('./default');

module.exports = _.merge(defaultConfig, {
  'navigation-url': { url: 'https://navigation.phoenix-tools.io' },
  'velocity-home': { url: 'velocity.ag' },
  'messaging-url': { url: 'https://messaging.velocity.ag' },
  'peadmin-home': { url: 'peadmin.monsanto.net' },
  'user-feedback-url': { url: 'https://user-feedback.velocity.ag' },
  'preferences-url': { url: 'https://preferences.velocity.ag' },
  'phoenix-home': { url: 'phoenix-tools.io', env: 'Prod' },
  'profile-url': { url: 'https://profile.velocity.ag' },
  'ez-trac-urls': {
    services: {
      'ez-trac-core': 'https://ez-trac-core-services.velocity.ag',
      'ez-trac-costing': 'https://ez-trac-costing-services.velocity.ag',
      'ez-trac-original': 'https://ez-trac-services.velocity.ag',
      'ez-trac-qc': 'https://ez-trac-qc-services.velocity.ag/ez-trac-qc/services',
      'ez-trac-reporting': 'https://eztrac-reporting-services.velocity.ag',
      'ez-trac-suggestion': 'https://ez-trac-suggestion.velocity.ag',
      'ez-trac-vip': 'https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services',
      'peadmin-home': 'peadmin.monsanto.net',
    },
    ui: {
      'ez-trac-costing': 'https://peadmin.monsanto.net/ez-trac-costing',
      'ez-trac-original': 'https://velocity.ag/ez-trac',
      'ez-trac-qc': 'https://peadmin.monsanto.net/ez-trac-qc',
      'ez-trac-reporting': 'https://peadmin.monsanto.net/ez-trac-reporting',
      'ez-trac-vip': 'https://peadmin.monsanto.net/ez-trac-vip',
      'ez-trac-workflows': 'https://peadmin.monsanto.net/ez-trac-workflows',
      'peadmin-ez-trac-home': 'https://peadmin.monsanto.net/ez-trac-core',
    },
  },
});
