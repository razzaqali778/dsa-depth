const config = {
  'navigation-url': { url: 'https://navigation.phoenix-tools-np.io' },
  'velocity-home': { url: 'velocity-np.ag' },
  'messaging-url': { url: 'https://messaging.velocity-np.ag' },
  'peadmin-home': { url: 'peadmin-np.monsanto.net' },
  'user-feedback-url': { url: 'https://user-feedback.velocity-np.ag' },
  'preferences-url': { url: 'https://preferences.velocity-np.ag' },
  'phoenix-home': { url: 'phoenix-tools-np.io' },
  'profile-url': { url: 'https://profile.velocity-np.ag' },
  'ez-trac-urls': {
    services: {
      'ez-trac-core': 'https://ez-trac-core-services.velocity-np.ag',
      'ez-trac-costing': 'https://ez-trac-costing-services.velocity-np.ag',
      'ez-trac-original': 'https://ez-trac-services.velocity-np.ag',
      'ez-trac-qc': 'https://ez-trac-qc-services.velocity-np.ag/ez-trac-qc/services',
      'ez-trac-reporting': 'https://eztrac-reporting-services.velocity-np.ag',
      'ez-trac-suggestion': 'https://ez-trac-suggestion.velocity-np.ag',
      'ez-trac-vip': 'https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services',
      'peadmin-home': 'peadmin-np.monsanto.net',
    },
    ui: {
      'ez-trac-costing': 'https://peadmin-np.monsanto.net/ez-trac-costing',
      'ez-trac-original': 'https://velocity-np.ag/ez-trac',
      'ez-trac-qc': 'https://peadmin-np.monsanto.net/ez-trac-qc',
      'ez-trac-reporting': 'https://peadmin-np.monsanto.net/ez-trac-reporting',
      'ez-trac-vip': 'https://peadmin-np.monsanto.net/ez-trac-vip',
      'ez-trac-workflows': 'https://peadmin-np.monsanto.net/ez-trac-workflows',
      'peadmin-ez-trac-home': 'https://peadmin-np.monsanto.net/ez-trac-core',
    },
  },
};

module.exports = config;
