const _ = require('lodash');
const defaultConfig = require('./default');

module.exports = _.merge(defaultConfig, {
  'ez-trac-reporting-url': {
    ui: 'localhost:3031/ez-trac-costing',
  },
});
