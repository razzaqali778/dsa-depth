const { Config, source } = require('@monsantoit/config');
const { determineEnvironmentFileName } = require('@monsantoit/config-velocity-store');

const config = new Config({
  sources: [
    source.fromJS({ src: `${__dirname}/files/${determineEnvironmentFileName()}` }),
  ],
  processors: [],
  required: [],
});

module.exports = config;
