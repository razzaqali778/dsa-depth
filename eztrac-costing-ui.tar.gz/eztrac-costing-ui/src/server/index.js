const express = require('express');
const fs = require('fs');
const bindingsMiddleware = require('@monsantoit/phoenix-service-bindings-middleware');
const {
  generateHtmlMiddleware,
} = require('@monsantoit/phoenix-html-middleware');
const config = require('../config');

const app = express();
const baseUrl = '/ez-trac-costing';

if (process.env.NODE_ENV !== 'production') {
  /* eslint-disable global-require, import/newline-after-import */
  const webpack = require('webpack');
  const webpackConfig = require('../../webpack.dev.config');
  const compiler = webpack({
    ...webpackConfig,
    plugins: [],
  });
  const webpackDevMiddleware = require('webpack-dev-middleware');
  const middlewareOptions = {
    publicPath: `${baseUrl}/scripts/`,
  };

  app.use(webpackDevMiddleware(compiler, middlewareOptions));
}

const defaultClientBindings = config.config;
const ezTracUrls = config.get('ez-trac-urls');
const serviceBindings = bindingsMiddleware(defaultClientBindings, {
  localOcelot: true,
  urls: ezTracUrls,
});

app.use(`${baseUrl}/service-bindings`, serviceBindings);

const css = '//static-assets.velocity.ag/styles/1.0.0/velocity.css';

app.get(`${baseUrl}*`, (req, res) => {
  /* eslint-disable max-len */
  res.send(`
    <!doctype html>
    <html>
      <head>
        <title>EZTrac Costing Engine</title>
        <link rel="stylesheet" type="text/css" href="https://phoenix-tools.io/assets/cached/peadmin/styles/navbar.css">
        <link rel="stylesheet" type="text/css" href="https://phoenix-tools.io/assets/cached/peadmin/styles/mat1.1.1.css">
        <link rel="stylesheet" type="text/css" href="${css}">
        <link rel="stylesheet" type="text/css" href="${baseUrl}/styles/style.css">
      </head>
      <body>
        <div class="nav"></div>
        <div id="root"></div>
        <script src="${baseUrl}/service-bindings"></script>
        <script src="${baseUrl}/scripts/bundle.js"></script>
      </body>
    </html>
  `);
  /* eslint-enable max-len */
});

if (!fs.existsSync('./public')) {
  fs.mkdirSync('./public');
}

const htmlOptions = {
  defaultSuite: 'velocity',
  lightningExpress: true,
  materialVersion: '1.1.1',
};

const generateIndex = async (req, res) => {
  await generateHtmlMiddleware(
    baseUrl,
    'ez-trac-costing',
    ['ez-trac-costing_local'],
    htmlOptions,
  )(req, res);
};

if (process.env.NODE_ENV === 'production') {
  app.get('/*', generateIndex);
}

const defaultPort = 3031;
const port = process.env.PORT || defaultPort;

const server = app.listen(port, () => console.log(
    // eslint-disable-line
  `Listening at http://${server.address().host || 'localhost'}:${port}${baseUrl}`,
));

module.exports = server;
