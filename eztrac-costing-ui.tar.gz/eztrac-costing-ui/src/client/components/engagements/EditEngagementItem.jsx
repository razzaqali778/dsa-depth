import { OverlayTrigger, Popover } from 'react-bootstrap';
import { isEmpty } from 'lodash';
import PropTypes from 'prop-types';
import React from 'react';
import Select from 'react-select';
import Toggle from 'react-toggle';
import cloneDeep from 'lodash/cloneDeep';
import find from 'lodash/find';
import isEqual from 'lodash/isEqual';

class EditEngagementItem extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedCostGroup: find(props.costGroups, c => c.value === props.engagement.costGroupId),
      engagement: props.engagement,
      originalEngagement: props.engagement,
      errors: {
        name: false,
        costGroup: false,
        purchaseOrder: false,
      },
    };
  }

  /**
   * Event Handlers
   **************************************************************** */

  onSaveClick() {
    this.props.updateEngagementHandler(this.state.engagement);
  }

  onCancelClick() {
    this.props.updateEngagementHandler(null);
  }

  onEngagementChange(engagementField = null, newValue = null) {
    if (engagementField && newValue !== null) {
      const errors = {
        name: this.state.errors.name,
        costGroup: this.state.errors.costGroup,
        purchaseOrder: this.state.errors.purchaseOrder,
      };

      switch ( engagementField ) { // eslint-disable-line
        case 'name':
          errors.name = !this.isNameValid(newValue);
          break;
        case 'costGroup':
          errors.costGroup = !this.isSelectedCostGroupValid(newValue);
          break;
        case 'purchaseOrder':
          errors.purchaseOrder = !this.isPurchaseOrderValid(newValue);
          break;
      }
      const newEngagement = cloneDeep(this.state.engagement);

      newEngagement[engagementField] = newValue;
      this.setState({ // eslint-disable-line
        engagement: newEngagement,
        errors,
      });
    }
  }

  setCostGroup = costGroup => {
    const updatedEngagement = {
      ...this.state.engagement,
      costGroupId: costGroup ? costGroup.value : null,
    };

    const errors = {
      ...this.state.errors,
      costGroup: !this.isSelectedCostGroupValid(costGroup),
    };

    this.setState({
      engagement: updatedEngagement,
      selectedCostGroup: costGroup,
      errors,
    });
  };

  /**
   * Validation Functions
   **************************************************************** */

  isWhitespaceString(str) {
    return !/\S/.test(str);
  }

  isNameValid(name = '') {
    const containsOnlyAllowedChars = (str) => str.search(/([^a-zA-Z0-9\s\)\(&\-])/) === -1;

    return name.length !== 0
      && !this.isWhitespaceString(name)
      && containsOnlyAllowedChars(name);
  }

  isSelectedCostGroupValid(selectedCostGroup = null) {
    return selectedCostGroup && selectedCostGroup.value;
  }

  isPurchaseOrderValid(purchaseOrder = '') {
    return (
      purchaseOrder.length !== 0
      && !this.isWhitespaceString(purchaseOrder)
      && (purchaseOrder.search(/([^a-zA-Z0-9\s\)])/) === -1)
    );
  }

  /**
   * Rendering Functions
   **************************************************************** */

  renderIsActiveEditingBtns() {
    return (
      <label className="react-toggle-label">
        <span className="react-toggle-text">Active?</span>
        <Toggle
          defaultChecked={this.state.engagement.isActive}
          onChange={() => this.onEngagementChange('isActive', !this.state.engagement.isActive)}
        />
      </label>
    );
  }

  renderSaveButton(errors = false) {
    const disableSaveButton = isEqual(this.state.engagement, this.state.originalEngagement)
      || isEmpty(this.state.engagement.name)
      || isEmpty(this.state.engagement.costGroupId)
      || isEmpty(this.state.engagement.purchaseOrder)
      || errors.name
      || errors.costGroup
      || errors.purchaseOrder;

    return (
      <button
        type="button"
        className="btn btn-primary pull-right"
        disabled={disableSaveButton}
        onClick={() => this.onSaveClick()}
      >
        Save
      </button>
    );
  }

  render() {
    const nameTooltip = (
      <Popover
        id="popover-positioned-right"
        title={`Engagement: ${this.state.engagement.id || 'NEW ENGAGEMENT'}`}
      >
        Names are the visible ID for an Engagement &mdash; they should only contain
        alpha-numeric characters, dashes (
        <code>-</code>
        ), or ampersands (
        <code>&</code>
        ).
      </Popover>
    );

    const purchaseOrderTooltip = (
      <Popover
        id="popover-positioned-right"
        title={`Purchase Order: ${this.state.engagement.purchaseOrder || 'PURCHASE ORDER'}`}
      >
        Purchase Order is the order number used to reference the transaction &mdash; they should
        only contain alpha-numeric characters.
      </Popover>
    );

    return (
      <div className="list-group-item edit-mode">
        {this.renderSaveButton(this.state.errors)}
        <button
          type="button"
          className="btn btn-default pull-right cancel-button"
          onClick={() => this.onCancelClick()}
        >
          Cancel
        </button>
        <div
          className={this.state.errors.name ? 'form-group has-error has-feedback' : 'form-group'}
        >
          <OverlayTrigger
            overlay={nameTooltip}
            placement="right"
            trigger={['focus']}
          >
            <div className="input-group col-xs-6">
              <div className="input-group-addon form-tag">Name</div>
              <input
                className="form-control"
                defaultValue={this.state.engagement.name}
                id="exampleInputAmount"
                onChange={e => this.onEngagementChange('name', e.target.value)}
                type="text"
              />
            </div>
          </OverlayTrigger>
        </div>
        <div
          className={this.state.errors.costGroup
            ? 'form-group has-error has-feedback' : 'form-group'}
        >
          <div className="input-group col-xs-6">
            <div className="input-group-addon form-tag">Cost Group</div>
            <Select
              clearable={false}
              onChange={this.setCostGroup}
              options={this.props.costGroups}
              value={this.state.selectedCostGroup}
            />
          </div>
        </div>
        <div
          className={this.state.errors.purchaseOrder ? 'form-group has-error has-feedback' : 'form-group'}
        >
          <OverlayTrigger
            overlay={purchaseOrderTooltip}
            placement="right"
            trigger={['focus']}
          >
            <div className="input-group col-xs-6">
              <div className="input-group-addon form-tag">Purchase Order</div>
              <input
                className="form-control"
                defaultValue={this.state.engagement.purchaseOrder}
                id="purchaseOrder"
                onChange={e => this.onEngagementChange('purchaseOrder', e.target.value)}
                style={{ zIndex: '0' }}
                type="text"
              />
            </div>
          </OverlayTrigger>
        </div>
        {this.renderIsActiveEditingBtns()}
      </div>
    );
  }
}

EditEngagementItem.propTypes = {
  costGroups: PropTypes.array.isRequired,
  engagement: PropTypes.object.isRequired,
  updateEngagementHandler: PropTypes.func.isRequired,
};

export default EditEngagementItem;
