import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React from 'react';
import find from 'lodash/find';
import get from 'lodash/get';
import EditEngagementItem from './EditEngagementItem';
import {
  engagements as engagementActions,
} from '../../redux/actions';

function EngagementItem({
  isEditing,
  costGroups,
  engagement,
  toggleIsEditing,
  putUpdateEngagement,
}) {
  const engagementStatus = (status = false) => {
    const label = status ? 'Active Engagement' : 'Inactive Engagement';
    const className = status ? 'success' : 'danger';

    return (
      <span className={`label label-${className}`}>{label}</span>
    );
  };

  const displayCostGroup = costGroupId => {
    const costGroup = find(costGroups, { value: costGroupId });

    return get(costGroup, 'label', costGroupId);
  };

  const displayPurchaseOrder = purchaseOrder => (purchaseOrder ? (
    <li>
      <strong>Purchase Order:&nbsp;</strong>
      <code>{purchaseOrder}</code>
    </li>
  ) : '');

  const saveNewEngagement = newEngagement => {
    if (newEngagement) {
      putUpdateEngagement(newEngagement);
    } else {
      toggleIsEditing('');
    }
  };

  const renderNormal = () => (
    <div className="list-group-item">
      <h4 className="list-group-item-heading inline-block">{engagement.name}</h4>
      <button
        className="btn btn-default pull-right"
        onClick={() => toggleIsEditing(engagement.id)}
      >
        Edit
      </button>
      <ul>
        <li>
          <strong>Cost Group:&nbsp;</strong>
          <code>{displayCostGroup(engagement.costGroupId)}</code>
        </li>
        <li>
          <strong>Engagement ID:&nbsp;</strong>
          <code>{displayCostGroup(engagement.id)}</code>
        </li>
        {displayPurchaseOrder(engagement.purchaseOrder)}
        {engagementStatus(engagement.isActive)}
      </ul>
    </div>
  );

  const renderEditing = () => (
    <EditEngagementItem costGroups={costGroups} engagement={engagement} updateEngagementHandler={saveNewEngagement} />
  );

  return isEditing === engagement.id ? renderEditing() : renderNormal();
}

EngagementItem.propTypes = {
  costGroups: PropTypes.array.isRequired,
  engagement: PropTypes.object.isRequired,
  isEditing: PropTypes.string.isRequired,
  putUpdateEngagement: PropTypes.func.isRequired,
  toggleIsEditing: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  isEditing: state.engagements.isEditing,
});

export default connect(mapStateToProps, { ...engagementActions })(EngagementItem);
