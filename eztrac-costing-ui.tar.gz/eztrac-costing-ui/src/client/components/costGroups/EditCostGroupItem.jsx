import { OverlayTrigger, Popover } from 'react-bootstrap';
import PropTypes from 'prop-types';
import React from 'react';
import Toggle from 'react-toggle';
import cloneDeep from 'lodash/cloneDeep';

class EditCostGroupItem extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      costGroup: props.costGroup,
      errors: {
        name: '',
        costCenter: '',
      },
    };
  }

  onSaveClick() {
    this.props.updateCostGroupHandler(this.state.costGroup);
  }

  onCancelClick() {
    this.props.updateCostGroupHandler(null);
  }

  onCostGroupChange(costGroupField = null, newValue = null) {
    if (costGroupField && newValue !== null) {
      const errors = {
        name: this.state.errors.name,
        costCenter: this.state.errors.costCenter,
      };

      switch ( costGroupField ) { // eslint-disable-line
        case 'name':
          errors.name = this.validateName(newValue);
          break;
        case 'costCenter':
          errors.costCenter = this.validateCostCenter(newValue);
      }

      const newCostGroup = cloneDeep(this.state.costGroup);

      newCostGroup[costGroupField] = newValue;
      this.setState({ // eslint-disable-line
        costGroup: newCostGroup,
        errors,
      });
    }
  }

  validateName(name = '') {
    if (name.length === 0) {
      return true;
    }
    if (name.search(/([^a-zA-Z0-9\s\)\(&\-])/) === -1) {
      return false;
    }

    return true;
  }

  validateCostCenter(costCenter = '') {
    if (costCenter.length === 0) {
      return true;
    }
    if (costCenter.search(/[^a-zA-Z0-9\-]/) === -1) {
      return false;
    }

    return true;
  }

  renderIsActiveEditingBtns() {
    return (
      <label className="react-toggle-label">
        <span className="react-toggle-text">Active?</span>
        <Toggle
          defaultChecked={this.state.costGroup.isActive}
          onChange={() => this.onCostGroupChange('isActive', !this.state.costGroup.isActive)}
        />
      </label>
    );
  }

  renderExcludeDistributionsBtns() {
    return (
      <label className="react-toggle-label" style={{ marginLeft: '12.5%' }}>
        <span className="react-toggle-text">Exclude?</span>
        <Toggle
          defaultChecked={this.state.costGroup.excludeFromDistributions}
          onChange={() => this.onCostGroupChange('excludeFromDistributions', !this.state.costGroup.excludeFromDistributions)}
        />
      </label>
    );
  }

  renderSaveButton(errors = false) {
    if (errors.name || errors.costGroup
      || this.state.costGroup.name === ''
      || this.state.costGroup.costCenter === '') {
      return (
        <button
          className="btn btn-primary pull-right"
          disabled
          onClick={() => this.onSaveClick()}
        >
          Save
        </button>
      );
    }

    return (
      <button
        className="btn btn-primary pull-right"
        onClick={() => this.onSaveClick()}
      >
        Save
      </button>
    );
  }

  render() {
    const nameTooltip = (
      <Popover
        id="popover-positioned-right"
        title={`Cost Group: ${this.state.costGroup.id || 'NEW COST GROUP'}`}
      >
        Names are the visible ID for a Cost Group &mdash; they should only contain
        alpha-numeric characters and dashes (
        <code>-</code>
        ).
      </Popover>
    );

    const costCenterTooltip = (
      <Popover
        id="popover-positioned-right"
        title={`Cost Group: ${this.state.costGroup.id || 'NEW COST GROUP'}`}
      >
        This unique string should already exist in SAP.
      </Popover>
    );

    return (
      <div className="list-group-item edit-mode">
        {this.renderSaveButton(this.state.errors)}
        <button
          className="btn btn-default pull-right cancel-button"
          onClick={() => this.onCancelClick()}
        >
          Cancel
        </button>
        <div className={this.state.errors.name ? 'form-group has-error has-feedback' : 'form-group'}>
          <OverlayTrigger
            overlay={nameTooltip}
            placement="right"
            trigger={['focus']}
          >
            <div className="input-group col-xs-6">
              <div className="input-group-addon form-tag">Name</div>
              <input
                className="form-control"
                defaultValue={this.state.costGroup.name}
                id="exampleInputAmount"
                onChange={e => this.onCostGroupChange('name', e.target.value)}
                type="text"
              />
            </div>
          </OverlayTrigger>
        </div>
        <div className={this.state.errors.costCenter ? 'form-group has-error has-feedback' : 'form-group'}>
          <OverlayTrigger
            overlay={costCenterTooltip}
            placement="right"
            trigger={['focus']}
          >
            <div className="input-group col-xs-6">
              <div className="input-group-addon form-tag">Cost Center</div>
              <input
                className="form-control"
                defaultValue={this.state.costGroup.costCenter}
                id="exampleInputAmount"
                onChange={e => this.onCostGroupChange('costCenter', e.target.value)}
                type="text"
              />
            </div>
          </OverlayTrigger>
        </div>
        {this.renderIsActiveEditingBtns()}
        {this.renderExcludeDistributionsBtns()}
      </div>
    );
  }
}

EditCostGroupItem.propTypes = {
  costGroup: PropTypes.object.isRequired,
  updateCostGroupHandler: PropTypes.func.isRequired,
};

export default EditCostGroupItem;
