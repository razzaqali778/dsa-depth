import { Button, Glyphicon } from 'react-bootstrap';
import React from 'react';

const downloadMultiplePeopleButton = action => (
  <Button
    className="btn pull-right"
    color="default"
    onClick={() => action()}
    title="Download CSV"
  >
    <Glyphicon glyph="download-alt" />
  </Button>
);

export default downloadMultiplePeopleButton;
