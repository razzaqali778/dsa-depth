import { Button } from 'react-bootstrap';
import React from 'react';

const downloadModalButton = action => (
  <Button
    color="default"
    onClick={() => action()}
  >
    Download CSV
  </Button>
);

export default downloadModalButton;
