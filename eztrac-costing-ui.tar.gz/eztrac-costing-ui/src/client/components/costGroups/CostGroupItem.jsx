import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React from 'react';
import {
  costGroups as costGroupActions,
} from '../../redux/actions';
import EditCostGroupItem from './EditCostGroupItem';

function CostGroupItem({
  fetchCostGroupPeople,
  isEditing,
  putUpdateCostGroup,
  costGroup,
  toggleIsEditing,
  fetchPeopleByCostGroupId,
}) {
  const costGroupStatus = (status = false) => {
    const label = status ? 'Active Cost Group' : 'Inactive Cost Group';
    const className = status ? 'success' : 'danger';

    return (
      <span className={`label label-${className}`}>{label}</span>
    );
  };

  const renderShowPeopleButton = () => {
    if (isEditing) {
      return (
        <button
          className="btn btn-default pull-right"
          disabled
        >
          Show People
        </button>
      );
    }

    return (
      <button
        className="btn btn-default pull-right"
        onClick={() => fetchCostGroupPeople(costGroup)}
      >
        Show People
      </button>
    );
  };

  const renderNormal = () => (
    <div className="list-group-item">
      <h4 className="list-group-item-heading inline-block">{costGroup.name}</h4>
      <button
        className="btn btn-default pull-right"
        onClick={() => toggleIsEditing(costGroup.id)}
      >
        Edit
      </button>
      {renderShowPeopleButton()}
      <ul>
        <li>
          <strong>Cost Center:&nbsp;</strong>
          <code>{costGroup.costCenter}</code>
        </li>
        <li>
          <strong>Cost Group ID:&nbsp;</strong>
          <code>{costGroup.id}</code>
        </li>
        {costGroupStatus(costGroup.isActive)}
      </ul>
    </div>
  );

  const saveNewCostGroup = newCostGroup => {
    if (newCostGroup) {
      if (newCostGroup.isActive !== costGroup.isActive) {
        fetchPeopleByCostGroupId(newCostGroup);
      } else {
        putUpdateCostGroup(newCostGroup);
      }
    } else {
      toggleIsEditing('');
    }
  };

  const renderEditing = () => (
    <EditCostGroupItem costGroup={costGroup} updateCostGroupHandler={saveNewCostGroup} />
  );

  return isEditing === costGroup.id ? renderEditing() : renderNormal();
}

CostGroupItem.propTypes = {
  costGroup: PropTypes.object.isRequired,
  fetchCostGroupPeople: PropTypes.func.isRequired,
  isEditing: PropTypes.string.isRequired,
  putUpdateCostGroup: PropTypes.func.isRequired,
  toggleIsEditing: PropTypes.func.isRequired,
  updateCostGroup: PropTypes.func.isRequired,
  viewPeopleWithCostGroup: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  isEditing: state.costGroups.isEditing,
});

export default connect(mapStateToProps, { ...costGroupActions })(CostGroupItem);
