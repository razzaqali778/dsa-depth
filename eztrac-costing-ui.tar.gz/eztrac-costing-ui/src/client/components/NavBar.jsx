import React from 'react';
import ReactDOM from 'react-dom';
import moment from 'moment';
import navbar from '@monsantoit/phoenix-navbar';
import pkg from '../../../package.json'; // eslint-disable-line import/default

export default navbar.def({ moment, React, ReactDOM }, pkg);
