import PropTypes from 'prop-types';
import React from 'react';
import Select from 'react-select';
import Toggle from 'react-toggle';
import includes from 'lodash/includes';

class CreatePerson extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      person: {
        personId: props.person.personId,
        personName: props.person.personName,
        costGroupName: undefined,
        rateName: undefined,
        isActive: true,
        isEmployee: props.person.isEmployee,
        photo: props.person.photo,
      },
    };
  }

  setCostGroup = newCostGroup => {
    const updatedPerson = {
      ...this.state.person,
      costGroupName: newCostGroup.label,
    };

    this.setState({ person: updatedPerson, selectedCostGroup: newCostGroup }); // eslint-disable-line react/no-set-state
  };

  setRate = newRate => {
    const updatedPerson = {
      ...this.state.person,
      rateName: newRate.label,
    };

    this.setState({ person: updatedPerson, selectedRate: newRate }); // eslint-disable-line react/no-set-state
  };

  renderIsActiveEditingBtns() {
    const toggleStateValue = () => {
      const updatedPerson = {
        ...this.state.person,
        isActive: !this.state.person.isActive,
      };

      this.setState({ person: updatedPerson }); // eslint-disable-line react/no-set-state
    };

    return (
      <div className="form-group">
        <label className="react-toggle-label">
          <span className="react-toggle-text">Active</span>
          <Toggle
            defaultChecked={this.state.person.isActive}
            onChange={toggleStateValue}
          />
        </label>
      </div>
    );
  }

  renderIsEmployeBtn() {
    return (
      <div className="form-group">
        <label className="react-toggle-label">
          <span className="react-toggle-text">Is Employee</span>
          <Toggle
            defaultChecked={this.state.person.isEmployee}
            disabled
          />
        </label>
      </div>
    );
  }

  renderSaveButton() {
    const disabled = includes(this.state.person, undefined);

    return (
      <button
        className="btn btn-primary pull-right"
        disabled={disabled}
        onClick={() => this.props.createPerson(this.state.person)}
      >
        Save
      </button>
    );
  }

  render() {
    return (
      <div className="list-group-item edit-mode">
        {this.renderSaveButton()}
        <button
          className="btn btn-default pull-right"
          onClick={this.props.cancelCreating}
        >
          Cancel
        </button>
        <div className="form-group">
          <div className="input-group col-xs-6">
            <div className="input-group-addon form-tag">ID</div>
            <input
              className="form-control"
              defaultValue={this.state.person.personId}
              disabled
            />
          </div>
        </div>
        <div className="form-group">
          <div className="input-group col-xs-6">
            <div className="input-group-addon form-tag">Name</div>
            <input
              className="form-control"
              defaultValue={this.state.person.personName}
              disabled
            />
          </div>
        </div>
        <div className="form-group">
          <div className="input-group col-xs-6">
            <div className="input-group-addon form-tag">Cost Group</div>
            <Select
              onChange={this.setCostGroup}
              options={this.props.costCenters}
              value={this.state.selectedCostGroup}
            />
          </div>
        </div>
        <div className="form-group">
          <div className="input-group col-xs-6">
            <div className="input-group-addon form-tag">Rate</div>
            <Select
              onChange={this.setRate}
              options={this.props.rates}
              value={this.state.selectedRate}
            />
          </div>
        </div>
        {this.renderIsActiveEditingBtns()}
        {this.renderIsEmployeBtn()}
      </div>
    );
  }
}

CreatePerson.propTypes = {
  cancelCreating: PropTypes.func.isRequired,
  costCenters: PropTypes.array.isRequired,
  createPerson: PropTypes.func.isRequired,
  person: PropTypes.object.isRequired,
  rates: PropTypes.array.isRequired,
};

export default CreatePerson;
