import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React from 'react';
import { people as peopleActions } from '../../redux/actions';

function PersonNotFound({
  personNotFound,
  toggleIsCreating,
}) {
  return (
    <div className="alert alert-warning" role="alert">
      <img className="img-circle person-photo" role="presentation" src={`${personNotFound.photo}`} />
      Could not find
      {' '}
      {personNotFound.personName}
      {' '}
      (
      {personNotFound.personId}
      ).
      Would you like to add them?
      <div className="row">
        <button
          className="btn btn-default new-person-button"
          onClick={() => toggleIsCreating(true)}
        >
          Add Person
        </button>
      </div>
    </div>
  );
}

PersonNotFound.propTypes = {
  personNotFound: PropTypes.object.isRequired,
  toggleIsCreating: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  personNotFound: state.people.personNotFound,
});

export default connect(mapStateToProps, { ...peopleActions })(PersonNotFound);
