import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React from 'react';
import {
  people as peopleActions,
} from '../../redux/actions';
import EditPerson from './EditPerson';
import getCostGroupsFormatted from '../../redux/selectors/getCostGroupsFormatted';
import getRatesFormatted from '../../redux/selectors/getRatesFormatted';

function Person({
  costCenters,
  isEditing,
  person,
  rates,
  toggleIsEditing,
  updatePerson,
}) {
  const isActiveStatus = status => {
    const label = status ? 'Active Person' : 'Inactive Person';
    const className = status ? 'success' : 'danger';

    return (
      <span className={`label label-${className}`}>{label}</span>
    );
  };

  const renderNormal = () => (
    <div className="list-group-item person-pane">
      <h4 className="list-group-item-heading inline-block">
        {person.personName}
        {' '}
        (
        {person.personId}
        )
      </h4>
      <button
        className="btn btn-default pull-right"
        onClick={() => toggleIsEditing(true)}
      >
        Edit
      </button>
      <img className="img-circle person-photo" role="presentation" src={`${person.photo}`} />
      <ul className="person-characteristics">
        <li>
          <strong>Cost Group Name</strong>
          <code>{person.costGroupName}</code>
        </li>
        <li>
          <strong>Rate Name</strong>
          <code>{person.rateName}</code>
        </li>
        <li>
          <strong>isEmployee</strong>
          <code>{person.isEmployee.toString()}</code>
        </li>
        {isActiveStatus(person.isActive)}
      </ul>
    </div>
  );

  const renderEditing = () => (
    <EditPerson
      cancelEditing={() => toggleIsEditing(false)}
      costCenters={costCenters}
      person={person}
      rates={rates}
      updatePersonHandler={updatePerson}
    />
  );

  return isEditing ? renderEditing() : renderNormal();
}

Person.propTypes = {
  isEditing: PropTypes.bool.isRequired,
  person: PropTypes.object.isRequired,
  toggleIsEditing: PropTypes.func.isRequired,
  updatePerson: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  costCenters: getCostGroupsFormatted(state),
  isEditing: state.people.isEditing,
  rates: getRatesFormatted(state),
});

export default connect(mapStateToProps, { ...peopleActions })(Person);
