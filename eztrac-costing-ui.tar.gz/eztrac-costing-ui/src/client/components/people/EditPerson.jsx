import PropTypes from 'prop-types';
import React from 'react';
import Select from 'react-select';
import Toggle from 'react-toggle';
import find from 'lodash/find';

class EditPerson extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      person: props.person,
      selectedCostGroup: find(this.props.costCenters, c => c.label === props.person.costGroupName),
      selectedRate: find(this.props.rates, r => r.label === props.person.rateName),
    };
  }

  setCostGroup = newCostGroup => {
    const updatedPerson = {
      ...this.state.person,
      costGroupName: newCostGroup.label,
    };

    this.setState({ person: updatedPerson, selectedCostGroup: newCostGroup }); // eslint-disable-line react/no-set-state
  };

  setRate = newRate => {
    const updatedPerson = {
      ...this.state.person,
      rateName: newRate.label,
    };

    this.setState({ person: updatedPerson, selectedRate: newRate }); // eslint-disable-line react/no-set-state
  };

  renderToggleButton = (toggleProperty, toggleText) => {
    const toggleStateValue = () => {
      const updatedPerson = {
        ...this.state.person,
        [toggleProperty]: !this.state.person[toggleProperty],
      };

      this.setState({ person: updatedPerson }); // eslint-disable-line react/no-set-state
    };

    return (
      <label className="react-toggle-label">
        <span className="react-toggle-text">{toggleText}</span>
        <Toggle
          defaultChecked={this.state.person[toggleProperty]}
          onChange={toggleStateValue}
        />
      </label>
    );
  };

  renderSaveButton() {
    return (
      <button
        className="btn btn-primary pull-right"
        onClick={() => this.props.updatePersonHandler(this.state.person)}
      >
        Save
      </button>
    );
  }

  render() {
    return (
      <div className="list-group-item edit-mode">
        {this.renderSaveButton()}
        <button
          className="btn btn-default pull-right"
          onClick={this.props.cancelEditing}
        >
          Cancel
        </button>
        <h4>
          {this.state.person.personName}
          {' '}
          (
          {this.state.person.personId}
          )
        </h4>
        <div className="form-group">
          <div className="input-group col-xs-6">
            <div className="input-group-addon form-tag">Cost Group</div>
            <Select
              clearable={false}
              onChange={this.setCostGroup}
              options={this.props.costCenters}
              value={this.state.selectedCostGroup}
            />
          </div>
        </div>
        <div className="form-group">
          <div className="input-group col-xs-6">
            <div className="input-group-addon form-tag">Rate</div>
            <Select
              clearable={false}
              onChange={this.setRate}
              options={this.props.rates}
              value={this.state.selectedRate}
            />
          </div>
        </div>
        <div className="form-group">
          <div className="input-group col-xs-6">
            {this.renderToggleButton('isActive', 'Active')}
          </div>
        </div>
        {this.renderToggleButton('isEmployee', 'isEmployee')}
      </div>
    );
  }
}

EditPerson.propTypes = {
  cancelEditing: PropTypes.func.isRequired,
  costCenters: PropTypes.array.isRequired,
  person: PropTypes.object.isRequired,
  rates: PropTypes.array.isRequired,
  updatePersonHandler: PropTypes.func.isRequired,
};

export default EditPerson;
