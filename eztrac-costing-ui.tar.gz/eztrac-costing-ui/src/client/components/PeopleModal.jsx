import {
  Modal,
  Table,
} from 'react-bootstrap';
import React from 'react';
import downloadCSV from './costGroups/DownloadCSV';

const renderPeoplePopUp = (popUpData, label, closeModal, action) => {
  const people = popUpData.people.map((p, index) => (
    <tr key={index}>
      <td>
        {' '}
        {p.personName}
        {' '}
      </td>
      <td>
        {' '}
        {p.personId}
        {' '}
      </td>
      <td>
        {' '}
        {label === 'Rate' ? p.rateName : p.costGroupName}
        {' '}
      </td>
    </tr>
  ));

  const displayDownloadButton = displayablePeople => {
    if (displayablePeople.length !== 0) {
      return downloadCSV(action);
    }

    return null;
  };

  const peopleText = people.length === 0
    ? `There are no people in this ${label}.`
    : (
      <Table bordered condensed striped>
        <thead>
          <tr>
            <th> Name </th>
            <th> CWID </th>
            <th>
              {' '}
              {label}
              {' '}
            </th>
          </tr>
        </thead>
        <tbody>
          {people}
        </tbody>
      </Table>
    );

  return (
    <Modal show={popUpData.showPopup}>
      <Modal.Header closeButton onClick={closeModal}>
        <Modal.Title>People</Modal.Title>
      </Modal.Header>
      <Modal.Body className="peopleModal">
        {peopleText}
      </Modal.Body>
      <Modal.Footer>
        <div className="downloadButton">
          {displayDownloadButton(people)}
        </div>
        <button className="btn btn-primary" onClick={closeModal}>Close</button>
      </Modal.Footer>
    </Modal>
  );
};

export default renderPeoplePopUp;
