import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React from 'react';
import find from 'lodash/find';
import get from 'lodash/get';
import EditRateItem from './EditRateItem';
import {
  rate as rateActions,
} from '../../redux/actions';

function RateItem({
  calendars,
  fetchPeopleByRateId,
  fetchRatePeople,
  isCreating,
  isEditing,
  putUpdateRate,
  rate,
  toggleIsEditing,
}) {
  const rateStatus = (status = false) => {
    const label = status ? 'Active Rate' : 'Inactive Rate';
    const className = status ? 'success' : 'danger';

    return (
      <span className={`label label-${className}`}>{label}</span>
    );
  };

  const displayCalendar = calendarId => {
    const calendar = find(calendars, { value: calendarId });

    return get(calendar, 'label', calendarId);
  };

  const renderShowPeopleButton = () => {
    if (isCreating) {
      return (
        <button
          className="btn btn-default pull-right"
          disabled
        >
          Show People
        </button>
      );
    }

    return (
      <button
        className="btn btn-default pull-right"
        onClick={() => fetchRatePeople(rate)}
      >
        Show People
      </button>
    );
  };

  const renderEditBtn = () => {
    if (isCreating) {
      return (
        <button
          className="btn btn-default pull-right"
          disabled
          onClick={() => toggleIsEditing(rate.id)}
        >
          Edit
        </button>
      );
    }

    return (
      <button
        className="btn btn-default pull-right"
        onClick={() => toggleIsEditing(rate.id)}
      >
        Edit
      </button>
    );
  };

  const renderNormal = () => (
    <div className="list-group-item">
      <h4 className="list-group-item-heading inline-block">{rate.name}</h4>
      {renderEditBtn()}
      {renderShowPeopleButton()}
      <ul>
        <li>
          <strong>Rate ID:&nbsp;</strong>
          <code>{rate.id}</code>
        </li>
        <li>
          <strong>Hourly Rate:&nbsp;</strong>
          <code>{rate.hourlyRate}</code>
        </li>
        <li>
          <strong>Calendar:&nbsp;</strong>
          <code>{displayCalendar(rate.calendarId)}</code>
        </li>
        {rateStatus(rate.isActive)}
      </ul>
    </div>
  );

  const saveNewRate = newRate => {
    if (newRate) {
      if (newRate.isActive !== rate.isActive) {
        fetchPeopleByRateId(newRate);
      } else {
        putUpdateRate(newRate);
      }
    } else {
      toggleIsEditing('');
    }
  };

  const renderEditing = () => (
    <EditRateItem calendars={calendars} rate={rate} updateRateHandler={saveNewRate} />
  );

  return isEditing === rate.id ? renderEditing() : renderNormal();
}

RateItem.propTypes = {
  calendars: PropTypes.array.isRequired,
  fetchPeopleByRateId: PropTypes.func.isRequired,
  fetchRatePeople: PropTypes.func.isRequired,
  isCreating: PropTypes.bool.isRequired,
  isEditing: PropTypes.string.isRequired,
  putUpdateRate: PropTypes.func.isRequired,
  rate: PropTypes.object.isRequired,
  toggleIsEditing: PropTypes.func.isRequired,
  viewPeopleWithRate: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  isCreating: state.rate.isCreating,
  isEditing: state.rate.isEditing,
  isUpdating: state.async.isUpdating,
});

export default connect(mapStateToProps, { ...rateActions })(RateItem);
