import { OverlayTrigger, Popover } from 'react-bootstrap';
import PropTypes from 'prop-types';
import React from 'react';
import Select from 'react-select';
import Toggle from 'react-toggle';
import find from 'lodash/find';
import inRange from 'lodash/inRange';
import isUndefined from 'lodash/isUndefined';

class EditRateItem extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      rate: props.rate,
      selectedCalendar: find(this.props.calendars, c => c.value === props.rate.calendarId),
      errors: {
        name: '',
        hourlyRate: '',
        selectedCalendar: null,
      },
    };
  }

  /**
   * Event Handlers
   **************************************************************** */

  onSaveClick() {
    this.props.updateRateHandler(this.state.rate);
  }

  onCancelClick() {
    this.props.updateRateHandler(null);
  }

  onRateChange(rateField = null, newValue = null) {
    if (rateField && newValue !== null) {
      const newRate = { ...this.state.rate };
      const errors = {
        name: this.state.errors.name,
        hourlyRate: this.state.errors.hourlyRate,
        selectedCalendar: this.state.errors.selectedCalendar,
      };

      switch (rateField) {
        case 'name':
          errors.name = this.validateName(newValue);
          break;
        case 'hourlyRate':
          errors.hourlyRate = this.validateHourlyRate(newValue);
          break;
        default: break;
      }

      newRate[rateField] = newValue;
      this.setState({ // eslint-disable-line
        rate: newRate,
        errors,
      });
    }
  }

  setCalendar = newCalendar => {
    const updatedRate = {
      ...this.state.rate,
      calendarId: newCalendar.value,
    };

    const errors = {
      ...this.state.errors,
      selectedCalendar: this.validateSelectedCalendar(newCalendar),
    };

    this.setState({
      rate: updatedRate,
      selectedCalendar: newCalendar,
      errors,
    }); // eslint-disable-line react/no-set-state
  };

  /**
   * Validation Functions
   **************************************************************** */

  validateName(name = '') {
    if (name.length === 0) {
      return true;
    }
    if (name.search(/([^a-zA-Z0-9\s\)\(&\-])/) === -1) {
      return false;
    }

    return true;
  }

  validateHourlyRate(hourlyRate = 0) {
    return !inRange(hourlyRate, 0, Infinity);
  }

  validateSelectedCalendar(selectedCalendar = null) {
    if (selectedCalendar.value) {
      return false;
    }

    return true;
  }

  /**
   * Rendering Functions
   **************************************************************** */

  renderIsActiveEditingBtns() {
    return (
      <label className="react-toggle-label">
        <span className="react-toggle-text">Active Rate</span>
        <Toggle
          defaultChecked={this.state.rate.isActive}
          onChange={() => this.onRateChange('isActive', !this.state.rate.isActive)}
        />
      </label>
    );
  }

  renderSaveButton(errors = false) {
    if (errors.name || errors.engagement || errors.hourlyRate
      || this.state.rate.name === ''
      || this.state.rate.hourlyRate === ''
      || isUndefined(this.state.selectedCalendar)) {
      return (
        <button
          className="btn btn-primary pull-right"
          disabled
          onClick={() => this.onSaveClick()}
        >
          Save
        </button>
      );
    }

    return (
      <button
        className="btn btn-primary pull-right"
        onClick={() => this.onSaveClick()}
      >
        Save
      </button>
    );
  }

  render() {
    const nameTooltip = (
      <Popover id="popover-positioned-right" title={`Rate: ${this.state.rate.id || 'NEW RATE'}`}>
        Names are the visible ID for a rate &mdash; they should only contain
        alpha-numeric characters. Certain special characters (i.e
        {' '}
        <code>(</code>
        ,
        <code>)</code>
        , and
        <code>&</code>
        ) are allowed.
      </Popover>
    );
    const hourlyRateTooltip = (
      <Popover id="popover-positioned-right" title={`Rate: ${this.state.rate.id || 'NEW RATE'}`}>
        Hourly rates must be a positive integer.
      </Popover>
    );

    return (
      <div className="list-group-item edit-mode">
        {this.renderSaveButton(this.state.errors)}
        <button
          className="btn btn-default pull-right cancel-button"
          onClick={() => this.onCancelClick()}
        >
          Cancel
        </button>
        <div className={this.state.errors.name ? 'form-group has-error' : 'form-group'}>
          <OverlayTrigger overlay={nameTooltip} placement="right" trigger={['focus']}>
            <div className="input-group col-xs-6">
              <div className="input-group-addon form-tag">Name</div>
              <input
                className="form-control"
                defaultValue={this.state.rate.name}
                id="exampleInputAmount"
                onChange={e => this.onRateChange('name', e.target.value)}
                type="text"
              />
            </div>
          </OverlayTrigger>
        </div>
        <div className={this.state.errors.hourlyRate ? 'form-group has-error has-feedback' : 'form-group'}>
          <OverlayTrigger overlay={hourlyRateTooltip} placement="right" trigger={['focus']}>
            <div className="input-group col-xs-6">
              <div className="input-group-addon form-tag">Hourly Rate</div>
              <input
                className="form-control"
                defaultValue={this.state.rate.hourlyRate}
                id="exampleInputAmount"
                onChange={e => this.onRateChange('hourlyRate', Number.parseInt(e.target.value, 10))}
                type="text"
              />
            </div>
          </OverlayTrigger>
        </div>
        <div className="form-group">
          <div className="input-group col-xs-6">
            <div className="input-group-addon form-tag">Calendar</div>
            <Select
              clearable={false}
              onChange={this.setCalendar}
              options={this.props.calendars}
              value={this.state.selectedCalendar}
            />
          </div>
        </div>
        {this.renderIsActiveEditingBtns()}
      </div>
    );
  }
}

EditRateItem.propTypes = {
  calendars: PropTypes.array.isRequired,
  rate: PropTypes.object.isRequired,
  updateRateHandler: PropTypes.func.isRequired,
};

export default EditRateItem;
