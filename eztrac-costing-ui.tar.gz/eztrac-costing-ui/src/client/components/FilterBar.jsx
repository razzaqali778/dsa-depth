import { DropdownButton, MenuItem } from 'react-bootstrap';
import React from 'react';

class FilterBar extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      title: 'ACTIVE',
    };
  }

  render() {
    return (
      <DropdownButton
        className="btn-group btn-group-justified"
        onSelect={evt => {
          this.setState({ title: evt });
          this.props.setFilter(evt);
        }}
        title={this.state.title}
      >
        <MenuItem eventKey="ACTIVE">ACTIVE</MenuItem>
        <MenuItem eventKey="ALL">ALL</MenuItem>
        <MenuItem eventKey="INACTIVE">INACTIVE</MenuItem>
      </DropdownButton>
    );
  }
}

export default FilterBar;
