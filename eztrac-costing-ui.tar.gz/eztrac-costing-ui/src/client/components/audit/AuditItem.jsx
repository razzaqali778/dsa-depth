import PropTypes from 'prop-types';
import React from 'react';
import map from 'lodash/map';
import moment from 'moment';

function AuditItem({
  item,
}) {
  const parseJson = jsonObject => map(jsonObject, (value, key) => (
    <li>
      <strong>
        {key[0].toUpperCase() + key.substring(1)}
        :
      </strong>
      {' '}
      {value.toString()}
    </li>
  ));

  const parseTypeName = name => name.replace('_', ' ').replace(/\w\S*/g, txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLocaleLowerCase());

  return (
    <tr>
      <td>
        <dl>
          <dt>{parseTypeName(item.entityType)}</dt>
          <dd className="audit-table-left">{item.entityKey}</dd>
          <dt>Edited By</dt>
          <dd className="audit-table-left">{item.userId}</dd>
          <dt>Modified Time</dt>
          <dd className="audit-table-left">{moment(item.modifiedTime).format('dddd, MMMM Do YYYY, h:mm:ss a')}</dd>
        </dl>
      </td>
      <td>
        <pre>
          <ul className="audit-list">
            {parseJson(item.entity)}
          </ul>
        </pre>
      </td>
    </tr>
  );
}

AuditItem.propTypes = {
  item: PropTypes.object.isRequired,
};

export default AuditItem;
