import { Provider } from 'react-redux';
import { enableAuthTokenSupport } from '@monsantoit/profile-client';
import { render } from 'react-dom';
import { ConnectedRouter } from 'connected-react-router';
import React from 'react';
import ReduxToastr from 'react-redux-toastr';
import navbar from '@monsantoit/phoenix-navbar';
import makeRoutes from './routes';
import makeStore from './redux';
import history from './history';

async function startup() {
  await enableAuthTokenSupport();
  navbar.install({
    element: document.querySelector('.nav'),
    suiteId: 'pe-admin',
    productId: 'ez-trac',
    cookieName: 'ez-trac-costing-ui',
  })
    .then(() => {
      const store = makeStore();
      const routes = makeRoutes(store);

      render(
        <Provider store={store}>
          <div>
            <ReduxToastr position="top-right" preventDuplicates />
            <ConnectedRouter history={history}>
              {routes}
            </ConnectedRouter>
          </div>
        </Provider>,
        document.getElementById('root'),
      );
    })
    .catch(err => {
      // Errors thrown as part of installation will likely be from invalid
      // auth tokens. Be sure to run a local ocelot instance to avoid this.
      console.error(err); // eslint-disable-line no-console
    });
}
startup();
