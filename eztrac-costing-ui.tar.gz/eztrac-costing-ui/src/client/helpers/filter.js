const filter = (arr, activeFilter) => {
  switch (activeFilter) {
    case 'ALL': return arr;
    case 'ACTIVE': return arr.filter(el => el.isActive);
    case 'INACTIVE': return arr.filter(el => !el.isActive);
    default: return arr;
  }
};

export default filter;
