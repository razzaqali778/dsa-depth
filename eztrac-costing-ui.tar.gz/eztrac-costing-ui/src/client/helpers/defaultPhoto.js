const defaultPhoto = 'https://static-assets.velocity.ag/images/profile/user-default.jpg';

export default defaultPhoto;
