import { combineReducers } from 'redux';
import {
  ADD_ENGAGEMENT,
  SET_ALL_ENGAGEMENTS_DATA,
  SET_SEARCH_TEXT,
  TOGGLE_IS_CREATING,
  TOGGLE_IS_EDITING,
  UPDATE_ENGAGEMENT,
  UPDATING_ENGAGEMENT,
} from '../constants/engagementsConstants';

const data = (state = [], action = {}) => {
  switch (action.type) {
    case SET_ALL_ENGAGEMENTS_DATA: return action.payload;
    case UPDATE_ENGAGEMENT: {
      return state.map(engagement => {
        if (engagement.id === action.payload.id) {
          return action.payload;
        }

        return engagement;
      });
    }
    case ADD_ENGAGEMENT: {
      return [...state, action.payload];
    }
    default: return state;
  }
};

const searchText = (state = '', action = {}) => {
  switch (action.type) {
    case SET_SEARCH_TEXT: return action.payload;
    default: return state;
  }
};

const isUpdating = (state = false, action = {}) => {
  switch (action.type) {
    case UPDATING_ENGAGEMENT: return action.payload;
    default: return state;
  }
};

const isCreating = (state = false, action = {}) => {
  switch (action.type) {
    case TOGGLE_IS_CREATING: return action.payload;
    case ADD_ENGAGEMENT: return false;
    default: return state;
  }
};

const isEditing = (state = '', action = {}) => {
  switch (action.type) {
    case TOGGLE_IS_EDITING: return action.payload;
    case UPDATE_ENGAGEMENT: return '';
    default: return state;
  }
};

const reducer = combineReducers({
  searchText,
  isCreating,
  data,
  isEditing,
  isUpdating,
});

export default reducer;
