import { combineReducers } from 'redux';
import {
  CLEAR_FILTER,
  SET_FILTER,
} from '../constants/filterConstants';

const activeFilter = (state = 'ACTIVE', action = {}) => {
  switch (action.type) {
    case CLEAR_FILTER: return 'ACTIVE';
    case SET_FILTER: return action.payload;
    default: return state;
  }
};

const reducer = combineReducers({
  activeFilter,
});

export default reducer;
