import { combineReducers } from 'redux';
import {
  ADD_NEW_RATE,
  CANCEL_AFFECTED_PEOPLE_POPUP,
  CANCEL_RATE_PEOPLE_POPUP,
  SET_ALL_RATE_DATA,
  SET_PEOPLE_WITH_RATE_ID,
  SET_SEARCH_TEXT,
  TOGGLE_IS_CREATING,
  TOGGLE_IS_EDITING,
  UPDATE_RATE,
  VIEW_PEOPLE_WITH_RATE,
} from '../constants/ratesConstants';

const data = (state = [], action = {}) => {
  switch (action.type) {
    case SET_ALL_RATE_DATA: return action.payload;
    case UPDATE_RATE: {
      return state.map(rate => {
        if (rate.id === action.payload.id) {
          return action.payload;
        }

        return rate;
      });
    }
    case ADD_NEW_RATE:
      return [...state, action.payload];
    default: return state;
  }
};

const isEditing = (state = '', action = {}) => {
  switch (action.type) {
    case TOGGLE_IS_EDITING: return action.payload;
    case UPDATE_RATE: return '';
    default: return state;
  }
};

/* `true` when creating a *new* rate. */
const isCreating = (state = false, action = {}) => {
  switch (action.type) {
    case TOGGLE_IS_CREATING: return action.payload;
    case ADD_NEW_RATE: return false;
    default: return state;
  }
};

const affectedPeoplePopup = (state = { showPopup: false, people: [], rate: undefined }, action = {}) => {
  switch (action.type) {
    case SET_PEOPLE_WITH_RATE_ID: return { showPopup: true, people: action.payload.people, rate: action.payload.rate };
    case UPDATE_RATE: return { showPopup: false, people: [], rate: undefined };
    case CANCEL_AFFECTED_PEOPLE_POPUP: return { showPopup: false, people: [], rate: undefined };
    default: return state;
  }
};

const ratePeoplePopup = (state = { showPopup: false, people: [], rate: undefined }, action = {}) => {
  switch (action.type) {
    case VIEW_PEOPLE_WITH_RATE: return { showPopup: true, people: action.payload.people, rate: action.payload.rate };
    case CANCEL_RATE_PEOPLE_POPUP: return { showPopup: false, people: [], rate: undefined };
    default: return state;
  }
};

const searchText = (state = '', action = {}) => {
  switch (action.type) {
    case SET_SEARCH_TEXT: return action.payload;
    default: return state;
  }
};

const reducer = combineReducers({
  data,
  isEditing,
  isCreating,
  affectedPeoplePopup,
  ratePeoplePopup,
  searchText,
});

export default reducer;
