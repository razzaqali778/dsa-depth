import { combineReducers } from 'redux';
import { SET_ALL_CALENDARS } from '../constants/calendarConstants';

const data = (state = [], action = {}) => {
  switch (action.type) {
    case SET_ALL_CALENDARS: return action.payload;
    default: return state;
  }
};

const reducer = combineReducers({
  data,
});

export default reducer;
