import { combineReducers } from 'redux';
import {
  SET_UPDATING,
} from '../constants/asyncConstants.js';

const isUpdating = (state = false, action = {}) => {
  switch (action.type) {
    case SET_UPDATING: return action.payload;
    default: return state;
  }
};

const reducer = combineReducers({
  isUpdating,
});

export default reducer;
