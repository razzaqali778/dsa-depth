import { combineReducers } from 'redux';
import { connectRouter } from 'connected-react-router';
import { reducer as toastrReducer } from 'react-redux-toastr';
import async from './asyncReducer';
import audit from './auditsReducer';
import calendar from './calendarReducer';
import costGroups from './costGroupsReducer';
import engagements from './engagementsReducer';
import filter from './filterReducer';
import people from './peopleReducer';
import rate from './ratesReducer';

const makeRootReducer = (history) => combineReducers({
  audit,
  async,
  calendar,
  costGroups,
  engagements,
  filter,
  people,
  rate,
  router: connectRouter(history),
  toastr: toastrReducer,
});

export default makeRootReducer;
