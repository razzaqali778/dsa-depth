import { combineReducers } from 'redux';
import {
  SET_ALL_AUDIT_DATA,
  SET_SEARCH_TEXT,
} from '../constants/auditsConstants';

const data = (state = [], action = {}) => {
  switch (action.type) {
    case SET_ALL_AUDIT_DATA: return action.payload;
    default: return state;
  }
};

const searchText = (state = '', action = {}) => {
  switch (action.type) {
    case SET_SEARCH_TEXT: return action.payload;
    default: return state;
  }
};

const reducer = combineReducers({
  data,
  searchText,
});

export default reducer;
