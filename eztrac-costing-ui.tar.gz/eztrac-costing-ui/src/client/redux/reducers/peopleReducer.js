import { combineReducers } from 'redux';
import {
  SET_ALL_PEOPLE_DATA,
  SET_NOT_FOUND_PERSON,
  SET_PAPI_DATA,
  SET_PERSON_DATA,
  TOGGLE_IS_CREATING,
  TOGGLE_IS_EDITING,
} from '../constants/peopleConstants';

const data = (state = [], action = {}) => {
  switch (action.type) {
    case SET_ALL_PEOPLE_DATA: return action.payload;
    default: return state;
  }
};
const isCreating = (state = false, action = {}) => {
  switch (action.type) {
    case TOGGLE_IS_CREATING: return action.payload;
    case TOGGLE_IS_EDITING: return false;
    default: return state;
  }
};

const isEditing = (state = false, action = {}) => {
  switch (action.type) {
    case TOGGLE_IS_EDITING: return action.payload;
    case SET_PERSON_DATA: return false;
    case TOGGLE_IS_CREATING: return false;
    default: return state;
  }
};

const papiData = (state = [], action = {}) => {
  switch (action.type) {
    case SET_PAPI_DATA: return action.payload;
    default: return state;
  }
};

const person = (state = {}, action = {}) => {
  switch (action.type) {
    case SET_PERSON_DATA: return action.payload;
    case SET_NOT_FOUND_PERSON: return {};
    default: return state;
  }
};

const personNotFound = (state = { value: false }, action = {}) => {
  switch (action.type) {
    case SET_NOT_FOUND_PERSON: return action.payload;
    case SET_PERSON_DATA: return { value: false };
    default: return state;
  }
};

const reducer = combineReducers({
  data,
  isCreating,
  isEditing,
  papiData,
  person,
  personNotFound,
});

export default reducer;
