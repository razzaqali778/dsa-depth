import { combineReducers } from 'redux';
import {
  ADD_COST_GROUP,
  CANCEL_AFFECTED_PEOPLE_POPUP,
  CANCEL_COST_GROUP_PEOPLE_POPUP,
  SET_ALL_COST_GROUP_DATA,
  SET_PEOPLE_WITH_COST_GROUP_ID,
  SET_SEARCH_TEXT,
  TOGGLE_IS_CREATING,
  TOGGLE_IS_EDITING,
  UPDATE_COST_GROUP,
  UPDATING_COST_GROUP,
  VIEW_PEOPLE_WITH_COST_GROUP,
} from '../constants/costGroupsConstants';

const data = (state = [], action = {}) => {
  switch (action.type) {
    case SET_ALL_COST_GROUP_DATA: return action.payload;
    case UPDATE_COST_GROUP: {
      return state.map(costGroup => {
        if (costGroup.id === action.payload.id) {
          return action.payload;
        }

        return costGroup;
      });
    }
    case ADD_COST_GROUP: {
      return [...state, action.payload];
    }
    default: return state;
  }
};

const isEditing = (state = '', action = {}) => {
  switch (action.type) {
    case TOGGLE_IS_EDITING: return action.payload;
    case UPDATE_COST_GROUP: return '';
    default: return state;
  }
};

const isUpdating = (state = false, action = {}) => {
  switch (action.type) {
    case UPDATING_COST_GROUP: return action.payload;
    default: return state;
  }
};

const isCreating = (state = false, action = {}) => {
  switch (action.type) {
    case TOGGLE_IS_CREATING: return action.payload;
    case ADD_COST_GROUP: return false;
    default: return state;
  }
};

const affectedPeoplePopup = (state = { showPopup: false, people: [], costGroup: undefined }, action = {}) => {
  switch (action.type) {
    case SET_PEOPLE_WITH_COST_GROUP_ID: return {
      showPopup: true,
      people: action.payload.people,
      costGroup: action.payload.costGroup,
    };
    case UPDATE_COST_GROUP: return { showPopup: false, people: [], costGroup: undefined };
    case CANCEL_AFFECTED_PEOPLE_POPUP: return { showPopup: false, people: [], costGroup: undefined };
    default: return state;
  }
};

const costGroupPeoplePopup = (state = { showPopup: false, people: [], costGroup: undefined }, action = {}) => {
  switch (action.type) {
    case VIEW_PEOPLE_WITH_COST_GROUP: return {
      showPopup: true,
      people: action.payload.people,
      costGroup: action.payload.costGroup,
    };
    case CANCEL_COST_GROUP_PEOPLE_POPUP: return { showPopup: false, people: [], costGroup: undefined };
    default: return state;
  }
};

const searchText = (state = '', action = {}) => {
  switch (action.type) {
    case SET_SEARCH_TEXT: return action.payload;
    default: return state;
  }
};

const reducer = combineReducers({
  data,
  isCreating,
  isEditing,
  isUpdating,
  affectedPeoplePopup,
  costGroupPeoplePopup,
  searchText,
});

export default reducer;
