const namespace = 'async';

export const SET_UPDATING = `${namespace}/SET_UPDATING`;
