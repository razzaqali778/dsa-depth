const namespace = 'engagements';

export const ADD_ENGAGEMENT = `${namespace}/ADD_ENGAGEMENT`;
export const SET_SEARCH_TEXT = `${namespace}/SET_SEARCH_TEXT`;
export const TOGGLE_IS_CREATING = `${namespace}/TOGGLE_IS_CREATING`;
export const FETCH_ALL_ENGAGEMENTS_DATA = `${namespace}/FETCH_ALL_ENGAGEMENTS_DATA`;
export const SET_ALL_ENGAGEMENTS_DATA = `${namespace}/SET_ALL_ENGAGEMENTS_DATA`;
export const TOGGLE_IS_EDITING = `${namespace}/TOGGLE_IS_EDITING`;
export const POST_ENGAGEMENT = `${namespace}/POST_ENGAGEMENT`;
export const PUT_UPDATE_ENGAGEMENT = `${namespace}/PUT_UPDATE_ENGAGEMENT`;
export const UPDATE_ENGAGEMENT = `${namespace}/UPDATE_ENGAGEMENT`;
export const UPDATING_ENGAGEMENT = `${namespace}/UPDATING_ENGAGEMENT`;
