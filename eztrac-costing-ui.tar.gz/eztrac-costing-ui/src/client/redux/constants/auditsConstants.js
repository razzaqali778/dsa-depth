const namespace = 'audits';

export const FETCH_ALL_AUDIT_DATA = `${namespace}/FETCH_ALL_AUDIT_DATA`;
export const SET_ALL_AUDIT_DATA = `${namespace}/SET_ALL_AUDIT_DATA`;

export const SET_SEARCH_TEXT = `${namespace}/SET_SEARCH_TEXT`;
