const namespace = 'filter';

export const SET_FILTER = `${namespace}/SET_FILTER`;
export const CLEAR_FILTER = `${namespace}/CLEAR_FILTER`;
