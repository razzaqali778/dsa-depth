const namespace = 'people';

export const SET_PAPI_DATA = `${namespace}/SET_PAPI_DATA`;
export const SET_PAPI_SEARCH_TEXT = `${namespace}/SET_PAPI_SEARCH_TEXT`;

export const FETCH_PERSON_DATA = `${namespace}/FETCH_PERSON_DATA`;
export const SET_PERSON_DATA = `${namespace}/SET_PERSON_DATA`;
export const UPDATE_PERSON = `${namespace}/UPDATE_PERSON`;
export const CREATE_PERSON = `${namespace}/CREATE_PERSON`;
export const SET_ALL_PEOPLE_DATA = `${namespace}/SET_ALL_PEOPLE_DATA`;

export const TOGGLE_IS_CREATING = `${namespace}/TOGGLE_IS_CREATING`;
export const TOGGLE_IS_EDITING = `${namespace}/TOGGLE_IS_EDITING`;

export const SET_NOT_FOUND_PERSON = `${namespace}/SET_NOT_FOUND_PERSON`;

export const CLEAR_TASK = `${namespace}/CLEAR_TASK`;
