const namespace = 'calendars';

export const GET_ALL_CALENDARS = `${namespace}/GET_ALL_CALENDARS`;
export const SET_ALL_CALENDARS = `${namespace}/SET_ALL_CALENDARS`;
