import { routerMiddleware } from 'connected-react-router';
import createSagaMiddleware from 'redux-saga';
import history from '../../history';
import sagas from '../sagas';

const sagaMiddleware = createSagaMiddleware();
const reduxRouterMiddleware = routerMiddleware(history);

const makeMiddleware = () => {
  const middleware = [sagaMiddleware, reduxRouterMiddleware];

  if (process.env.NODE_ENV !== 'production') {
    const logger = require('redux-logger'); // eslint-disable-line global-require

    return middleware.concat(logger({ collapsed: true }));
  }

  return middleware;
};

export const runSagas = () => sagaMiddleware.run(sagas);

export default makeMiddleware;
