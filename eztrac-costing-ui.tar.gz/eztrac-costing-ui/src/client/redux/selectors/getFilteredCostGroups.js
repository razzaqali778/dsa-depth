import { createSelector } from 'reselect';
import filter from 'lodash/filter';
import { getCostGroupSearchText, getCostGroups } from '.';

const getFilteredCostGroups = createSelector(
  getCostGroups,
  getCostGroupSearchText,
  (costGroups, costGroupSearchText) => {
    const searchText = costGroupSearchText.toLowerCase().trim();

    const criteria = costGroup => (
      costGroup.name.toLowerCase().includes(searchText)
      || costGroup.costCenter.toLowerCase().includes(searchText)
      || costGroup.id.toLowerCase().includes(searchText)
    );

    return filter(costGroups, criteria);
  },
);

export default getFilteredCostGroups;
