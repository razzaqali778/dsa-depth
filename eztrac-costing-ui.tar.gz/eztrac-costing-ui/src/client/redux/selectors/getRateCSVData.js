import { createSelector } from 'reselect';
import { unparse } from 'papaparse';
import map from 'lodash/map';
import { getPeopleForRate } from '.';

export default createSelector(
  getPeopleForRate,
  people => {
    const headers = ['Name', 'CWID', 'Cost Group'];
    const rows = map(people, person => [person.personName, person.personId, person.costGroupName]);

    return unparse([headers, ...rows]);
  },
);
