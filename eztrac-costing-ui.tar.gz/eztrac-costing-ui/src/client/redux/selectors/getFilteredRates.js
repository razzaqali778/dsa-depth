import { createSelector } from 'reselect';
import filter from 'lodash/filter';
import { getRates, getRatesSearchText } from '.';

const getFilteredRates = createSelector(
  getRates,
  getRatesSearchText,
  (ratesList, ratesSearchText) => {
    const searchText = ratesSearchText.toLowerCase().trim();

    const criteria = rate => (
      rate.name.toLowerCase().includes(searchText)
      || rate.id.toLowerCase().includes(searchText)
    );

    return filter(ratesList, criteria);
  },
);

export default getFilteredRates;
