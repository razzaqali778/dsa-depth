import { createSelector } from 'reselect';
import filter from 'lodash/filter';
import moment from 'moment';
import valuesIn from 'lodash/valuesIn';
import { getAuditSearchText, getAudits } from '.';

const getFilteredAudits = createSelector(
  getAudits,
  getAuditSearchText,
  (audits, auditSearchText) => {
    const searchText = auditSearchText.toLowerCase().trim();

    const criteria = audit => (
      audit.entityType.toLowerCase().includes(searchText)
      || audit.entityKey.toLowerCase().includes(searchText)
      || audit.userId.toLowerCase().includes(searchText)
      || valuesIn(audit.entity).map(a => a.toString().toLowerCase().includes(searchText)).includes(true)
      || moment(audit.modifiedTime).format('dddd, MMMM Do YYYY, h:mm:ss a').toString()
        .toLowerCase()
        .includes(searchText)
    );

    return filter(audits, criteria);
  },
);

export default getFilteredAudits;
