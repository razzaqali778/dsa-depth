import { createSelector } from 'reselect';
import { getRates } from '.';

const getRatesFormatted = createSelector(
  getRates,
  rates => rates.filter(r => r.isActive).map(r => ({ label: r.name, value: r.id })),
);

export default getRatesFormatted;
