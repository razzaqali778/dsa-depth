import { createSelector } from 'reselect';
import { getCostGroups } from '.';

const getCostGroupsFormatted = createSelector(
  getCostGroups,
  costGroups => costGroups.filter(c => c.isActive).map(c => ({ label: c.name, value: c.id })),
);

export default getCostGroupsFormatted;
