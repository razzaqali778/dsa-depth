import { createSelector } from 'reselect';
import { getCostGroupForPeople } from './index';

export default createSelector(
  getCostGroupForPeople,
  costGroup => {
    if (costGroup) {
      return `Cost Group ${costGroup.name}`;
    }

    return '';
  },
);
