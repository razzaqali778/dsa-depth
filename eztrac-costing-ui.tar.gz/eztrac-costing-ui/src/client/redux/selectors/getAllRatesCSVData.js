import { createSelector } from 'reselect';
import { unparse } from 'papaparse';
import map from 'lodash/map';
import getFilteredPeople from './getFilteredPeople';

export default createSelector(
  getFilteredPeople,
  people => {
    const headers = ['Rate', 'Name', 'CWID', 'Cost Group'];
    const rows = map(people, person => [person.rateName, person.personName, person.personId, person.costGroupName]);

    return unparse([headers, ...rows]);
  },
);
