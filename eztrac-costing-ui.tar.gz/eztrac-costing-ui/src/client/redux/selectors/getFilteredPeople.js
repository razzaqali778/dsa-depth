import { createSelector } from 'reselect';
import filter from 'lodash/filter';
import includes from 'lodash/includes';
import map from 'lodash/map';
import { getAllPeople } from '.';
import getFilteredCostGroups from './getFilteredCostGroups';
import getFilteredRates from './getFilteredRates';

export default createSelector(
  getFilteredCostGroups,
  getAllPeople,
  getFilteredRates,
  (filteredCostGroups, people, filteredRates) => {
    const costGroupNames = map(filteredCostGroups, costGroup => costGroup.name);
    const rateNames = map(filteredRates, rate => rate.name);
    const filteredPeople = costGroupNames.length > 0
      ? filter(people, person => includes(costGroupNames, person.costGroupName))
      : filter(people, person => includes(rateNames, person.rateName));

    return filteredPeople;
  },
);
