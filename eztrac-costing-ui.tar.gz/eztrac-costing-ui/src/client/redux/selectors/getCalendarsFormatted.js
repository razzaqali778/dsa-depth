import { createSelector } from 'reselect';
import { getCalendars } from '.';

const getCalendarsFormatted = createSelector(
  getCalendars,
  calendar => calendar.map(c => ({ label: c.calendarName, value: c.calendarId })),
);

export default getCalendarsFormatted;
