import { createSelector } from 'reselect';
import { unparse } from 'papaparse';
import map from 'lodash/map';
import getFilteredPeople from './getFilteredPeople';

export default createSelector(
  getFilteredPeople,
  people => {
    const headers = ['Cost Group', 'Name', 'CWID', 'Rate'];
    const rows = map(people, person => [person.costGroupName, person.personName, person.personId, person.rateName]);

    return unparse([headers, ...rows]);
  },
);
