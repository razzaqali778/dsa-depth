import { createSelector } from 'reselect';
import filter from 'lodash/filter';
import includes from 'lodash/includes';
import some from 'lodash/some';
import { getCostGroups, getEngagementSearchText, getEngagements } from '.';

const getFilteredEngagements = (costGroups, engagements, engagementSearchText) => {
  const searchText = engagementSearchText.toLowerCase().trim();
  const filteredCostGroups = filter(costGroups, costGroup => includes(costGroup.name.toLowerCase(), searchText));
  const criteria = engagement => (
    engagement.name.toLowerCase().includes(searchText)
      || some(filteredCostGroups, ({ id }) => id === engagement.costGroupId)
      || engagement.purchaseOrder.toLowerCase().includes(searchText)
      || engagement.id.toLowerCase().includes(searchText)
  );

  return filter(engagements, criteria);
};

export default createSelector(
  getCostGroups,
  getEngagements,
  getEngagementSearchText,
  getFilteredEngagements,
);
