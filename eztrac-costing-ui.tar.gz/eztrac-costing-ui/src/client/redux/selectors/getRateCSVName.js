import { createSelector } from 'reselect';
import { getRateForPeople } from '.';

export default createSelector(
  getRateForPeople,
  rate => {
    if (rate) {
      return `${rate.name} Rate`;
    }

    return '';
  },
);
