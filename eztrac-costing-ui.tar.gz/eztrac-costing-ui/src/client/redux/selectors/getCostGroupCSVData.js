import { createSelector } from 'reselect';
import { unparse } from 'papaparse';
import map from 'lodash/map';
import { getPeopleForCostGroup } from './index';

export default createSelector(
  getPeopleForCostGroup,
  people => {
    const headers = ['Name', 'CWID', 'Rate'];
    const rows = map(people, person => [person.personName, person.personId, person.rateName]);

    return unparse([headers, ...rows]);
  },
);
