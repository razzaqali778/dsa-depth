import makeActions from '@monsantoit/redux-make-actions';
import {
  asyncConstants,
  auditsConstants,
  calendarConstants,
  costGroupsConstants,
  engagementsConstants,
  filterConstants,
  peopleConstants,
  ratesConstants,
} from '../constants';

export const async = makeActions(asyncConstants);
export const audit = makeActions(auditsConstants);
export const calendar = makeActions(calendarConstants);
export const costGroups = makeActions(costGroupsConstants);
export const engagements = makeActions(engagementsConstants);
export const filter = makeActions(filterConstants);
export const rate = makeActions(ratesConstants);
export const people = makeActions(peopleConstants);

export default {
  ...async,
  ...audit,
  ...calendar,
  ...costGroups,
  ...engagements,
  ...filterConstants,
  ...rate,
  ...people,
};
