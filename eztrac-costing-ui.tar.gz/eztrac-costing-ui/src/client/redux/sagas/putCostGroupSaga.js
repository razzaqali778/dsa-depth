import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import { put } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

// TODO: Use common async updating action

export function* putCostGroupSaga({ payload }) {
  yield dispatch(actions.updatingCostGroup(true));

  const result = yield call(put, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: `costGroup/${payload.id}`,
    body: payload,
  });

  if (result.error) {
    yield call(toastr.error, 'Could not update cost-group!');
  } else {
    yield dispatch(actions.updateCostGroup(result));
    yield call(toastr.success, 'Successfully updated cost group.');
  }

  yield dispatch(actions.updatingCostGroup(false));
}

export default function* () {
  yield* takeLatest(
    [
      actions.putUpdateCostGroup().type,
    ],
    putCostGroupSaga,
  );
}
