import makeNetworkCall from '@monsantoit/redux-saga-network';

const wrapMakeNetworkCall = method => {
  const networkCall = makeNetworkCall(method);

  return options => networkCall({
    headers: {
      accept: 'application/json',
      ...phoenix.authHeader ? phoenix.authHeader() : {}, // eslint-disable-line
    },
    ...options,
  });
};

export const get = wrapMakeNetworkCall('get');
export const del = wrapMakeNetworkCall('del');
export const post = wrapMakeNetworkCall('post');
export const put = wrapMakeNetworkCall('put');
