const serviceUrls = window.phoenix.urls.services;

export const serviceBindings = {
  coreServices: serviceUrls['ez-trac-core'],
  qcServices: serviceUrls['ez-trac-qc'],
  costingServices: serviceUrls['ez-trac-costing'],
  suggestionService: serviceUrls['ez-trac-suggestion'],
  eztracTeamsHook: window.phoenix.serviceBindings['ez-trac-teams-hook'],
  profileApi: window.phoenix.serviceBindings['profile-url'],
};
