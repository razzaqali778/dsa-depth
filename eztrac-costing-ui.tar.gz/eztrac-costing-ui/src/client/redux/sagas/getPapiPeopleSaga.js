import { all, call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import filter from 'lodash/filter';
import findIndex from 'lodash/findIndex';
import getOrElse from 'lodash/get';
import isNull from 'lodash/isNull';
import map from 'lodash/map';
import defaultPhoto from '../../helpers/defaultPhoto';
import actions from '../actions';
import { serviceBindings } from './helpers/getServiceBindings';
import { get as getRequest, post as postRequest } from './helpers/network';

const escapeGraphQlString = value => String(value)
  .replace(/\\/g, '\\\\')
  .replace(/"/g, '\\"');

export function* getPapiPeopleSaga({ payload: searchText }) {
  if (searchText !== '' && searchText !== undefined) {
    const escapedSearchText = escapeGraphQlString(searchText);
    const query = `{ searchUsers(query: "${escapedSearchText}") { members { id, legalName { first middle last } employeeType photo } } }`; // eslint-disable-line max-len
    const papiCall = call(postRequest, {
      baseUrl: serviceBindings.profileApi,
      path: '/v3/graphql',
      body: { query },
    });

    const costEngineCall = call(getRequest, {
      baseUrl: serviceBindings.costingServices,
      path: `/v1/people?q=${encodeURIComponent(searchText)}`,
    });

    const result = yield all([papiCall, costEngineCall]);
    const error = findIndex(result, r => isNull(r) || r.hasOwnProperty('error')) > -1;

    if (error) {
      yield call(toastr.error, 'Could not connect to PAPI!');
    } else {
      const [graphQLResult, costEngineResult] = result;

      const papiResult = getOrElse(graphQLResult, 'data.searchUsers.members', []);

      const filteredPapiPeople = filter(papiResult, ({ employeeType }) => employeeType !== 'External' && employeeType !== 'Mechanical');

      const mappedPapiResult = map(filteredPapiPeople, ({
        photo,
        id,
        legalName,
        employeeType,
      }) => {
        const photoUrl = photo || defaultPhoto;

        const { first: firstName, last: lastName, middle: middleName } = legalName;

        const label = middleName
          ? `${lastName}, ${firstName} ${middleName} (${id})`
          : `${lastName}, ${firstName} (${id})`;
        const personName = middleName
          ? `${lastName}, ${firstName} ${middleName}`
          : `${lastName}, ${firstName}`;

        return {
          value: id,
          label,
          personName,
          employeeType,
          photo: photoUrl,
        };
      });

      const filteredCostEngineResults = filter(costEngineResult, c => findIndex(mappedPapiResult, p => p.value === c.personId) === -1);
      const mappedCostEngineResult = map(filteredCostEngineResults, r => ({
        value: r.personId,
        label: `${r.personName} (${r.personId})`,
        personName: r.personName,
        employeeType: r.isEmployee ? 'Employee' : 'Contractor',
        photo: defaultPhoto,
      }));

      yield dispatch(actions.setPapiData(mappedPapiResult.concat(mappedCostEngineResult)));
    }
  }

  return undefined;
}

export default function* () {
  yield* takeLatest(
    [
      actions.setPapiSearchText().type,
    ],
    getPapiPeopleSaga,
  );
}
