import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import { post } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* postRateSaga({ payload }) {
  yield dispatch(actions.setUpdating(true));

  const result = yield call(post, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: 'rates',
    body: { ...payload, modifiedBy: 'Will-Be-Replaced-By-Endpoint' },
  });

  if (result.error) {
    yield call(toastr.error, 'Could not save rate!');
  } else {
    yield dispatch(actions.addNewRate(result));
    yield call(toastr.success, 'Successfully created new rate.');
  }
  yield dispatch(actions.setUpdating(false));
}

export default function* () {
  yield* takeLatest(
    [
      actions.postNewRate().type,
    ],
    postRateSaga,
  );
}
