import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import sortBy from 'lodash/sortBy';
import { FETCH_RATE_PEOPLE } from '../constants/ratesConstants';
import { get } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* getPeopleByRateIdSaga({ type, payload }) {
  const result = yield call(get, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: `people?rateId=${payload.id}&isActive=true`,
  });

  if (result.error) {
    yield call(toastr.error, `Could not retrieve people with rate ${payload.id}!`);
  } else {
    const rateAndPeople = {
      people: sortBy(result, 'personName'),
      rate: payload,
    };

    if (type === FETCH_RATE_PEOPLE) {
      yield dispatch(actions.viewPeopleWithRate(rateAndPeople));
    } else {
      yield dispatch(actions.setPeopleWithRateId(rateAndPeople));
    }
  }
}

export default function* () {
  yield* takeLatest(
    [
      actions.fetchPeopleByRateId().type,
      actions.fetchRatePeople().type,
    ],
    getPeopleByRateIdSaga,
  );
}
