import { call, put as dispatch } from 'redux-saga/effects';
import { push as setPath } from 'connected-react-router';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import omit from 'lodash/omit';
import queryString from 'query-string';
import actions from '../actions';
import { serviceBindings } from './helpers/getServiceBindings';
import { put } from './helpers/network';

export function* putPersonSaga({ payload }) {
  const { photo } = payload;

  const result = yield call(put, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: 'person',
    body: {
      ...omit(payload, ['photo', 'clearTask']),
      modifiedBy: 'Will-Be-Replaced-By-Endpoint',
    },
  });

  if (result.error) {
    yield call(toastr.error, `Could not update ${payload.personId}!`);
  } else {
    yield dispatch(actions.setPersonData({ ...result, photo }));
    yield dispatch(actions.toggleIsEditing(false));

    const queryParams = queryString.parse(window.location.search);

    if (queryParams.task === 'true') {
      yield dispatch(actions.clearTask(payload.personId));
    }

    const search = queryString.stringify({
      ...queryParams,
      edit: undefined,
      task: undefined,
    });

    yield dispatch(
      setPath({
        pathname: '/people',
        search: search ? `?${search}` : '',
      }),
    );

    yield call(toastr.success, `Successfully updated ${payload.personId}.`);
  }
}

export default function* () {
  yield* takeLatest(
    [actions.updatePerson().type, actions.createPerson().type],
    putPersonSaga,
  );
}
