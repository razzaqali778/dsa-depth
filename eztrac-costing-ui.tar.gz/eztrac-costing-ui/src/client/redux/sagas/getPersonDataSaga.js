import {
  call, put as dispatch, select, take,
} from 'redux-saga/effects';
import { push as setPath } from 'connected-react-router';
import { takeLatest } from 'redux-saga';
import isEmpty from 'lodash/isEmpty';
import isUndefined from 'lodash/isUndefined';
import queryString from 'query-string';
import { get } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';
import getCostGroupsFormatted from '../selectors/getCostGroupsFormatted';
import getRatesFormatted from '../selectors/getRatesFormatted';

export function* getPersonDataSaga({ payload }) {
  if (isEmpty(yield select(getCostGroupsFormatted))) {
    yield take(actions.setAllCostGroupData().type);
  }

  if (isEmpty(yield select(getRatesFormatted))) {
    yield take(actions.setAllRateData().type);
  }

  const result = yield call(get, {
    baseUrl: serviceBindings.costingServices,
    path: `/v1/person/${payload.value}`,
  });

  if (result.error) {
    const errorObj = {
      value: true,
      personName: payload.personName,
      personId: payload.value,
      employeeType: payload.employeeType,
      photo: payload.photo,
    };

    yield dispatch(actions.setNotFoundPerson(errorObj));
  } else {
    yield dispatch(
      actions.setPersonData({
        ...result,
        photo: payload.photo,
      }),
    );

    if (!isUndefined(payload.edit)) {
      yield dispatch(actions.toggleIsEditing(payload.edit));
    }
  }

  const queryParams = queryString.parse(window.location.search);
  const search = queryString.stringify({
    ...queryParams,
    personId: payload.value,
  });

  yield dispatch(
    setPath({
      pathname: '/people',
      search: search ? `?${search}` : '',
    }),
  );
}

export default function* () {
  yield* takeLatest([actions.fetchPersonData().type], getPersonDataSaga);
}
