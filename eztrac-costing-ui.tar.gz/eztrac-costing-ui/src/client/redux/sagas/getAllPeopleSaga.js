import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import sortBy from 'lodash/sortBy';
import { SET_DOWNLOAD_ALL_COST_GROUPS_CLICKED } from '../constants/costGroupsConstants';
import { SET_DOWNLOAD_ALL_RATES_CLICKED } from '../constants/ratesConstants';
import { get } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* getAllPeopleSaga({ type }) {
  const result = yield call(get, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: 'people?isActive=true',
  });

  if (result.error) {
    yield call(toastr.error, 'Could not retrieve people!');
  } else {
    const sortedResult = (type === SET_DOWNLOAD_ALL_COST_GROUPS_CLICKED)
      ? sortBy(sortBy(result, 'personName'), 'costGroupName')
      : sortBy(sortBy(result, 'personName'), 'rateName');

    yield dispatch(actions.setAllPeopleData(sortedResult));

    if (type === SET_DOWNLOAD_ALL_COST_GROUPS_CLICKED) {
      yield dispatch(actions.setAllPeopleForCostGroupsCsv());
    } else if (type === SET_DOWNLOAD_ALL_RATES_CLICKED) {
      yield dispatch(actions.setAllPeopleForRatesCsv());
    }
  }
}

export default function* () {
  yield* takeLatest(
    [
      actions.setDownloadAllCostGroupsClicked().type,
      actions.setDownloadAllRatesClicked().type,
    ],
    getAllPeopleSaga,
  );
}
