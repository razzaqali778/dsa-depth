import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import { put } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

// TODO: Use common async updating action

export function* putEngagementSaga({ payload }) {
  yield dispatch(actions.updatingEngagement(true));

  const result = yield call(put, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: `engagement/${payload.id}`,
    body: payload,
  });

  if (result.error) {
    yield call(toastr.error, 'Could not update engagement!');
  } else {
    yield dispatch(actions.updateEngagement(result));
    yield call(toastr.success, 'Successfully updated engagement.');
  }

  yield dispatch(actions.updatingEngagement(false));
}

export default function* () {
  yield* takeLatest(
    [
      actions.putUpdateEngagement().type,
    ],
    putEngagementSaga,
  );
}
