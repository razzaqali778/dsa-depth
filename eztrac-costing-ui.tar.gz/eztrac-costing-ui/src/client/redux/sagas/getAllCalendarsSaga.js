import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import sortBy from 'lodash/sortBy';
import { get } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* getAllCalendarsSaga() {
  const result = yield call(get, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: 'calendars',
  });

  if (result.error) {
    yield call(toastr.error, 'Could not retrieve calendars!');
  } else {
    const sortedResult = sortBy(result, 'calendarName');

    yield dispatch(actions.setAllCalendars(sortedResult));
  }
}

export default function* () {
  yield* takeLatest(
    [
      actions.getAllCalendars().type,
    ],
    getAllCalendarsSaga,
  );
}
