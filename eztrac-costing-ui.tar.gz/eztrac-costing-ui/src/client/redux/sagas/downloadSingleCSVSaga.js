import { select } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { SET_DOWNLOAD_RATE_CLICKED } from '../constants/ratesConstants';
import actions from '../actions';
import getCostGroupCSVData from '../selectors/getCostGroupCSVData';
import getCostGroupCSVName from '../selectors/getCostGroupCSVName';
import getRateCSVData from '../selectors/getRateCSVData';
import getRateCSVName from '../selectors/getRateCSVName';

export function* downloadSingleCSVSaga({ type }) {
  const state = yield select();
  const csvData = (type === SET_DOWNLOAD_RATE_CLICKED) ? getRateCSVData(state) : getCostGroupCSVData(state);
  const csvName = (type === SET_DOWNLOAD_RATE_CLICKED) ? getRateCSVName(state) : getCostGroupCSVName(state);
  const data = new Blob([csvData], { type: 'text/csv' }); // eslint-disable-line no-undef
  const url = URL.createObjectURL(data); // eslint-disable-line no-undef

  const link = document.createElement('a');

  link.setAttribute('href', url);
  link.setAttribute('download', `${csvName}.csv`);
  link.click();
}

export default function* () {
  yield* takeLatest(
    [
      actions.setDownloadRateClicked().type,
      actions.setDownloadCostGroupClicked().type,
    ],
    downloadSingleCSVSaga,
  );
}
