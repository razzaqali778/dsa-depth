import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import { post } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

const sanitizeEngagementPayload = (engagement) => {
  const sanitizedName = engagement.name.replace(/\s+/g, ' ');

  return {
    ...engagement,
    name: sanitizedName,
  };
};

export function* postEngagementSaga({ payload }) {
  yield dispatch(actions.setUpdating(true));

  const result = yield call(post, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: 'engagements',
    body: {
      ...sanitizeEngagementPayload(payload),
      modifiedBy: 'Will-Be-Replaced-By-Endpoint',
    },
  });

  if (result.error) {
    yield call(toastr.error, 'Could not save engagement!');
  } else {
    yield dispatch(actions.addEngagement(result));
    yield call(toastr.success, 'Successfully created engagement.');
  }

  yield dispatch(actions.setUpdating(false));
}

export default function* () {
  yield* takeLatest(
    [
      actions.postEngagement().type,
    ],
    postEngagementSaga,
  );
}
