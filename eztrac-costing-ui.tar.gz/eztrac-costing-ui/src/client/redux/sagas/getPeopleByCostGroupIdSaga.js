import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import sortBy from 'lodash/sortBy';
import { FETCH_COST_GROUP_PEOPLE } from '../constants/costGroupsConstants';
import { get } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* getPeopleByCostGroupIdSaga({ type, payload }) {
  const result = yield call(get, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: `people?costGroupId=${payload.id}&isActive=true`,
  });

  if (result.error) {
    yield call(toastr.error, `Could not retrieve people with cost-group ${payload.id}!`);
  } else {
    const costGroupAndPeople = {
      people: sortBy(result, 'personName'),
      costGroup: payload,
    };

    if (type === FETCH_COST_GROUP_PEOPLE) {
      yield dispatch(actions.viewPeopleWithCostGroup(costGroupAndPeople));
    } else {
      yield dispatch(actions.setPeopleWithCostGroupId(costGroupAndPeople));
    }
  }
}

export default function* () {
  yield* takeLatest(
    [
      actions.fetchPeopleByCostGroupId().type,
      actions.fetchCostGroupPeople().type,
    ],
    getPeopleByCostGroupIdSaga,
  );
}
