import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import { post } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* postCostGroupSaga({ payload }) {
  yield dispatch(actions.setUpdating(true));

  const result = yield call(post, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: 'costGroups',
    body: { ...payload, modifiedBy: 'Will-Be-Replaced-By-Endpoint' },
  });

  if (result.error) {
    yield call(toastr.error, 'Could not save cost-group!');
  } else {
    yield dispatch(actions.addCostGroup(result));
    yield call(toastr.success, 'Successfully created cost-group.');
  }

  yield dispatch(actions.setUpdating(false));
}

export default function* () {
  yield* takeLatest(
    [
      actions.postCostGroup().type,
    ],
    postCostGroupSaga,
  );
}
