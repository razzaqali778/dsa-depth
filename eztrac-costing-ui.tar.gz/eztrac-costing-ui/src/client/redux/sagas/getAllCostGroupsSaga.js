import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import sortBy from 'lodash/sortBy';
import { get } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* getAllCostGroupsSaga() {
  const result = yield call(get, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: 'costGroups',
  });

  if (result.error) {
    yield call(toastr.error, 'Could not retrieve cost-groups!');
  } else {
    const sortedResult = sortBy(result, 'name');

    yield dispatch(actions.setAllCostGroupData(sortedResult));
  }
}

export default function* () {
  yield* takeLatest(
    [
      actions.fetchAllCostGroupData().type,
      actions.fetchAllEngagementsData().type,
    ],
    getAllCostGroupsSaga,
  );
}
