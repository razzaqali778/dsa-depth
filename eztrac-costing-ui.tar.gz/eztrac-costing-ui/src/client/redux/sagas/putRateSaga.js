import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import { put } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* putRateSaga({ payload }) {
  yield dispatch(actions.setUpdating(true));

  const result = yield call(put, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: `rate/${payload.id}`,
    body: payload,
  });

  if (result.error) {
    yield call(toastr.error, 'Could not update rate!');
  } else {
    yield dispatch(actions.updateRate(result));
    yield call(toastr.success, 'Successfully updated rate.');
  }

  yield dispatch(actions.setUpdating(false));
}

export default function* () {
  yield* takeLatest(
    [
      actions.putUpdateRate().type,
    ],
    putRateSaga,
  );
}
