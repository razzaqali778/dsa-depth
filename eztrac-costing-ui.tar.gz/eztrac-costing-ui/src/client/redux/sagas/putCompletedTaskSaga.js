import { call, put as dispatch } from 'redux-saga/effects';
import { push as setPath } from 'connected-react-router';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import getOrElse from 'lodash/get';
import queryString from 'query-string';
import actions from '../actions';
import { serviceBindings } from './helpers/getServiceBindings';
import { post, put } from './helpers/network';

export function* putCompletedTaskSaga({ payload }) {
  const query = '{ getCurrentUser { legalName { full } } }';
  const user = yield call(post, {
    baseUrl: serviceBindings.profileApi,
    path: '/v3/graphql',
    body: { query },
  });

  const userFullName = getOrElse(
    user,
    'data.getCurrentUser.legalName.full',
    'Unknown user',
  );
  const completionObject = {
    complete: true,
    completedBy: userFullName,
    tag: 'Ez Trac',
    tagKey: payload,
    result: 'Task Completed.',
  };

  const result = yield call(put, {
    baseUrl: '/ez-trac-costing/messaging-api',
    path: '/v5/tasks/complete',
    body: completionObject,
  });

  if (result.error) {
    if (result.error.statusCode !== 404) {
      yield call(toastr.error, `Could not complete task for ${payload}!`);
    }
  } else {
    const queryParams = queryString.parse(window.location.search);
    const search = queryString.stringify({ ...queryParams, task: undefined });

    yield dispatch(
      setPath({
        pathname: '/people',
        search: search ? `?${search}` : '',
      }),
    );
    yield call(toastr.success, `Successfully completed task for ${payload}.`);
  }
}

export default function* () {
  yield* takeLatest([actions.clearTask().type], putCompletedTaskSaga);
}
