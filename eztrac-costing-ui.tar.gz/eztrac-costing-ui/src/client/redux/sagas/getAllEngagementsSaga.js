import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import sortBy from 'lodash/sortBy';
import { get } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* getAllEngagementsSaga() {
  yield dispatch(actions.setUpdating(true));

  const result = yield call(get, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: 'engagements',
  });

  if (result.error) {
    yield call(toastr.error, 'Could not retrieve engagements!');
  } else {
    const sortedResult = sortBy(result, 'name');

    yield dispatch(actions.setAllEngagementsData(sortedResult));
  }

  yield dispatch(actions.setUpdating(false));
}

export default function* () {
  yield* takeLatest(
    [
      actions.fetchAllEngagementsData().type,
    ],
    getAllEngagementsSaga,
  );
}
