import { select } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { SET_ALL_PEOPLE_FOR_COST_GROUPS_CSV } from '../constants/costGroupsConstants';
import actions from '../actions';
import getAllCostGroupsCSVData from '../selectors/getAllCostGroupsCSVData';
import getAllRatesCSVData from '../selectors/getAllRatesCSVData';

export function* downloadPeopleDataSaga({ type }) {
  const state = yield select();
  const csvData = (type === SET_ALL_PEOPLE_FOR_COST_GROUPS_CSV)
    ? getAllCostGroupsCSVData(state)
    : getAllRatesCSVData(state);

  const csvName = (type === SET_ALL_PEOPLE_FOR_COST_GROUPS_CSV)
    ? 'Cost_Groups.csv'
    : 'Rates.csv';

  const data = new Blob([csvData], { type: 'text/csv' }); // eslint-disable-line no-undef
  const url = URL.createObjectURL(data); // eslint-disable-line no-undef

  const link = document.createElement('a');

  link.setAttribute('href', url);
  link.setAttribute('download', csvName);
  link.click();
}

export default function* () {
  yield* takeLatest(
    [
      actions.setAllPeopleForCostGroupsCsv().type,
      actions.setAllPeopleForRatesCsv().type,
    ],
    downloadPeopleDataSaga,
  );
}
