import { call, put as dispatch } from 'redux-saga/effects';
import { takeLatest } from 'redux-saga';
import { toastr } from 'react-redux-toastr';
import { get } from './helpers/network';
import { serviceBindings } from './helpers/getServiceBindings';
import actions from '../actions';

export function* getAllAuditsSaga() {
  const result = yield call(get, {
    baseUrl: `${serviceBindings.costingServices}/v1/`,
    path: 'audits',
  });

  if (result.error) {
    yield call(toastr.error, 'Could not retrieve audits!');
  } else {
    yield dispatch(actions.setAllAuditData(result));
  }
}

export default function* () {
  yield* takeLatest(
    [
      actions.fetchAllAuditData().type,
    ],
    getAllAuditsSaga,
  );
}
