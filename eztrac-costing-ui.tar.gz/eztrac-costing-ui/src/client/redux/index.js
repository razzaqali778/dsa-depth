import { applyMiddleware, compose, createStore } from 'redux';
import { loadState } from '../localStorage';
import history from '../history';
import makeMiddleware, { runSagas } from './middleware';
import makeReducers from './reducers';

const persistedState = loadState();
const makeStore = () => {
  const store = createStore(
    makeReducers(history),
    persistedState,
    compose(
      applyMiddleware(...makeMiddleware()),
      window.__REDUX_DEVTOOLS_EXTENSION__
        ? window.__REDUX_DEVTOOLS_EXTENSION__()
        : (f) => f,
    ),
  );

  runSagas();

  return store;
};

export default makeStore;
