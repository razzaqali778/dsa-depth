import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';
import AppContainer from '../containers/AppContainer';
import AuditContainer from '../containers/AuditContainer';
import CostGroupContainer from '../containers/CostGroupContainer';
import EngagementsContainer from '../containers/EngagementsContainer';
import PeopleContainer from '../containers/PeopleContainer';
import RatesContainer from '../containers/RatesContainer';

function Routes() {
  return (
    <AppContainer>
      <Switch>
        <Route exact path="/rates" component={RatesContainer} />
        <Route exact path="/people" component={PeopleContainer} />
        <Route exact path="/cost-groups" component={CostGroupContainer} />
        <Route exact path="/audits" component={AuditContainer} />
        <Route exact path="/engagements" component={EngagementsContainer} />
        <Redirect from="/" to="/rates" />
      </Switch>
    </AppContainer>
  );
}

export default Routes;
