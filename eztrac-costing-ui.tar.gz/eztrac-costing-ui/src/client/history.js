import { createBrowserHistory } from 'history';

const history = createBrowserHistory({ basename: '/ez-trac-costing' });

export default history;
