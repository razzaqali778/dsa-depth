import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import map from 'lodash/map';
import getFilteredAudits from '../redux/selectors/getFilteredAudits';
import AuditItem from '../components/audit/AuditItem';
import { audit as AuditActions } from '../redux/actions';
import { FETCH_ALL_AUDIT_DATA } from '../redux/constants/auditsConstants';

function AuditContainer({
  data,
  dispatch,
  setSearchText,
}) {
  useEffect(() => {
    dispatch({ type: FETCH_ALL_AUDIT_DATA });
  }, [dispatch]);
  const mapAudits = audits => map(audits, (audit, index) => (
    <AuditItem
      key={`${audit.entityType}-${audit.entityKey}-${audit.modifiedTime}-${index}`}
      item={audit}
    />
  ));

  return (
    <div className="container">
      <div className="row audit-header-row">
        <h1 className="col-md-6 audit-header">Audits</h1>
        <div className="col-md-6 audit-search">
          <input
            className="form-control"
            onChange={({ target }) => setSearchText(target.value)}
            placeholder="Search..."
            type="text"
          />
        </div>
      </div>
      <table className="table table-striped table-responsive">
        <thead>
          <tr>
            <th>Edited Information</th>
            <th>Edited To</th>
          </tr>
        </thead>
        <tbody>
          {mapAudits(data)}
        </tbody>
      </table>
    </div>
  );
}

AuditContainer.propTypes = {
  data: PropTypes.array.isRequired,
  setSearchText: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  data: getFilteredAudits(state),
});

const mapDispatchToProps = dispatch => ({
  ...bindActionCreators(AuditActions, dispatch),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(AuditContainer);
