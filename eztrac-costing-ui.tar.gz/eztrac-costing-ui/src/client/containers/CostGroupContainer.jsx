import { Modal } from 'react-bootstrap';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import {
  costGroups as costGroupActions,
  filter as filterActions,
} from '../redux/actions';
import CostGroupItem from '../components/costGroups/CostGroupItem';
import EditCostGroupItem from '../components/costGroups/EditCostGroupItem';
import FilterBar from '../components/FilterBar';
import downloadMultiplePeopleCSV from '../components/costGroups/DownloadMultiplePeopleCSV';
import filter from '../helpers/filter';
import getFilteredCostGroups from '../redux/selectors/getFilteredCostGroups';
import renderPeoplePopUp from '../components/PeopleModal';
import { FETCH_ALL_COST_GROUP_DATA } from '../redux/constants/costGroupsConstants';

function CostGroupContainer({
  activeFilter,
  affectedPeoplePopup,
  cancelAffectedPeoplePopup,
  cancelCostGroupPeoplePopup,
  costGroupPeoplePopup,
  data,
  dispatch,
  isCreating,
  isUpdating,
  postCostGroup,
  putUpdateCostGroup,
  setDownloadAllCostGroupsClicked,
  setDownloadCostGroupClicked,
  setFilter,
  setSearchText,
  toggleIsCreating,
  updateCostGroup,
}) {
  useEffect(() => {
    dispatch({ type: FETCH_ALL_COST_GROUP_DATA });
  }, [dispatch]);
  const saveCostGroup = costGroup => {
    if (costGroup) {
      postCostGroup(costGroup);
    } else {
      toggleIsCreating(false);
    }
  };

  const renderCreateCostGroupSpace = () => {
    if (isUpdating) {
      return (
        <div className="well">
          <div className="velocity-spinner" />
        </div>
      );
    }

    if (isCreating) {
      const newCostGroup = {
        name: '', costCenter: '', isActive: true, excludeFromDistributions: false,
      };

      return (<EditCostGroupItem costGroup={newCostGroup} updateCostGroupHandler={saveCostGroup} />);
    }

    return null;
  };

  const renderNewCostGroupBtn = () => {
    if (isCreating) {
      return (
        <button className="btn btn-success pull-right" disabled>
          <i className="fa fa-plus" />
        </button>
      );
    }

    return (
      <button
        className="btn btn-success pull-right"
        onClick={() => toggleIsCreating(true)}
        title="Add Cost Group"
      >
        <i className="fa fa-plus" />
      </button>
    );
  };

  const mapCostGroups = costGroups => {
    const filteredCostGroups = filter(costGroups, activeFilter);

    return filteredCostGroups
      .sort((x, y) => x.name.localeCompare(y.name))
      .map((costGroup, index) => (
        <CostGroupItem
          costGroup={costGroup}
          key={index}
          putUpdateCostGroup={putUpdateCostGroup}
          updateCostGroup={updateCostGroup}
        />
      ));
  };

  const updateFromPopup = () => {
    if (affectedPeoplePopup.costGroup) {
      putUpdateCostGroup(affectedPeoplePopup.costGroup);
    } else {
      toggleIsCreating(false);
    }
  };

  const renderPopUp = () => {
    const affectedPeople = affectedPeoplePopup.people.length;

    return (
      <Modal show={affectedPeoplePopup.showPopup}>
        <Modal.Header closeButton onClick={cancelAffectedPeoplePopup}>
          <Modal.Title>Affected People</Modal.Title>
        </Modal.Header>
        <Modal.Body className="affectedPeoplePopupModal">
          <p>
            This will affect
            {affectedPeople}
            {' '}
            people.
          </p>
        </Modal.Body>
        <Modal.Footer>
          <button className="btn btn-default" onClick={cancelAffectedPeoplePopup}>Cancel</button>
          <button className="btn btn-primary" onClick={updateFromPopup}>Update</button>
        </Modal.Footer>
      </Modal>
    );
  };

  return (
    <div className="container">
      <h1>Cost Groups</h1>
      <div className="filterBar">
        <div className="col-md-9 searchBar">
          <div className="col-md-1 searchBar dropdown">
            <FilterBar setFilter={setFilter} />
          </div>
          <div className="col-md-8 searchBar">
            <input
              className="form-control"
              onChange={({ target }) => setSearchText(target.value)}
              placeholder="Search by Name, Cost Center, or ID..."
              type="text"
            />
          </div>
        </div>
        <div className="actionButtonsWrapper">
          <div className="multipleDownloadButton">
            {downloadMultiplePeopleCSV(setDownloadAllCostGroupsClicked)}
          </div>
          {renderNewCostGroupBtn()}
        </div>
      </div>
      {renderCreateCostGroupSpace()}
      {renderPopUp()}
      {renderPeoplePopUp(costGroupPeoplePopup, 'Rate', cancelCostGroupPeoplePopup, setDownloadCostGroupClicked)}
      <div className="cost-group-list">
        {mapCostGroups(data, updateCostGroup)}
      </div>

    </div>
  );
}

CostGroupContainer.propTypes = {
  activeFilter: PropTypes.string.isRequired,
  affectedPeoplePopup: PropTypes.object.isRequired,
  cancelAffectedPeoplePopup: PropTypes.func.isRequired,
  cancelCostGroupPeoplePopup: PropTypes.func.isRequired,
  costGroupPeoplePopup: PropTypes.object.isRequired,
  data: PropTypes.array.isRequired,
  isCreating: PropTypes.bool.isRequired,
  isUpdating: PropTypes.bool.isRequired,
  postCostGroup: PropTypes.func.isRequired,
  putUpdateCostGroup: PropTypes.func.isRequired,
  setDownloadAllCostGroupsClicked: PropTypes.func.isRequired,
  setDownloadCostGroupClicked: PropTypes.func.isRequired,
  setFilter: PropTypes.func.isRequired,
  setSearchText: PropTypes.func.isRequired,
  toggleIsCreating: PropTypes.func.isRequired,
  updateCostGroup: PropTypes.func.isRequired,
  viewPeopleWithCostGroup: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  activeFilter: state.filter.activeFilter,
  isUpdating: state.async.isUpdating,
  isCreating: state.costGroups.isCreating,
  affectedPeoplePopup: state.costGroups.affectedPeoplePopup,
  costGroupPeoplePopup: state.costGroups.costGroupPeoplePopup,
  data: getFilteredCostGroups(state),
});

const mapDispatchToProps = dispatch => ({
  ...bindActionCreators({ ...costGroupActions, ...filterActions }, dispatch),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(CostGroupContainer);
