import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import Select from 'react-select';
import debounce from 'lodash/debounce';
import get from 'lodash/get';
import isEmpty from 'lodash/isEmpty';
import queryString from 'query-string';
import {
  people as peopleActions,
} from '../redux/actions';
import CreatePerson from '../components/people/CreatePerson';
import Person from '../components/people/Person';
import PersonNotFound from '../components/people/PersonNotFound';
import getCostGroupsFormatted from '../redux/selectors/getCostGroupsFormatted';
import getRatesFormatted from '../redux/selectors/getRatesFormatted';
import defaultPhoto from '../helpers/defaultPhoto';
import { FETCH_ALL_COST_GROUP_DATA } from '../redux/constants/costGroupsConstants';
import { FETCH_ALL_RATE_DATA } from '../redux/constants/ratesConstants';

function PeopleContainer({
  costCenters,
  createPerson,
  dispatch,
  fetchPersonData,
  isCreating,
  papiData,
  person,
  personNotFound,
  rates,
  setPapiSearchText,
  toggleIsCreating,
}) {
  useEffect(() => {
    dispatch({ type: FETCH_ALL_RATE_DATA });
    dispatch({ type: FETCH_ALL_COST_GROUP_DATA });

    const queryParams = queryString.parse(window.location.search);
    const personId = get(queryParams, 'personId', false);
    const edit = get(queryParams, 'edit', false) === 'true';

    if (personId) {
      // Action creators wrap args as `payload`; pass the person option shape directly
      // (same as Select onChange), not nested under another `payload`.
      fetchPersonData({
        value: personId.toUpperCase(),
        photo: defaultPhoto,
        edit,
      });
    }
  }, [dispatch, fetchPersonData]);

  const displayPerson = () => {
    if (!isEmpty(person) && !personNotFound.value && !isCreating) {
      return <Person person={person} />;
    } if (isCreating) {
      const newPerson = {
        personId: personNotFound.personId,
        personName: personNotFound.personName,
        isEmployee: personNotFound.employeeType === 'Employee',
        photo: personNotFound.photo,
      };

      return (
        <CreatePerson
          cancelCreating={() => toggleIsCreating(false)}
          costCenters={costCenters}
          createPerson={createPerson}
          person={newPerson}
          rates={rates}
        />
      );
    } if (!isCreating && personNotFound.value) {
      return (
        <PersonNotFound
          personNotFound={personNotFound}
          toggleIsCreating={toggleIsCreating}
        />
      );
    }

    return undefined;
  };

  return (
    <div className="container">
      <div className="row">
        <h1>People</h1>
        <Select
          className="person-search"
          clearable
          multi={false}
          onChange={fetchPersonData}
          onInputChange={debounce(setPapiSearchText, 200)}
          options={papiData}
          placeholder="Search for person..."
        />
      </div>
      <div className="row">
        {displayPerson()}
      </div>
    </div>
  );
}

PeopleContainer.propTypes = {
  costCenters: PropTypes.array.isRequired,
  createPerson: PropTypes.func.isRequired,
  dispatch: PropTypes.func.isRequired,
  fetchPersonData: PropTypes.func.isRequired,
  isCreating: PropTypes.bool.isRequired,
  papiData: PropTypes.array.isRequired,
  person: PropTypes.object.isRequired,
  personNotFound: PropTypes.object.isRequired,
  rates: PropTypes.array.isRequired,
  setPapiSearchText: PropTypes.func.isRequired,
  toggleIsCreating: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  costCenters: getCostGroupsFormatted(state),
  isCreating: state.people.isCreating,
  papiData: state.people.papiData,
  person: state.people.person,
  personNotFound: state.people.personNotFound,
  rates: getRatesFormatted(state),
});

const mapDispatchToProps = dispatch => ({
  ...bindActionCreators(peopleActions, dispatch),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(PeopleContainer);
