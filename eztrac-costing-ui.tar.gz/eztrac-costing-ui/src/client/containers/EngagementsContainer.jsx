import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import {
  engagements as engagementActions,
  filter as filterActions,
} from '../redux/actions';
import EditEngagementItem from '../components/engagements/EditEngagementItem';
import EngagementItem from '../components/engagements/EngagementItem';
import FilterBar from '../components/FilterBar';
import SaveToXlsxButton from './SaveToXlsxButton';
import filter from '../helpers/filter';
import getCostGroupsFormatted from '../redux/selectors/getCostGroupsFormatted';
import getFilteredEngagements from '../redux/selectors/getFilteredEngagements';
import { FETCH_ALL_ENGAGEMENTS_DATA } from '../redux/constants/engagementsConstants';

function EngagementsContainer({
  activeFilter,
  costGroups,
  data,
  dispatch,
  isCreating,
  isUpdating,
  postEngagement,
  setFilter,
  setSearchText,
  toggleIsCreating,
}) {
  useEffect(() => {
    dispatch({ type: FETCH_ALL_ENGAGEMENTS_DATA });
  }, [dispatch]);
  const filteredEngagements = filter(data, activeFilter).sort((x, y) => x.name.localeCompare(y.name));

  const mapEngagements = engagements => engagements
    .map((engagement, index) => (
      <EngagementItem
        costGroups={costGroups}
        engagement={engagement}
        key={index}
      />
    ));

  const renderNewEngagementBtn = () => {
    if (isCreating) {
      return (
        <button className="btn btn-success pull-right" disabled>
          <i className="fa fa-plus" />
        </button>
      );
    }

    return (
      <button
        className="btn btn-success pull-right"
        onClick={() => toggleIsCreating(true)}
        title="Add Engagement"
      >
        <i className="fa fa-plus" />
      </button>
    );
  };

  const renderDownloadBtn = excelData => <SaveToXlsxButton csvData={excelData} fileName="Engagements" />;

  const saveEngagement = engagement => {
    if (engagement) {
      postEngagement(engagement);
    } else {
      toggleIsCreating(false);
    }
  };

  const renderCreateCostGroupSpace = () => {
    if (isUpdating) {
      return (
        <div className="well">
          <div className="velocity-spinner" />
        </div>
      );
    }

    if (isCreating) {
      const newEngagement = {
        name: '', costGroupId: '', isActive: true, purchaseOrder: '',
      };

      return (
        <EditEngagementItem
          costGroups={costGroups}
          engagement={newEngagement}
          updateEngagementHandler={saveEngagement}
        />
      );
    }

    return null;
  };

  return (
    <div className="container">
      <h1>Engagements</h1>
      <div className="filterBar">
        <div className="col-md-9 searchBar">
          <div className="col-md-1 searchBar dropdown">
            <FilterBar setFilter={setFilter} />
          </div>
          <div className="col-md-8 searchBar">
            <input
              className="form-control"
              onChange={({ target }) => setSearchText(target.value)}
              placeholder="Search by Name, Cost Group, ID, or Purchase Order..."
              type="text"
            />
          </div>
        </div>
        <div className="actionButtonsWrapper">
          {renderDownloadBtn(filteredEngagements)}
          {renderNewEngagementBtn()}
        </div>
      </div>
      {renderCreateCostGroupSpace()}
      <div className="cost-group-list">
        {mapEngagements(filteredEngagements)}
      </div>
    </div>
  );
}

EngagementsContainer.propTypes = {
  activeFilter: PropTypes.string.isRequired,
  costGroups: PropTypes.array.isRequired,
  data: PropTypes.array.isRequired,
  isCreating: PropTypes.bool.isRequired,
  isUpdating: PropTypes.bool.isRequired,
  postEngagement: PropTypes.func.isRequired,
  setFilter: PropTypes.func.isRequired,
  setSearchText: PropTypes.func.isRequired,
  toggleIsCreating: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  activeFilter: state.filter.activeFilter,
  isUpdating: state.async.isUpdating,
  isCreating: state.engagements.isCreating,
  data: getFilteredEngagements(state),
  costGroups: getCostGroupsFormatted(state),
});

const mapDispatchToProps = dispatch => ({
  ...bindActionCreators({ ...engagementActions, ...filterActions }, dispatch),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(EngagementsContainer);
