import PropTypes from 'prop-types';
import React from 'react';

function AppContainer({
  children,
}) {
  return (
    <div>
      <div>
        {children}
      </div>
    </div>
  );
}

AppContainer.propTypes = {
  children: PropTypes.node,
};

export default AppContainer;
