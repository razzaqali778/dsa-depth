import { Modal } from 'react-bootstrap';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import React, { useEffect } from 'react';
import groupBy from 'lodash/groupBy';
import keys from 'lodash/keys';
import mapValues from 'lodash/mapValues';
import {
  filter as filterActions,
  rate as rateActions,
} from '../redux/actions';
import { FETCH_ALL_RATE_DATA } from '../redux/constants/ratesConstants';
import { GET_ALL_CALENDARS } from '../redux/constants/calendarConstants';
import EditRateItem from '../components/rates/EditRateItem';
import FilterBar from '../components/FilterBar';
import RateItem from '../components/rates/RateItem';
import downloadMultiplePeopleCSV from '../components/costGroups/DownloadMultiplePeopleCSV';
import filter from '../helpers/filter';
import getCalendarsFormatted from '../redux/selectors/getCalendarsFormatted';
import getFilteredRates from '../redux/selectors/getFilteredRates';
import renderPeoplePopUp from '../components/PeopleModal';

function RatesContainer({
  activeFilter,
  affectedPeoplePopup,
  cancelAffectedPeoplePopup,
  cancelRatePeoplePopup,
  calendars,
  dispatch,
  isCreating,
  isUpdating,
  postNewRate,
  putUpdateRate,
  data,
  ratePeoplePopup,
  setDownloadAllRatesClicked,
  setDownloadRateClicked,
  setFilter,
  setSearchText,
  toggleIsCreating,
  updateRate,
}) {
  useEffect(() => {
    dispatch({ type: GET_ALL_CALENDARS });
    dispatch({ type: FETCH_ALL_RATE_DATA });
  }, [dispatch]);
  const saveNewRate = newRate => {
    if (newRate) {
      postNewRate(newRate);
    } else {
      toggleIsCreating(false);
    }
  };

  const mapRates = rates => {
    const filteredRates = filter(rates, activeFilter);

    return filteredRates
      .sort((x, y) => x.name.localeCompare(y.name))
      .map((rate, index) => (
        <RateItem
          calendars={calendars}
          key={index}
          putUpdateRate={putUpdateRate}
          rate={rate}
          updateRate={updateRate}
        />
      ));
  };

  const renderNewRateBtn = () => {
    if (isCreating) {
      return (
        <button className="btn btn-success pull-right" disabled title="Add Rate">
          <i className="fa fa-plus" />
        </button>
      );
    }

    return (
      <button
        className="btn btn-success pull-right"
        onClick={() => toggleIsCreating(true)}
        title="Add Rate"
      >
        <i className="fa fa-plus" />
      </button>
    );
  };

  const renderCreateRateSpace = () => {
    if (isUpdating) {
      return (
        <div className="well">
          <div className="velocity-spinner" />
        </div>
      );
    }

    if (isCreating) {
      const newRate = { name: '', hourlyRate: 0, isActive: true };

      return (<EditRateItem calendars={calendars} rate={newRate} updateRateHandler={saveNewRate} />);
    }

    return null;
  };

  const updateFromPopup = () => {
    if (affectedPeoplePopup.rate) {
      putUpdateRate(affectedPeoplePopup.rate);
    } else {
      toggleIsCreating(false);
    }
  };

  const renderPopUp = () => {
    const affectedCostGroups = (mapValues(groupBy(affectedPeoplePopup.people, 'costGroupName'), o => o.length));
    const costGroupsWithPeopleCount = keys(affectedCostGroups)
      .map((key, idx) => (
        <li key={`list-${idx}`}>{`${key} - ${affectedCostGroups[key]}`}</li>
      ));

    return (
      <Modal show={affectedPeoplePopup.showPopup}>
        <Modal.Header closeButton onClick={cancelAffectedPeoplePopup}>
          <Modal.Title>Affected People</Modal.Title>
        </Modal.Header>
        <Modal.Body className="affectedPeoplePopupRate">
          <ul>{costGroupsWithPeopleCount}</ul>
        </Modal.Body>
        <Modal.Footer>
          <button className="btn btn-default" onClick={cancelAffectedPeoplePopup}>Cancel</button>
          <button className="btn btn-primary" onClick={updateFromPopup}>Update</button>
        </Modal.Footer>
      </Modal>
    );
  };

  return (
    <div className="container">
      <h1>Rates</h1>
      <div className="filterBar">
        <div className="col-md-9 searchBar">
          <div className="col-md-1 searchBar dropdown">
            <FilterBar setFilter={setFilter} />
          </div>
          <div className="col-md-8 searchBar">
            <input
              className="form-control"
              onChange={({ target }) => setSearchText(target.value)}
              placeholder="Search by Rate Name or ID..."
              type="text"
            />
          </div>
        </div>
        <div className="actionButtonsWrapper pull-right">
          <div className="multipleDownloadButton">
            {downloadMultiplePeopleCSV(setDownloadAllRatesClicked)}
          </div>
          {renderNewRateBtn()}
        </div>
      </div>
      <div className="list-group">
        {renderCreateRateSpace()}
      </div>
      {renderPopUp()}
      {renderPeoplePopUp(ratePeoplePopup, 'Cost Group', cancelRatePeoplePopup, setDownloadRateClicked)}
      <div className="list-group">
        {mapRates(data, updateRate)}
      </div>
    </div>
  );
}

RatesContainer.propTypes = {
  activeFilter: PropTypes.string.isRequired,
  affectedPeoplePopup: PropTypes.object.isRequired,
  calendars: PropTypes.array.isRequired,
  cancelAffectedPeoplePopup: PropTypes.func.isRequired,
  cancelRatePeoplePopup: PropTypes.func.isRequired,
  data: PropTypes.array.isRequired,
  dispatch: PropTypes.func.isRequired,
  isCreating: PropTypes.bool.isRequired,
  isUpdating: PropTypes.bool.isRequired,
  postNewRate: PropTypes.func.isRequired,
  putUpdateRate: PropTypes.func.isRequired,
  ratePeoplePopup: PropTypes.object.isRequired,
  setDownloadAllRatesClicked: PropTypes.func.isRequired,
  setDownloadRateClicked: PropTypes.func.isRequired,
  setFilter: PropTypes.func.isRequired,
  setSearchText: PropTypes.func.isRequired,
  toggleIsCreating: PropTypes.func.isRequired,
  updateRate: PropTypes.func.isRequired,
  viewPeopleWithRate: PropTypes.func.isRequired,
};

const mapStateToProps = state => ({
  calendars: getCalendarsFormatted(state),
  isCreating: state.rate.isCreating,
  affectedPeoplePopup: state.rate.affectedPeoplePopup,
  ratePeoplePopup: state.rate.ratePeoplePopup,
  activeFilter: state.filter.activeFilter,
  isUpdating: state.async.isUpdating,
  data: getFilteredRates(state),
});

const mapDispatchToProps = dispatch => ({
  ...bindActionCreators({ ...filterActions, ...rateActions }, dispatch),
  dispatch,
});

export default connect(mapStateToProps, mapDispatchToProps)(RatesContainer);
