import { Button, Glyphicon } from 'react-bootstrap';
import ExcelJS from 'exceljs';
import FileSaver from 'file-saver';
import React from 'react';

const exportToXlsx = async (csvData, fileName) => {
  const date = new Date();
  const dateParts = [date.getMonth() + 1, date.getDate(), date.getFullYear(), date.getHours(), date.getMinutes()];
  const dateFileNamePart = `_${dateParts.join('_')}`;

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('data');

  if (csvData && csvData.length > 0) {
    const headers = Object.keys(csvData[0]);
    worksheet.columns = headers.map(key => ({ header: key, key }));
    csvData.forEach(row => worksheet.addRow(row));
  }

  const excelBuffer = await workbook.xlsx.writeBuffer();
  const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8' });

  FileSaver.saveAs(data, `${fileName}${dateFileNamePart}.xlsx`);
};

function SaveToXlsxButton({ csvData, fileName }) {
  return (
    <Button
      className="btn pull-right multipleDownloadButton"
      color="default"
      onClick={() => exportToXlsx(csvData, fileName)}
      title="Export to excel"
    >
      <Glyphicon glyph="download-alt" />
    </Button>
  );
}

export default SaveToXlsxButton;
