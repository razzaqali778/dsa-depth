const {
    TeamStructure,
    CostGroup,
    InitiativeTree,
    EffortSpendingDetail,
    SpendLineItemDetails
} = require('../../src/api/models')
const {recursive, validateTimeframes} = require('../../src/api/getSpendingForRange')

describe('getSpendingForRange', () => {
    const team = new TeamStructure({teamId: 'TEAM-ID', teamName: 'Team Id'})
    const costGroup = new CostGroup({id: 'COST-GROUP', name: 'Cost Group', costCenter: 'ABC12345'})

    const tfId1 = 101
    const tfId2 = 102
    const tfId3 = 103
    const initId1 = 'INIT-1'
    const initId2 = 'INIT-2'
    const effortComment1 = 'test-comment1'
    const effortComment2 = ''

    const validateInitSpendFull = (
        initSpend,
        initId,
        directExpenditure,
        totalExpenditure,
        effortSpending
    ) => {
        initSpend.initiative.id.should.eql(initId)
        initSpend.directExpenditure.should.eql(directExpenditure)
        initSpend.totalExpenditure.should.eql(totalExpenditure)
        initSpend.effortSpending.should.eql(effortSpending)
    }

    const validateInitSpend = (initSpend, initId, directExpenditure, effortSpending) =>
        validateInitSpendFull(
            initSpend,
            initId,
            directExpenditure,
            directExpenditure,
            effortSpending
        )

    const genInitiativeWithName = (id, name) =>
        new InitiativeTree({
            id,
            initiativeName: name,
            typeValue: 'Type',
            status: 'Funded',
            financeCodeValue: null,
            financeCodeType: null,
            fundingInitiativeId: id,
            fundingInitiativeName: 'Funding Name',
            portfolioCode: 'Portfolio Code',
            programCode: 'Program Code',
            activityId: 'Activity ID',
            isAllocable: true,
            budgets: null,
            tags: null,
            children: []
        })

    // Other than matching an id, the rest of the details don't matter
    const genInitiative = (id) => genInitiativeWithName(id, id)

    // Assuming the each effort spend only has a single line item (doesn't really effect outcome)
    const getEffortSpend = (timeFrameId, expenditure, effortComment, person) =>
        new EffortSpendingDetail(timeFrameId, team, expenditure, [
            new SpendLineItemDetails(costGroup, expenditure, undefined, effortComment, person)
        ])

    it('rejects invalid timeframe ranges', () => {
        const invalidRange = () => validateTimeframes(101, 100)
        const invalidNumber = () => validateTimeframes(Number.NaN, 100)
        const negativeStart = () => validateTimeframes(-1, 100)
        const validRange = () => validateTimeframes(100, 101)

        invalidRange.should.throw('Ending timeframe must be equal or later than starting timeframe')
        invalidNumber.should.throw('Starting and ending timeframe must be valid integers')
        negativeStart.should.throw('Starting timeframe must be equal or later than 0')
        validRange.should.not.throw()
    })

    it('matches initiative to effort spend', () => {
        const spend = 1000
        const initiative = genInitiative(initId1)
        const effortSpend = getEffortSpend(tfId1, spend, effortComment1)
        const effortSpendMap = {[initId1]: [effortSpend]}

        const results = recursive([initiative], effortSpendMap)
        results.length.should.equal(1)
        validateInitSpend(results[0], initId1, spend, [effortSpend])
    })

    it('combines spend if initiative has multiple effort spending components', () => {
        const spend1 = 1000
        const spend2 = 2000
        const initiative = genInitiative(initId1)
        const effortSpend1 = getEffortSpend(tfId1, spend1, effortComment1)
        const effortSpend2 = getEffortSpend(tfId2, spend2, effortComment2)
        const effortSpendMap = {[initId1]: [effortSpend1, effortSpend2]}

        const results = recursive([initiative], effortSpendMap)
        results.length.should.equal(1)
        validateInitSpend(results[0], initId1, spend1 + spend2, [effortSpend1, effortSpend2])
    })

    it('works on multiple initiative trees', () => {
        const spend1 = 1000
        const spend2 = 2000
        const initiative1 = genInitiative(initId1)
        const initiative2 = genInitiative(initId2)
        const effortSpend1 = getEffortSpend(tfId1, spend1, effortComment1)
        const effortSpend2 = getEffortSpend(tfId2, spend2, effortComment2)
        const effortSpendMap = {
            [initId1]: [effortSpend1],
            [initId2]: [effortSpend2]
        }

        const results = recursive([initiative1, initiative2], effortSpendMap)
        results.length.should.equal(2)

        const init1Spend = results.find((result) => result.initiative.id === initId1)
        should.exist(init1Spend)
        validateInitSpend(init1Spend, initId1, spend1, [effortSpend1])

        const init2Spend = results.find((result) => result.initiative.id === initId2)
        should.exist(init2Spend)
        validateInitSpend(init2Spend, initId2, spend2, [effortSpend2])
    })

    it('works with multi-level initiative hierarchy', () => {
        const initIdTop = 'INIT-TOP'
        const initIdMiddle = 'INIT-MIDDLE'
        const initIdBottom = 'INIT-BOTTOM'
        const spendTop = 1000
        const spendMiddle = 2000
        const spendBottom = 3000
        const initiativeBottom = genInitiative(initIdBottom)
        const initiativeMiddle = genInitiative(initIdMiddle)
        initiativeMiddle.children = [initiativeBottom]
        const initiativeTop = genInitiative(initIdTop)
        initiativeTop.children = [initiativeMiddle]
        const effortSpendTop = getEffortSpend(tfId1, spendTop, effortComment1)
        const effortSpendMiddle = getEffortSpend(tfId2, spendMiddle, effortComment2)
        const effortSpendBottom = getEffortSpend(tfId3, spendBottom, effortComment2)
        const effortSpendMap = {
            [initIdTop]: [effortSpendTop],
            [initIdMiddle]: [effortSpendMiddle],
            [initIdBottom]: [effortSpendBottom]
        }

        const results = recursive([initiativeTop], effortSpendMap)
        results.length.should.equal(1)

        const initSpendTop = results[0]
        validateInitSpendFull(
            initSpendTop,
            initIdTop,
            spendTop,
            spendTop + spendMiddle + spendBottom,
            [effortSpendTop]
        )

        const initSpendMiddle = initSpendTop.children[0]
        validateInitSpendFull(
            initSpendMiddle,
            initIdMiddle,
            spendMiddle,
            spendMiddle + spendBottom,
            [effortSpendMiddle]
        )

        const initSpendBottom = initSpendMiddle.children[0]

        validateInitSpendFull(initSpendBottom, initIdBottom, spendBottom, spendBottom, [
            effortSpendBottom
        ])
    })

    it("doesn't include initiatives that have no spend", () => {
        const spend1 = 1000
        const initiative1 = genInitiative(initId1)
        const initiative2 = genInitiative(initId2)
        const effortSpend1 = getEffortSpend(tfId1, spend1, effortComment1)
        const effortSpendMap = {
            [initId1]: [effortSpend1]
        }

        const results = recursive([initiative1, initiative2], effortSpendMap)
        results.length.should.equal(1)
        validateInitSpend(results[0], initId1, spend1, [effortSpend1])
    })

    it("doesn't include child initiative that have no spend", () => {
        const initIdParent = 'INIT-PARENT'
        const initIdChild = 'INIT-CHILD'
        const spendParent = 1000
        const initiativeChild = genInitiative(initIdChild)
        const initiativeParent = genInitiative(initIdParent)
        initiativeParent.children = [initiativeChild]
        const effortSpendParent = getEffortSpend(tfId1, spendParent, effortComment1)
        const effortSpendMap = {
            [initIdParent]: [effortSpendParent]
        }

        const results = recursive([initiativeParent], effortSpendMap)
        results.length.should.equal(1)

        const initSpendParent = results[0]
        validateInitSpend(initSpendParent, initIdParent, spendParent, [effortSpendParent])
        initSpendParent.children.length.should.equal(0)
    })

    it("doesn't include parents initiative that no direct spend but whose children do", () => {
        const initIdParent = 'INIT-PARENT'
        const initIdChild = 'INIT-CHILD'
        const spendChild = 1000
        const initiativeChild = genInitiative(initIdChild)
        const initiativeParent = genInitiative(initIdParent)
        initiativeParent.children = [initiativeChild]
        const effortSpendChild = getEffortSpend(tfId1, spendChild, effortComment2)
        const effortSpendMap = {
            [initIdChild]: [effortSpendChild]
        }

        const results = recursive([initiativeParent], effortSpendMap)
        results.length.should.equal(1)

        const initSpendParent = results[0]
        validateInitSpendFull(initSpendParent, initIdParent, 0, spendChild, [])

        initSpendParent.children.length.should.equal(1)
        const initSpendChild = initSpendParent.children[0]
        validateInitSpendFull(initSpendChild, initIdChild, spendChild, spendChild, [
            effortSpendChild
        ])
    })

    it("injects top-level parent into initiative tree and it's traversing", () => {
        const initIdTopLevel = 'INIT-TOP'
        const initIdMidLevel = 'INIT-MIDDLE'
        const initIdBottom = 'INIT-BOTTOM'
        const initNameTopLevel = 'Top Level'
        const initNameMidLevel = 'Middle Level'
        const initNameBottom = 'Bottom Level'
        const spendBottomLevel = 1000
        const initiativeBottom = genInitiativeWithName(initIdBottom, initNameBottom)
        const initiativeMidLevel = genInitiativeWithName(initIdMidLevel, initNameMidLevel)
        initiativeMidLevel.children = [initiativeBottom]
        const initiativeTopLevel = genInitiativeWithName(initIdTopLevel, initNameTopLevel)
        initiativeTopLevel.children = [initiativeMidLevel]
        const effortSpendBottom = getEffortSpend(tfId1, spendBottomLevel, effortComment2)
        const effortSpendMap = {
            [initIdBottom]: [effortSpendBottom]
        }

        const results = recursive([initiativeTopLevel], effortSpendMap)
        results.length.should.equal(1)

        const initSpendTopLevel = results[0]
        initSpendTopLevel.initiative.topLevelInitiativeName.should.equal(initNameTopLevel)

        initSpendTopLevel.children.length.should.equal(1)
        const initSpendMidLevel = initSpendTopLevel.children[0]
        initSpendMidLevel.initiative.topLevelInitiativeName.should.equal(initNameTopLevel)

        initSpendMidLevel.children.length.should.equal(1)
        const initSpendBottom = initSpendMidLevel.children[0]
        initSpendBottom.initiative.topLevelInitiativeName.should.equal(initNameTopLevel)
    })

    it('adds effortComment property to line items', () => {
        const spend = 1000
        const initiative = genInitiative(initId1)
        const effortSpend = getEffortSpend(tfId1, spend, effortComment1)
        const effortSpendMap = {[initId1]: [effortSpend]}

        const results = recursive([initiative], effortSpendMap)
        results[0].effortSpending[0].lineItems[0].effortComment.should.equal(effortComment1)
        results.length.should.equal(1)
        validateInitSpend(results[0], initId1, spend, [effortSpend])
    })

    it('adds person data to line items', () => {
        const spend = 1000
        const initiative = genInitiative(initId1)
        const effortSpend = getEffortSpend(tfId1, spend, effortComment1, {id: 'PERSON-ID'})
        const effortSpendMap = {[initId1]: [effortSpend]}

        const results = recursive([initiative], effortSpendMap)
        results[0].effortSpending[0].lineItems[0].person.id.should.equal('PERSON-ID')
        results.length.should.equal(1)
        validateInitSpend(results[0], initId1, spend, [effortSpend])
    })

    describe('pagination helpers', () => {
        const {
            isPaginationRequested,
            parsePaginationParams,
            findInitiativeSubtree,
            paginateSpendingResults
        } = require('../../src/api/getSpendingForRange')

        it('treats pagination as opt-in via page or pageSize', () => {
            isPaginationRequested({}).should.equal(false)
            isPaginationRequested({initiativeId: 'abc'}).should.equal(false)
            isPaginationRequested({page: 1}).should.equal(true)
            isPaginationRequested({pageSize: 10}).should.equal(true)
        })

        it('parses pagination defaults and validates bounds', () => {
            parsePaginationParams({}).should.eql({page: 1, pageSize: 25})
            parsePaginationParams({page: '2', pageSize: '10'}).should.eql({page: 2, pageSize: 10})
            parsePaginationParams({page: '2'}).should.eql({page: 2, pageSize: 25})

            ;(() => parsePaginationParams({page: 0})).should.throw(
                'page must be an integer greater than or equal to 1'
            )
            ;(() => parsePaginationParams({pageSize: 999})).should.throw(
                'pageSize must be an integer between 1 and 200'
            )
        })

        it('finds an initiative subtree and builds breadcrumb path', () => {
            const child = genInitiativeWithName(initId2, 'Child')
            const parent = genInitiativeWithName(initId1, 'Parent')
            parent.children = [child]

            const found = findInitiativeSubtree([parent], initId2)
            found.tree.id.should.equal(initId2)
            found.path.should.eql([
                {id: '', name: 'Initiatives'},
                {id: initId1, name: 'Parent'},
                {id: initId2, name: 'Child'}
            ])
        })

        it('pages top-level spending results', () => {
            const items = [
                {initiative: {id: 'a'}},
                {initiative: {id: 'b'}},
                {initiative: {id: 'c'}}
            ]
            const result = paginateSpendingResults(items, 2, 2, null)
            result.data.should.eql([{initiative: {id: 'c'}}])
            result.pagination.should.eql({
                page: 2,
                pageSize: 2,
                totalCount: 3,
                totalPages: 2
            })
        })

        it('pages children when scoped to an initiative', () => {
            const {InitiativeSpendingTree} = require('../../src/api/models')
            const children = [
                new InitiativeSpendingTree({id: 'c1'}, 1, 1, [], []),
                new InitiativeSpendingTree({id: 'c2'}, 2, 2, [], []),
                new InitiativeSpendingTree({id: 'c3'}, 3, 3, [], [])
            ]
            const parent = new InitiativeSpendingTree({id: 'p1'}, 0, 6, [], children)
            const result = paginateSpendingResults([parent], 1, 2, 'p1', [
                {id: '', name: 'Initiatives'},
                {id: 'p1', name: 'Parent'}
            ])

            result.data.length.should.equal(1)
            result.data[0].children.length.should.equal(2)
            result.data[0].children[0].initiative.id.should.equal('c1')
            result.pagination.totalCount.should.equal(3)
            result.path[1].id.should.equal('p1')
        })
    })
})
