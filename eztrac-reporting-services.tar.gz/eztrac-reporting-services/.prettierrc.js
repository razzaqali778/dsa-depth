module.exports = Object.assign({
    // project-specific exclusions go here
}, require('./node_modules/@monsantoit/eslint-config-velocity/.prettierrc'));
