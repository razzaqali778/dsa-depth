# Node 22.22.3 upgrade assessment

**Date:** 2026-07-09  
**Repo:** `eztrac-reporting-services`  
**Previous Node:** `^18.0.0` in `package.json`, `18.15.0` in CI inputs  
**Target Node:** `22.22.3`

## Recommendation

Proceed after CI and smoke testing. This is an Express API deployed through Fargate, so Node runs in production. Validate request handling, outbound service calls, and the spending range endpoint before promoting.

## What changed in the repo

| File | Change |
|---|---|
| `package.json` | `engines.node` set to `22.22.3` |
| `package-lock.json` | Root package engine metadata set to `22.22.3` |
| `.nvmrc` | Added `22.22.3` |
| `.github/workflows/*.yml` | CI `node_version` defaults/fallbacks set to `22.22.3` |

## Node 22 impact notes

| Area | Risk | Notes |
|---|---|---|
| Production runtime | Medium | The service runs on Node in Fargate; smoke test `/ping` and spending routes. |
| Express / body-parser | Low | Current versions support modern Node, but check transitive warnings. |
| Swagger tools | Medium | `swagger-tools` is legacy; verify route validation and docs startup. |
| npm 10 lockfile behavior | Medium | Audit failed locally until lockfile/install state is refreshed. |

## Required validation

```bash
nvm install 22.22.3
nvm use 22.22.3
npm ci
npm run lint
npm test
npm start
```

## Smoke tests

- `GET /ping` should return the ping page.
- Spending range endpoint should return either valid data or a structured 4xx/5xx JSON error.
- Confirm the Fargate build image receives `NODE_VERSION=22.22.3` from the shared deploy workflow.
