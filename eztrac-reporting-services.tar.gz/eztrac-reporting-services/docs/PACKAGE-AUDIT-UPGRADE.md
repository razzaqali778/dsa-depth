# Package audit and upgrade notes

**Date:** 2026-07-09  
**Repo:** `eztrac-reporting-services`  
**Node target:** `22.22.3`

## Audit status

`npm audit --json` was attempted, but npm returned `ENOLOCK` / `loadVirtual requires existing shrinkwrap file`. Re-run after a clean `npm ci` or regenerate the lockfile with npm 10 if the lockfile remains incompatible with audit.

## Application findings to fix first

| Priority | Finding | Suggested fix |
|---|---|---|
| High | `entitlementMiddleware.js` exists but is not applied to spending API routes. | Wire entitlement middleware before reporting routes. |
| High | Spending endpoint fetches large org-wide datasets for every range request. | Cache/precompute aggregates and avoid fetching unused dimensions. |
| Medium | Timeframe validation compares URL params as strings. | Convert params to numbers and return 400 for invalid ranges. |
| Medium | Error handler can use undefined status and leave clients hanging. | Default to 500 and always send a JSON error response. |

## Package areas to review

| Package area | Notes |
|---|---|
| `swagger-tools` | Legacy package; verify support and consider a maintained OpenAPI middleware. |
| `superagent` | Direct dependency is modern enough for Node 22; add request timeouts in service callers. |
| `lodash` | Pinned patched 4.17.21 line; keep override strategy if transitive copies appear. |
| Phoenix/Monsanto config/auth packages | Validate engine warnings and auth behavior under Node 22.22.3. |

## Validation checklist

```bash
nvm use 22.22.3
npm ci
npm run lint
npm test
npm audit --json
```
