const _ = require('lodash')
const defaultConfig = require('./default')

module.exports = _.merge(defaultConfig, {
    'workforce-approle': {
        role_id: '',
        secret_id: '',
        role_name: 'workforce-dev-admins-eztrac-np'
    }
})
