const _ = require('lodash')
const npConfig = require('./fargate-np')

module.exports = _.merge(npConfig, {
    'ez-trac-core-url': 'https://ez-trac-core-services.velocity.ag/v2',
    'ez-trac-costing-url': 'https://ez-trac-costing-services.velocity.ag/v1',
    'ez-trac-vip-url': {
        v1: 'https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services/v1',
        v2: 'https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services/v2'
    },
    'oauth-client': {
        id: 'vault://secret/ez-trac/reporting-services/prod/oauth-azure/client-id',
        secret: 'vault://secret/ez-trac/reporting-services/prod/oauth-azure/client-secret'
    },
    'profile-url': 'https://profile.velocity.ag',
    'velocity-home': {
        url: 'velocity.ag',
        value: 'velocity.ag'
    },
    'workforce-approle': {
        role_name: 'workforce-dev-admins-eztrac-prod'
    }
})
