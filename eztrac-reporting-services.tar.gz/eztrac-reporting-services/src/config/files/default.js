const config = {
    'ez-trac-core-url': 'https://ez-trac-core-services.velocity-np.ag/v2',
    'ez-trac-costing-url': 'https://ez-trac-costing-services.velocity-np.ag/v1',
    'ez-trac-vip-url': {
        v1: 'https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services/v1',
        v2: 'https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services/v2'
    },
    'oauth-client': {
        id: 'vault://secret/ez-trac/reporting-services/np/oauth-azure/client-id',
        secret: 'vault://secret/ez-trac/reporting-services/np/oauth-azure/client-secret'
    },
    'profile-url': 'https://profile.velocity-np.ag',
    'velocity-home': {
        url: 'velocity-np.ag',
        value: 'velocity-np.ag'
    },
    'workforce-approle': {
        role_id: process.env.VAULT_APPROLE_ROLE_ID,
        secret_id: process.env.VAULT_APPROLE_SECRET_ID
    }
}

module.exports = config
