const {httpGetToken} = require('@monsantoit/oauth-azure')
const config = require('../config')

const getToken = () =>
    httpGetToken({
        clientId: config.get('oauth-client.id'),
        clientSecret: config.get('oauth-client.secret')
    })()

module.exports = getToken
