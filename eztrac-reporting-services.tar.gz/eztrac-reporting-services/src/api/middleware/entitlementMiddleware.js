const agent = require('superagent')
const _ = require('lodash')
const getToken = require('../../util/getToken')
const config = require('../../config')

const getUserEntitlements = async (userId, appIds) => {
    if (!userId) {
        throw new Error('No valid userId provided')
    }
    const variables = {
        userId,
        appIds
    }

    const query = `query($userId:String!, $appIds:[String!]!){
        entitlements: getEntitlementsForUser(userId: $userId,appIds:$appIds){
          code
          application{
            id
          }
        }
      }
    `

    const url = `https://profile.${config.get('velocity-home.value', 'velocity-np.ag')}/v3/graphql`

    const token = await getToken()
    const {body} = await agent
        .post(url)
        .set('Authorization', `Bearer ${token}`)
        .send({query, variables})

    const grouped = _.groupBy(body.data.entitlements, (item) => item.application.id)
    const entitlements = {}
    _.forEach(_.keys(grouped), (appCode) => {
        entitlements[`${appCode.toUpperCase()}`] = _.map(grouped[appCode], (ent) =>
            ent.code.toUpperCase()
        )
    })

    return entitlements
}

module.exports = async (req, res, next) => {
    // Local dev runs without Ocelot-injected profile headers; core-services uses the
    // same pattern (see server.ts localDevProfile). Deployed environments (including
    // non-prod Fargate) must still enforce entitlements, so only bypass when there's
    // no Fargate signal at all.
    const isLocalDev = process.env.NODE_ENV !== 'production' && !process.env.FARGATE_ENV
    if (isLocalDev) {
        return next()
    }

    try {
        const entitlements = await getUserEntitlements(req.userId, ['EZTRAC'])

        const hasAccessEntitlement =
            entitlements &&
            entitlements.EZTRAC &&
            (entitlements.EZTRAC.includes('EZTRAC-WRITE-USER') ||
                entitlements.EZTRAC.includes('EZTRAC-READ-USER'))

        if (hasAccessEntitlement) {
            return next()
        }

        return res.sendStatus(403)
    } catch (err) {
        return res.sendStatus(403)
    }
}
