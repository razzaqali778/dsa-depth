const agent = require('superagent')
const getToken = require('../../../util/getToken')
const config = require('../../../config')
const {Person} = require('../../models')

module.exports = async () => {
    const token = await getToken()

    const result = await agent
        .get(`${config.get('ez-trac-costing-url')}/people`)
        .set('Authorization', `Bearer ${token}`)

    return result.body.map((item) => new Person(item))
}
