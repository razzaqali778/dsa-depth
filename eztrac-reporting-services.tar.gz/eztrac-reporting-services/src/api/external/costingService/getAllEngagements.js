const agent = require('superagent')
const getToken = require('../../../util/getToken')
const config = require('../../../config')
const {Engagement} = require('../../models')

module.exports = async () => {
    const token = await getToken()

    const result = await agent
        .get(`${config.get('ez-trac-costing-url')}/engagements`)
        .set('Authorization', `Bearer ${token}`)

    return result.body.map((item) => new Engagement(item))
}
