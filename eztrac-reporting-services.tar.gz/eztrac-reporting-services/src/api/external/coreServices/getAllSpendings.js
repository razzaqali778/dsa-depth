const agent = require('superagent')
const getToken = require('../../../util/getToken')
const config = require('../../../config')
const {EffortInitiativeSpending} = require('../../models')

module.exports = async (startTimeFrame, endTimeFrame) => {
    const token = await getToken()

    const result = await agent
        .get(
            `${config.get(
                'ez-trac-core-url'
            )}/spend/startTimeFrame/${startTimeFrame}/endTimeFrame/${endTimeFrame}`
        )
        .set('Authorization', `Bearer ${token}`)

    return result.body.map((item) => new EffortInitiativeSpending(item))
}
