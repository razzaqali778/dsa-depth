const agent = require('superagent')
const getToken = require('../../../util/getToken')
const config = require('../../../config')

const getAllTimeframes = async () => {
    const token = await getToken()

    const result = await agent
        .get(`${config.get('ez-trac-core-url')}/timeframes`)
        .set('Authorization', `Bearer ${token}`)

    return result.body
}

module.exports = {getAllTimeframes}
