const {getAllTimeframes} = require('./getTimeframes')
const getAllTeams = require('./getAllTeams')
const getAllSpendings = require('./getAllSpendings')
const getAllEffortEngagements = require('./getAllEffortEngagements')

module.exports = {getAllTimeframes, getAllTeams, getAllSpendings, getAllEffortEngagements}
