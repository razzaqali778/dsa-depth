const agent = require('superagent')
const getToken = require('../../../util/getToken')
const config = require('../../../config')

module.exports = async () => {
    const token = await getToken()
    console.log(token)

    const result = await agent
        .get(`${config.get('ez-trac-vip-url.v2')}/tags/names`)
        .set('Authorization', `Bearer ${token}`)

    return result.body
}
