const agent = require('superagent')
const getToken = require('../../../util/getToken')
const config = require('../../../config')
const {InitiativeTree} = require('../../models')

module.exports = async () => {
    const token = await getToken()
    const startTime = new Date()
    const result = await agent
        .get(
            `${config.get(
                'ez-trac-vip-url.v2'
            )}/initiatives/tree?fields=fundingDetails,tags,budgets,types`
        )
        .set('Authorization', `Bearer ${token}`)
    const endTime = new Date()
    const diff = endTime - startTime
    console.log(`time to get initiatives tree in ms: ${diff}`)
    return result.body.map((initiative) => new InitiativeTree(initiative))
}
