/* eslint-disable no-param-reassign */
const {getAllInitiatives} = require('./external/vipServices')
const {getAllTeams, getAllSpendings, getAllEffortEngagements} = require('./external/coreServices')
const {getCostGroups, getAllEngagements} = require('./external/costingService')
const {InitiativeSpendingTree} = require('./models')
const effortSpendingMap = require('./models/EffortSpendingMap')
const logger = require('../../logger')
const getAllPeople = require('./external/costingService/getAllPeople')

const DEFAULT_PAGE = 1
const DEFAULT_PAGE_SIZE = 10
const MAX_PAGE_SIZE = 200

const addGenericPersonItem = (peopleArray) => [
    ...peopleArray,
    {id: 'GENERIC-PERSON', name: 'Placeholder'}
]

const parseTimeframeParam = (value) => Number(value)

const validateTimeframes = (startTimeframe, endTimeframe) => {
    if (!Number.isInteger(startTimeframe) || !Number.isInteger(endTimeframe)) {
        const error = new Error('Starting and ending timeframe must be valid integers')
        error.status = 400
        throw error
    }

    if (startTimeframe < 0) {
        const error = new Error('Starting timeframe must be equal or later than 0')
        error.status = 400
        throw error
    }

    if (endTimeframe < startTimeframe) {
        const error = new Error('Ending timeframe must be equal or later than starting timeframe')
        error.status = 400
        throw error
    }
}

const isPresent = (value) => value !== undefined && value !== null && value !== ''

// Pagination is opt-in. Legacy clients (eztrac-reporting UI) call with no page/pageSize
// and expect a raw InitiativeSpendingTree[] — not { data, pagination, path }.
const isPaginationRequested = ({page, pageSize} = {}) => isPresent(page) || isPresent(pageSize)

const parsePaginationParams = ({page, pageSize} = {}) => {
    const parsedPage = isPresent(page) ? Number(page) : DEFAULT_PAGE
    const parsedPageSize = isPresent(pageSize) ? Number(pageSize) : DEFAULT_PAGE_SIZE

    if (!Number.isInteger(parsedPage) || parsedPage < 1) {
        const error = new Error('page must be an integer greater than or equal to 1')
        error.status = 400
        throw error
    }

    if (!Number.isInteger(parsedPageSize) || parsedPageSize < 1 || parsedPageSize > MAX_PAGE_SIZE) {
        const error = new Error(`pageSize must be an integer between 1 and ${MAX_PAGE_SIZE}`)
        error.status = 400
        throw error
    }

    return {page: parsedPage, pageSize: parsedPageSize}
}

const findInitiativeSubtree = (trees, initiativeId, path = [{id: '', name: 'Initiatives'}]) => {
    for (let i = 0; i < trees.length; i += 1) {
        const tree = trees[i]
        const nextPath = [...path, {id: tree.id, name: tree.initiativeName}]
        if (tree.id === initiativeId) {
            return {tree, path: nextPath}
        }
        const found = findInitiativeSubtree(tree.children || [], initiativeId, nextPath)
        if (found) {
            return found
        }
    }
    return null
}

const buildPaginationMeta = (page, pageSize, totalCount) => ({
    page,
    pageSize,
    totalCount,
    totalPages: totalCount === 0 ? 0 : Math.ceil(totalCount / pageSize)
})

const paginateList = (items, page, pageSize) => {
    const totalCount = items.length
    const start = (page - 1) * pageSize
    return {
        data: items.slice(start, start + pageSize),
        pagination: buildPaginationMeta(page, pageSize, totalCount)
    }
}

const paginateSpendingResults = (results, page, pageSize, initiativeId, path) => {
    // Root forest: page top-level initiatives
    if (!initiativeId) {
        const paged = paginateList(results, page, pageSize)
        return {...paged, path: [{id: '', name: 'Initiatives'}]}
    }

    // Scoped initiative: keep parent, page its children
    if (!results.length) {
        return {
            data: [],
            pagination: buildPaginationMeta(page, pageSize, 0),
            path: path || [{id: '', name: 'Initiatives'}]
        }
    }

    const node = results[0]
    const children = node.children || []

    if (children.length === 0) {
        return {
            data: [node],
            pagination: buildPaginationMeta(1, pageSize, 1),
            path: path || [{id: '', name: 'Initiatives'}]
        }
    }

    const {data: pagedChildren, pagination} = paginateList(children, page, pageSize)
    const pagedNode = new InitiativeSpendingTree(
        node.initiative,
        node.directExpenditure,
        node.totalExpenditure,
        node.effortSpending,
        pagedChildren
    )

    return {
        data: [pagedNode],
        pagination,
        path: path || [{id: '', name: 'Initiatives'}]
    }
}

const recursive = (initiativeTrees, effortMap, topLevelInitiative) =>
    initiativeTrees
        .map((initiativeTree) => {
            const topLevel = topLevelInitiative || initiativeTree.initiativeName
            const children = recursive(initiativeTree.children, effortMap, topLevel)
            const childExpenditure = children.reduce(
                (sum, child) => sum + (Number(child.totalExpenditure) || 0),
                0
            ) // sum child expenditures
            const spendItems = effortMap[initiativeTree.id] || []
            const expenditure = spendItems.reduce((sum, item) => sum + (Number(item.spend) || 0), 0) // sum spend item expenditures
            return new InitiativeSpendingTree(
                initiativeTree.toProperties(topLevel),
                expenditure,
                expenditure + childExpenditure,
                spendItems,
                children
            )
        })
        .filter((initiativeSpendingTree) => initiativeSpendingTree.totalExpenditure > 0)

const parseData = (
    initiativeTrees,
    effortSpending,
    teams,
    costGroups,
    engagements,
    effortEngagements,
    people
) => {
    const convertToMap = (key, items) =>
        items.reduce((map, item) => {
            map[item[key]] = item
            return map
        }, {})

    const teamStructureMap = convertToMap('teamId', teams)
    const costGroupMap = convertToMap('id', costGroups)
    const engagementMap = convertToMap('id', engagements)
    const peopleMap = convertToMap('id', people)

    const effortSpendMap = effortSpendingMap(
        effortSpending,
        teamStructureMap,
        costGroupMap,
        engagementMap,
        effortEngagements,
        peopleMap
    )

    return recursive(initiativeTrees, effortSpendMap)
}

const getSpendingForRange = async (startTimeframe, endTimeframe, options = {}) => {
    const startTime = new Date().getTime()
    const parsedStartTimeframe = parseTimeframeParam(startTimeframe)
    const parsedEndTimeframe = parseTimeframeParam(endTimeframe)
    validateTimeframes(parsedStartTimeframe, parsedEndTimeframe)

    const paginate = isPaginationRequested(options)
    const pagination = paginate ? parsePaginationParams(options) : null
    const initiativeId = options.initiativeId || null

    const [initiatives, spending, teams, costGroups, engagements, effortEngagements, people] =
        await Promise.all([
            getAllInitiatives(),
            getAllSpendings(parsedStartTimeframe, parsedEndTimeframe),
            getAllTeams(),
            getCostGroups(),
            getAllEngagements(),
            getAllEffortEngagements(parsedStartTimeframe, parsedEndTimeframe),
            getAllPeople()
        ])

    let scopedInitiatives = initiatives
    let path = [{id: '', name: 'Initiatives'}]

    if (initiativeId) {
        const found = findInitiativeSubtree(initiatives, initiativeId)
        if (!found) {
            if (!paginate) {
                return []
            }
            return {
                data: [],
                pagination: buildPaginationMeta(pagination.page, pagination.pageSize, 0),
                path
            }
        }
        scopedInitiatives = [found.tree]
        path = found.path
    }

    const results = parseData(
        scopedInitiatives,
        spending,
        teams,
        costGroups,
        engagements,
        effortEngagements,
        addGenericPersonItem(people)
    )

    const endTime = new Date().getTime()

    // Legacy contract: raw tree array when page/pageSize are omitted.
    if (!paginate) {
        logger.info(
            `Total Time: ${
                endTime - startTime
            }; Timeframe Range: ${parsedStartTimeframe} - ${parsedEndTimeframe}` +
                (initiativeId ? `; initiativeId=${initiativeId}` : '')
        )
        return results
    }

    const response = paginateSpendingResults(
        results,
        pagination.page,
        pagination.pageSize,
        initiativeId,
        path
    )

    logger.info(
        `Total Time: ${
            endTime - startTime
        }; Timeframe Range: ${parsedStartTimeframe} - ${parsedEndTimeframe}; ` +
            `page=${response.pagination.page} pageSize=${response.pagination.pageSize} ` +
            `totalCount=${response.pagination.totalCount}` +
            (initiativeId ? `; initiativeId=${initiativeId}` : '')
    )

    return response
}

module.exports = getSpendingForRange
module.exports.recursive = recursive
module.exports.validateTimeframes = validateTimeframes
module.exports.isPaginationRequested = isPaginationRequested
module.exports.parsePaginationParams = parsePaginationParams
module.exports.findInitiativeSubtree = findInitiativeSubtree
module.exports.paginateSpendingResults = paginateSpendingResults
module.exports.DEFAULT_PAGE_SIZE = DEFAULT_PAGE_SIZE
