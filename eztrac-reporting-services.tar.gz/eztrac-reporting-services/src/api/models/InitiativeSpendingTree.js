class InitiativeSpendingTree {
    constructor(initiative, directExpenditure, totalExpenditure, effortSpending, children) {
        this.initiative = initiative
        this.directExpenditure = directExpenditure
        this.totalExpenditure = totalExpenditure
        this.effortSpending = effortSpending
        this.children = children
    }
}

module.exports = InitiativeSpendingTree
