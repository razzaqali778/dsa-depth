class Person {
    constructor(input) {
        this.id = input.personId
        this.name = input.personName
    }
}

class PersonIdOnly {
    constructor(id, notFound = true) {
        this.id = id
        this.notFound = notFound
    }
}

module.exports = {Person, PersonIdOnly}
