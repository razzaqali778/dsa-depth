class EffortEngagement {
    constructor(input) {
        this.timeFrameId = input.timeFrameId
        this.teamId = input.teamId
        this.amount = input.amount
        this.amountDetails = input.amountDetails
        this.comment = input.comment
        this.engagementId = input.engagementId
    }
}

module.exports = EffortEngagement
