class CostGroup {
    constructor(input) {
        this.id = input.id
        this.name = input.name
        this.costCenter = input.costCenter
        this.isActive = input.isActive
        this.excludeFromDistributions = input.excludeFromDistributions
    }
}

class CostGroupIdOnly {
    constructor(id, isActive = false, notFound = true) {
        this.id = id
        this.isActive = isActive
        this.notFound = notFound
    }
}

module.exports = {CostGroup, CostGroupIdOnly}
