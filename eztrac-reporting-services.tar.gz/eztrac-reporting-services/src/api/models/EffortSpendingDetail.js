class EffortSpendingDetail {
    constructor(timeFrameId, team, spend, lineItems) {
        this.timeFrameId = timeFrameId
        this.team = team
        this.spend = spend
        this.lineItems = lineItems
    }
}

module.exports = EffortSpendingDetail
