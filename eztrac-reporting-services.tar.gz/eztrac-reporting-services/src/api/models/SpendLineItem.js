class SpendLineItem {
    constructor(input) {
        this.costGroupId = input.costGroupId
        this.spend = input.spend || 0
        this.engagementId = input.engagementId
        this.personId = input.personId
    }
}

class SpendLineItemDetails {
    constructor(costGroup, spend, engagement, effortComment, person) {
        this.costGroup = costGroup
        this.spend = spend
        this.engagement = engagement
        this.person = person
        this.effortComment = effortComment
    }
}

module.exports = {SpendLineItem, SpendLineItemDetails}
