// eslint-disable-next-line max-classes-per-file
class InitiativeProperties {
    constructor(initiativeWithTopLevelInitiative) {
        this.id = initiativeWithTopLevelInitiative.id
        this.name = initiativeWithTopLevelInitiative.initiativeName
        this.typeName = initiativeWithTopLevelInitiative.typeValue
        this.status = initiativeWithTopLevelInitiative.status
        this.financeCodeValue = initiativeWithTopLevelInitiative.financeCodeValue
        this.financeCodeType = initiativeWithTopLevelInitiative.financeCodeType
        this.fundingInitiativeId = initiativeWithTopLevelInitiative.fundingInitiativeId
        this.fundingInitiativeName = initiativeWithTopLevelInitiative.fundingInitiativeName
        this.topLevelInitiativeName = initiativeWithTopLevelInitiative.topLevelInitiative
        this.portfolioCode = initiativeWithTopLevelInitiative.portfolioCode
        this.programCode = initiativeWithTopLevelInitiative.programCode
        this.activityId = initiativeWithTopLevelInitiative.activityId
        this.isGroupingOnly = !initiativeWithTopLevelInitiative.isAllocable
        this.budgets = initiativeWithTopLevelInitiative.budgets
        this.tags = initiativeWithTopLevelInitiative.tags
    }
}

class InitiativeTree {
    constructor(initiative) {
        this.id = initiative.id
        this.initiativeName = initiative.initiativeName
        this.typeValue = initiative.typeValue
        this.status = initiative.status
        this.financeCodeValue = initiative.financeCodeValue
        this.financeCodeType = initiative.financeCodeType
        this.fundingInitiativeId = initiative.fundingInitiativeId
        this.fundingInitiativeName = initiative.fundingInitiativeName
        this.portfolioCode = initiative.portfolioCode
        this.programCode = initiative.programCode
        this.activityId = initiative.activityId
        this.isAllocable = initiative.isAllocable
        this.budgets = initiative.budgets
        this.tags = initiative.tags
        this.children = initiative.children.map((child) => new InitiativeTree(child))
    }

    toProperties(topLevelInitiative) {
        return new InitiativeProperties({
            ...this,
            topLevelInitiative
        })
    }
}

module.exports = InitiativeTree
