class TeamStructure {
    constructor(input) {
        this.teamId = input.teamId
        this.teamName = input.teamName
        this.communityId = input.communityId
        this.communityName = input.communityName
        this.platformId = input.platformId
        this.platformName = input.platformName
        this.orgId = input.orgId
        this.orgName = input.orgName
        this.isActive = input.isActive
    }
}

class TeamIdOnly {
    constructor(teamId, isActive = false, notFound = true) {
        this.teamId = teamId
        this.isActive = isActive
        this.notFound = notFound
    }
}

module.exports = {TeamStructure, TeamIdOnly}
