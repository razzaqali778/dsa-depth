const {SpendLineItem} = require('./SpendLineItem')

class InitiativeSpending {
    constructor(input) {
        this.initiativeId = input.initiativeId
        this.spend = input.spend || 0
        this.lineItems = input.lineItems.map((lineItem) => new SpendLineItem(lineItem))
    }
}

class EffortInitiativeSpending {
    constructor(input) {
        this.timeFrameId = input.timeFrameId
        this.teamId = input.teamId
        this.initiatives = input.initiatives.map((initiative) => new InitiativeSpending(initiative))
    }
}

module.exports = EffortInitiativeSpending
