class InitiativeDetails {
    constructor(initiativeTree, topLevelInitiative) {
        this.id = initiativeTree.id
        this.name = initiativeTree.initiativeName
        this.typeName = initiativeTree.typeValue
        this.status = initiativeTree.status
        this.financeCodeValue = initiativeTree.financeCodeValue
        this.financeCodeType = initiativeTree.financeCodeType
        this.fundingInitiativeId = initiativeTree.fundingInitiativeId
        this.fundingInitiativeName = initiativeTree.fundingInitiativeName
        this.topLevelInitiativeName = topLevelInitiative
        this.portfolioCode = initiativeTree.portfolioCode
        this.programCode = initiativeTree.programCode
        this.activityId = initiativeTree.activityId
        this.isGroupingOnly = !initiativeTree.isAllocable || false
        this.budgets = initiativeTree.budgets || []
        this.tags = initiativeTree.tags || []
    }
}

module.exports = InitiativeDetails
