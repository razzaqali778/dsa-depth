class Engagement {
    constructor(input) {
        this.id = input.id
        this.name = input.name
        this.purchaseOrder = input.purchaseOrder
        this.costGroupId = input.costGroupId
        this.isActive = input.isActive
    }
}

class EngagementIdOnly {
    constructor(id, isActive = false, notFound = true) {
        this.id = id
        this.isActive = isActive
        this.notFound = notFound
    }
}

module.exports = {Engagement, EngagementIdOnly}
