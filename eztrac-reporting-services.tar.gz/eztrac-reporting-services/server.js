const express = require('express')
const compression = require('compression')
const pingPage = require('@monsantoit/ping-page')
const bodyParser = require('body-parser')

const api = require('./src/api/routes')
const pkg = require('./package.json')

const appBaseUrl = ''
const app = express()

app.use(bodyParser.json({limit: '50mb'}))
app.use(compression())
app.get(`/ping|${appBaseUrl}/ping`, pingPage(pkg)) // for accessing through ocelot

let localUser = null
if (process.env.NODE_ENV !== 'production') {
    app.use(require('./src/middleware/cors'))
    localUser = process.env.USER || 'MSKEMM'
}

app.use('/', (req, res, next) => {
    req.userId = req.headers['user-id'] || localUser
    req.clientId = req.headers['client-id']
    next()
})

app.use(`${appBaseUrl}/v2`, api)

app.use('/*', (err, req, res, next) => {
    console.error(err) // handle uncaught errors
    next()
})

const port = parseInt(process.env.PORT || 9092, 10)
const hostname = process.env.NODE_ENV === 'production' ? undefined : '127.0.0.1' // unlike default, only reachable from this machine
const server = app.listen(port, hostname, () => {
    const address = server.address()
    const url = `http://${address.host || 'localhost'}:${port}`
    console.info(`Listening at ${url}${appBaseUrl}/`)
    console.info(`Swagger at ${url}${appBaseUrl}/v1/docs`)
})
