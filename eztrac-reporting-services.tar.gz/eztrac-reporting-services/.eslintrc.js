module.exports = {
    parserOptions: {
        requireConfigFile: false
    },
    extends: ['@monsantoit/eslint-config-velocity'],
    rules: {
        'global-require': 'off',
        'max-classes-per-file': 'off',
        'arrow-body-style': ['error', 'as-needed']
    }
}
