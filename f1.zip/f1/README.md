# FLEX

Financial Lifecycle Execution modulith for unified planning and decision support across outcomes, business use cases, FinOps, and people planning.

The current target is:

- React + Redux Toolkit frontend
- NestJS backend modulith
- explicit network, auth, integration, messaging, and DB platform layers
- module-owned persistence boundaries
- read-only integration first with existing systems
- planned on-demand source synchronization through backend adapters
- RabbitMQ as a planned broker for accepted async events
- future write-back, microservice, and production cloud deployment decisions handled through ADRs

## Repository Layout

```text
apps/
  web/                  React application
  api/                  NestJS API modulith
    src/modules/        FLEX business modules
    src/platform/       network, auth, data, integration, messaging boundaries

docs/
  README.md             documentation index
  architecture.md       architecture overview
  module-blueprint.md   module structure rules
  diagrams/             draw.io source
  adr/                  architecture decision records
```

## Product Modules

Target FLEX modules:

- `outcomes`: strategic goals and business value tracking; linked to Workpath
- `business-usecase`: ROI analysis, investment justification, and capital allocation to Outcomes
- `finops`: financial operations and forecasting; linked to Planview and EzTrac
- `people-planning`: resource skills, staffing, and allocation; linked to RPT and other tools

## Current Scaffold Status

- The repository contains an older prototype scaffold.
- The docs and base folders now define the corrected FLEX modulith direction.
- The old prototype module registrations have been replaced with the target FLEX module scaffold.
- RPT stays independent in the current phase; FLEX consumes RPT data read-only first.

## Local Development

Use Node 22 (`nvm use` reads `.nvmrc`).

**If `npm` fails with `EPERM uv_cwd` or `getcwd: cannot access parent directories`**, your terminal cannot resolve the current directory inside `~/Desktop` (macOS privacy). Use one of these fixes:

1. **Recommended:** open the project from `~/Projects/flex` (outside Desktop). A copy is already there:

```bash
cd ~/Projects/flex
nvm use
npm i
```

Then reopen **File → Open Folder → ~/Projects/flex** in Cursor and use that path going forward.

2. **Grant Desktop access:** System Settings → Privacy & Security → Files and Folders → enable **Desktop Folder** for Terminal / iTerm / Cursor.
3. **Stay on Desktop but use the safe wrapper** (runs npm from `$HOME` so `getcwd` is not blocked):

```bash
cd ~
bash ~/Desktop/flex/scripts/setup.sh
```

After dependencies are installed:

```bash
make install    # safe npm install wrapper
make dev        # start all apps
```

Or without Make:

```bash
./scripts/npm-from-safe-cwd.sh install
./scripts/npm-from-safe-cwd.sh run dev
```

Start local dependencies:

```bash
make up            # Postgres + Grafana/OTEL + SonarQube + API + Web (recommended)
make up SONAR=0    # Same without SonarQube (lighter / faster startup)
make down          # Stop everything
make status        # Check what's running
make help          # All targets
```

Individual targets:

```bash
make up-infra      # Docker only (Postgres + Grafana/OTEL + SonarQube)
make up-apps       # API + Web in background
make deps          # Postgres only (legacy alias)
make observability # Grafana stack only
make sonar         # SonarQube only (if not already running)
make stack         # Same as up-infra (all infra profiles)
```

Run a Sonar scan (`make up` already starts SonarQube; the scan script auto-loads or bootstraps `SONAR_TOKEN` into `.flex/sonar/dev-credentials.env`):

```bash
npm run test:coverage
npm run sonar:scan
```

Set `SONAR_TOKEN` in `.env` only for SonarCloud or a custom token. See [Local SonarQube](./docs/sonarqube-local.md).

Run individual apps:

```bash
npm run dev:web
npm run dev:api
```

Local URLs:

- Web: `http://localhost:5173`
- API: `http://localhost:3000`
- Swagger UI: `http://localhost:3000/api/docs`

Create a module scaffold:

```bash
make module MODULE=my-module
```

If `make` is not installed:

```bash
npm run module -- my-module
```

Container build entry points:

```bash
docker build -f Dockerfile.api -t flex-api .
docker build -f Dockerfile.web -t flex-web .
```

## Documentation

- [Documentation Index](./docs/README.md)
- [Architecture Overview](./docs/architecture.md)
- [Module Blueprint](./docs/module-blueprint.md)
- [Observability (OTEL + Grafana)](./docs/observability.md)
- [Local SonarQube](./docs/sonarqube-local.md)
- [FLEX Architecture Draw.io](./docs/diagrams/flex-architecture.drawio)
- [ADR: RPT Integration Approach](./docs/adr/rpt-integration-approach.md)
- [ADR: RabbitMQ Message Broker](./docs/adr/rabbitmq-message-broker.md)

## Architecture Rule

The backend is a modulith, not microservices on day one. FLEX is first a consuming decision layer, not a replacement for every source system.

Business modules must keep strict boundaries and own their persistence access. Source-system adapters must be explicit and backend-only. RabbitMQ, ECS, ECR, write-back, and service extraction require separate production decisions.
