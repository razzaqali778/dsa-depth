#!/usr/bin/env node
/**
 * check-staged-tests.js
 *
 * Checks that every staged source file has a corresponding test file.
 * Blocks the commit if any staged source file is missing a test.
 *
 * Exempt patterns and auto-scaffold paths are configured in /.test-exempt.json.
 *
 * Convention: for every foo.ts there must be a foo.spec.ts or foo.test.ts
 * in the same directory (or a __tests__ subdirectory).
 */

const { execFileSync, execSync } = require("child_process");
const { existsSync, readFileSync } = require("fs");
const { dirname, basename, join, extname } = require("path");
const { scaffoldTestStub } = require("./scaffold-test-stub");

const root = join(__dirname, "..");

// Load exempt patterns from config file
const exemptConfigPath = join(root, ".test-exempt.json");
let exemptGlobs = [];
let autoScaffoldGlobs = [];
try {
  const config = JSON.parse(readFileSync(exemptConfigPath, "utf8"));
  exemptGlobs = config.patterns || [];
  autoScaffoldGlobs = config.autoScaffold || [];
} catch (_) {
  // No config file — no exemptions
}

/**
 * Convert a simple glob pattern to a regex.
 * Supports: * (any chars except /), ** (any chars including /), ? (single char)
 */
function globToRegex(glob) {
  const escaped = glob
    .replace(/[.+^${}()|[\]\\]/g, "\\$&") // escape regex special chars
    .replace(/\*\*/g, "§DOUBLESTAR§") // placeholder for **
    .replace(/\*/g, "[^/\\\\]*") // * = anything except path separator
    .replace(/§DOUBLESTAR§/g, ".*") // ** = anything including separators
    .replace(/\?/g, "[^/\\\\]"); // ? = single non-separator char
  return new RegExp(escaped);
}

const exemptPatterns = exemptGlobs.map(globToRegex);
const autoScaffoldPatterns = autoScaffoldGlobs.map(globToRegex);

function isExempt(filePath) {
  // Normalise to forward slashes for consistent matching
  const normalised = filePath.replace(/\\/g, "/");
  return exemptPatterns.some((pattern) => pattern.test(normalised));
}

function shouldAutoScaffold(filePath) {
  const normalised = filePath.replace(/\\/g, "/");
  return autoScaffoldPatterns.some((pattern) => pattern.test(normalised));
}

function isTestFile(filePath) {
  return /\.(spec|test)\.[jt]sx?$/.test(filePath);
}

function findTestFile(filePath) {
  const dir = dirname(filePath);
  const ext = extname(filePath);
  const base = basename(filePath, ext);

  const candidates = [
    join(dir, `${base}.spec${ext}`),
    join(dir, `${base}.test${ext}`),
    join(dir, `${base}.spec.ts`),
    join(dir, `${base}.test.ts`),
    join(dir, "__tests__", `${base}.spec${ext}`),
    join(dir, "__tests__", `${base}.test${ext}`),
    join(dir, "__tests__", `${base}.spec.ts`),
    join(dir, "__tests__", `${base}.test.ts`),
  ];

  return candidates.find(existsSync) || null;
}

// Get staged files from git
let stagedFiles;
try {
  const output = execSync("git diff --cached --name-only --diff-filter=ACM", {
    cwd: root,
    encoding: "utf8",
  });
  stagedFiles = output.trim().split("\n").filter(Boolean);
} catch (_) {
  process.exit(0);
}

// Filter to source files only (TypeScript/JavaScript, not test files, not exempt)
const sourceFiles = stagedFiles.filter((f) => {
  if (!/\.[jt]sx?$/.test(f)) return false;
  if (isTestFile(f)) return false;
  if (isExempt(f)) return false;
  return true;
});

if (sourceFiles.length === 0) {
  process.exit(0);
}

// Auto-scaffold bootstrap/platform tests when configured
const scaffolded = [];
for (const relPath of sourceFiles) {
  if (!shouldAutoScaffold(relPath)) continue;
  const absPath = join(root, relPath);
  if (findTestFile(absPath)) continue;

  const created = scaffoldTestStub(root, relPath);
  if (created) {
    execFileSync("git", ["add", "--", created], { cwd: root });
    scaffolded.push(created);
  }
}

if (scaffolded.length > 0) {
  console.log("");
  console.log("🧩 Auto-scaffolded test stubs for bootstrap/platform files:");
  for (const f of scaffolded) {
    console.log(`  + ${f}`);
  }
  console.log("  Review the generated specs and strengthen assertions when you can.");
  console.log("");
}

// Check each source file for a corresponding test file
const missing = [];

for (const relPath of sourceFiles) {
  const absPath = join(root, relPath);
  const testFile = findTestFile(absPath);
  if (!testFile) {
    missing.push(relPath);
  }
}

if (missing.length === 0) {
  console.log("✔ All staged source files have a corresponding test file.");
  process.exit(0);
}

// Block the commit and guide the developer
console.error("");
console.error("✖ Commit blocked — the following staged files have NO test file:");
console.error("");

for (const f of missing) {
  const dir = dirname(f);
  const ext = extname(f);
  const base = basename(f, ext);
  const suggestedTest = join(dir, `${base}.spec${ext}`);

  console.error(`  📄 ${f}`);
  console.error(`     → Create: ${suggestedTest}`);
  console.error("");
}

console.error("  Write at least one test for each file above, then commit again.");
console.error("  To exempt a file type, add its pattern to .test-exempt.json");
if (autoScaffoldGlobs.length > 0) {
  console.error("  Platform/bootstrap paths auto-scaffold — see autoScaffold in .test-exempt.json");
}
console.error("");

process.exit(1);
