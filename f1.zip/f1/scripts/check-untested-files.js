#!/usr/bin/env node
/**
 * check-untested-files.js
 *
 * Reads coverage-summary.json from each app's coverage output and prints
 * any source file that has 0% line coverage — i.e. no tests at all.
 *
 * Exit code 0 always (informational only — does not block the push).
 * To make it blocking, change the final process.exit(0) to process.exit(1).
 */

const { readFileSync, existsSync } = require("fs");
const { resolve, relative } = require("path");

const root = resolve(__dirname, "..");

const summaryFiles = [
  resolve(root, "apps/api/coverage/coverage-summary.json"),
  resolve(root, "apps/web/coverage/coverage-summary.json"),
];

let foundUntested = false;

for (const summaryPath of summaryFiles) {
  if (!existsSync(summaryPath)) {
    continue;
  }

  const summary = JSON.parse(readFileSync(summaryPath, "utf8"));

  const untestedFiles = Object.entries(summary)
    .filter(([file]) => file !== "total")
    .filter(([, data]) => data.lines.pct === 0 || data.lines.covered === 0)
    .map(([file]) => relative(root, file));

  if (untestedFiles.length > 0) {
    foundUntested = true;
    console.log("");
    console.log("⚠️  Files with NO test coverage (0% lines covered):");
    for (const f of untestedFiles) {
      console.log(`   • ${f}`);
    }
  }
}

if (!foundUntested) {
  console.log("✔ All source files have at least some test coverage.");
}

console.log("");
process.exit(0); // informational — change to exit(1) to make it blocking
