#!/usr/bin/env node
/**
 * Scaffold a minimal Vitest spec file next to a source file.
 * Used by check-staged-tests.js for platform/bootstrap paths.
 */

const { writeFileSync } = require("fs");
const { dirname, basename, join, extname } = require("path");

function specPathFor(relPath) {
  const dir = dirname(relPath);
  const ext = extname(relPath);
  const base = basename(relPath, ext);
  return join(dir, `${base}.spec${ext}`);
}

function buildSpecContent(relPath) {
  const ext = extname(relPath);
  const base = basename(relPath, ext);
  const importPath = `./${base}`;

  if (ext === ".tsx") {
    return `import { describe, it, expect } from "vitest";

describe("${base}", () => {
  it("exports without throwing", async () => {
    await expect(import("${importPath}")).resolves.toBeDefined();
  });
});
`;
  }

  return `import { describe, it, expect } from "vitest";

describe("${base}", () => {
  it("exports without throwing", async () => {
    await expect(import("${importPath}")).resolves.toBeDefined();
  });
});
`;
}

/**
 * @param {string} root - repo root
 * @param {string} relPath - source file path relative to root
 * @returns {string | null} relative path of created spec, or null if skipped
 */
function scaffoldTestStub(root, relPath) {
  const specRel = specPathFor(relPath);
  const specAbs = join(root, specRel);

  try {
    writeFileSync(specAbs, buildSpecContent(relPath), { encoding: "utf8", flag: "wx" });
    return specRel;
  } catch (err) {
    if (err && err.code === "EEXIST") {
      return null;
    }
    throw err;
  }
}

module.exports = { scaffoldTestStub, specPathFor };
