#!/usr/bin/env bash
set -euo pipefail
"$(dirname "${BASH_SOURCE[0]}")/npm-from-safe-cwd.sh" install "$@"
