#!/usr/bin/env bash
set -euo pipefail

sed_inplace() {
  if [[ "$(uname -s)" == "Darwin" ]]; then
    sed -i '' "$@"
  else
    sed -i "$@"
  fi
}

module="${1:-}"

if [[ -z "$module" ]]; then
  echo "Usage: npm run module -- <module-name>"
  echo "       make module MODULE=<module-name>"
  exit 1
fi

if [[ ! "$module" =~ ^[a-z][a-z0-9-]*$ ]]; then
  echo "MODULE must be kebab-case, for example people-planning"
  exit 1
fi

# ── Derived names ──────────────────────────────────────────────────────────────
class_name="$(printf '%s' "$module" | awk -F- '{ for (i = 1; i <= NF; i++) { printf toupper(substr($i,1,1)) substr($i,2) } }')"
constant_prefix="$(printf '%s' "$module" | tr '[:lower:]-' '[:upper:]_')"
camel_name="$(printf '%s' "$class_name" | awk '{ print tolower(substr($0,1,1)) substr($0,2) }')"
definition_name="${camel_name}Definition"
state_key="${camel_name}"
api_dir="apps/api/src/modules/$module"
web_dir="apps/web/src/modules/$module"

# ── Create directory structure ─────────────────────────────────────────────────
mkdir -p \
  "$api_dir/application/ports" \
  "$api_dir/application/services" \
  "$api_dir/domain/events" \
  "$api_dir/infrastructure/events" \
  "$api_dir/infrastructure/integrations" \
  "$api_dir/infrastructure/persistence" \
  "$api_dir/presentation/controllers" \
  "$api_dir/presentation/dto" \
  "$web_dir/api" \
  "$web_dir/pages" \
  "$web_dir/state" \
  "$web_dir/types"

# ── API: NestJS module class ───────────────────────────────────────────────────
if [[ ! -f "$api_dir/$module.module.ts" ]]; then
  cat > "$api_dir/$module.module.ts" <<EOF
import { Module } from "@nestjs/common";
import { ${class_name}Service } from "./application/services/$module.service";
import { ${class_name}Controller } from "./presentation/controllers/$module.controller";

@Module({
  controllers: [${class_name}Controller],
  providers: [${class_name}Service],
})
export class ${class_name}Module {}
EOF
fi

# ── API: Module definition ─────────────────────────────────────────────────────
if [[ ! -f "$api_dir/$module.definition.ts" ]]; then
  cat > "$api_dir/$module.definition.ts" <<EOF
import type { FlexModuleDefinition } from "../../platform/modules/flex-module.definition";
import { ${class_name}Module } from "./$module.module";

export const ${definition_name}: FlexModuleDefinition = {
  key: "$module",
  displayName: "$class_name",
  route: "/api/$module",

  nestModule: ${class_name}Module,
  enabled: true,
  databasePoolSize: 5,

  databaseBoundary: "$class_name DB",
  databaseName: "flex_${module//-/_}",
  databaseUrlEnvVar: "${constant_prefix}_DATABASE_URL",
  responsibilities: [],
  sourceIntegrations: [],
  publishesEvents: [],
  consumesEvents: [],
};
EOF
fi

# ── API: Service ───────────────────────────────────────────────────────────────
if [[ ! -f "$api_dir/application/services/$module.service.ts" ]]; then
  cat > "$api_dir/application/services/$module.service.ts" <<EOF
import { Injectable } from "@nestjs/common";
import { Traced } from "../../../../platform/telemetry/traced.decorator";
import { ${definition_name} } from "../../$module.definition";
import type { ${class_name}SummaryResponseDto } from "../../presentation/dto/$module-summary.response";

@Injectable()
export class ${class_name}Service {
  @Traced("${class_name}Service.getSummary")
  async getSummary(): Promise<${class_name}SummaryResponseDto> {
    return {
      module: ${definition_name}.key,
      displayName: ${definition_name}.displayName,
      route: ${definition_name}.route,
      responsibilities: ${definition_name}.responsibilities,
      sourceIntegrations: ${definition_name}.sourceIntegrations,
      databaseBoundary: ${definition_name}.databaseBoundary,
      databaseName: ${definition_name}.databaseName,
      databaseUrlEnvVar: ${definition_name}.databaseUrlEnvVar,
      publishesEvents: ${definition_name}.publishesEvents,
      consumesEvents: ${definition_name}.consumesEvents,
      currentPhase: "boilerplate",
    };
  }
}
EOF
fi

# ── API: Controller ────────────────────────────────────────────────────────────
if [[ ! -f "$api_dir/presentation/controllers/$module.controller.ts" ]]; then
  cat > "$api_dir/presentation/controllers/$module.controller.ts" <<EOF
import { Controller, Get } from "@nestjs/common";
import { ${class_name}Service } from "../../application/services/$module.service";

@Controller("$module")
export class ${class_name}Controller {
  constructor(private readonly ${camel_name}Service: ${class_name}Service) {}

  @Get("summary")
  getSummary() {
    return this.${camel_name}Service.getSummary();
  }
}
EOF
fi

# ── API: DTO ───────────────────────────────────────────────────────────────────
if [[ ! -f "$api_dir/presentation/dto/$module-summary.response.ts" ]]; then
  cat > "$api_dir/presentation/dto/$module-summary.response.ts" <<EOF
import type { SourceIntegrationDefinition } from "../../../../platform/modules/flex-module.definition";

export type ${class_name}SummaryResponseDto = {
  module: string;
  displayName: string;
  route: string;
  responsibilities: string[];
  sourceIntegrations: SourceIntegrationDefinition[];
  databaseBoundary: string;
  databaseName: string;
  databaseUrlEnvVar: string;
  publishesEvents: string[];
  consumesEvents: string[];
  currentPhase: "boilerplate";
};
EOF
fi

# ── API: Ports ─────────────────────────────────────────────────────────────────
if [[ ! -f "$api_dir/application/ports/$module-repository.port.ts" ]]; then
  cat > "$api_dir/application/ports/$module-repository.port.ts" <<EOF
import type { CanonicalSnapshot } from "../../../../platform/database/module-database.port";

export interface ${class_name}RepositoryPort<TRecord = unknown> {
  saveSnapshot(snapshot: CanonicalSnapshot<TRecord>): Promise<void>;
}
EOF
fi

if [[ ! -f "$api_dir/application/ports/$module-source-adapter.port.ts" ]]; then
  cat > "$api_dir/application/ports/$module-source-adapter.port.ts" <<EOF
import type { SourceAdapterPort } from "../../../../platform/integration/source-adapter.port";

export type ${class_name}SourceAdapterPort<TRecord = unknown> = SourceAdapterPort<TRecord>;
EOF
fi

if [[ ! -f "$api_dir/application/ports/$module-event-publisher.port.ts" ]]; then
  cat > "$api_dir/application/ports/$module-event-publisher.port.ts" <<EOF
import type { IntegrationEvent } from "../../../../platform/messaging/integration-event";

export interface ${class_name}EventPublisherPort {
  publish<TPayload>(event: IntegrationEvent<TPayload>): Promise<void>;
}
EOF
fi

# ── API: Domain event ──────────────────────────────────────────────────────────
if [[ ! -f "$api_dir/domain/events/$module-snapshot-stored.event.ts" ]]; then
  cat > "$api_dir/domain/events/$module-snapshot-stored.event.ts" <<EOF
export const ${constant_prefix}_SNAPSHOT_STORED_EVENT = "$module.snapshot-stored.v1";

export type ${class_name}SnapshotStoredEventPayload = {
  sourceSystem: string;
  capturedAt: string;
  recordCount: number;
};
EOF
fi

# ── API: Domain event test ─────────────────────────────────────────────────────
if [[ ! -f "$api_dir/domain/events/$module-domain-events.spec.ts" ]]; then
  cat > "$api_dir/domain/events/$module-domain-events.spec.ts" <<EOF
import { ${constant_prefix}_SNAPSHOT_STORED_EVENT } from "./$module-snapshot-stored.event";

describe("$module domain events", () => {
  it("exports the snapshot stored event name", () => {
    expect(${constant_prefix}_SNAPSHOT_STORED_EVENT).toBe("$module.snapshot-stored.v1");
  });
});
EOF
fi

# ── API: Infrastructure READMEs ────────────────────────────────────────────────
if [[ ! -f "$api_dir/infrastructure/integrations/README.md" ]]; then
  cat > "$api_dir/infrastructure/integrations/README.md" <<EOF
# $class_name Integrations

External API clients and canonical mappers owned by $class_name belong here.
EOF
fi

if [[ ! -f "$api_dir/infrastructure/persistence/README.md" ]]; then
  cat > "$api_dir/infrastructure/persistence/README.md" <<EOF
# $class_name Persistence

Repository implementations for the flex_${module//-/_} physical database belong here.
EOF
fi

if [[ ! -f "$api_dir/infrastructure/events/README.md" ]]; then
  cat > "$api_dir/infrastructure/events/README.md" <<EOF
# $class_name Events

Outbox, EventBus publisher, and subscriber implementations owned by $class_name belong here.
EOF
fi

# ── API: Service test ──────────────────────────────────────────────────────────
if [[ ! -f "$api_dir/application/services/$module.service.spec.ts" ]]; then
  cat > "$api_dir/application/services/$module.service.spec.ts" <<EOF
import { ${class_name}Service } from "./$module.service";
import { ${definition_name} } from "../../$module.definition";

describe("${class_name}Service", () => {
  const service = new ${class_name}Service();

  it("returns the $module module summary", async () => {
    await expect(service.getSummary()).resolves.toEqual({
      module: ${definition_name}.key,
      displayName: ${definition_name}.displayName,
      route: ${definition_name}.route,
      responsibilities: ${definition_name}.responsibilities,
      sourceIntegrations: ${definition_name}.sourceIntegrations,
      databaseBoundary: ${definition_name}.databaseBoundary,
      databaseName: ${definition_name}.databaseName,
      databaseUrlEnvVar: ${definition_name}.databaseUrlEnvVar,
      publishesEvents: ${definition_name}.publishesEvents,
      consumesEvents: ${definition_name}.consumesEvents,
      currentPhase: "boilerplate",
    });
  });
});
EOF
fi

# ── API: Controller test ───────────────────────────────────────────────────────
if [[ ! -f "$api_dir/presentation/controllers/$module.controller.spec.ts" ]]; then
  cat > "$api_dir/presentation/controllers/$module.controller.spec.ts" <<EOF
import { vi } from "vitest";
import { ${class_name}Controller } from "./$module.controller";
import type { ${class_name}Service } from "../../application/services/$module.service";

describe("${class_name}Controller", () => {
  it("delegates summary requests to ${class_name}Service", async () => {
    const summary = { module: "$module", currentPhase: "boilerplate" };
    const ${camel_name}Service = {
      getSummary: vi.fn().mockResolvedValue(summary),
    } as unknown as ${class_name}Service;
    const controller = new ${class_name}Controller(${camel_name}Service);

    await expect(controller.getSummary()).resolves.toBe(summary);
    expect(${camel_name}Service.getSummary).toHaveBeenCalledTimes(1);
  });
});
EOF
fi

# ── Web: API client ────────────────────────────────────────────────────────────
if [[ ! -f "$web_dir/api/$module.api.ts" ]]; then
  cat > "$web_dir/api/$module.api.ts" <<EOF
import { apiGatewayClient } from "../../../shared/api/api-gateway.client";
import type { ${class_name}Summary } from "../types/$module.types";

export function get${class_name}Summary(signal?: AbortSignal) {
  return apiGatewayClient.get<${class_name}Summary>("/$module/summary", { signal });
}
EOF
fi

# ── Web: Types ─────────────────────────────────────────────────────────────────
if [[ ! -f "$web_dir/types/$module.types.ts" ]]; then
  cat > "$web_dir/types/$module.types.ts" <<EOF
export type ${class_name}SourceIntegration = {
  sourceSystem: string;
  direction: "read-only" | "write-back-future";
  adapterBoundary: string;
  ownedByModule: boolean;
};

export type ${class_name}Summary = {
  module: string;
  displayName: string;
  route: string;
  responsibilities: string[];
  sourceIntegrations: ${class_name}SourceIntegration[];
  databaseBoundary: string;
  databaseName: string;
  databaseUrlEnvVar: string;
  publishesEvents: string[];
  consumesEvents: string[];
  currentPhase: string;
};

export type ${class_name}Status = "idle" | "loading" | "succeeded" | "failed";

export type ${class_name}State = {
  status: ${class_name}Status;
  selectedId?: string;
  error?: string;
};
EOF
fi

# ── Web: Redux slice ───────────────────────────────────────────────────────────
if [[ ! -f "$web_dir/state/$module.slice.ts" ]]; then
  cat > "$web_dir/state/$module.slice.ts" <<EOF
import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { ${class_name}State, ${class_name}Status } from "../types/$module.types";

const initialState: ${class_name}State = {
  status: "idle",
};

const ${state_key}Slice = createSlice({
  name: "$module",
  initialState,
  reducers: {
    statusChanged: (state, action: PayloadAction<${class_name}Status>) => {
      state.status = action.payload;
    },
    selectedIdChanged: (state, action: PayloadAction<string | undefined>) => {
      state.selectedId = action.payload;
    },
    errorChanged: (state, action: PayloadAction<string | undefined>) => {
      state.error = action.payload;
    },
  },
});

export const { statusChanged, selectedIdChanged, errorChanged } = ${state_key}Slice.actions;
export const ${state_key}Reducer = ${state_key}Slice.reducer;
EOF
fi

# ── Web: Page component ────────────────────────────────────────────────────────
if [[ ! -f "$web_dir/pages/$module-page.tsx" ]]; then
  cat > "$web_dir/pages/$module-page.tsx" <<EOF
import { useAppSelector } from "../../../shared/hooks/redux";

export function ${class_name}Page() {
  const status = useAppSelector((state) => state.${state_key}.status);

  return (
    <section className="page-stack">
      <div>
        <span className="eyebrow">$class_name</span>
        <h1>$class_name</h1>
        <p className="page-copy">Status: {status}</p>
      </div>
    </section>
  );
}
EOF
fi

# ── Web: API client test ───────────────────────────────────────────────────────
if [[ ! -f "$web_dir/api/$module.api.spec.ts" ]]; then
  cat > "$web_dir/api/$module.api.spec.ts" <<EOF
import { vi } from "vitest";
import { apiGatewayClient } from "../../../shared/api/api-gateway.client";
import { get${class_name}Summary } from "./$module.api";

vi.mock("../../../shared/api/api-gateway.client", () => ({
  apiGatewayClient: { get: vi.fn() },
}));

describe("$module api", () => {
  it("requests the module summary", () => {
    get${class_name}Summary();

    expect(apiGatewayClient.get).toHaveBeenCalledWith("/$module/summary", { signal: undefined });
  });
});
EOF
fi

# ── Web: Page component test ───────────────────────────────────────────────────
if [[ ! -f "$web_dir/pages/$module-page.spec.tsx" ]]; then
  cat > "$web_dir/pages/$module-page.spec.tsx" <<EOF
import { configureStore } from "@reduxjs/toolkit";
import { render, screen } from "@testing-library/react";
import { Provider } from "react-redux";
import { ${class_name}Page } from "./$module-page";
import { ${state_key}Reducer } from "../state/$module.slice";

describe("${class_name}Page", () => {
  it("renders the module status", () => {
    const store = configureStore({ reducer: { ${state_key}: ${state_key}Reducer } });

    render(
      <Provider store={store}>
        <${class_name}Page />
      </Provider>,
    );

    expect(screen.getByRole("heading", { name: "$class_name" })).toBeInTheDocument();
    expect(screen.getByText(/Status: idle/)).toBeInTheDocument();
  });
});
EOF
fi

# ══════════════════════════════════════════════════════════════════════════════
# Auto-register in all 6 framework files
# ══════════════════════════════════════════════════════════════════════════════

CATALOG_FILE="apps/api/src/platform/modules/flex-module.catalog.ts"
BOUNDARIES_FILE="apps/api/src/platform/database/module-database-boundaries.ts"
DB_INIT_FILE="docker/postgres/init-module-databases.sh"
ROUTER_FILE="apps/web/src/app/router/app-router.tsx"
REDUCERS_FILE="apps/web/src/app/store/module-reducers.ts"
SHELL_FILE="apps/web/src/app/layouts/app-shell.tsx"
database_name="flex_${module//-/_}"

# ── 1. Register in flex-module.catalog.ts ─────────────────────────────────────
if grep -q "\"$module\":" "$CATALOG_FILE"; then
  echo "  ↳ Catalog already contains \"$module\", skipping"
else
  if ! grep -q "${definition_name}" "$CATALOG_FILE"; then
    sed_inplace "/^import type { FlexModuleDefinition }/a\\
import { ${definition_name} } from \"../../modules/$module/$module.definition\";
" "$CATALOG_FILE"
  fi

  if grep -q "FLEX_MODULE_CATALOG: Record<string, FlexModuleDefinition> = {};" "$CATALOG_FILE"; then
    sed_inplace "s/FLEX_MODULE_CATALOG: Record<string, FlexModuleDefinition> = {};/FLEX_MODULE_CATALOG: Record<string, FlexModuleDefinition> = {\\
  \"$module\": ${definition_name},\\
};/" "$CATALOG_FILE"
  else
    sed_inplace "/^export const FLEX_MODULE_CATALOG/,/^};/ s/^};$/  \"$module\": ${definition_name},\\
};/" "$CATALOG_FILE"
  fi
  echo "  ✓ Registered in flex-module.catalog.ts"
fi

# ── 2. Register database boundary ─────────────────────────────────────────────
if grep -q "$database_name" "$BOUNDARIES_FILE"; then
  echo "  ↳ Database boundaries already contains $database_name, skipping"
else
  sed_inplace "/^];$/i\\
  {\\
    owner: \"$class_name\",\\
    databaseName: \"$database_name\",\\
    envVar: \"${constant_prefix}_DATABASE_URL\",\\
  },
" "$BOUNDARIES_FILE"
  echo "  ✓ Registered $database_name in module-database-boundaries.ts"
fi

# ── 3. Register database in docker init script ────────────────────────────────
if grep -q "$database_name" "$DB_INIT_FILE"; then
  echo "  ↳ init-module-databases.sh already contains $database_name, skipping"
else
  printf '\ncreate_database %s\n' "$database_name" >> "$DB_INIT_FILE"
  echo "  ✓ Added create_database $database_name to init-module-databases.sh"
fi

# ── 4. Register route in app-router.tsx ───────────────────────────────────────
if grep -q "path=\"/$module\"" "$ROUTER_FILE"; then
  echo "  ↳ Router already contains /$module, skipping"
else
  if ! grep -q "${class_name}Page" "$ROUTER_FILE"; then
    sed_inplace "/^import { AppShell }/a\\
import { ${class_name}Page } from \"../../modules/$module/pages/$module-page\";
" "$ROUTER_FILE"
  fi

  sed_inplace "s|<Route path=\"/\" element={<div className=\"page-stack\"><h1>Welcome to FLEX</h1></div>} />|<Route path=\"/\" element={<div className=\"page-stack\"><h1>Welcome to FLEX</h1></div>} />\\
        <Route path=\"/$module\" element={<${class_name}Page />} />|" "$ROUTER_FILE"
  echo "  ✓ Registered route /$module in app-router.tsx"
fi

# ── 5. Register reducer in module-reducers.ts ─────────────────────────────────
if grep -q "${state_key}Reducer" "$REDUCERS_FILE"; then
  echo "  ↳ Reducers already contains ${state_key}Reducer, skipping"
else
  if grep -q "export const moduleReducers = {};" "$REDUCERS_FILE"; then
    sed_inplace "s|export const moduleReducers = {};|import { ${state_key}Reducer } from \"../../modules/$module/state/$module.slice\";\\
\\
export const moduleReducers = {\\
  ${state_key}: ${state_key}Reducer,\\
};|" "$REDUCERS_FILE"
  else
    if ! grep -q "${state_key}Reducer" "$REDUCERS_FILE"; then
      sed_inplace "1i\\
import { ${state_key}Reducer } from \"../../modules/$module/state/$module.slice\";
" "$REDUCERS_FILE"
    fi
    sed_inplace "/^export const moduleReducers = {/,/^};/ s/^};$/  ${state_key}: ${state_key}Reducer,\\
};/" "$REDUCERS_FILE"
  fi
  echo "  ✓ Registered ${state_key}Reducer in module-reducers.ts"
fi

# ── 6. Add nav link in app-shell.tsx ──────────────────────────────────────────
if grep -q "to: \"/$module\"" "$SHELL_FILE"; then
  echo "  ↳ AppShell nav already contains /$module, skipping"
else
  if grep -q "const NAV_LINKS" "$SHELL_FILE"; then
    if ! grep -q "BriefcaseBusiness" "$SHELL_FILE"; then
      sed_inplace 's/import { type LucideIcon } from "lucide-react";/import { BriefcaseBusiness, type LucideIcon } from "lucide-react";/' "$SHELL_FILE"
    fi
    sed_inplace "/^const NAV_LINKS/,/^];/ s/^];$/  { to: \"\/$module\", label: \"$class_name\", icon: BriefcaseBusiness },\\
];/" "$SHELL_FILE"
  else
    echo "  ⚠ app-shell.tsx is missing NAV_LINKS — add nav link for /$module manually"
  fi
  echo "  ✓ Added nav link for $class_name in app-shell.tsx"
fi

echo ""
echo "✅ Created FLEX module boilerplate for: $module"
echo "   Includes Vitest specs for service, controller, API client, and page."
echo ""
echo "Manual steps still required:"
echo "  1. Copy .env.example to .env if you have not already"
echo "  2. (Optional) Replace the generic BriefcaseBusiness icon in app-shell.tsx"
echo "       with a more appropriate lucide-react icon for $class_name"
