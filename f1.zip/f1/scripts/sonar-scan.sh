#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

if [[ -f "${ROOT}/.flex/sonar/dev-credentials.env" ]]; then
  set -a
  # shellcheck disable=SC1091
  source "${ROOT}/.flex/sonar/dev-credentials.env"
  set +a
fi

SONAR_CLOUD="${SONAR_CLOUD:-false}"
SONAR_PROJECT_KEY="${SONAR_PROJECT_KEY:-flex}"
SONAR_SCAN_STRICT="${SONAR_SCAN_STRICT:-false}"
SONAR_ADMIN_USER="${SONAR_ADMIN_USER:-admin}"
SONAR_ADMIN_PASSWORD="${SONAR_ADMIN_PASSWORD:-Flex-Sonar-Dev1}"

if [[ "$SONAR_CLOUD" == "true" ]]; then
  SONAR_HOST_URL="${SONAR_HOST_URL:-https://sonarcloud.io}"
  if [[ -z "${SONAR_ORGANIZATION:-}" ]]; then
    echo "⚠ SONAR_CLOUD=true but SONAR_ORGANIZATION is not set — skipping scan"
    exit 0
  fi
fi

SONAR_HOST_URL="${SONAR_HOST_URL:-http://localhost:9000}"

if ! curl -sf "${SONAR_HOST_URL}/api/system/status" > /dev/null 2>&1; then
  echo "⚠ SonarQube unreachable at ${SONAR_HOST_URL}"
  echo "  Start local server: make up  (or make sonar)"
  if [[ "$SONAR_SCAN_STRICT" == "true" ]]; then
    exit 1
  fi
  exit 0
fi

if [[ -z "${SONAR_TOKEN:-}" ]]; then
  if [[ -f "${ROOT}/scripts/ops/sonar-bootstrap.sh" ]]; then
    "${ROOT}/scripts/ops/sonar-bootstrap.sh" || true
    if [[ -f "${ROOT}/.flex/sonar/dev-credentials.env" ]]; then
      set -a
      # shellcheck disable=SC1091
      source "${ROOT}/.flex/sonar/dev-credentials.env"
      set +a
    fi
  fi
fi

if [[ -z "${SONAR_TOKEN:-}" ]]; then
  echo "⚠ SONAR_TOKEN not set — skipping Sonar scan"
  echo "  Run: make up  (auto-provisions token to .flex/sonar/dev-credentials.env)"
  exit 0
fi

missing_coverage=0
for report in apps/api/coverage/lcov.info apps/web/coverage/lcov.info; do
  if [[ ! -f "$report" ]]; then
    echo "⚠ Missing coverage report: $report (run npm run test:coverage first)"
    missing_coverage=1
  fi
done

if [[ "$missing_coverage" -eq 1 ]]; then
  if [[ "$SONAR_SCAN_STRICT" == "true" ]]; then
    exit 1
  fi
  exit 0
fi

scan_args=(
  "-Dsonar.host.url=${SONAR_HOST_URL}"
  "-Dsonar.token=${SONAR_TOKEN}"
  "-Dsonar.projectKey=${SONAR_PROJECT_KEY}"
)

if [[ -n "${SONAR_ORGANIZATION:-}" ]]; then
  scan_args+=("-Dsonar.organization=${SONAR_ORGANIZATION}")
fi

echo "▶ Uploading analysis to ${SONAR_HOST_URL} (project: ${SONAR_PROJECT_KEY})"
npx @sonar/scan "${scan_args[@]}"
echo "✔ Sonar scan complete — ${SONAR_HOST_URL}/dashboard?id=${SONAR_PROJECT_KEY}"
