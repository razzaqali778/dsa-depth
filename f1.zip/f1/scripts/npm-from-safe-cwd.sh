#!/usr/bin/env bash
# macOS blocks getcwd() inside ~/Desktop for Terminal unless the app has
# Desktop folder access. Run npm from $HOME with --prefix instead.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

export NVM_DIR="${NVM_DIR:-$HOME/.nvm}"

with_nvm_lock() {
  local lock_file="$NVM_DIR/.flex-nvm-install.lock"

  if command -v flock >/dev/null 2>&1; then
    exec 9>"$lock_file"
    flock 9
    "$@"
    flock -u 9
    return
  fi

  while ! mkdir "${lock_file}.d" 2>/dev/null; do
    sleep 1
  done

  trap 'rmdir "${lock_file}.d"' RETURN
  "$@"
  trap - RETURN
  rmdir "${lock_file}.d"
}

activate_project_node() {
  if [[ ! -s "$NVM_DIR/nvm.sh" ]]; then
    return
  fi

  # shellcheck source=/dev/null
  source "$NVM_DIR/nvm.sh"

  if [[ ! -f "$ROOT/.nvmrc" ]]; then
    return
  fi

  local node_version
  node_version="$(tr -d '[:space:]' < "$ROOT/.nvmrc")"
  if [[ "$(nvm version "$node_version")" == "N/A" ]]; then
    nvm install "$node_version" >/dev/null
  fi
  nvm use "$node_version" >/dev/null
}

with_nvm_lock activate_project_node

cd "$HOME"
exec npm --prefix "$ROOT" "$@"
