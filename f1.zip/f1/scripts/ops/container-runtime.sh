#!/usr/bin/env bash
# Detect container runtime (podman preferred, then docker) and compose command.
# Usage:
#   source scripts/ops/container-runtime.sh && resolve_container_runtime
#   ./scripts/ops/container-runtime.sh compose   # print compose command only
#   ./scripts/ops/container-runtime.sh runtime   # print runtime name only
#   ./scripts/ops/container-runtime.sh info      # print "runtime|compose"

set -euo pipefail

_resolve_compose_for() {
  local runtime="$1"
  if "$runtime" compose version >/dev/null 2>&1; then
    echo "$runtime compose"
    return 0
  fi
  if command -v "${runtime}-compose" >/dev/null 2>&1; then
    if "${runtime}-compose" version >/dev/null 2>&1; then
      echo "${runtime}-compose"
      return 0
    fi
  fi
  return 1
}

_runtime_daemon_ok() {
  local runtime="$1"
  "$runtime" info >/dev/null 2>&1
}

resolve_container_runtime() {
  local compose="" podman_installed=0 podman_down=0 docker_installed=0 docker_down=0

  if command -v podman >/dev/null 2>&1; then
    podman_installed=1
    if compose="$(_resolve_compose_for podman)"; then
      if _runtime_daemon_ok podman; then
        CONTAINER_RUNTIME="podman"
        COMPOSE="$compose"
        export CONTAINER_RUNTIME COMPOSE
        return 0
      fi
      podman_down=1
    fi
  fi

  if command -v docker >/dev/null 2>&1; then
    docker_installed=1
    if compose="$(_resolve_compose_for docker)"; then
      if _runtime_daemon_ok docker; then
        CONTAINER_RUNTIME="docker"
        COMPOSE="$compose"
        export CONTAINER_RUNTIME COMPOSE
        return 0
      fi
      docker_down=1
    fi
  fi

  echo "✖ No container runtime available." >&2
  if [[ "$podman_installed" -eq 1 && "$podman_down" -eq 1 ]]; then
    echo "  Podman is installed but not running. Try: podman machine start" >&2
  fi
  if [[ "$docker_installed" -eq 1 && "$docker_down" -eq 1 ]]; then
    echo "  Docker is installed but daemon is not running. Try: colima start or Docker Desktop" >&2
  fi
  if [[ "$podman_installed" -eq 0 && "$docker_installed" -eq 0 ]]; then
    echo "  Install Podman (preferred) or Docker with Compose support." >&2
  fi
  return 1
}

# CLI modes for Makefile and scripts
case "${1:-}" in
  compose)
    if resolve_container_runtime; then
      echo "$COMPOSE"
    else
      exit 1
    fi
    ;;
  runtime)
    if resolve_container_runtime; then
      echo "$CONTAINER_RUNTIME"
    else
      exit 1
    fi
    ;;
  info)
    if resolve_container_runtime; then
      echo "${CONTAINER_RUNTIME}|${COMPOSE}"
    else
      exit 1
    fi
    ;;
  "")
    # Sourced without args — caller invokes resolve_container_runtime
    ;;
  *)
    echo "Usage: $0 [compose|runtime|info]" >&2
    exit 1
    ;;
esac
