#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

FLEX_ENV="${FLEX_ENV:-local}"
OBSERVABILITY="${OBSERVABILITY:-1}"
SONAR="${SONAR:-1}"
API_PORT="${API_PORT:-3000}"
WEB_PORT="${WEB_PORT:-5173}"
GRAFANA_PORT="${GRAFANA_PORT:-3001}"
SONAR_PORT="${SONAR_PORT:-9000}"

MAX_WAIT="${MAX_WAIT:-120}"
INTERVAL=2

check_tcp() {
  local port="$1"
  if command -v nc >/dev/null 2>&1; then
    nc -z localhost "$port" 2>/dev/null
    return
  fi
  (exec 3<>"/dev/tcp/127.0.0.1/${port}") >/dev/null 2>&1
}

check_http() {
  curl -sf "$1" >/dev/null 2>&1
}

wait_for() {
  local name="$1"
  shift
  local elapsed=0
  echo -n "  Waiting for ${name}"
  while (( elapsed < MAX_WAIT )); do
    if "$@"; then
      echo " ✓"
      return 0
    fi
    echo -n "."
    sleep "$INTERVAL"
    elapsed=$((elapsed + INTERVAL))
  done
  echo " ✗ timeout"
  return 1
}

echo "▶ Waiting for services to become healthy..."

failed=0

if [[ "$FLEX_ENV" != "cloud" ]]; then
  wait_for "postgres :5432" check_tcp 5432 || failed=1
fi

if [[ "$OBSERVABILITY" == "1" ]]; then
  wait_for "grafana :${GRAFANA_PORT}" check_http "http://localhost:${GRAFANA_PORT}/api/health" || failed=1
  wait_for "otel-collector :13133" check_http "http://localhost:13133/" || failed=1
fi

if [[ "$SONAR" == "1" ]]; then
  SONAR_MAX_WAIT="${SONAR_MAX_WAIT:-300}"
  sonar_ok=0
  MAX_WAIT=$SONAR_MAX_WAIT wait_for "sonarqube :${SONAR_PORT}" check_http "http://localhost:${SONAR_PORT}/api/system/status" && sonar_ok=1 || failed=1
  if [[ "$sonar_ok" -eq 1 ]]; then
    "$ROOT/scripts/ops/sonar-bootstrap.sh" || failed=1
  fi
fi

if [[ "$failed" -ne 0 ]]; then
  echo ""
  echo "⚠ Some services did not become healthy in ${MAX_WAIT}s."
  echo "  Run 'make status' for details. Continuing anyway..."
fi

echo "✔ Health check complete"
