#!/usr/bin/env bash
# Print compose command for Makefile (podman preferred, then docker).
exec "$(dirname "$0")/container-runtime.sh" compose
