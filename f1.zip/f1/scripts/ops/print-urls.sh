#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

API_PORT="${API_PORT:-3000}"
WEB_PORT="${WEB_PORT:-5173}"
GRAFANA_PORT="${GRAFANA_PORT:-3001}"
SONAR_PORT="${SONAR_PORT:-9000}"
SONAR_CREDS="${ROOT}/.flex/sonar/dev-credentials.env"

if [[ -f "$SONAR_CREDS" ]]; then
  set -a
  # shellcheck disable=SC1091
  source "$SONAR_CREDS"
  set +a
fi

echo ""
echo "FLEX local URLs"
echo "────────────────────────────────────────"
echo "  Web app:     http://localhost:${WEB_PORT}/"
echo "  API:         http://localhost:${API_PORT}/api/health"
echo "  Auth:        http://localhost:${API_PORT}/api/auth/summary"
echo "  Grafana:     http://localhost:${GRAFANA_PORT}/"
echo "  Prometheus:  http://localhost:9090/"
echo "  Tempo:       http://localhost:3200/"
echo "  SonarQube:   http://localhost:${SONAR_PORT}/"
if [[ -n "${SONAR_ADMIN_USER:-}" && -n "${SONAR_ADMIN_PASSWORD:-}" ]]; then
  echo ""
  echo "SonarQube (local dev — fixed credentials)"
  echo "  Login:       ${SONAR_ADMIN_USER} / ${SONAR_ADMIN_PASSWORD}"
  if [[ -n "${SONAR_TOKEN:-}" ]]; then
    echo "  Scan token:  ${SONAR_TOKEN}"
    echo "  (also in .flex/sonar/dev-credentials.env)"
  fi
fi
echo "────────────────────────────────────────"
echo ""
