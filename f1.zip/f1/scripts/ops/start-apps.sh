#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

# shellcheck disable=SC1091
source "$ROOT/scripts/ops/process-utils.sh"

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

RUN_DIR="${ROOT}/.flex/run"
mkdir -p "$RUN_DIR"

API_PORT="${API_PORT:-3000}"
WEB_PORT="${WEB_PORT:-5173}"
AUTH_MODE="${AUTH_MODE:-disabled}"
FLEX_BIND_HOST="${FLEX_BIND_HOST:-127.0.0.1}"
REUSE_EXTERNAL_APPS="${REUSE_EXTERNAL_APPS:-0}"
APP_START_TIMEOUT="${APP_START_TIMEOUT:-60}"
APP_START_INTERVAL=2
API_HEALTH_URL="http://127.0.0.1:${API_PORT}/api/health"
WEB_HEALTH_URL="http://127.0.0.1:${WEB_PORT}/"
API_LOG_FILE="$RUN_DIR/api.log"
WEB_LOG_FILE="$RUN_DIR/web.log"

stop_if_running() {
  local pid_file="$1"
  if [[ -f "$pid_file" ]]; then
    local pid
    pid="$(cat "$pid_file")"
    if process_exists "$pid"; then
      echo "  Stopping existing process (pid $pid)..."
      stop_process_tree "$pid"
      sleep 1
    fi
    rm -f "$pid_file"
  fi
}

stop_if_running "$RUN_DIR/api.pid"
stop_if_running "$RUN_DIR/web.pid"

listener_pid_on_port() {
  local port="$1"

  if is_windows_shell; then
    local ps_script
    ps_script=$(cat <<EOF
\$conn = Get-NetTCPConnection -LocalPort ${port} -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if (\$null -ne \$conn) { Write-Output \$conn.OwningProcess }
EOF
)
    powershell.exe -NoProfile -Command "$ps_script" 2>/dev/null | tr -d '\r' || true
    return
  fi

  if command -v lsof >/dev/null 2>&1; then
    lsof -tiTCP:"$port" -sTCP:LISTEN 2>/dev/null | head -n 1 || true
    return
  fi

  ss -ltnp "sport = :${port}" 2>/dev/null \
    | sed -n 's/.*pid=\([0-9][0-9]*\).*/\1/p' \
    | head -n 1 || true
}

stop_port_listener() {
  local name="$1"
  local port="$2"
  local pid

  if [[ "$REUSE_EXTERNAL_APPS" == "1" ]]; then
    return
  fi

  pid="$(listener_pid_on_port "$port")"
  if [[ -n "$pid" ]] && process_exists "$pid"; then
    echo "  Stopping existing ${name} listener on port ${port} (pid ${pid})..."
    stop_process_tree "$pid"
    sleep 1
  fi
}

stop_port_listener "API" "$API_PORT"
stop_port_listener "Web" "$WEB_PORT"

tail_log() {
  local name="$1"
  local log_file="$2"
  echo ""
  echo "Last lines from ${name}:"
  if [[ -f "$log_file" ]]; then
    tail -n 20 "$log_file"
  else
    echo "  (log file missing)"
  fi
}

prepare_log_file() {
  local preferred_path="$1"
  local service_name="$2"
  local log_path="$preferred_path"
  local dir base ext suffix

  if ! : >"$log_path" 2>/dev/null; then
    dir="$(dirname "$preferred_path")"
    base="$(basename "$preferred_path")"
    ext=""
    if [[ "$base" == *.* ]]; then
      ext=".${base##*.}"
      base="${base%.*}"
    fi
    suffix="$(date +%Y%m%d-%H%M%S)"
    log_path="${dir}/${base}-${suffix}${ext}"
    : >"$log_path"
    echo "  ${service_name} log path ${preferred_path} is unavailable; using ${log_path} instead." >&2
  fi

  printf '%s\n' "$log_path"
}

process_alive() {
  local pid_file="$1"
  [[ -f "$pid_file" ]] || return 1
  process_exists "$(cat "$pid_file")"
}

check_http() {
  local url="$1"
  curl -sf --max-time 2 "$url" >/dev/null 2>&1 && return 0

  if command -v powershell.exe >/dev/null 2>&1; then
    local ps_script
    ps_script=$(cat <<EOF
try {
  Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 -Uri '$(escape_powershell "$url")' | Out-Null
  exit 0
} catch {
  exit 1
}
EOF
)
    powershell.exe -NoProfile -Command "$ps_script" >/dev/null 2>&1 && return 0
  fi

  return 1
}

reuse_external_if_healthy() {
  local name="$1"
  local url="$2"
  if [[ "$REUSE_EXTERNAL_APPS" != "1" ]]; then
    return 1
  fi
  if check_http "$url"; then
    echo "  ${name} already healthy on ${url} — reusing external process"
    return 0
  fi
  return 1
}

start_windows_process() {
  local pid_file="$1"
  local log_file="$2"
  local command_line="$3"
  local root_win log_win ps_script pid

  root_win="$(windows_path "$ROOT")"
  log_win="$(windows_path "$log_file")"

  ps_script=$(cat <<EOF
\$proc = Start-Process -FilePath 'cmd.exe' -WorkingDirectory '$(escape_powershell "$root_win")' -ArgumentList '/d','/s','/c','$(escape_powershell "$command_line")' -WindowStyle Hidden -PassThru
Write-Output \$proc.Id
EOF
)

  pid="$(powershell.exe -NoProfile -Command "$ps_script" 2>/dev/null | tr -d '\r')"
  [[ -n "$pid" ]] || return 1
  printf '%s\n' "$pid" >"$pid_file"
}

windows_env_chain() {
  local command=""
  local name

  for name in "$@"; do
    if [[ -n "${!name+x}" ]]; then
      command+="set \"${name}=${!name}\" && "
    fi
  done

  printf '%s' "$command"
}

start_api() {
  if reuse_external_if_healthy "API" "$API_HEALTH_URL"; then
    return
  fi

  API_LOG_FILE="$(prepare_log_file "$API_LOG_FILE" "API")"
  if is_windows_shell; then
    local root_win log_win cmd_line env_chain
    root_win="$(windows_path "$ROOT")"
    log_win="$(windows_path "$API_LOG_FILE")"
    env_chain="$(windows_env_chain \
      API_PORT \
      FLEX_BIND_HOST \
      CORS_ORIGIN \
      AUTH_MODE \
      AUTH_DATABASE_URL \
      INTEGRATION_CONTROL_DATABASE_URL \
      AZURE_TENANT_ID \
      AZURE_API_AUDIENCE \
      AZURE_JWKS_URI \
      AZURE_ISSUER \
      AZURE_ADMIN_ROLES \
      AZURE_PLATFORM_LEAD_ROLES \
      OTEL_SDK_DISABLED \
      OTEL_EXPORTER_OTLP_ENDPOINT \
      OTEL_SERVICE_NAME)"
    cmd_line="${env_chain}call npm.cmd --prefix \"$root_win\" run dev:api >> \"$log_win\" 2>&1"
    start_windows_process "$RUN_DIR/api.pid" "$API_LOG_FILE" "$cmd_line"
    return
  fi

  nohup ./scripts/npm-from-safe-cwd.sh run dev:api >"$API_LOG_FILE" 2>&1 &
  echo $! >"$RUN_DIR/api.pid"
}

start_web() {
  if reuse_external_if_healthy "Web" "$WEB_HEALTH_URL"; then
    return
  fi

  WEB_LOG_FILE="$(prepare_log_file "$WEB_LOG_FILE" "Web")"
  if is_windows_shell; then
    local root_win log_win cmd_line env_chain
    root_win="$(windows_path "$ROOT")"
    log_win="$(windows_path "$WEB_LOG_FILE")"
    env_chain="$(windows_env_chain \
      API_PORT \
      WEB_PORT \
      FLEX_BIND_HOST \
      VITE_AZURE_CLIENT_ID \
      VITE_AZURE_TENANT_ID \
      VITE_AZURE_API_SCOPE \
      VITE_AZURE_REDIRECT_URI \
      VITE_FLEX_API_BASE_URL)"
    cmd_line="${env_chain}call npm.cmd --prefix \"$root_win\" run dev:web >> \"$log_win\" 2>&1"
    start_windows_process "$RUN_DIR/web.pid" "$WEB_LOG_FILE" "$cmd_line"
    return
  fi

  nohup ./scripts/npm-from-safe-cwd.sh run dev:web >"$WEB_LOG_FILE" 2>&1 &
  echo $! >"$RUN_DIR/web.pid"
}

wait_for_http() {
  local name="$1"
  local pid_file="$2"
  local url="$3"
  local log_file="$4"
  local elapsed=0

  echo -n "  Waiting for ${name}"
  while (( elapsed < APP_START_TIMEOUT )); do
    if check_http "$url"; then
      echo " ✓"
      return 0
    fi
    if ! process_alive "$pid_file"; then
      echo " ✗"
      echo "✖ ${name} exited during startup"
      tail_log "$name" "$log_file"
      return 1
    fi
    echo -n "."
    sleep "$APP_START_INTERVAL"
    elapsed=$((elapsed + APP_START_INTERVAL))
  done

  echo " ✗ timeout"
  echo "✖ ${name} did not become ready at ${url}"
  tail_log "$name" "$log_file"
  return 1
}

verify_started_process() {
  local name="$1"
  local pid_file="$2"
  local log_file="$3"

  [[ -f "$pid_file" ]] || return 0

  if ! process_exists "$(cat "$pid_file")"; then
    echo "✖ ${name} exited during startup"
    tail_log "$name" "$log_file"
    return 1
  fi

  return 0
}

echo "▶ Starting API on port ${API_PORT}..."
start_api

echo "▶ Starting Web on port ${WEB_PORT}..."
start_web

failed=0
verify_started_process "API" "$RUN_DIR/api.pid" "$API_LOG_FILE" || failed=1
verify_started_process "Web" "$RUN_DIR/web.pid" "$WEB_LOG_FILE" || failed=1

if [[ "$failed" -ne 0 ]]; then
  exit 1
fi

wait_for_http "API" "$RUN_DIR/api.pid" "$API_HEALTH_URL" "$API_LOG_FILE" || failed=1
wait_for_http "Web" "$RUN_DIR/web.pid" "$WEB_HEALTH_URL" "$WEB_LOG_FILE" || failed=1

if [[ "$failed" -ne 0 ]]; then
  exit 1
fi

echo "✔ Apps started (logs: ${API_LOG_FILE}, ${WEB_LOG_FILE})"
