#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
RUN_DIR="${ROOT}/.flex/run"

# shellcheck disable=SC1091
source "$ROOT/scripts/ops/process-utils.sh"

stop_pid_file() {
  local name="$1"
  local pid_file="$RUN_DIR/${name}.pid"
  if [[ -f "$pid_file" ]]; then
    local pid
    pid="$(cat "$pid_file")"
    if process_exists "$pid"; then
      echo "▶ Stopping ${name} (pid $pid)..."
      stop_process_tree "$pid"
    fi
    rm -f "$pid_file"
  fi
}

stop_pid_file "api"
stop_pid_file "web"

echo "✔ Apps stopped"
