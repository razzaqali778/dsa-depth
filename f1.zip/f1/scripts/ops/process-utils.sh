#!/usr/bin/env bash

is_windows_shell() {
  case "$(uname -s)" in
    MINGW*|MSYS*|CYGWIN*) return 0 ;;
    *) return 1 ;;
  esac
}

windows_path() {
  local path="$1"
  if command -v cygpath >/dev/null 2>&1; then
    cygpath -aw "$path"
  else
    printf '%s\n' "$path"
  fi
}

escape_powershell() {
  printf '%s' "$1" | sed "s/'/''/g"
}

process_exists() {
  local pid="${1:-}"
  [[ -n "$pid" ]] || return 1

  if is_windows_shell; then
    tasklist.exe //FI "PID eq ${pid}" //NH 2>/dev/null \
      | tr -d '\r' \
      | grep -Eq "^[^[:space:]].*[[:space:]]${pid}[[:space:]]"
    return
  fi

  kill -0 "$pid" 2>/dev/null
}

stop_process_tree() {
  local pid="${1:-}"
  process_exists "$pid" || return 0

  if is_windows_shell; then
    taskkill.exe //PID "$pid" //T //F >/dev/null 2>&1 || true
    return
  fi

  kill "$pid" 2>/dev/null || true
  pkill -P "$pid" 2>/dev/null || true
}

process_info_record() {
  local pid="${1:-}"
  process_exists "$pid" || {
    echo "|||"
    return
  }

  if is_windows_shell; then
    local ps_script
    ps_script=$(cat <<EOF
\$p = Get-Process -Id $pid -ErrorAction SilentlyContinue
if (\$null -eq \$p) { exit 1 }
\$elapsed = (Get-Date) - \$p.StartTime
if (\$elapsed.Days -gt 0) {
  \$uptime = '{0}-{1:00}:{2:00}:{3:00}' -f \$elapsed.Days, \$elapsed.Hours, \$elapsed.Minutes, \$elapsed.Seconds
} else {
  \$uptime = '{0:00}:{1:00}:{2:00}' -f \$elapsed.Hours, \$elapsed.Minutes, \$elapsed.Seconds
}
\$rssKb = [int](\$p.WorkingSet64 / 1KB)
Write-Output ("\$uptime|\$rssKb|R")
EOF
)
    powershell.exe -NoProfile -Command "$ps_script" 2>/dev/null | tr -d '\r' || echo "|||"
    return
  fi

  ps -p "$pid" -o etime=,rss=,state= 2>/dev/null \
    | awk '{$1=$1; print $1 "|" $2 "|" $3; exit}' \
    || echo "|||"
}
