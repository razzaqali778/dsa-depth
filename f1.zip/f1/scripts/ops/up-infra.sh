#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

# shellcheck disable=SC1091
source "$ROOT/scripts/ops/container-runtime.sh"
resolve_container_runtime

echo "▶ Using ${CONTAINER_RUNTIME} (${COMPOSE})"

if [[ -f .env ]]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

FLEX_ENV="${FLEX_ENV:-local}"
OBSERVABILITY="${OBSERVABILITY:-1}"
SONAR="${SONAR:-1}"

OBSERVABILITY_SERVICES=(tempo prometheus loki otel-collector grafana)
SONAR_SERVICES=(sonar-db sonarqube)

if [[ "$FLEX_ENV" == "cloud" ]]; then
  echo "▶ FLEX_ENV=cloud — skipping local Postgres container"
else
  echo "▶ Starting Postgres..."
  $COMPOSE up -d postgres
fi

if [[ "$OBSERVABILITY" == "1" ]]; then
  echo "▶ Starting observability stack (Grafana, Tempo, Prometheus, Loki, OTEL)..."
  $COMPOSE --profile observability up -d "${OBSERVABILITY_SERVICES[@]}"
fi

if [[ "$SONAR" == "1" ]]; then
  echo "▶ Starting SonarQube..."
  $COMPOSE --profile sonar up -d "${SONAR_SERVICES[@]}"
fi

echo "✔ Infrastructure started"
