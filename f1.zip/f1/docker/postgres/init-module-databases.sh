#!/usr/bin/env sh
set -eu

create_database() {
  database="$1"
  psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<SQL
SELECT 'CREATE DATABASE $database'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '$database')\gexec
SQL
}

create_database flex_outcomes
create_database flex_business_usecase
create_database flex_finops
create_database flex_people_planning
create_database flex_integration_control

create_database flex_auth
