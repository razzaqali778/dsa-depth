# ═══════════════════════════════════════════════════════════════════════════════
# outputs.tf — Flex Infrastructure Outputs
# ═══════════════════════════════════════════════════════════════════════════════

output "alb_dns_name" {
  description = "Internal ALB DNS — accessible via Bayer VPN/TGW only"
  value       = aws_lb.main.dns_name
}

output "ecs_cluster_name" {
  description = "ECS cluster name"
  value       = aws_ecs_cluster.main.name
}

output "ecs_service_name" {
  description = "ECS service name"
  value       = aws_ecs_service.main.name
}

output "web_ecr_url" {
  description = "ECR URL for web app (apps/web — Dockerfile.web)"
  value       = aws_ecr_repository.web.repository_url
}

output "api_ecr_url" {
  description = "ECR URL for API (apps/api — Dockerfile.api)"
  value       = aws_ecr_repository.api.repository_url
}

output "aurora_endpoint" {
  description = "Aurora cluster write endpoint (private)"
  value       = aws_rds_cluster.main.endpoint
  sensitive   = true
}

output "sns_topic_arn" {
  description = "SNS topic ARN for deployment notifications"
  value       = aws_sns_topic.deployments.arn
}

output "vpc_id" {
  description = "VPC ID provisioned by Bayer VPC module"
  value       = local.vpc_id
}
