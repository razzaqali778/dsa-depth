# ═══════════════════════════════════════════════════════════════════════════════
# main.tf — Flex Infrastructure
# Monorepo structure: apps/api (NestJS) + apps/web (ReactJS)
# Dockerfiles       : Dockerfile.api + Dockerfile.web (both at repo root)
# ECR repos         : flex-{env}-api + flex-{env}-web
# ═══════════════════════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────────────────────
# 1. VPC — Bayer SMART AWS Module
#    Creates VPC, subnets, TGW attachment, CNAT, CGNAT
#    Source: github.com/bayer-int/smart-aws-bayer-vpc-products-terraform
# ─────────────────────────────────────────────────────────────────────────────
module "vpc_cidr_tgw_cnat" {
  count = local.vpc_configuration.use_existing_vpc ? 0 : 1

  source = "github.com/bayer-int/smart-aws-bayer-vpc-products-terraform?ref=22e83bd6605715594db5d5a2c9162c0a532e546e"

  # VPC Configuration
  description   = local.bayer_vpc_config.description
  size          = local.bayer_vpc_config.vpc_size
  subnet_layout = local.bayer_vpc_config.subnet_layout

  # CGNAT
  enable_cgnat    = local.bayer_vpc_config.enable_cgnat
  cgnat_cidr_size = local.bayer_vpc_config.cgnat_cidr_size

  # Service Catalog Flags
  create_vpc   = true   # always true when module is created
  reserve_cidr = true   # always true — required by Bayer module
  attach_tgw   = local.bayer_vpc_config.attach_tgw
  attach_cnat  = local.bayer_vpc_config.attach_cnat

  # Pin versions — prevents unexpected infrastructure updates
  vpc_product_version  = local.bayer_vpc_config.vpc_product_version
  tgw_product_version  = local.bayer_vpc_config.tgw_product_version
  cnat_product_version = local.bayer_vpc_config.cnat_product_version

  # Minimal tags — avoids Service Catalog conflicts
  tags = local.vpc_tags
}

# ─────────────────────────────────────────────────────────────────────────────
# 2. ECR Repositories
#    flex-{env}-web → apps/web (ReactJS) — built from Dockerfile.web
#    flex-{env}-api → apps/api (NestJS)  — built from Dockerfile.api
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_ecr_repository" "web" {
  name                 = local.ecr_config.web_repo
  image_tag_mutability = local.ecr_config.image_tag_mutability
  force_delete         = var.environment != "prod"

  image_scanning_configuration {
    scan_on_push = local.ecr_config.scan_on_push
  }

  encryption_configuration {
    encryption_type = "AES256"
  }

  tags = merge(local.common_tags, {
    Name      = local.ecr_config.web_repo
    Component = "web"
    Source    = "apps/web"
  })
}

resource "aws_ecr_repository" "api" {
  name                 = local.ecr_config.api_repo
  image_tag_mutability = local.ecr_config.image_tag_mutability
  force_delete         = var.environment != "prod"

  image_scanning_configuration {
    scan_on_push = local.ecr_config.scan_on_push
  }

  encryption_configuration {
    encryption_type = "AES256"
  }

  tags = merge(local.common_tags, {
    Name      = local.ecr_config.api_repo
    Component = "api"
    Source    = "apps/api"
  })
}

resource "aws_ecr_lifecycle_policy" "web" {
  repository = aws_ecr_repository.web.name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Keep last ${local.ecr_config.keep_images} images"
      selection    = {
        tagStatus   = "any"
        countType   = "imageCountMoreThan"
        countNumber = local.ecr_config.keep_images
      }
      action = { type = "expire" }
    }]
  })
}

resource "aws_ecr_lifecycle_policy" "api" {
  repository = aws_ecr_repository.api.name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Keep last ${local.ecr_config.keep_images} images"
      selection    = {
        tagStatus   = "any"
        countType   = "imageCountMoreThan"
        countNumber = local.ecr_config.keep_images
      }
      action = { type = "expire" }
    }]
  })
}

# ─────────────────────────────────────────────────────────────────────────────
# 3. Secrets Manager
#    flex/{env}/jwt       → NestJS JWT secret
#    flex/{env}/db        → Aurora credentials
#    flex/{env}/workpath  → Workpath API key (Portfolio module)
#    flex/{env}/planview  → Planview API key (Portfolio module)
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_secretsmanager_secret" "jwt" {
  name                    = "${local.secrets_config.prefix}/jwt"
  description             = "JWT signing secret for Flex API — ${var.environment}"
  recovery_window_in_days = local.secrets_config.recovery_window
  tags                    = local.common_tags
}

resource "aws_secretsmanager_secret_version" "jwt" {
  secret_id     = aws_secretsmanager_secret.jwt.id
  secret_string = jsonencode({ jwt_secret = var.jwt_secret })
}

resource "aws_secretsmanager_secret" "db" {
  name                    = "${local.secrets_config.prefix}/db"
  description             = "Aurora PostgreSQL credentials — ${var.environment}"
  recovery_window_in_days = local.secrets_config.recovery_window
  tags                    = local.common_tags
}

resource "aws_secretsmanager_secret_version" "db" {
  secret_id = aws_secretsmanager_secret.db.id
  secret_string = jsonencode({
    username = local.aurora_config.db_username
    password = var.db_password
  })
}

resource "aws_secretsmanager_secret" "workpath" {
  name                    = "${local.secrets_config.prefix}/workpath"
  description             = "Workpath API credentials — Portfolio module"
  recovery_window_in_days = local.secrets_config.recovery_window
  tags                    = local.common_tags
}

resource "aws_secretsmanager_secret_version" "workpath" {
  secret_id     = aws_secretsmanager_secret.workpath.id
  secret_string = jsonencode({ api_key = var.workpath_api_key })
}

resource "aws_secretsmanager_secret" "planview" {
  name                    = "${local.secrets_config.prefix}/planview"
  description             = "Planview API credentials — Portfolio module"
  recovery_window_in_days = local.secrets_config.recovery_window
  tags                    = local.common_tags
}

resource "aws_secretsmanager_secret_version" "planview" {
  secret_id     = aws_secretsmanager_secret.planview.id
  secret_string = jsonencode({ api_key = var.planview_api_key })
}

# ─────────────────────────────────────────────────────────────────────────────
# 4. IAM Roles
#    ecs-execution → ECS agent: pull ECR images, read Secrets Manager
#    ecs-task      → running app: S3 access, Bedrock (AI agents)
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_iam_role" "ecs_execution" {
  name = "flex-${var.environment}-ecs-execution"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy_attachment" "ecs_execution_managed" {
  role       = aws_iam_role.ecs_execution.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

resource "aws_iam_role_policy" "ecs_execution_secrets" {
  name = "flex-${var.environment}-secrets-read"
  role = aws_iam_role.ecs_execution.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["secretsmanager:GetSecretValue"]
      Resource = "arn:aws:secretsmanager:${var.aws_region}:*:secret:flex/${var.environment}/*"
    }]
  })
}

resource "aws_iam_role" "ecs_task" {
  name = "flex-${var.environment}-ecs-task"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy" "ecs_task_s3" {
  name = "flex-${var.environment}-s3-access"
  role = aws_iam_role.ecs_task.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:ListBucket"]
      Resource = [
        "arn:aws:s3:::flex-${var.environment}-uploads",
        "arn:aws:s3:::flex-${var.environment}-uploads/*"
      ]
    }]
  })
}

resource "aws_iam_role_policy" "ecs_task_bedrock" {
  name = "flex-${var.environment}-bedrock-access"
  role = aws_iam_role.ecs_task.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["bedrock:InvokeModel", "bedrock:InvokeModelWithResponseStream"]
      Resource = "arn:aws:bedrock:${var.aws_region}::foundation-model/*"
    }]
  })
}

# ─────────────────────────────────────────────────────────────────────────────
# 5. Security Groups
#    alb    → ingress 80/443 from Bayer internal (10.0.0.0/8) only
#    ecs    → ingress from ALB security group only
#    aurora → ingress port 5432 from ECS security group only
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_security_group" "alb" {
  name        = "flex-${var.environment}-alb"
  description = "ALB — allow HTTP/HTTPS from Bayer internal network only"
  vpc_id      = local.vpc_id

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
    description = "HTTP from Bayer internal network via TGW"
  }

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
    description = "HTTPS from Bayer internal network via TGW"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow all outbound"
  }

  tags = merge(local.common_tags, { Name = "flex-${var.environment}-alb-sg" })
}

resource "aws_security_group" "ecs" {
  name        = "flex-${var.environment}-ecs"
  description = "ECS tasks — allow traffic from ALB only"
  vpc_id      = local.vpc_id

  ingress {
    from_port       = local.ecs_config.web_port
    to_port         = local.ecs_config.api_port
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
    description     = "Allow web and API ports from ALB"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Allow all outbound (ECR, Secrets Manager, Aurora)"
  }

  tags = merge(local.common_tags, { Name = "flex-${var.environment}-ecs-sg" })
}

resource "aws_security_group" "aurora" {
  name        = "flex-${var.environment}-aurora"
  description = "Aurora — allow PostgreSQL from ECS tasks only"
  vpc_id      = local.vpc_id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.ecs.id]
    description     = "PostgreSQL from ECS tasks only"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, { Name = "flex-${var.environment}-aurora-sg" })
}

# ─────────────────────────────────────────────────────────────────────────────
# 6. Application Load Balancer (Internal)
#    HTTP  → redirect to HTTPS (CSRM AWS.CST.NET.05a compliance)
#    HTTPS → forward to target group (requires ACM cert — pending DNS ticket)
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_lb" "main" {
  name               = local.alb_config.name
  internal           = local.alb_config.internal
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = local.private_subnet_ids

  enable_deletion_protection = var.environment == "prod"

  tags = merge(local.common_tags, { Name = local.alb_config.name })
}

resource "aws_lb_target_group" "main" {
  name        = "flex-${var.environment}"
  port        = local.ecs_config.web_port
  protocol    = "HTTP"
  vpc_id      = local.vpc_id
  target_type = "ip"

  health_check {
    path                = local.alb_config.health_check_path
    healthy_threshold   = 2
    unhealthy_threshold = 3
    interval            = 30
    matcher             = local.alb_config.health_check_code
  }

  tags = merge(local.common_tags, { Name = "flex-${var.environment}-tg" })
}

# HTTP → HTTPS redirect — satisfies Bayer CSRM policy AWS.CST.NET.05a
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.main.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type = "redirect"
    redirect {
      port        = "443"
      protocol    = "HTTPS"
      status_code = "HTTP_301"
    }
  }
}

# TODO: Uncomment once ACM certificate is issued for *.flex.int.bayer.com
# DNS registration ServiceNow ticket is in progress.
#
# resource "aws_lb_listener" "https" {
#   load_balancer_arn = aws_lb.main.arn
#   port              = 443
#   protocol          = "HTTPS"
#   ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
#   certificate_arn   = var.acm_certificate_arn
#
#   default_action {
#     type             = "forward"
#     target_group_arn = aws_lb_target_group.main.arn
#   }
# }

# ─────────────────────────────────────────────────────────────────────────────
# 7. ECS Fargate Cluster + Task Definition + Service
#    Task runs 2 containers side by side:
#      - web : ReactJS served by nginx (port 80)  ← apps/web → Dockerfile.web
#      - api  : NestJS API             (port 3000) ← apps/api → Dockerfile.api
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_ecs_cluster" "main" {
  name = local.ecs_config.cluster_name

  setting {
    name  = "containerInsights"
    value = "enabled"
  }

  tags = merge(local.common_tags, { Name = local.ecs_config.cluster_name })
}

resource "aws_ecs_cluster_capacity_providers" "main" {
  cluster_name       = aws_ecs_cluster.main.name
  capacity_providers = ["FARGATE", "FARGATE_SPOT"]

  default_capacity_provider_strategy {
    capacity_provider = local.ecs_config.capacity_provider
    weight            = 1
  }
}

resource "aws_cloudwatch_log_group" "ecs" {
  name              = "/ecs/flex-${var.environment}"
  retention_in_days = var.environment == "prod" ? 30 : 7
  tags              = local.common_tags
}

resource "aws_ecs_task_definition" "main" {
  family                   = "flex-${var.environment}"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = local.ecs_config.task_cpu
  memory                   = local.ecs_config.task_memory
  execution_role_arn       = aws_iam_role.ecs_execution.arn
  task_role_arn            = aws_iam_role.ecs_task.arn

  container_definitions = jsonencode([
    # ── Web container (ReactJS — apps/web — Dockerfile.web) ─────────────────
    {
      name      = "web"
      image     = var.web_image
      essential = true
      portMappings = [{
        containerPort = local.ecs_config.web_port
        protocol      = "tcp"
        name          = "web-http"
      }]
      environment = [
        { name = "NODE_ENV",      value = var.environment },
        { name = "VITE_API_URL",  value = "http://localhost:${local.ecs_config.api_port}" }
      ]
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.ecs.name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "web"
        }
      }
      healthCheck = {
        command     = ["CMD-SHELL", "wget -qO- http://localhost:${local.ecs_config.web_port}/ || exit 1"]
        interval    = 30
        timeout     = 5
        retries     = 3
        startPeriod = 60
      }
    },
    # ── API container (NestJS — apps/api — Dockerfile.api) ──────────────────
    {
      name      = "api"
      image     = var.api_image
      essential = true
      portMappings = [{
        containerPort = local.ecs_config.api_port
        protocol      = "tcp"
        name          = "api-http"
      }]
      secrets = [
        { name = "DATABASE_URL", valueFrom = "${aws_secretsmanager_secret.db.arn}:url::" },
        { name = "JWT_SECRET",   valueFrom = "${aws_secretsmanager_secret.jwt.arn}:jwt_secret::" }
      ]
      environment = [
        { name = "NODE_ENV", value = var.environment },
        { name = "PORT",     value = tostring(local.ecs_config.api_port) }
      ]
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = aws_cloudwatch_log_group.ecs.name
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "api"
        }
      }
      healthCheck = {
        command     = ["CMD-SHELL", "wget -qO- http://localhost:${local.ecs_config.api_port}/health-check/alive || exit 1"]
        interval    = 30
        timeout     = 5
        retries     = 3
        startPeriod = 60
      }
    }
  ])

  tags = merge(local.common_tags, { Name = "flex-${var.environment}-task" })
}

resource "aws_ecs_service" "main" {
  name            = local.ecs_config.service_name
  cluster         = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.main.arn
  desired_count   = local.ecs_config.desired_count

  capacity_provider_strategy {
    capacity_provider = local.ecs_config.capacity_provider
    weight            = 1
  }

  network_configuration {
    subnets          = local.private_subnet_ids
    security_groups  = [aws_security_group.ecs.id]
    assign_public_ip = false
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.main.arn
    container_name   = "web"
    container_port   = local.ecs_config.web_port
  }

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  # task_definition and desired_count managed by GitHub Actions — not Terraform
  lifecycle {
    ignore_changes = [task_definition, desired_count]
  }

  depends_on = [aws_lb_listener.http]

  tags = merge(local.common_tags, { Name = "flex-${var.environment}-service" })
}

# ── Auto Scaling ──────────────────────────────────────────────────────────────
resource "aws_appautoscaling_target" "ecs" {
  max_capacity       = local.ecs_config.max_capacity
  min_capacity       = local.ecs_config.min_capacity
  resource_id        = "service/${aws_ecs_cluster.main.name}/${aws_ecs_service.main.name}"
  scalable_dimension = "ecs:service:DesiredCount"
  service_namespace  = "ecs"
}

resource "aws_appautoscaling_policy" "cpu" {
  name               = "flex-${var.environment}-cpu-scaling"
  policy_type        = "TargetTrackingScaling"
  resource_id        = aws_appautoscaling_target.ecs.resource_id
  scalable_dimension = aws_appautoscaling_target.ecs.scalable_dimension
  service_namespace  = aws_appautoscaling_target.ecs.service_namespace

  target_tracking_scaling_policy_configuration {
    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
    target_value       = 70.0
    scale_in_cooldown  = 300
    scale_out_cooldown = 60
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# 8. Aurora Serverless v2 PostgreSQL
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_db_subnet_group" "main" {
  name       = "flex-${var.environment}-aurora"
  subnet_ids = local.private_subnet_ids
  tags       = merge(local.common_tags, { Name = "flex-${var.environment}-aurora-subnet-group" })
}

resource "aws_rds_cluster" "main" {
  cluster_identifier          = local.aurora_config.cluster_id
  engine                      = "aurora-postgresql"
  engine_mode                 = "provisioned"
  engine_version              = local.aurora_config.engine_version
  database_name               = local.aurora_config.db_name
  master_username             = local.aurora_config.db_username
  master_password             = var.db_password
  db_subnet_group_name        = aws_db_subnet_group.main.name
  vpc_security_group_ids      = [aws_security_group.aurora.id]
  backup_retention_period     = local.aurora_config.backup_days
  deletion_protection         = var.environment == "prod"
  skip_final_snapshot         = var.environment != "prod"
  final_snapshot_identifier   = var.environment == "prod" ? "flex-${var.environment}-final-snapshot" : null
  enabled_cloudwatch_logs_exports = ["postgresql"]

  serverlessv2_scaling_configuration {
    min_capacity = local.aurora_config.min_acu
    max_capacity = local.aurora_config.max_acu
  }

  tags = merge(local.common_tags, { Name = "flex-${var.environment}-aurora" })
}

resource "aws_rds_cluster_instance" "main" {
  count              = local.aurora_config.instance_count
  identifier         = "${local.aurora_config.cluster_id}-${count.index}"
  cluster_identifier = aws_rds_cluster.main.id
  instance_class     = "db.serverless"
  engine             = aws_rds_cluster.main.engine
  engine_version     = aws_rds_cluster.main.engine_version
  tags               = merge(local.common_tags, { Name = "${local.aurora_config.cluster_id}-${count.index}" })
}

# ─────────────────────────────────────────────────────────────────────────────
# 9. SNS Notification Topic
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_sns_topic" "deployments" {
  name = local.sns_config.topic_name
  tags = merge(local.common_tags, { Name = local.sns_config.topic_name })
}

resource "aws_sns_topic_subscription" "email" {
  topic_arn = aws_sns_topic.deployments.arn
  protocol  = "email"
  endpoint  = local.sns_config.notification_email
}
