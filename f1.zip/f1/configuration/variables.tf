# ═══════════════════════════════════════════════════════════════════════════════
# variables.tf — Input variables for Flex infrastructure
# Non-sensitive values : configuration/envs/dev.tfvars  (committed to git)
# Sensitive values     : secrets.auto.tfvars            (injected by GitHub Actions, never committed)
# Image values         : injected via -var in deploy workflow
# ═══════════════════════════════════════════════════════════════════════════════

# ── Core ──────────────────────────────────────────────────────────────────────
variable "environment" {
  type        = string
  description = "Deployment environment (dev | staging | prod)"
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be one of: dev, staging, prod."
  }
}

variable "aws_region" {
  type        = string
  description = "AWS region for all resources"
  default     = "eu-central-1"
}

variable "cost_center" {
  type        = string
  description = "Bayer cost center code for resource tagging and billing"
  default     = "FLEX-POC"
}

# ── GitHub (used for OIDC trust policy) ───────────────────────────────────────
variable "github_org" {
  type        = string
  description = "GitHub organisation"
  default     = "bayer-int"
}

variable "github_repo" {
  type        = string
  description = "GitHub repository name"
  default     = "smart-aws-bay-flex-BEAT04087220"
}

# ── Application images (injected by deploy workflow) ─────────────────────────
# These are set by GitHub Actions after building and pushing to ECR
# -var="web_image=<ecr-url>/flex-dev-web:<sha>"
# -var="api_image=<ecr-url>/flex-dev-api:<sha>"
variable "web_image" {
  type        = string
  description = "ECR image URI for the ReactJS web app (apps/web)"
}

variable "api_image" {
  type        = string
  description = "ECR image URI for the NestJS API (apps/api)"
}

# ── Secrets (injected via secrets.auto.tfvars — never committed to git) ───────
variable "jwt_secret" {
  type        = string
  sensitive   = true
  description = "JWT signing secret for NestJS API authentication"
}

variable "db_password" {
  type        = string
  sensitive   = true
  description = "Aurora PostgreSQL master password"
}

variable "workpath_api_key" {
  type        = string
  sensitive   = true
  default     = ""
  description = "Workpath API key — Portfolio module integration"
}

variable "planview_api_key" {
  type        = string
  sensitive   = true
  default     = ""
  description = "Planview API key — Portfolio module migration"
}
