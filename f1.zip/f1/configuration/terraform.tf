# ═══════════════════════════════════════════════════════════════════════════════
# terraform.tf — Provider versions and backend configuration
# Repository : smart-aws-bay-flex-BEAT04087220
# Stack      : Turborepo monorepo (apps/api + apps/web)
# ═══════════════════════════════════════════════════════════════════════════════

terraform {
  required_version = ">= 1.7"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.5"
    }
    null = {
      source  = "hashicorp/null"
      version = "~> 3.2"
    }
  }

  # ── S3 Backend ───────────────────────────────────────────────────────────────
  # bucket and key are injected by deploy workflow via -backend-config:
  #   -backend-config bucket=${{ vars.FAWKES_AWS_TF_BACKEND_NAME }}
  #   -backend-config key="${ENVIRONMENT}.tfstate"
  backend "s3" {
    region       = "eu-central-1"
    encrypt      = true
    use_lockfile = true   # Bayer standard — S3 native locking, no DynamoDB needed
  }
}

# ── AWS Provider ──────────────────────────────────────────────────────────────
provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Environment = var.environment
      Project     = "Flex"
      Owner       = "gautam.raj@bayer.com"
      Application = "Flex"
      ManagedBy   = "Terraform"
      CostCenter  = var.cost_center
      Repository  = "smart-aws-bay-flex-BEAT04087220"
    }
  }
}
