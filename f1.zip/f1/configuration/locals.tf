# ═══════════════════════════════════════════════════════════════════════════════
# locals.tf — Centralised configuration for Flex
# All environment-specific values live here.
# main.tf references locals only — keeps main.tf clean and consistent.
# ═══════════════════════════════════════════════════════════════════════════════

locals {

  # ── Identity ─────────────────────────────────────────────────────────────────
  project     = "flex"
  environment = var.environment
  owner       = "gautam.raj@bayer.com"
  team        = "Bayer Flex DevOps"

  # ── Common tags (auto-applied to all resources via provider default_tags) ────
  common_tags = {
    Environment = local.environment
    Project     = local.project
    Owner       = local.owner
    ManagedBy   = "Terraform"
    Application = "Flex"
    CostCenter  = var.cost_center
  }

  # ── VPC Configuration ─────────────────────────────────────────────────────────
  # use_existing_vpc = false → create new VPC via Bayer module
  # use_existing_vpc = true  → reference an existing VPC (set existing_vpc_id)
  vpc_configuration = {
    use_existing_vpc = false
    existing_vpc_id  = ""
  }

  # ── Bayer VPC Module Parameters ───────────────────────────────────────────────
  # Ref: github.com/bayer-int/smart-aws-bayer-vpc-products-terraform
  # vpc_size options  : small | medium | large
  # subnet_layout     : private-only | private-public
  bayer_vpc_config = {
    description   = "Flex ${local.environment} VPC"
    vpc_size      = "medium"
    subnet_layout = "private-public"

    # CGNAT — required for Bayer internal routing
    enable_cgnat    = true
    cgnat_cidr_size = 24

    # Attach to Bayer Transit Gateway (tgw-053c68d4c54133858)
    attach_tgw = true

    # CNAT — outbound internet for ECR pulls, AWS API calls
    attach_cnat = true

    # Pin product versions — only update after testing in dev
    vpc_product_version  = "1.0.0"
    tgw_product_version  = "1.0.0"
    cnat_product_version = "1.0.0"
  }

  # Minimal tags for VPC — avoids Service Catalog conflicts
  vpc_tags = {
    Environment = local.environment
    Project     = local.project
    ManagedBy   = "Terraform"
  }

  # ── ECR Configuration ─────────────────────────────────────────────────────────
  # Naming matches new monorepo structure: apps/web + apps/api
  ecr_config = {
    web_repo             = "flex-${local.environment}-web"   # apps/web (ReactJS)
    api_repo             = "flex-${local.environment}-api"   # apps/api (NestJS)
    image_tag_mutability = "MUTABLE"
    scan_on_push         = true
    keep_images          = 10
  }

  # ── ECS Configuration ─────────────────────────────────────────────────────────
  ecs_config = {
    cluster_name  = "flex-${local.environment}"
    service_name  = "flex-${local.environment}"
    web_port      = 80      # ReactJS served by nginx on port 80
    api_port      = 3000    # NestJS API on port 3000

    # Scale up in prod, minimal in dev
    task_cpu      = var.environment == "prod" ? 1024 : 512
    task_memory   = var.environment == "prod" ? 2048 : 1024
    desired_count = var.environment == "prod" ? 2 : 1
    min_capacity  = var.environment == "prod" ? 2 : 1
    max_capacity  = var.environment == "prod" ? 8 : 4

    # Fargate Spot saves cost in non-prod environments
    capacity_provider = var.environment == "prod" ? "FARGATE" : "FARGATE_SPOT"
  }

  # ── ALB Configuration ─────────────────────────────────────────────────────────
  alb_config = {
    name              = "flex-${local.environment}"
    internal          = true                     # internal only — Bayer network via TGW
    health_check_path = "/health-check/alive"    # NestJS health endpoint
    health_check_code = "200"
  }

  # ── Aurora Serverless v2 Configuration ───────────────────────────────────────
  aurora_config = {
    cluster_id     = "flex-${local.environment}"
    engine_version = "16.4"
    db_name        = "flexdb"
    db_username    = "flexadmin"
    # 0.0 ACU = scales to zero in dev (cost saving)
    min_acu        = var.environment == "prod" ? 0.5 : 0.0
    max_acu        = var.environment == "prod" ? 8.0 : 2.0
    instance_count = var.environment == "prod" ? 2 : 1
    backup_days    = var.environment == "prod" ? 7 : 1
  }

  # ── Secrets Manager ───────────────────────────────────────────────────────────
  secrets_config = {
    # prod: 7-day recovery window | dev: 0 = immediate delete allowed
    recovery_window = var.environment == "prod" ? 7 : 0
    prefix          = "flex/${local.environment}"
  }

  # ── SNS Notifications ─────────────────────────────────────────────────────────
  sns_config = {
    topic_name         = "flex-${local.environment}-deployments"
    notification_email = "gautam.raj@bayer.com"
  }

  # ── Resolved VPC outputs ──────────────────────────────────────────────────────
  # Points to Bayer module outputs or existing VPC depending on vpc_configuration
  vpc_id             = local.vpc_configuration.use_existing_vpc ? local.vpc_configuration.existing_vpc_id : module.vpc_cidr_tgw_cnat[0].vpc_id
  private_subnet_ids = local.vpc_configuration.use_existing_vpc ? [] : module.vpc_cidr_tgw_cnat[0].private_subnet_ids
  public_subnet_ids  = local.vpc_configuration.use_existing_vpc ? [] : module.vpc_cidr_tgw_cnat[0].public_subnet_ids
}
