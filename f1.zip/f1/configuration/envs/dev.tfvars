# ═══════════════════════════════════════════════════════════════════════════════
# envs/dev.tfvars — Non-sensitive dev environment values
# Safe to commit to git.
# Sensitive values go in secrets.auto.tfvars (injected by GitHub Actions)
# ═══════════════════════════════════════════════════════════════════════════════

environment = "dev"
aws_region  = "eu-central-1"
cost_center = "FLEX-POC-DEV"
github_org  = "bayer-int"
github_repo = "smart-aws-bay-flex-BEAT04087220"