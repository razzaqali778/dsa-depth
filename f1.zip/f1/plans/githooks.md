# Git Hooks — Local Quality Gate (Pre-Commit & Pre-Push)

> **Living document** — reflects the current implemented state as of July 2026.

## Overview

Every commit and push runs an automated quality gate locally, giving developers the same signal SonarCloud provides in CI — before code ever leaves the machine.

```
Developer writes code
        │
        ▼
  git add (stage)
        │
        ▼
  git commit ──► PRE-COMMIT HOOK (3 steps)
        │              ├─ 1. ESLint + SonarJS rules on staged files (auto-fix)
        │              ├─ 2. TypeScript type check on staged files
        │              ├─ 3. Check every staged source file has a test file ← BLOCKS if missing
        │              └─ 4. Full test suite (blocks if any test fails)
        │
        ▼ (commit created locally)
        │
  git push ───► PRE-PUSH HOOK (5 steps)
                       ├─ 1. Full build verification (turbo build)
                       ├─ 2. Full test suite + coverage ≥ 80% (turbo test:coverage)
                       ├─ 3. Alert: files with 0% line coverage (informational)
                       ├─ 4. SonarJS quality summary (informational)
                       └─ 5. SonarQube scan — upload coverage + analysis (warn-only if Sonar down)
```

**Philosophy:** Fail fast, fail small. Pre-commit catches missing tests and broken code at the smallest unit of work (a single commit). Pre-push enforces the full quality bar before code reaches the remote.

---

## Implemented Files

| File | Status | Purpose |
|------|--------|---------|
| `.husky/pre-commit` | ✅ Implemented | 3-step commit gate |
| `.husky/pre-push` | ✅ Implemented | 5-step push gate (includes SonarQube scan) |
| `scripts/check-staged-tests.js` | ✅ Implemented | Blocks commit if staged source file has no test |
| `scripts/check-untested-files.js` | ✅ Implemented | Reports files with 0% coverage after push |
| `.test-exempt.json` | ✅ Implemented | Config file — patterns exempt from test requirement |
| `eslint.config.mjs` | ✅ Implemented | ESLint flat config with TypeScript + SonarJS rules |
| `package.json` | ✅ Modified | Added `prepare`, `lint-staged`, `test:coverage`, devDependencies |
| `turbo.json` | ✅ Modified | Added `test:coverage` task |
| `apps/api/vitest.config.ts` | ✅ Modified | Vitest coverage thresholds + `json-summary` reporter |
| `apps/web/vite.config.ts` | ✅ Modified | Vitest coverage thresholds + `json-summary` reporter |
| `.gitignore` | ✅ Modified | Added `coverage`, `.turbo`, `dist` |

---

## Part 1: Pre-Commit Hook

**File:** `.husky/pre-commit`

```sh
#!/usr/bin/env sh

# Step 1: Lint + typecheck staged files only (fast — only what you changed)
echo "🔍 Step 1/3: Linting staged files..."
npx lint-staged
if [ $? -ne 0 ]; then
  echo "✖ Commit blocked — lint or typecheck failed on staged files."
  exit 1
fi

# Step 2: Ensure every staged source file has a test file
echo "🧪 Step 2/3: Checking staged files have tests..."
node scripts/check-staged-tests.js
if [ $? -ne 0 ]; then
  exit 1
fi

# Step 3: Run the full test suite (ensures nothing is broken)
echo "✅ Step 3/3: Running tests..."
npm run test
if [ $? -ne 0 ]; then
  echo "✖ Commit blocked — tests are failing."
  exit 1
fi

echo "✔ All checks passed — committing."
```

### Step 1 — lint-staged

Configured in `package.json`:

```json
"lint-staged": {
  "apps/api/**/*.ts": [
    "eslint --fix --max-warnings=0",
    "bash -c 'tsc -p apps/api/tsconfig.json --noEmit'"
  ],
  "apps/web/**/*.{ts,tsx}": [
    "eslint --fix --max-warnings=0",
    "bash -c 'tsc -p apps/web/tsconfig.json --noEmit'"
  ]
}
```

Only staged files are checked — keeps pre-commit fast (2–5 seconds).

### Step 2 — check-staged-tests.js

**File:** `scripts/check-staged-tests.js`

For every staged `.ts`/`.tsx` source file, checks that a corresponding `.spec.ts` or `.test.ts` exists (in the same directory or a `__tests__/` subdirectory). If any are missing, the commit is **blocked** with exact guidance.

Paths listed under `autoScaffold` in `.test-exempt.json` (platform bootstrap code) get a minimal Vitest stub created and staged automatically on commit.

```
✖ Commit blocked — the following staged files have NO test file:

  📄 apps/api/src/modules/outcomes/application/services/pricing.service.ts
     → Create: apps/api/src/modules/outcomes/application/services/pricing.service.spec.ts

  Write at least one test for each file above, then commit again.
  To exempt a file type, add its pattern to .test-exempt.json
  Platform/bootstrap paths may auto-scaffold stubs — see autoScaffold in .test-exempt.json
```

### Exempt Patterns — `.test-exempt.json`

Files matching these patterns are **not required** to have a test file. Edit this file to add new exemptions — no code changes needed.

```json
{
  "_comment": "Files matching these patterns do NOT need a test file.",
  "patterns": [
    "*.module.ts",
    "*.definition.ts",
    "*.dto.ts",
    "*.response.ts",
    "*.port.ts",
    "*.event.ts",
    "*.types.ts",
    "*.slice.ts",
    "*.d.ts",
    "main.ts",
    "main.tsx",
    "**/router/**",
    "**/providers/**",
    "**/store/**",
    "**/layouts/**",
    "**/styles/**",
    "vite.config.ts",
    "vitest.config.ts",
    "vitest.setup.ts"
  ]
}
```

Supports `*` (any chars except `/`), `**` (any chars including `/`), and `?` (single char) glob syntax.

### Step 3 — npm run test

Runs `turbo test` across all workspaces. Blocks the commit if any test fails. This ensures you can't commit code that breaks existing tests.

---

## Part 2: Pre-Push Hook

**File:** `.husky/pre-push`

```sh
#!/usr/bin/env sh

# Step 1: Build verification
npm run build          # blocks push if build fails

# Step 2: Full test suite with coverage
npm run test:coverage  # blocks push if tests fail or coverage < 80%

# Step 3: Alert on files with zero test coverage (informational)
node scripts/check-untested-files.js

# Step 4: SonarJS full scan summary (informational)
npm run lint 2>/dev/null | tail -10 || true
```

### Step 2 — Coverage Thresholds

Both apps enforce 80% minimum across all metrics:

| Metric | Threshold | Applies to |
|--------|-----------|-----------|
| Statements | ≥ 80% | `apps/api` + `apps/web` |
| Branches | ≥ 80% | `apps/api` + `apps/web` |
| Functions | ≥ 80% | `apps/api` + `apps/web` |
| Lines | ≥ 80% | `apps/api` + `apps/web` |

Configured in:
- `apps/api/vitest.config.ts` → `test.coverage.thresholds`
- `apps/web/vite.config.ts` → `test.coverage.thresholds`

### Step 3 — check-untested-files.js

**File:** `scripts/check-untested-files.js`

Reads `coverage-summary.json` (generated by `test:coverage`) from both apps and prints any file with 0% line coverage. **Informational only** — does not block the push.

To make it blocking, change `process.exit(0)` → `process.exit(1)` at the bottom of the script.

```
⚠️  Files with NO test coverage (0% lines covered):
   • apps/api/src/modules/finops/application/services/budget.service.ts
   • apps/api/src/modules/outcomes/domain/outcome.entity.ts
```

### Coverage Reporters

Both apps output `json-summary` (required by `check-untested-files.js`) in addition to human-readable formats:

- `apps/api`: `["text", "text-summary", "lcov", "json-summary"]`
- `apps/web`: `["text", "text-summary", "lcov", "json-summary"]`

---

## Part 3: ESLint Configuration

**File:** `eslint.config.mjs` (root level, ESLint 9 flat config)

```javascript
import js from "@eslint/js";
import tseslint from "typescript-eslint";
import sonarjs from "eslint-plugin-sonarjs";

export default tseslint.config(
  js.configs.recommended,
  ...tseslint.configs.recommended,
  sonarjs.configs.recommended,
  {
    rules: {
      "sonarjs/cognitive-complexity": ["error", 15],
      "sonarjs/no-duplicate-string": ["error", { threshold: 3 }],
      "@typescript-eslint/no-explicit-any": "error",
      "@typescript-eslint/no-unused-vars": ["error", { argsIgnorePattern: "^_" }],
      "@typescript-eslint/consistent-type-imports": "error",
    },
  },
  {
    ignores: ["**/dist/**", "**/node_modules/**", "**/coverage/**", "**/*.js", "**/*.mjs", "**/*.cjs"],
  },
);
```

### SonarJS Rules Enforced Locally

| Rule | What it catches |
|------|----------------|
| `cognitive-complexity` | Functions too complex to understand (threshold: 15) |
| `no-duplicate-string` | Magic strings repeated 3+ times |
| `no-identical-functions` | Copy-pasted function bodies |
| `no-collapsible-if` | Nested `if` that can be merged |
| `no-redundant-jump` | Unnecessary `return`/`continue` |
| `prefer-immediate-return` | Unnecessary temp variable before return |

---

## Part 4: Turbo Pipeline

**File:** `turbo.json`

```json
{
  "tasks": {
    "build": { "dependsOn": ["^build"], "outputs": ["dist/**", "build/**"] },
    "dev": { "cache": false, "persistent": true },
    "lint": { "dependsOn": ["^lint"] },
    "test": { "dependsOn": ["^build"] },
    "test:coverage": { "dependsOn": ["^build"], "outputs": ["coverage/**"] },
    "typecheck": { "dependsOn": ["^build"] }
  }
}
```

`test:coverage` is a separate turbo task so coverage output is cached and the `json-summary` files are available for `check-untested-files.js`.

---

## Part 5: .gitignore

```
node_modules
.gitnexus
coverage
.turbo
dist
```

---

## Part 6: Team Onboarding

Any developer who clones the repo and runs `npm install` gets the hooks automatically — no manual setup required:

```bash
git clone https://github.com/bayer-int/flex
cd flex
npm install   # ← hooks installed automatically via "prepare": "husky"
```

### Escape Hatch

Hooks are intentionally strict — fix failures locally rather than skipping checks. CI runs the same gates on push.

---

## Part 7: Mapping to SonarCloud Quality Gate

| SonarCloud Check | Local Equivalent | Hook |
|-----------------|-----------------|------|
| New bugs | ESLint + SonarJS `recommended` | pre-commit |
| New code smells | `sonarjs/cognitive-complexity`, `no-duplicate-string`, etc. | pre-commit |
| New security hotspots | `@typescript-eslint` strict rules | pre-commit |
| Missing test file | `check-staged-tests.js` | pre-commit |
| Coverage on new code ≥ 80% | Vitest `--coverage` with thresholds | pre-push |
| Files with 0% coverage | `check-untested-files.js` | pre-push |
| Duplicated lines | `sonarjs/no-identical-functions`, `no-duplicate-string` | pre-commit |
| Build passes | `turbo build` | pre-push |
| All tests pass | `turbo test` | pre-commit + pre-push |
| SonarQube analysis + coverage upload | `npm run sonar:scan` | pre-push |

---

## Part 8: Future Enhancements

| Enhancement | When to add |
|-------------|------------|
| **Make `check-untested-files.js` blocking** | Change `process.exit(0)` → `process.exit(1)` once test coverage is established |
| **Commit message linting** (`commitlint`) | When adopting Conventional Commits for changelog generation |
| **Secret scanning** (`gitleaks`) | Before any credentials are ever accidentally committed |
| **Dependency vulnerability check** (`npm audit`) | In pre-push, once baseline vulnerabilities are resolved |
| **SonarCloud PR decoration** | CI pipeline task — shows inline comments on GitHub PRs |
