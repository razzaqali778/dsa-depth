# Auth & OIDC — Frontend Plan

All paths under `apps/web/src/modules/auth`.

## Structure

| File | Purpose |
|------|---------|
| `types/auth.types.ts` | `AuthUser`, `AuthSession`, `Permission`, state types. |
| `entra/oidc-config.ts` | Reads `VITE_AZURE_*`; derives endpoints; `isOidcConfigured()`. |
| `entra/pkce.ts` (+spec) | PKCE verifier/challenge + state helpers (browser `crypto.subtle`). |
| `entra/oidc-client.ts` (+spec) | Build authorize URL, handle redirect, exchange code, logout. |
| `api/auth.api.ts` (+spec) | `verify`, `getMe`, user CRUD calls through the gateway client. |
| `state/auth.slice.ts` | Session slice: user, permissions, status, token. |
| `hooks/use-auth.ts` (+spec) | `useAuth()` + `useHasPermission()` selectors. |
| `providers/auth-provider.tsx` | Bootstraps session on mount; handles callback. |
| `components/*` (+spec) | `PermissionGate`, `UserAvatar`, small UI pieces. |
| `pages/login-page.tsx` (+spec) | Modern responsive login. |
| `pages/callback-page.tsx` (+spec) | OIDC redirect handler. |
| `pages/users-admin-page.tsx` (+spec) | User table, role edit, activate/deactivate. |
| `pages/auth-page.tsx` | Account/session overview (keep + extend). |

## Flows

- **Dev mode (no `VITE_AZURE_CLIENT_ID`):** login calls the API directly (`AUTH_MODE=disabled` returns the local admin). No redirect. Everything demoable offline.
- **OIDC mode:** login → Entra authorize (PKCE) → `/auth/callback` → token exchange → `POST /verify` → store session.

## Session bootstrap

`AuthProvider` on mount:
1. If a stored token exists (or dev mode), call `GET /me` to hydrate the session.
2. Route guards (`PermissionGate`, protected routes) read the session from Redux.

## UI/UX

- Responsive layout (sidebar collapses < 1100px, already in `styles.css`).
- Modern login card: brand, SSO button, subtle gradient, loading + error states.
- Users admin: responsive table → cards on mobile, role dropdown, status toggle, permission-gated actions, empty/loading/error states.
- Accessible: labelled controls, semantic headings, keyboard-focusable actions.

## Wiring

- Register `authReducer` (exists) — extend, keep key `auth`.
- Add routes `/login`, `/auth/callback`, `/users` in `app-router.tsx`.
- Add "Users" nav link (permission-gated) in `app-shell.tsx`.
- Wrap app with `AuthProvider` in `app-providers.tsx`.
