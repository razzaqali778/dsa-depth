# Auth & OIDC — Overview

## Goal

Deliver a complete, production-ready authentication and authorization feature for FLEX:

- **OIDC login** with Microsoft Entra ID (Azure AD) on the frontend (Authorization Code + PKCE).
- **Bearer token verification** on the backend (Azure JWKS, RS256) as ingress identity.
- **User provisioning** (upsert on first login) into the `flex_auth` boundary.
- **RBAC** — roles → permissions, enforced with a route guard.
- **User management CRUD** — admin UI + API (list, view, update role, activate/deactivate).
- **Modern, responsive UI** — login screen, session bootstrap, user administration.
- **Full unit tests** and **Sonar-clean** code across backend and frontend.

## Architecture summary

FLEX splits auth into two concerns (see [`01-architecture.md`](./01-architecture.md)):

| Concern | Layer | Owns |
|---------|-------|------|
| **Ingress identity** — "who is calling?" | `apps/api/src/platform/auth` | Gateway guard, bearer/JWKS verification, `AuthenticatedUser` |
| **Authorization domain** — "what may they do?" | `apps/api/src/modules/auth` | RBAC, users DB (`flex_auth`), user CRUD, `/verify`, `/me` |

The frontend auth module lives at `apps/web/src/modules/auth`.

## Auth modes

The backend supports three ingress modes via `AUTH_MODE`:

| Mode | Use | Identity source |
|------|-----|-----------------|
| `disabled` | Local dev (default) | Injected local developer (Admin) |
| `gateway` | Behind enterprise API gateway | `x-flex-user-*` headers |
| `bearer` | Direct SPA → API with Entra tokens | `Authorization: Bearer <token>` verified against Azure JWKS |

## Delivery phases

| Phase | Doc | Scope |
|-------|-----|-------|
| 1 | [`02-backend-plan.md`](./02-backend-plan.md) | Domain, ports, services, persistence, JWKS verifier, controllers, guards |
| 2 | [`03-frontend-plan.md`](./03-frontend-plan.md) | OIDC client, session state, login + callback + admin UI |
| 3 | [`04-testing-and-sonar.md`](./04-testing-and-sonar.md) | Unit tests, coverage thresholds, Sonar rules |
| 4 | [`05-environment-and-deployment.md`](./05-environment-and-deployment.md) | Env vars, Azure app registration, DB swap to Prisma |

## Key decisions

- **No new runtime dependencies.** JWKS verification uses Node's built-in `crypto` + `fetch`. Frontend OIDC uses the browser `crypto.subtle` + `fetch` (no MSAL package) so everything is testable and hermetic.
- **Ports & adapters.** Persistence is behind `UserRepositoryPort`. An in-memory adapter ships as the working default; a Prisma adapter (schema included) is wired once a database URL is provided.
- **Dev works with zero config.** With `AUTH_MODE=disabled` and no Azure env, the app is fully usable and demoable; real OIDC activates when env is supplied.
