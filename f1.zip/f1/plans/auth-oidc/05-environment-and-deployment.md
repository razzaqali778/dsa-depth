# Auth & OIDC — Environment & Deployment

## Backend env

| Var | Required for | Description |
|-----|--------------|-------------|
| `AUTH_MODE` | all | `disabled` (default) \| `gateway` \| `bearer`. |
| `AUTH_DATABASE_URL` | prod persistence | `flex_auth` connection (Prisma swap). |
| `AZURE_TENANT_ID` | `bearer` | Entra tenant (directory) ID. |
| `AZURE_API_AUDIENCE` | `bearer` | Expected token audience (API app ID URI or client ID). |
| `AZURE_JWKS_URI` | optional | Overrides derived JWKS endpoint. |
| `AZURE_ISSUER` | optional | Overrides derived issuer. |
| `AZURE_ADMIN_ROLES` | optional | Comma list of Entra roles mapped to FLEX `Admin` (default `FLEX.Admin`). |
| `AZURE_PLATFORM_LEAD_ROLES` | optional | Entra roles mapped to `Platform Lead` (default `PLD`). |

## Frontend env (Vite `VITE_` prefix)

| Var | Required for | Description |
|-----|--------------|-------------|
| `VITE_AZURE_CLIENT_ID` | OIDC | SPA app registration client ID. Absent → dev mode. |
| `VITE_AZURE_TENANT_ID` | OIDC | Entra tenant ID. |
| `VITE_AZURE_API_SCOPE` | OIDC | Scope requested for the FLEX API (e.g. `api://<api-client-id>/access_as_user`). |
| `VITE_AZURE_REDIRECT_URI` | optional | Defaults to `${origin}/auth/callback`. |
| `VITE_FLEX_API_BASE_URL` | optional | Defaults to `/api`. |

## Azure app registration (summary)

1. Register a **SPA** app → set redirect URI `https://<host>/auth/callback`.
2. Register (or reuse) an **API** app → expose scope `access_as_user`; define app roles (`FLEX.Admin`, `PLD`).
3. Grant the SPA delegated permission to the API scope.
4. Assign users/groups to app roles.
5. Populate frontend `VITE_AZURE_*` and backend `AZURE_*` env.

## Local development

- Zero-config: `AUTH_MODE=disabled`, no Azure env → local admin user, full UI.
- `make up` / `npm run dev` runs both apps; web proxies `/api` to the API.

## Database swap to Prisma

1. Provide `AUTH_DATABASE_URL`, run `make db-migrate-dev MODULE=auth NAME=init` + `make db-generate MODULE=auth`.
2. Add `PrismaUserRepository` implementing `UserRepositoryPort` from `schema.prisma`.
3. Rebind `USER_REPOSITORY` in `auth.module.ts` to the Prisma adapter.
4. No changes to services, controllers, or the frontend.
