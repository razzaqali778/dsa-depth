# Auth & OIDC — Backend Plan

All paths under `apps/api/src`.

## New / changed files

### Platform (ingress identity) — `platform/auth/`
| File | Purpose |
|------|---------|
| `auth-context.ts` | Add `bearer` to `AuthMode`; extend `AuthenticatedUser` (optional `tenantId`). |
| `jwks-token-verifier.ts` (+spec) | Verify Azure RS256 JWT against JWKS; return claims. Node `crypto` + `fetch`, no deps. |
| `gateway-auth.guard.ts` (+spec) | Async guard; `bearer` mode delegates to `JwksTokenVerifier`. |
| `auth.module.ts` | Provide `JwksTokenVerifier`. |

### Module (authorization domain) — `modules/auth/`
| File | Purpose |
|------|---------|
| `domain/rbac.ts` (+spec) | Roles, permissions, role→permission map, Entra role mapping, resolve helpers. |
| `application/ports/user-repository.port.ts` | `UserRepositoryPort`, `UserRecord`, upsert/update/list types. |
| `application/services/rbac.service.ts` (+spec) | Injectable RBAC checks; `resolvePermissions(roles)`. |
| `application/services/azure-auth.service.ts` (+spec) | `provisionFromIdentity(identity)` upsert + role map + session assembly. |
| `application/services/user.service.ts` (+spec) | CRUD: list, get, getMe, updateRole, setActive, createLocal. |
| `infrastructure/persistence/in-memory-user.repository.ts` (+spec) | Default adapter (no DB). |
| `infrastructure/persistence/user.seed.ts` (+spec) | Seed default admin + demo users. |
| `infrastructure/persistence/schema.prisma` | Prisma `User` model (design; wired when DB env provided). |
| `presentation/decorators/require-permission.decorator.ts` (+spec) | `@RequirePermission(...)` metadata. |
| `presentation/guards/require-permission.guard.ts` (+spec) | Enforce permissions via `RbacService`. |
| `presentation/controllers/auth.controller.ts` (+spec) | `GET /summary`, `POST /verify`, `GET /me`. |
| `presentation/controllers/users.controller.ts` (+spec) | `GET/POST/PATCH /users`, activate/deactivate. |
| `presentation/dto/*.dto.ts`, `*.response.ts` | Requests/responses (coverage-exempt). |
| `auth.module.ts` | Wire providers, controllers, `USER_REPOSITORY` token. |
| `auth.definition.ts` | Fill responsibilities, events, integrations. |

## API surface

| Method | Route | Auth | Permission |
|--------|-------|------|------------|
| GET | `/api/auth/summary` | public | — |
| POST | `/api/auth/verify` | authenticated | — (self) |
| GET | `/api/auth/me` | authenticated | — (self) |
| GET | `/api/auth/users` | authenticated | `view_users` |
| GET | `/api/auth/users/:id` | authenticated | `view_users` |
| POST | `/api/auth/users` | authenticated | `manage_users` |
| PATCH | `/api/auth/users/:id` | authenticated | `manage_users` |
| POST | `/api/auth/users/:id/deactivate` | authenticated | `manage_users` |
| POST | `/api/auth/users/:id/activate` | authenticated | `manage_users` |

## Rules

- Every service method is decorated with `@Traced()`.
- No hard delete — deactivate sets `isActive = false`.
- `permissions` are derived from `role` via `RbacService` (not stored free-form).
- DTOs use `class-validator` (global `ValidationPipe` already configured in `platform/network`).

## Persistence swap (later)

`UserRepositoryPort` is bound to `InMemoryUserRepository` today. When `AUTH_DATABASE_URL` + a generated Prisma client are available, add `PrismaUserRepository` implementing the same port and rebind the `USER_REPOSITORY` token — no service/controller changes required.
