# Auth & OIDC — Testing & Sonar

## Test tooling

- **Runner:** Vitest (`vitest run`), co-located `*.spec.ts` / `*.spec.tsx`.
- **Backend:** node environment; NestJS providers unit-tested with fakes (no real DB/network).
- **Frontend:** jsdom + Testing Library.

## Coverage thresholds (must pass)

Both apps enforce **80%** statements / branches / functions / lines.

Coverage-exempt (per `vitest.config.ts` and `.test-exempt.json`):
`*.module.ts`, `*.definition.ts`, `*.dto.ts`, `*.response.ts`, `*.port.ts`, `*.event.ts`, `*.types.ts`, `*.slice.ts`, `main.ts`.

Everything else added by this feature ships with a spec.

## What each test covers

| Unit | Key cases |
|------|-----------|
| `rbac.ts` | permission map completeness, `hasPermission`, Entra role mapping, unknown role → `User`. |
| `RbacService` | resolve permissions across multiple roles, dedupe. |
| `JwksTokenVerifier` | valid RS256 token, expired, not-yet-valid, bad signature, wrong issuer/audience, missing/unknown `kid`. (Tests generate an RSA keypair + fake `fetch`.) |
| `GatewayAuthGuard` | public route, disabled, gateway headers, bearer success/failure. |
| `AzureAuthService` | new user upsert, existing update, role mapping, session assembly. |
| `UserService` | list/filter, get, getMe, updateRole, activate/deactivate, not-found. |
| `InMemoryUserRepository` | upsert create/update, findBy*, list, update, setActive. |
| `RequirePermissionGuard` | allow, deny, no-metadata passthrough, missing user. |
| Controllers | delegate to services, permission wiring, verify/me. |
| Frontend `pkce`/`oidc-client` | challenge generation, url build, callback parse, dev-mode. |
| Frontend pages/components | render states, actions dispatch, permission gating. |

## Sonar / ESLint rules honored

- `sonarjs/cognitive-complexity` ≤ 15 — keep functions small, extract helpers.
- `sonarjs/no-duplicate-string` (threshold 3) — hoist repeated literals to constants.
- `@typescript-eslint/no-explicit-any` — no `any`; use precise types/generics.
- `@typescript-eslint/consistent-type-imports` — `import type { ... }`.
- `@typescript-eslint/no-unused-vars` — prefix intentionally unused with `_`.

## Validation commands

```bash
npm run typecheck          # tsc both apps
npm run test               # vitest both apps
npm run test:coverage      # enforce thresholds
npm run sonar:scan         # SonarQube (when stack is up)
```
