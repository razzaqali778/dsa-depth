# Auth & OIDC — Architecture

## Two concerns, two layers

```
Enterprise IdP (Entra ID)
        │  OIDC (Auth Code + PKCE)
        ▼
   FLEX SPA (apps/web/src/modules/auth)
        │  Authorization: Bearer <access_token>
        ▼
┌─────────────────────────────────────────────┐
│ platform/auth  — INGRESS IDENTITY            │
│  GatewayAuthGuard (disabled | gateway | bearer)
│  JwksTokenVerifier (Azure RS256 verify)      │
│  @CurrentUser(), @Public(), AuthenticatedUser│
└─────────────────────────────────────────────┘
        │  request.user = { id, email, displayName, roles }
        ▼
┌─────────────────────────────────────────────┐
│ modules/auth  — AUTHORIZATION DOMAIN         │
│  RbacService (roles → permissions)           │
│  AzureAuthService (upsert user from claims)  │
│  UserService (CRUD)                          │
│  RequirePermissionGuard + @RequirePermission │
│  UserRepositoryPort → flex_auth              │
└─────────────────────────────────────────────┘
```

## Why the split

- **Platform** answers *who is calling* — every service needs this, like telemetry. It never owns a database or business rules.
- **Module** answers *what they may do* — it owns the users table, roles, permissions, and admin APIs. It is a normal FLEX business module registered in `FLEX_MODULE_CATALOG` with its own `flex_auth` database boundary.

## Request lifecycle (bearer mode)

1. SPA acquires an Entra access token (PKCE) scoped to the FLEX API.
2. SPA calls `POST /api/auth/verify` with the bearer token.
3. `GatewayAuthGuard` verifies the token signature/claims via `JwksTokenVerifier` and sets `request.user`.
4. `AzureAuthService.provisionFromIdentity()` upserts the user into `flex_auth`, mapping the Entra role to a FLEX role.
5. Response returns the FLEX session: profile + resolved permissions.
6. Subsequent calls send the same bearer token; `RequirePermissionGuard` maps `request.user.roles` → permissions via `RbacService`.

## RBAC model

- **Roles:** `Admin`, `Platform Lead`, `User`.
- **Permissions:** view/manage users, assign roles, view audit, view dashboard.
- **Mapping:** Entra app roles/groups (e.g. `PLD`, `FLEX.Admin`) → FLEX roles → permission set.

See `apps/api/src/modules/auth/domain/rbac.ts`.

## Layering rules (must follow)

- `presentation/` → controllers, DTOs only.
- `application/` → services + port interfaces.
- `domain/` → pure functions (no NestJS imports).
- `infrastructure/` → adapters (repositories, external clients).
- Other business modules consume identity via `@CurrentUser()` and permissions via `RequirePermissionGuard`; they never read `flex_auth` directly.
