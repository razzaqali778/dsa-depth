# Plan: Makefile as the FLEX Operations API

> **Living document** — unified local + cloud dev operations via `make`, replacing fragmented commands and fixing “Grafana not running” class of problems.

## Problem today

| Symptom | Root cause |
|---------|------------|
| Grafana not running | Developer ran `make deps` or `npm run dev:api` only — observability is a **separate** target (`make observability` / `make stack`) |
| Unclear what “full local” means | ~~No single `make up`~~ — **fixed** via `make up` |
| Docker-only assumptions | ~~Compose hardcoded to `docker`~~ — **fixed** via auto-detected Podman/Docker runtime |
| Cloud DB vs local DB | Only local URLs in `.env.example`; no documented switch or validation path |
| One-off shell commands in chat | Recurring ops (port checks, log tailing, health probes) are not codified — agents and humans reinvent them |

Current Makefile ([`Makefile`](../Makefile)) has infra targets but **does not start API/web** and has no health/status layer.

```text
Today (fragmented):
  make deps              → Postgres only
  make stack             → Postgres + Sonar + Grafana stack (Docker)
  npm run dev:api        → API (separate terminal)
  npm run dev:web        → Web (separate terminal)

Missing:
  make up                → everything a developer needs in one command
  make status            → “is Grafana up?” answered in 2 seconds
```

---

## Design principles

### 1. Make is the operations API

Humans and agents **start from `make help`**, not from remembering npm scripts or compose profiles.

- **npm scripts** = build/test/lint (Turbo workspace tasks)
- **Make** = orchestration: Docker infra, app processes, env modes, health, logs, DB access

### 2. Add a Make target when a problem recurs

**Rule (for humans and agents):** If an operational step is needed **more than once** or by **more than one person/agent**, it becomes a Make target backed by a script in `scripts/ops/`, not a one-off shell one-liner.

| Add a target when… | Do NOT add a target when… |
|--------------------|---------------------------|
| Same debug/start/stop flow happens weekly | Truly unique production incident |
| Agents keep rediscovering the same curl/ps/docker command | A single npm script already covers it with no orchestration |
| Onboarding doc would say “run these 4 commands” | Wrapping one trivial command with no value (`make ls`) |

Document new targets in `make help` and [`docs/dev-operations.md`](../docs/dev-operations.md).

### 3. Layers, not a flat list

```mermaid
flowchart TB
  subgraph makeUp [make up]
    Infra[Layer 1: Infra]
    Apps[Layer 2: Apps]
    Verify[Layer 3: Health]
  end

  Infra --> Postgres[postgres]
  Infra --> Obs[observability profile]
  Infra --> Sonar[sonar profile optional]

  Apps --> API[api :3000]
  Apps --> Web[web :5173]

  Verify --> Status[make status]
```

### 4. Environment is explicit: `local` vs `cloud`

One variable drives DB and optional service endpoints:

```bash
FLEX_ENV=local   # default — Docker Postgres on localhost
FLEX_ENV=cloud   # module DB URLs point at cloud (RDS, etc.)
```

Make loads `.env` and validates required vars per mode before starting apps.

---

## Proposed Makefile layout

Split into included fragments (keeps root [`Makefile`](../Makefile) small):

```text
Makefile                 # entry: help, includes, default goals
make/
  variables.mk           # COMPOSE, CONTAINER_RUNTIME, NPM, FLEX_ENV, ports, profiles
  infra.mk               # up-infra, down-infra, postgres, observability, sonar
  apps.mk                # up-apps, down-apps, api, web
  database.mk            # db-shell, db-status, db-cloud-check, db-migrate (future)
  quality.mk             # sonar-scan, test, lint (thin wrappers)
  health.mk              # status, wait-healthy, logs, urls
scripts/ops/
  container-runtime.sh   # detect podman (preferred) or docker + compose command
  compose-cmd.sh         # print compose command for Makefile $(COMPOSE)
  up-infra.sh            # start postgres + profiles using detected runtime
  wait-healthy.sh        # poll HTTP/TCP until services ready
  start-apps.sh          # background api + web with pid files
  stop-apps.sh           # kill by pid file
  db-cloud-check.sh      # verify cloud DATABASE_URL connectivity
  print-urls.sh          # all local URLs for copy-paste
```

---

## Target catalog

### Primary (what developers use daily)

| Target | Purpose |
|--------|---------|
| **`make up`** | **Full local dev:** `up-infra` + wait for health + `up-apps` + print URLs (Grafana, API, Web, Sonar) |
| **`make down`** | Stop apps + stop all Docker profiles |
| **`make status`** | Table: service name, URL, up/down (postgres, grafana, api, web, sonar, tempo, …) |
| **`make urls`** | Print all local URLs |
| **`make help`** | Grouped target list with one-line descriptions |
| **`make runtime`** | Show detected container runtime and compose command (`podman compose` or `docker compose`) |

### Infrastructure

| Target | Purpose |
|--------|---------|
| `make up-infra` | Postgres + observability (Grafana, Tempo, Prometheus, Loki, OTEL) — **always included in `make up`** |
| `make up-infra-full` | `up-infra` + Sonar profile |
| `make down-infra` | `$(COMPOSE)` down for active profiles |
| `make logs SERVICE=grafana` | `$(COMPOSE) logs -f <service>` |
| `make reset-infra` | Destructive: remove volumes + recreate (documented warning) |

**Deprecate / alias:** `make stack` → alias to `make up-infra-full`; `make deps` → alias to `make up-infra` (postgres-only option: `make up-infra-minimal`).

### Applications (run independently)

| Target | Purpose |
|--------|---------|
| `make up-apps` | Start API + Web in background (`scripts/ops/start-apps.sh`) |
| `make down-apps` | Stop API + Web (`scripts/ops/stop-apps.sh`) |
| `make api` | API only (foreground) |
| `make web` | Web only (foreground) |
| `make dev` | Foreground: infra + turbo dev (current `make dev` behavior, enhanced) |

Apps write PID files to `.flex/run/` (gitignored) so `make down-apps` is reliable.

### Database — local

| Target | Purpose |
|--------|---------|
| `make db-status` | List module DBs from [`module-database-boundaries.ts`](../apps/api/src/platform/database/module-database-boundaries.ts) + connection ok/fail |
| `make db-shell MODULE=auth` | `psql` into `flex_auth` via local Postgres |
| `make db-reset` | Recreate local Postgres volume + re-run [`init-module-databases.sh`](../docker/postgres/init-module-databases.sh) |

### Database — cloud

| Target | Purpose |
|--------|---------|
| `make db-cloud-check` | Read `*_DATABASE_URL` from env; test TCP/auth to each; report failures |
| `make db-cloud-tunnel` | *(future)* Start SSM/bastion port-forward when `CLOUD_DB_TUNNEL_CONFIG` is set |
| `make up FLEX_ENV=cloud` | Skip local Postgres; validate cloud URLs; start apps only |

Cloud env file pattern:

```text
.env.cloud.example     # template for cloud URLs (no secrets committed)
.env.local             # optional override (gitignored)
.env                   # active config (gitignored)
```

Example cloud vars (per module, already in architecture):

```env
FLEX_ENV=cloud
AUTH_DATABASE_URL=postgresql://user:pass@flex-auth.xxxx.region.rds.amazonaws.com:5432/flex_auth
# ... other module URLs
```

`make up` with `FLEX_ENV=cloud` must **not** start Docker Postgres; must run `db-cloud-check` first.

### Quality (thin wrappers — keep existing behavior)

| Target | Purpose |
|--------|---------|
| `make test` | `npm run test` |
| `make test-coverage` | `npm run test:coverage` |
| `make sonar-scan` | existing script |
| `make check` | typecheck + test + lint (pre-CI local gate) |

---

## `make up` sequence (detailed)

```text
make up
  │
  ├─ 1. Load .env (if present)
  ├─ 2. FLEX_ENV=local (default)
  │      → $(COMPOSE) --profile observability up -d
  │      → (postgres starts — no profile required)
  ├─ 3. FLEX_ENV=cloud
  │      → skip postgres container
  │      → scripts/ops/db-cloud-check.sh
  ├─ 4. scripts/ops/wait-healthy.sh
  │      → postgres :5432
  │      → grafana :3001/api/health
  │      → otel-collector :13133
  │      → api :3000/api/health (after apps start)
  ├─ 5. scripts/ops/start-apps.sh
  │      → npm run dev:api (background)
  │      → npm run dev:web (background)
  ├─ 6. scripts/ops/print-urls.sh
  └─ 7. Exit 0 with summary table
```

Optional flags via variables:

```bash
make up SONAR=1          # include sonar profile
make up APPS=0           # infra only (Grafana debugging)
make up OBSERVABILITY=0  # postgres + apps only (fast mode)
```

---

## Health / status output (example)

`make status` shows a rich dashboard: health icons, container state, uptime, memory,
reachable URLs, actionable tips, and a daily dev quote.

```
$ make status

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  FLEX Service Status
  Wednesday, July 1 2026 · 14:30 CEST
  Runtime: podman (podman compose)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  💬 There are only two hard things in Computer Science: cache invalidation...

  6/9 services healthy

  SERVICE          HEALTH             STATE          UPTIME       MEMORY       URL
  ────────────────────────────────────────────────────────────────────────────
  postgres         ● healthy          running        2 hours ago  45.2MiB      localhost:5432
  grafana          ● healthy          running        2 hours ago  128MiB       http://localhost:3001/
  ...

  Quick access
  ────────────
  → Grafana (dashboards): http://localhost:3001/
  → API: http://localhost:3000/

  Tips
  ────
  • Web not running — run: make up-apps
```

This directly answers “is Grafana running?” without reading compose docs.

---

## Agent governance (add to AGENTS.md)

When an agent hits a recurring operational problem:

1. Check `make help` and [`docs/dev-operations.md`](../docs/dev-operations.md)
2. If no target exists, **add one** in the appropriate `make/*.mk` + `scripts/ops/*.sh`
3. Update `make help` text and status/urls if a new service is involved
4. Do **not** document one-off shell sequences in chat only

---

## Documentation to add

| File | Content |
|------|---------|
| [`docs/dev-operations.md`](../docs/dev-operations.md) | Full ops guide: `make up`, cloud mode, troubleshooting |
| [`docs/README.md`](../docs/README.md) | Link to dev-operations |
| [`README.md`](../README.md) | Replace fragmented make section with `make up` / `make help` |
| [`.env.cloud.example`](../.env.cloud.example) | Cloud DB URL template |
| [`.gitignore`](../.gitignore) | Add `.flex/run/` |

---

## Container runtime detection

Infra scripts **prefer Podman over Docker** and auto-detect the compose command:

```text
scripts/ops/container-runtime.sh
  1. podman + (podman compose | podman-compose)  — preferred
  2. docker + (docker compose | docker-compose)  — fallback
```

| Variable / target | Purpose |
|-------------------|---------|
| `CONTAINER_RUNTIME` | `podman` or `docker` (from `make/variables.mk`) |
| `COMPOSE` | Full compose command, e.g. `podman compose` |
| `make runtime` | Prints `runtime\|compose` for debugging |

If the daemon is down, the script prints a hint:

- Podman: `podman machine start` (macOS)
- Docker: `colima start` or Docker Desktop

`scripts/ops/up-infra.sh` sources `container-runtime.sh` and prints which runtime is used on every `make up-infra` / `make up`.

---

## Docker Compose adjustments

1. **Rename profile** `observability` → keep as-is (already includes Grafana)
2. **Add `depends_on` health** where missing so `wait-healthy.sh` is reliable
3. **Optional `apps` profile** (phase 2): run API/web via Docker for parity with production — not required for phase 1
4. **Fix `make stack`** bug: current `stack` omits explicit postgres in docs but postgres has no profile — document that `up-infra` always includes postgres

---

## Implementation phases

### Phase 1 — Fix the Grafana gap (high priority)

- [x] `make up-infra` = postgres + observability profile
- [x] `make up` = up-infra + wait-healthy + up-apps + urls
- [x] `make down`, `make status`, `make urls`, `make help`
- [x] `scripts/ops/wait-healthy.sh`, `start-apps.sh`, `stop-apps.sh`, `print-urls.sh`
- [x] `scripts/ops/container-runtime.sh` — Podman preferred, Docker fallback
- [x] `make runtime` — show detected runtime + compose command
- [x] Deprecate aliases: `deps` → `up-infra-minimal`, `stack` → `up-infra-full`
- [ ] Update README and add `docs/dev-operations.md`

### Phase 2 — Database operations

- [ ] `make db-status`, `make db-shell MODULE=auth`
- [ ] `FLEX_ENV=cloud` + `make db-cloud-check`
- [ ] `.env.cloud.example`
- [ ] `make up FLEX_ENV=cloud` path

### Phase 3 — Quality integration

- [ ] `make check` (typecheck + test + lint)
- [ ] `make up SONAR=1` optional in `make up`
- [ ] Pre-push docs reference `make check` not raw npm

### Phase 4 — Cloud tunnel / migrations (when RDS exists)

- [ ] `make db-cloud-tunnel` (SSM/bastion — ADR required)
- [ ] `make db-migrate MODULE=auth` (per-module Prisma — when persistence lands)
- [ ] Optional Docker `apps` profile for CI-like local runs

---

## Migration map (old → new)

| Old | New |
|-----|-----|
| `make deps` | `make up-infra-minimal` (postgres only) or part of `make up` |
| `make stack` | `make up-infra-full` or `make up SONAR=1` |
| `make observability` | `make up-infra` (same compose profile) |
| `npm run dev:api` + `npm run dev:web` manually | `make up-apps` or included in `make up` |
| “Is Grafana running?” | `make status` |

---

## Out of scope (this plan)

- Terraform / RDS provisioning (separate infra ADR)
- Production ECS/K8s deploy targets (CI/CD plan)
- RabbitMQ broker in `make up` (until ADR accepted)

---

## Implementation checklist

| ID | Task | Status |
|----|------|--------|
| makefile-split | Split Makefile into `make/*.mk` fragments | done |
| ops-scripts | Add `scripts/ops/` health, start/stop apps, urls | done |
| make-up | Implement `make up` / `make down` / `make status` | done |
| container-runtime | Podman/Docker auto-detection in `container-runtime.sh` | done |
| cloud-env | `FLEX_ENV=cloud`, `.env.cloud.example`, `db-cloud-check` | pending |
| db-local | `db-status`, `db-shell`, `db-reset` | pending |
| docs | `docs/dev-operations.md`, README, AGENTS.md governance | pending |
| deprecate | Aliases for `deps`, `stack`, `observability` | pending |
