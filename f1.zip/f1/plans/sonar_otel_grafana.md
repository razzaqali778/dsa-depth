# SonarQube + OpenTelemetry + Grafana Stack

> **Living document** — plan for local SonarQube, full LGTM observability stack, git hook integration, and pre-provisioned Grafana dashboards.

## Overview

Add Dockerized local SonarQube and full LGTM observability stack (OTEL Collector, Tempo, Prometheus, Loki, Grafana) with Makefile commands, wire the NestJS API to export OTLP traces/metrics, extend git hooks to push Sonar scans (local + optional SonarCloud), and ship pre-provisioned Grafana dashboards plus a project skill for creating new ones.

## Current state

| Area | Today |
|------|-------|
| Docker | Only Postgres in [`docker-compose.yml`](../docker-compose.yml); `make deps` starts it |
| Telemetry | Log-only [`TracingInterceptor`](../apps/api/src/platform/telemetry/tracing.interceptor.ts) + [`@Traced`](../apps/api/src/platform/telemetry/traced.decorator.ts) — **no OTEL SDK** |
| Sonar | ESLint **SonarJS** rules locally; **no SonarQube server, no scanner, no `sonar-project.properties`** |
| Git hooks | [`.husky/pre-push`](../.husky/pre-push) runs build + coverage + SonarJS lint summary — **does not upload to Sonar** |
| Grafana | Planned in [`bootstrap_code.md`](bootstrap_code.md) Part 5 — **not implemented** |
| Infra folder | Does not exist |

---

## Target architecture

```mermaid
flowchart TB
  subgraph dev [Developer machine]
    GitHooks[pre-push hook]
    FlexAPI[flex-api NestJS]
  end

  subgraph sonarDocker [make sonar]
    SonarQube[SonarQube :9000]
    SonarDB[(sonar-db)]
  end

  subgraph obsDocker [make observability]
    OTEL[OTEL Collector :4317/:4318]
    Tempo[Tempo :3200]
    Prom[Prometheus :9090]
    Loki[Loki :3100]
    Grafana[Grafana :3001]
  end

  GitHooks -->|sonar-scanner + lcov| SonarQube
  GitHooks -.->|SONAR_CLOUD=true| SonarCloud[SonarCloud optional]
  FlexAPI -->|OTLP traces+metrics| OTEL
  OTEL --> Tempo
  OTEL --> Prom
  OTEL --> Loki
  Grafana --> Tempo
  Grafana --> Prom
  Grafana --> Loki
```

---

## Part 1: Docker Compose — split by concern

Use **Compose profiles** in an extended [`docker-compose.yml`](../docker-compose.yml) (or `docker-compose.observability.yml` + `docker-compose.sonar.yml` included via `include:`). Profiles keep `make deps` fast (Postgres only) while allowing full stacks on demand.

### Services to add

**Profile `sonar`** (local SonarQube):

| Service | Image | Port | Notes |
|---------|-------|------|-------|
| `sonar-db` | `postgres:16-alpine` | internal | Dedicated DB for SonarQube |
| `sonarqube` | `sonarqube:community` | `9000` | Default login `admin`/`admin` (forced change on first use) |

**Profile `observability`** (full LGTM):

| Service | Image | Ports | Role |
|---------|-------|-------|------|
| `otel-collector` | `otel/opentelemetry-collector-contrib` | `4317` gRPC, `4318` HTTP, `8889` metrics | Receives OTLP from flex-api; exports to backends |
| `tempo` | `grafana/tempo` | `3200` | Trace storage |
| `prometheus` | `prom/prometheus` | `9090` | Metrics storage (scrapes collector + self) |
| `loki` | `grafana/loki` | `3100` | Log storage |
| `grafana` | `grafana/grafana` | `3001` → 3000 | Dashboards (anonymous admin for local dev) |

### New config files (under `infra/`)

```
infra/
├── otel-collector/config.yaml      # receivers: otlp; exporters: tempo, prometheus, loki
├── tempo/tempo.yaml
├── prometheus/prometheus.yml       # scrape otel-collector + prometheus self
├── loki/loki-config.yaml
└── grafana/
    ├── provisioning/
    │   ├── datasources/datasources.yaml   # Tempo, Prometheus, Loki (linked)
    │   └── dashboards/dashboards.yaml     # auto-load JSON from dashboards/
    └── dashboards/
        ├── flex-api-traces.json           # Tempo: service=flex-api, latency waterfall
        ├── flex-api-metrics.json          # Prometheus: request rate, error rate, duration
        └── flex-platform-overview.json    # Combined RED metrics + trace search
```

Leverage the config sketches already in [`bootstrap_code.md`](bootstrap_code.md) (Part 5) as the starting point.

---

## Part 2: Makefile commands

Extend [`Makefile`](../Makefile):

| Target | Command | What it does |
|--------|---------|--------------|
| `deps` | *(existing)* | `docker compose up -d postgres` |
| `sonar` | `docker compose --profile sonar up -d` | Start local SonarQube |
| `sonar-down` | `docker compose --profile sonar down` | Stop SonarQube |
| `observability` | `docker compose --profile observability up -d` | Start OTEL + LGTM stack |
| `observability-down` | `docker compose --profile observability down` | Stop observability stack |
| `stack` | `docker compose --profile sonar --profile observability up -d postgres` | All dev infra (Postgres + Sonar + observability) |
| `stack-down` | `docker compose --profile sonar --profile observability down` | Tear down all profiles |
| `sonar-scan` | `./scripts/sonar-scan.sh` | Run scanner manually (also called from hook) |

Update [`README.md`](../README.md) with URLs:

- Grafana: http://localhost:3001
- SonarQube: http://localhost:9000
- Prometheus: http://localhost:9090
- Tempo: http://localhost:3200

---

## Part 3: OpenTelemetry in flex-api

### Dependencies

Add to [`apps/api/package.json`](../apps/api/package.json):

- `@opentelemetry/sdk-node`
- `@opentelemetry/api`
- `@opentelemetry/exporter-trace-otlp-http`
- `@opentelemetry/exporter-metrics-otlp-http`
- `@opentelemetry/sdk-metrics`
- `@opentelemetry/resources`
- `@opentelemetry/semantic-conventions`
- `@opentelemetry/auto-instrumentations-node`
- `@opentelemetry/instrumentation-nestjs-core` (optional, complements custom interceptor)

### New file: `apps/api/src/platform/telemetry/otel-sdk.ts`

- `initTelemetry({ serviceName: "flex-api" })` — must be called **before** NestJS bootstraps
- OTLP endpoint from env: `OTEL_EXPORTER_OTLP_ENDPOINT` (default `http://localhost:4318`)
- Auto-instrument HTTP, Express, `pg` (ready for when Prisma/DB is wired)

### Wire into app

[`apps/api/src/main.ts`](../apps/api/src/main.ts) — first lines:

```typescript
import { initTelemetry } from "./platform/telemetry/otel-sdk";
initTelemetry({ serviceName: "flex-api", version: "0.1.0" });
```

### Upgrade existing tracing to real spans

Refactor [`tracing.interceptor.ts`](../apps/api/src/platform/telemetry/tracing.interceptor.ts) and [`traced.decorator.ts`](../apps/api/src/platform/telemetry/traced.decorator.ts) to create **OpenTelemetry spans** (using `@opentelemetry/api`) while keeping structured logs as a fallback. This gives parent/child span hierarchy: `HTTP → Controller → Service`.

### Environment ([`.env.example`](../.env.example))

```env
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4318
OTEL_SERVICE_NAME=flex-api
OTEL_TRACES_EXPORTER=otlp
OTEL_METRICS_EXPORTER=otlp
```

When observability stack is down, SDK should log a warning and not crash the API (graceful degrade).

---

## Part 4: SonarQube — local + optional SonarCloud

### Project config

**New:** [`sonar-project.properties`](../sonar-project.properties)

```properties
sonar.projectKey=flex
sonar.projectName=FLEX Resource Allocation Platform
sonar.sources=apps/api/src,apps/web/src
sonar.tests=apps/api/src,apps/web/src
sonar.test.inclusions=**/*.spec.ts,**/*.test.ts,**/*.spec.tsx,**/*.test.tsx
sonar.exclusions=**/node_modules/**,**/dist/**,**/*.module.ts,**/main.ts
sonar.javascript.lcov.reportPaths=apps/api/coverage/lcov.info,apps/web/coverage/lcov.info
sonar.typescript.tsconfigPath=apps/api/tsconfig.json,apps/web/tsconfig.json
```

### Scan script

**New:** [`scripts/sonar-scan.sh`](../scripts/sonar-scan.sh)

1. Check `SONAR_HOST_URL` (default `http://localhost:9000`)
2. Require `SONAR_TOKEN` (generate in SonarQube UI → My Account → Tokens)
3. Run `npx @sonar/scan` (or `sonar-scanner` if preferred) after coverage exists
4. If `SONAR_CLOUD=true`, override host to `https://sonarcloud.io` (or Bayer corporate URL) and use `SONAR_ORGANIZATION` + cloud project key from env
5. If SonarQube is unreachable: print clear message (`make sonar` to start) and **exit 0 with warning** on pre-push (or exit 1 — recommend **warn-only locally, strict in CI**)

### First-time SonarQube setup doc

Add `docs/sonarqube-local.md`:

1. `make sonar`
2. Open http://localhost:9000, create project `flex`, generate token
3. Add `SONAR_TOKEN=...` to `.env`

### `.env.example` additions

```env
SONAR_HOST_URL=http://localhost:9000
SONAR_TOKEN=
SONAR_PROJECT_KEY=flex
SONAR_CLOUD=false
# When SONAR_CLOUD=true:
# SONAR_HOST_URL=https://sonarcloud.io
# SONAR_ORGANIZATION=your-org
```

---

## Part 5: Git hooks — push reports to Sonar

Update [`.husky/pre-push`](../.husky/pre-push) — add **Step 5** after coverage:

```
Step 5/5: SonarQube scan (upload coverage + analysis)
  → npm run sonar:scan  (calls scripts/sonar-scan.sh)
  → Uses lcov from Step 2
  → Local by default; SonarCloud when SONAR_CLOUD=true
```

Add to root [`package.json`](../package.json):

```json
"sonar:scan": "bash ./scripts/sonar-scan.sh"
```

Update [`githooks.md`](githooks.md) Part 7 table: add row for SonarQube upload on pre-push.

**Note:** Pre-push already runs `test:coverage` which produces `lcov.info` — Sonar scanner consumes those files. Web Vitest must emit `lcov` (already configured in [`apps/web/vite.config.ts`](../apps/web/vite.config.ts)).

---

## Part 6: Pre-provisioned Grafana dashboards

Ship **3 starter dashboards** (JSON, version-controlled) covering the FLEX API:

| Dashboard | Panels |
|-----------|--------|
| **FLEX API — Traces** | Trace search by `service.name=flex-api`, p95 latency, error traces, link to logs |
| **FLEX API — Metrics** | Request rate, error rate, duration histogram (from OTEL → Prometheus) |
| **FLEX Platform Overview** | Module bootstrap health, active spans, top endpoints |

Provision via `infra/grafana/provisioning/dashboards/dashboards.yaml` so they appear automatically on `make observability`.

**Validation:** after `make observability` + `npm run dev:api`, hit `GET /api/auth/summary` a few times → traces visible in Grafana Explore → Tempo within ~30s.

---

## Part 7: Grafana dashboard skill

Create project skill: `.cursor/skills/grafana-dashboards/SKILL.md`

Contents:

- When to use (adding/modifying FLEX observability dashboards)
- Local URLs and datasource UIDs (`tempo`, `prometheus`, `loki`)
- Workflow: Explore → build panel → Export JSON → save to `infra/grafana/dashboards/` → reload Grafana
- Panel templates for NestJS (HTTP duration, status codes, service.name labels)
- How to link traces → logs → metrics using provisioned datasource correlations
- Reference existing pre-built dashboards as examples

This gives developers a repeatable path without requiring Grafana expertise.

Also update [`docs/README.md`](../docs/README.md) index with links to `docs/sonarqube-local.md` and `docs/observability.md`.

---

## Part 8: Documentation

**New:** `docs/observability.md`

- `make observability` / `make stack`
- Env vars for OTEL
- How to view traces in Grafana
- Troubleshooting (collector not receiving, port conflicts with API on 3000 vs Grafana on 3001)

---

## Implementation order

1. **Infra configs** — `infra/otel-collector`, tempo, prometheus, loki, grafana provisioning
2. **Docker Compose profiles** — sonar + observability services
3. **Makefile targets** — `sonar`, `observability`, `stack`, `sonar-scan`
4. **OTEL SDK** — `otel-sdk.ts`, wire `main.ts`, upgrade interceptor/decorator to real spans
5. **Sonar** — `sonar-project.properties`, `scripts/sonar-scan.sh`, `.env.example`
6. **Git hook** — pre-push Step 5
7. **Grafana dashboards** — 3 JSON dashboards + provisioning
8. **Docs + skill** — observability guide, sonarqube-local guide, grafana-dashboards skill
9. **Smoke test** — `make stack`, run API, curl endpoints, verify Grafana + SonarQube

---

## Implementation checklist

| ID | Task | Status |
|----|------|--------|
| infra-docker | Add `infra/` configs and docker-compose profiles for sonar + observability | done |
| makefile-targets | Extend Makefile with sonar, observability, stack, sonar-scan targets | done |
| otel-sdk | Install OTEL packages, create otel-sdk.ts, wire main.ts, upgrade TracingInterceptor and @Traced | done |
| sonar-setup | Add sonar-project.properties, scripts/sonar-scan.sh, .env.example vars | done |
| git-hooks | Add Step 5 to pre-push: npm run sonar:scan after coverage | done |
| grafana-dashboards | Provision 3 pre-built Grafana dashboards + grafana-dashboards Cursor skill | done |
| docs | Add docs/observability.md, docs/sonarqube-local.md, update README | done |

---

## Out of scope (future)

- CI pipeline SonarCloud PR decoration (mentioned in githooks.md Part 8)
- Promtail / structured log shipping from NestJS to Loki (Loki container ready; log pipeline can follow)
- Corporate Bayer SonarCloud project key provisioning (document env vars; user supplies token/org)
- Web frontend OTEL (browser traces) — API first
