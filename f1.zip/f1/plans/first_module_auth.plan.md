---
name: Create FLEX Module
overview: Scaffold auth as a first-class business module (same pattern as outcomes/finops) with event-based cross-module communication, while shrinking platform/auth to thin ingress identity propagation only. Includes generator fix for empty catalog.
todos:
  - id: document-platform-boundary
    content: Add platform vs modules boundary section to docs/architecture.md (contracts only in platform; all domain logic and data in modules)
    status: pending
  - id: clarify-auth-split
    content: Document and implement the split — platform/auth = ingress identity only; modules/auth = authorization domain (users, roles, permissions, events)
    status: pending
  - id: fix-generator
    content: Update create-flex-module.sh auto-registration to work with empty catalog/router/shell
    status: completed
  - id: run-generator
    content: Run npm run module -- auth to scaffold the auth business module (backend + frontend)
    status: pending
  - id: wire-auth-events
    content: Define auth domain events (user-provisioned, role-assigned, permission-changed) and wire EventBusPort publish/subscribe contracts in auth.definition.ts
    status: pending
  - id: wire-database
    content: Add flex_auth to init-module-databases.sh and AUTH_DATABASE_URL to local .env
    status: pending
  - id: verify-module
    content: Run typecheck/tests and smoke-test /api/auth/summary + web /auth route
    status: pending
isProject: false
---

# Create a New FLEX Module — Auth as a First-Class Module

## Platform vs modules — the boundary

**One-sentence rule:** Platform holds **contracts and wiring** that every module needs but no module should own. Modules hold **domain logic, data, UI, and integrations**.

```mermaid
flowchart LR
  subgraph platform [Platform - no business data]
    Net[network]
    IdCtx[identity-context]
    Tel[telemetry]
    Msg[messaging ports]
    Int[integration ports]
    Mod[module registry]
    DBmeta[database metadata]
  end

  subgraph modules [Business Modules - own everything else]
    Auth[auth]
    Outcomes[outcomes]
    FinOps[finops]
  end

  platform --> modules
```

### What belongs in `platform/` (today: `apps/api/src/platform/`)

| Folder | Belongs here because | Contains | Does NOT contain |
|--------|---------------------|----------|------------------|
| `network/` | Every HTTP service needs the same prefix, CORS, validation | `configureNetwork()` | Route handlers, business validation rules |
| `auth/` | Every controller needs caller identity from the gateway | Guard, `@CurrentUser()`, `@Public()`, `AuthenticatedUser` type | Users DB, roles, permissions, login, SSO |
| `telemetry/` | Every layer should be traced the same way | `TracingInterceptor`, `@Traced()`, `TelemetryModule` | Business metrics, domain audit logs |
| `messaging/` | Event shape and bus interface must be shared | `IntegrationEvent`, `EventBusPort` | Concrete publishers, subscribers, queue config, domain event payloads |
| `integration/` | Adapter *shape* is shared; implementations are not | `SourceAdapterPort`, `SourceSnapshot` types | Workday/RPT/IdP clients, API keys, mappers |
| `database/` | Cross-module registry of DB boundaries | `MODULE_DATABASE_BOUNDARIES`, `CanonicalSnapshot` type | Prisma schemas, queries, repositories |
| `modules/` | Monolith needs one catalog to bootstrap all modules | `FlexModuleDefinition`, `FLEX_MODULE_CATALOG`, `bootstrapModules()` | Business services, controllers |

**Platform code has no `*.definition.ts`, no physical database, no REST routes for business features, no Redux slice, no frontend pages.**

### What belongs in `modules/{name}/`

| Layer | Location | Owns |
|-------|----------|------|
| Contract | `{name}.definition.ts` | DB name, env var, events, integrations, responsibilities |
| API | `presentation/` | Controllers, DTOs, HTTP routes |
| Application | `application/services/` + `application/ports/` | Use cases, repository/adapter/event *interfaces* |
| Domain | `domain/` | Entities, domain events (names + payloads) |
| Infrastructure | `infrastructure/` | Prisma repos, external API clients, event bus *implementations* |
| Frontend | `apps/web/src/modules/{name}/` | Pages, API client, Redux slice, types |

**If it stores business data, publishes domain events, or talks to an external system — it is a module, not platform.**

### At microservice extraction

Platform does not become a microservice. It becomes **shared npm packages** copied into each service:

```text
@flex/platform-telemetry   → TracingInterceptor, @Traced()
@flex/platform-identity    → GatewayAuthGuard, @CurrentUser()
@flex/platform-messaging   → EventBusPort, IntegrationEvent
@flex/platform-integration → SourceAdapterPort
```

Each extracted service runs:

```text
main.ts
  → TelemetryModule + IdentityModule + HealthModule
  → ONE business module (e.g. AuthModule or OutcomesModule)
```

The monolith is just all business modules + platform in one process. **Same module code; platform is the glue.**

### Quick decision test

Ask: *"Does this have a database, domain events, or an admin UI?"*

- **Yes** → `modules/`
- **No, but every service needs the same interface** → `platform/`

Examples:

- User role management → `modules/auth`
- Reading `x-flex-user-id` header → `platform/auth`
- `auth.role-assigned.v1` event payload type → `modules/auth/domain/events/`
- `EventBusPort.publish()` interface → `platform/messaging/`
- Workday API client → `modules/people-planning/infrastructure/integrations/workday/`

---

## Why it feels broken today

There are **two different concerns** both named "auth", but only one is implemented:

| Concern | What it is | Where it lives today |
|---------|-----------|---------------------|
| **Authentication (ingress)** | Who is calling this request? Validate IdP/gateway identity and attach `user` to the request. | [`apps/api/src/platform/auth/`](apps/api/src/platform/auth/) — `GatewayAuthGuard`, `@CurrentUser()`, `@Public()` |
| **Authorization domain** | What users, roles, and permissions exist? Who can do what inside FLEX? | **Not implemented** — no business module, no DB, no events |

[`platform/auth/README.md`](apps/api/src/platform/auth/README.md) explicitly states: *"FLEX does not implement SSO inside product modules."* The platform layer only reads headers forwarded by the enterprise API gateway (`x-flex-user-id`, `x-flex-user-roles`, etc.). It is **not** a business module and does not follow `FlexModuleDefinition`.

That is why creating `npm run module -- auth` felt wrong — you would end up with two unrelated things both called auth.

**This is a design gap, not a generator bug.** The fix is to make the authorization domain a real business module while keeping ingress identity as thin platform infrastructure.

---

## Target architecture: auth module + thin platform layer

```mermaid
flowchart TB
  subgraph ingress [Ingress - stays platform or gateway]
    IdP[Enterprise IdP]
    GW[API Gateway]
    Guard[GatewayAuthGuard - thin]
  end

  subgraph authModule [Auth Business Module - extractable]
    AuthAPI["/api/auth/*"]
    AuthSvc[AuthService]
    AuthDB[(flex_auth)]
    AuthEvents[Event publisher]
  end

  subgraph otherModules [Other Business Modules]
    Outcomes[Outcomes module]
    FinOps[FinOps module]
    LocalProj[Local role/permission projection]
  end

  subgraph bus [Event Bus]
    EB[In-process now / RabbitMQ later]
  end

  IdP --> GW
  GW --> Guard
  Guard --> AuthAPI
  Guard --> Outcomes
  Guard --> FinOps
  AuthAPI --> AuthSvc --> AuthDB
  AuthSvc --> AuthEvents --> EB
  EB --> LocalProj
  LocalProj --> Outcomes
  LocalProj --> FinOps
```

### What stays in `platform/auth` (cross-cutting, not extractable as a business service)

Minimal **identity context** only — every service needs this, like telemetry or validation:

- `GatewayAuthGuard` — reads gateway headers (or dev-mode stub user)
- `@CurrentUser()` — injects `AuthenticatedUser` into controllers
- `@Public()` — opt-out for health checks etc.
- `AuthenticatedUser` type — `{ id, email, displayName, roles }`

This is **not** the auth domain. It does not own a database, publish business events, or have admin UI. When you extract microservices, each service **imports the same thin guard package** (or the gateway terminates auth and internal services trust forwarded headers).

Rename optional later: `platform/auth` → `platform/identity-context` to reduce naming collision.

### What becomes `modules/auth` (full business module, same pattern as all others)

A standard FLEX module registered in `FLEX_MODULE_CATALOG`:

```typescript
// auth.definition.ts (target shape)
{
  key: "auth",
  displayName: "Auth",
  route: "/api/auth",
  nestModule: AuthModule,
  enabled: true,
  databaseName: "flex_auth",
  databaseUrlEnvVar: "AUTH_DATABASE_URL",
  responsibilities: [
    "User provisioning and profile sync from enterprise IdP",
    "Role and permission definitions",
    "Authorization policy storage",
  ],
  sourceIntegrations: [
    { sourceSystem: "enterprise-idp", direction: "read-only", ... },
  ],
  publishesEvents: [
    "auth.user-provisioned.v1",
    "auth.role-assigned.v1",
    "auth.permission-changed.v1",
  ],
  consumesEvents: [],  // other modules consume auth events, not the reverse
}
```

**Domain API examples** (beyond boilerplate `/summary`):

- `GET /api/auth/users` — list users (admin)
- `GET /api/auth/users/:id/permissions` — resolve effective permissions
- `POST /api/auth/roles` — manage roles
- Sync endpoint to pull users/roles from enterprise IdP via source adapter

**Event-driven cross-module communication** (your requirement):

```text
Auth module writes flex_auth
  → publishes auth.role-assigned.v1
  → EventBusPort (in-process today)
  → Outcomes / FinOps subscribers update local projection tables
  → module services check permissions locally (no sync call to auth on every request)
```

Tomorrow when auth graduates to a microservice:

```text
auth-service publishes to RabbitMQ exchange
  → same event names, same payloads
  → other services' subscribers unchanged (only EventBus implementation swaps)
```

No direct SQL across databases. No synchronous HTTP call from every module to auth on every request. **Events are the integration contract** — same as outcomes → business-usecase projections.

---

## Microservice extraction: how auth fits the same pattern

From [`plans/bootstrap_code.md`](plans/bootstrap_code.md), any module extracts by:

1. `FlexModuleDefinition` already declares DB, routes, events, integrations
2. Create `apps/auth-service/` with its own `main.ts`
3. Import `AuthModule` + platform infra (`TelemetryModule`, thin `AuthModule` guard)
4. Point to `flex_auth` database
5. Connect to RabbitMQ for cross-service events
6. Remove `auth` from monolith catalog

```text
Monolith (today):
  AppModule
    ├── TelemetryModule          ← platform package, copied to every service
    ├── platform/AuthModule        ← thin guard only
    └── bootstrapModules()
          ├── auth                 ← business module
          ├── outcomes
          └── finops

auth-service (tomorrow):
  AuthServiceApp
    ├── TelemetryModule
    ├── platform/AuthModule        ← same thin guard
    └── AuthModule                 ← extracted business module, unchanged code
```

**Key rule:** platform auth guard validates *who* is calling. Auth business module owns *what they are allowed to do* and communicates that to other modules via events (and optional read API for admin UI).

---

## How to create the auth module

### Command

```bash
npm run module -- auth
# or
make module MODULE=auth
```

Name must be kebab-case.

### What the generator scaffolds

**Backend** — [`scripts/create-flex-module.sh`](scripts/create-flex-module.sh):

```text
apps/api/src/modules/auth/
  auth.definition.ts
  auth.module.ts
  application/{ports,services}/
  domain/events/
  infrastructure/{events,integrations,persistence}/
  presentation/{controllers,dto}/
```

**Frontend**:

```text
apps/web/src/modules/auth/
  api/  pages/  state/  types/
```

**Auto-registers** (after generator fix): catalog, router, reducers, nav.

### Generator fix still required

Current script anchors on removed `people-planning` entries. With empty catalog, auto-registration fails. Fix [`scripts/create-flex-module.sh`](scripts/create-flex-module.sh) to handle first-module / empty-state before running.

### Manual steps after generation

1. Add `create_database flex_auth` to [`docker/postgres/init-module-databases.sh`](docker/postgres/init-module-databases.sh)
2. Add `AUTH_DATABASE_URL=postgresql://flex:flex@localhost:5432/flex_auth` to local `.env`
3. Fill `auth.definition.ts` responsibilities, integrations, and event names
4. Implement domain beyond boilerplate `getSummary()`
5. Wire `EventBusPort` in auth infrastructure when messaging module lands

---

## What you can build on the scaffold

Same as any FLEX module ([`docs/module-blueprint.md`](docs/module-blueprint.md)):

| Layer | Auth module work |
|-------|-----------------|
| Read flow | `controller → service → repository → flex_auth` |
| Sync flow | `controller → service → IdP adapter → canonical event → repository → flex_auth` |
| Cross-module | Publish role/permission events; other modules subscribe |
| Frontend | Admin pages for users/roles; Redux slice for auth UI state |
| Extraction | Same `auth.definition.ts` drives standalone `auth-service` |

Platform capabilities inherited automatically:

- `@Traced()` on services
- Thin `GatewayAuthGuard` on all routes (ingress identity)
- Module isolation via `AUTH_DATABASE_URL`

---

## Recommended implementation sequence

1. **Clarify the split in docs** — update [`docs/architecture.md`](docs/architecture.md) auth layer description to distinguish ingress vs auth domain module
2. **Fix generator** for empty catalog state
3. **Scaffold `auth` business module** via `npm run module -- auth`
4. **Define event contracts** in `domain/events/` and `auth.definition.ts` `publishesEvents`
5. **Implement auth persistence** — users, roles, permissions tables in `flex_auth`
6. **Add IdP source adapter** under `infrastructure/integrations/`
7. **Subscribe from one pilot module** (e.g. outcomes) to prove event-driven authz projection
8. **Keep `platform/auth` thin** — do not move domain logic there

---

## Open decision resolved

You chose: **auth as any module, event communication, microservice-ready by design.**

That means:
- Do **not** delete `platform/auth` — it becomes the thin ingress layer every service shares
- Do **create** `modules/auth` as the authorization domain with its own DB and events
- Cross-module authz uses **events + local projections**, not shared DB or per-request sync calls
- Microservice extraction is identical to outcomes/finops — swap EventBus implementation, extract `AuthModule` + definition
