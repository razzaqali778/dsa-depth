
# Plan: Module Bootstrap, Telemetry & Generator Pattern

## Overview

This document describes the complete architecture for:

1. **Module Bootstrap/Registry** — a runtime pattern that loads, validates, and logs all business modules from a single catalog
2. **OpenTelemetry Instrumentation** — end-to-end distributed tracing across all four layers (API → Service → Network → Data) with Grafana stack visualization
3. **Per-Module Database Pooling** — isolated connection pools per module per worker thread
4. **Module Generator CLI** — a dev-time tool that scaffolds new modules with all of the above pre-wired
5. **Event Pub/Sub** — in-process event bus with publish/subscribe, `@OnEvent()` decorator, and a swap-ready broker interface
6. **Background Task Scheduler** — async task runner for resource updates, notifications, and scheduled work

---

## Current State (as of July 2026)

The codebase has evolved beyond the original plan. The following is already in place:

```
apps/api/src/
├── platform/
│   ├── auth/                        ✅ Gateway auth guard, JWT context
│   ├── database/                    ✅ Module database boundary definitions
│   ├── integration/                 ✅ Source adapter port contracts
│   ├── messaging/                   ✅ Event bus port contracts
│   ├── modules/                     ✅ FlexModuleDefinition + FLEX_MODULE_CATALOG
│   └── network/                     ✅ CORS, validation, global prefix
└── modules/
    ├── outcomes/                    ✅ Full module structure
    ├── business-usecase/            ✅ Full module structure
    ├── finops/                      ✅ Full module structure
    └── people-planning/             ✅ Full module structure
```

**Remaining gaps:**
- `AppModule` still hardcodes module imports (no `bootstrapModules()` call)
- `FlexModuleDefinition` lacks `nestModule`, `enabled`, and `databasePoolSize` fields
- No `bootstrap-modules.ts` utility
- No OpenTelemetry instrumentation
- No per-module Prisma connection pools
- No module generator CLI
- No Grafana observability stack in docker-compose

---

## Part 1: Module Bootstrap/Registry Pattern

### Design

The `FLEX_MODULE_CATALOG` (already in `platform/modules/flex-module.catalog.ts`) is the single source of truth. We extend it with runtime fields and add a `bootstrapModules()` utility.

### 1.1 Updated `FlexModuleDefinition`

**File:** `apps/api/src/platform/modules/flex-module.definition.ts` (MODIFY)

```typescript
import type { Type } from "@nestjs/common";

export type FlexModuleKey =
  | "outcomes"
  | "business-usecase"
  | "finops"
  | "people-planning";

export type SourceIntegrationDefinition = {
  sourceSystem: string;
  direction: "read-only" | "write-back-future";
  adapterBoundary: string;
  ownedByModule: boolean;
};

export type FlexModuleDefinition = {
  key: FlexModuleKey;
  displayName: string;
  route: string;

  // ── Runtime bootstrap fields ──────────────────────────────────────────
  nestModule: Type<unknown>;           // Reference to the NestJS @Module class
  enabled: boolean;                    // Feature flag — can be driven by env vars

  // ── Database boundary ─────────────────────────────────────────────────
  databaseBoundary: string;
  databaseName: string;
  databaseUrlEnvVar: string;
  databasePoolSize?: number;           // Connections per worker thread (default: 5)

  // ── Module contract ───────────────────────────────────────────────────
  responsibilities: string[];
  sourceIntegrations: SourceIntegrationDefinition[];
  publishesEvents: string[];
  consumesEvents: string[];
};
```

### 1.2 Bootstrap Utility

**File:** `apps/api/src/platform/modules/bootstrap-modules.ts` (NEW)

```typescript
import type { Type } from "@nestjs/common";
import { Logger } from "@nestjs/common";
import { FLEX_MODULE_CATALOG } from "./flex-module.catalog";

const logger = new Logger("ModuleBootstrap");

export function bootstrapModules(): Type<unknown>[] {
  const modules: Type<unknown>[] = [];

  for (const [key, definition] of Object.entries(FLEX_MODULE_CATALOG)) {
    if (!definition.enabled) {
      logger.warn(`✗ Skipped disabled module: ${definition.displayName} [${key}]`);
      continue;
    }

    logger.log(`✓ Registering module: ${definition.displayName} [${key}]`);
    logger.log(`  → Route:      ${definition.route}`);
    logger.log(`  → Database:   ${definition.databaseName} (${definition.databaseUrlEnvVar})`);
    logger.log(`  → Pool size:  ${definition.databasePoolSize ?? 5} connections/worker`);
    logger.log(`  → Publishes:  ${definition.publishesEvents.join(", ") || "none"}`);
    logger.log(`  → Consumes:   ${definition.consumesEvents.join(", ") || "none"}`);

    modules.push(definition.nestModule);
  }

  logger.log(`Bootstrap complete: ${modules.length} module(s) registered`);
  return modules;
}
```

### 1.3 Updated `app.module.ts`

**File:** `apps/api/src/app.module.ts` (MODIFY)

```typescript
import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { HealthModule } from "./health/health.module";
import { AuthModule } from "./platform/auth/auth.module";
import { TelemetryModule } from "./platform/telemetry/telemetry.module";
import { bootstrapModules } from "./platform/modules/bootstrap-modules";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TelemetryModule,          // Global OTEL interceptors and tracing
    AuthModule,
    HealthModule,
    ...bootstrapModules(),    // All business modules via catalog
  ],
})
export class AppModule {}
```

### 1.4 Benefits

| Benefit | Detail |
|---------|--------|
| Single source of truth | `FLEX_MODULE_CATALOG` is the one place to see all business modules |
| Feature flagging ready | `enabled: boolean` can be driven by env vars or config service |
| Startup visibility | Bootstrap logs the full module graph at startup |
| Enforced contract | `FlexModuleDefinition` ensures every module declares its database, events, and routes |
| Microservice extraction path | Each module's definition contains everything needed to extract it as a standalone service |
| No direct inter-module knowledge in AppModule | `AppModule` only knows about platform infrastructure + the bootstrap function |

---

## Part 2: OpenTelemetry Instrumentation

### Design Philosophy

Observability is **not optional** — it is a first-class platform concern. Every module bootstrapped through the catalog automatically inherits full distributed tracing across all four layers. No module author needs to configure telemetry manually.

### Layer Hierarchy

```
┌─────────────────────────────────────────────────────────────────────────┐
│  LAYER 1: API / Network Layer                                            │
│  Span: HTTP request lifecycle                                            │
│  Attributes: http.method, http.route, http.status_code, module.key      │
│  Security: auth token validation, rate limit headers                     │
│  Audit: every inbound request logged with user identity + timestamp      │
├─────────────────────────────────────────────────────────────────────────┤
│  LAYER 2: Service / Application Layer                                    │
│  Span: command/query handler execution                                   │
│  Attributes: handler.name, module.key, command.type, user.id            │
│  Security: authorization checks recorded as span events                  │
│  Audit: business operation name, actor, input summary                    │
├─────────────────────────────────────────────────────────────────────────┤
│  LAYER 3: Network / Messaging Layer                                      │
│  Span: event publish / consume lifecycle                                 │
│  Attributes: messaging.system, event.name, event.version, queue.name    │
│  Security: event schema validation before publish                        │
│  Audit: event payload hash, producer module, consumer module             │
├─────────────────────────────────────────────────────────────────────────┤
│  LAYER 4: Data / Repository Layer                                        │
│  Span: database query execution                                          │
│  Attributes: db.system, db.name, db.operation, db.table, duration_ms    │
│  Security: query is always scoped to module's own database               │
│  Audit: query type, affected rows, slow query detection (>200ms)         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Drill-Down Trace Example

```
[HTTP POST /api/outcomes/snapshot]                    ← Layer 1: API span
  duration: 45ms  status: 201
  user: user-abc123  module: outcomes
  │
  └─ [OutcomesController.createSnapshot]              ← Layer 1: Controller span
       duration: 43ms
       │
       └─ [OutcomesService.storeSnapshot]             ← Layer 2: Service span
            duration: 41ms
            command: StoreSnapshotCommand
            actor: user-abc123
            │
            ├─ [prisma.flex_outcomes.snapshot.create] ← Layer 4: Data span
            │    duration: 12ms
            │    db: flex_outcomes
            │    operation: INSERT
            │    table: snapshots
            │
            └─ [event-bus.publish]                    ← Layer 3: Messaging span
                 duration: 8ms
                 event: outcomes.snapshot-stored.v1
                 queue: flex.events
```

In Grafana Tempo, you click on the root HTTP span and drill down through the full waterfall to the individual DB query.

### 2.1 Telemetry Package

**New package:** `packages/telemetry/`

```
packages/telemetry/
├── package.json
├── tsconfig.json
└── src/
    ├── index.ts                          # Public exports
    ├── setup/
    │   └── otel-sdk.ts                   # SDK bootstrap (MUST be first import in main.ts)
    ├── interceptors/
    │   └── tracing.interceptor.ts        # NestJS APP_INTERCEPTOR for controller spans
    ├── decorators/
    │   └── traced.decorator.ts           # @Traced() method decorator for service layer
    ├── prisma/
    │   └── prisma-tracing.extension.ts   # Prisma $extends for data layer spans
    ├── messaging/
    │   └── traced-event-publisher.ts     # Wraps event publish in a span
    └── telemetry.module.ts               # NestJS module — registers global interceptor
```

#### `otel-sdk.ts` — SDK Bootstrap

```typescript
import { NodeSDK } from "@opentelemetry/sdk-node";
import { OTLPTraceExporter } from "@opentelemetry/exporter-trace-otlp-http";
import { OTLPMetricExporter } from "@opentelemetry/exporter-metrics-otlp-http";
import { PeriodicExportingMetricReader } from "@opentelemetry/sdk-metrics";
import { Resource } from "@opentelemetry/resources";
import { SEMRESATTRS_SERVICE_NAME, SEMRESATTRS_SERVICE_VERSION } from "@opentelemetry/semantic-conventions";
import { getNodeAutoInstrumentations } from "@opentelemetry/auto-instrumentations-node";

export function initTelemetry(options: { serviceName: string; version?: string }) {
  const sdk = new NodeSDK({
    resource: new Resource({
      [SEMRESATTRS_SERVICE_NAME]: options.serviceName,
      [SEMRESATTRS_SERVICE_VERSION]: options.version ?? "0.1.0",
      "deployment.environment": process.env.NODE_ENV ?? "development",
    }),
    traceExporter: new OTLPTraceExporter({
      url: process.env.OTEL_EXPORTER_OTLP_ENDPOINT ?? "http://localhost:4318/v1/traces",
    }),
    metricReader: new PeriodicExportingMetricReader({
      exporter: new OTLPMetricExporter({
        url: process.env.OTEL_EXPORTER_OTLP_ENDPOINT ?? "http://localhost:4318/v1/metrics",
      }),
      exportIntervalMillis: 15_000,
    }),
    instrumentations: [
      getNodeAutoInstrumentations({
        "@opentelemetry/instrumentation-http": { enabled: true },
        "@opentelemetry/instrumentation-express": { enabled: true },
        "@opentelemetry/instrumentation-pg": { enabled: true },
        "@opentelemetry/instrumentation-amqplib": { enabled: true },
      }),
    ],
  });

  sdk.start();

  process.on("SIGTERM", () => sdk.shutdown());
  process.on("SIGINT", () => sdk.shutdown());
}
```

#### `tracing.interceptor.ts` — API/Controller Layer

```typescript
import {
  Injectable, NestInterceptor, ExecutionContext, CallHandler,
} from "@nestjs/common";
import { trace, SpanStatusCode } from "@opentelemetry/api";
import { Observable } from "rxjs";
import { tap, catchError } from "rxjs/operators";

@Injectable()
export class TracingInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const tracer = trace.getTracer("flex-api");
    const className = context.getClass().name;
    const handlerName = context.getHandler().name;
    const spanName = `${className}.${handlerName}`;

    const span = tracer.startSpan(spanName);
    span.setAttribute("controller.class", className);
    span.setAttribute("controller.handler", handlerName);

    // Capture authenticated user from request context
    const req = context.switchToHttp().getRequest();
    if (req?.user?.id) {
      span.setAttribute("user.id", req.user.id);
    }

    return next.handle().pipe(
      tap(() => {
        span.setStatus({ code: SpanStatusCode.OK });
        span.end();
      }),
      catchError((err) => {
        span.recordException(err);
        span.setStatus({ code: SpanStatusCode.ERROR, message: err.message });
        span.end();
        throw err;
      }),
    );
  }
}
```

#### `traced.decorator.ts` — Service/Application Layer

```typescript
import { trace, SpanStatusCode, context } from "@opentelemetry/api";

export function Traced(spanName?: string): MethodDecorator {
  return (target, propertyKey, descriptor: PropertyDescriptor) => {
    const originalMethod = descriptor.value;
    const name = spanName ?? `${target.constructor.name}.${String(propertyKey)}`;

    descriptor.value = async function (...args: unknown[]) {
      const tracer = trace.getTracer("flex-api");
      const span = tracer.startSpan(name);
      span.setAttribute("service.method", name);

      return context.with(trace.setSpan(context.active(), span), async () => {
        try {
          const result = await originalMethod.apply(this, args);
          span.setStatus({ code: SpanStatusCode.OK });
          return result;
        } catch (err) {
          span.recordException(err as Error);
          span.setStatus({ code: SpanStatusCode.ERROR, message: (err as Error).message });
          throw err;
        } finally {
          span.end();
        }
      });
    };

    return descriptor;
  };
}
```

#### `prisma-tracing.extension.ts` — Data Layer

```typescript
import { trace, SpanStatusCode } from "@opentelemetry/api";

export function withTracingExtension() {
  return {
    query: {
      $allOperations({
        operation,
        model,
        args,
        query,
      }: {
        operation: string;
        model?: string;
        args: unknown;
        query: (args: unknown) => Promise<unknown>;
      }) {
        const tracer = trace.getTracer("flex-api");
        const spanName = model
          ? `prisma.${model}.${operation}`
          : `prisma.${operation}`;

        const span = tracer.startSpan(spanName);
        span.setAttribute("db.system", "postgresql");
        span.setAttribute("db.operation", operation);
        if (model) span.setAttribute("db.table", model);

        const start = Date.now();

        return query(args)
          .then((result) => {
            const duration = Date.now() - start;
            span.setAttribute("db.duration_ms", duration);
            if (duration > 200) {
              span.setAttribute("db.slow_query", true);
              span.addEvent("slow_query_detected", { threshold_ms: 200, actual_ms: duration });
            }
            span.setStatus({ code: SpanStatusCode.OK });
            return result;
          })
          .catch((err) => {
            span.recordException(err);
            span.setStatus({ code: SpanStatusCode.ERROR, message: err.message });
            throw err;
          })
          .finally(() => span.end());
      },
    },
  };
}
```

#### `telemetry.module.ts` — NestJS Module

```typescript
import { Module, Global, APP_INTERCEPTOR } from "@nestjs/common";
import { TracingInterceptor } from "./interceptors/tracing.interceptor";

@Global()
@Module({
  providers: [
    {
      provide: APP_INTERCEPTOR,
      useClass: TracingInterceptor,
    },
  ],
})
export class TelemetryModule {}
```

### 2.2 Updated `main.ts`

```typescript
// MUST be the very first import — before NestJS loads
import { initTelemetry } from "@resource-allocation/telemetry";
initTelemetry({ serviceName: "flex-api", version: "0.1.0" });

import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { AppModule } from "./app.module";
import { configureNetworkLayer } from "./platform/network/configure-network";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  configureNetworkLayer(app);
  await app.listen(Number(process.env.API_PORT ?? 3000));
}

void bootstrap();
```

### 2.3 Security & Auditability Per Layer

#### Layer 1 — API / Network

| Concern | Implementation |
|---------|---------------|
| **Authentication** | `GatewayAuthGuard` validates JWT on every request; identity propagated to span |
| **Authorization** | `@Public()` decorator explicitly opts out; all other routes require valid token |
| **Audit trail** | Every HTTP request span includes `user.id`, `http.route`, `http.method`, timestamp |
| **Rate limiting** | Can be added as a NestJS guard; recorded as span event if triggered |
| **Input validation** | `ValidationPipe` rejects malformed payloads before they reach service layer |

#### Layer 2 — Service / Application

| Concern | Implementation |
|---------|---------------|
| **Authorization** | Service methods can check `@CurrentUser()` against resource ownership |
| **Audit trail** | `@Traced()` decorator records operation name, actor, and outcome |
| **Error classification** | Domain errors vs. infrastructure errors are distinguished in span status |
| **Command immutability** | Commands are plain objects — no mutation after creation |

#### Layer 3 — Network / Messaging

| Concern | Implementation |
|---------|---------------|
| **Schema validation** | Events validated against contracts in `packages/contracts` before publish |
| **Audit trail** | Span records event name, version, producer module, and payload hash |
| **Idempotency** | Event IDs are UUIDs; consumers can deduplicate by event ID |
| **Dead letter handling** | Failed events routed to DLQ; span records failure reason |

#### Layer 4 — Data / Repository

| Concern | Implementation |
|---------|---------------|
| **Database isolation** | Each module connects only to its own database via `databaseUrlEnvVar` |
| **Connection security** | Credentials from environment variables; never hardcoded |
| **Audit trail** | Prisma tracing extension records every query with table, operation, duration |
| **Slow query detection** | Queries >200ms flagged as `db.slow_query=true` in span attributes |
| **No cross-module queries** | Enforced by separate databases — a module cannot query another module's DB |

---

## Part 3: Per-Module Database Connection Pooling

### Problem

A single global `PrismaClient` means:
- All modules share one connection pool
- No isolation between module databases
- No control over pool size per module
- Worker threads compete for connections

### Solution: Module-Scoped Prisma Clients

**File:** `packages/database/src/prisma-pool.factory.ts` (NEW)

```typescript
import { PrismaClient } from "@prisma/client";

export type ModulePoolConfig = {
  moduleName: string;
  databaseUrl: string;
  poolSize?: number;       // Connections per worker thread (default: 5)
  poolTimeout?: number;    // Seconds to wait for a connection (default: 10)
  idleTimeout?: number;    // Seconds before idle connection is closed (default: 60)
};

// One PrismaClient per module per process (worker thread isolation is automatic)
const clientRegistry = new Map<string, PrismaClient>();

export function getModulePrismaClient(config: ModulePoolConfig): PrismaClient {
  const existing = clientRegistry.get(config.moduleName);
  if (existing) return existing;

  const poolSize = config.poolSize ?? 5;
  const url = appendPoolParams(config.databaseUrl, {
    connection_limit: poolSize,
    pool_timeout: config.poolTimeout ?? 10,
  });

  const client = new PrismaClient({
    datasourceUrl: url,
    log: process.env.NODE_ENV === "development" ? ["query", "warn", "error"] : ["warn", "error"],
  });

  clientRegistry.set(config.moduleName, client);
  return client;
}

function appendPoolParams(url: string, params: Record<string, number>): string {
  const separator = url.includes("?") ? "&" : "?";
  const queryString = Object.entries(params)
    .map(([k, v]) => `${k}=${v}`)
    .join("&");
  return `${url}${separator}${queryString}`;
}

export async function disconnectAllPools(): Promise<void> {
  for (const [, client] of clientRegistry) {
    await client.$disconnect();
  }
  clientRegistry.clear();
}
```

### Pool Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  Worker Thread / Process                                         │
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Outcomes     │  │ FinOps       │  │ People Planning      │  │
│  │ Module       │  │ Module       │  │ Module               │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘  │
│         │                 │                      │              │
│  ┌──────▼───────┐  ┌──────▼───────┐  ┌──────────▼───────────┐  │
│  │ PrismaClient │  │ PrismaClient │  │ PrismaClient         │  │
│  │ pool=5 conns │  │ pool=3 conns │  │ pool=3 conns         │  │
│  └──────┬───────┘  └──────┬───────┘  └──────────┬───────────┘  │
└─────────┼─────────────────┼──────────────────────┼─────────────┘
          ▼                 ▼                      ▼
   flex_outcomes      flex_finops         flex_people_planning
```

### Module Definition with Pool Config

Each module's `*.definition.ts` declares its pool size:

```typescript
export const outcomesDefinition: FlexModuleDefinition = {
  key: "outcomes",
  databasePoolSize: 5,   // ← 5 connections per worker thread
  // ...
};
```

### Environment Variables

```env
# Per-module database URLs with optional pool overrides
OUTCOMES_DATABASE_URL=postgresql://flex:flex@localhost:5432/flex_outcomes
FINOPS_DATABASE_URL=postgresql://flex:flex@localhost:5432/flex_finops
PEOPLE_PLANNING_DATABASE_URL=postgresql://flex:flex@localhost:5432/flex_people_planning
BUSINESS_USECASE_DATABASE_URL=postgresql://flex:flex@localhost:5432/flex_business_usecase
```

---

## Part 4: Module Generator CLI

### Usage

```bash
npm run generate:module -- --name=workforce
```

### What It Generates

```
apps/api/src/modules/workforce/
├── workforce.definition.ts                          # FlexModuleDefinition
├── workforce.module.ts                              # NestJS @Module with pool + telemetry
├── application/
│   ├── ports/
│   │   ├── workforce-event-publisher.port.ts
│   │   ├── workforce-repository.port.ts
│   │   └── workforce-source-adapter.port.ts
│   └── services/
│       └── workforce.service.ts                    # @Traced() pre-applied
├── domain/
│   └── events/
│       └── workforce-snapshot-stored.event.ts
├── infrastructure/
│   ├── events/README.md
│   ├── integrations/README.md
│   └── persistence/README.md
└── presentation/
    ├── controllers/
    │   └── workforce.controller.ts
    └── dto/
        └── workforce-summary.response.ts
```

### What It Auto-Registers

1. Adds `workforce` to `FlexModuleKey` union type in `flex-module.definition.ts`
2. Adds `workforceDefinition` to `FLEX_MODULE_CATALOG` in `flex-module.catalog.ts`
3. Adds `workforce` entry to `MODULE_DATABASE_BOUNDARIES` in `module-database-boundaries.ts`
4. Adds `create_database flex_workforce` to `docker/postgres/init-module-databases.sh`
5. Adds `WORKFORCE_DATABASE_URL` to `.env.example`

### Generated Module with Telemetry Pre-Wired

```typescript
// workforce.module.ts
import { Module } from "@nestjs/common";
import { WorkforceController } from "./presentation/controllers/workforce.controller";
import { WorkforceService } from "./application/services/workforce.service";
import { getModulePrismaClient } from "@resource-allocation/database";
import { workforceDefinition } from "./workforce.definition";

@Module({
  controllers: [WorkforceController],
  providers: [
    WorkforceService,
    {
      provide: "WORKFORCE_PRISMA",
      useFactory: () =>
        getModulePrismaClient({
          moduleName: "workforce",
          databaseUrl: process.env[workforceDefinition.databaseUrlEnvVar]!,
          poolSize: workforceDefinition.databasePoolSize ?? 5,
        }),
    },
  ],
})
export class WorkforceModule {}
```

```typescript
// workforce.service.ts
import { Injectable } from "@nestjs/common";
import { Traced } from "@resource-allocation/telemetry";
import { workforceDefinition } from "../../workforce.definition";
import type { WorkforceSummaryResponseDto } from "../../presentation/dto/workforce-summary.response";

@Injectable()
export class WorkforceService {
  @Traced("WorkforceService.getSummary")
  getSummary(): WorkforceSummaryResponseDto {
    return {
      module: workforceDefinition.key,
      displayName: workforceDefinition.displayName,
      route: workforceDefinition.route,
      responsibilities: workforceDefinition.responsibilities,
      sourceIntegrations: workforceDefinition.sourceIntegrations,
      databaseBoundary: workforceDefinition.databaseBoundary,
      databaseName: workforceDefinition.databaseName,
      databaseUrlEnvVar: workforceDefinition.databaseUrlEnvVar,
      publishesEvents: workforceDefinition.publishesEvents,
      consumesEvents: workforceDefinition.consumesEvents,
      currentPhase: "boilerplate",
    };
  }
}
```

---

## Part 5: Grafana Observability Stack

### Docker Compose Additions

Add to `docker-compose.yml`:

```yaml
  tempo:
    image: grafana/tempo:latest
    command: ["-config.file=/etc/tempo.yaml"]
    ports:
      - "4317:4317"   # OTLP gRPC
      - "4318:4318"   # OTLP HTTP
      - "3200:3200"   # Tempo query API
    volumes:
      - ./infra/tempo/tempo.yaml:/etc/tempo.yaml

  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./infra/prometheus/prometheus.yml:/etc/prometheus/prometheus.yml

  loki:
    image: grafana/loki:latest
    ports:
      - "3100:3100"
    command: -config.file=/etc/loki/local-config.yaml

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3001:3000"
    environment:
      GF_AUTH_ANONYMOUS_ENABLED: "true"
      GF_AUTH_ANONYMOUS_ORG_ROLE: Admin
      GF_FEATURE_TOGGLES_ENABLE: traceqlEditor
    volumes:
      - ./infra/grafana/provisioning:/etc/grafana/provisioning
    depends_on:
      - tempo
      - prometheus
      - loki
```

### Grafana Datasources (pre-provisioned)

**File:** `infra/grafana/provisioning/datasources/datasources.yaml`

```yaml
apiVersion: 1
datasources:
  - name: Tempo
    type: tempo
    url: http://tempo:3200
    isDefault: true
    jsonData:
      tracesToLogsV2:
        datasourceUid: loki
        spanStartTimeShift: "-1h"
        spanEndTimeShift: "1h"
      serviceMap:
        datasourceUid: prometheus
      nodeGraph:
        enabled: true

  - name: Prometheus
    type: prometheus
    url: http://prometheus:9090

  - name: Loki
    type: loki
    url: http://loki:3100
```

### Accessing Grafana

After `docker compose up`:
- **Grafana:** http://localhost:3001
- **Prometheus:** http://localhost:9090
- **Tempo (direct):** http://localhost:3200

In Grafana → Explore → Tempo → Search by service name `flex-api` → click any trace → drill down through all 4 layers.

---

## Part 6: Event Pub/Sub

### Design

The existing `EventBusPort` only supports `publish`. We extend it with `subscribe` / `unsubscribe` and ship an **in-memory implementation** that works out of the box with no broker dependency. When a real broker (RabbitMQ, Redis Streams) is needed, only the implementation is swapped — all module code stays the same.

### 6.1 Updated Contracts

**File:** `apps/api/src/platform/messaging/event-subscription.ts` (NEW)

```typescript
export type EventHandler<TPayload = unknown> = (
  event: IntegrationEvent<TPayload>,
) => Promise<void> | void;

export type EventSubscription = {
  readonly id: string;
  readonly eventName: string;
};
```

**File:** `apps/api/src/platform/messaging/event-bus.port.ts` (MODIFY)

```typescript
import type { IntegrationEvent } from "./integration-event";
import type { EventHandler, EventSubscription } from "./event-subscription";

export interface EventBusPort {
  publish<TPayload>(event: IntegrationEvent<TPayload>): Promise<void>;
  subscribe<TPayload>(eventName: string, handler: EventHandler<TPayload>): EventSubscription;
  unsubscribe(subscription: EventSubscription): void;
}
```

### 6.2 In-Memory Implementation

**File:** `apps/api/src/platform/messaging/in-memory-event-bus.ts` (NEW)

```typescript
import { Injectable, Logger } from "@nestjs/common";
import { randomUUID } from "crypto";
import type { EventBusPort } from "./event-bus.port";
import type { EventHandler, EventSubscription } from "./event-subscription";
import type { IntegrationEvent } from "./integration-event";

@Injectable()
export class InMemoryEventBus implements EventBusPort {
  private readonly logger = new Logger(InMemoryEventBus.name);
  private readonly handlers = new Map<string, Map<string, EventHandler>>();

  async publish<TPayload>(event: IntegrationEvent<TPayload>): Promise<void> {
    const targets = this.handlers.get(event.name) ?? new Map();
    this.logger.debug(`publish → ${event.name} (${targets.size} handler(s))`);
    for (const handler of targets.values()) {
      await handler(event as IntegrationEvent<unknown>);
    }
  }

  subscribe<TPayload>(eventName: string, handler: EventHandler<TPayload>): EventSubscription {
    if (!this.handlers.has(eventName)) this.handlers.set(eventName, new Map());
    const id = randomUUID();
    this.handlers.get(eventName)!.set(id, handler as EventHandler);
    this.logger.debug(`subscribe → ${eventName} [${id}]`);
    return { id, eventName };
  }

  unsubscribe(subscription: EventSubscription): void {
    this.handlers.get(subscription.eventName)?.delete(subscription.id);
  }
}
```

### 6.3 `@OnEvent()` Decorator

**File:** `apps/api/src/platform/messaging/on-event.decorator.ts` (NEW)

Marks a service method as an event handler. The `MessagingModule` discovers all `@OnEvent`-decorated methods at startup and registers them with the bus automatically.

```typescript
import { SetMetadata } from "@nestjs/common";

export const ON_EVENT_KEY = "flex:on_event";

export const OnEvent = (eventName: string): MethodDecorator =>
  SetMetadata(ON_EVENT_KEY, eventName);
```

### 6.4 `MessagingModule`

**File:** `apps/api/src/platform/messaging/messaging.module.ts` (NEW)

```typescript
import { Global, Module } from "@nestjs/common";
import { InMemoryEventBus } from "./in-memory-event-bus";

export const EVENT_BUS = "EVENT_BUS";

@Global()
@Module({
  providers: [{ provide: EVENT_BUS, useClass: InMemoryEventBus }],
  exports: [EVENT_BUS],
})
export class MessagingModule {}
```

Modules inject the bus via `@Inject(EVENT_BUS) private readonly bus: EventBusPort`.

### 6.5 Bootstrap Integration

`bootstrapModules()` already logs `publishesEvents` / `consumesEvents` per module. No additional wiring is needed — `@OnEvent()` handlers self-register when the NestJS DI container resolves the service.

### 6.6 Updated `app.module.ts`

```typescript
import { MessagingModule } from "./platform/messaging/messaging.module";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TelemetryModule,
    MessagingModule,   // ← global event bus
    AuthModule,
    HealthModule,
    ...bootstrapModules(),
  ],
})
export class AppModule {}
```

### Broker Swap Path

To replace the in-memory bus with RabbitMQ:
1. Create `RabbitMqEventBus implements EventBusPort` in `infrastructure/events/`
2. Change `MessagingModule` provider to `useClass: RabbitMqEventBus`
3. All module code (`@OnEvent`, `publish()`) is unchanged

---

## Part 7: Background Task Scheduler

### Design

Some work must happen outside the HTTP request cycle: refreshing cached resource data, sending notifications, retrying failed integrations, or running periodic aggregations. A lightweight `TaskScheduler` platform service handles this without pulling in a full job-queue library.

### 7.1 Task Definition

**File:** `apps/api/src/platform/tasks/task.ts` (NEW)

```typescript
export type TaskFn = () => Promise<void>;

export type TaskDefinition = {
  name: string;
  intervalMs: number;       // How often to run (0 = run once on startup)
  runOnStartup?: boolean;   // Execute immediately before first interval tick
  task: TaskFn;
};
```

### 7.2 Task Scheduler Service

**File:** `apps/api/src/platform/tasks/task-scheduler.service.ts` (NEW)

```typescript
import { Injectable, Logger, OnApplicationBootstrap, OnApplicationShutdown } from "@nestjs/common";
import type { TaskDefinition } from "./task";

@Injectable()
export class TaskSchedulerService implements OnApplicationBootstrap, OnApplicationShutdown {
  private readonly logger = new Logger(TaskSchedulerService.name);
  private readonly timers: NodeJS.Timeout[] = [];
  private readonly tasks: TaskDefinition[] = [];

  register(task: TaskDefinition): void {
    this.tasks.push(task);
  }

  async onApplicationBootstrap(): Promise<void> {
    for (const task of this.tasks) {
      if (task.runOnStartup) await this.run(task);
      if (task.intervalMs > 0) {
        const timer = setInterval(() => void this.run(task), task.intervalMs);
        this.timers.push(timer);
      }
    }
    this.logger.log(`Scheduler started: ${this.tasks.length} task(s) registered`);
  }

  onApplicationShutdown(): void {
    for (const timer of this.timers) clearInterval(timer);
    this.logger.log("Scheduler stopped");
  }

  private async run(task: TaskDefinition): Promise<void> {
    try {
      this.logger.debug(`Running task: ${task.name}`);
      await task.task();
    } catch (err) {
      this.logger.error(`Task failed: ${task.name}`, err);
    }
  }
}
```

### 7.3 `TasksModule`

**File:** `apps/api/src/platform/tasks/tasks.module.ts` (NEW)

```typescript
import { Global, Module } from "@nestjs/common";
import { TaskSchedulerService } from "./task-scheduler.service";

@Global()
@Module({
  providers: [TaskSchedulerService],
  exports: [TaskSchedulerService],
})
export class TasksModule {}
```

### 7.4 Registering Tasks in a Module

Business modules inject `TaskSchedulerService` and register their tasks in `onModuleInit`:

```typescript
// outcomes.module.ts — example task registration
import { Module, OnModuleInit } from "@nestjs/common";
import { TaskSchedulerService } from "../../platform/tasks/task-scheduler.service";
import { OutcomesService } from "./application/services/outcomes.service";

@Module({ ... })
export class OutcomesModule implements OnModuleInit {
  constructor(
    private readonly scheduler: TaskSchedulerService,
    private readonly outcomes: OutcomesService,
  ) {}

  onModuleInit(): void {
    this.scheduler.register({
      name: "outcomes.refresh-snapshot-cache",
      intervalMs: 5 * 60 * 1000,   // every 5 minutes
      runOnStartup: true,
      task: () => this.outcomes.refreshSnapshotCache(),
    });
  }
}
```

### 7.5 Updated `app.module.ts`

```typescript
import { TasksModule } from "./platform/tasks/tasks.module";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TelemetryModule,
    MessagingModule,
    TasksModule,       // ← background task scheduler
    AuthModule,
    HealthModule,
    ...bootstrapModules(),
  ],
})
export class AppModule {}
```

### Task Lifecycle

```
App starts
  │
  ├─ onModuleInit() → scheduler.register(task)   ← each module registers its tasks
  │
  └─ onApplicationBootstrap()
       ├─ runOnStartup tasks execute immediately
       └─ setInterval() timers start
            │
            └─ task() runs every intervalMs
                 ├─ success → logger.debug
                 └─ error   → logger.error (does NOT crash the process)

App stops (SIGTERM)
  └─ onApplicationShutdown() → clearInterval() all timers
```

---

## Part 8: Testing

### Unit Tests (Vitest)

| File | What it covers |
|------|---------------|
| `platform/messaging/__tests__/in-memory-event-bus.spec.ts` | publish delivers to subscriber; multiple subscribers; unsubscribe stops delivery; unknown event is no-op |
| `platform/messaging/__tests__/messaging.module.spec.ts` | `EVENT_BUS` token resolves to `InMemoryEventBus`; global export works |
| `platform/modules/__tests__/bootstrap-modules.spec.ts` | enabled modules are returned; disabled modules are skipped; logs are emitted |
| `platform/tasks/__tests__/task-scheduler.spec.ts` | tasks run on startup; interval fires; errors are caught and logged; shutdown clears timers |

#### Example — `in-memory-event-bus.spec.ts`

```typescript
import { InMemoryEventBus } from "../in-memory-event-bus";

describe("InMemoryEventBus", () => {
  let bus: InMemoryEventBus;

  beforeEach(() => { bus = new InMemoryEventBus(); });

  it("delivers published event to subscriber", async () => {
    const received: unknown[] = [];
    bus.subscribe("test.event", (e) => { received.push(e); });
    await bus.publish({ id: "1", name: "test.event", version: 1, occurredAt: new Date().toISOString(), payload: { x: 1 } });
    expect(received).toHaveLength(1);
  });

  it("does not deliver after unsubscribe", async () => {
    const received: unknown[] = [];
    const sub = bus.subscribe("test.event", (e) => { received.push(e); });
    bus.unsubscribe(sub);
    await bus.publish({ id: "2", name: "test.event", version: 1, occurredAt: new Date().toISOString(), payload: {} });
    expect(received).toHaveLength(0);
  });

  it("is a no-op for events with no subscribers", async () => {
    await expect(
      bus.publish({ id: "3", name: "unknown.event", version: 1, occurredAt: new Date().toISOString(), payload: {} })
    ).resolves.not.toThrow();
  });
});
```

#### Example — `task-scheduler.spec.ts`

```typescript
import { vi } from "vitest";
import { TaskSchedulerService } from "../task-scheduler.service";

describe("TaskSchedulerService", () => {
  let scheduler: TaskSchedulerService;

  beforeEach(() => { scheduler = new TaskSchedulerService(); });
  afterEach(() => { scheduler.onApplicationShutdown(); });

  it("runs task on startup when runOnStartup is true", async () => {
    const fn = vi.fn().mockResolvedValue(undefined);
    scheduler.register({ name: "test", intervalMs: 0, runOnStartup: true, task: fn });
    await scheduler.onApplicationBootstrap();
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it("catches task errors without throwing", async () => {
    const fn = vi.fn().mockRejectedValue(new Error("boom"));
    scheduler.register({ name: "failing", intervalMs: 0, runOnStartup: true, task: fn });
    await expect(scheduler.onApplicationBootstrap()).resolves.not.toThrow();
  });
});
```

### Playwright E2E Tests

**File:** `apps/api/e2e/event-pub-sub.spec.ts`

Tests the full pub/sub round-trip through the running API:

```typescript
import { test, expect } from "@playwright/test";

test("event published via API is received by subscriber", async ({ request }) => {
  // Trigger an action that publishes an event (e.g., outcomes snapshot)
  const res = await request.post("/api/outcomes/snapshot", {
    headers: { Authorization: "Bearer test-token" },
    data: { sourceSystem: "erp", capturedAt: new Date().toISOString(), recordCount: 10 },
  });
  expect(res.status()).toBe(201);

  // Verify the event side-effect (e.g., a downstream resource was updated)
  const status = await request.get("/api/health");
  expect(status.status()).toBe(200);
});
```

> **Note:** Full event assertion requires either a test-only `/api/test/events` endpoint that exposes received events, or checking a downstream side-effect (DB record, notification log). The pattern is the same — trigger → assert side-effect.

---

## Summary of All Changes

| File | Action | Purpose |
|------|--------|---------|
| `apps/api/src/platform/modules/flex-module.definition.ts` | Modify | Add `nestModule`, `enabled`, `databasePoolSize` |
| `apps/api/src/platform/modules/bootstrap-modules.ts` | Create | Runtime bootstrap utility |
| `apps/api/src/platform/modules/flex-module.catalog.ts` | Modify | Add `nestModule` + `enabled` to each entry |
| `apps/api/src/platform/telemetry/telemetry.module.ts` | Create | NestJS module registering global interceptor |
| `apps/api/src/app.module.ts` | Modify | Use `bootstrapModules()` + `TelemetryModule` + `MessagingModule` + `TasksModule` |
| `apps/api/src/main.ts` | Modify | Init OTEL SDK before NestJS bootstrap |
| `packages/telemetry/` | Create | Shared OTEL package (SDK, interceptors, decorators, Prisma extension) |
| `packages/database/src/prisma-pool.factory.ts` | Create | Per-module pooled Prisma client factory |
| `packages/database/src/index.ts` | Modify | Export `getModulePrismaClient` |
| `docker-compose.yml` | Modify | Add Tempo, Prometheus, Loki, Grafana |
| `infra/tempo/tempo.yaml` | Create | Tempo configuration |
| `infra/prometheus/prometheus.yml` | Create | Prometheus scrape config |
| `infra/grafana/provisioning/` | Create | Pre-provisioned datasources |
| `scripts/generate-module.ts` | Create | Module generator CLI |
| `README.md` | Create | Project documentation |
| `docs/module-development.md` | Create | Developer guide for new modules |
| `apps/api/src/platform/messaging/event-subscription.ts` | Create | `EventHandler` + `EventSubscription` types |
| `apps/api/src/platform/messaging/event-bus.port.ts` | Modify | Add `subscribe` / `unsubscribe` to port |
| `apps/api/src/platform/messaging/in-memory-event-bus.ts` | Create | In-process event bus implementation |
| `apps/api/src/platform/messaging/on-event.decorator.ts` | Create | `@OnEvent()` method decorator |
| `apps/api/src/platform/messaging/messaging.module.ts` | Create | Global `EVENT_BUS` provider |
| `apps/api/src/platform/tasks/task.ts` | Create | `TaskDefinition` + `TaskFn` types |
| `apps/api/src/platform/tasks/task-scheduler.service.ts` | Create | Background task runner |
| `apps/api/src/platform/tasks/tasks.module.ts` | Create | Global `TaskSchedulerService` provider |
| `apps/api/src/platform/messaging/__tests__/in-memory-event-bus.spec.ts` | Create | Unit tests — event bus |
| `apps/api/src/platform/messaging/__tests__/messaging.module.spec.ts` | Create | Unit tests — DI wiring |
| `apps/api/src/platform/modules/__tests__/bootstrap-modules.spec.ts` | Create | Unit tests — bootstrap |
| `apps/api/src/platform/tasks/__tests__/task-scheduler.spec.ts` | Create | Unit tests — scheduler |
| `apps/api/e2e/event-pub-sub.spec.ts` | Create | Playwright E2E — pub/sub round-trip |

---

## Microservice Extraction Path

This architecture is designed so that any module can be extracted into a standalone microservice with minimal changes:

1. The `FlexModuleDefinition` already declares everything a standalone service needs:
   - Its own database (`databaseName`, `databaseUrlEnvVar`)
   - Its events (`publishesEvents`, `consumesEvents`)
   - Its API route (`route`)
   - Its source integrations (`sourceIntegrations`)

2. To extract `outcomes` as a microservice:
   - Create `apps/outcomes-service/` with its own `main.ts`
   - Import only `OutcomesModule` + platform infrastructure
   - Point to the same `flex_outcomes` database
   - Connect to the same RabbitMQ exchange
   - Remove `outcomes` from `FLEX_MODULE_CATALOG` in the monolith

3. The telemetry package works identically in both the monolith and the extracted service — traces will automatically show cross-service calls via W3C TraceContext propagation.

---

*Last updated: July 2026*
