import type { FlexModuleDefinition } from "../../platform/modules/flex-module.definition";
import { AuthModule } from "./auth.module";

export const authDefinition: FlexModuleDefinition = {
  key: "auth",
  displayName: "Auth",
  route: "/api/auth",

  nestModule: AuthModule,
  enabled: true,
  databasePoolSize: 5,

  databaseBoundary: "Auth DB",
  databaseName: "flex_auth",
  databaseUrlEnvVar: "AUTH_DATABASE_URL",
  responsibilities: [],
  sourceIntegrations: [],
  publishesEvents: [],
  consumesEvents: [],
};
