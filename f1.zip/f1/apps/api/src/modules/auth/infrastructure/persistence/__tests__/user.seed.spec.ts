import { ROLES } from "../../../domain/rbac";
import { InMemoryUserRepository } from "../in-memory-user.repository";
import { DEFAULT_SEED_USERS, seedLocalUsers } from "../user.seed";

describe("seedLocalUsers", () => {
  it("creates the default users on an empty repository", async () => {
    const repo = new InMemoryUserRepository();

    const created = await seedLocalUsers(repo);

    expect(created).toHaveLength(DEFAULT_SEED_USERS.length);
    expect((await repo.list({})).total).toBe(DEFAULT_SEED_USERS.length);
    expect(await repo.findByEmail("admin@flex.local")).toMatchObject({ role: ROLES.ADMIN });
  });

  it("is idempotent and skips existing users", async () => {
    const repo = new InMemoryUserRepository();
    await seedLocalUsers(repo);

    const secondRun = await seedLocalUsers(repo);

    expect(secondRun).toHaveLength(0);
    expect((await repo.list({})).total).toBe(DEFAULT_SEED_USERS.length);
  });

  it("accepts a custom user set", async () => {
    const repo = new InMemoryUserRepository();

    const created = await seedLocalUsers(repo, [
      { email: "solo@flex.local", name: "Solo", role: ROLES.USER },
    ]);

    expect(created).toHaveLength(1);
  });
});
