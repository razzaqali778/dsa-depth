import { ROLES, type Role } from "../../domain/rbac";
import type { UserRepositoryPort, UserRecord } from "../../application/ports/user-repository.port";

export type SeedUser = {
  email: string;
  name: string;
  role: Role;
};

/** Default local users created for development and first-run environments. */
export const DEFAULT_SEED_USERS: readonly SeedUser[] = [
  { email: "admin@flex.local", name: "FLEX Administrator", role: ROLES.ADMIN },
  { email: "lead@flex.local", name: "Platform Lead", role: ROLES.PLATFORM_LEAD },
  { email: "member@flex.local", name: "Team Member", role: ROLES.USER },
];

/**
 * Idempotently seeds local users. Existing emails are skipped so the seed is
 * safe to run repeatedly. Returns the users that were created.
 */
export async function seedLocalUsers(
  repo: UserRepositoryPort,
  users: readonly SeedUser[] = DEFAULT_SEED_USERS,
): Promise<UserRecord[]> {
  const created: UserRecord[] = [];

  for (const user of users) {
    const existing = await repo.findByEmail(user.email);
    if (existing) {
      continue;
    }
    created.push(await repo.createLocal(user));
  }

  return created;
}
