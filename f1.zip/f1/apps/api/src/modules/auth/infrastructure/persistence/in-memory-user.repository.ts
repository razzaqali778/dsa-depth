import { randomUUID } from "node:crypto";
import { Injectable, Optional } from "@nestjs/common";
import { Traced } from "../../../../platform/telemetry/traced.decorator";
import type {
  CreateLocalUserData,
  ListUsersFilter,
  ListUsersResult,
  UpdateUserData,
  UpsertIdentityData,
  UserRecord,
  UserRepositoryPort,
} from "../../application/ports/user-repository.port";

/**
 * In-memory {@link UserRepositoryPort} adapter. Ships as the working default so
 * the feature runs and is fully testable without a database. Swap for a Prisma
 * adapter (see schema.prisma) by rebinding USER_REPOSITORY once a DB is provided.
 *
 * Note: on SSO upsert of an existing user, the stored FLEX role is preserved so
 * that admin role changes are not overwritten on the user's next login.
 */
@Injectable()
export class InMemoryUserRepository implements UserRepositoryPort {
  private readonly users = new Map<string, UserRecord>();

  constructor(
    @Optional() private readonly newId: () => string = randomUUID,
    @Optional() private readonly clock: () => Date = () => new Date(),
  ) {}

  @Traced()
  async findById(id: string): Promise<UserRecord | null> {
    return this.users.get(id) ?? null;
  }

  @Traced()
  async findByEmail(email: string): Promise<UserRecord | null> {
    const target = email.toLowerCase();
    return this.find((user) => user.email.toLowerCase() === target);
  }

  @Traced()
  async findByAzureId(azureId: string): Promise<UserRecord | null> {
    return this.find((user) => user.azureId === azureId);
  }

  @Traced()
  async list(filter: ListUsersFilter): Promise<ListUsersResult> {
    const matched = [...this.users.values()]
      .filter((user) => matchesFilter(user, filter))
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());

    const skip = filter.skip ?? 0;
    const take = filter.take ?? matched.length;

    return {
      items: matched.slice(skip, skip + take),
      total: matched.length,
    };
  }

  @Traced()
  async upsertFromIdentity(data: UpsertIdentityData): Promise<UserRecord> {
    const existing = await this.locateForUpsert(data);

    if (existing) {
      existing.email = data.email;
      existing.name = data.name;
      existing.tenantId = data.tenantId;
      existing.azureId = data.azureId ?? existing.azureId;
      existing.updatedAt = this.clock();
      return existing;
    }

    return this.insert({
      email: data.email,
      name: data.name,
      role: data.role,
      authProvider: data.provider,
      azureId: data.azureId,
      tenantId: data.tenantId,
    });
  }

  @Traced()
  async createLocal(data: CreateLocalUserData): Promise<UserRecord> {
    return this.insert({
      email: data.email.toLowerCase(),
      name: data.name,
      role: data.role,
      authProvider: "local",
      azureId: null,
      tenantId: null,
    });
  }

  @Traced()
  async update(id: string, data: UpdateUserData): Promise<UserRecord | null> {
    const user = this.users.get(id);
    if (!user) {
      return null;
    }

    if (data.name !== undefined) user.name = data.name;
    if (data.role !== undefined) user.role = data.role;
    if (data.isActive !== undefined) user.isActive = data.isActive;
    user.updatedAt = this.clock();

    return user;
  }

  @Traced()
  async setActive(id: string, isActive: boolean): Promise<UserRecord | null> {
    return this.update(id, { isActive });
  }

  @Traced()
  async recordLogin(id: string, at: Date): Promise<void> {
    const user = this.users.get(id);
    if (user) {
      user.lastLoginAt = at;
      user.updatedAt = this.clock();
    }
  }

  private async locateForUpsert(data: UpsertIdentityData): Promise<UserRecord | null> {
    if (data.provider === "azure" && data.azureId) {
      const byAzure = await this.findByAzureId(data.azureId);
      if (byAzure) {
        return byAzure;
      }
    }
    return this.findByEmail(data.email);
  }

  private insert(seed: Omit<UserRecord, "id" | "isActive" | "lastLoginAt" | "createdAt" | "updatedAt">): UserRecord {
    const now = this.clock();
    const record: UserRecord = {
      id: this.newId(),
      isActive: true,
      lastLoginAt: null,
      createdAt: now,
      updatedAt: now,
      ...seed,
    };
    this.users.set(record.id, record);
    return record;
  }

  private find(predicate: (user: UserRecord) => boolean): UserRecord | null {
    for (const user of this.users.values()) {
      if (predicate(user)) {
        return user;
      }
    }
    return null;
  }
}

function matchesFilter(user: UserRecord, filter: ListUsersFilter): boolean {
  if (filter.role && user.role !== filter.role) {
    return false;
  }

  if (filter.isActive !== undefined && user.isActive !== filter.isActive) {
    return false;
  }

  if (filter.search) {
    const needle = filter.search.toLowerCase();
    const haystack = `${user.name} ${user.email}`.toLowerCase();
    if (!haystack.includes(needle)) {
      return false;
    }
  }

  return true;
}
