import { ROLES } from "../../../domain/rbac";
import { Test } from "@nestjs/testing";
import type { UpsertIdentityData } from "../../../application/ports/user-repository.port";
import { InMemoryUserRepository } from "../in-memory-user.repository";

function makeRepo() {
  let counter = 0;
  const clock = new Date("2026-01-01T00:00:00.000Z");
  return new InMemoryUserRepository(
    () => `id-${++counter}`,
    () => clock,
  );
}

const azureIdentity: UpsertIdentityData = {
  email: "user@flex",
  name: "User One",
  role: ROLES.USER,
  provider: "azure",
  azureId: "oid-1",
  tenantId: "tenant-1",
};

describe("InMemoryUserRepository", () => {
  it("can be instantiated by Nest without factory overrides", async () => {
    const moduleRef = await Test.createTestingModule({
      providers: [InMemoryUserRepository],
    }).compile();

    expect(moduleRef.get(InMemoryUserRepository)).toBeInstanceOf(InMemoryUserRepository);
  });

  it("creates a user on first upsert", async () => {
    const repo = makeRepo();
    const record = await repo.upsertFromIdentity(azureIdentity);

    expect(record).toMatchObject({ id: "id-1", email: "user@flex", role: ROLES.USER });
    expect(await repo.findById("id-1")).not.toBeNull();
  });

  it("updates profile fields but preserves role on re-upsert by azureId", async () => {
    const repo = makeRepo();
    const created = await repo.upsertFromIdentity(azureIdentity);
    await repo.update(created.id, { role: ROLES.ADMIN });

    const updated = await repo.upsertFromIdentity({
      ...azureIdentity,
      name: "Renamed",
      role: ROLES.USER,
    });

    expect(updated.id).toBe(created.id);
    expect(updated.name).toBe("Renamed");
    expect(updated.role).toBe(ROLES.ADMIN);
  });

  it("matches an existing user by email when azure id is absent", async () => {
    const repo = makeRepo();
    const created = await repo.upsertFromIdentity(azureIdentity);

    const again = await repo.upsertFromIdentity({
      email: "USER@flex",
      name: "User One",
      role: ROLES.USER,
      provider: "local",
      azureId: null,
      tenantId: null,
    });

    expect(again.id).toBe(created.id);
  });

  it("finds users by email case-insensitively and by azure id", async () => {
    const repo = makeRepo();
    await repo.upsertFromIdentity(azureIdentity);

    expect(await repo.findByEmail("USER@FLEX")).not.toBeNull();
    expect(await repo.findByAzureId("oid-1")).not.toBeNull();
    expect(await repo.findByAzureId("missing")).toBeNull();
  });

  it("creates local users without an azure id", async () => {
    const repo = makeRepo();
    const record = await repo.createLocal({ email: "Local@Flex", name: "Local", role: ROLES.ADMIN });

    expect(record.authProvider).toBe("local");
    expect(record.azureId).toBeNull();
    expect(record.email).toBe("local@flex");
  });

  it("filters and paginates the list", async () => {
    const repo = makeRepo();
    await repo.upsertFromIdentity(azureIdentity);
    await repo.createLocal({ email: "lead@flex", name: "Lead Person", role: ROLES.PLATFORM_LEAD });
    await repo.createLocal({ email: "admin@flex", name: "Admin Person", role: ROLES.ADMIN });

    const byRole = await repo.list({ role: ROLES.ADMIN });
    expect(byRole.total).toBe(1);

    const bySearch = await repo.list({ search: "person" });
    expect(bySearch.total).toBe(2);

    const paged = await repo.list({ skip: 1, take: 1 });
    expect(paged.items).toHaveLength(1);
    expect(paged.total).toBe(3);
  });

  it("filters by active state", async () => {
    const repo = makeRepo();
    const created = await repo.upsertFromIdentity(azureIdentity);
    await repo.setActive(created.id, false);

    const inactive = await repo.list({ isActive: false });
    expect(inactive.total).toBe(1);
    const active = await repo.list({ isActive: true });
    expect(active.total).toBe(0);
  });

  it("updates fields and returns null for unknown ids", async () => {
    const repo = makeRepo();
    const created = await repo.upsertFromIdentity(azureIdentity);

    const updated = await repo.update(created.id, { name: "New Name", isActive: false });
    expect(updated).toMatchObject({ name: "New Name", isActive: false });

    expect(await repo.update("missing", { name: "x" })).toBeNull();
    expect(await repo.setActive("missing", true)).toBeNull();
  });

  it("records login timestamps and ignores unknown ids", async () => {
    const repo = makeRepo();
    const created = await repo.upsertFromIdentity(azureIdentity);
    const at = new Date("2026-05-05T05:05:05.000Z");

    await repo.recordLogin(created.id, at);
    expect((await repo.findById(created.id))?.lastLoginAt).toEqual(at);

    await expect(repo.recordLogin("missing", at)).resolves.toBeUndefined();
  });
});
