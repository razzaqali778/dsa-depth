import {
  ROLES,
  PERMISSIONS,
  isRole,
  getPermissionsForRole,
  hasPermission,
  mapRawRoleToFlexRole,
  resolvePermissions,
  pickHighestRole,
} from "../rbac";

describe("rbac domain", () => {
  describe("isRole", () => {
    it("recognises known roles", () => {
      expect(isRole("Admin")).toBe(true);
      expect(isRole("Platform Lead")).toBe(true);
      expect(isRole("User")).toBe(true);
    });

    it("rejects unknown roles", () => {
      expect(isRole("Wizard")).toBe(false);
    });
  });

  describe("getPermissionsForRole", () => {
    it("grants every permission to Admin", () => {
      const perms = getPermissionsForRole(ROLES.ADMIN);
      expect(perms).toEqual(expect.arrayContaining(Object.values(PERMISSIONS)));
      expect(perms).toHaveLength(Object.keys(PERMISSIONS).length);
    });

    it("grants management permissions to Platform Lead but not audit", () => {
      const perms = getPermissionsForRole(ROLES.PLATFORM_LEAD);
      expect(perms).toContain(PERMISSIONS.MANAGE_USERS);
      expect(perms).not.toContain(PERMISSIONS.VIEW_AUDIT);
    });

    it("restricts User to the dashboard", () => {
      expect(getPermissionsForRole(ROLES.USER)).toEqual([PERMISSIONS.VIEW_DASHBOARD]);
    });
  });

  describe("hasPermission", () => {
    it("allows Admin to manage users", () => {
      expect(hasPermission(ROLES.ADMIN, PERMISSIONS.MANAGE_USERS)).toBe(true);
    });

    it("denies User management permissions", () => {
      expect(hasPermission(ROLES.USER, PERMISSIONS.MANAGE_USERS)).toBe(false);
    });
  });

  describe("mapRawRoleToFlexRole", () => {
    it("passes through canonical FLEX roles", () => {
      expect(mapRawRoleToFlexRole("Platform Lead")).toBe(ROLES.PLATFORM_LEAD);
    });

    it("maps default Entra admin roles", () => {
      expect(mapRawRoleToFlexRole("FLEX.Admin")).toBe(ROLES.ADMIN);
    });

    it("maps default Entra PLD role to Platform Lead (case-insensitive)", () => {
      expect(mapRawRoleToFlexRole("pld")).toBe(ROLES.PLATFORM_LEAD);
    });

    it("honours custom mapping options", () => {
      expect(
        mapRawRoleToFlexRole("group-admins", { adminRoles: ["group-admins"] }),
      ).toBe(ROLES.ADMIN);
    });

    it("falls back to User for unknown roles", () => {
      expect(mapRawRoleToFlexRole("random")).toBe(ROLES.USER);
    });
  });

  describe("pickHighestRole", () => {
    it("defaults to User for an empty list", () => {
      expect(pickHighestRole([])).toBe(ROLES.USER);
    });

    it("selects the most privileged role", () => {
      expect(pickHighestRole([ROLES.USER, ROLES.ADMIN, ROLES.PLATFORM_LEAD])).toBe(ROLES.ADMIN);
    });
  });

  describe("resolvePermissions", () => {
    it("unions permissions from the highest role", () => {
      const perms = resolvePermissions(["PLD", "random"]);
      expect(perms).toContain(PERMISSIONS.MANAGE_USERS);
      expect(perms).not.toContain(PERMISSIONS.VIEW_AUDIT);
    });

    it("returns User permissions for an empty list", () => {
      expect(resolvePermissions([])).toEqual([PERMISSIONS.VIEW_DASHBOARD]);
    });

    it("grants all permissions when an admin role is present", () => {
      expect(resolvePermissions(["FLEX.Admin"])).toHaveLength(Object.keys(PERMISSIONS).length);
    });
  });
});
