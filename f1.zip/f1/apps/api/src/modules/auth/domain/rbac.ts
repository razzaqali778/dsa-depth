/**
 * RBAC domain — pure functions and constants. No NestJS imports.
 *
 * Roles and permissions are the FLEX authorization vocabulary. Entra (Azure AD)
 * app roles are mapped onto FLEX roles at the ingress boundary.
 */

export const ROLES = {
  ADMIN: "Admin",
  PLATFORM_LEAD: "Platform Lead",
  USER: "User",
} as const;

export type Role = (typeof ROLES)[keyof typeof ROLES];

export const PERMISSIONS = {
  VIEW_DASHBOARD: "view_dashboard",
  VIEW_USERS: "view_users",
  MANAGE_USERS: "manage_users",
  ASSIGN_ROLES: "assign_roles",
  VIEW_AUDIT: "view_audit",
} as const;

export type Permission = (typeof PERMISSIONS)[keyof typeof PERMISSIONS];

const ALL_PERMISSIONS: readonly Permission[] = Object.values(PERMISSIONS);

const ROLE_PERMISSIONS: Record<Role, readonly Permission[]> = {
  [ROLES.ADMIN]: ALL_PERMISSIONS,
  [ROLES.PLATFORM_LEAD]: [
    PERMISSIONS.VIEW_DASHBOARD,
    PERMISSIONS.VIEW_USERS,
    PERMISSIONS.MANAGE_USERS,
    PERMISSIONS.ASSIGN_ROLES,
  ],
  [ROLES.USER]: [PERMISSIONS.VIEW_DASHBOARD],
};

const VALID_ROLES: readonly string[] = Object.values(ROLES);

/** Returns true when the given string is a known FLEX role. */
export function isRole(value: string): value is Role {
  return VALID_ROLES.includes(value);
}

/** Permissions granted to a single FLEX role. */
export function getPermissionsForRole(role: Role): readonly Permission[] {
  return ROLE_PERMISSIONS[role] ?? [];
}

/** True when the role grants the permission. */
export function hasPermission(role: Role, permission: Permission): boolean {
  return getPermissionsForRole(role).includes(permission);
}

/**
 * Maps a raw role string (from an Entra token, gateway header, or stored value)
 * to a FLEX role. Custom mappings for Entra app roles are supplied via options.
 * Unknown values fall back to {@link ROLES.USER}.
 */
export type RoleMappingOptions = {
  adminRoles?: readonly string[];
  platformLeadRoles?: readonly string[];
};

const DEFAULT_ADMIN_ROLES: readonly string[] = ["FLEX.Admin", "Admin"];
const DEFAULT_PLATFORM_LEAD_ROLES: readonly string[] = ["PLD", "Platform Lead"];

export function mapRawRoleToFlexRole(raw: string, options: RoleMappingOptions = {}): Role {
  const value = raw.trim();

  if (isRole(value)) {
    return value;
  }

  const adminRoles = options.adminRoles ?? DEFAULT_ADMIN_ROLES;
  const platformLeadRoles = options.platformLeadRoles ?? DEFAULT_PLATFORM_LEAD_ROLES;

  if (matchesIgnoreCase(adminRoles, value)) {
    return ROLES.ADMIN;
  }

  if (matchesIgnoreCase(platformLeadRoles, value)) {
    return ROLES.PLATFORM_LEAD;
  }

  return ROLES.USER;
}

/**
 * Resolves the highest-privilege FLEX role from a list of raw roles, then
 * returns the union of permissions for that role. An empty list yields
 * {@link ROLES.USER} permissions.
 */
export function resolvePermissions(
  rawRoles: readonly string[],
  options: RoleMappingOptions = {},
): readonly Permission[] {
  const flexRoles = rawRoles.map((role) => mapRawRoleToFlexRole(role, options));
  const effectiveRole = pickHighestRole(flexRoles);
  return getPermissionsForRole(effectiveRole);
}

const ROLE_RANK: Record<Role, number> = {
  [ROLES.USER]: 0,
  [ROLES.PLATFORM_LEAD]: 1,
  [ROLES.ADMIN]: 2,
};

/** Selects the most privileged role, defaulting to {@link ROLES.USER}. */
export function pickHighestRole(roles: readonly Role[]): Role {
  return roles.reduce<Role>((highest, role) => {
    return ROLE_RANK[role] > ROLE_RANK[highest] ? role : highest;
  }, ROLES.USER);
}

function matchesIgnoreCase(candidates: readonly string[], value: string): boolean {
  return candidates.some((candidate) => candidate.toLowerCase() === value.toLowerCase());
}
