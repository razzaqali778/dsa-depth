import { ApiProperty } from "@nestjs/swagger";
import type { Permission, Role } from "../../domain/rbac";

/** Public projection of a user record returned by the API. */
export class UserProfileDto {
  @ApiProperty()
  id!: string;

  @ApiProperty()
  email!: string;

  @ApiProperty()
  name!: string;

  @ApiProperty({ enum: ["Admin", "Platform Lead", "User"] })
  role!: Role;

  @ApiProperty()
  isActive!: boolean;

  @ApiProperty({ enum: ["local", "azure"] })
  authProvider!: "local" | "azure";

  @ApiProperty({ nullable: true, type: String, format: "date-time" })
  lastLoginAt!: string | null;

  @ApiProperty({ format: "date-time" })
  createdAt!: string;

  @ApiProperty({ format: "date-time" })
  updatedAt!: string;
}

/** Authenticated session: the resolved user plus their effective permissions. */
export class AuthSessionDto {
  @ApiProperty({ type: UserProfileDto })
  user!: UserProfileDto;

  @ApiProperty({
    type: [String],
    enum: ["view_dashboard", "view_users", "manage_users", "assign_roles", "view_audit"],
  })
  permissions!: Permission[];
}
