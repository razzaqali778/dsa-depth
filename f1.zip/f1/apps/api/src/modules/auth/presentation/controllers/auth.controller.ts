import { Controller, Get, Post, UnauthorizedException } from "@nestjs/common";
import {
  ApiBearerAuth,
  ApiOkResponse,
  ApiOperation,
  ApiTags,
  ApiUnauthorizedResponse,
} from "@nestjs/swagger";
import { CurrentUser } from "../../../../platform/auth/decorators/current-user.decorator";
import type { AuthenticatedUser } from "../../../../platform/auth/types/auth-context";
import { Public } from "../../../../platform/auth/decorators/public.decorator";
import { AzureAuthService } from "../../application/services/azure-auth.service";
import { AuthService } from "../../application/services/auth.service";
import { AuthSummaryResponseDto } from "../dto/auth-summary.response";
import { AuthSessionDto } from "../dto/session.response";

@ApiTags("auth")
@Controller("auth")
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly azureAuthService: AzureAuthService,
  ) {}

  @Public()
  @ApiOperation({ summary: "Describe the auth module and current auth boundary" })
  @ApiOkResponse({ type: AuthSummaryResponseDto })
  @Get("summary")
  getSummary() {
    return this.authService.getSummary();
  }

  @ApiBearerAuth("bearer")
  @ApiOperation({ summary: "Establish an authenticated FLEX session from the current identity" })
  @ApiOkResponse({ type: AuthSessionDto })
  @ApiUnauthorizedResponse({ description: "Missing or invalid identity token." })
  @Post("verify")
  verify(@CurrentUser() user: AuthenticatedUser | undefined) {
    return this.azureAuthService.provision(requireUser(user), { recordLogin: true });
  }

  @ApiBearerAuth("bearer")
  @ApiOperation({ summary: "Read the current authenticated FLEX session" })
  @ApiOkResponse({ type: AuthSessionDto })
  @ApiUnauthorizedResponse({ description: "Missing or invalid identity token." })
  @Get("me")
  getMe(@CurrentUser() user: AuthenticatedUser | undefined) {
    return this.azureAuthService.provision(requireUser(user));
  }
}

function requireUser(user: AuthenticatedUser | undefined): AuthenticatedUser {
  if (!user) {
    throw new UnauthorizedException("Authentication required");
  }

  return user;
}
