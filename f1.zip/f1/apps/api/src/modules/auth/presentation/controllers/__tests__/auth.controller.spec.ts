import { vi } from "vitest";
import { AuthController } from "../auth.controller";
import type { AzureAuthService } from "../../application/services/azure-auth.service";
import type { AuthService } from "../../application/services/auth.service";

describe("AuthController", () => {
  const session = { user: { id: "u1" }, permissions: ["view_dashboard"] };
  const authService = {
    getSummary: vi.fn(),
  } as unknown as AuthService;
  const azureAuthService = {
    provision: vi.fn(),
  } as unknown as AzureAuthService;
  const controller = new AuthController(authService, azureAuthService);

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("delegates summary requests to AuthService", async () => {
    const summary = {
      module: "auth",
      displayName: "Auth",
      route: "/api/auth",
      responsibilities: [],
      sourceIntegrations: [],
      databaseBoundary: "Auth DB",
      databaseName: "flex_auth",
      databaseUrlEnvVar: "AUTH_DATABASE_URL",
      publishesEvents: [],
      consumesEvents: [],
      currentPhase: "boilerplate" as const,
    };
    vi.mocked(authService.getSummary).mockResolvedValue(summary);

    await expect(controller.getSummary()).resolves.toBe(summary);
    expect(authService.getSummary).toHaveBeenCalledTimes(1);
  });

  it("verifies the current identity and records a login", async () => {
    vi.mocked(azureAuthService.provision).mockResolvedValue(session as never);
    const user = { id: "u1", roles: ["Admin"] };

    await expect(controller.verify(user)).resolves.toBe(session);
    expect(azureAuthService.provision).toHaveBeenCalledWith(user, { recordLogin: true });
  });

  it("returns the current session without recording a login", async () => {
    vi.mocked(azureAuthService.provision).mockResolvedValue(session as never);
    const user = { id: "u1", roles: ["Admin"] };

    await expect(controller.getMe(user)).resolves.toBe(session);
    expect(azureAuthService.provision).toHaveBeenCalledWith(user);
  });

  it("rejects verify without an ingress identity", () => {
    expect(() => controller.verify(undefined)).toThrow("Authentication required");
  });
});
