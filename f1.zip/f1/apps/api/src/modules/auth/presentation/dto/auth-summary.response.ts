import { ApiProperty } from "@nestjs/swagger";
import type { SourceIntegrationDefinition } from "../../../../platform/modules/flex-module.definition";

class SourceIntegrationDto implements SourceIntegrationDefinition {
  @ApiProperty()
  sourceSystem!: string;

  @ApiProperty({ enum: ["read-only", "write-back-future"] })
  direction!: "read-only" | "write-back-future";

  @ApiProperty()
  adapterBoundary!: string;

  @ApiProperty()
  ownedByModule!: boolean;
}

export class AuthSummaryResponseDto {
  @ApiProperty()
  module!: string;

  @ApiProperty()
  displayName!: string;

  @ApiProperty()
  route!: string;

  @ApiProperty({ type: [String] })
  responsibilities!: string[];

  @ApiProperty({ type: [SourceIntegrationDto] })
  sourceIntegrations!: SourceIntegrationDefinition[];

  @ApiProperty()
  databaseBoundary!: string;

  @ApiProperty()
  databaseName!: string;

  @ApiProperty()
  databaseUrlEnvVar!: string;

  @ApiProperty({ type: [String] })
  publishesEvents!: string[];

  @ApiProperty({ type: [String] })
  consumesEvents!: string[];

  @ApiProperty({ enum: ["boilerplate"] })
  currentPhase!: "boilerplate";
}
