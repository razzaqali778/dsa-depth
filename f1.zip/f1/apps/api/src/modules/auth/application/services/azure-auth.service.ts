import { Inject, Injectable } from "@nestjs/common";
import { Traced } from "../../../../platform/telemetry/traced.decorator";
import type { AuthenticatedUser } from "../../../../platform/auth/types/auth-context";
import {
  USER_REPOSITORY,
  type UpsertIdentityData,
  type UserRepositoryPort,
} from "../ports/user-repository.port";
import type { AuthSessionDto } from "../../presentation/dto/session.response";
import { RbacService } from "./rbac.service";
import { toUserProfile } from "./user-profile.mapper";

type ProvisionOptions = {
  recordLogin?: boolean;
  now?: () => Date;
};

/**
 * Provisions FLEX users from an ingress identity (Entra token, gateway header,
 * or local dev) and assembles the authenticated session. Identity verification
 * itself happens in the platform layer; this service owns the authorization
 * domain (user record + role mapping).
 */
@Injectable()
export class AzureAuthService {
  constructor(
    @Inject(USER_REPOSITORY) private readonly userRepo: UserRepositoryPort,
    private readonly rbac: RbacService,
  ) {}

  @Traced()
  async provision(user: AuthenticatedUser, options: ProvisionOptions = {}): Promise<AuthSessionDto> {
    const identity = this.toUpsertData(user);
    const record = await this.userRepo.upsertFromIdentity(identity);

    if (options.recordLogin) {
      const now = options.now ?? (() => new Date());
      await this.userRepo.recordLogin(record.id, now());
      record.lastLoginAt = now();
    }

    return {
      user: toUserProfile(record),
      permissions: [...this.rbac.getPermissions(record.role)],
    };
  }

  private toUpsertData(user: AuthenticatedUser): UpsertIdentityData {
    const provider = user.provider ?? (user.tenantId ? "azure" : "local");
    const email = user.email ?? `${user.id}@flex.local`;

    return {
      email: email.toLowerCase(),
      name: user.displayName ?? user.email ?? user.id,
      role: this.rbac.resolveRole(user.roles),
      provider,
      azureId: provider === "azure" ? user.id : null,
      tenantId: user.tenantId ?? null,
    };
  }
}
