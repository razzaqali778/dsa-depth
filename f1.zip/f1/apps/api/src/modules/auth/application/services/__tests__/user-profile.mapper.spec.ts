import { ROLES } from "../../../domain/rbac";
import type { UserRecord } from "../../ports/user-repository.port";
import { toUserProfile } from "../user-profile.mapper";

const CREATED_AT = "2026-01-01T00:00:00.000Z";
const UPDATED_AT = "2026-01-02T00:00:00.000Z";

function makeRecord(overrides: Partial<UserRecord> = {}): UserRecord {
  return {
    id: "u1",
    email: "user@flex",
    name: "User One",
    role: ROLES.USER,
    isActive: true,
    authProvider: "azure",
    azureId: "oid-1",
    tenantId: "tenant-1",
    lastLoginAt: new Date(CREATED_AT),
    createdAt: new Date(CREATED_AT),
    updatedAt: new Date(UPDATED_AT),
    ...overrides,
  };
}

describe("toUserProfile", () => {
  it("serialises dates to ISO strings", () => {
    const profile = toUserProfile(makeRecord());

    expect(profile).toMatchObject({
      id: "u1",
      email: "user@flex",
      role: ROLES.USER,
      lastLoginAt: CREATED_AT,
      createdAt: CREATED_AT,
      updatedAt: UPDATED_AT,
    });
  });

  it("maps a null last login to null", () => {
    const profile = toUserProfile(makeRecord({ lastLoginAt: null }));
    expect(profile.lastLoginAt).toBeNull();
  });
});
