import { Injectable } from "@nestjs/common";
import { Traced } from "../../../../platform/telemetry/traced.decorator";
import { authDefinition } from "../../auth.definition";
import type { AuthSummaryResponseDto } from "../../presentation/dto/auth-summary.response";

@Injectable()
export class AuthService {
  @Traced("AuthService.getSummary")
  async getSummary(): Promise<AuthSummaryResponseDto> {
    return {
      module: authDefinition.key,
      displayName: authDefinition.displayName,
      route: authDefinition.route,
      responsibilities: authDefinition.responsibilities,
      sourceIntegrations: authDefinition.sourceIntegrations,
      databaseBoundary: authDefinition.databaseBoundary,
      databaseName: authDefinition.databaseName,
      databaseUrlEnvVar: authDefinition.databaseUrlEnvVar,
      publishesEvents: authDefinition.publishesEvents,
      consumesEvents: authDefinition.consumesEvents,
      currentPhase: "boilerplate",
    };
  }
}
