import type { UserRecord } from "../ports/user-repository.port";
import type { UserProfileDto } from "../../presentation/dto/session.response";

/** Projects a persisted {@link UserRecord} into the public API shape. */
export function toUserProfile(record: UserRecord): UserProfileDto {
  return {
    id: record.id,
    email: record.email,
    name: record.name,
    role: record.role,
    isActive: record.isActive,
    authProvider: record.authProvider,
    lastLoginAt: record.lastLoginAt ? record.lastLoginAt.toISOString() : null,
    createdAt: record.createdAt.toISOString(),
    updatedAt: record.updatedAt.toISOString(),
  };
}
