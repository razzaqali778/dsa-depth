import { Injectable } from "@nestjs/common";
import { Traced } from "../../../../platform/telemetry/traced.decorator";
import {
  type Permission,
  type Role,
  type RoleMappingOptions,
  getPermissionsForRole,
  hasPermission,
  mapRawRoleToFlexRole,
  pickHighestRole,
  resolvePermissions,
} from "../../domain/rbac";

/**
 * Injectable facade over the RBAC domain. Reads optional Entra role mappings
 * from the environment so deployments can align app roles to FLEX roles.
 */
@Injectable()
export class RbacService {
  private readonly mappingOptions: RoleMappingOptions = {
    adminRoles: splitEnv(process.env.AZURE_ADMIN_ROLES),
    platformLeadRoles: splitEnv(process.env.AZURE_PLATFORM_LEAD_ROLES),
  };

  @Traced()
  mapRole(rawRole: string): Role {
    return mapRawRoleToFlexRole(rawRole, this.mappingOptions);
  }

  @Traced()
  resolveRole(rawRoles: readonly string[]): Role {
    const flexRoles = rawRoles.map((role) => this.mapRole(role));
    return pickHighestRole(flexRoles);
  }

  @Traced()
  hasPermission(role: Role, permission: Permission): boolean {
    return hasPermission(role, permission);
  }

  @Traced()
  getPermissions(role: Role): readonly Permission[] {
    return getPermissionsForRole(role);
  }

  @Traced()
  resolvePermissions(rawRoles: readonly string[]): readonly Permission[] {
    return resolvePermissions(rawRoles, this.mappingOptions);
  }

  @Traced()
  isAllowed(rawRoles: readonly string[], permission: Permission): boolean {
    return this.resolvePermissions(rawRoles).includes(permission);
  }
}

function splitEnv(value: string | undefined): string[] | undefined {
  if (!value) {
    return undefined;
  }

  const entries = value
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean);

  return entries.length > 0 ? entries : undefined;
}
