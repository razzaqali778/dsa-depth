import type { Role } from "../../domain/rbac";

/** Injection token for the user repository adapter. */
export const USER_REPOSITORY = "AUTH_USER_REPOSITORY";

/** Persisted user record inside the `flex_auth` boundary. */
export type UserRecord = {
  id: string;
  email: string;
  name: string;
  role: Role;
  isActive: boolean;
  authProvider: "local" | "azure";
  azureId: string | null;
  tenantId: string | null;
  lastLoginAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
};

/** Data used to upsert a user provisioned from an ingress identity. */
export type UpsertIdentityData = {
  email: string;
  name: string;
  role: Role;
  provider: "local" | "azure";
  azureId: string | null;
  tenantId: string | null;
};

/** Data for creating a local (non-SSO) user, e.g. dev/bootstrap. */
export type CreateLocalUserData = {
  email: string;
  name: string;
  role: Role;
};

/** Partial update applied by admins. */
export type UpdateUserData = {
  name?: string;
  role?: Role;
  isActive?: boolean;
};

/** Filters for listing users. */
export type ListUsersFilter = {
  search?: string;
  role?: Role;
  isActive?: boolean;
  skip?: number;
  take?: number;
};

/** Page of users plus the total count matching the filter. */
export type ListUsersResult = {
  items: UserRecord[];
  total: number;
};

/**
 * Persistence contract for users. Implemented by an in-memory adapter today and
 * a Prisma adapter once a database URL is provided.
 */
export interface UserRepositoryPort {
  findById(id: string): Promise<UserRecord | null>;
  findByEmail(email: string): Promise<UserRecord | null>;
  findByAzureId(azureId: string): Promise<UserRecord | null>;
  list(filter: ListUsersFilter): Promise<ListUsersResult>;
  upsertFromIdentity(data: UpsertIdentityData): Promise<UserRecord>;
  createLocal(data: CreateLocalUserData): Promise<UserRecord>;
  update(id: string, data: UpdateUserData): Promise<UserRecord | null>;
  setActive(id: string, isActive: boolean): Promise<UserRecord | null>;
  recordLogin(id: string, at: Date): Promise<void>;
}
