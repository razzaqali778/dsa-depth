import { vi } from "vitest";
import type { AuthenticatedUser } from "../../../../platform/auth/types/auth-context";
import { ROLES } from "../../../domain/rbac";
import type { UserRecord, UserRepositoryPort } from "../../ports/user-repository.port";
import { AzureAuthService } from "../azure-auth.service";
import { RbacService } from "../rbac.service";

function makeRecord(overrides: Partial<UserRecord> = {}): UserRecord {
  const now = new Date("2026-02-01T00:00:00.000Z");
  return {
    id: "db-1",
    email: "user@flex",
    name: "User One",
    role: ROLES.USER,
    isActive: true,
    authProvider: "azure",
    azureId: "oid-1",
    tenantId: "tenant-1",
    lastLoginAt: null,
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

function makeRepo(): UserRepositoryPort {
  return {
    findById: vi.fn(),
    findByEmail: vi.fn(),
    findByAzureId: vi.fn(),
    list: vi.fn(),
    upsertFromIdentity: vi.fn(),
    createLocal: vi.fn(),
    update: vi.fn(),
    setActive: vi.fn(),
    recordLogin: vi.fn(),
  };
}

describe("AzureAuthService", () => {
  let repo: UserRepositoryPort;
  let service: AzureAuthService;

  beforeEach(() => {
    repo = makeRepo();
    service = new AzureAuthService(repo, new RbacService());
  });

  it("provisions an Entra user and resolves permissions", async () => {
    const record = makeRecord({ role: ROLES.PLATFORM_LEAD });
    vi.mocked(repo.upsertFromIdentity).mockResolvedValue(record);

    const user: AuthenticatedUser = {
      id: "oid-1",
      email: "User@Flex",
      displayName: "User One",
      roles: ["PLD"],
      provider: "azure",
      tenantId: "tenant-1",
    };

    const session = await service.provision(user);

    expect(repo.upsertFromIdentity).toHaveBeenCalledWith({
      email: "user@flex",
      name: "User One",
      role: ROLES.PLATFORM_LEAD,
      provider: "azure",
      azureId: "oid-1",
      tenantId: "tenant-1",
    });
    expect(session.user.role).toBe(ROLES.PLATFORM_LEAD);
    expect(session.permissions).toContain("manage_users");
  });

  it("treats identities without tenant as local and synthesises an email", async () => {
    const record = makeRecord({ authProvider: "local", azureId: null, email: "local-dev@flex.local" });
    vi.mocked(repo.upsertFromIdentity).mockResolvedValue(record);

    const user: AuthenticatedUser = { id: "local-dev", roles: ["Admin"] };

    await service.provision(user);

    expect(repo.upsertFromIdentity).toHaveBeenCalledWith(
      expect.objectContaining({
        email: "local-dev@flex.local",
        provider: "local",
        azureId: null,
        role: ROLES.ADMIN,
      }),
    );
  });

  it("records the login timestamp when requested", async () => {
    const record = makeRecord();
    vi.mocked(repo.upsertFromIdentity).mockResolvedValue(record);
    const now = new Date("2026-03-03T03:03:03.000Z");

    const session = await service.provision(
      { id: "oid-1", email: "user@flex", roles: [], provider: "azure" },
      { recordLogin: true, now: () => now },
    );

    expect(repo.recordLogin).toHaveBeenCalledWith("db-1", now);
    expect(session.user.lastLoginAt).toBe(now.toISOString());
  });
});
