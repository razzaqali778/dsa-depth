import { PERMISSIONS, ROLES } from "../../../domain/rbac";
import { RbacService } from "../rbac.service";

describe("RbacService", () => {
  const service = new RbacService();

  it("maps raw roles to FLEX roles", () => {
    expect(service.mapRole("PLD")).toBe(ROLES.PLATFORM_LEAD);
    expect(service.mapRole("unknown")).toBe(ROLES.USER);
  });

  it("resolves the highest role from a list", () => {
    expect(service.resolveRole(["User", "FLEX.Admin"])).toBe(ROLES.ADMIN);
    expect(service.resolveRole([])).toBe(ROLES.USER);
  });

  it("checks a permission for a single role", () => {
    expect(service.hasPermission(ROLES.ADMIN, PERMISSIONS.MANAGE_USERS)).toBe(true);
    expect(service.hasPermission(ROLES.USER, PERMISSIONS.MANAGE_USERS)).toBe(false);
  });

  it("returns the permission set for a role", () => {
    expect(service.getPermissions(ROLES.USER)).toEqual([PERMISSIONS.VIEW_DASHBOARD]);
  });

  it("resolves permissions from multiple raw roles", () => {
    const perms = service.resolvePermissions(["User", "PLD"]);
    expect(perms).toContain(PERMISSIONS.MANAGE_USERS);
  });

  it("answers isAllowed against resolved permissions", () => {
    expect(service.isAllowed(["FLEX.Admin"], PERMISSIONS.VIEW_AUDIT)).toBe(true);
    expect(service.isAllowed(["User"], PERMISSIONS.MANAGE_USERS)).toBe(false);
  });

  it("reads custom Entra role mappings from the environment", () => {
    const previous = process.env.AZURE_ADMIN_ROLES;
    process.env.AZURE_ADMIN_ROLES = "corp-superadmins";
    try {
      const scoped = new RbacService();
      expect(scoped.mapRole("corp-superadmins")).toBe(ROLES.ADMIN);
    } finally {
      process.env.AZURE_ADMIN_ROLES = previous;
    }
  });
});
