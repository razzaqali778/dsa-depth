import { Module } from "@nestjs/common";
import { AuthService } from "./application/services/auth.service";
import { AzureAuthService } from "./application/services/azure-auth.service";
import { RbacService } from "./application/services/rbac.service";
import { USER_REPOSITORY } from "./application/ports/user-repository.port";
import { InMemoryUserRepository } from "./infrastructure/persistence/in-memory-user.repository";
import { AuthController } from "./presentation/controllers/auth.controller";

@Module({
  controllers: [AuthController],
  providers: [
    AuthService,
    AzureAuthService,
    RbacService,
    InMemoryUserRepository,
    {
      provide: USER_REPOSITORY,
      useExisting: InMemoryUserRepository,
    },
  ],
})
export class AuthModule {}
