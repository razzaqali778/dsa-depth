import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { HealthModule } from "./health/health.module";
import { AuthModule } from "./platform/auth/auth.module";
import { TelemetryModule } from "./platform/telemetry/telemetry.module";
import { bootstrapModules } from "./platform/modules/bootstrap-modules";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    TelemetryModule,       // Global tracing interceptor (Layer 1: API spans)
    AuthModule,
    HealthModule,
    ...bootstrapModules(), // All business modules loaded from FLEX_MODULE_CATALOG
  ],
})
export class AppModule {}
