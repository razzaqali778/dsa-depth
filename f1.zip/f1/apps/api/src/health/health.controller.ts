import { Controller, Get } from "@nestjs/common";
import { ApiOkResponse, ApiOperation, ApiTags } from "@nestjs/swagger";
import { Public } from "../platform/auth/decorators/public.decorator";

@Public()
@ApiTags("health")
@Controller("health")
export class HealthController {
  @ApiOperation({ summary: "Check API health" })
  @ApiOkResponse({
    schema: {
      type: "object",
      properties: {
        status: { type: "string", example: "ok" },
        service: { type: "string", example: "resource-allocation-api" },
      },
    },
  })
  @Get()
  getHealth() {
    return {
      status: "ok",
      service: "resource-allocation-api",
    };
  }
}
