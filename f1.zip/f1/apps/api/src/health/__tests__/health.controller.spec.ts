import { HealthController } from "../health.controller";

describe("HealthController", () => {
  const controller = new HealthController();

  it("returns service health status", () => {
    expect(controller.getHealth()).toEqual({
      status: "ok",
      service: "resource-allocation-api",
    });
  });
});
