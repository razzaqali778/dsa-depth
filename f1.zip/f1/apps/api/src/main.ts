import { initTelemetry } from "./platform/telemetry/otel-sdk";

initTelemetry({ serviceName: "flex-api", version: "0.1.0" });

import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { DocumentBuilder, SwaggerModule } from "@nestjs/swagger";
import { AppModule } from "./app.module";
import { configureNetworkLayer } from "./platform/network/configure-network";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  configureNetworkLayer(app);
  configureSwagger(app);

  await app.listen(
    Number(process.env.API_PORT ?? 3000),
    process.env.FLEX_BIND_HOST ?? "127.0.0.1",
  );
}

void bootstrap();

function configureSwagger(app: Awaited<ReturnType<typeof NestFactory.create>>): void {
  const config = new DocumentBuilder()
    .setTitle("FLEX API")
    .setDescription("Authentication and OIDC session endpoints for FLEX.")
    .setVersion("0.1.0")
    .addBearerAuth(
      {
        type: "http",
        scheme: "bearer",
        bearerFormat: "JWT",
        description: "Microsoft Entra access token used when AUTH_MODE=bearer.",
      },
      "bearer",
    )
    .build();

  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup("api/docs", app, document, {
    swaggerOptions: { persistAuthorization: true },
  });
}
