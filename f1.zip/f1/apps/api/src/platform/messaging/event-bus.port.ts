import type { IntegrationEvent } from "./integration-event";

export interface EventBusPort {
  publish<TPayload>(event: IntegrationEvent<TPayload>): Promise<void>;
}
