# Messaging Boundary

RabbitMQ is a planned broker option for source snapshot events, projection updates, async workflows, and future service extraction.

Current rule:

- no RabbitMQ runtime wiring in the boilerplate
- modules depend on `EventBusPort` when async workflows are implemented
- module subscribers store data only in their owning module DB
- queue topology, retry, DLQ, and security need an ADR before production use
