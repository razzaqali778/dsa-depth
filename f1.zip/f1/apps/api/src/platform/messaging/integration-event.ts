export type IntegrationEvent<TPayload> = {
  id: string;
  name: string;
  version: number;
  occurredAt: string;
  correlationId?: string;
  payload: TPayload;
};
