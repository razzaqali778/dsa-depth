export type AuthMode = "disabled" | "gateway" | "bearer";

export type AuthenticatedUser = {
  id: string;
  email?: string;
  displayName?: string;
  roles: string[];
  provider?: "local" | "azure";
  tenantId?: string;
};
