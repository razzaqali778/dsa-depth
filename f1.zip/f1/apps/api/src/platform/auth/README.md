# Auth Boundary

FLEX separates **ingress identity** from the **authorization domain**:

| Concern | Location | Owns |
| --- | --- | --- |
| Ingress identity | `apps/api/src/platform/auth` | Gateway header parsing, `@CurrentUser()`, `@Public()` |
| Authorization domain | `apps/api/src/modules/auth` | Users, roles, permissions, `flex_auth` DB, domain events |

FLEX does not implement SSO inside product modules.

The deployed target is:

```text
Enterprise identity provider
  -> API Gateway / Enterprise Ingress
  -> NestJS GatewayAuthGuard
  -> module controller / handler
```

Local development defaults to `AUTH_MODE=disabled`, which injects a local developer user.

Deployed gateway mode uses headers forwarded by the enterprise gateway:

- `x-flex-user-id`
- `x-flex-user-email`
- `x-flex-user-name`
- `x-flex-user-roles`

Product modules should read identity through `CurrentUser`, not by parsing headers directly.
