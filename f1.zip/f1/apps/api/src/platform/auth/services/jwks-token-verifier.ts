import { createPublicKey, verify as cryptoVerify, type KeyObject } from "node:crypto";
import { Injectable, Optional, UnauthorizedException } from "@nestjs/common";

/** Normalised identity claims extracted from a verified Entra token. */
export type VerifiedClaims = {
  subjectId: string;
  email?: string;
  name?: string;
  roles: string[];
  tenantId?: string;
};

type Jwk = {
  kid: string;
  kty: string;
  n: string;
  e: string;
  alg?: string;
  use?: string;
};

type JwksResponse = { keys: Jwk[] };

type RawClaims = {
  iss?: string;
  aud?: string | string[];
  exp?: number;
  nbf?: number;
  oid?: string;
  sub?: string;
  tid?: string;
  name?: string;
  email?: string;
  preferred_username?: string;
  upn?: string;
  roles?: string[];
};

export type JwksVerifierConfig = {
  jwksUri: string;
  issuer?: string;
  audience?: string;
  now?: () => number;
  fetchImpl?: typeof fetch;
  cacheTtlMs?: number;
};

const RS256 = "RS256";
const CLOCK_SKEW_SECONDS = 60;
const DEFAULT_CACHE_TTL_MS = 10 * 60 * 1000;

/**
 * Verifies Microsoft Entra (Azure AD) RS256 JWTs against the tenant JWKS using
 * only Node built-ins (no external dependency). Configuration is read lazily
 * from the environment unless explicit overrides are supplied (tests).
 */
@Injectable()
export class JwksTokenVerifier {
  private keyCache = new Map<string, KeyObject>();
  private keyCacheExpiry = 0;
  private resolvedConfig: JwksVerifierConfig | null = null;

  constructor(@Optional() private readonly overrides: Partial<JwksVerifierConfig> = {}) {}

  async verify(token: string): Promise<VerifiedClaims> {
    const config = this.getConfig();
    const { headerSegment, payloadSegment, signature } = parseToken(token);

    const header = decodeSegment<{ alg?: string; kid?: string }>(headerSegment);
    if (header.alg !== RS256 || !header.kid) {
      throw new UnauthorizedException("Unsupported token header");
    }

    const claims = decodeSegment<RawClaims>(payloadSegment);
    assertTimeValid(claims, config.now ?? defaultNow);
    assertIssuerAudience(claims, config);

    const key = await this.getSigningKey(header.kid, config);
    const signingInput = `${headerSegment}.${payloadSegment}`;
    if (!cryptoVerify("RSA-SHA256", Buffer.from(signingInput), key, signature)) {
      throw new UnauthorizedException("Invalid token signature");
    }

    return normalizeClaims(claims);
  }

  private getConfig(): JwksVerifierConfig {
    let config = this.resolvedConfig;
    if (config === null) {
      config = resolveConfigFromEnv(this.overrides);
      this.resolvedConfig = config;
    }
    return config;
  }

  private async getSigningKey(kid: string, config: JwksVerifierConfig): Promise<KeyObject> {
    const now = Date.now();
    if (this.keyCacheExpiry > now) {
      const cached = this.keyCache.get(kid);
      if (cached) {
        return cached;
      }
    }

    await this.refreshKeys(config);

    const key = this.keyCache.get(kid);
    if (!key) {
      throw new UnauthorizedException("Signing key not found");
    }
    return key;
  }

  private async refreshKeys(config: JwksVerifierConfig): Promise<void> {
    const fetchImpl = config.fetchImpl ?? fetch;
    const response = await fetchImpl(config.jwksUri);
    if (!response.ok) {
      throw new UnauthorizedException("Unable to load signing keys");
    }

    const body = (await response.json()) as JwksResponse;
    const cache = new Map<string, KeyObject>();
    for (const jwk of body.keys ?? []) {
      cache.set(jwk.kid, createPublicKey({ key: jwk, format: "jwk" }));
    }

    this.keyCache = cache;
    this.keyCacheExpiry = Date.now() + (config.cacheTtlMs ?? DEFAULT_CACHE_TTL_MS);
  }
}

function parseToken(token: string): {
  headerSegment: string;
  payloadSegment: string;
  signature: Buffer;
} {
  const parts = token.split(".");
  if (parts.length !== 3) {
    throw new UnauthorizedException("Malformed token");
  }
  return {
    headerSegment: parts[0],
    payloadSegment: parts[1],
    signature: base64UrlToBuffer(parts[2]),
  };
}

function decodeSegment<T>(segment: string): T {
  try {
    return JSON.parse(base64UrlToBuffer(segment).toString("utf8")) as T;
  } catch {
    throw new UnauthorizedException("Malformed token segment");
  }
}

function assertTimeValid(claims: RawClaims, now: () => number): void {
  const currentSeconds = now();
  if (typeof claims.exp === "number" && currentSeconds > claims.exp + CLOCK_SKEW_SECONDS) {
    throw new UnauthorizedException("Token expired");
  }
  if (typeof claims.nbf === "number" && currentSeconds + CLOCK_SKEW_SECONDS < claims.nbf) {
    throw new UnauthorizedException("Token not yet valid");
  }
}

function assertIssuerAudience(claims: RawClaims, config: JwksVerifierConfig): void {
  if (config.issuer && claims.iss !== config.issuer) {
    throw new UnauthorizedException("Unexpected token issuer");
  }
  if (config.audience && !audienceMatches(claims.aud, config.audience)) {
    throw new UnauthorizedException("Unexpected token audience");
  }
}

function audienceMatches(aud: string | string[] | undefined, expected: string): boolean {
  if (Array.isArray(aud)) {
    return aud.includes(expected);
  }
  return aud === expected;
}

function normalizeClaims(claims: RawClaims): VerifiedClaims {
  const subjectId = claims.oid ?? claims.sub;
  if (!subjectId) {
    throw new UnauthorizedException("Token missing subject");
  }

  return {
    subjectId,
    email: claims.email ?? claims.preferred_username ?? claims.upn,
    name: claims.name ?? claims.email ?? claims.preferred_username,
    roles: claims.roles ?? [],
    tenantId: claims.tid,
  };
}

function resolveConfigFromEnv(overrides: Partial<JwksVerifierConfig>): JwksVerifierConfig {
  const tenantId = process.env.AZURE_TENANT_ID;
  const derivedJwks = tenantId
    ? `https://login.microsoftonline.com/${tenantId}/discovery/v2.0/keys`
    : "";
  const derivedIssuer = tenantId
    ? `https://login.microsoftonline.com/${tenantId}/v2.0`
    : undefined;

  return {
    jwksUri: overrides.jwksUri ?? process.env.AZURE_JWKS_URI ?? derivedJwks,
    issuer: overrides.issuer ?? process.env.AZURE_ISSUER ?? derivedIssuer,
    audience: overrides.audience ?? process.env.AZURE_API_AUDIENCE,
    now: overrides.now,
    fetchImpl: overrides.fetchImpl,
    cacheTtlMs: overrides.cacheTtlMs,
  };
}

function base64UrlToBuffer(value: string): Buffer {
  return Buffer.from(value, "base64url");
}

function defaultNow(): number {
  return Math.floor(Date.now() / 1000);
}
