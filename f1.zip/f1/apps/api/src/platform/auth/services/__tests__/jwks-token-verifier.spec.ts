import { generateKeyPairSync, sign as cryptoSign, type KeyObject } from "node:crypto";
import { vi } from "vitest";
import { UnauthorizedException } from "@nestjs/common";
import { Test } from "@nestjs/testing";
import { JwksTokenVerifier, type JwksVerifierConfig } from "../jwks-token-verifier";

const { privateKey, publicKey } = generateKeyPairSync("rsa", { modulusLength: 2048 });

function buildJwk(key: KeyObject, kid: string) {
  return { ...key.export({ format: "jwk" }), kid, alg: "RS256", use: "sig" };
}

const jwk = buildJwk(publicKey, "test-key");

function segment(value: unknown): string {
  return Buffer.from(JSON.stringify(value)).toString("base64url");
}

function makeToken(
  claims: Record<string, unknown>,
  header: Record<string, unknown> = { alg: "RS256", kid: "test-key", typ: "JWT" },
): string {
  const headerSegment = segment(header);
  const payloadSegment = segment(claims);
  const signature = cryptoSign(
    "RSA-SHA256",
    Buffer.from(`${headerSegment}.${payloadSegment}`),
    privateKey,
  ).toString("base64url");
  return `${headerSegment}.${payloadSegment}.${signature}`;
}

function fakeFetch(body: unknown, ok = true) {
  return vi.fn().mockResolvedValue({
    ok,
    json: async () => body,
  } as Response);
}

const NOW_SECONDS = 1_000;
const ISSUER = "https://issuer.test";
const AUDIENCE = "api://flex";
const EMAIL = "user@flex";
const PREFERRED_USERNAME = "person@flex";

function makeVerifier(overrides: Partial<JwksVerifierConfig> = {}) {
  return new JwksTokenVerifier({
    jwksUri: "https://jwks.test/keys",
    issuer: ISSUER,
    audience: AUDIENCE,
    now: () => NOW_SECONDS,
    fetchImpl: fakeFetch({ keys: [jwk] }),
    ...overrides,
  });
}

const validClaims = {
  iss: ISSUER,
  aud: AUDIENCE,
  exp: NOW_SECONDS + 1_000,
  nbf: NOW_SECONDS - 100,
  oid: "oid-1",
  tid: "tenant-1",
  name: "User One",
  email: EMAIL,
  roles: ["PLD"],
};

describe("JwksTokenVerifier", () => {
  it("can be instantiated by Nest without a config provider", async () => {
    const moduleRef = await Test.createTestingModule({
      providers: [JwksTokenVerifier],
    }).compile();

    expect(moduleRef.get(JwksTokenVerifier)).toBeInstanceOf(JwksTokenVerifier);
  });

  it("verifies a valid token and normalises claims", async () => {
    const verifier = makeVerifier();

    const claims = await verifier.verify(makeToken(validClaims));

    expect(claims).toEqual({
      subjectId: "oid-1",
      email: EMAIL,
      name: "User One",
      roles: ["PLD"],
      tenantId: "tenant-1",
    });
  });

  it("falls back to preferred_username and sub", async () => {
    const verifier = makeVerifier();
    const token = makeToken({
      ...validClaims,
      oid: undefined,
      sub: "sub-1",
      email: undefined,
      name: undefined,
      preferred_username: PREFERRED_USERNAME,
      roles: undefined,
    });

    const claims = await verifier.verify(token);

    expect(claims).toMatchObject({
      subjectId: "sub-1",
      email: PREFERRED_USERNAME,
      name: PREFERRED_USERNAME,
      roles: [],
    });
  });

  it("accepts an audience array", async () => {
    const verifier = makeVerifier();
    const claims = await verifier.verify(makeToken({ ...validClaims, aud: ["other", "api://flex"] }));
    expect(claims.subjectId).toBe("oid-1");
  });

  it("caches keys across calls", async () => {
    const fetchImpl = fakeFetch({ keys: [jwk] });
    const verifier = makeVerifier({ fetchImpl });

    await verifier.verify(makeToken(validClaims));
    await verifier.verify(makeToken(validClaims));

    expect(fetchImpl).toHaveBeenCalledTimes(1);
  });

  it.each([
    ["malformed token", "a.b"],
  ])("rejects a %s", async (_label, token) => {
    await expect(makeVerifier().verify(token)).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it("rejects an unsupported algorithm", async () => {
    const token = makeToken(validClaims, { alg: "HS256", kid: "test-key" });
    await expect(makeVerifier().verify(token)).rejects.toThrow("Unsupported token header");
  });

  it("rejects a missing kid", async () => {
    const token = makeToken(validClaims, { alg: "RS256" });
    await expect(makeVerifier().verify(token)).rejects.toThrow("Unsupported token header");
  });

  it("rejects an expired token", async () => {
    const token = makeToken({ ...validClaims, exp: NOW_SECONDS - 1_000 });
    await expect(makeVerifier().verify(token)).rejects.toThrow("Token expired");
  });

  it("rejects a not-yet-valid token", async () => {
    const token = makeToken({ ...validClaims, nbf: NOW_SECONDS + 1_000 });
    await expect(makeVerifier().verify(token)).rejects.toThrow("Token not yet valid");
  });

  it("rejects an unexpected issuer", async () => {
    const token = makeToken({ ...validClaims, iss: "https://evil.test" });
    await expect(makeVerifier().verify(token)).rejects.toThrow("Unexpected token issuer");
  });

  it("rejects an unexpected audience", async () => {
    const token = makeToken({ ...validClaims, aud: "someone-else" });
    await expect(makeVerifier().verify(token)).rejects.toThrow("Unexpected token audience");
  });

  it("rejects a token missing a subject", async () => {
    const token = makeToken({ ...validClaims, oid: undefined, sub: undefined });
    await expect(makeVerifier().verify(token)).rejects.toThrow("Token missing subject");
  });

  it("rejects an unknown signing key", async () => {
    const verifier = makeVerifier({ fetchImpl: fakeFetch({ keys: [buildJwk(publicKey, "other")] }) });
    await expect(verifier.verify(makeToken(validClaims))).rejects.toThrow("Signing key not found");
  });

  it("rejects a tampered signature", async () => {
    const token = makeToken(validClaims);
    const [header, , signature] = token.split(".");
    const tampered = `${header}.${segment({ ...validClaims, oid: "hacker" })}.${signature}`;
    await expect(makeVerifier().verify(tampered)).rejects.toThrow("Invalid token signature");
  });

  it("throws when the JWKS endpoint fails", async () => {
    const verifier = makeVerifier({ fetchImpl: fakeFetch({}, false) });
    await expect(verifier.verify(makeToken(validClaims))).rejects.toThrow("Unable to load signing keys");
  });

  it("derives configuration from the environment", async () => {
    const previousTenant = process.env.AZURE_TENANT_ID;
    process.env.AZURE_TENANT_ID = "tenant-xyz";
    try {
      const verifier = new JwksTokenVerifier({
        audience: AUDIENCE,
        issuer: ISSUER,
        now: () => NOW_SECONDS,
        fetchImpl: fakeFetch({ keys: [jwk] }),
      });
      // jwksUri is derived from the tenant; verification still succeeds via fetch stub.
      const claims = await verifier.verify(makeToken(validClaims));
      expect(claims.subjectId).toBe("oid-1");
    } finally {
      process.env.AZURE_TENANT_ID = previousTenant;
    }
  });
});
