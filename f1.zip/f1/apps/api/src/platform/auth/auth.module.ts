import { Module } from "@nestjs/common";
import { APP_GUARD } from "@nestjs/core";
import { GatewayAuthGuard } from "./guards/gateway-auth.guard";
import { JwksTokenVerifier } from "./services/jwks-token-verifier";

@Module({
  providers: [
    JwksTokenVerifier,
    {
      provide: APP_GUARD,
      useClass: GatewayAuthGuard,
    },
  ],
  exports: [JwksTokenVerifier],
})
export class AuthModule {}
