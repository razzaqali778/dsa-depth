import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import type { AuthenticatedUser, AuthMode } from "../types/auth-context";
import { JwksTokenVerifier } from "../services/jwks-token-verifier";
import { IS_PUBLIC_ROUTE } from "../decorators/public.decorator";

type RequestWithUser = {
  headers: Record<string, string | string[] | undefined>;
  user?: AuthenticatedUser;
};

@Injectable()
export class GatewayAuthGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly tokenVerifier: JwksTokenVerifier,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_ROUTE, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (isPublic) {
      return true;
    }

    const authMode = (process.env.AUTH_MODE ?? "disabled") as AuthMode;
    const request = context.switchToHttp().getRequest<RequestWithUser>();

    if (authMode === "disabled") {
      request.user = {
        id: "local-dev",
        email: "local-dev@flex",
        displayName: "Local Developer",
        roles: ["Admin"],
        provider: "local",
      };
      return true;
    }

    if (authMode === "bearer") {
      request.user = await this.verifyBearer(request);
      return true;
    }

    const userId = this.readHeader(request, "x-flex-user-id");

    if (!userId) {
      throw new UnauthorizedException("Missing gateway identity header: x-flex-user-id");
    }

    request.user = {
      id: userId,
      email: this.readHeader(request, "x-flex-user-email"),
      displayName: this.readHeader(request, "x-flex-user-name"),
      roles: this.readHeader(request, "x-flex-user-roles")?.split(",").map((role) => role.trim()).filter(Boolean) ?? [],
      provider: "azure",
    };

    return true;
  }

  private async verifyBearer(request: RequestWithUser): Promise<AuthenticatedUser> {
    const authorization = this.readHeader(request, "authorization");
    const token = this.extractBearerToken(authorization);

    if (!token) {
      throw new UnauthorizedException("Missing bearer token");
    }

    const claims = await this.tokenVerifier.verify(token);
    return {
      id: claims.subjectId,
      email: claims.email,
      displayName: claims.name,
      roles: claims.roles,
      provider: "azure",
      tenantId: claims.tenantId,
    };
  }

  private extractBearerToken(authorization: string | undefined): string | undefined {
    if (!authorization) {
      return undefined;
    }

    const prefix = "bearer ";
    if (!authorization.toLowerCase().startsWith(prefix)) {
      return undefined;
    }

    const token = authorization.slice(prefix.length).trim();
    return token.length > 0 ? token : undefined;
  }

  private readHeader(request: RequestWithUser, name: string): string | undefined {
    const value = request.headers[name];

    if (Array.isArray(value)) {
      return value[0];
    }

    return value;
  }
}
