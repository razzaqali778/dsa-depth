import { vi } from "vitest";
import { UnauthorizedException } from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import type { ExecutionContext } from "@nestjs/common";
import type { AuthenticatedUser } from "../../types/auth-context";
import { GatewayAuthGuard } from "../gateway-auth.guard";
import type { JwksTokenVerifier } from "../../services/jwks-token-verifier";

type MockRequest = {
  headers: Record<string, string | string[] | undefined>;
  user?: AuthenticatedUser;
};

function makeContext(request: MockRequest) {
  return {
    getHandler: () => ({}),
    getClass: () => ({}),
    switchToHttp: () => ({
      getRequest: () => request,
    }),
  } as ExecutionContext;
}

describe("GatewayAuthGuard", () => {
  let guard: GatewayAuthGuard;
  let reflector: Reflector;
  let verifier: JwksTokenVerifier;
  const originalAuthMode = process.env.AUTH_MODE;

  beforeEach(() => {
    reflector = new Reflector();
    verifier = {
      verify: vi.fn(),
    } as unknown as JwksTokenVerifier;
    guard = new GatewayAuthGuard(reflector, verifier);
  });

  afterEach(() => {
    process.env.AUTH_MODE = originalAuthMode;
  });

  it("allows public routes", async () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(true);

    await expect(guard.canActivate(makeContext({ headers: {} }))).resolves.toBe(true);
  });

  it("sets a local developer user when auth is disabled", async () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    process.env.AUTH_MODE = "disabled";

    const request: MockRequest = { headers: {} };
    await expect(guard.canActivate(makeContext(request))).resolves.toBe(true);
    expect(request).toMatchObject({
      user: {
        id: "local-dev",
        email: "local-dev@flex",
        displayName: "Local Developer",
        roles: ["Admin"],
      },
    });
  });

  it("defaults to disabled auth when AUTH_MODE is unset", async () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    delete process.env.AUTH_MODE;

    const request: MockRequest = { headers: {} };
    await expect(guard.canActivate(makeContext(request))).resolves.toBe(true);
    expect(request.user).toBeDefined();
  });

  it("throws when gateway auth is enabled without identity headers", async () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    process.env.AUTH_MODE = "gateway";

    await expect(guard.canActivate(makeContext({ headers: {} }))).rejects.toThrow(
      new UnauthorizedException("Missing gateway identity header: x-flex-user-id"),
    );
  });

  it("maps gateway identity headers onto the request user", async () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    process.env.AUTH_MODE = "gateway";

    const request: MockRequest = {
      headers: {
        "x-flex-user-id": "user-1",
        "x-flex-user-email": "user@flex",
        "x-flex-user-name": "User One",
        "x-flex-user-roles": "Admin, Viewer",
      },
    };

    await expect(guard.canActivate(makeContext(request))).resolves.toBe(true);
    expect(request).toMatchObject({
      user: {
        id: "user-1",
        email: "user@flex",
        displayName: "User One",
        roles: ["Admin", "Viewer"],
      },
    });
  });

  it("reads the first value when a header is provided as an array", async () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    process.env.AUTH_MODE = "gateway";

    const request: MockRequest = {
      headers: {
        "x-flex-user-id": ["user-2", "ignored"],
      },
    };

    await expect(guard.canActivate(makeContext(request))).resolves.toBe(true);
    expect(request.user).toMatchObject({ id: "user-2", roles: [] });
  });

  it("verifies bearer tokens in bearer auth mode", async () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    vi.mocked(verifier.verify).mockResolvedValue({
      subjectId: "oid-1",
      email: "user@flex",
      name: "User One",
      roles: ["FLEX.Admin"],
      tenantId: "tenant-1",
    });
    process.env.AUTH_MODE = "bearer";

    const request: MockRequest = {
      headers: { authorization: "Bearer token-1" },
    };

    await expect(guard.canActivate(makeContext(request))).resolves.toBe(true);
    expect(verifier.verify).toHaveBeenCalledWith("token-1");
    expect(request.user).toMatchObject({
      id: "oid-1",
      email: "user@flex",
      displayName: "User One",
      roles: ["FLEX.Admin"],
      provider: "azure",
      tenantId: "tenant-1",
    });
  });

  it("rejects bearer mode without a bearer token", async () => {
    vi.spyOn(reflector, "getAllAndOverride").mockReturnValue(false);
    process.env.AUTH_MODE = "bearer";

    await expect(guard.canActivate(makeContext({ headers: {} }))).rejects.toThrow(
      new UnauthorizedException("Missing bearer token"),
    );
  });
});
