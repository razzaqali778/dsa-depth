# Integration Boundary

This is not a business module and it does not own business data.

This folder defines shared source-adapter contracts. Concrete external API clients belong inside the owning business module.

Current rule:

- no source-system calls from the frontend
- source synchronization starts from the backend API
- source adapters live under `apps/api/src/modules/{module}/infrastructure/integrations`
- source data is saved by the owning module into its own physical database
- source ownership and write-back must be documented before implementation
