export type SourceSnapshotRequest = {
  correlationId: string;
  requestedBy: string;
};

export type SourceSnapshot<TRecord> = {
  sourceSystem: string;
  records: TRecord[];
  capturedAt: Date;
};

export interface SourceAdapterPort<TRecord> {
  readonly sourceSystem: string;
  fetchSnapshot(request: SourceSnapshotRequest): Promise<SourceSnapshot<TRecord>>;
}
