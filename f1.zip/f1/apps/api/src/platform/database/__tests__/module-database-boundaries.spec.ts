import {
  MODULE_DATABASE_BOUNDARIES,
  getModuleDatabaseUrl,
} from "../module-database-boundaries";

describe("MODULE_DATABASE_BOUNDARIES", () => {
  it("should be a non-empty array", () => {
    expect(Array.isArray(MODULE_DATABASE_BOUNDARIES)).toBe(true);
    expect(MODULE_DATABASE_BOUNDARIES.length).toBeGreaterThan(0);
  });

  it("each entry should have owner, databaseName, and envVar", () => {
    for (const boundary of MODULE_DATABASE_BOUNDARIES) {
      expect(typeof boundary.owner).toBe("string");
      expect(boundary.owner.length).toBeGreaterThan(0);
      expect(typeof boundary.databaseName).toBe("string");
      expect(boundary.databaseName.length).toBeGreaterThan(0);
      expect(typeof boundary.envVar).toBe("string");
      expect(boundary.envVar.length).toBeGreaterThan(0);
    }
  });

  it("should contain the Integration Control boundary", () => {
    const entry = MODULE_DATABASE_BOUNDARIES.find(
      (b) => b.databaseName === "flex_integration_control",
    );
    expect(entry).toBeDefined();
    expect(entry?.owner).toBe("Integration Control");
    expect(entry?.envVar).toBe("INTEGRATION_CONTROL_DATABASE_URL");
  });

  it("should contain the Auth boundary", () => {
    const entry = MODULE_DATABASE_BOUNDARIES.find((b) => b.databaseName === "flex_auth");
    expect(entry).toBeDefined();
    expect(entry?.owner).toBe("Auth");
    expect(entry?.envVar).toBe("AUTH_DATABASE_URL");
  });
});

describe("getModuleDatabaseUrl", () => {
  const TEST_ENV_VAR = "TEST_MODULE_DB_URL";
  const TEST_VALUE = "postgres://localhost:5432/test_db";

  beforeEach(() => {
    delete process.env[TEST_ENV_VAR];
  });

  afterEach(() => {
    delete process.env[TEST_ENV_VAR];
  });

  it("should return the value of the given environment variable", () => {
    process.env[TEST_ENV_VAR] = TEST_VALUE;
    expect(getModuleDatabaseUrl(TEST_ENV_VAR)).toBe(TEST_VALUE);
  });

  it("should return undefined when the environment variable is not set", () => {
    expect(getModuleDatabaseUrl(TEST_ENV_VAR)).toBeUndefined();
  });
});
