export type CanonicalSnapshot<TRecord> = {
  sourceSystem: string;
  records: TRecord[];
  capturedAt: Date;
};

export interface ModuleDatabasePort<TRecord> {
  saveSnapshot(snapshot: CanonicalSnapshot<TRecord>): Promise<void>;
}
