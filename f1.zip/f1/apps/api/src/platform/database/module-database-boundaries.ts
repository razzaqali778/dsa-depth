export type ModuleDatabaseBoundary = {
  owner: string;
  databaseName: string;
  envVar: string;
};

// Module database boundaries are defined in each module's *.definition.ts file
// and registered in apps/api/src/platform/modules/flex-module.catalog.ts.
// The generator (scripts/create-flex-module.sh) wires this up automatically.
export const MODULE_DATABASE_BOUNDARIES: ModuleDatabaseBoundary[] = [
  {
    owner: "Integration Control",
    databaseName: "flex_integration_control",
    envVar: "INTEGRATION_CONTROL_DATABASE_URL",
  },
  {
    owner: "Auth",
    databaseName: "flex_auth",
    envVar: "AUTH_DATABASE_URL",
  },
];

export function getModuleDatabaseUrl(envVar: string) {
  return process.env[envVar];
}
