import { ValidationPipe, type INestApplication } from "@nestjs/common";

function getCorsOrigin() {
  const configured = process.env.CORS_ORIGIN;

  if (!configured) {
    return true;
  }

  return configured.split(",").map((origin) => origin.trim());
}

export function configureNetworkLayer(app: INestApplication) {
  app.setGlobalPrefix("api");
  app.enableCors({
    credentials: true,
    origin: getCorsOrigin(),
  });
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
    }),
  );
}
