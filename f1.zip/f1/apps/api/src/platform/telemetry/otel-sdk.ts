export type TelemetryInitOptions = {
  serviceName: string;
  version?: string;
};

const ATTR_SERVICE_NAME = "service.name";
const ATTR_SERVICE_VERSION = "service.version";

let sdkStarted = false;
let sdkStarting = false;

/** Reset init state between unit tests. */
export function resetTelemetryForTests(): void {
  sdkStarted = false;
  sdkStarting = false;
}

/**
 * Bootstraps the OpenTelemetry Node SDK. Must run before NestJS imports.
 * Set OTEL_SDK_DISABLED=true to skip (e.g. unit tests).
 */
export function initTelemetry(options: TelemetryInitOptions): void {
  if (sdkStarted || sdkStarting || process.env.OTEL_SDK_DISABLED === "true") {
    return;
  }

  sdkStarting = true;

  void loadTelemetryRuntime()
    .then(
      ({
        getNodeAutoInstrumentations,
        NodeSDK,
        OTLPMetricExporter,
        OTLPTraceExporter,
        PeriodicExportingMetricReader,
        Resource,
      }) => {
        const baseEndpoint = process.env.OTEL_EXPORTER_OTLP_ENDPOINT ?? "http://localhost:4318";
        const tracesUrl = `${baseEndpoint.replace(/\/$/, "")}/v1/traces`;
        const metricsUrl = `${baseEndpoint.replace(/\/$/, "")}/v1/metrics`;

        const sdk = new NodeSDK({
          resource: new Resource({
            [ATTR_SERVICE_NAME]: process.env.OTEL_SERVICE_NAME ?? options.serviceName,
            [ATTR_SERVICE_VERSION]: options.version ?? "0.1.0",
            "deployment.environment": process.env.NODE_ENV ?? "development",
          }),
          traceExporter: new OTLPTraceExporter({ url: tracesUrl }),
          metricReader: new PeriodicExportingMetricReader({
            exporter: new OTLPMetricExporter({ url: metricsUrl }),
            exportIntervalMillis: 15_000,
          }),
          instrumentations: [
            getNodeAutoInstrumentations({
              "@opentelemetry/instrumentation-fs": { enabled: false },
            }),
          ],
        });

        const shutdown = () => {
          void sdk.shutdown();
        };

        return Promise.resolve(sdk.start()).then(() => {
          sdkStarted = true;
          process.on("SIGTERM", shutdown);
          process.on("SIGINT", shutdown);
        });
      },
    )
    .then(() => {
      sdkStarted = true;
    })
    .catch((error) => {
      sdkStarting = false;
      console.warn("[telemetry] OpenTelemetry SDK failed to start — continuing without export:", error);
    });
}

async function loadTelemetryRuntime() {
  const [
    { getNodeAutoInstrumentations },
    { OTLPMetricExporter },
    { OTLPTraceExporter },
    { Resource },
    { NodeSDK },
    { PeriodicExportingMetricReader },
  ] = await Promise.all([
    import("@opentelemetry/auto-instrumentations-node"),
    import("@opentelemetry/exporter-metrics-otlp-http"),
    import("@opentelemetry/exporter-trace-otlp-http"),
    import("@opentelemetry/resources"),
    import("@opentelemetry/sdk-node"),
    import("@opentelemetry/sdk-metrics"),
  ]);

  return {
    getNodeAutoInstrumentations,
    NodeSDK,
    OTLPMetricExporter,
    OTLPTraceExporter,
    PeriodicExportingMetricReader,
    Resource,
  };
}
