import {
  CallHandler,
  ExecutionContext,
  Injectable,
  Logger,
  NestInterceptor,
} from "@nestjs/common";
import { context as otelContext, SpanStatusCode, trace } from "@opentelemetry/api";
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";

/**
 * Layer 1 — API / Controller tracing interceptor.
 * Creates OpenTelemetry spans for every controller method and logs structured traces.
 */
@Injectable()
export class TracingInterceptor implements NestInterceptor {
  private readonly logger = new Logger("Tracing");

  intercept(context: ExecutionContext, next: CallHandler): ReturnType<CallHandler["handle"]> {
    const className = context.getClass().name;
    const handlerName = context.getHandler().name;
    const spanName = `${className}.${handlerName}`;
    const start = Date.now();

    const req = context.switchToHttp().getRequest<{ user?: { id?: string } }>();
    const userId = req?.user?.id ?? "anonymous";

    const tracer = trace.getTracer("flex-api");
    const span = tracer.startSpan(spanName, undefined, otelContext.active());
    span.setAttribute("controller.class", className);
    span.setAttribute("controller.handler", handlerName);
    if (userId !== "anonymous") {
      span.setAttribute("user.id", userId);
    }

    const activeContext = trace.setSpan(otelContext.active(), span);
    let finished = false;

    const finishSpan = (outcome: "ok" | "error", err?: Error) => {
      if (finished) {
        return;
      }
      finished = true;
      const duration = Date.now() - start;
      if (outcome === "error" && err) {
        span.recordException(err);
        span.setStatus({ code: SpanStatusCode.ERROR, message: err.message });
        span.end();
        this.logger.error(
          `← [${spanName}] status=error duration=${duration}ms user=${userId} error=${err.message}`,
        );
        return;
      }
      span.setStatus({ code: SpanStatusCode.OK });
      span.end();
      this.logger.log(`← [${spanName}] status=ok duration=${duration}ms user=${userId}`);
    };

    this.logger.log(`→ [${spanName}] user=${userId}`);

    return new Observable((subscriber) => {
      otelContext.with(activeContext, () => {
        next.handle().subscribe({
          next: (value) => subscriber.next(value),
          error: (err) => subscriber.error(err),
          complete: () => subscriber.complete(),
        });
      });
    }).pipe(
      tap({
        complete: () => finishSpan("ok"),
        error: (err: Error) => finishSpan("error", err),
      }),
    );
  }
}
