import { Logger } from "@nestjs/common";
import { context, SpanStatusCode, trace } from "@opentelemetry/api";

const logger = new Logger("Tracing");

/**
 * Layer 2 — Service / Application layer tracing decorator.
 *
 * Wraps a service method in an OTel child span + structured log that records:
 *   - span name (defaults to ClassName.methodName)
 *   - execution duration
 *   - success or error outcome
 *
 * Preserves the original sync/async contract: async methods return a Promise,
 * synchronous methods return their value directly.
 *
 * Usage:
 *   @Traced()
 *   async getSummary(): Promise<...> { ... }
 *
 *   @Traced("OutcomesService.customOperation")
 *   getSomethingSync(): SomeDto { ... }
 *
 * When the OpenTelemetry SDK is active (see platform/telemetry/otel-sdk.ts),
 * this decorator will automatically create a child span under the active
 * HTTP trace context, giving full drill-down from API → Service layer.
 */
export function Traced(spanName?: string): MethodDecorator {
  return (
    target: object,
    propertyKey: string | symbol,
    descriptor: PropertyDescriptor,
  ) => {
    const originalMethod = descriptor.value as (...args: unknown[]) => unknown;
    const name = spanName ?? `${target.constructor.name}.${String(propertyKey)}`;

    descriptor.value = function (...args: unknown[]) {
      const start = Date.now();
      const tracer = trace.getTracer("flex-api");
      const span = tracer.startSpan(name, undefined, context.active());
      span.setAttribute("service.method", name);

      logger.log(`→ [${name}]`);

      let result: unknown;
      try {
        result = context.with(trace.setSpan(context.active(), span), () =>
          originalMethod.apply(this, args),
        );
      } catch (err) {
        const duration = Date.now() - start;
        const error = err as Error;
        span.recordException(error);
        span.setStatus({ code: SpanStatusCode.ERROR, message: error.message });
        span.end();
        logger.error(`← [${name}] status=error duration=${duration}ms error=${error.message}`);
        throw err;
      }

      if (result != null && typeof (result as Promise<unknown>).then === "function") {
        return (result as Promise<unknown>).then(
          (value) => {
            const duration = Date.now() - start;
            span.setStatus({ code: SpanStatusCode.OK });
            span.end();
            logger.log(`← [${name}] status=ok duration=${duration}ms`);
            return value;
          },
          (err: Error) => {
            const duration = Date.now() - start;
            span.recordException(err);
            span.setStatus({ code: SpanStatusCode.ERROR, message: err.message });
            span.end();
            logger.error(`← [${name}] status=error duration=${duration}ms error=${err.message}`);
            throw err;
          },
        );
      }

      const duration = Date.now() - start;
      span.setStatus({ code: SpanStatusCode.OK });
      span.end();
      logger.log(`← [${name}] status=ok duration=${duration}ms`);
      return result;
    };

    return descriptor;
  };
}
