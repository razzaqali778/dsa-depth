import { Traced } from "../traced.decorator";

class ExampleService {
  @Traced()
  async doWork(): Promise<string> {
    return "result";
  }

  @Traced("CustomSpan.operation")
  async doNamedWork(): Promise<number> {
    return 42;
  }

  @Traced()
  async failingWork(): Promise<never> {
    throw new Error("something went wrong");
  }

  @Traced()
  getSyncValue(): string {
    return "sync-result";
  }

  @Traced()
  failingSyncWork(): never {
    throw new Error("sync error");
  }
}

describe("Traced decorator", () => {
  let service: ExampleService;

  beforeEach(() => {
    service = new ExampleService();
  });

  it("should return the original method's result", async () => {
    const result = await service.doWork();
    expect(result).toBe("result");
  });

  it("should return the correct result when a custom span name is provided", async () => {
    const result = await service.doNamedWork();
    expect(result).toBe(42);
  });

  it("should re-throw errors thrown by the original async method", async () => {
    await expect(service.failingWork()).rejects.toThrow("something went wrong");
  });

  it("should preserve the method's return value across multiple calls", async () => {
    const first = await service.doWork();
    const second = await service.doWork();
    expect(first).toBe("result");
    expect(second).toBe("result");
  });

  it("should work with a custom span name that overrides the default", async () => {
    await expect(service.doNamedWork()).resolves.toBe(42);
  });

  it("should return a plain value (not a Promise) for synchronous methods", () => {
    const result = service.getSyncValue();
    expect(result).toBe("sync-result");
    expect(result).not.toBeInstanceOf(Promise);
  });

  it("should re-throw errors thrown by synchronous methods without wrapping in a Promise", () => {
    expect(() => service.failingSyncWork()).toThrow("sync error");
  });
});
