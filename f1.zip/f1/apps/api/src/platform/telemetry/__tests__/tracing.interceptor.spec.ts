import { context as otelContext, trace } from "@opentelemetry/api";
import { AsyncLocalStorageContextManager } from "@opentelemetry/context-async-hooks";
import { EMPTY, Observable, firstValueFrom, lastValueFrom, of, throwError } from "rxjs";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TracingInterceptor } from "../tracing.interceptor";

function makeContext(
  className: string,
  handlerName: string,
  user?: { id?: string },
) {
  return {
    getClass: () => ({ name: className }),
    getHandler: () => ({ name: handlerName }),
    switchToHttp: () => ({
      getRequest: () => ({ user }),
    }),
  };
}

function makeCallHandler<T>(observable: Observable<T>) {
  return { handle: () => observable };
}

function makeErrorHandler(error: Error) {
  return { handle: () => throwError(() => error) };
}

function makeControllerSpanMock() {
  return {
    setAttribute: vi.fn(),
    setStatus: vi.fn(),
    end: vi.fn(),
    recordException: vi.fn(),
    spanContext: () => ({ spanId: "controller-span", traceId: "trace-1" }),
  };
}

describe("TracingInterceptor", () => {
  let interceptor: TracingInterceptor;
  let contextManager: AsyncLocalStorageContextManager;

  beforeEach(() => {
    contextManager = new AsyncLocalStorageContextManager().enable();
    otelContext.setGlobalContextManager(contextManager);
    interceptor = new TracingInterceptor();
  });

  afterEach(() => {
    contextManager.disable();
    vi.restoreAllMocks();
  });

  it("passes through the observable returned by the handler", async () => {
    const context = makeContext("TestController", "getAll");
    const handler = makeCallHandler(of("response-value"));

    const result$ = interceptor.intercept(context as never, handler as never);

    await expect(firstValueFrom(result$)).resolves.toBe("response-value");
  });

  it("propagates errors from the handler observable", async () => {
    const context = makeContext("TestController", "getAll");
    const handler = makeErrorHandler(new Error("handler error"));

    const result$ = interceptor.intercept(context as never, handler as never);

    await expect(firstValueFrom(result$)).rejects.toThrow("handler error");
  });

  it("uses anonymous when no user is present in the request", async () => {
    const context = makeContext("TestController", "getAll");
    const handler = makeCallHandler(of("ok"));

    const result$ = interceptor.intercept(context as never, handler as never);

    await expect(firstValueFrom(result$)).resolves.toBe("ok");
  });

  it("uses the authenticated user id when present", async () => {
    const context = makeContext("TestController", "getAll", { id: "user-123" });
    const handler = makeCallHandler(of("ok"));

    const result$ = interceptor.intercept(context as never, handler as never);

    await expect(firstValueFrom(result$)).resolves.toBe("ok");
  });

  it("activates the controller span while the handler runs", async () => {
    const controllerSpan = makeControllerSpanMock();

    vi.spyOn(trace, "getTracer").mockReturnValue({
      startSpan: vi.fn().mockReturnValue(controllerSpan),
    } as never);

    let activeSpanDuringHandler: ReturnType<typeof trace.getSpan> | undefined;
    const context = makeContext("TestController", "getAll");
    const handler = {
      handle: () => {
        activeSpanDuringHandler = trace.getSpan(otelContext.active());
        return of("ok");
      },
    };

    await firstValueFrom(interceptor.intercept(context as never, handler as never));

    expect(activeSpanDuringHandler).toBe(controllerSpan);
  });

  it("ends the span on complete, not on the first emission", async () => {
    const controllerSpan = makeControllerSpanMock();

    vi.spyOn(trace, "getTracer").mockReturnValue({
      startSpan: vi.fn().mockReturnValue(controllerSpan),
    } as never);

    const context = makeContext("TestController", "stream");
    const handler = makeCallHandler(
      new Observable((subscriber) => {
        subscriber.next("first");
        subscriber.next("second");
        subscriber.complete();
      }),
    );

    await lastValueFrom(interceptor.intercept(context as never, handler as never));

    expect(controllerSpan.end).toHaveBeenCalledTimes(1);
  });

  it("ends the span when the handler observable completes without emitting", async () => {
    const controllerSpan = makeControllerSpanMock();

    vi.spyOn(trace, "getTracer").mockReturnValue({
      startSpan: vi.fn().mockReturnValue(controllerSpan),
    } as never);

    const context = makeContext("TestController", "empty");
    const handler = makeCallHandler(EMPTY);

    await firstValueFrom(interceptor.intercept(context as never, handler as never), {
      defaultValue: undefined,
    });

    expect(controllerSpan.end).toHaveBeenCalledTimes(1);
  });
});
