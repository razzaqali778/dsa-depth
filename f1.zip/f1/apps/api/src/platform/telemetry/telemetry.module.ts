import { Global, Module } from "@nestjs/common";
import { APP_INTERCEPTOR } from "@nestjs/core";
import { TracingInterceptor } from "./tracing.interceptor";

/**
 * Platform telemetry module — registered globally in AppModule.
 *
 * Provides:
 *   - TracingInterceptor as APP_INTERCEPTOR (Layer 1: API/Controller spans)
 *
 * The @Traced() decorator (Layer 2: Service spans) is applied per-method
 * in service classes — see platform/telemetry/traced.decorator.ts.
 *
 * OpenTelemetry SDK is initialised in main.ts via platform/telemetry/otel-sdk.ts
 * before NestJS bootstraps. Spans export to the local LGTM stack (make observability).
 */
@Global()
@Module({
  providers: [
    {
      provide: APP_INTERCEPTOR,
      useClass: TracingInterceptor,
    },
  ],
})
export class TelemetryModule {}
