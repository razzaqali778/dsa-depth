import type { Type } from "@nestjs/common";

export type SourceIntegrationDefinition = {
  sourceSystem: string;
  direction: "read-only" | "write-back-future";
  adapterBoundary: string;
  ownedByModule: boolean;
};

export type FlexModuleDefinition = {
  key: string;
  displayName: string;
  route: string;

  // ── Runtime bootstrap fields ──────────────────────────────────────────
  /** Reference to the NestJS @Module class — used by bootstrapModules() */
  nestModule: Type<unknown>;
  /** Feature flag — set to false to exclude from bootstrap without deleting code */
  enabled: boolean;

  // ── Database boundary ─────────────────────────────────────────────────
  databaseBoundary: string;
  databaseName: string;
  databaseUrlEnvVar: string;
  /** Max connections per worker thread for this module's Prisma pool (default: 5) */
  databasePoolSize?: number;

  // ── Module contract ───────────────────────────────────────────────────
  responsibilities: string[];
  sourceIntegrations: SourceIntegrationDefinition[];
  publishesEvents: string[];
  consumesEvents: string[];
};
