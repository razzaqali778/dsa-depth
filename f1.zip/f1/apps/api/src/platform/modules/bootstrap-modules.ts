import type { Type } from "@nestjs/common";
import { Logger } from "@nestjs/common";
import { FLEX_MODULE_CATALOG } from "./flex-module.catalog";
import type { FlexModuleDefinition } from "./flex-module.definition";

const logger = new Logger("ModuleBootstrap");

/**
 * Reads the FLEX_MODULE_CATALOG, logs each module's metadata at startup,
 * and returns the array of enabled NestJS module classes to be spread into
 * AppModule's imports array.
 *
 * To disable a module without deleting code, set `enabled: false` in its
 * *.definition.ts file.
 */
export function bootstrapModules(): Type<unknown>[] {
  const modules: Type<unknown>[] = [];

  for (const [key, definition] of Object.entries(FLEX_MODULE_CATALOG) as [string, FlexModuleDefinition][]) {
    if (!definition.enabled) {
      logger.warn(`✗ Skipped disabled module: ${definition.displayName} [${key}]`);
      continue;
    }

    logger.log(`✓ Registering module: ${definition.displayName} [${key}]`);
    logger.log(`  → Route:      ${definition.route}`);
    logger.log(`  → Database:   ${definition.databaseName} (${definition.databaseUrlEnvVar})`);
    logger.log(`  → Pool size:  ${definition.databasePoolSize ?? 5} connections/worker`);
    logger.log(`  → Publishes:  ${definition.publishesEvents.join(", ") || "none"}`);
    logger.log(`  → Consumes:   ${definition.consumesEvents.join(", ") || "none"}`);

    modules.push(definition.nestModule);
  }

  logger.log(`Bootstrap complete: ${modules.length} module(s) registered`);
  return modules;
}
