import type { FlexModuleDefinition } from "./flex-module.definition";
import { authDefinition } from "../../modules/auth/auth.definition";

// Module definitions are registered here by the generator (scripts/create-flex-module.sh).
export const FLEX_MODULE_CATALOG: Record<string, FlexModuleDefinition> = {
  "auth": authDefinition,
};

export function getFlexModuleDefinition(moduleKey: string) {
  return FLEX_MODULE_CATALOG[moduleKey];
}
