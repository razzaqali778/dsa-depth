import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "../../model/use-auth";

export function ProtectedRoute() {
  const { status } = useAuth();

  if (status === "idle" || status === "loading") {
    return (
      <div className="auth-screen auth-screen-inline">
        <div className="auth-card auth-card-compact">
          <h1>Loading FLEX</h1>
          <p className="auth-copy">Checking your workspace session.</p>
        </div>
      </div>
    );
  }

  if (status !== "authenticated") {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
}
