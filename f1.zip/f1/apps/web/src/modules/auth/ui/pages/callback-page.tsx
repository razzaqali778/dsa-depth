import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAppDispatch } from "../../../../app/store/hooks";
import { verifySession } from "../../client/api/auth.api";
import { oidcClient } from "../../client/oidc/oidc-client";
import { sessionEstablished } from "../../model/state/auth.slice";
import type { AuthSession } from "../../model/types/auth.types";

const callbackRequests = new Map<string, Promise<AuthSession>>();

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Sign-in failed";
}

function completeRedirectOnce(search: string): Promise<AuthSession> {
  const existing = callbackRequests.get(search);
  if (existing) {
    return existing;
  }

  const request = (async () => {
    await oidcClient.handleRedirect(new URLSearchParams(search));
    return verifySession();
  })();

  callbackRequests.set(search, request);
  return request;
}

/** Completes the OIDC redirect: exchanges the code, establishes the session. */
export function CallbackPage() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [error, setError] = useState<string | undefined>();

  useEffect(() => {
    let active = true;

    async function complete() {
      try {
        const session = await completeRedirectOnce(globalThis.location.search);
        if (active) {
          dispatch(sessionEstablished(session));
          navigate("/", { replace: true });
        }
      } catch (cause) {
        if (active) {
          setError(errorMessage(cause));
        }
      }
    }

    void complete();
    return () => {
      active = false;
    };
  }, [dispatch, navigate]);

  return (
    <div className="auth-screen">
      <div className="auth-card">
        {error ? (
          <>
            <h1>Sign-in failed</h1>
            <p role="alert" className="auth-error">
              {error}
            </p>
            <button type="button" className="auth-primary" onClick={() => navigate("/login")}>
              Back to sign in
            </button>
          </>
        ) : (
          <>
            <h1>Signing you in…</h1>
            <p className="auth-copy">Completing authentication with Microsoft Entra.</p>
          </>
        )}
      </div>
    </div>
  );
}
