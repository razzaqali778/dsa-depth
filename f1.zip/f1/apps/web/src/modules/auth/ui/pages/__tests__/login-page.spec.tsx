import { vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import { LoginPage } from "../login-page";
import { useAuth } from "../../../model/use-auth";
import { isOidcConfigured } from "../../../client/oidc/oidc-config";

const navigate = vi.fn();

vi.mock("../../../model/use-auth", () => ({ useAuth: vi.fn() }));
vi.mock("../../../client/oidc/oidc-config", () => ({ isOidcConfigured: vi.fn() }));
vi.mock("react-router-dom", async (importOriginal) => ({
  ...(await importOriginal<typeof import("react-router-dom")>()),
  useNavigate: () => navigate,
}));

const login = vi.fn();

function mockAuth(overrides: Partial<ReturnType<typeof useAuth>> = {}) {
  vi.mocked(useAuth).mockReturnValue({
    status: "unauthenticated",
    user: undefined,
    permissions: [],
    error: undefined,
    isAuthenticated: false,
    login,
    logout: vi.fn(),
    refresh: vi.fn(),
    ...overrides,
  });
}

describe("LoginPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockAuth();
    vi.mocked(isOidcConfigured).mockReturnValue(false);
  });

  it("shows the dev-mode call to action when OIDC is not configured", () => {
    render(<LoginPage />);
    expect(screen.getByLabelText("Bayer")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Continue to FLEX/ })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: /Sign in to Flex/ })).toBeInTheDocument();
  });

  it("shows the Microsoft sign-in when OIDC is configured", () => {
    vi.mocked(isOidcConfigured).mockReturnValue(true);
    render(<LoginPage />);
    expect(screen.getByRole("button", { name: /Continue with Microsoft/ })).toBeInTheDocument();
  });

  it("shows the busy label and disables the button while signing in", () => {
    mockAuth({ status: "loading" });
    render(<LoginPage />);

    expect(screen.getByRole("button", { name: /Signing in/i })).toBeDisabled();
  });

  it("triggers login on click", () => {
    render(<LoginPage />);
    fireEvent.click(screen.getByRole("button"));
    expect(login).toHaveBeenCalled();
  });

  it("renders an error message", () => {
    mockAuth({ error: "Something failed", status: "error" });
    render(<LoginPage />);
    expect(screen.getByRole("alert")).toHaveTextContent("Something failed");
  });

  it("redirects home when already authenticated", () => {
    mockAuth({ isAuthenticated: true });
    render(<LoginPage />);
    expect(navigate).toHaveBeenCalledWith("/", { replace: true });
  });
});
