import { configureStore } from "@reduxjs/toolkit";
import { render, screen } from "@testing-library/react";
import { Provider } from "react-redux";
import { vi } from "vitest";
import { AuthPage } from "../auth-page";
import { authReducer } from "../../../model/state/auth.slice";
import { isOidcConfigured } from "../../../client/oidc/oidc-config";

vi.mock("../../../client/oidc/oidc-config", () => ({ isOidcConfigured: vi.fn() }));

function renderPage(preloadedState?: {
  auth?: {
    status: "idle" | "loading" | "authenticated" | "unauthenticated" | "error";
    permissions: string[];
    user?: {
      id: string;
      email: string;
      name: string;
      role: string;
      authProvider: "local" | "azure";
      isActive: boolean;
      createdAt: string;
      updatedAt: string;
      lastLoginAt: string | null;
    };
    error?: string;
  };
}) {
  const store = configureStore({
    reducer: { auth: authReducer },
    preloadedState,
  });

  return render(
    <Provider store={store}>
      <AuthPage />
    </Provider>,
  );
}

describe("AuthPage", () => {
  beforeEach(() => {
    vi.mocked(isOidcConfigured).mockReturnValue(false);
  });

  it("renders the workspace access overview", () => {
    renderPage();

    expect(screen.getByRole("heading", { name: "Workspace access" })).toBeInTheDocument();
    expect(screen.getByText("idle")).toBeInTheDocument();
    expect(screen.getByText("No permissions resolved for this session.")).toBeInTheDocument();
    expect(screen.getByText("No sign-in recorded")).toBeInTheDocument();
    expect(screen.getByText("Local development identity")).toBeInTheDocument();
  });

  it("renders authenticated user details, formatted sign-in date, and permissions", () => {
    vi.mocked(isOidcConfigured).mockReturnValue(true);

    renderPage({
      auth: {
        status: "authenticated",
        permissions: ["view_users", "assign_roles"],
        user: {
          id: "user-1",
          email: "sam@bayer.com",
          name: "Sam",
          role: "Admin",
          authProvider: "azure",
          isActive: true,
          createdAt: "2026-07-05T16:00:00.000Z",
          updatedAt: "2026-07-05T16:00:00.000Z",
          lastLoginAt: "2026-07-05T17:00:00.000Z",
        },
      },
    });

    expect(screen.getByText("Microsoft Entra ID")).toBeInTheDocument();
    expect(screen.getByText("Sam")).toBeInTheDocument();
    expect(screen.getByText("sam@bayer.com")).toBeInTheDocument();
    expect(screen.getByText("Admin")).toBeInTheDocument();
    expect(screen.getByText(/Jul/)).toBeInTheDocument();
    expect(screen.getByText("view_users")).toBeInTheDocument();
    expect(screen.getByText("assign_roles")).toBeInTheDocument();
  });
});
