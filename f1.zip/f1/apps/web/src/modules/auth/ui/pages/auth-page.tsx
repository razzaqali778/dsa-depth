import { KeyRound, ShieldCheck, UserRound } from "lucide-react";
import { isOidcConfigured } from "../../client/oidc/oidc-config";
import { useAuth } from "../../model/use-auth";

export function AuthPage() {
  const { permissions, status, user } = useAuth();
  const authModeLabel = isOidcConfigured() ? "Microsoft Entra ID" : "Local development identity";

  return (
    <section className="page-stack auth-overview-page">
      <div className="auth-overview-hero">
        <span className="eyebrow">Workspace</span>
        <h1>Workspace access</h1>
        <p className="page-copy">
          FLEX is using {authModeLabel}. Your authenticated session and resolved permissions are
          shown below.
        </p>
      </div>

      <div className="auth-overview-grid">
        <article className="auth-overview-card">
          <div className="auth-overview-card-header">
            <ShieldCheck size={18} />
            <h2>Session</h2>
          </div>
          <dl className="auth-overview-details">
            <div>
              <dt>Status</dt>
              <dd>{status}</dd>
            </div>
            <div>
              <dt>Provider</dt>
              <dd>{authModeLabel}</dd>
            </div>
            <div>
              <dt>Last sign-in</dt>
              <dd>{formatDate(user?.lastLoginAt)}</dd>
            </div>
          </dl>
        </article>

        <article className="auth-overview-card">
          <div className="auth-overview-card-header">
            <UserRound size={18} />
            <h2>Identity</h2>
          </div>
          <dl className="auth-overview-details">
            <div>
              <dt>Name</dt>
              <dd>{user?.name ?? "Unknown user"}</dd>
            </div>
            <div>
              <dt>Email</dt>
              <dd>{user?.email ?? "Unavailable"}</dd>
            </div>
            <div>
              <dt>Role</dt>
              <dd>{user?.role ?? "Not assigned"}</dd>
            </div>
          </dl>
        </article>

        <article className="auth-overview-card">
          <div className="auth-overview-card-header">
            <KeyRound size={18} />
            <h2>Permissions</h2>
          </div>
          <div className="auth-permission-list">
            {permissions.length > 0 ? (
              permissions.map((permission) => (
                <span key={permission} className="tag-pill auth-permission-pill">
                  {permission}
                </span>
              ))
            ) : (
              <p className="muted-text">No permissions resolved for this session.</p>
            )}
          </div>
        </article>
      </div>
    </section>
  );
}

function formatDate(value: string | null | undefined): string {
  if (!value) {
    return "No sign-in recorded";
  }

  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}
