import { describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { ProtectedRoute } from "../protected-route";
import { useAuth } from "../../../model/use-auth";

vi.mock("../../../model/use-auth", () => ({ useAuth: vi.fn() }));

function mockAuth(status: ReturnType<typeof useAuth>["status"]) {
  vi.mocked(useAuth).mockReturnValue({
    status,
    user: undefined,
    permissions: [],
    error: undefined,
    isAuthenticated: status === "authenticated",
    login: vi.fn(),
    logout: vi.fn(),
    refresh: vi.fn(),
  });
}

describe("ProtectedRoute", () => {
  it("shows the loading screen while auth is resolving", () => {
    mockAuth("loading");

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route element={<ProtectedRoute />}>
            <Route index element={<div>Workspace</div>} />
          </Route>
        </Routes>
      </MemoryRouter>,
    );

    expect(screen.getByRole("heading", { name: "Loading FLEX" })).toBeInTheDocument();
  });

  it("redirects unauthenticated users to login", () => {
    mockAuth("unauthenticated");

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route element={<ProtectedRoute />}>
            <Route index element={<div>Workspace</div>} />
          </Route>
          <Route path="/login" element={<div>Login screen</div>} />
        </Routes>
      </MemoryRouter>,
    );

    expect(screen.getByText("Login screen")).toBeInTheDocument();
  });

  it("renders child routes for authenticated users", () => {
    mockAuth("authenticated");

    render(
      <MemoryRouter initialEntries={["/"]}>
        <Routes>
          <Route element={<ProtectedRoute />}>
            <Route index element={<div>Workspace</div>} />
          </Route>
        </Routes>
      </MemoryRouter>,
    );

    expect(screen.getByText("Workspace")).toBeInTheDocument();
  });
});
