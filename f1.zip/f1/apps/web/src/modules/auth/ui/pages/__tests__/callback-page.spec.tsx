import { vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import { StrictMode } from "react";
import { CallbackPage } from "../callback-page";
import { oidcClient } from "../../../client/oidc/oidc-client";
import * as api from "../../../client/api/auth.api";
import type { AuthSession } from "../../../model/types/auth.types";

const navigate = vi.fn();
const dispatch = vi.fn();
let runId = 0;

vi.mock("../../../client/oidc/oidc-client", () => ({
  oidcClient: { handleRedirect: vi.fn() },
}));
vi.mock("../../../client/api/auth.api");
vi.mock("../../../../../app/store/hooks", () => ({ useAppDispatch: () => dispatch }));
vi.mock("react-router-dom", async (importOriginal) => ({
  ...(await importOriginal<typeof import("react-router-dom")>()),
  useNavigate: () => navigate,
}));

const session: AuthSession = {
  user: {
    id: "u1",
    email: "user@flex",
    name: "User One",
    role: "Admin",
    isActive: true,
    authProvider: "azure",
    lastLoginAt: null,
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z",
  },
  permissions: ["view_dashboard"],
};

describe("CallbackPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    window.sessionStorage.clear();
    runId += 1;
    window.history.replaceState({}, "", `/auth/callback?test=${runId}`);
  });

  it("completes the redirect and navigates home", async () => {
    vi.mocked(oidcClient.handleRedirect).mockResolvedValue("token");
    vi.mocked(api.verifySession).mockResolvedValue(session);

    render(<CallbackPage />);

    expect(screen.getByText(/Signing you in/)).toBeInTheDocument();
    await waitFor(() => expect(navigate).toHaveBeenCalledWith("/", { replace: true }));
    expect(dispatch).toHaveBeenCalled();
  });

  it("shows an error when the exchange fails", async () => {
    vi.mocked(oidcClient.handleRedirect).mockRejectedValue(new Error("bad state"));

    render(<CallbackPage />);

    await waitFor(() => expect(screen.getByRole("alert")).toHaveTextContent("bad state"));
  });

  it("only handles the redirect once under StrictMode", async () => {
    vi.mocked(oidcClient.handleRedirect).mockResolvedValue("token");
    vi.mocked(api.verifySession).mockResolvedValue(session);
    window.history.replaceState({}, "", "/auth/callback?code=test-code&state=test-state");

    render(
      <StrictMode>
        <CallbackPage />
      </StrictMode>,
    );

    await waitFor(() => expect(navigate).toHaveBeenCalledWith("/", { replace: true }));
    expect(oidcClient.handleRedirect).toHaveBeenCalledTimes(1);
    expect(api.verifySession).toHaveBeenCalledTimes(1);
  });
});
