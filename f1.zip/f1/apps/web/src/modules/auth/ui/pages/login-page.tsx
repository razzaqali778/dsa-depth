import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../model/use-auth";
import { isOidcConfigured } from "../../client/oidc/oidc-config";

export function LoginPage() {
  const { login, status, error, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const oidc = isOidcConfigured();
  const isBusy = status === "loading";
  let buttonLabel = "Continue to FLEX";
  if (isBusy) {
    buttonLabel = "Signing in...";
  } else if (oidc) {
    buttonLabel = "Continue with Microsoft";
  }

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/", { replace: true });
    }
  }, [isAuthenticated, navigate]);

  return (
    <div className="auth-screen">
      <main className="login-panel" aria-labelledby="login-heading">
        <div className="bayer-orb" aria-label="Bayer">
          <span className="bayer-orb-word bayer-orb-word-horizontal" data-text="BAYER" aria-hidden="true" />
          <span className="bayer-orb-word bayer-orb-word-vertical" data-text="BAYER" aria-hidden="true" />
        </div>
        <h1 id="login-heading">
          Sign in to <span>Flex</span>
        </h1>
        <p className="login-subtitle">Enterprise workspace via Microsoft Azure</p>
        {error ? (
          <p role="alert" className="auth-error">
            {error}
          </p>
        ) : null}

        <div className="login-action-frame">
          <button type="button" className="auth-primary microsoft-button" onClick={() => void login()} disabled={isBusy}>
            <span className="microsoft-mark" aria-hidden="true">
              <span />
              <span />
              <span />
              <span />
            </span>
            {buttonLabel}
          </button>
        </div>

        <footer className="login-footer">
          <nav aria-label="Legal">
            <a href="/terms">Terms</a>
            <span aria-hidden="true">.</span>
            <a href="/privacy">Privacy</a>
            <span aria-hidden="true">.</span>
            <a href="/security">Security</a>
          </nav>
          <p>{"\u00A9"} 2026 Flex Inc.</p>
        </footer>
      </main>
    </div>
  );
}
