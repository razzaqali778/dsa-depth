import { useEffect, type ReactNode } from "react";
import { setAuthTokenProvider } from "../../../../shared/http/api-client";
import { useAppDispatch } from "../../../../app/store/hooks";
import { sessionCleared, sessionEstablished } from "../../model/state/auth.slice";
import { sessionStore } from "../../client/oidc/session-store";
import { isOidcConfigured } from "../../client/oidc/oidc-config";
import { useAuth } from "../../model/use-auth";
import type { AuthSession } from "../../model/types/auth.types";

// Attach the stored bearer token to every API request.
setAuthTokenProvider(() => sessionStore.getAccessToken());

type AuthProviderProps = {
  readonly children: ReactNode;
};

const DEV_AUTH_SESSION: AuthSession = {
  user: {
    id: "dev-user",
    email: "dev.user@flex.local",
    name: "Dev User",
    role: "Admin",
    isActive: true,
    authProvider: "local",
    lastLoginAt: null,
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z",
  },
  permissions: ["view_dashboard", "view_users", "manage_users", "assign_roles", "view_audit"],
};

function isAuthDisabled(): boolean {
  return import.meta.env.VITE_AUTH_DISABLED === "true";
}

/** Bootstraps the session on mount so route guards have a resolved identity. */
export function AuthProvider({ children }: AuthProviderProps) {
  const dispatch = useAppDispatch();
  const { refresh } = useAuth();

  useEffect(() => {
    if (globalThis.window?.location.pathname === "/auth/callback") {
      return;
    }

    if (isAuthDisabled()) {
      dispatch(sessionEstablished(DEV_AUTH_SESSION));
      return;
    }

    if (sessionStore.getAccessToken() !== null || !isOidcConfigured()) {
      void refresh();
      return;
    }

    dispatch(sessionCleared());
  }, [dispatch, refresh]);

  return <>{children}</>;
}
