import { vi } from "vitest";
import { configureStore } from "@reduxjs/toolkit";
import { render, screen, waitFor } from "@testing-library/react";
import { Provider } from "react-redux";
import { AuthProvider } from "../auth-provider";
import { authReducer } from "../../../model/state/auth.slice";
import * as api from "../../../client/api/auth.api";
import type { AuthSession } from "../../../model/types/auth.types";

vi.mock("../../../client/api/auth.api");

const session: AuthSession = {
  user: {
    id: "u1",
    email: "user@flex",
    name: "User One",
    role: "Admin",
    isActive: true,
    authProvider: "local",
    lastLoginAt: null,
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z",
  },
  permissions: ["view_dashboard"],
};

describe("AuthProvider", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.stubEnv("VITE_AUTH_DISABLED", "");
    vi.stubEnv("VITE_AZURE_CLIENT_ID", "");
    vi.stubEnv("VITE_AZURE_TENANT_ID", "");
    vi.stubEnv("VITE_AZURE_API_SCOPE", "");
    vi.stubEnv("VITE_AZURE_REDIRECT_URI", "");
    vi.mocked(api.getMe).mockResolvedValue(session);
  });

  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("bootstraps the session and renders children", async () => {
    const store = configureStore({ reducer: { auth: authReducer } });

    render(
      <Provider store={store}>
        <AuthProvider>
          <span>App content</span>
        </AuthProvider>
      </Provider>,
    );

    expect(screen.getByText("App content")).toBeInTheDocument();
    await waitFor(() => expect(api.getMe).toHaveBeenCalled());
    await waitFor(() => expect(store.getState().auth.status).toBe("authenticated"));
  });

  it("skips bootstrapping on the OIDC callback route", async () => {
    window.history.replaceState({}, "", "/auth/callback");
    const store = configureStore({ reducer: { auth: authReducer } });

    render(
      <Provider store={store}>
        <AuthProvider>
          <span>Callback content</span>
        </AuthProvider>
      </Provider>,
    );

    expect(screen.getByText("Callback content")).toBeInTheDocument();
    await waitFor(() => expect(api.getMe).not.toHaveBeenCalled());
    expect(store.getState().auth.status).toBe("idle");
    window.history.replaceState({}, "", "/");
  });

  it("establishes a local dev session when auth is disabled", async () => {
    vi.stubEnv("VITE_AUTH_DISABLED", "true");
    const store = configureStore({ reducer: { auth: authReducer } });

    render(
      <Provider store={store}>
        <AuthProvider>
          <span>Dev content</span>
        </AuthProvider>
      </Provider>,
    );

    expect(screen.getByText("Dev content")).toBeInTheDocument();
    await waitFor(() => expect(store.getState().auth.status).toBe("authenticated"));
    expect(api.getMe).not.toHaveBeenCalled();
    expect(store.getState().auth.user?.email).toBe("dev.user@flex.local");
  });
});
