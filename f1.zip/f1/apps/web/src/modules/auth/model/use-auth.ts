import { useCallback } from "react";
import { useAppDispatch, useAppSelector } from "../../../app/store/hooks";
import { getMe, verifySession } from "../client/api/auth.api";
import { oidcClient } from "../client/oidc/oidc-client";
import {
  sessionCleared,
  sessionEstablished,
  sessionFailed,
  sessionLoading,
} from "./state/auth.slice";

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "Authentication failed";
}

export function useAuth() {
  const dispatch = useAppDispatch();
  const state = useAppSelector((store) => store.auth);

  const refresh = useCallback(async () => {
    dispatch(sessionLoading());
    try {
      dispatch(sessionEstablished(await getMe()));
    } catch {
      dispatch(sessionCleared());
    }
  }, [dispatch]);

  const login = useCallback(async () => {
    dispatch(sessionLoading());
    try {
      if (oidcClient.isConfigured()) {
        await oidcClient.login();
        return;
      }
      dispatch(sessionEstablished(await verifySession()));
    } catch (error) {
      dispatch(sessionFailed(errorMessage(error)));
    }
  }, [dispatch]);

  const logout = useCallback(() => {
    oidcClient.logout();
    dispatch(sessionCleared());
  }, [dispatch]);

  return {
    status: state.status,
    user: state.user,
    permissions: state.permissions,
    error: state.error,
    isAuthenticated: state.status === "authenticated",
    login,
    logout,
    refresh,
  };
}
