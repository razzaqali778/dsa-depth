export type AuthSourceIntegration = {
  sourceSystem: string;
  direction: "read-only" | "write-back-future";
  adapterBoundary: string;
  ownedByModule: boolean;
};

export type AuthSummary = {
  module: string;
  displayName: string;
  route: string;
  responsibilities: string[];
  sourceIntegrations: AuthSourceIntegration[];
  databaseBoundary: string;
  databaseName: string;
  databaseUrlEnvVar: string;
  publishesEvents: string[];
  consumesEvents: string[];
  currentPhase: string;
};

export const ROLE_OPTIONS = ["Admin", "Platform Lead", "User"] as const;
export type Role = (typeof ROLE_OPTIONS)[number];

export const PERMISSION_OPTIONS = [
  "view_dashboard",
  "view_users",
  "manage_users",
  "assign_roles",
  "view_audit",
] as const;
export type Permission = (typeof PERMISSION_OPTIONS)[number];

export type AuthUser = {
  id: string;
  email: string;
  name: string;
  role: Role;
  isActive: boolean;
  authProvider: "local" | "azure";
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
};

export type AuthSession = {
  user: AuthUser;
  permissions: Permission[];
};

export type AuthStatus = "idle" | "loading" | "authenticated" | "unauthenticated" | "error";

export type AuthState = {
  status: AuthStatus;
  user?: AuthUser;
  permissions: Permission[];
  error?: string;
};
