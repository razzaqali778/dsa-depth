import { createSlice, type PayloadAction } from "@reduxjs/toolkit";
import type { AuthSession, AuthState } from "../types/auth.types";

const initialState: AuthState = {
  status: "idle",
  permissions: [],
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    sessionLoading: (state) => {
      state.status = "loading";
      state.error = undefined;
    },
    sessionEstablished: (state, action: PayloadAction<AuthSession>) => {
      state.status = "authenticated";
      state.user = action.payload.user;
      state.permissions = action.payload.permissions;
      state.error = undefined;
    },
    sessionCleared: (state) => {
      state.status = "unauthenticated";
      state.user = undefined;
      state.permissions = [];
      state.error = undefined;
    },
    sessionFailed: (state, action: PayloadAction<string>) => {
      state.status = "error";
      state.user = undefined;
      state.permissions = [];
      state.error = action.payload;
    },
  },
});

export const { sessionLoading, sessionEstablished, sessionCleared, sessionFailed } =
  authSlice.actions;
export const authReducer = authSlice.reducer;
