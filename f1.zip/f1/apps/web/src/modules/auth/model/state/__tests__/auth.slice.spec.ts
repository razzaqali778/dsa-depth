import { describe, expect, it } from "vitest";
import type { AuthSession } from "../../types/auth.types";
import {
  authReducer,
  sessionCleared,
  sessionEstablished,
  sessionFailed,
  sessionLoading,
} from "../auth.slice";

describe("authReducer", () => {
  it("handles the auth lifecycle", () => {
    const session: AuthSession = {
      user: {
        id: "u1",
        email: "user@flex",
        name: "User One",
        role: "Admin" as const,
        isActive: true,
        authProvider: "azure" as const,
        lastLoginAt: null,
        createdAt: "2026-01-01T00:00:00.000Z",
        updatedAt: "2026-01-01T00:00:00.000Z",
      },
      permissions: ["view_dashboard"],
    };

    const loading = authReducer(undefined, sessionLoading());
    expect(loading).toMatchObject({ status: "loading", permissions: [], error: undefined });

    const established = authReducer(loading, sessionEstablished(session));
    expect(established).toMatchObject({
      status: "authenticated",
      user: session.user,
      permissions: ["view_dashboard"],
      error: undefined,
    });

    const failed = authReducer(established, sessionFailed("boom"));
    expect(failed).toMatchObject({
      status: "error",
      user: undefined,
      permissions: [],
      error: "boom",
    });

    const cleared = authReducer(failed, sessionCleared());
    expect(cleared).toMatchObject({
      status: "unauthenticated",
      user: undefined,
      permissions: [],
      error: undefined,
    });
  });
});
