import { vi } from "vitest";
import { configureStore } from "@reduxjs/toolkit";
import { act, renderHook } from "@testing-library/react";
import { Provider } from "react-redux";
import type { ReactNode } from "react";
import { useAuth } from "../use-auth";
import { authReducer } from "../state/auth.slice";
import * as api from "../../client/api/auth.api";
import { oidcClient } from "../../client/oidc/oidc-client";
import type { AuthSession } from "../types/auth.types";

vi.mock("../../client/api/auth.api");
vi.mock("../../client/oidc/oidc-client", () => ({
  oidcClient: { isConfigured: vi.fn(), login: vi.fn(), logout: vi.fn() },
}));

const session: AuthSession = {
  user: {
    id: "u1",
    email: "user@flex",
    name: "User One",
    role: "Admin",
    isActive: true,
    authProvider: "local",
    lastLoginAt: null,
    createdAt: "2026-01-01T00:00:00.000Z",
    updatedAt: "2026-01-01T00:00:00.000Z",
  },
  permissions: ["manage_users"],
};

function wrapper({ children }: { children: ReactNode }) {
  const store = configureStore({ reducer: { auth: authReducer } });
  return <Provider store={store}>{children}</Provider>;
}

describe("useAuth", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("establishes a session on refresh", async () => {
    vi.mocked(api.getMe).mockResolvedValue(session);
    const { result } = renderHook(() => useAuth(), { wrapper });

    await act(async () => {
      await result.current.refresh();
    });

    expect(result.current.isAuthenticated).toBe(true);
    expect(result.current.user?.name).toBe("User One");
  });

  it("clears the session when refresh fails", async () => {
    vi.mocked(api.getMe).mockRejectedValue(new Error("401"));
    const { result } = renderHook(() => useAuth(), { wrapper });

    await act(async () => {
      await result.current.refresh();
    });

    expect(result.current.status).toBe("unauthenticated");
  });

  it("logs in via the API in dev mode", async () => {
    vi.mocked(oidcClient.isConfigured).mockReturnValue(false);
    vi.mocked(api.verifySession).mockResolvedValue(session);
    const { result } = renderHook(() => useAuth(), { wrapper });

    await act(async () => {
      await result.current.login();
    });

    expect(api.verifySession).toHaveBeenCalled();
    expect(result.current.isAuthenticated).toBe(true);
  });

  it("redirects to Entra when OIDC is configured", async () => {
    vi.mocked(oidcClient.isConfigured).mockReturnValue(true);
    vi.mocked(oidcClient.login).mockResolvedValue();
    const { result } = renderHook(() => useAuth(), { wrapper });

    await act(async () => {
      await result.current.login();
    });

    expect(oidcClient.login).toHaveBeenCalled();
    expect(api.verifySession).not.toHaveBeenCalled();
  });

  it("records an error when login fails", async () => {
    vi.mocked(oidcClient.isConfigured).mockReturnValue(false);
    vi.mocked(api.verifySession).mockRejectedValue(new Error("boom"));
    const { result } = renderHook(() => useAuth(), { wrapper });

    await act(async () => {
      await result.current.login();
    });

    expect(result.current.status).toBe("error");
    expect(result.current.error).toBe("boom");
  });

  it("logs out and clears the session", () => {
    const { result } = renderHook(() => useAuth(), { wrapper });

    act(() => {
      result.current.logout();
    });

    expect(oidcClient.logout).toHaveBeenCalled();
    expect(result.current.status).toBe("unauthenticated");
  });
});
