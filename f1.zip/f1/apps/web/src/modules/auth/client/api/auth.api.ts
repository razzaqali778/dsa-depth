import { apiGatewayClient } from "../../../../shared/http/api-client";
import type {
  AuthSession,
  AuthSummary,
} from "../../model/types/auth.types";

export function getAuthSummary(signal?: AbortSignal) {
  return apiGatewayClient.get<AuthSummary>("/auth/summary", { signal });
}

export function verifySession(signal?: AbortSignal) {
  return apiGatewayClient.post<AuthSession>("/auth/verify", undefined, { signal });
}

export function getMe(signal?: AbortSignal) {
  return apiGatewayClient.get<AuthSession>("/auth/me", { signal });
}
