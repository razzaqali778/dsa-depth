/** PKCE (RFC 7636) helpers built on the Web Crypto API. */

export function base64UrlEncode(bytes: ArrayBuffer | Uint8Array): string {
  const view = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let binary = "";
  for (const byte of view) {
    binary += String.fromCodePoint(byte);
  }

  let encoded = btoa(binary).replaceAll("+", "-").replaceAll("/", "_");
  while (encoded.endsWith("=")) {
    encoded = encoded.slice(0, -1);
  }

  return encoded;
}

/** Cryptographically-random URL-safe string of the given byte length. */
export function randomUrlSafeString(byteLength = 32): string {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return base64UrlEncode(bytes);
}

/** Derives the S256 code challenge for a PKCE verifier. */
export async function deriveCodeChallenge(verifier: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier));
  return base64UrlEncode(digest);
}

export type PkcePair = {
  verifier: string;
  challenge: string;
  state: string;
};

export async function createPkcePair(): Promise<PkcePair> {
  const verifier = randomUrlSafeString(48);
  const challenge = await deriveCodeChallenge(verifier);
  const state = randomUrlSafeString(16);
  return { verifier, challenge, state };
}
