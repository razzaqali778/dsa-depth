import { vi } from "vitest";
import {
  buildAuthorizeUrl,
  exchangeCodeForToken,
  oidcClient,
} from "../oidc-client";
import type { OidcConfig } from "../oidc-config";
import { sessionStore } from "../session-store";

const config: OidcConfig = {
  clientId: "client-1",
  tenantId: "tenant-1",
  apiScope: "api://flex/access",
  redirectUri: "https://flex.bayer/auth/callback",
  authorizeEndpoint: "https://login.test/authorize",
  tokenEndpoint: "https://login.test/token",
  logoutEndpoint: "https://login.test/logout",
};

function configureEnv() {
  vi.stubEnv("VITE_AZURE_CLIENT_ID", "client-1");
  vi.stubEnv("VITE_AZURE_TENANT_ID", "tenant-1");
  vi.stubEnv("VITE_AZURE_API_SCOPE", "api://flex/access");
  vi.stubEnv("VITE_AZURE_REDIRECT_URI", "https://flex.bayer/auth/callback");
}

function clearEnv() {
  vi.stubEnv("VITE_AZURE_CLIENT_ID", "");
  vi.stubEnv("VITE_AZURE_TENANT_ID", "");
  vi.stubEnv("VITE_AZURE_API_SCOPE", "");
  vi.stubEnv("VITE_AZURE_REDIRECT_URI", "");
}

function tokenResponse(token: string, ok = true) {
  return { ok, status: ok ? 200 : 400, json: async () => ({ access_token: token }) } as Response;
}

describe("oidc-client", () => {
  beforeEach(() => {
    window.sessionStorage.clear();
    clearEnv();
  });

  afterEach(() => {
    vi.unstubAllEnvs();
    vi.restoreAllMocks();
  });

  it("builds an authorize url with PKCE parameters", () => {
    const url = buildAuthorizeUrl(config, { challenge: "chal", state: "st" });
    expect(url).toContain("https://login.test/authorize?");
    expect(url).toContain("client_id=client-1");
    expect(url).toContain("code_challenge=chal");
    expect(url).toContain("code_challenge_method=S256");
    expect(url).toContain("state=st");
    expect(url).toContain("scope=openid+profile+email+api");
  });

  it("exchanges an authorization code for a token", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(tokenResponse("access-1"));
    const token = await exchangeCodeForToken(config, { code: "c", verifier: "v" }, fetchImpl);
    expect(token).toBe("access-1");
    expect(fetchImpl).toHaveBeenCalledWith(config.tokenEndpoint, expect.objectContaining({ method: "POST" }));
  });

  it("throws when the token exchange fails", async () => {
    const fetchImpl = vi.fn().mockResolvedValue(tokenResponse("", false));
    await expect(exchangeCodeForToken(config, { code: "c", verifier: "v" }, fetchImpl)).rejects.toThrow(
      "Token exchange failed",
    );
  });

  it("reports configuration state from the environment", () => {
    expect(oidcClient.isConfigured()).toBe(false);
    configureEnv();
    expect(oidcClient.isConfigured()).toBe(true);
  });

  it("redirects to Entra on login", async () => {
    configureEnv();
    const assign = vi.fn();
    vi.spyOn(window, "location", "get").mockReturnValue({
      ...window.location,
      assign,
    } as Location);

    await oidcClient.login();

    expect(assign).toHaveBeenCalledTimes(1);
    expect(String(assign.mock.calls[0][0])).toContain("/authorize?");
    expect(sessionStore.takePkce()).not.toBeNull();
  });

  it("completes the redirect by exchanging the code", async () => {
    configureEnv();
    sessionStore.savePkce({ verifier: "v", state: "st" });
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(tokenResponse("access-2")));

    const params = new URLSearchParams({ code: "auth-code", state: "st" });
    const token = await oidcClient.handleRedirect(params);

    expect(token).toBe("access-2");
    expect(sessionStore.getAccessToken()).toBe("access-2");
  });

  it("rejects a callback with an error param", async () => {
    configureEnv();
    const params = new URLSearchParams({ error: "access_denied", error_description: "denied" });
    await expect(oidcClient.handleRedirect(params)).rejects.toThrow("denied");
  });

  it("rejects a callback with mismatched state", async () => {
    configureEnv();
    sessionStore.savePkce({ verifier: "v", state: "expected" });
    const params = new URLSearchParams({ code: "c", state: "unexpected" });
    await expect(oidcClient.handleRedirect(params)).rejects.toThrow("Invalid OIDC callback state");
  });

  it("clears the token on logout", () => {
    sessionStore.setAccessToken("t");
    oidcClient.logout();
    expect(sessionStore.getAccessToken()).toBeNull();
  });

  it("throws when login is attempted without configuration", async () => {
    await expect(oidcClient.login()).rejects.toThrow("OIDC is not configured");
  });
});
