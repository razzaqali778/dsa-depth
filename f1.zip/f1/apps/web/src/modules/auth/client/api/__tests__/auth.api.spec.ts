import { vi } from "vitest";
import { apiGatewayClient } from "../../../../../shared/http/api-client";
import { getAuthSummary, getMe, verifySession } from "../auth.api";

vi.mock("../../../../../shared/http/api-client", () => ({
  apiGatewayClient: { get: vi.fn(), post: vi.fn() },
}));

describe("auth api", () => {
  it("requests the module summary", () => {
    getAuthSummary();

    expect(apiGatewayClient.get).toHaveBeenCalledWith("/auth/summary", { signal: undefined });
  });

  it("requests session verification", () => {
    verifySession();

    expect(apiGatewayClient.post).toHaveBeenCalledWith("/auth/verify", undefined, { signal: undefined });
  });

  it("requests the current session", () => {
    getMe();

    expect(apiGatewayClient.get).toHaveBeenCalledWith("/auth/me", { signal: undefined });
  });
});
