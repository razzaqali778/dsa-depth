import { base64UrlEncode, createPkcePair, deriveCodeChallenge, randomUrlSafeString } from "../pkce";

describe("pkce", () => {
  it("base64url-encodes bytes without padding or unsafe chars", () => {
    const encoded = base64UrlEncode(new Uint8Array([251, 255, 191, 0, 1, 2]));
    expect(encoded).not.toMatch(/[+/=]/);
    expect(encoded.length).toBeGreaterThan(0);
  });

  it("accepts an ArrayBuffer", () => {
    const encoded = base64UrlEncode(new Uint8Array([1, 2, 3]).buffer);
    expect(typeof encoded).toBe("string");
  });

  it("generates random url-safe strings", () => {
    const a = randomUrlSafeString(16);
    const b = randomUrlSafeString(16);
    expect(a).not.toBe(b);
    expect(a).not.toMatch(/[+/=]/);
  });

  it("derives a deterministic S256 challenge for a verifier", async () => {
    const first = await deriveCodeChallenge("verifier-123");
    const second = await deriveCodeChallenge("verifier-123");
    expect(first).toBe(second);
    expect(first).not.toBe(await deriveCodeChallenge("other"));
  });

  it("creates a matching verifier/challenge/state triple", async () => {
    const pair = await createPkcePair();
    expect(pair.verifier).toBeTruthy();
    expect(pair.state).toBeTruthy();
    expect(pair.challenge).toBe(await deriveCodeChallenge(pair.verifier));
  });
});
