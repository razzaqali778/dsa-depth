import { sessionStore } from "../session-store";

describe("sessionStore", () => {
  beforeEach(() => {
    window.sessionStorage.clear();
  });

  it("stores and clears the access token", () => {
    expect(sessionStore.getAccessToken()).toBeNull();

    sessionStore.setAccessToken("token-1");
    expect(sessionStore.getAccessToken()).toBe("token-1");

    sessionStore.clearAccessToken();
    expect(sessionStore.getAccessToken()).toBeNull();
  });

  it("saves and consumes PKCE state exactly once", () => {
    sessionStore.savePkce({ verifier: "v", state: "s" });

    expect(sessionStore.takePkce()).toEqual({ verifier: "v", state: "s" });
    expect(sessionStore.takePkce()).toBeNull();
  });

  it("returns null for corrupt PKCE state", () => {
    window.sessionStorage.setItem("flex.auth.pkce", "not-json");
    expect(sessionStore.takePkce()).toBeNull();
  });
});
