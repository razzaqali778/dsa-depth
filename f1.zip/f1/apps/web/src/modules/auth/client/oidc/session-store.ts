const ACCESS_TOKEN_KEY = "flex.auth.accessToken";
const PKCE_KEY = "flex.auth.pkce";

export type PkceState = {
  verifier: string;
  state: string;
};

function safeStorage(): Storage | null {
  try {
    if (globalThis.window === undefined) {
      return null;
    }
    return globalThis.window.sessionStorage;
  } catch {
    return null;
  }
}

/** Session token + transient PKCE state persisted across the OIDC redirect. */
export const sessionStore = {
  getAccessToken(): string | null {
    return safeStorage()?.getItem(ACCESS_TOKEN_KEY) ?? null;
  },

  setAccessToken(token: string): void {
    safeStorage()?.setItem(ACCESS_TOKEN_KEY, token);
  },

  clearAccessToken(): void {
    safeStorage()?.removeItem(ACCESS_TOKEN_KEY);
  },

  savePkce(pkce: PkceState): void {
    safeStorage()?.setItem(PKCE_KEY, JSON.stringify(pkce));
  },

  takePkce(): PkceState | null {
    const storage = safeStorage();
    const raw = storage?.getItem(PKCE_KEY);
    storage?.removeItem(PKCE_KEY);

    if (!raw) {
      return null;
    }

    try {
      return JSON.parse(raw) as PkceState;
    } catch {
      return null;
    }
  },
};
