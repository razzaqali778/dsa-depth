import { buildScope, readOidcConfig, type OidcConfig } from "./oidc-config";
import { createPkcePair } from "./pkce";
import { sessionStore } from "./session-store";

type TokenResponse = {
  access_token: string;
  id_token?: string;
  expires_in?: number;
};

export function buildAuthorizeUrl(
  config: OidcConfig,
  params: { challenge: string; state: string },
): string {
  const query = new URLSearchParams({
    client_id: config.clientId,
    response_type: "code",
    redirect_uri: config.redirectUri,
    response_mode: "query",
    scope: buildScope(config.apiScope),
    code_challenge: params.challenge,
    code_challenge_method: "S256",
    state: params.state,
  });
  return `${config.authorizeEndpoint}?${query.toString()}`;
}

export async function exchangeCodeForToken(
  config: OidcConfig,
  params: { code: string; verifier: string },
  fetchImpl: typeof fetch = fetch,
): Promise<string> {
  const body = new URLSearchParams({
    client_id: config.clientId,
    grant_type: "authorization_code",
    code: params.code,
    redirect_uri: config.redirectUri,
    code_verifier: params.verifier,
    scope: buildScope(config.apiScope),
  });

  const response = await fetchImpl(config.tokenEndpoint, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: body.toString(),
  });

  if (!response.ok) {
    throw new Error(`Token exchange failed: ${response.status}`);
  }

  const token = (await response.json()) as TokenResponse;
  return token.access_token;
}

function requireConfig(): OidcConfig {
  const config = readOidcConfig();
  if (!config) {
    throw new Error("OIDC is not configured");
  }
  return config;
}

export const oidcClient = {
  isConfigured(): boolean {
    return readOidcConfig() !== null;
  },

  /** Starts the Authorization Code + PKCE flow by redirecting to Entra. */
  async login(): Promise<void> {
    const config = requireConfig();
    const { verifier, challenge, state } = await createPkcePair();
    sessionStore.savePkce({ verifier, state });
    globalThis.location.assign(buildAuthorizeUrl(config, { challenge, state }));
  },

  /** Handles the redirect callback: validates state, exchanges the code, stores the token. */
  async handleRedirect(searchParams: URLSearchParams): Promise<string> {
    const config = requireConfig();
    const error = searchParams.get("error");
    if (error) {
      throw new Error(searchParams.get("error_description") ?? error);
    }

    const code = searchParams.get("code");
    const state = searchParams.get("state");
    const pkce = sessionStore.takePkce();

    if (!code || pkce?.state !== state) {
      throw new Error("Invalid OIDC callback state");
    }

    const token = await exchangeCodeForToken(config, { code, verifier: pkce.verifier });
    sessionStore.setAccessToken(token);
    return token;
  },

  logout(): void {
    sessionStore.clearAccessToken();
  },
};
