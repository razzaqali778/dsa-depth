export type OidcConfig = {
  clientId: string;
  tenantId: string;
  apiScope: string;
  redirectUri: string;
  authorizeEndpoint: string;
  tokenEndpoint: string;
  logoutEndpoint: string;
};

const OPENID_SCOPES = "openid profile email";

function readEnv(key: string): string | undefined {
  const value = import.meta.env[key];
  return typeof value === "string" && value.length > 0 ? value : undefined;
}

function defaultRedirectUri(): string {
  if (globalThis.window === undefined) {
    return "";
  }
  return `${globalThis.location.origin}/auth/callback`;
}

/**
 * Reads Entra OIDC configuration from Vite env. Returns null when the SPA is not
 * configured for SSO (dev mode), in which case the app authenticates directly
 * against the API (AUTH_MODE=disabled).
 */
export function readOidcConfig(): OidcConfig | null {
  const clientId = readEnv("VITE_AZURE_CLIENT_ID");
  const tenantId = readEnv("VITE_AZURE_TENANT_ID");

  if (!clientId || !tenantId) {
    return null;
  }

  const authority = `https://login.microsoftonline.com/${tenantId}/oauth2/v2.0`;
  const apiScope = readEnv("VITE_AZURE_API_SCOPE") ?? "";

  return {
    clientId,
    tenantId,
    apiScope,
    redirectUri: readEnv("VITE_AZURE_REDIRECT_URI") ?? defaultRedirectUri(),
    authorizeEndpoint: `${authority}/authorize`,
    tokenEndpoint: `${authority}/token`,
    logoutEndpoint: `${authority}/logout`,
  };
}

/** The full scope string requested during login. */
export function buildScope(apiScope: string): string {
  return apiScope ? `${OPENID_SCOPES} ${apiScope}` : OPENID_SCOPES;
}

export function isOidcConfigured(): boolean {
  return readOidcConfig() !== null;
}
