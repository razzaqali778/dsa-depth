import { vi } from "vitest";
import { buildScope, isOidcConfigured, readOidcConfig } from "../oidc-config";

describe("oidc-config", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("returns null when the SPA is not configured", () => {
    vi.stubEnv("VITE_AZURE_CLIENT_ID", "");
    vi.stubEnv("VITE_AZURE_TENANT_ID", "");
    expect(readOidcConfig()).toBeNull();
    expect(isOidcConfigured()).toBe(false);
  });

  it("derives endpoints from the tenant", () => {
    vi.stubEnv("VITE_AZURE_CLIENT_ID", "client-1");
    vi.stubEnv("VITE_AZURE_TENANT_ID", "tenant-1");
    vi.stubEnv("VITE_AZURE_API_SCOPE", "api://flex/access");

    const config = readOidcConfig();

    expect(config).toMatchObject({
      clientId: "client-1",
      tenantId: "tenant-1",
      apiScope: "api://flex/access",
      authorizeEndpoint: "https://login.microsoftonline.com/tenant-1/oauth2/v2.0/authorize",
      tokenEndpoint: "https://login.microsoftonline.com/tenant-1/oauth2/v2.0/token",
    });
    expect(config?.redirectUri).toContain("/auth/callback");
    expect(isOidcConfigured()).toBe(true);
  });

  it("honours an explicit redirect uri", () => {
    vi.stubEnv("VITE_AZURE_CLIENT_ID", "client-1");
    vi.stubEnv("VITE_AZURE_TENANT_ID", "tenant-1");
    vi.stubEnv("VITE_AZURE_REDIRECT_URI", "https://flex.bayer/auth/callback");

    expect(readOidcConfig()?.redirectUri).toBe("https://flex.bayer/auth/callback");
  });

  it("builds the scope string", () => {
    expect(buildScope("api://flex/access")).toBe("openid profile email api://flex/access");
    expect(buildScope("")).toBe("openid profile email");
  });
});
