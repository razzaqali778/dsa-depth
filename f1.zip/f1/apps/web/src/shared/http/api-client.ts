type QueryValue = string | number | boolean | null | undefined;
type QueryParams = Record<string, QueryValue>;

type RequestOptions = {
  signal?: AbortSignal;
  headers?: HeadersInit;
  query?: QueryParams;
};

const defaultApiBaseUrl = "/api";
type AuthTokenProvider = () => string | null;

let authTokenProvider: AuthTokenProvider = () => null;

function getApiBaseUrl() {
  return import.meta.env.VITE_FLEX_API_BASE_URL ?? defaultApiBaseUrl;
}

function buildUrl(path: string, query?: QueryParams): string {
  const baseUrl = getApiBaseUrl().replace(/\/$/, "");
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  const url = new URL(baseUrl + normalizedPath, globalThis.location.origin);

  if (!query) {
    return url.toString();
  }

  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === "") {
      continue;
    }

    url.searchParams.set(key, String(value));
  }

  return url.toString();
}

function serializeBody(body: unknown, headers: Headers): BodyInit | undefined {
  if (body === undefined) {
    return undefined;
  }

  if (
    body instanceof Blob ||
    body instanceof FormData ||
    body instanceof URLSearchParams ||
    typeof body === "string"
  ) {
    return body;
  }

  if (!headers.has("content-type")) {
    headers.set("content-type", "application/json");
  }

  return JSON.stringify(body);
}

async function request<TResponse>(
  path: string,
  options: Omit<RequestInit, "body"> & { query?: QueryParams; body?: unknown } = {},
): Promise<TResponse> {
  const url = buildUrl(path, options.query);
  const headers = new Headers(options.headers);
  const token = authTokenProvider();
  const body = serializeBody(options.body, headers);

  if (token && !headers.has("authorization")) {
    headers.set("authorization", `Bearer ${token}`);
  }

  const { body: _rawBody, query: _query, ...requestInit } = options;
  const response = await fetch(url, {
    ...requestInit,
    body,
    headers,
  });

  if (!response.ok) {
    throw new Error(`FLEX API request failed: ${response.status} ${response.statusText}`);
  }

  if (response.status === 204) {
    return undefined as TResponse;
  }

  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) {
    return undefined as TResponse;
  }

  return response.json() as Promise<TResponse>;
}

export function setAuthTokenProvider(provider: AuthTokenProvider): void {
  authTokenProvider = provider;
}

export const apiGatewayClient = {
  get<TResponse>(path: string, options: RequestOptions = {}) {
    return request<TResponse>(path, {
      method: "GET",
      headers: options.headers,
      query: options.query,
      signal: options.signal,
    });
  },

  post<TResponse>(path: string, body?: unknown, options: RequestOptions = {}) {
    return request<TResponse>(path, {
      method: "POST",
      body,
      headers: options.headers,
      query: options.query,
      signal: options.signal,
    });
  },

  patch<TResponse>(path: string, body?: unknown, options: RequestOptions = {}) {
    return request<TResponse>(path, {
      method: "PATCH",
      body,
      headers: options.headers,
      query: options.query,
      signal: options.signal,
    });
  },
};
