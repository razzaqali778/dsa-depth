import { beforeEach, describe, expect, it, vi } from "vitest";
import { apiGatewayClient, setAuthTokenProvider } from "../api-client";

function makeResponse(body: unknown, init: ResponseInit = {}): Response {
  return new Response(body === undefined ? null : JSON.stringify(body), {
    status: 200,
    headers: { "content-type": "application/json", ...init.headers },
    ...init,
  });
}

describe("apiGatewayClient", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllEnvs();
    setAuthTokenProvider(() => null);
    vi.stubGlobal("fetch", vi.fn());
  });

  it("builds relative URLs, filters empty query values, and attaches bearer tokens", async () => {
    setAuthTokenProvider(() => "token-1");
    vi.mocked(fetch).mockResolvedValue(makeResponse({ ok: true }));

    await expect(
      apiGatewayClient.get<{ ok: boolean }>("/users", {
        query: { search: "ann", active: true, skip: 0, empty: "", nope: undefined, nil: null },
      }),
    ).resolves.toEqual({ ok: true });

    const [url, init] = vi.mocked(fetch).mock.calls[0] ?? [];
    expect(url).toBe("http://localhost:3000/api/users?search=ann&active=true&skip=0");
    expect(init).toEqual(
      expect.objectContaining({
        method: "GET",
        body: undefined,
        headers: expect.any(Headers),
        signal: undefined,
      }),
    );
    const headers = init?.headers as Headers;
    expect(headers.get("authorization")).toBe("Bearer token-1");
  });

  it("uses the configured absolute API base URL and JSON-serializes plain objects", async () => {
    vi.stubEnv("VITE_FLEX_API_BASE_URL", "https://api.flex.local/base/");
    vi.mocked(fetch).mockResolvedValue(makeResponse({ created: true }));

    await expect(apiGatewayClient.post("/users", { name: "User One" })).resolves.toEqual({ created: true });

    expect(fetch).toHaveBeenCalledWith(
      "https://api.flex.local/base/users",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ name: "User One" }),
        headers: expect.any(Headers),
      }),
    );
    const headers = vi.mocked(fetch).mock.calls[0]?.[1]?.headers as Headers;
    expect(headers.get("content-type")).toBe("application/json");
  });

  it("passes through string bodies and existing headers", async () => {
    vi.mocked(fetch).mockResolvedValue(makeResponse({ ok: true }));

    await apiGatewayClient.post("/raw", "payload", {
      headers: { "content-type": "text/plain", authorization: "Basic abc" },
    });

    const [, init] = vi.mocked(fetch).mock.calls[0] ?? [];
    expect(init).toEqual(
      expect.objectContaining({
        method: "POST",
        body: "payload",
        headers: expect.any(Headers),
      }),
    );
    const headers = init?.headers as Headers;
    expect(headers.get("content-type")).toBe("text/plain");
    expect(headers.get("authorization")).toBe("Basic abc");
  });

  it("returns undefined for no-content and non-JSON responses", async () => {
    vi.mocked(fetch)
      .mockResolvedValueOnce(makeResponse(undefined, { status: 204, headers: {} }))
      .mockResolvedValueOnce(new Response("plain", { status: 200, headers: { "content-type": "text/plain" } }));

    await expect(apiGatewayClient.patch("/users/u1", { role: "Admin" })).resolves.toBeUndefined();
    await expect(apiGatewayClient.get("/status")).resolves.toBeUndefined();
  });

  it("throws for failed responses", async () => {
    vi.mocked(fetch).mockResolvedValue(new Response("boom", { status: 500, statusText: "Server Error" }));

    await expect(apiGatewayClient.get("/users")).rejects.toThrow("FLEX API request failed: 500 Server Error");
  });
});
