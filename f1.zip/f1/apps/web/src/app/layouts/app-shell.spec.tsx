import { describe, expect, it, vi } from "vitest";
import { fireEvent, render, screen } from "@testing-library/react";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { AppShell } from "./app-shell";
import { useAuth } from "../../modules/auth/model/use-auth";

vi.mock("../../modules/auth/model/use-auth", () => ({ useAuth: vi.fn() }));

const logout = vi.fn();
const baseUser = {
  id: "u1",
  email: "user@flex",
  name: "User One",
  role: "Admin" as const,
  isActive: true,
  authProvider: "local" as const,
  lastLoginAt: null,
  createdAt: "2026-01-01T00:00:00.000Z",
  updatedAt: "2026-01-01T00:00:00.000Z",
};

function mockAuth(overrides: Partial<ReturnType<typeof useAuth>> = {}) {
  vi.mocked(useAuth).mockReturnValue({
    status: "authenticated",
    user: baseUser,
    permissions: ["view_dashboard"],
    error: undefined,
    isAuthenticated: true,
    login: vi.fn(),
    logout,
    refresh: vi.fn(),
    ...overrides,
  });
}

function renderShell() {
  return render(
    <MemoryRouter initialEntries={["/"]}>
      <Routes>
        <Route element={<AppShell />}>
          <Route index element={<div>Workspace view</div>} />
        </Route>
        <Route path="/login" element={<div>Login view</div>} />
      </Routes>
    </MemoryRouter>,
  );
}

describe("AppShell", () => {
  it("renders the workspace navigation", () => {
    mockAuth();
    renderShell();

    expect(screen.getByRole("link", { name: "Workspace" })).toBeInTheDocument();
    expect(screen.getByText("Workspace view")).toBeInTheDocument();
  });

  it("shows the active provider label", () => {
    mockAuth();
    renderShell();

    expect(screen.getByText("Local development")).toBeInTheDocument();
  });

  it("logs out and navigates to login", () => {
    mockAuth({ user: { ...baseUser, authProvider: "azure", role: "User" } });
    renderShell();

    expect(screen.getByText("Microsoft Entra ID")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "Sign out" }));

    expect(logout).toHaveBeenCalledTimes(1);
    expect(screen.getByText("Login view")).toBeInTheDocument();
  });
});
