import { House, LogOut, type LucideIcon } from "lucide-react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../../modules/auth/model/use-auth";

type NavItem = {
  to: string;
  label: string;
  icon: LucideIcon;
};

const BASE_NAV_LINKS: NavItem[] = [{ to: "/", label: "Workspace", icon: House }];

export function AppShell() {
  const navigate = useNavigate();
  const { logout, user } = useAuth();
  const providerLabel = user?.authProvider === "azure" ? "Microsoft Entra ID" : "Local development";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span>BAYER AG</span>
          <strong>FLEX</strong>
        </div>
        <nav className="nav-list">
          {BASE_NAV_LINKS.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} className={({ isActive }) => (isActive ? "nav-link active" : "nav-link")}>
              <Icon size={20} />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="signed-in">
          <span>Signed in as</span>
          <strong>{user?.name ?? "FLEX user"}</strong>
          <p className="signed-in-email">{user?.email ?? "No active session"}</p>
          <div className="signed-in-meta">
            <span className="status-badge status-active">{user?.role ?? "Guest"}</span>
            <span className="muted-text">{providerLabel}</span>
          </div>
          <button
            type="button"
            className="sidebar-action"
            onClick={() => {
              logout();
              navigate("/login", { replace: true });
            }}
          >
            <LogOut size={16} />
            Sign out
          </button>
        </div>
      </aside>
      <main className="main-panel">
        <Outlet />
      </main>
    </div>
  );
}
