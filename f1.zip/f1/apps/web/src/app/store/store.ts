import { configureStore } from "@reduxjs/toolkit";
import { moduleReducers } from "./module-reducers";

export const store = configureStore({
  reducer: moduleReducers,
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
