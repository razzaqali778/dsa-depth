import { describe, expect, it } from "vitest";
import { useAppDispatch, useAppSelector } from "../hooks";

describe("typed redux hooks", () => {
  it("exposes typed hook functions", () => {
    expect(useAppDispatch).toBeTypeOf("function");
    expect(useAppSelector).toBeTypeOf("function");
  });
});
