import { describe, expect, it } from "vitest";
import { moduleReducers } from "../module-reducers";
import { store } from "../store";
import { sessionCleared } from "../../../modules/auth/model/state/auth.slice";

describe("store", () => {
  it("registers the auth reducer and exposes dispatch/getState", () => {
    expect(moduleReducers).toHaveProperty("auth");

    store.dispatch(sessionCleared());
    expect(store.getState().auth.status).toBe("unauthenticated");
  });
});
