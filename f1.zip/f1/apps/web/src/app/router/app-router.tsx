import { Navigate, Route, Routes } from "react-router-dom";
import { AppShell } from "../layouts/app-shell";
import { AuthPage } from "../../modules/auth/ui/pages/auth-page";
import { ProtectedRoute } from "../../modules/auth/ui/components/protected-route";
import { CallbackPage } from "../../modules/auth/ui/pages/callback-page";
import { LoginPage } from "../../modules/auth/ui/pages/login-page";
import { useAuth } from "../../modules/auth/model/use-auth";

// Module page imports and routes are registered here.
// The generator (scripts/create-flex-module.sh) appends additional entries automatically.

export function AppRouter() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/auth/callback" element={<CallbackPage />} />
      <Route element={<ProtectedRoute />}>
        <Route element={<AppShell />}>
          <Route index element={<AuthPage />} />
        </Route>
      </Route>
      <Route path="/auth" element={<Navigate to="/" replace />} />
      <Route path="*" element={<FallbackRoute />} />
    </Routes>
  );
}

function FallbackRoute() {
  const { isAuthenticated, status } = useAuth();

  if (status === "idle" || status === "loading") {
    return null;
  }

  return <Navigate to={isAuthenticated ? "/" : "/login"} replace />;
}
