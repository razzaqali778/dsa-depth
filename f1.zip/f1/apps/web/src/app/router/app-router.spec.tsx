import { describe, expect, it, vi } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";
import { MemoryRouter, Outlet } from "react-router-dom";
import { AppRouter } from "./app-router";
import { useAuth } from "../../modules/auth/model/use-auth";

vi.mock("../../modules/auth/model/use-auth", () => ({
  useAuth: vi.fn(),
}));
vi.mock("../layouts/app-shell", () => ({
  AppShell: () => (
    <div>
      <span>App shell</span>
      <Outlet />
    </div>
  ),
}));
vi.mock("../../modules/auth/ui/components/protected-route", () => ({
  ProtectedRoute: () => <Outlet />,
}));
vi.mock("../../modules/auth/ui/pages/auth-page", () => ({ AuthPage: () => <div>Auth page</div> }));
vi.mock("../../modules/auth/ui/pages/callback-page", () => ({ CallbackPage: () => <div>Callback page</div> }));
vi.mock("../../modules/auth/ui/pages/login-page", () => ({ LoginPage: () => <div>Login page</div> }));

function mockAuth(overrides: Partial<ReturnType<typeof useAuth>> = {}) {
  vi.mocked(useAuth).mockReturnValue({
    status: "authenticated",
    user: undefined,
    permissions: [],
    error: undefined,
    isAuthenticated: true,
    login: vi.fn(),
    logout: vi.fn(),
    refresh: vi.fn(),
    ...overrides,
  });
}

describe("AppRouter", () => {
  it("renders the login route", () => {
    mockAuth();
    render(
      <MemoryRouter initialEntries={["/login"]}>
        <AppRouter />
      </MemoryRouter>,
    );

    expect(screen.getByText("Login page")).toBeInTheDocument();
  });

  it("renders the callback route", () => {
    mockAuth();
    render(
      <MemoryRouter initialEntries={["/auth/callback"]}>
        <AppRouter />
      </MemoryRouter>,
    );

    expect(screen.getByText("Callback page")).toBeInTheDocument();
  });

  it("redirects unknown routes based on auth state", () => {
    mockAuth({ status: "loading", isAuthenticated: false });
    const { container } = render(
      <MemoryRouter initialEntries={["/unknown"]}>
        <AppRouter />
      </MemoryRouter>,
    );
    expect(container).toBeEmptyDOMElement();
    cleanup();

    mockAuth({ status: "authenticated", isAuthenticated: true });
    render(
      <MemoryRouter initialEntries={["/unknown"]}>
        <AppRouter />
      </MemoryRouter>,
    );
    expect(screen.getByText("Auth page")).toBeInTheDocument();
    cleanup();

    mockAuth({ status: "unauthenticated", isAuthenticated: false });
    render(
      <MemoryRouter initialEntries={["/unknown"]}>
        <AppRouter />
      </MemoryRouter>,
    );
    expect(screen.getByText("Login page")).toBeInTheDocument();
  });
});
