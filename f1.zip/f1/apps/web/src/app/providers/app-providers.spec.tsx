import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { AppProviders } from "./app-providers";

function Probe() {
  const location = useLocation();
  const status = useSelector((state: { auth: { status: string } }) => state.auth.status);
  return <div>{`${location.pathname}:${status}`}</div>;
}

describe("AppProviders", () => {
  it("provides the router and redux store", () => {
    render(
      <AppProviders>
        <Probe />
      </AppProviders>,
    );

    expect(screen.getByText(/^\/:(idle|unauthenticated|authenticated)$/)).toBeInTheDocument();
  });
});
