.PHONY: up-apps down-apps api web

up-apps:
	@$(BASH) ./scripts/ops/start-apps.sh

down-apps:
	@$(BASH) ./scripts/ops/stop-apps.sh

api:
	@$(NPM) run dev:api

web:
	@$(NPM) run dev:web
