ifeq ($(OS),Windows_NT)
BASH ?= $(shell if exist "%ProgramFiles%\\Git\\bin\\bash.exe" (echo "%ProgramFiles%\\Git\\bin\\bash.exe") else (echo bash))
else
BASH ?= bash
endif
NPM := $(BASH) ./scripts/npm-from-safe-cwd.sh
COMPOSE := $(shell $(BASH) -c "./scripts/ops/compose-cmd.sh 2>/dev/null || echo podman compose")
CONTAINER_RUNTIME := $(shell $(BASH) -c "./scripts/ops/container-runtime.sh runtime 2>/dev/null || echo unknown")
OPS := $(BASH) ./scripts/ops

# Runtime mode: local (Docker Postgres) | cloud (external DB URLs)
FLEX_ENV ?= local

# up flags: OBSERVABILITY=0 skips Grafana/OTEL; SONAR=0 skips SonarQube; APPS=0 for infra only
OBSERVABILITY ?= 1
SONAR ?= 1
APPS ?= 1

API_PORT ?= 3000
WEB_PORT ?= 5173
GRAFANA_PORT ?= 3001
SONAR_PORT ?= 9000
FLEX_BIND_HOST ?= 127.0.0.1

RUN_DIR := .flex/run

export FLEX_ENV OBSERVABILITY SONAR APPS API_PORT WEB_PORT GRAFANA_PORT SONAR_PORT FLEX_BIND_HOST
