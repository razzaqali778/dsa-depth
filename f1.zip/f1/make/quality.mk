.PHONY: install dev typecheck build module test test-coverage check sonar-scan

install:
	$(NPM) install

dev:
	$(NPM) run dev

typecheck:
	$(NPM) run typecheck

build:
	$(NPM) run build

test:
	$(NPM) run test

test-coverage:
	$(NPM) run test:coverage

check: typecheck test
	$(NPM) run lint

sonar-scan:
	@$(BASH) ./scripts/sonar-scan.sh

ifeq ($(strip $(MODULE)),)
module:
	$(error Usage: make module MODULE=module-name)
else
module:
	@$(BASH) ./scripts/create-flex-module.sh "$(MODULE)"
endif
