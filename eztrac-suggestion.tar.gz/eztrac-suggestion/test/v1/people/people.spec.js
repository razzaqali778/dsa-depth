import { deps, getSuggestionForPerson, getSuggestionsForPeople } from '../../../src/v1/people'
import sinon from 'sinon'

describe('Person service spec ', () => {
  let suggestionStub

  beforeEach(() => {
    suggestionStub = sinon.stub(deps, 'getSuggestion')
  })

  afterEach(() => {
    suggestionStub.restore()
  })

  it('gets suggested rateName and costGroupName for specific userId', async() => {
    const userId = 'MAWEIN'
    const req = { params: { userId } }
    const res = { json: sinon.spy() }
    const suggestionObject = [ { costGroupName: 'PD', id: userId, rateName: 'STANDARD' } ]

    suggestionStub.withArgs([ userId ]).resolves(suggestionObject)

    await getSuggestionForPerson(req, res)
    expect(res.json.args[0][0]).toEqual(suggestionObject)
    expect(suggestionStub.called).toEqual(true)
  })

  it('gets suggested rateName and costGroupName for multiple userIds', async() => {

    const userIds = [ 'MAWEIN', 'MDLIND1' ]
    const req = { body: userIds }
    const res = { json: sinon.spy() }
    const suggestionsArray = [
      { costGroupName: 'PD', id: userIds[0], rateName: 'STANDARD' },
      { costGroupName: 'PD', id: userIds[1], rateName: 'STANDARD' },
    ]

    suggestionStub.withArgs(userIds).resolves(suggestionsArray)

    await getSuggestionsForPeople(req, res)
    expect(res.json.args[0][0]).toEqual(suggestionsArray)
    expect(suggestionStub.called).toEqual(true)
  })
})
