process.env.NODE_ENV = 'test'
process.env.CONFIG_ENV = 'test'

const config = require('../src/config')
const testConfig = require('../src/config/files/test')

config.config = testConfig
config.initalized = true
global.services = testConfig
