/* eslint-disable max-statements*/
import agent from '../../src/util/agent'
import config from '../../src/config'
import DecisionTree from 'decision-tree'
import dt from '../../src/services/decisionTree'
import floor from 'lodash/floor'
import sinon from 'sinon'

const getPapiDataReturn = [
  {
    costGroupName: 'PE',
    id: '0',
    otherVar: ':D',
    rateName: 'Standard',
  }, {
    costGroupName: 'Unknown',
    id: '1',
    otherVar: ':D',
    rateName: 'ScaryRate',
  }, {
    costGroupName: 'Unknown',
    id: '2',
    otherVar: ':D',
    rateName: 'Unknown',
  } ]

describe('Decision Tree Spec', () => {
  let agentGetStub = null

  beforeAll(() => {
    config.init()
  })

  beforeEach(() => {
    agentGetStub = sinon.stub(agent, 'get')
  })

  afterEach(() => {
    agentGetStub.restore()
  })

  it('Gets train test split', () => {
    const mergedPeople = getPapiDataReturn
    const percent = 0.6

    const split = dt.getTrainTestSplit(mergedPeople, percent)
    const trainingSet = split[0]
    const testingSet = split[1]

    expect(trainingSet.length).toEqual(floor(mergedPeople.length * percent))
    expect(testingSet.length).toEqual(floor(mergedPeople.length * (1 - percent)))
  })

  it('Creates a decision tree object', () => {
    const split = dt.getTrainTestSplit(getPapiDataReturn, 0.5)
    const trainingSet = split[0]
    const testingSet = split[1]
    const features = [ 'id', 'otherVar', 'rateName' ]
    const expectedTree = new DecisionTree(trainingSet, 'costGroupName', features)
    const tree = dt.createTree(trainingSet, testingSet, 'costGroupName', features)

    expect(tree.target).toEqual(expectedTree.target)
    expect(tree.features).toEqual(expectedTree.features)
    expect(tree.evaluate(testingSet)).toEqual(expectedTree.evaluate(testingSet))
  })
})
