import agent from '../../src/util/agent'
import cloneDeep from 'lodash/cloneDeep'
import config from '../../src/config'
import people from '../../src/services/getPeople'
import sinon from 'sinon'
import testConfig from '../../src/config/files/test'

const papiUrl = `${testConfig['profile-url']}/v3/graphql`
const eztCostEngineURL = `${testConfig['ez-trac-costing-url']}/v1/people?isActive=true`
const queryBody = `{
  id
  manager { id }
  country { id }
  site { id }
  organization { name, id }
}`

const makePapiQuery = list => ({ query: `{ getUsersById(ids: ["${list.join('","')}"]) ${queryBody} }` })

const papiPeople = new Array(510).fill(0).map((_, i) => i.toString())
const papiUserReturn = {
  body: {
    data: {
      getUsersById: [ {
        country: { id: 'countryId' },
        id: 'personId',
        manager: { id: 'managerId' },
        organization: { id: 'organizationId' },
        site: {
          id: 'siteId',
        },
      } ],
    },
  },
}

const costEngineReturn = cloneDeep(papiPeople).slice(1, 510).map((i) => ({ personId: i }))

describe('Get People Spec', () => {
  let agentGetStub = null
  let agentPostStub = null

  beforeAll(() => {
    config.init()
  })

  beforeEach(() => {
    agentGetStub = sinon.stub(agent, 'get')
    agentPostStub = sinon.stub(agent, 'post')
  })

  afterEach(() => {
    agentGetStub.restore()
    agentPostStub.restore()
  })

  it('fetches cost group people', async() => {
    expect.assertions(2)

    agentGetStub.withArgs(eztCostEngineURL).resolves({ body: costEngineReturn })

    const result = await people.getCostGroupPeople()

    expect(agentGetStub.calledWith(eztCostEngineURL)).toEqual(true)
    expect(result).toEqual(costEngineReturn)
  })

  it('fails to fetch cost group people', async() => {
    expect.assertions(2)

    const expectedFailure = []

    agentGetStub.withArgs(eztCostEngineURL).rejects(expectedFailure)

    const result = await people.getCostGroupPeople()

    expect(agentGetStub.calledWith(eztCostEngineURL)).toEqual(true)
    expect(result).toEqual(expectedFailure)
  })

  it('Retrieve papi data for missing people', async() => {
    agentPostStub.resolves(papiUserReturn)

    const result = await people.getPapiData(papiPeople.slice(0, 1))

    const postArgs = agentPostStub.args

    const expected = [ {
      businessArea: 'missing',
      companyCode: 'missing',
      country: 'countryId',
      id: 'personId',
      managerId: 'managerId',
      organization: 'organizationId',
      siteId: 'siteId',
    } ]

    expect(postArgs[0][0]).toEqual(papiUrl)
    expect(postArgs[0][1]).toEqual(makePapiQuery(papiPeople.slice(0, 1)))
    expect(result).toEqual(expected)
  })

  it('Fails to retrieve papi data for missing people', async() => {
    const response = 'Failure to get stuff'

    agentPostStub.rejects({ error: response })

    const result = await people.getPapiData(papiPeople.slice(0, 1))

    const postArgs = agentPostStub.args

    expect(postArgs[0][0]).toEqual(papiUrl)
    expect(postArgs[0][1]).toEqual(makePapiQuery(papiPeople.slice(0, 1)))
    expect(result).toEqual({ error: response })
  })
})
