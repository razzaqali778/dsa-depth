/* eslint-disable sort-keys */
import RouteClientValidator from 'express-client-validator'

const routes = [
  {
    url: '/people',
    methods: [ 'POST' ],
    clientIds: [
      'PD-EZ-TRAC-CRON-SVC',
      '16540e2d-a0f7-4855-ba4b-3f82056152b1', // CRON-NP
      '38d76d77-2189-47da-8011-889be60064f6', // CRON-PROD
    ],
  },
  {
    url: '/people/user/?',
    methods: [ 'GET' ],
    clientIds: [
      'PD-EZ-TRAC-WORKFLOWS-UI',
      'PD-EZ-TRAC-WORKFLOWS-SVC',
      '2d0de1d8-1fa1-47e0-bb81-5ab76d1831ea', // WORKFLOWS-UI-NP
      'bdf87b85-1dfc-46bb-ad17-6e566593d75b', // WORKFLOWS-UI-PROD
      '6d50bd69-07c5-4696-b242-adf2d75a1033', // WORKFLOWS-SVC-NP
      'e9a927e0-0ec7-443f-b98b-bd0d29e065dc', // WORKFLOWS-SVC-PROD
    ],
  },
  {
    url: '/people/updateCache',
    methods: [ 'GET' ],
    clientIds: [
      'PD-EZ-TRAC-CRON-SVC',
      '16540e2d-a0f7-4855-ba4b-3f82056152b1', // CRON-NP
      '38d76d77-2189-47da-8011-889be60064f6', // CRON-PROD
    ],
  },
]

RouteClientValidator.configure({ routes })
const { validator } = RouteClientValidator

export default validator
