import people from './people'
import { Router } from 'express'
import routeSecurity from './routeSecurity'

const router = new Router()

router.use('/people', routeSecurity, people)

export default router
