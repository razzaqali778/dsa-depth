import { getSuggestion, updateCache } from '../../services/decisionTree'
import logger from '../../util/logger'
import { Router } from 'express'

const router = new Router()

export const deps = {
  getSuggestion,
  updateCache,
}

export const getSuggestionsForPeople = async(req, res) => {
  logger.log('Suggestions requested for people')
  const suggestionArray = await deps.getSuggestion(req.body)

  res.json(suggestionArray)
}

export const getSuggestionForPerson = async(req, res) => {
  logger.log('Suggestion request for person')
  const suggestionObject = await deps.getSuggestion([ req.params.userId ])

  res.json(suggestionObject)
}

export const updateCacheWithResult = async(req, res) => {
  logger.log('Updating cache!')
  const updateCacheSuccess = await deps.updateCache()

  res.json(updateCacheSuccess)
}
router.post('/', getSuggestionsForPeople)
router.get('/user/:userId', getSuggestionForPerson)
router.get('/updateCache', updateCacheWithResult)

export default router
