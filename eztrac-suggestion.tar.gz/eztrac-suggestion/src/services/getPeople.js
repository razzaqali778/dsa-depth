import agent from '../util/agent'
import config from '../config'
import flatMap from 'lodash/flatMap'
import getOrElse from 'lodash/get'
import logger from '../util/logger'
import map from 'lodash/map'

const papiUrl = `${config.get('profile-url')}/v3/graphql`

const costingEngineUrl = `${config.get('ez-trac-costing-url')}/v1`
const queryBody = `{
  id
  manager { id }
  country { id }
  site { id }
  organization { name, id }
}`

const makeQuery = list => ({ query: `{ getUsersById(ids: ["${list.join('","')}"]) ${queryBody} }` })
const getPapiData = async list => {
  try {
    // Ensure list is an array to prevent type confusion
    if (!Array.isArray(list)) {
      logger.error('getPapiData: list parameter must be an array')
      return []
    }
    const thresh = 200
    const callsToMake = Math.ceil(list.length / thresh)

    const promises = new Array(callsToMake).fill(0).map((_, idx) => {
      const start = idx * thresh
      const end = start + thresh
      const subList = list.slice(start, end + 1)
      const query = makeQuery(subList)

      return agent.post(papiUrl, query)
    })

    const resolvedPromises = await Promise.all(promises)
    const results = flatMap(resolvedPromises, d => {
      const persons = getOrElse(d, 'body.data.getUsersById', d)

      return map(persons, person => {
        if (!person) {
          return null
        }
        const val = {
          businessArea: getOrElse(person, 'businessArea', 'missing'),
          companyCode: getOrElse(person, 'company.code', 'missing'),
          country: getOrElse(person, 'country.id', 'missing'),
          id: getOrElse(person, 'id', 'missing'),
          managerId: getOrElse(person, 'manager.id', 'missing'),
          organization: getOrElse(person, 'organization.id', 'missing'),
          siteId: getOrElse(person, 'site.id', 'missing'),
        }

        return val
      })
    }).filter(d => d)

    logger.log(`Resolved all papi promises, fetched data for: ${results.length} people`)
    return results
  } catch (err) {
    logger.error(`Error fetching papi profiles: ${err}`)

    return err
  }
}

const getCostGroupPeople = async() => {
  try {
    const results = await agent.get(`${costingEngineUrl}/people?isActive=true`)

    return results.body
  } catch (error) {
    logger.error('Error in Get Cost Group People', error)
    return []
  }
}

export default {
  getCostGroupPeople,
  getPapiData,
}
