import assign from 'lodash/assign'
import chunk from 'lodash/chunk'
import DecisionTree from 'decision-tree'
import find from 'lodash/find'
import floor from 'lodash/floor'
import intersectionBy from 'lodash/intersectionBy'
import logger from '../util/logger'
import LRU from 'lru-cache'
import map from 'lodash/map'
import omit from 'lodash/omit'
import people from './getPeople'
import remove from 'lodash/remove'

const cache = LRU()

const getMergedPeople = async() => {
  const costCalcPeople = await people.getCostGroupPeople() // from cost calc

  const costGroupPeople = map(costCalcPeople, p => ({
    ...omit(p, 'personId'),
    id: p.personId,
  }))
  const peopleIdList = map(costGroupPeople, ({ id }) => id)

  const papiPeopleData = await people.getPapiData(peopleIdList)

  const costGroupPapiIntersect = intersectionBy(costGroupPeople, papiPeopleData, 'id')
  const papiIntersection = intersectionBy(papiPeopleData, costGroupPapiIntersect, 'id')
  const mergedPeople = map(costGroupPapiIntersect, person =>
    assign(person, find(papiIntersection, [ 'id', person.id ])))
  const removedAllUnknown = remove(mergedPeople,
    ({ costGroupName, rateName }) => costGroupName !== 'Unknown' || rateName !== 'Unknown')

  return removedAllUnknown
}

const getCachedMergedPeople = async() => {
  const cachedMergedPeople = cache.get('mergedPeople')

  if (cachedMergedPeople !== undefined){
    return cachedMergedPeople
  }

  const mergedPeople = await getMergedPeople()

  cache.set('mergedPeople', mergedPeople, 86400000)
  return mergedPeople
}

export const updateCache = async() => {
  try {
    const mergedPeople = await getMergedPeople()

    cache.set('mergedPeople', mergedPeople, 86400000)
    logger.log('Merged people data cached')

    return { started: true }
  } catch (er) {
    logger.error(er)
    return { started: false }
  }
}

const getTrainTestSplit = (peopleList, percentInTrainingSet) => {
  const trainTestArray = chunk(peopleList.sort(() => 0.5 - Math.random()),
    floor(peopleList.length * percentInTrainingSet))

  return trainTestArray
}

const defaultFeatures = [
  'managerId',
  'country',
  'businessArea',
  'companyCode',
  'organization',
  'siteId',
]

const createTree = (trainingData, testingData, decisionKey, features = defaultFeatures) => {
  const tree = new DecisionTree(trainingData, decisionKey, features)

  logger.log(`Accuracy for ${decisionKey}: ${tree.evaluate(testingData)}`)
  return tree
}

export const getSuggestion = async(peoples) => {
  try {
    const papiData = await people.getPapiData(peoples)
    const mergedPeople = await getCachedMergedPeople()
    const [ trainingSet, testingSet ] = getTrainTestSplit(mergedPeople, 0.9)

    const costTree = createTree(trainingSet, testingSet, 'costGroupName')
    const costGroupPredictions = map(papiData, person =>
      ({ costGroupName: costTree.predict(person), id: person.id }))

    const rateTree = createTree(trainingSet, testingSet, 'rateName')
    const ratePredictions = map(papiData, person => ({ id: person.id, rateName: rateTree.predict(person) }))

    const costGroupRatePredictions = map(costGroupPredictions, person =>
      assign(person, find(ratePredictions, [ 'id', person.id ])))

    return costGroupRatePredictions
  } catch (error) {
    logger.log('Failed to determine suggestion ', error)

    const errorReturn = peoples.map(person => ({
      costGroupName: 'Unknown',
      id: person ? person.personId : '',
      rateName: 'Unknown',
    }))

    return errorReturn
  }
}

export default { createTree, getMergedPeople, getSuggestion, getTrainTestSplit, updateCache }
