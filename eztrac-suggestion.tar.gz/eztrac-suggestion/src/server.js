import bodyParser from 'body-parser'
import dt from './services/decisionTree'
import express from 'express'
import logger from './util/logger'
import v1 from './v1'
const app = express()

app.use(bodyParser.json())
app.use('/v1', v1)

const port = parseInt(process.env.PORT || 3600, 10)
const hostname = process.env.NODE_ENV === 'production' ? undefined : '127.0.0.1'

app.get('/ping', (req, res) => {
  res.send('pong')
})

const server = app.listen(port, hostname, () => {
  const address = server.address()
  const url = `http://${address.host || 'localhost'}:${port}`

  // eslint-disable-next-line no-console
  console.info(`Listening at ${url} 🤓 🔮 ✨`)
})

const onStartBuild = async() => {
  const thint = await dt.getSuggestion([ 'DHARR2', 'MAWEIN', 'CWCAME', 'MJLANE' ])

  logger.log(' TEST DATA RETURNS: ', JSON.stringify(thint))
}

onStartBuild()
