const { Config, env, processor, source } = require('@monsantoit/config')
const { determineEnvironmentFileName, isFargate } = require('@monsantoit/config-velocity-store')

const environmentFileName
    = process.env.NODE_ENV === 'production' && isFargate
      ? `${determineEnvironmentFileName()}`
      : `${process.env.CONFIG_ENV || process.env.NODE_ENV || 'default'}.js`

console.info(
  `Configuration Environment - IsFargate: ${isFargate}, environmentFileName: ${environmentFileName}`
)

const config = new Config({
  processors: [
    processor.readVaultFromConfig({
      auth: { type: 'local' },
      enabled: env.inDevelopment,
    }),
    processor.readVaultFromConfig({
      auth: {
        roleName: { inConfig: 'workforce-approle.role_name' },
        type: 'awsRole',
      },
      enabled: env.inProduction,
    }),
  ],
  required: [],
  sources: [
    source.fromJS({ src: `${__dirname}/files/${environmentFileName}` }),
  ],

})

module.exports = config
