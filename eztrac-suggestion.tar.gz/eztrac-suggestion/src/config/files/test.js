const merge = require('lodash/merge')
const defaultConfig = require('./default')

module.exports = merge(defaultConfig, {
  'ez-trac-suggestion': {
    oauth: {
      clientId: 'vault://secret/ez-trac/suggestion-services/np/oauth-azure/client-id',
      clientSecret: 'vault://secret/ez-trac/suggestion-services/np/oauth-azure/client-secret',
    },
  },
})
