const merge = require('lodash/merge')
const defaultConfig = require('./default')

module.exports = merge(defaultConfig, {
  'workforce-approle': {
    role_name: 'workforce-dev-admins-eztrac-np',
  },
})
