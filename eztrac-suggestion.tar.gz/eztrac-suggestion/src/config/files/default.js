const config = {
  'ez-trac-costing-url': 'https://eztrac-costing-services.velocity-np.ag',
  'ez-trac-suggestion': {
    oauth: {
      clientId: 'vault://secret/ez-trac/suggestion-services/np/oauth-azure/client-id',
      clientSecret: 'vault://secret/ez-trac/suggestion-services/np/oauth-azure/client-secret',
    },
  },
  'messaging-url': 'https://messaging.velocity-np.ag',
  'peadmin-home': 'peadmin-np.monsanto.net',
  'profile-url': 'https://profile.velocity-np.ag',
  'velocity-home': 'velocity-np.ag',
  'workforce-approle': {
    role_name: '',
  },
}

module.exports = config
