const merge = require('lodash/merge')
const npConfig = require('./fargate-np')

module.exports = merge(npConfig, {
  'ez-trac-costing-url': 'https://ez-trac-costing-services.velocity.ag',
  'ez-trac-suggestion': {
    oauth: {
      clientId: 'vault://secret/ez-trac/suggestion-services/prod/oauth-azure/client-id',
      clientSecret: 'vault://secret/ez-trac/suggestion-services/prod/oauth-azure/client-secret',
    },
  },
  'messaging-url': 'https://messaging.velocity.ag',
  'peadmin-home': 'peadmin.monsanto.net',
  'profile-url': 'https://profile.velocity.ag',
  'velocity-home': 'velocity.ag',
  'workforce-approle': {
    role_name: 'workforce-dev-admins-eztrac-prod',
  },
})
