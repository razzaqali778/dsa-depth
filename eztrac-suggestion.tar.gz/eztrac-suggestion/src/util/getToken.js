import config from '../config'
import { httpGetToken } from '@monsantoit/oauth-azure'

let tokenFn

export default function getToken(...args) {
  if (!tokenFn) {
    const { oauth: { clientId, clientSecret } } = config.get('ez-trac-suggestion')

    tokenFn = httpGetToken({ clientId, clientSecret })
  }

  return tokenFn(...args)
}
