const message = (args) => args.reduce((memo, val) => `${memo}${val}`, '')

const log = (...args) => {
  // eslint-disable-next-line no-console
  console.log(`app="ez-trac-suggestion" log_level="log" message="${message(args)}"`)
}

const error = (...args) => {
  console.error(`app="ez-trac-suggestion" log_level="error" message="${message(args)}"`)
}

export default { error, log }
