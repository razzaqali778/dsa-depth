import each from 'lodash/each'
import getToken from '../util/getToken'
import promise from 'superagent-promise'
import superagent from 'superagent'

const agent = promise(superagent, Promise)

const setHeaders = (req, headers = {}) => {
  if ( !headers['Accept'] ) { // eslint-disable-line
    req.set('Accept', 'application/json')
  }
  if (!headers['Content-Type']) {
    req.set('Content-Type', 'application/json')
  }
  each(headers, (value, key) => {
    req.set(key, value)
  })

  return req
}

const processSuccess = result => result
const processError = error => {
  if (error.response && error.response.error) {
    return { error: { message: error.response.text, status: error.response.status } }
  }

  return { error: { message: error, status: 500 } }
}

const wrapper = method => {
  if (method === 'put' || method === 'post') {
    return async(url, data, headers = {}) => {
      const token = await getToken()
      const allHeaders = Object.assign(headers, { Authorization: `Bearer ${token}` })

      return setHeaders(agent[method](url, data), allHeaders).then(processSuccess).catch(processError)
    }
  }

  return async(url, headers = {}) => {
    const token = await getToken()
    const allHeaders = Object.assign(headers, { Authorization: `Bearer ${token}` })

    return setHeaders(agent[method](url), allHeaders).then(processSuccess).catch(processError)
  }
}

const get = wrapper('get')
const put = wrapper('put')
const post = wrapper('post')
const del = wrapper('del')

export default { del, get, post, put }
