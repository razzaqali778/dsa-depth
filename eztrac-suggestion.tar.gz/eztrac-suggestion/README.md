# EZ-Trac Suggestion

## Fargate App Name
  `eztrac-suggestion`


## Description
  Node server that builds a decision tree from PAPI profiles of all people in EZ Trac in order to suggest cost groups and rates for new individuals

## Dependencies
  * ez-trac-costing-services
  * papi

## Vault 

### Paths
  * `/secret/ez-trac/suggestion-services/np` -- non prod values
  * `/secret/ez-trac/suggestion-services/prod` -- prod values
### Values
  * `oauth` -- Contains `client-id` and `client-secret`

Ex:
  `vault read secret/ez-trac/suggestion-services/np/oauth` -- Would show you `client-id` and `client-secret` for this app
 
