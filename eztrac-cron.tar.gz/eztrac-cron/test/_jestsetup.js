import testConfig from '../src/config/files/test'

global.services = testConfig
