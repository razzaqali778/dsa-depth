import sinon from 'sinon'
import agent from '../../src/util/agent'
import config from '../../src/config'
import recost from '../../src/cron/recost'
import testConfig from '../../src/config/files/test'

describe('Recost Cron Spec', () => {
  let agentPutStub = null

  const standardTeamUrl = `${testConfig['ez-trac-core-url']}/v2/cost/standard-teams`

  beforeAll(() => {
    config.init()
  })

  beforeEach(() => {
    agentPutStub = sinon.stub(agent, 'put')
  })

  afterEach(() => {
    agentPutStub.restore()
  })

  it('recosts all standard-teams (test success)', async () => {
    expect.assertions(1)

    const standardTeamRows = [
      { numAffectedRows: 150, timeFrameId: 32100 },
      { numAffectedRows: 36, timeFrameId: 32102 },
    ]

    const standardTeamResponse = { body: standardTeamRows }

    const expectedVal = { standardTeamRow: 186 }

    agentPutStub.withArgs(standardTeamUrl).resolves(standardTeamResponse)

    const result = await recost()

    expect(result).toEqual(expectedVal)
  })

  it('standard team failure, returns error', async () => {
    const error = { message: 'internal server error', statusCode: 500 }

    agentPutStub.withArgs(standardTeamUrl).rejects(error)

    const result = await recost()

    expect(result).toEqual(error)
  })
})
