import sinon from 'sinon'
import agent from '../../src/util/agent'
import config from '../../src/config'
import tasks from '../../src/cron/createTasks'
import testConfig from '../../src/config/files/test'

const papiURL = `${testConfig['profile-url']}/v3/graphql`
const messagingURL = `${testConfig['messaging-url']}/v5/tasks`
const personURL = `https://${testConfig['peadmin-home']}/ez-trac-costing/people`

describe('Gets ops leads and submits tasks', () => {
  let agentGetStub = null
  let agentPostStub = null

  const formattedPerson = {
    costGroupName: 'SCARY',
    isActive: true,
    isEmployee: true,
    personId: 'PERSONID',
    personName: 'LANE, MATTHEW, J',
    rateName: 'STANDARD',
  }

  const messagingReturn = {
    id: 1234,
    ok: true,
    rev: 42,
  }

  const oppLeadsV3Return = {
    data: {
      getGroupById: {
        members: {
          total: 4,
          members: [
            {
              id: 'MJLANE',
            },
            {
              id: 'CWCAME',
            },
            {
              id: 'DHARR2',
            },
            {
              id: 'MAWEIN',
            },
          ],
        },
      },
    },
  }

  beforeAll(() => {
    config.init()
  })

  beforeEach(() => {
    agentGetStub = sinon.stub(agent, 'get')
    agentPostStub = sinon.stub(agent, 'post')
  })

  afterEach(() => {
    agentGetStub.restore()
    agentPostStub.restore()
  })

  it('gets ops leads from profile services', async () => {
    expect.assertions(2)

    agentPostStub
      .withArgs(papiURL)
      .resolves({ body: oppLeadsV3Return })
    const expectedResults = [ 'MJLANE', 'CWCAME', 'DHARR2', 'MAWEIN' ]

    const result = await tasks.getOpsLeads()

    expect(agentPostStub.calledWith(papiURL)).toEqual(true)
    expect(result).toEqual(expectedResults)
  })

  it('notifies ops leads of tasks', async () => {
    expect.assertions(6)

    agentPostStub
      .withArgs(messagingURL)
      .resolves(messagingReturn)
    const department = 'Cool People Department'
    const members = [ 'MJLANE', 'CWCAME', 'DHARR2', 'MAWEIN' ]

    const result = await tasks.sendTask(members, formattedPerson, department)

    const taskObject = agentPostStub.getCall(0).args[1]

    expect(agentPostStub.calledWith(messagingURL)).toEqual(true)
    expect(taskObject.actions[0].url).toEqual(
      `${personURL}?personId=${formattedPerson.personId}&edit=true&task=true`,
    )
    expect(taskObject.recipients).toEqual(members)
    expect(taskObject.senderKey).toEqual(formattedPerson.personId)
    expect(taskObject.sender).toEqual('Ez Trac')
    expect(result).toEqual(true)
  })
})
