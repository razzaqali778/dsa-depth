import sinon from 'sinon'
import agent from '../../src/util/agent'
import config from '../../src/config'
import suggestions from '../../src/cron/suggestions'
import testConfig from '../../src/config/files/test'

const papiGetArgs = `${testConfig['ez-trac-suggestion-url']}/v1/people/updateCache`

const suggestionRespond = {
  started: 'true',
}

describe('Suggestions spec', () => {
  let agentGetStub = null

  beforeAll(() => {
    config.init()
  })

  beforeEach(() => {
    agentGetStub = sinon.stub(agent, 'get')
  })

  afterEach(() => {
    agentGetStub.restore()
  })

  it('updates suggestion cache', async () => {
    expect.assertions(2)

    agentGetStub.withArgs(papiGetArgs).resolves({ body: suggestionRespond })

    const result = await suggestions.updateSuggestionCache()

    expect(agentGetStub.calledWith(papiGetArgs)).toEqual(true)
    expect(result).toEqual(suggestionRespond)
  })
})
