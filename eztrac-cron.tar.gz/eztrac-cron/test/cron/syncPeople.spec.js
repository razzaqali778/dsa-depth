import sinon from 'sinon'
import agent from '../../src/util/agent'
import config from '../../src/config'
import createTasks from '../../src/cron/createTasks'
import people from '../../src/cron/syncPeople'
import testConfig from '../../src/config/files/test'

const costingApiUrl = testConfig['ez-trac-costing-url']
const papiUrl = `${testConfig['profile-url']}/v3/graphql`
const costingUrl = `${costingApiUrl}/v1/people`
const eztPutArgs = `${testConfig['ez-trac-costing-url']}/v1/person`
const suggestionUrl = `${testConfig['ez-trac-suggestion-url']}/v1/people`
const opsLeadsGroups = `${testConfig['profile-url']}/v3/graphql`

const makePerson = num => ({
  id: `id${num}`,
  legalName: {
    first: `first${num}`,
    middle: `middle${num}`,
    last: `last${num}`,
  },
  employeeType: 'Employee',
  organization: {
    id: 'org',
    name: 'orgName',
  },
})

const makeMappedPerson = num => ({
  id: `id${num}`,
  firstName: `first${num}`,
  middleName: `middle${num}`,
  lastName: `last${num}`,
  employeeType: 'Employee',
  department: {
    id: 'org',
    name: 'orgName',
  },
})

const makeCostingPerson = num => ({
  personId: `id${num}`,
  isActive: true,
  costGroup: 'someGroup',
  rateName: 'someRate',
})

const papiUserReturn = {
  employeeType: 'Contractor',
  firstName: 'Scary',
  id: '0',
  lastName: 'Lastname',
  middleName: 'Darius',
}

const eztPerson = {
  costGroupName: 'PE',
  isActive: true,
  isEmployee: false,
  personId: '0',
  personName: `${papiUserReturn.lastName}, ${papiUserReturn.firstName} ${papiUserReturn.middleName}`,
  rateName: 'Standard',
}

const eztPersonWithModifiedBy = {
  ...eztPerson,
  modifiedBy: '',
}

const suggestionReturn = {
  ...papiUserReturn,
  costGroupName: 'PE',
  rateName: 'Standard',
}

const oppLeadsV3Return = {
  data: {
    getGroupById: {
      members: {
        total: 4,
        members: [
          {
            id: 'MJLANE',
          },
          {
            id: 'CWCAME',
          },
          {
            id: 'DHARR2',
          },
          {
            id: 'MAWEIN',
          },
        ],
      },
    },
  },
}

describe('Sync people spec', () => {
  let agentGetStub = null
  let agentPutStub = null
  let agentPostStub = null

  beforeAll(() => {
    config.init()
  })

  beforeEach(() => {
    agentGetStub = sinon.stub(agent, 'get')
    agentPutStub = sinon.stub(agent, 'put')
    agentPostStub = sinon.stub(agent, 'post')
  })

  afterEach(() => {
    agentGetStub.restore()
    agentPutStub.restore()
    agentPostStub.restore()
  })

  const setupGraphQLStubs = () => {
    const countQuery1 = { query: '{ getOrganizationById(id: "1") { members { total } } }' }
    const countQuery2 = { query: '{ getOrganizationById(id: "2") { members { total } } }' }
    const countResult = {
      body: {
        data: {
          getOrganizationById: { members: { total: 1 } },
        },
      },
    }

    agentPostStub.withArgs(papiUrl, countQuery1).resolves(countResult)
    agentPostStub.withArgs(papiUrl, countQuery2).resolves(countResult)

    const makeQueryResult = nums => ({
      body: {
        data: {
          getOrganizationById: {
            members: {
              members: nums.map(n => makePerson(n)),
            },
          },
        },
      },
    })

    const queryBody = '{ members(limit:200, offset:0) { members { id, employeeType, legalName { first last middle } organization { id name } } } }' // eslint-disable-line max-len

    const query1 = { query: `{ getOrganizationById(id: "1") ${queryBody} }` }
    const query2 = { query: `{ getOrganizationById(id: "2") ${queryBody} }` }

    const queryResult1 = makeQueryResult([ 1, 2 ])
    const queryResult2 = makeQueryResult([ 3, 4 ])

    agentPostStub.withArgs(papiUrl, query1).resolves(queryResult1)
    agentPostStub.withArgs(papiUrl, query2).resolves(queryResult2)

    return {
      queries: {
        countQuery1,
        countQuery2,
        query1,
        query2,
      },
      results: {
        queryResult1,
        queryResult2,
        countResult,
      },
    }
  }

  it('fetches cost group people', async () => {
    const costingPeople = [ makeCostingPerson(1), makeCostingPerson(2) ]

    expect.assertions(2)

    agentGetStub.resolves({ body: costingPeople })

    const result = await people.getCostGroupPeople()

    expect(agentGetStub.calledWith(costingUrl)).toEqual(true)
    expect(result).toEqual(costingPeople)
  })

  it('fails to fetch cost group people', async () => {
    expect.assertions(2)

    const expectedFailure = []

    agentGetStub.rejects(expectedFailure)

    const result = await people.getCostGroupPeople()

    expect(agentGetStub.calledWith(costingUrl)).toEqual(true)
    expect(result).toEqual(expectedFailure)
  })

  it('fetches all people from papi graphql, maps them to old shape', async () => {
    agentPostStub.resolves()

    const {
      queries: {
        countQuery1, countQuery2, query1, query2,
      },
    } = setupGraphQLStubs()

    const expected = [ makeMappedPerson(1), makeMappedPerson(2), makeMappedPerson(3), makeMappedPerson(4) ]
    const result = await people.getPapiPeople()
    const { args } = agentPostStub

    expect(args[0][0]).toEqual(papiUrl)
    expect(args[0][1]).toEqual(countQuery1)

    expect(args[1][0]).toEqual(papiUrl)
    expect(args[1][1]).toEqual(countQuery2)

    expect(args[2][0]).toEqual(papiUrl)
    expect(args[2][1]).toEqual(query1)

    expect(args[3][0]).toEqual(papiUrl)
    expect(args[3][1]).toEqual(query2)

    expect(result).toEqual(expected)
  })

  describe('compares ez-trac-costing and papi results to find new', () => {
    it('returns empty array if no differences by id', () => {
      const papiPeeps = [ makePerson(1), makePerson(2), makePerson(3) ]
      const costingPeople = [ makeCostingPerson(1), makeCostingPerson(2), makeCostingPerson(3) ]
      const differences = people.findDifferences(papiPeeps, costingPeople)

      expect(differences).toEqual([])
    })
    it('returns an array containing new people not in costing', () => {
      const newPerson = makePerson(3)
      const papiPeople = [ makePerson(1), makePerson(2), newPerson ]
      const costingPeople = [ makeCostingPerson(1), makeCostingPerson(2) ]
      const differences = people.findDifferences(papiPeople, costingPeople)

      expect(differences).toEqual([ newPerson ])
    })
  })

  it('Places missing people into EZ database', async () => {
    expect.assertions(3)

    agentPostStub.withArgs().resolves({ body: oppLeadsV3Return })
    agentPutStub.withArgs(eztPutArgs, eztPersonWithModifiedBy).resolves({ body: eztPerson })

    const result = await people.putMissingPeopleData([ suggestionReturn ])

    expect(agentPostStub.calledWith(opsLeadsGroups)).toEqual(true)
    expect(agentPutStub.calledWith(eztPutArgs, eztPersonWithModifiedBy)).toEqual(true)
    expect(result).toEqual([ eztPerson ])
  })

  it('sync person', async () => {
    agentPostStub.resolves({})
    agentPutStub.resolves({})
    agentGetStub.resolves({})
    const taskStub = sinon.stub(createTasks, 'sendTask')
    const opsLeadStub = sinon.stub(createTasks, 'getOpsLeads')

    opsLeadStub.resolves([ 'mskemm' ])
    taskStub.resolves()

    const {
      queries: {
        countQuery1, countQuery2, query1, query2,
      },
    } = setupGraphQLStubs()

    const costingPeople = [ makeCostingPerson(1), makeCostingPerson(2), makeCostingPerson(3) ]
    const missingPerson = makePerson(4)
    const suggestionResult = {
      body: {
        id: missingPerson.id,
        costGroupName: 'new cost group',
        rateName: 'some new rate name',
      },
    }

    const costingPayload = {
      costGroupName: 'new cost group',
      isActive: true,
      isEmployee: true,
      modifiedBy: '',
      personId: 'id4',
      personName: 'last4, first4 middle4',
      rateName: 'some new rate name',
    }

    agentGetStub.withArgs(costingUrl).resolves({ body: costingPeople })
    agentPostStub.withArgs(suggestionUrl, [ 'id4' ]).resolves({ body: suggestionResult })

    agentPutStub.withArgs(`${costingApiUrl}/v1/person`, costingPayload).resolves({ body: { id: 'id4', some: 'stuff' } })
    const result = await people.syncPeople()

    const { args: taskStubArgs } = taskStub
    const { args: putArgs } = agentPutStub
    const { args: postArgs } = agentPostStub
    const { args: getArgs } = agentGetStub

    expect(putArgs[0][0]).toEqual(`${costingApiUrl}/v1/person`)
    expect(putArgs[0][1]).toEqual(costingPayload)

    expect(getArgs[0][0]).toEqual(costingUrl)

    expect(postArgs[0][0]).toEqual(papiUrl)
    expect(postArgs[0][1]).toEqual(countQuery1)

    expect(postArgs[1][0]).toEqual(papiUrl)
    expect(postArgs[1][1]).toEqual(countQuery2)

    expect(postArgs[2][0]).toEqual(papiUrl)
    expect(postArgs[2][1]).toEqual(query1)

    expect(postArgs[3][0]).toEqual(papiUrl)
    expect(postArgs[3][1]).toEqual(query2)

    expect(postArgs[4][0]).toEqual(suggestionUrl)
    expect(postArgs[4][1]).toEqual([ 'id4' ])

    expect(taskStubArgs[0][0]).toEqual([])
    expect(taskStubArgs[0][1]).toEqual(costingPayload)
    expect(taskStubArgs[0][2]).toEqual({ id: 'org', name: 'orgName' })

    expect(result).toEqual([ 'id4' ])
  })
})
