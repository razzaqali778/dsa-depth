const _ = require('lodash')
const npConfig = require('./fargate-np')

module.exports = _.merge(npConfig, {
  'messaging-url': 'https://messaging.velocity.ag',
  'profile-url': 'https://profile.velocity.ag',
  'velocity-home': 'velocity.ag',
  'peadmin-home': 'peadmin.monsanto.net',
  'ez-trac-core-url': 'https://ez-trac-core-services.velocity.ag',
  'ez-trac-costing-url': 'https://ez-trac-costing-services.velocity.ag',
  'ez-trac-suggestion-url': 'https://ez-trac-suggestion.velocity.ag',
  'ez-trac-vip-url': 'https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services',
  'ez-trac-cron': {
    oauth: {
      clientId: 'vault://secret/ez-trac/cron-services/prod/oauth-azure/client-id',
      clientSecret: 'vault://secret/ez-trac/cron-services/prod/oauth-azure/client-secret',
    },
    organizationIds: [
      51183632,
      51183636,
    ],
  },
  'ez-trac-teams-hooks': {
    devs: {
      hook: 'vault://secret/ez-trac/teams/alerts-prod/url',
    },
  },
  'workforce-approle': {
    role_name: 'workforce-dev-admins-eztrac-prod',
  },
})
