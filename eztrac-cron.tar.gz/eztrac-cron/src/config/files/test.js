const _ = require('lodash')
const defaultConfig = require('./default')

module.exports = _.merge(defaultConfig, {
  'ez-trac-cron': {
    oauth: {
      clientId: 'vault://secret/ez-trac/cron-services/np/oauth-azure/client-id',
      clientSecret: 'vault://secret/ez-trac/cron-services/np/oauth-azure/client-secret',
    },
    organizationIds: [
      1,
      2,
    ],
  },
})
