
const config = {
  'messaging-url': 'https://messaging.velocity-np.ag',
  'profile-url': 'https://profile.velocity-np.ag',
  'velocity-home': 'velocity-np.ag',
  'peadmin-home': 'peadmin-np.monsanto.net',
  'ez-trac-core-url': 'https://ez-trac-core-services.velocity-np.ag',
  'ez-trac-costing-url': 'https://ez-trac-costing-services.velocity-np.ag',
  'ez-trac-suggestion-url': 'https://ez-trac-suggestion.velocity-np.ag',
  'ez-trac-vip-url': 'https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services',
  'ez-trac-cron': {
    oauth: {
      clientId: 'vault://secret/ez-trac/cron-services/np/oauth-azure/client-id',
      clientSecret: 'vault://secret/ez-trac/cron-services/np/oauth-azure/client-secret',
    },
    organizationIds: [
      51183632,
      51183636,
    ],
  },
  'workforce-approle': {
    role_name: '',
  },
  'ez-trac-teams-hooks': {
    devs: {
      hook: 'vault://secret/ez-trac/teams/alerts-np/url',
    },
  },
}

module.exports = config
