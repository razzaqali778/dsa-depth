import { httpGetToken } from '@monsantoit/oauth-azure'
import config from '../config'

const getToken = () => {
  const { oauth: { clientId, clientSecret } } = config.get('ez-trac-cron')

  return httpGetToken({ clientId, clientSecret })()
}

export default getToken
