import sendTeamsLog from './teamsMessenger'

const makeMessage = args => args.reduce((memo, val) => `${memo}${val}`, '')

const log = (...args) => {
  // eslint-disable-next-line no-console
  console.log(`app="ez-trac-cron" log_level="log" message="${makeMessage(args)}"`)
}

const error = (...args) => {
  // eslint-disable-next-line no-console
  console.error(`app="ez-trac-cron" log_level="error" message="${makeMessage(args)}"`)
}

const teams = (...args) => {
  const message = makeMessage(args)

  log(message)
  sendTeamsLog(message)
}

export default { error, log, teams }
