import teams from '@bayerit/velocity-teams'
import config from '../config'

const isLocal = process.env.NODE_ENV !== 'production'

function makeTeamsMessage(message) {
  const hookUrl = config.get('ez-trac-teams-hooks').devs.hook

  teams.sendMessage({ text: message, hookUrl })
}

const sendTeamsLog = message => (isLocal
  ? null
  : makeTeamsMessage(message))

export default sendTeamsLog
