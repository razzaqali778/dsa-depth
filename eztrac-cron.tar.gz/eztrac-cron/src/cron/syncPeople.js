import ceil from 'lodash/ceil'
import concat from 'lodash/concat'
import differenceBy from 'lodash/differenceBy'
import find from 'lodash/find'
import flatMap from 'lodash/flatMap'
import flatten from 'lodash/flatten'
import getOrElse from 'lodash/get'
import map from 'lodash/map'
import logger from '../util/logger'
import createTask from './createTasks'
import config from '../config'
import agent from '../util/agent'

const thresh = 200

const getPapiUrl = () => `${config.get('profile-url')}/v3/graphql`
const getCostingEngineUrl = () => `${config.get('ez-trac-costing-url')}/v1`
const getSuggestionServicesUrl = () => `${config.get('ez-trac-suggestion-url')}/v1`
const getOrganizationIds = () => config.get('ez-trac-cron').organizationIds

const getCountInGroup = async groupId => {
  const queryBody = '{ members { total } }'
  const result = await agent.post(getPapiUrl(), { query: `{ getOrganizationById(id: "${groupId}") ${queryBody} }` })

  return getOrElse(result, 'body.data.getOrganizationById.members.total', 0)
}

const makeQuery = (organizationId, start) => {
  const fields = 'id, employeeType, legalName { first last middle } organization { id name }'
  const queryBody = `{ members(limit:${thresh}, offset:${start}) { members { ${fields} } } }`
  const queryString = `{ getOrganizationById(id: "${organizationId}") ${queryBody} }`

  return { query: queryString }
}
const getPeopleInOrganization = async organizationId => {
  logger.log(`Fetching people in organization: ${organizationId}`)
  const callsToMake = ceil(await getCountInGroup(organizationId) / thresh)
  const papiUrl = getPapiUrl()

  const promises = new Array(callsToMake).fill(0).map((_, idx) => {
    const start = idx * thresh
    const query = makeQuery(organizationId, start)

    return agent.post(papiUrl, query)
  })

  const resolvedPromises = await Promise.all(promises)

  const results = flatMap(resolvedPromises, result => {
    const list = getOrElse(result, 'body.data.getOrganizationById.members.members', [])

    return map(list, person => {
      if ( !person || !person.id || !person.employeeType || !person.organization || !person.legalName ) { return null }

      return {
        id: person.id,
        firstName: person.legalName.first,
        middleName: person.legalName.middle,
        lastName: person.legalName.last,
        employeeType: person.employeeType,
        department: {
          id: person.organization.id,
          name: person.organization.name,
        },
      }
    }).filter(d => d)
  })

  logger.log(`Fetched ${results.length} people for organization ${organizationId}`)

  return results
}
const getPapiPeople = async () => {
  const promises = map(getOrganizationIds(), organizationId => getPeopleInOrganization(organizationId))
  const results = await Promise.all(promises)
  const flattened = flatten(results)

  logger.log(`fetched ${flattened.length} total people`)

  return flattened
}

const getCostGroupPeople = async () => {
  try {
    const results = await agent.get(`${getCostingEngineUrl()}/people`)

    return results.body
  } catch ( error ) {
    logger.error('Error in Get Cost Group People', error)

    return []
  }
}

const findDifferences = (papiPeople, costingPeople) => differenceBy(papiPeople, costingPeople, p => p.id || p.personId)

const putMissingPeopleData = async mergedSuggestedPeople => {
  const costingUrl = `${getCostingEngineUrl()}/person`
  // This gets the correct ops leads from the Ez-Trac group
  const opsLeads = await createTask.getOpsLeads()
  const fakeOpsLeads = [ ]
  const combinedOpsLeads = concat(opsLeads, fakeOpsLeads)

  const realOpsLeads = `${config.get('profile-url')}`.includes('np') ? fakeOpsLeads : combinedOpsLeads

  logger.log('ops leads: ', realOpsLeads)
  const promises = map(mergedSuggestedPeople, person => {
    const formattedPerson = {
      costGroupName: person.costGroupName,
      isActive: true,
      isEmployee: person.employeeType === 'Employee',
      modifiedBy: '',
      personId: person.id,
      personName: `${person.lastName}, ${person.firstName} ${person.middleName || ''}`.trim(),
      rateName: person.rateName,
    }

    createTask.sendTask(realOpsLeads, formattedPerson, person.department)

    return agent.put(costingUrl, formattedPerson)
  })
  const results = await Promise.all(promises)

  return map(results, result => result.body)
}

const getSuggestions = async people => {
  try {
    const response = await agent.post(`${getSuggestionServicesUrl()}/people`, people)

    return response.body
  } catch ( error ) {
    logger.error('ERROR IN GET SUGGESTION: ', error)

    return []
  }
}

const syncPeople = async () => {
  const promises = [ getPapiPeople(), getCostGroupPeople() ]

  try {
    const [ papiPeople, costGroupPeople ] = await Promise.all(promises)
    const differences = findDifferences(papiPeople, costGroupPeople)

    if ( differences.length === 0 || differences.length === undefined ) {
      logger.log('No differences detected')

      return []
    }

    const idList = map(differences, ({ id }) => id)
    const suggestions = await getSuggestions(idList)

    const mergedSuggestedPeople = map(differences, person => ({
      ...person,
      ...find(suggestions, [ 'id', person.id ]),
    }))

    const putResult = await putMissingPeopleData(mergedSuggestedPeople)

    return map(putResult, ({ personId, id }) => personId || id)
  } catch ( error ) {
    logger.error('ERROR IN SYNC PEOPLE FUNC', error)

    return `Sync Error: ${error}`
  }
}

export default {
  findDifferences,
  getCostGroupPeople,
  getPapiPeople,
  putMissingPeopleData,
  syncPeople,
}
