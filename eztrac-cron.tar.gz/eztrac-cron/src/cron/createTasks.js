import getOrElse from 'lodash/get'
import map from 'lodash/map'
import moment from 'moment'
import agent from '../util/agent'
import config from '../config'
import logger from '../util/logger'

const getOpsLeads = async () => {
  const papiURL = `${config.get('profile-url')}/v3/graphql`
  const query = { query: '{getGroupById(id:"PE-STRATEGY-AND-OPERATIONS-LEADS") {members {total members {id}}}}' }

  const result = await agent.post(papiURL, query)
  const members = getOrElse(result, 'body.data.getGroupById.members.members', [])

  return map(members, 'id')
}

const sendTask = async (opsLeadsList, newPerson, department) => {
  try {
    const messagingURL = `${config.get('messaging-url')}/v5/tasks`
    const personURL = `https://${config.get('peadmin-home')}/ez-trac-costing/people`
    const messagingPayload = {
      actions: [
        {
          title: 'view',
          url: `${personURL}?personId=${newPerson.personId}&edit=true&task=true`,
        },
      ],
      body: {
        markdown: `Please review the new profile for **${newPerson.personName}**
                    from the department **${department.name}**. They have been suggested the
                    cost group of **${newPerson.costGroupName}** with the rate of **${newPerson.rateName}.**`,
      },
      dueDate: moment().add(1, 'w').format('YYYY-MM-DD'),
      recipients: opsLeadsList,
      sender: 'Ez Trac',
      senderKey: newPerson.personId,
      tags: [
        'Ez Trac',
      ],
      title: 'Review Person Added to Ez-Trac',
    }

    const response = await agent.post(messagingURL, messagingPayload)

    return response.ok
  } catch ( error ) {
    logger.error(`Failed to send tasks: ${error}`)

    return error
  }
}

export default {
  getOpsLeads,
  sendTask,
}
