import reduce from 'lodash/reduce'
import agent from '../util/agent'
import config from '../config'
import logger from '../util/logger'

const recost = async () => {
  const standardTeamUrl = `${config.get('ez-trac-core-url')}/v2/cost/standard-teams`

  try {
    const standardTeams = await agent.put(standardTeamUrl)
    const standardTeamRowCount = reduce(standardTeams.body, (sum, teamRows) => sum + teamRows.numAffectedRows, 0)

    return {
      standardTeamRow: standardTeamRowCount,
    }
  } catch ( error ) {
    logger.error('Error recosting teams', JSON.stringify(error))

    return error
  }
}

export default recost
