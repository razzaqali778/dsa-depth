import agent from '../util/agent'
import config from '../config'
import logger from '../util/logger'

export default async () => {
  const vipUrl = config.get('ez-trac-vip-url')
  const result = await agent.get(`${vipUrl}/v1/rebuild-elastic-search`)

  if ( result.error ) {
    logger.error('Error rebuilding VIP elastic: ', result.error ? result.error.message : JSON.stringify(result))
  } else {
    logger.teams('Rebuilt VIP elastic search: ', result.text)
  }
}
