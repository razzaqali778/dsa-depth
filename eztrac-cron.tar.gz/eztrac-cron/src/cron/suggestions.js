import agent from '../util/agent'
import config from '../config'
import logger from '../util/logger'

const updateSuggestionCache = async () => {
  try {
    const suggestionUrl = `${config.get('ez-trac-suggestion-url')}/v1`

    logger.log('UPDATING CACHE!')
    const queryParams = '/people/updateCache'
    const result = await agent.get(suggestionUrl + queryParams)

    return result.body
  } catch ( error ) {
    logger.log('Failed to update cache!', error)

    return error
  }
}

export default {
  updateSuggestionCache,
}
