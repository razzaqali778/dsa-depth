# eztrac-cron — Node 22 / Toolchain Upgrade

This document summarizes the Node 22 upgrade and vulnerability remediation for `eztrac-cron`. It is intended for reviewers, deployers, and anyone running the app locally via `eztrac-local-setup`.

**App version:** `1.0.29` (unchanged in `package.json`)  
**Target Node:** `22.x` (was `~18.x`)

---

## Executive summary

The upgrade modernizes the JavaScript toolchain for this Express cron scheduler (no UI / Webpack):

| Area | Before | After |
|------|--------|-------|
| Node | ~18.x | **22.x** |
| Babel | 6.x (`babel-preset-es2017`) | **7.x** (`@babel/preset-env`) |
| Jest | 23.x | **29.x** |
| ESLint | 5.x + `eslint-plugin-wyze` | **8.x** (Airbnb 19, wyze removed) |
| Dev reload | `piping` | **Removed** |
| `@monsantoit/config` | ~2.1.0 | **~3.1.6** |
| `config-velocity-store` | ~1.1.0 | **~2.0.1** |
| `superagent` | ^8 | **^10.2.2** |
| Lockfile | `package-lock.json` committed | **Removed** (`preinstall` + `legacy-peer-deps`) |

`npm audit` reports **0 vulnerabilities** after overrides.

---

## Files changed

### Configuration & build

| File | Change |
|------|--------|
| `package.json` | engines `22.x`, Babel/Jest/ESLint upgrades, dependency bumps, prune unused deps, `overrides`, `preinstall` |
| `package-lock.json` | **Deleted** |
| `.babelrc` | Babel 7 + `targets: { node: "current" }`; `env.test` block |
| `.npmrc` | `legacy-peer-deps=true` |
| `.eslintrc.json` | ESLint 8 / Airbnb 19; `@babel/eslint-parser`; removed wyze + webpack resolver |
| `test/.eslintrc.json` | Removed wyze rule |
| `.github/workflows/{np,prepare,release}.yml` | Default `node_version` → `22.15.0` |

### Application runtime

| File | Change |
|------|--------|
| `bin/www` | `@babel/register` instead of `babel-register`; removed `piping` |
| `src/util/getToken.js` | Lazy `config.get` (config v3 requires `init()` first) |
| `src/util/teamsMessenger.js` | Lazy `config.get` for Teams hook URL |
| `src/cron/{suggestions,createTasks,rebuildVIPElastic,syncPeople}.js` | Deferred `config.get` until after `init()` |
| `src/cron/syncPeople.js` | `config['profile-url']` → `config.get('profile-url')` |

### Local setup (eztrac-notes)

| File | Change |
|------|--------|
| `eztrac-local-setup/compose.yaml` | `cron` `NODE_VERSION: "22"` |
| `eztrac-local-setup/scripts/install.sh` | `eztrac-cron\|22` |
| `eztrac-local-setup/scripts/lib.sh` | `service_node_version` returns 22 for cron |
| `eztrac-local-setup/docs/diagrams.md` | cron Node 22 |
| `eztrac-local-setup/Makefile` | Help text updated |

### Tests

| Pattern | Change |
|---------|--------|
| Jest config | `babel-jest`, `testEnvironment: node`, sinon `moduleNameMapper` |
| Scripts | `BABEL_ENV=test` on test scripts |
| `syncPeople.spec.js` | Expect empty ops-leads recipients on NP profile URL (correct `config.get` behavior) |

---

## Detailed changes by area

### 1. Node.js 18 → 22

```json
"engines": { "node": "22.x" }
```

- Local: `nvm use 22` before `npm install` / `npm run dev`
- Compose / CI / Fargate image build-arg must use Node 22 (`Dockerfile` already takes `NODE_VERSION`)

### 2. Babel 6 → 7

**Removed:** `babel-cli`, `babel-register`, `babel-preset-es2017`, Babel 6 plugins, `piping`

**Added:** `@babel/core`, `@babel/cli`, `@babel/preset-env`, `@babel/plugin-transform-runtime`, `@babel/register`, `@babel/runtime`

Production still uses `npm run build` → `dist/` then `NODE_ENV=production node ./bin/www`. Dev uses `@babel/register` on source.

### 3. Jest 23 → 29 / ESLint 5 → 8

- Jest 29 + `babel-jest` + `jest-environment-node`; Sinon ~15.2
- ESLint 8 + Airbnb 19; drop `eslint-plugin-wyze` / `babel-eslint`
- Lint script matches QC (`eslint --fix` without the removed `table` formatter)

### 4. Dependencies & vulnerabilities

**Bumped:** `@monsantoit/config` ~3.1.6, `config-velocity-store` ~2.0.1, `express` ~4.22, `lodash` ~4.18, `superagent` ^10.2.2, `cross-env` ~7

**Pruned (unused):** `decision-tree`, `machine_learning`, `lru-cache`, `node-cache`, `shuffle-array`, `winston`, `dotenv`

**Kept:** `cron@1.2.1` (API change risk on major bump); `@monsantoit/oauth-azure` (no MSAL rewrite in this pass)

**Overrides:** force safe transitive versions (`superagent` ^10.2.2, AWS SDK clients ≥3.896, `@smithy/*` patched ranges, `uuid` ≥11.1.1, `formidable`, `js-yaml`, nested Monsanto packages, etc.)

Do **not** run `npm audit fix --force` — npm suggests downgrading `@monsantoit/config` to 3.0.1, which is a breaking change. Use the `overrides` instead, then:

```bash
rm -rf node_modules
npm install
npm audit   # expect 0 vulnerabilities
```

### 5. Config v3 notes

`@monsantoit/config` 3.x throws if `config.get()` runs before `config.init()`. Cron modules and utils were updated to call `get()` lazily inside functions. Tests already call `config.init()` in `beforeAll`.

`@monsantoit/config@3.1.6` declares `engines.node: ^20` — installs cleanly on Node 22 with an `EBADENGINE` warning (same as QC).

---

## Verification

```bash
nvm use 22
npm install
npm test          # lint + jest
npm run build     # babel → dist/
npm audit         # expect 0 vulnerabilities
```

Local compose: rebuild the `cron` service so it picks up Node 22, then `GET http://localhost:3020/ping`.

---

## Residual / follow-ups

- `@monsantoit/oauth-azure` remains deprecated (migrate to `@azure/msal-node` separately)
- `cron@1.2.1` left pinned; consider a careful major upgrade later
- Sibling `eztrac-suggestion` still on the pre-upgrade Babel 6 / older Node stack
