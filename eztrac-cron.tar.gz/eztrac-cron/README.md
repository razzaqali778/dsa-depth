# EZ-Trac Cron

## Fargate App Name
  `eztrac-cron`

## Description
  Node server to automatically run jobs at midnight.
  
## Jobs
  Recosting in the costing engine
  Rebuilding the VIP Audit Elasticsearch Index
  Finding people new to P&E or the Agile Office and automatically adding them to the costing engine
  
## Dependencies
  * ez-trac-suggestion
  * ez-trac-vip
  * papi

## Vault 

### Paths
  * `/secret/ez-trac/cron-services/np` -- non prod values
  * `/secret/ez-trac/cron-services/prod` -- prod values
### Values
  * `oauth` -- Contains `client-id` and `client-secret`

Ex:
  `vault read secret/ez-trac/cron-services/np/oauth` -- Would show you `client-id` and `client-secret` for this app
 
