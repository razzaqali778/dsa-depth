import { CronJob } from 'cron'
import express from 'express'
import logger from './src/util/logger'
import people from './src/cron/syncPeople'
import rebuildVIPElastic from './src/cron/rebuildVIPElastic'
import recost from './src/cron/recost'
import suggestions from './src/cron/suggestions'

const app = express()

const port = parseInt( process.env.PORT || 3020, 10 )
const hostname = process.env.NODE_ENV === 'production' ? undefined : '127.0.0.1'

const recostTick = async () => {
  const rowsAffected = await recost()
  logger.teams(`Recosting run... \n
    Standard Team rows affected: ${rowsAffected.standardTeamRow}`
  )
}

const syncTick = async () => {
  const syncResult = await people.syncPeople()

  logger.teams('The following people were added to the costing engine: ', JSON.stringify(syncResult))
}

const cacheTick = async () => {
  const updateCache = await suggestions.updateSuggestionCache()
  logger.teams('Updating cache response:', JSON.stringify(updateCache))
}

const recostJob = new CronJob({
  cronTime: '00 00 00 * * 0-6',
  onTick: recostTick,
  start: false,
  timeZone: 'America/Chicago',
})

const syncPeopleJob = new CronJob({
  cronTime: '00 01 00 * * 0-6',
  onTick: syncTick,
  start: false,
  timeZone: 'America/Chicago',
})

const updateCacheJob = new CronJob({
  cronTime: '00 02 00 * * 0-6',
  onTick: cacheTick,
  start: false,
  timeZone: 'America/Chicago',
})

const resetVipElasticJob = new CronJob({
  cronTime: '00 00 00 * * *',
  onTick: rebuildVIPElastic,
  start: false,
  timeZone: 'America/Chicago',
})

const initializationFunction = async () => {
  await recostTick()
  await cacheTick()
  await syncTick()
}

app.get( '/ping', ( req, res ) => {
  res.send( 'pong' )
} )

const server = app.listen( port, hostname, () => {
  const address = server.address()
  const url = `http://${address.host || 'localhost'}:${port}`

  console.info(`Listening at ${url} 🐶 👏🏽 🤷`)
} )

recostJob.start()
syncPeopleJob.start()
updateCacheJob.start()
resetVipElasticJob.start()

initializationFunction()