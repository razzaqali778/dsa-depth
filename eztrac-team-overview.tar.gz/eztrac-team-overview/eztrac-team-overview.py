import asyncio
import logging
import os
import subprocess
import sys
import time
from datetime import datetime

import browser_cookie3
import pandas as pd
import requests
import seaborn.objects as so
import truststore
from tqdm import tqdm


def get_general_headers():
    """Returns HTTP headers suitable for interacting with EZ Trac and Velocity profile API

    :return: array of headers to be used for requests or urllib
    :rtype: array of strings
    """
    # Define general headers
    return {
        "authority": "peadmin.monsanto.net",
        "accept": "*/*",
        "accept-language": "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7",
        "cache-control": "no-cache",
        "pragma": "no-cache",
        "referer": "https://peadmin.monsanto.net/ez-trac-qc/team-history",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
    }


def get_full_name(username: str, bearer_token: str):
    """Queries Velocity Profiles for the full name for a username

    :param username: username defined as CWID to resolve the full name for
    :type username: str
    :param bearer_token: bearer token to interact with Velocity Profiles
    :type bearer_token: str
    :return: Full name with first and last name for the user name. If the request fails, the CWID is returned
    :rtype: str
    """
    headers = {
        "authority": "profile.velocity.ag",
        "accept": "*/*",
        "accept-language": "de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7",
        "authorization": "Bearer %s" % bearer_token,
        "cache-control": "no-cache",
        "origin": "https://velocity.ag",
        "pragma": "no-cache",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
    }

    params = {
        "q": username,
        "limit": "10",
        "offset": "0",
    }

    response = requests.get(
        "https://profile.velocity.ag/v3/search/users",
        params=params,
        cookies=cookie_jar,
        headers=headers,
    )
    if response.status_code != 200:
        logging.error(
            "Could not retrieve full name for '{}', using CWID. Response: {} {}".format(
                username, response.status_code, response.text
            )
        )
        return username
    try:
        response_doc = response.json()
        results = response_doc["docs"]
        if results:
            full_name = results[0]["preferredName"]["full"]
        else:
            full_name = None
    except IndexError as e:
        logging.error(
            "Could not retrieve full name for '{}', using CWID. Response: {} {}".format(
                username, response.status_code, response.text
            ),
            exc_info=e,
        )
    return full_name


def get_timeframes(cookie_jar: dict):
    """Retrieves a list of timeframes for the current year. Includes the timeframe ID from EZ Trac and the name

    :param cookie_jar: Cookie jar with EZ trac cookies
    :type cookie_jar: dict
    :return: dictionary with ID of the time frame and the name. Key is the ID
    :rtype: dict
    """
    response = requests.get(
        "https://peadmin.monsanto.net/ez-trac-qc/services/proxies/core-services/v2/timeframes/",
        cookies=cookie_jar,
        headers=get_general_headers(),
    )
    logging.debug("Status code: {}".format(response.status_code))
    if response.status_code != 200:
        logging.error(
            "Could not get time frames: %s - %s"
            % (response.status_code, response.content)
        )
        return None
    try:
        given_timeframes = response.json()
    except requests.exceptions.JSONDecodeError as e:
        logging.error("Could not parse time frames: ", exc_info=e)
        logging.error(response)
        logging.error(response.text)
        return None

    starting_day_of_current_year = datetime.now().replace(
        month=1, day=1, hour=0, minute=0, second=0, microsecond=0
    )
    first_timestamp = starting_day_of_current_year.timestamp() * 1000

    timeframes_of_interest = {}
    for tf in given_timeframes:
        if int(tf["startDate"]) >= first_timestamp:
            timeframes_of_interest[tf["id"]] = tf["name"]
    return timeframes_of_interest


def refresh_bearer_token(cookie_jar: dict):
    """Refreshes the bearer token for EZ Tract

    :param cookie_jar: Cookie jar with the EZ Trac cookies
    :type cookie_jar: dict
    :return: a new bearer token to interact with EZ Trac, none if it fails
    :rtype: str
    """
    response = requests.get(
        "https://peadmin.monsanto.net/ez-trac-qc/team-history/auth-token-refresh",
        cookies=cookie_jar,
        headers=get_general_headers(),
    )

    logging.debug(response.status_code)
    if response.status_code != 200:
        logging.error(
            "Could not refresh bearer token. Response: {} {}".format(
                response.status_code, response.text
            )
        )
        return None

    bearer_token = response.json()["access_token"]
    return bearer_token


def get_eztrac_headers(bearer_token: str):
    """Returns HTTP headers suitable for interacting with EZ Trac. Injects the bearer token

    :param bearer_token: bearer token valid for EZ Trac
    :type bearer_token: str
    :return: array of headers to be used for requests or urllib
    :rtype: array of strings
    """

    headers = get_general_headers()
    headers["content-type"] = "application/json"
    headers["authorization"] = "%s" % ("Bearer %s" % bearer_token)
    return headers


async def get_monthly_allocation(cookie_jar, headers, timeframe_id: str, user_id: str):
    """Retrieves the monthly allocation for a user in a specific time frame.

    :param cookie_jar:  Cookie jar with the EZ Trac cookies
    :type cookie_jar: dict
    :param headers: HTTP headers for EZ Trac
    :type headers: dict
    :param timeframe_id: ID of the time frame to search for
    :type timeframe_id: str
    :param user_id: CWID of the user to get the allocation for
    :type user_id: str
    :return: dict of allocation in percent per charging team
    :rtype: dict
    """
    params = {
        "timeFrameId": timeframe_id,
        "userId": user_id,
    }
    response = requests.get(
        "https://peadmin.monsanto.net/ez-trac-qc/services/v1/people/all-teams-by-timeframe",
        params=params,
        cookies=cookie_jar,
        headers=headers,
    )

    if response.status_code != 200:
        logging.error(
            "Could not get monthly allocation: %s - %s"
            % (response.status_code, response.content)
        )
        return None

    effort_teams = response.json()["effortTeams"]
    return effort_teams


async def download_all_users(
    cookie_jar, timeframes_of_interest, bearer_token, headers, users, full_names
):
    user_allocations_df = pd.DataFrame(
        {
            "Employee": [],
            "Month": [],
            "Allocation": [],
            "ChargingTeamId": [],
            "ChargingTeamName": [],
        }
    )

    for user in tqdm(users, desc="Users"):
        if user[0] == "#":
            continue
        months = []
        percentages = []
        charging_team_ids = []
        charging_team_names = []

        # Resolve name to user ID
        full_name = get_full_name(user, bearer_token)
        full_names[user] = full_name

        tasks = []
        for tf_id in timeframes_of_interest:
            tf_name = timeframes_of_interest[tf_id]
            task = asyncio.ensure_future(
                get_monthly_allocation(cookie_jar, headers, tf_id, user)
            )
            tasks.append(task)

        effort_teams_list = await asyncio.gather(*tasks, return_exceptions=True)

        for effort_teams in effort_teams_list:
            if effort_teams:
                for effort_team in effort_teams:
                    month = timeframes_of_interest[effort_team["timeFrameId"]]
                    months.append(datetime.strptime(month, "%b %Y"))
                    percentages.append(effort_team["percent"])
                    charging_team_ids.append(effort_team["teamId"])
                    charging_team_names.append(effort_team["teamName"])
            else:
                logging.warning(
                    "Could not get allocations for '%s' in %s, skipping this period"
                    % (user, tf_name)
                )
        if len(months) > 0:
            overview_df = pd.DataFrame(
                {
                    "Month": months,
                    "Allocation": percentages,
                    "ChargingTeamId": charging_team_ids,
                    "ChargingTeamName": charging_team_names,
                }
            )

            last_update_time = datetime.now().isoformat(timespec="minutes")
            overview_df = overview_df.sort_values("ChargingTeamName", ascending=True)

            overview_df["Employee"] = full_name
            user_allocations_df = pd.concat([user_allocations_df, overview_df])
            try:
                (
                    so.Plot(
                        overview_df, x="Month", y="Allocation", color="ChargingTeamName"
                    )
                    .add(so.Bar(), so.Stack())
                    .label(
                        title="Allocation for %s (last update: %s)"
                        % (full_name, last_update_time),
                        xlab="Month in year",
                        ylab="Allocation in %",
                    )
                    .save("reports/%s" % user, bbox_inches="tight")
                )
            except Exception as e:
                logging.error("Could not plot for user %s " % user, exc_info=e)
        else:
            logging.error(f"Could not get allocation for user {user}")
    return user_allocations_df


if __name__ == "__main__":
    # Set up logging
    FORMAT = "%(asctime)s [%(name)s] [%(levelname)-5.8s]  %(message)s"
    logging_formatter = logging.Formatter(FORMAT, "%H:%M:%S")

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging_formatter)

    logging.basicConfig(level=logging.DEBUG, handlers=[console_handler])

    logging.info("Starting EZTrac team overview...")
    truststore.inject_into_ssl()

    # Get consent for reading out cookies
    logging.warning("All Edge instances will now be closed in order to restart it.")
    logging.warning(
        "This script will read out EZ Trac's cookies. It only uses them to authenticate you against EZTrac."
    )
    logging.warning(
        "If you are not OK with this, please press CTRL+C or CMD+C to abort. Otherwise press any key."
    )
    input()

    # Start EZtrac once so that cookies are up to date
    if os.name == "posix":
        kill_command = ["killall", "Microsoft\\ Edge"]
        start_binary = "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"
    else:
        kill_command = ["taskkill", "/F", "/im", "msedge.exe"]
        start_binary = (
            "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
        )
        subprocess.run(["taskkill", "/F", "/im", "excel.exe"])

    subprocess.run(kill_command)
    subprocess.Popen(
        [
            start_binary,
            "--disable-features=LockProfileCookieDatabase",
            "https://peadmin.monsanto.net/ez-trac-core/teams/",
        ]
    )

    wait_time_for_browser = 22
    logging.info("Wait for %d seconds for EZ trac to open up" % wait_time_for_browser)
    for _ in tqdm(range(wait_time_for_browser)):
        time.sleep(1)

    # Ensure that folder "reports/" exists
    newpath = r"reports"
    if not os.path.exists(newpath):
        os.makedirs(newpath)

    # Extract cookies from browser
    domain_to_extract = None
    try:
        cookie_jar = browser_cookie3.edge()
        logging.info("Extracted {} cookies from Edge".format(len(cookie_jar)))
    except PermissionError as e:
        logging.error(
            "Could not extract cookies from Edge. Ensure to start it --disable-features=LockProfileCookieDatabase.",
            e,
        )

    # Get all timeframes for this year
    logging.info("Get all time frames")
    timeframes_of_interest = get_timeframes(cookie_jar)
    if not timeframes_of_interest:
        print("No timeframes found")
        sys.exit(1)
    logging.debug(timeframes_of_interest)

    # Refresh the bearer token
    logging.info("Get bearer token")
    bearer_token = refresh_bearer_token(cookie_jar)

    # Prepare request for user allocation
    headers = get_eztrac_headers(bearer_token)

    # Load requested users
    with open("users.txt", "r", encoding="utf-8") as f:
        users = f.read().splitlines()
    full_names = {}

    user_allocations_df = asyncio.run(
        download_all_users(
            cookie_jar, timeframes_of_interest, bearer_token, headers, users, full_names
        )
    )

    user_allocations_df.set_index(["Employee", "Month"])
    # Write team report to Excel file
    last_update_time = datetime.now().isoformat(timespec="minutes")
    with pd.ExcelWriter("reports/Team Allocations.xlsx") as writer:
        user_allocations_df["Month"] = user_allocations_df["Month"].dt.strftime("%Y-%m")
        pivoted = user_allocations_df.pivot_table(
            values="Allocation", index=["Employee", "ChargingTeamName"], columns="Month"
        )
        pivoted.to_excel(writer)
        writer.book[writer.book.sheetnames[0]].append(
            ["Last update: %s" % last_update_time]
        )

    logging.info("Report created")
    input("Press any key to quit")
