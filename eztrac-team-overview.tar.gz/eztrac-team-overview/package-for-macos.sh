pipenv run pyinstaller --console --onefile eztrac-team-overview.py
touch dist/eztrac-team-overview/users.txt