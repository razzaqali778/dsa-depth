$venvDir = pipenv --venv
pipenv run pyinstaller --console --onefile --paths $venvDir .\eztrac-team-overview.py
touch .\dist\users.txt