EZTrac team overview
====================
Goal
----

In EZTrac you cannot see a complete overview of your team and their allocations for the whole year. It's helpful to have such an overview in order to check if you have all allocations correct and not missing any allocations, e.g. for leaves.
Having a tabular overview and maybe a graphical version would help to get a glance of your team's forecast.

This tool helps you to get this overview:

Show a list of many people across the year and details on the charging teams:
![Screenshot showing an Excel table with columns for each month of the year 2023 and rows for each charging team for an employee. The cell values show allocations in percent.](https://github.com/bayer-int/eztrac-team-overview/assets/230782/56016d09-5275-4588-bb1f-e16e8548b02f)

Additionally, it creates one plot for the whole year for each individual.
![Stacked bar plot showing allocations per month for 2023. All sum up to 100%](https://github.com/bayer-int/eztrac-team-overview/assets/230782/6f23f186-e2c0-4f9c-a1c3-c61f97cecd93)

Usage
-----

Download the release matching your operating system, extract the file.
Then add your CWIDs which you want to report on in the `users.txt` and start the executable.

Once the executable starts, you see a console window with a warning. The tool accesses your browser's cookies (Chrome) to authenticate yourself against EZTrac.
If that's not wanted, please abort the process. The cookies are not stored or processed differently.
At the same time, the EZTrac website is started, so that you have valid cookies for EZTrac in your browser.

After that, data for each user specified in the `users.txt` is collected and a graph is created.
At the end, an Excel report is created to show all individuals in one file. All files are put into a `reports` folder next to the executable.

Feedback is always welcome!

Installation
------------
1. Clone this repository
2. Install Python (3.10 or newer) and `pipenv`
3. `pipenv install` or `pipenv install --dev`

Packaging
---------

If you want to create a release or portable executable, use one of the two scripts depending on the operating system

Prepare your `pipenv` as described above

* Windows: Open PowerShell and execute `package-for-windows.ps1`.
* MacOS: Open a terminal and execute `package-for-macos.sh`

The scripts should take care of everything and create the executable including `users.txt` in the folder `dist`.

Open aspects
------------
* [ ] Maintain the same colors for the same charging team
