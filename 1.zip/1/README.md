# Flex — Cloud FinOps Platform & Browser Extension

**Flex** (formerly **FinOps**) is a demo-ready platform for cloud usage, resource allocation, anomaly detection, and **governed data exchange** with:

- **EzTrac** — finance forecasting (desktop)
- **dhub-rpt** — resource planning

![Flex](apps/flex/public/flex-icon.svg)

## Quick start (demo)

### 1. Install dependencies

```bash
cd /mnt/c/Users/razza/Downloads/test/test
npm install
```

### 2. Run Flex host app (development)

```bash
npm run dev
```

Open http://localhost:5173

### 3. Run partner apps (separate sites)

```bash
npm run api          # http://localhost:3847 (required for cross-port plugin calls)
npm run dev:eztrac   # http://localhost:5174
npm run dev:rpt      # http://localhost:5175
```

Or run all three:

```bash
npm run dev:all
```

### 4. Build & load Chrome extension (recommended for demo)

```bash
npm run build
```

Then in Chrome:

1. Open `chrome://extensions`
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select the folder: `extensions/chrome/`
5. Click the Flex toolbar icon → **quick-view popup** (KPIs + shortcuts)
6. In popup, click **Open command center** → **side panel** with full UI

> Run `node scripts/generate-icons.js` first if icons are missing.

## What's new (v2.0)

| Area | Feature |
|------|---------|
| **Finance** | [Chargeback & Showback](/chargeback) — team spend vs budget, tag compliance |
| **Finance** | Savings lifecycle — identified → approved → implementing → realized |
| **Finance** | Proof-of-governance audit bundle (JSON + markdown) in Settings |
| **HR / Planning** | [Workforce × Infrastructure](/workforce) — squad capacity, hiring signals |
| **Governance** | RBAC-lite (Finance / Platform / Admin / Viewer) |
| **Governance** | Approval impact preview + field boundary on publish + 8s undo |
| **DevOps** | Anomaly incident stories (deploy + transfer correlation) |
| **Extension** | Page Sense chip on AWS/Azure/GCP consoles |
| **Extension** | Predictive badge (`3·$4K` risk) + Slack approval demo |
| **AI** | Intent command palette (⌘K) + chat-to-action with undo |

See [HLD](docs/HLD.md) and [LLD](docs/LLD.md) for full architecture.

## Extension highlights (v1.2)

| Feature | Description |
|---------|-------------|
| **FinOps Insights** | Savings opportunities ($23K+/mo) + smart recommendations |
| **Activity & Audit** | Unified timeline of transfers, requests, anomalies |
| **Global search** | `⇧⌘F` — search initiatives, squads, datasets, anomalies |
| **Quick actions** | One-click approve, publish, EzTrac sync from dashboard |
| **Executive export** | Copy/download markdown report (Settings) |
| **Presentation mode** | Cleaner demo UI with banner |
| **Context menu** | Right-click → Open Flex / Insights / AI |
| **Enhanced popup** | Savings banner + Insights/Activity shortcuts |

## Extension highlights (v1.1)

| Feature | Description |
|---------|-------------|
| **Quick popup** | Spend, utilization, pending count, recent transfers at a glance |
| **Toolbar badge** | Shows pending approval count (or `!` for anomalies) |
| **Side panel** | Full Flex app optimized for narrow width (icon nav) |
| **⌘K / Ctrl+K** | Command palette — jump to any page or simulate sync |
| **Keyboard shortcuts** | `Alt+Shift+D` dashboard, `E` exchange, `A` AI (configure in `chrome://extensions/shortcuts`) |
| **Desktop notifications** | New approval requests and completed transfers |
| **Live top bar** | Sync indicator, open full tab, command palette |
| **Welcome guide** | First-run tips inside the side panel |

## Features

| Area | Description |
|------|-------------|
| **Dashboard** | KPIs, usage trend, anomalies, pending approvals |
| **Chargeback** | Team showback, cost centers, tag compliance |
| **Workforce** | Squad × cloud cost, hiring/reallocate signals |
| **Cloud Usage** | Category breakdown, forecast vs budget |
| **Resources** | Allocation vs utilization by team |
| **Anomalies** | Severity, status, resolve workflow |
| **Data Exchange** | Approve/reject inbound; publish outbound datasets |
| **Integrations** | Simulate EzTrac / dhub-rpt sync → new approval requests |
| **Flex AI** | RAG assistant over Flex + EzTrac + dhub-rpt knowledge |
| **Settings** | Governance toggles |

## Demo script (5 minutes)

1. Open extension side panel → review **Dashboard** KPIs.
2. Go to **Integrations** → click **Simulate inbound data request** on EzTrac.
3. Open **Data Exchange** → **Approve** the new request.
4. **Anomalies** → resolve one open item.
5. **Data Exchange** → **Publish** the draft `anomaly_feed` dataset.
6. **Resources** → show allocation data published to dhub-rpt.

## Project structure

```
apps/flex/                    Flex global web app and plugin host
apps/eztrac/                  EzTrac standalone app consuming Flex plugins
apps/rpt/                     RPT standalone app consuming Flex plugins
apps/flex/src/plugins/        Core, partner, and marketplace plugin runtime
extensions/chrome/            Chrome MV3 extension source
extensions/vscode/            VS Code extension source; `.vsix` is build output
packages/flex-plugin-sdk/     SDK for EzTrac, dhub-rpt, scripts, and tools
packages/plugin-manifests/    Sample `.flexext.json` plugin packages
services/flex-api/            Local REST bridge for VS Code/Node demos
```

## Documentation

- [High-Level Design (HLD)](docs/HLD.md)
- [Low-Level Design (LLD)](docs/LLD.md)
- [Plugin API](docs/PLUGINS.md) — core APIs + **installable extensions** (marketplace) and `flex-plugin-sdk`
- [Repository Organization](docs/REPO_ORGANIZATION.md) — app vs plugin vs extension vs VSIX boundaries

## Tech stack

- React 18, TypeScript, Vite, Tailwind CSS, Recharts
- Chrome Extension Manifest V3 (side panel)

## Notes

- All cloud and partner data is **dummy/mock** for demonstration.
- State persists in `localStorage` under key `flex_state_v1`.
- Production would add REST APIs, OAuth, and live EzTrac/dhub-rpt connectors (see LLD).
