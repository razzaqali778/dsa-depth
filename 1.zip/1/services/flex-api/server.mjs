import cors from 'cors';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { catalog, consume, produce } from './pluginApi.mjs';
import {
  getMarketplacePluginVersions,
  installMarketplacePlugin,
  listAppInstallations,
  searchMarketplacePlugins,
  uninstallMarketplacePlugin,
} from './marketplaceRegistry.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.FLEX_API_PORT ?? 3847);
const STATE_FILE = process.env.FLEX_STATE_FILE ?? path.join(__dirname, 'runtime-state.json');
const SEED_FILE = path.join(__dirname, 'seed-state.json');

let state = loadState();

function normalizePartnerAppId(value) {
  const appId = String(value ?? '').trim();
  if (appId === 'eztrac') return 'eztrac';
  if (appId === 'rpt' || appId === 'dhub-rpt') return 'rpt';
  return '';
}

function publishedPlugins() {
  return Array.isArray(state.partnerMarketplacePublished) ? state.partnerMarketplacePublished : [];
}

function installedByApp() {
  return state.partnerInstalledByApp && typeof state.partnerInstalledByApp === 'object'
    ? state.partnerInstalledByApp
    : {};
}

function installedForApp(appId) {
  const byApp = installedByApp();
  const aliases = appId === 'rpt' ? ['rpt', 'dhub-rpt'] : [appId];
  return Array.from(
    new Set(aliases.flatMap((key) => (Array.isArray(byApp[key]) ? byApp[key] : [])))
  );
}

function setInstalledForApp(appId, pluginIds) {
  const byApp = installedByApp();
  byApp[appId] = Array.from(new Set(pluginIds));
  if (appId === 'rpt') delete byApp['dhub-rpt'];
  state.partnerInstalledByApp = byApp;
  return byApp[appId];
}

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    }
  } catch {
    /* ignore */
  }
  try {
    return JSON.parse(fs.readFileSync(SEED_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function saveState() {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

const app = express();
app.use(cors());
app.use(express.json({ limit: '4mb' }));

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'flex-api', port: PORT });
});

app.get('/api/v1/state', (_req, res) => {
  res.json(state);
});

app.post('/api/v1/sync', (req, res) => {
  if (!req.body || typeof req.body !== 'object') {
    res.status(400).json({ ok: false, error: 'Expected Flex state JSON' });
    return;
  }
  const integrationState = {
    partnerMarketplacePublished: state.partnerMarketplacePublished,
    partnerInstalledByApp: state.partnerInstalledByApp,
  };
  state = { ...req.body, ...integrationState };
  saveState();
  res.json({ ok: true, message: 'State synced from Flex app' });
});

app.get('/api/v1/catalog', (_req, res) => {
  res.json(catalog());
});

app.get('/api/v1/plugins/search', (req, res) => {
  res.json(
    searchMarketplacePlugins({
      q: typeof req.query.q === 'string' ? req.query.q : '',
      category: typeof req.query.category === 'string' ? req.query.category : '',
    })
  );
});

app.get('/api/v1/plugins/:id/versions', (req, res) => {
  const versions = getMarketplacePluginVersions(req.params.id);
  if (!versions) {
    res.status(404).json({ ok: false, error: 'Plugin not found' });
    return;
  }
  res.json(versions);
});

app.get('/api/v1/apps/:appId/installations', (req, res) => {
  res.json(listAppInstallations(req.params.appId));
});

app.post('/api/v1/apps/:appId/installations', (req, res) => {
  const pluginId = String(req.body?.pluginId ?? '').trim();
  const version = req.body?.version == null ? undefined : String(req.body.version).trim();
  if (!pluginId) {
    res.status(400).json({ ok: false, error: 'pluginId is required' });
    return;
  }
  const result = installMarketplacePlugin(req.params.appId, pluginId, version);
  if (!result.ok) {
    res.status(result.status).json({ ok: false, error: result.error });
    return;
  }
  res.status(201).json(result.installation);
});

app.delete('/api/v1/apps/:appId/installations/:pluginId', (req, res) => {
  const result = uninstallMarketplacePlugin(req.params.appId, req.params.pluginId);
  if (!result.ok) {
    res.status(result.status).json({ ok: false, error: result.error });
    return;
  }
  res.status(204).send();
});

app.get('/api/v1/partner-marketplace', (req, res) => {
  const appId = normalizePartnerAppId(req.query.app);
  if (!appId) {
    res.status(400).json({ ok: false, error: 'query param app is required' });
    return;
  }
  res.json(
    publishedPlugins().filter((row) => normalizePartnerAppId(row.targetApp) === appId)
  );
});

app.get('/api/v1/partner-marketplace/installed', (req, res) => {
  const appId = normalizePartnerAppId(req.query.app);
  if (!appId) {
    res.status(400).json({ ok: false, error: 'query param app is required' });
    return;
  }
  res.json(installedForApp(appId));
});

app.post('/api/v1/partner-marketplace/publish', (req, res) => {
  const body = req.body ?? {};
  const pluginId = String(body.pluginId ?? '').trim();
  const name = String(body.name ?? pluginId).trim();
  const targetApp = normalizePartnerAppId(body.targetApp);
  const version = String(body.version ?? '1.0.0').trim();
  const description = String(body.description ?? '').trim();
  const publisher = String(body.publisher ?? 'Flex').trim();
  const icon = typeof body.icon === 'string' ? body.icon : '';
  const category = typeof body.category === 'string' ? body.category : 'tools';
  const kind = body.kind === 'extension' ? 'extension' : 'core';
  const permissions = Array.isArray(body.permissions) ? body.permissions.map(String) : [];
  const datasets = Array.isArray(body.datasets) ? body.datasets : [];

  if (!pluginId || !targetApp) {
    res.status(400).json({ ok: false, error: 'pluginId and targetApp are required' });
    return;
  }

  const published = publishedPlugins();
  const nextPublished = published.filter(
    (row) => !(row.pluginId === pluginId && normalizePartnerAppId(row.targetApp) === targetApp)
  );
  const plugin = {
    pluginId,
    name,
    targetApp,
    version,
    description,
    publisher,
    icon,
    category,
    kind,
    permissions,
    datasets,
    publishedAt: new Date().toISOString(),
  };
  nextPublished.push(plugin);
  state.partnerMarketplacePublished = nextPublished;

  saveState();
  res.json({ ok: true, plugin, message: 'Plugin published to partner marketplace' });
});

app.post('/api/v1/partner-marketplace/install', (req, res) => {
  const appId = normalizePartnerAppId(req.body?.app);
  const pluginId = String(req.body?.pluginId ?? '').trim();
  if (!appId || !pluginId) {
    res.status(400).json({ ok: false, error: 'app and pluginId are required' });
    return;
  }
  const available = publishedPlugins().some(
    (row) => row.pluginId === pluginId && normalizePartnerAppId(row.targetApp) === appId
  );
  if (!available) {
    res.status(404).json({ ok: false, error: 'Plugin is not published to this partner marketplace' });
    return;
  }
  const installed = installedForApp(appId);
  const nextInstalled = installed.includes(pluginId) ? installed : [...installed, pluginId];
  setInstalledForApp(appId, nextInstalled);
  saveState();
  res.json({ ok: true, app: appId, pluginId, installed: nextInstalled });
});

app.post('/api/v1/partner-marketplace/uninstall', (req, res) => {
  const appId = normalizePartnerAppId(req.body?.app);
  const pluginId = String(req.body?.pluginId ?? '').trim();
  if (!appId || !pluginId) {
    res.status(400).json({ ok: false, error: 'app and pluginId are required' });
    return;
  }
  const nextInstalled = installedForApp(appId).filter((id) => id !== pluginId);
  setInstalledForApp(appId, nextInstalled);
  saveState();
  res.json({ ok: true, app: appId, pluginId, installed: nextInstalled });
});

app.post('/api/v1/consume', (req, res) => {
  const result = consume(state, req.body ?? {});
  if (result.ok === false) {
    res.status(400).json(result);
    return;
  }
  res.json(result);
});

app.post('/api/v1/produce', (req, res) => {
  const result = produce(state, req.body ?? {});
  saveState();
  res.json(result);
});

app.listen(PORT, () => {
  console.log(`Flex API listening on http://localhost:${PORT}`);
  console.log(`  Health:  GET  /health`);
  console.log(`  Plugins: POST /api/v1/consume | /api/v1/produce`);
  console.log(`  Sync:    POST /api/v1/sync (from Flex web app)`);
});
