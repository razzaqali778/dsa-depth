import React, { useCallback, useEffect, useMemo, useState } from 'react';
import ReactDOM from 'react-dom/client';
import { ArrowUpRight, CheckCircle2, Database, Download, RefreshCw, Search, Send, Trash2 } from 'lucide-react';
import { createPartnerPluginClient } from 'flex-plugin-sdk';
import './styles.css';

type DatasetDirection = 'inbound' | 'outbound' | 'bidirectional';

interface PluginDataset {
  name: string;
  description: string;
  direction: DatasetDirection;
}

interface PublishedPlugin {
  pluginId: string;
  name: string;
  version: string;
  description: string;
  icon?: string;
  category?: string;
  permissions?: string[];
  datasets?: PluginDataset[];
}

const client = createPartnerPluginClient('eztrac', {
  apiUrl: 'http://localhost:3847',
});

const APP_NAME = 'EzTrac';
const SOURCE_APP = 'eztrac';
const REQUEST_DATASET = 'forecast_variance';
const MARKETPLACE_URL = 'http://localhost:5176/';

function datasetsFor(plugin: PublishedPlugin): PluginDataset[] {
  return Array.isArray(plugin.datasets) ? plugin.datasets : [];
}

function sampleRecords(pluginId: string, dataset: string) {
  if (dataset === 'inbound_request') {
    return [
      {
        fromApp: SOURCE_APP,
        dataset: REQUEST_DATASET,
        recordCount: 1200,
        purpose: 'Monthly forecast variance reconciliation',
      },
    ];
  }
  if (dataset === 'request_sync' || dataset === 'pull_published' || dataset === 'simulate_inbound_sync') {
    return [{ partner: SOURCE_APP }];
  }
  if (dataset === 'update_budget') {
    return [{ id: 'team-platform', budget: 420000, owner: 'Platform Finance' }];
  }
  return [{ source: SOURCE_APP, pluginId }];
}

function directionText(direction: DatasetDirection) {
  if (direction === 'inbound') return 'Sends to Flex';
  if (direction === 'bidirectional') return 'Read + send';
  return 'Reads Flex';
}

function PluginCard({
  plugin,
  installed,
  busy,
  onInstall,
  onUninstall,
  onRead,
  onSend,
}: {
  plugin: PublishedPlugin;
  installed: boolean;
  busy: boolean;
  onInstall: () => void;
  onUninstall: () => void;
  onRead: (dataset: string) => void;
  onSend: (dataset: string) => void;
}) {
  const datasets = datasetsFor(plugin);
  const readDatasets = datasets.filter((dataset) => dataset.direction !== 'inbound');
  const sendDatasets = datasets.filter((dataset) => dataset.direction !== 'outbound');

  return (
    <article className="plugin-card">
      <div className="plugin-head">
        <span className="plugin-icon" aria-hidden>{plugin.icon || 'Fx'}</span>
        <div className="plugin-title">
          <div className="title-row">
            <h3>{plugin.name}</h3>
            <span className={installed ? 'badge good' : 'badge'}>{installed ? 'Installed' : `v${plugin.version}`}</span>
          </div>
          <p>{plugin.pluginId}</p>
        </div>
      </div>

      <p className="description">{plugin.description}</p>

      <div className="chips">
        {plugin.category && <span className="badge">{plugin.category}</span>}
        {sendDatasets.length > 0 && <span className="badge warn">Can send to Flex</span>}
        {(plugin.permissions ?? []).slice(0, 2).map((permission) => (
          <span className="badge" key={permission}>{permission}</span>
        ))}
      </div>

      <div className="dataset-list">
        {datasets.slice(0, 5).map((dataset) => (
          <div className="dataset" key={dataset.name}>
            <span>{dataset.description || dataset.name}</span>
            <strong>{directionText(dataset.direction)}</strong>
          </div>
        ))}
        {datasets.length === 0 && <div className="dataset"><span>No dataset metadata</span><strong>metadata</strong></div>}
      </div>

      <div className="plugin-actions">
        {installed ? (
          <button className="btn danger" disabled={busy} type="button" onClick={onUninstall}>
            <Trash2 size={16} /> Uninstall
          </button>
        ) : (
          <button className="btn primary" disabled={busy} type="button" onClick={onInstall}>
            <Download size={16} /> Install
          </button>
        )}
        {installed && readDatasets.slice(0, 2).map((dataset) => (
          <button className="btn" disabled={busy} key={dataset.name} type="button" onClick={() => onRead(dataset.name)}>
            <Database size={16} /> Read
          </button>
        ))}
        {installed && sendDatasets.slice(0, 2).map((dataset) => (
          <button className="btn send" disabled={busy} key={dataset.name} type="button" onClick={() => onSend(dataset.name)}>
            <Send size={16} /> Send to Flex
          </button>
        ))}
      </div>
    </article>
  );
}

function App() {
  const [plugins, setPlugins] = useState<PublishedPlugin[]>([]);
  const [installed, setInstalled] = useState<string[]>([]);
  const [search, setSearch] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [output, setOutput] = useState<unknown>(null);

  const reload = useCallback(async () => {
    setBusy(true);
    setError(null);
    try {
      const [published, installedIds] = await Promise.all([
        client.listPublishedPlugins() as Promise<PublishedPlugin[]>,
        client.listInstalledPluginsRemote(),
      ]);
      setPlugins(published);
      setInstalled(installedIds);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load plugins');
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const installedSet = useMemo(() => new Set(installed), [installed]);
  const installedPlugins = plugins.filter((plugin) => installedSet.has(plugin.pluginId));
  const filtered = plugins.filter((plugin) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (
      plugin.name.toLowerCase().includes(q) ||
      plugin.description.toLowerCase().includes(q) ||
      plugin.pluginId.toLowerCase().includes(q)
    );
  });

  async function install(pluginId: string) {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const next = await client.installPublishedPlugin(pluginId);
      setInstalled(next);
      setMessage(`Installed ${pluginId}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Install failed');
    } finally {
      setBusy(false);
    }
  }

  async function uninstall(pluginId: string) {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const next = await client.uninstallPublishedPlugin(pluginId);
      setInstalled(next);
      setMessage(`Uninstalled ${pluginId}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Uninstall failed');
    } finally {
      setBusy(false);
    }
  }

  async function runRead(pluginId: string, dataset: string) {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const result = await client.consume({ pluginId, dataset });
      setOutput(result);
      setMessage(`Read ${dataset} from Flex`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Read failed');
    } finally {
      setBusy(false);
    }
  }

  async function runSend(pluginId: string, dataset: string) {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const result = await client.produce({
        pluginId,
        dataset,
        records: sampleRecords(pluginId, dataset),
        destinationApp: 'flex',
      });
      setOutput(result);
      setMessage(`Sent ${dataset} to Flex`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Send failed');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="app-shell">
      <header className="app-header">
        <div>
          <p className="eyebrow">Partner application</p>
          <h1>{APP_NAME} Plugins</h1>
          <p className="header-copy">Install marketplace plugins, read Flex datasets, and send governed requests back to Flex.</p>
        </div>
        <div className="header-actions">
          <a className="btn" href={MARKETPLACE_URL} target="_blank" rel="noreferrer">
            Marketplace <ArrowUpRight size={16} />
          </a>
          <button className="btn" disabled={busy} type="button" onClick={() => void reload()}>
            <RefreshCw size={16} /> Refresh
          </button>
        </div>
      </header>

      <section className="summary-grid">
        <div className="summary-card">
          <span>Available plugins</span>
          <strong>{plugins.length}</strong>
        </div>
        <div className="summary-card">
          <span>Installed</span>
          <strong>{installed.length}</strong>
        </div>
        <div className="summary-card">
          <span>Can send to Flex</span>
          <strong>{plugins.filter((plugin) => datasetsFor(plugin).some((dataset) => dataset.direction !== 'outbound')).length}</strong>
        </div>
      </section>

      <section className="installed-panel">
        <div>
          <h2>Installed in {APP_NAME}</h2>
          <p>These plugins are active for this app.</p>
        </div>
        <div className="installed-list">
          {installedPlugins.length === 0 ? (
            <span className="empty-inline">No plugins installed</span>
          ) : (
            installedPlugins.map((plugin) => (
              <span className="installed-pill" key={plugin.pluginId}>
                <CheckCircle2 size={14} /> {plugin.name}
              </span>
            ))
          )}
        </div>
      </section>

      <label className="search-box">
        <Search size={16} />
        <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search available plugins" />
      </label>

      {message && <p className="notice good">{message}</p>}
      {error && <p className="notice error">{error}. Publish plugins from Flex or use the marketplace first.</p>}

      <section className="plugin-grid">
        {filtered.map((plugin) => (
          <PluginCard
            key={plugin.pluginId}
            plugin={plugin}
            installed={installedSet.has(plugin.pluginId)}
            busy={busy}
            onInstall={() => void install(plugin.pluginId)}
            onUninstall={() => void uninstall(plugin.pluginId)}
            onRead={(dataset) => void runRead(plugin.pluginId, dataset)}
            onSend={(dataset) => void runSend(plugin.pluginId, dataset)}
          />
        ))}
        {filtered.length === 0 && (
          <div className="empty-state">
            <h2>No plugins available</h2>
            <p>Open Flex Publisher, publish plugins to EzTrac, then refresh this page.</p>
          </div>
        )}
      </section>

      <section className="output-panel">
        <h2>Plugin response</h2>
        <pre>{output ? JSON.stringify(output, null, 2) : 'Run a plugin action to see the response.'}</pre>
      </section>
    </main>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
