import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  Code2,
  Database,
  Package,
  Play,
  Radio,
  RefreshCw,
  Send,
} from 'lucide-react';
import { Badge } from '../../components/Badge';
import {
  getStoredFlexUrl,
  openFlexWindow,
  partnerCatalog,
  partnerConsume,
  partnerProduce,
  setStoredFlexUrl,
} from '../../lib/flexPartnerClient';
import {
  installAllPublishedPartnerPlugins,
  installPartnerPlugin as installPublishedPartnerPlugin,
  listInstalledPartnerPlugins,
  listPublishedPartnerPlugins,
  partnerDisplayName,
  uninstallPartnerPlugin as uninstallPublishedPartnerPlugin,
  type PublishedPartnerPlugin,
} from '../../lib/partnerMarketplace';
import { PLUGIN_PRESETS, type PluginPreset } from '../../lib/pluginPresets';
import type {
  PluginCatalogEntry,
  PluginConsumeResult,
  PluginDataset,
  PluginProduceResult,
} from '../../plugins/types';

export type PartnerId = 'eztrac' | 'dhub-rpt';

const PARTNER_META: Record<
  PartnerId,
  { title: string; subtitle: string; accent: string; border: string; badge: string }
> = {
  eztrac: {
    title: 'EzTrac',
    subtitle: 'Finance & variance — consumes Flex via plugins only',
    accent: 'text-emerald-400',
    border: 'border-emerald-500/30',
    badge: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
  },
  'dhub-rpt': {
    title: 'dhub-rpt',
    subtitle: 'Planning & capacity — consumes Flex via plugins only',
    accent: 'text-violet-400',
    border: 'border-violet-500/30',
    badge: 'bg-violet-500/15 text-violet-300 border-violet-500/40',
  },
};

function presetForPartner(p: PluginPreset, partner: PartnerId): boolean {
  if (p.id.includes('eztrac') && partner !== 'eztrac') return false;
  if (p.id.includes('dhub') && partner !== 'dhub-rpt') return false;
  if (p.kind === 'get' && p.dataset === 'consumption_status') return true;
  if (p.kind === 'send' && p.sendForm === 'partner-sync') {
    return p.id.includes(partner === 'eztrac' ? 'eztrac' : 'dhub');
  }
  if (p.kind === 'send' && p.id.includes('eztrac') && partner !== 'eztrac') return false;
  if (p.kind === 'send' && p.id.includes('dhub') && partner !== 'dhub-rpt') return false;
  return true;
}

function partnerPluginId(partner: PartnerId): 'flex.partner.eztrac' | 'flex.partner.dhub-rpt' {
  return partner === 'eztrac' ? 'flex.partner.eztrac' : 'flex.partner.dhub-rpt';
}

function partnerDefaultDataset(partner: PartnerId): string {
  return partner === 'eztrac' ? 'forecast_variance' : 'capacity_forecast';
}

function jsonBlock(value: unknown): string {
  return JSON.stringify(value, null, 2);
}

function defaultConsumeJson(partner: PartnerId): string {
  return jsonBlock({
    pluginId: partnerPluginId(partner),
    dataset: 'consumption_status',
  });
}

function defaultProduceJson(partner: PartnerId): string {
  return jsonBlock({
    pluginId: partnerPluginId(partner),
    dataset: 'inbound_request',
    records: [
      {
        fromApp: partner,
        dataset: partnerDefaultDataset(partner),
        recordCount: 800,
        purpose: `Manual plugin test from ${partner}`,
      },
    ],
    sourceApp: partner,
  });
}

function pluginDatasets(
  pluginId: string,
  published: PublishedPartnerPlugin[],
  catalog: PluginCatalogEntry[]
): PluginDataset[] {
  return (
    catalog.find((entry) => entry.id === pluginId)?.datasets ??
    published.find((entry) => entry.pluginId === pluginId)?.datasets ??
    []
  );
}

function isReadableDataset(dataset: PluginDataset): boolean {
  return (
    dataset.direction === 'outbound' ||
    dataset.direction === 'bidirectional' ||
    dataset.name === 'data_requests'
  );
}

function isWritableDataset(dataset: PluginDataset): boolean {
  if (dataset.name === 'data_requests') return false;
  return dataset.direction === 'inbound' || dataset.direction === 'bidirectional';
}

function consumeParamsForDataset(partner: PartnerId, pluginId: string, dataset: string) {
  if (pluginId === 'flex.integrations' && dataset === 'partner_consumption') {
    return { partner };
  }
  return undefined;
}

function demoRecordsForPartnerDataset(partner: PartnerId, pluginId: string, dataset: string): unknown[] {
  if (dataset === 'simulate_inbound_sync' || dataset === 'request_sync') return [{ partner }];
  if (dataset === 'pull_outbound' || dataset === 'pull_published') return [{ partner }];
  if (dataset === 'inbound_request') {
    return [
      {
        fromApp: partner,
        dataset: partnerDefaultDataset(partner),
        recordCount: 800,
        purpose: `Marketplace plugin test from ${partnerDisplayName(partner)}`,
      },
    ];
  }
  if (dataset === 'create_ticket') return [{ anomalyId: 'a1', projectKey: 'FIN', assignee: 'finops' }];
  if (dataset === 'trigger_page') return [{ anomalyId: 'a1', routingKey: 'demo', urgency: 'high' }];
  if (dataset === 'post_message') {
    return [{ channel: '#finops-alerts', title: 'Flex plugin update', body: 'Partner sent a plugin message', severity: 'info' }];
  }
  if (dataset === 'preferences') return [{ meetingMode: true }];
  if (dataset === 'advance_stage') return [{ id: 's1' }];
  if (dataset === 'resolve_anomaly') return [{ id: 'a1' }];
  if (dataset === 'create_anomaly') {
    return [{
      title: `Partner-reported signal from ${partnerDisplayName(partner)}`,
      severity: 'medium',
      service: partner === 'eztrac' ? 'Forecasting' : 'Capacity',
      detectedAt: new Date().toISOString(),
      impact: 'Needs Flex admin review',
      status: 'open',
      deltaPercent: 12,
    }];
  }
  if (dataset === 'update_budget') return [{ id: 'cb1', budget: 150000 }];
  if (dataset === 'acknowledge_signal') return [{ id: 'wf1' }];
  if (dataset === 'resolve_conflict') return [{ id: 'a4' }];
  return [{ partner, pluginId }];
}

export function PartnerExternalApp({ partner }: { partner: PartnerId }) {
  const meta = PARTNER_META[partner];
  const pluginId = partnerPluginId(partner);
  const [connected, setConnected] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<unknown>(null);
  const [error, setError] = useState<string | null>(null);
  const [recordCount, setRecordCount] = useState(800);
  const [purpose, setPurpose] = useState(`Data refresh from ${meta.title}`);
  const [consumeJson, setConsumeJson] = useState(() => defaultConsumeJson(partner));
  const [produceJson, setProduceJson] = useState(() => defaultProduceJson(partner));
  const [flexUrl, setFlexUrl] = useState(() => getStoredFlexUrl());
  const [publishedPlugins, setPublishedPlugins] = useState<PublishedPartnerPlugin[]>([]);
  const [installedPluginIds, setInstalledPluginIds] = useState<string[]>([]);
  const [marketplaceBusy, setMarketplaceBusy] = useState(false);
  const [marketplaceError, setMarketplaceError] = useState<string | null>(null);
  const [remoteCatalog, setRemoteCatalog] = useState<PluginCatalogEntry[]>([]);

  const installedSet = useMemo(() => new Set(installedPluginIds), [installedPluginIds]);
  const getPresets = useMemo(
    () => PLUGIN_PRESETS.filter((p) => p.kind === 'get' && presetForPartner(p, partner) && installedSet.has(p.pluginId)),
    [installedSet, partner]
  );
  const check = useCallback(async () => {
    try {
      const catalog = (await partnerCatalog()) as PluginCatalogEntry[];
      setRemoteCatalog(catalog);
      setConnected(true);
      return true;
    } catch {
      setConnected(false);
      return false;
    }
  }, []);

  const refreshMarketplace = useCallback(async () => {
    setMarketplaceBusy(true);
    setMarketplaceError(null);
    try {
      const [published, installed] = await Promise.all([
        listPublishedPartnerPlugins(partner),
        listInstalledPartnerPlugins(partner),
      ]);
      setPublishedPlugins(published);
      setInstalledPluginIds(installed);
    } catch (e) {
      setMarketplaceError(
        e instanceof Error ? e.message : 'Could not load partner marketplace'
      );
    } finally {
      setMarketplaceBusy(false);
    }
  }, [partner]);

  useEffect(() => {
    void check();
    const t = setInterval(() => void check(), 5000);
    return () => clearInterval(t);
  }, [check]);

  useEffect(() => {
    void refreshMarketplace();
  }, [refreshMarketplace]);

  useEffect(() => {
    setConsumeJson(defaultConsumeJson(partner));
    setProduceJson(defaultProduceJson(partner));
    setPurpose(`Data refresh from ${meta.title}`);
    setResult(null);
    setError(null);
  }, [meta.title, partner]);

  const installPublishedPlugin = async (targetPluginId: string) => {
    setMarketplaceBusy(true);
    setError(null);
    try {
      const installed = await installPublishedPartnerPlugin(partner, targetPluginId);
      setInstalledPluginIds(installed);
      setResult({ ok: true, pluginId: targetPluginId, message: `${targetPluginId} installed in ${meta.title}` });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Install failed');
    } finally {
      setMarketplaceBusy(false);
    }
  };

  const uninstallPublishedPlugin = async (targetPluginId: string) => {
    setMarketplaceBusy(true);
    setError(null);
    try {
      const installed = await uninstallPublishedPartnerPlugin(partner, targetPluginId);
      setInstalledPluginIds(installed);
      setResult({ ok: true, pluginId: targetPluginId, message: `${targetPluginId} uninstalled from ${meta.title}` });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Uninstall failed');
    } finally {
      setMarketplaceBusy(false);
    }
  };

  const installAllPlugins = async () => {
    setMarketplaceBusy(true);
    setError(null);
    try {
      const installed = await installAllPublishedPartnerPlugins(
        partner,
        publishedPlugins.map((item) => item.pluginId)
      );
      setInstalledPluginIds(installed);
      setResult({ ok: true, pluginId: '*', message: `Installed ${installed.length} plugin(s) in ${meta.title}` });
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Install all failed');
    } finally {
      setMarketplaceBusy(false);
    }
  };

  const requireInstalled = (targetPluginId: string = pluginId): boolean => {
    if (installedSet.has(targetPluginId)) return true;
    setError(`Install ${targetPluginId} in ${meta.title} before consume or produce.`);
    return false;
  };

  const connectFlex = async () => {
    setError(null);
    const win = openFlexWindow(flexUrl);
    if (!win) {
      setError('Browser blocked the Flex window. Allow popups, then retry.');
      setConnected(false);
      return;
    }
    setStoredFlexUrl(flexUrl);
    setTimeout(() => void check(), 600);
  };

  const runGet = async (preset: PluginPreset) => {
    if (!requireInstalled(preset.pluginId)) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab (same browser), then retry.');
        return;
      }
      const params = preset.params;
      const out = await partnerConsume({
        pluginId: preset.pluginId,
        dataset: preset.dataset,
        params,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Consume failed');
    } finally {
      setBusy(false);
    }
  };

  const runSync = async () => {
    if (!requireInstalled(partnerPluginId(partner))) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const out = await partnerProduce({
        pluginId: partnerPluginId(partner),
        dataset: 'request_sync',
        records: [{ partner }],
        sourceApp: partner,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Produce failed');
    } finally {
      setBusy(false);
    }
  };

  const runInbound = async () => {
    if (!requireInstalled(partnerPluginId(partner))) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const dataset = partner === 'eztrac' ? 'forecast_variance' : 'capacity_forecast';
      const out = await partnerProduce({
        pluginId: partnerPluginId(partner),
        dataset: 'inbound_request',
        records: [
          {
            fromApp: partner,
            dataset,
            recordCount,
            purpose,
          },
        ],
        sourceApp: partner,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Produce failed');
    } finally {
      setBusy(false);
    }
  };

  const runPull = async () => {
    if (!requireInstalled(partnerPluginId(partner))) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const out = await partnerProduce({
        pluginId: partnerPluginId(partner),
        dataset: 'pull_published',
        records: [{ partner }],
        sourceApp: partner,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Produce failed');
    } finally {
      setBusy(false);
    }
  };

  const runManualConsume = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const payload = JSON.parse(consumeJson) as {
        pluginId?: string;
        dataset?: string;
        params?: Record<string, unknown>;
      };
      if (!payload.pluginId) throw new Error('consume JSON must include pluginId');
      if (!requireInstalled(payload.pluginId)) return;
      const out = await partnerConsume({
        pluginId: payload.pluginId,
        dataset: payload.dataset,
        params: payload.params,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Manual consume failed');
    } finally {
      setBusy(false);
    }
  };

  const runManualProduce = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const payload = JSON.parse(produceJson) as {
        pluginId?: string;
        dataset?: string;
        records?: unknown[];
        sourceApp?: PartnerId;
        metadata?: Record<string, unknown>;
      };
      if (!payload.pluginId) throw new Error('produce JSON must include pluginId');
      if (!payload.dataset) throw new Error('produce JSON must include dataset');
      if (!Array.isArray(payload.records)) throw new Error('produce JSON must include records array');
      if (!requireInstalled(payload.pluginId)) return;
      const out = await partnerProduce({
        pluginId: payload.pluginId,
        dataset: payload.dataset,
        records: payload.records,
        sourceApp: payload.sourceApp ?? partner,
        metadata: payload.metadata,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Manual produce failed');
    } finally {
      setBusy(false);
    }
  };

  const runMarketplaceConsume = async (targetPluginId: string, dataset: string) => {
    if (!requireInstalled(targetPluginId)) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const out = await partnerConsume({
        pluginId: targetPluginId,
        dataset,
        params: consumeParamsForDataset(partner, targetPluginId, dataset),
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Consume failed');
    } finally {
      setBusy(false);
    }
  };

  const runMarketplaceProduce = async (targetPluginId: string, dataset: string) => {
    if (!requireInstalled(targetPluginId)) return;
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const out = await partnerProduce({
        pluginId: targetPluginId,
        dataset,
        records: demoRecordsForPartnerDataset(partner, targetPluginId, dataset),
        sourceApp: partner,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Produce failed');
    } finally {
      setBusy(false);
    }
  };

  const successMessage =
    result && typeof result === 'object' && result !== null && 'ok' in result
      ? (result as PluginConsumeResult | PluginProduceResult).ok
        ? 'message' in result
          ? String((result as PluginProduceResult).message)
          : `Loaded ${(result as PluginConsumeResult).meta?.recordCount ?? 0} record(s)`
        : null
      : null;
  const governanceUrl = useMemo(() => {
    try {
      return new URL('/govern/exchange', flexUrl).toString();
    } catch {
      return 'http://localhost:5173/govern/exchange';
    }
  }, [flexUrl]);

  return (
    <div>
      <div className={`rounded-2xl border p-6 mb-6 ${meta.border} bg-slate-900/80`}>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className={`text-xs font-semibold uppercase tracking-wide ${meta.accent}`}>
              Partner application
            </p>
            <h1 className="text-2xl font-bold mt-1">{meta.title}</h1>
            <p className="text-sm text-slate-400 mt-1">{meta.subtitle}</p>
          </div>
          <span className={`text-xs px-2.5 py-1 rounded-full border ${meta.badge}`}>
            sourceApp: {partner}
          </span>
        </div>
      </div>

      <section className="mb-6 rounded-xl border border-slate-800 bg-slate-900/50 p-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
              Published plugin marketplace
            </p>
            <h2 className="mt-1 text-sm font-semibold text-slate-100">
              {publishedPlugins.length} available · {installedPluginIds.length} installed
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              Flex admins publish feature plugins and add-ons here. {meta.title} installs them before using
              consume or produce actions.
            </p>
          </div>
          {marketplaceBusy ? <Badge variant="neutral">Syncing</Badge> : <Badge variant="info">Marketplace</Badge>}
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void refreshMarketplace()}
            disabled={marketplaceBusy}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 px-3 py-2 text-xs text-slate-300 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </button>
          <button
            type="button"
            onClick={() => void installAllPlugins()}
            disabled={marketplaceBusy || publishedPlugins.length === 0}
            className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-300 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Package className="w-3.5 h-3.5" />
            Install all available
          </button>
        </div>
        {marketplaceError && (
          <div className="mt-4 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-300">
            {marketplaceError}. Start the Flex API with <code>npm run api</code>, then publish plugins from Flex.
          </div>
        )}
        {!marketplaceError && publishedPlugins.length === 0 && (
          <div className="mt-4 rounded-lg border border-slate-800 bg-slate-950/50 p-3 text-xs text-slate-500">
            No plugins have been published to {meta.title} yet. In Flex, open Plugins → Partner plugins and publish selected or all enabled plugins.
          </div>
        )}
        {publishedPlugins.length > 0 && (
          <div className="mt-4 grid grid-cols-1 gap-3">
            {publishedPlugins.map((published) => {
              const installed = installedSet.has(published.pluginId);
              const datasets = pluginDatasets(published.pluginId, publishedPlugins, remoteCatalog);
              const readable = datasets.filter(isReadableDataset);
              const writable = datasets.filter(isWritableDataset);

              return (
                <article
                  key={published.pluginId}
                  className="rounded-xl border border-slate-800 bg-slate-950/40 p-4"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-lg" aria-hidden>{published.icon || '*'}</span>
                        <p className="text-sm font-semibold text-slate-100">{published.name}</p>
                        <Badge variant={installed ? 'success' : 'neutral'}>
                          {installed ? 'Installed' : 'Available'}
                        </Badge>
                        {published.kind && <Badge variant="info">{published.kind}</Badge>}
                      </div>
                      <p className="mt-1 text-xs text-slate-500">{published.description}</p>
                      <p className="mt-1 font-mono text-[10px] text-slate-600">{published.pluginId}</p>
                    </div>
                    <div className="flex shrink-0 flex-wrap gap-2">
                      {installed ? (
                        <button
                          type="button"
                          onClick={() => void uninstallPublishedPlugin(published.pluginId)}
                          disabled={marketplaceBusy}
                          className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-300 disabled:opacity-50"
                        >
                          Uninstall
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => void installPublishedPlugin(published.pluginId)}
                          disabled={marketplaceBusy}
                          className="rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-300 disabled:opacity-50"
                        >
                          Install
                        </button>
                      )}
                    </div>
                  </div>
                  {installed && datasets.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {readable.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {readable.slice(0, 3).map((dataset) => (
                            <button
                              key={`read-${dataset.name}`}
                              type="button"
                              disabled={busy}
                              onClick={() => void runMarketplaceConsume(published.pluginId, dataset.name)}
                              className="rounded-lg border border-sky-500/30 bg-sky-500/10 px-3 py-1.5 text-xs text-sky-300 disabled:opacity-50"
                            >
                              Get {dataset.name}
                            </button>
                          ))}
                        </div>
                      )}
                      {writable.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {writable.slice(0, 3).map((dataset) => (
                            <button
                              key={`write-${dataset.name}`}
                              type="button"
                              disabled={busy}
                              onClick={() => void runMarketplaceProduce(published.pluginId, dataset.name)}
                              className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 text-xs text-amber-300 disabled:opacity-50"
                            >
                              Send {dataset.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        )}
      </section>

      <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 mb-6 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-medium flex items-center gap-2">
            <Radio className={`w-4 h-4 ${meta.accent}`} />
            Flex plugin bridge
          </p>
          {connected === true && <Badge variant="success">Connected</Badge>}
          {connected === false && <Badge variant="danger">Flex not reachable</Badge>}
          {connected === null && <Badge variant="neutral">Checking…</Badge>}
        </div>
        <p className="text-xs text-slate-500">
          This partner app can run on another port. Click <strong>Connect Flex</strong>, keep
          Flex open, then run consume or produce against the partner plugin.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_auto_auto] gap-2">
          <label className="sr-only" htmlFor="flex-url">
            Flex URL
          </label>
          <input
            id="flex-url"
            type="url"
            value={flexUrl}
            onChange={(e) => setFlexUrl(e.target.value)}
            className="min-w-0 rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-xs text-slate-300 outline-none focus:border-emerald-500/50"
            placeholder="http://localhost:5173/"
          />
          <button
            type="button"
            onClick={() => void check()}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs border border-slate-700"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
          <button
            type="button"
            onClick={() => void connectFlex()}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs border border-emerald-600/40 text-emerald-400"
          >
            Connect Flex
          </button>
        </div>
      </div>

      <section className="mb-8">
        <h2 className="font-semibold text-sm flex items-center gap-2 mb-3 text-slate-200">
          <Code2 className="w-4 h-4 text-emerald-400" />
          Manual plugin JSON test
        </h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
            <div className="flex items-center justify-between gap-3 mb-3">
              <p className="text-sm font-medium text-slate-200">Consume request</p>
              <button
                type="button"
                onClick={() => setConsumeJson(defaultConsumeJson(partner))}
                className="text-xs text-slate-400 hover:text-slate-200"
              >
                Reset
              </button>
            </div>
            <textarea
              value={consumeJson}
              onChange={(e) => setConsumeJson(e.target.value)}
              spellCheck={false}
              className="min-h-44 w-full resize-y rounded-lg border border-slate-800 bg-slate-950 p-3 font-mono text-xs text-slate-300 outline-none focus:border-sky-500/50"
            />
            <button
              type="button"
              disabled={busy}
              onClick={() => void runManualConsume()}
              className="mt-3 inline-flex items-center gap-2 rounded-lg border border-sky-500/30 bg-sky-500/10 px-4 py-2 text-sm text-sky-300 hover:bg-sky-500/15 disabled:opacity-50"
            >
              <Play className="w-4 h-4" />
              Run consume
            </button>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4">
            <div className="flex items-center justify-between gap-3 mb-3">
              <p className="text-sm font-medium text-slate-200">Produce request</p>
              <button
                type="button"
                onClick={() => setProduceJson(defaultProduceJson(partner))}
                className="text-xs text-slate-400 hover:text-slate-200"
              >
                Reset
              </button>
            </div>
            <textarea
              value={produceJson}
              onChange={(e) => setProduceJson(e.target.value)}
              spellCheck={false}
              className="min-h-44 w-full resize-y rounded-lg border border-slate-800 bg-slate-950 p-3 font-mono text-xs text-slate-300 outline-none focus:border-amber-500/50"
            />
            <button
              type="button"
              disabled={busy}
              onClick={() => void runManualProduce()}
              className="mt-3 inline-flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-2 text-sm text-amber-300 hover:bg-amber-500/15 disabled:opacity-50"
            >
              <Play className="w-4 h-4" />
              Run produce
            </button>
          </div>
        </div>
      </section>

      <section className="mb-8">
        <h2 className="font-semibold text-sm flex items-center gap-2 mb-3 text-slate-200">
          <ArrowDownToLine className="w-4 h-4 text-sky-400" />
          Consume — read from Flex
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {getPresets.length === 0 && (
            <p className="rounded-xl border border-slate-800 bg-slate-900/50 p-3 text-xs text-slate-500 sm:col-span-2">
              Install published plugins above to enable quick consume actions.
            </p>
          )}
          {getPresets.map((preset) => (
            <button
              key={preset.id}
              type="button"
              disabled={busy}
              onClick={() => void runGet(preset)}
              className="text-left p-3 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-sky-500/40 text-sm disabled:opacity-50"
            >
              <p className="font-medium">{preset.label}</p>
              <p className="text-xs text-slate-500 mt-1">{preset.description}</p>
              <p className="text-[10px] font-mono text-slate-600 mt-2">
                {preset.pluginId} → {preset.dataset}
              </p>
            </button>
          ))}
        </div>
      </section>

      <section className="mb-8">
        <h2 className="font-semibold text-sm flex items-center gap-2 mb-3 text-slate-200">
          <ArrowUpFromLine className="w-4 h-4 text-amber-400" />
          Produce — send to Flex
        </h2>
        <div className="space-y-3">
          <button
            type="button"
            disabled={busy || !installedSet.has(partnerPluginId(partner))}
            onClick={() => void runSync()}
            className="w-full text-left p-3 rounded-xl border border-amber-500/25 bg-amber-500/5 hover:bg-amber-500/10 text-sm disabled:opacity-50"
          >
            <p className="font-medium flex items-center gap-2">
              <Send className="w-4 h-4" />
              Simulate inbound sync
            </p>
            <p className="text-xs text-slate-500 mt-1 font-mono">
              {partner === 'eztrac' ? 'flex.partner.eztrac' : 'flex.partner.dhub-rpt'} → request_sync
            </p>
          </button>

          <div className="p-4 rounded-xl border border-slate-800 space-y-3">
            <p className="font-medium text-sm flex items-center gap-2">
              <Database className="w-4 h-4 text-violet-400" />
              Governed inbound request
            </p>
            <p className="text-xs text-slate-500 font-mono">
              {partnerPluginId(partner)} → inbound_request
            </p>
            <label className="block text-xs text-slate-400">
              Record count
              <input
                type="number"
                value={recordCount}
                onChange={(e) => setRecordCount(Number(e.target.value))}
                className="mt-1 block w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm"
              />
            </label>
            <label className="block text-xs text-slate-400">
              Purpose
              <input
                type="text"
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                className="mt-1 block w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm"
              />
            </label>
            <button
              type="button"
              disabled={busy || !installedSet.has(partnerPluginId(partner))}
              onClick={() => void runInbound()}
              className="px-4 py-2 rounded-lg text-sm bg-violet-600 hover:bg-violet-500 disabled:opacity-50"
            >
              Send inbound request
            </button>
          </div>

          <button
            type="button"
            disabled={busy || !installedSet.has(partnerPluginId(partner))}
            onClick={() => void runPull()}
            className="w-full text-left p-3 rounded-xl border border-slate-800 text-sm disabled:opacity-50"
          >
            <p className="font-medium">Pull published datasets</p>
            <p className="text-xs text-slate-500 mt-1 font-mono">
              {partnerPluginId(partner)} → pull_published
            </p>
          </button>
        </div>
      </section>

      {error && (
        <div className="p-4 rounded-xl border border-red-500/40 bg-red-500/10 text-sm text-red-300 mb-4">
          {error}
        </div>
      )}

      {successMessage && (
        <div className="p-4 rounded-xl border border-emerald-500/40 bg-emerald-500/10 text-sm text-emerald-300 mb-4">
          {successMessage}
          <a
            href={governanceUrl}
            target="_blank"
            rel="noreferrer"
            className="block mt-2 underline"
          >
            View approvals in Flex →
          </a>
        </div>
      )}

      {result !== null && (
        <div className="rounded-xl p-4 border border-slate-800 bg-slate-950">
          <p className="text-xs font-semibold uppercase text-slate-500 mb-2">Plugin response</p>
          <pre className="text-xs font-mono text-slate-400 overflow-x-auto max-h-72">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}

      <p className="text-xs text-slate-600 mt-8">
        SDK: <code className="text-slate-400">flex-plugin-sdk</code> with{' '}
        <code className="text-slate-400">createFlexPluginClient()</code> — no apiUrl.{' '}
        <Link to="/partner" className="text-emerald-500 underline">
          Partner console
        </Link>
      </p>
    </div>
  );
}
