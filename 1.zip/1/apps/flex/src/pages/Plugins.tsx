import { useMemo, useState } from 'react';
import {
  ArrowUpRight,
  CheckCircle2,
  PackageOpen,
  Search,
  Send,
  UploadCloud,
} from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { Badge } from '../components/Badge';
import { useFlexPlugins } from '../hooks/useFlexPlugins';
import { useInstalledExtensions } from '../hooks/useInstalledExtensions';
import {
  partnerDisplayName,
  publishPartnerPlugin,
  type PartnerMarketplaceAppId,
} from '../lib/partnerMarketplace';
import type { PluginCatalogEntry, PluginDataset } from '../plugins/types';

type PublishTarget = 'all' | PartnerMarketplaceAppId;

const MARKETPLACE_URL = 'http://localhost:5176/';

function directionLabel(direction: PluginDataset['direction']) {
  if (direction === 'inbound') return 'Accepts data';
  if (direction === 'bidirectional') return 'Read + accept';
  return 'Read only';
}

function targetApps(target: PublishTarget): PartnerMarketplaceAppId[] {
  return target === 'all' ? ['eztrac', 'rpt'] : [target];
}

function targetLabel(target: PublishTarget): string {
  return target === 'all' ? 'EzTrac and dhub-rpt' : partnerDisplayName(target);
}

export function Plugins() {
  const { catalog } = useFlexPlugins();
  const extensions = useInstalledExtensions();
  const [target, setTarget] = useState<PublishTarget>('all');
  const [search, setSearch] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const marketplaceById = useMemo(
    () => new Map(extensions.marketplace.map((item) => [item.id, item])),
    [extensions.marketplace]
  );

  const publishablePlugins = useMemo(
    () =>
      [...catalog]
        .filter((plugin) => plugin.capabilities.consume || plugin.capabilities.produce)
        .sort((a, b) => a.name.localeCompare(b.name)),
    [catalog]
  );

  const filtered = publishablePlugins.filter((plugin) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (
      plugin.name.toLowerCase().includes(q) ||
      plugin.description.toLowerCase().includes(q) ||
      plugin.id.toLowerCase().includes(q)
    );
  });

  const publishOne = async (plugin: PluginCatalogEntry) => {
    setBusyId(plugin.id);
    setMessage(null);
    setError(null);
    try {
      const listing = marketplaceById.get(plugin.id);
      for (const targetApp of targetApps(target)) {
        await publishPartnerPlugin({
          plugin,
          targetApp,
          icon: listing?.icon,
          permissions: listing?.permissions,
        });
      }
      setMessage(`${plugin.name} published to ${targetLabel(target)} marketplace.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Publish failed');
    } finally {
      setBusyId(null);
    }
  };

  const publishAll = async () => {
    setBusyId('all');
    setMessage(null);
    setError(null);
    try {
      for (const plugin of filtered) {
        const listing = marketplaceById.get(plugin.id);
        for (const targetApp of targetApps(target)) {
          await publishPartnerPlugin({
            plugin,
            targetApp,
            icon: listing?.icon,
            permissions: listing?.permissions,
          });
        }
      }
      setMessage(`${filtered.length} plugin(s) published to ${targetLabel(target)} marketplace.`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Publish all failed');
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="page-shell max-w-5xl">
      <PageHeader
        title="Marketplace Publisher"
        description="Flex publishes plugin contracts here. Partner apps install them from the standalone marketplace, then use them inside EzTrac or dhub-rpt."
        action={
          <a
            href={MARKETPLACE_URL}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-flex-accent/15 text-flex-accent border border-flex-accent/40 text-sm font-medium"
          >
            Open marketplace
            <ArrowUpRight className="w-4 h-4" />
          </a>
        }
      />

      <section className="glass rounded-xl border border-flex-border/40 p-4 mb-6">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-3">
          <label className="flex min-h-11 items-center gap-2 px-3 rounded-lg bg-flex-surface/70 border border-flex-border/50">
            <Search className="w-4 h-4 text-flex-muted" />
            <input
              type="search"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search Flex plugins"
              className="w-full bg-transparent border-0 outline-none text-sm text-slate-200 placeholder:text-flex-muted"
            />
          </label>
          <div className="flex flex-wrap gap-2">
            {(
              [
                ['all', 'Both apps'],
                ['eztrac', 'EzTrac'],
                ['rpt', 'dhub-rpt'],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTarget(id)}
                className={`px-3 py-2 rounded-lg text-sm border ${
                  target === id
                    ? 'border-flex-accent/50 bg-flex-accent/15 text-flex-accent'
                    : 'border-flex-border/40 text-flex-muted hover:text-slate-200'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-flex-muted">
            Publishing target: <span className="text-slate-200 font-medium">{targetLabel(target)}</span>
          </p>
          <button
            type="button"
            disabled={busyId !== null || filtered.length === 0}
            onClick={() => void publishAll()}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-flex-accent2/15 text-flex-accent2 border border-flex-accent2/40 text-sm font-medium disabled:opacity-50"
          >
            <UploadCloud className="w-4 h-4" />
            Publish visible
          </button>
        </div>
      </section>

      {message && (
        <div className="mb-4 p-4 rounded-xl border border-flex-success/40 bg-flex-success/10 text-sm text-flex-success flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          {message}
        </div>
      )}
      {error && (
        <div className="mb-4 p-4 rounded-xl border border-flex-danger/40 bg-flex-danger/10 text-sm text-flex-danger">
          {error}. Start the API with <code>npm run api</code>.
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="glass rounded-xl p-8 border border-flex-border/40 text-center">
          <PackageOpen className="w-10 h-10 mx-auto text-flex-muted mb-3" />
          <p className="font-medium">No matching plugins</p>
          <p className="text-sm text-flex-muted mt-1">Try a different search term.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filtered.map((plugin) => {
            const listing = marketplaceById.get(plugin.id);
            const inboundCount = plugin.datasets.filter(
              (dataset) => dataset.direction === 'inbound' || dataset.direction === 'bidirectional'
            ).length;
            return (
              <article key={plugin.id} className="glass rounded-xl border border-flex-border/40 p-5 flex flex-col">
                <div className="flex items-start gap-3">
                  <span className="w-10 h-10 rounded-lg bg-flex-accent/10 border border-flex-accent/25 flex items-center justify-center text-xl shrink-0">
                    {listing?.icon ?? '*'}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="font-semibold text-sm">{plugin.name}</h3>
                      <Badge variant="neutral">v{plugin.version}</Badge>
                      {plugin.kind && <Badge variant={plugin.kind === 'extension' ? 'info' : 'neutral'}>{plugin.kind}</Badge>}
                      {inboundCount > 0 && <Badge variant="warning">Accepts data</Badge>}
                    </div>
                    <p className="text-[11px] font-mono text-flex-muted mt-1 break-all">{plugin.id}</p>
                  </div>
                </div>

                <p className="text-sm text-slate-300 mt-3 flex-1">{plugin.description}</p>

                <div className="mt-4 space-y-2">
                  {plugin.datasets.slice(0, 4).map((dataset) => (
                    <div
                      key={dataset.name}
                      className="flex items-center justify-between gap-3 rounded-lg bg-flex-surface/45 border border-flex-border/30 px-3 py-2"
                    >
                      <span className="text-xs text-slate-300 truncate">{dataset.description}</span>
                      <span className="text-[10px] uppercase tracking-wide text-flex-muted shrink-0">
                        {directionLabel(dataset.direction)}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
                  <p className="text-xs text-flex-muted">
                    {plugin.datasetCount} dataset(s) · {plugin.category}
                  </p>
                  <button
                    type="button"
                    disabled={busyId !== null}
                    onClick={() => void publishOne(plugin)}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-flex-accent/15 text-flex-accent border border-flex-accent/40 text-sm font-medium disabled:opacity-50"
                  >
                    <Send className="w-4 h-4" />
                    {busyId === plugin.id ? 'Publishing' : 'Publish'}
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
