import { Link } from 'react-router-dom';
import { MousePointerClick } from 'lucide-react';

export function ExtensionsGuide() {
  return (
    <div className="glass rounded-xl p-4 sm:p-5 border border-flex-accent/25 text-sm space-y-4">
      <p className="font-semibold flex items-center gap-2">
        <MousePointerClick className="w-4 h-4 text-flex-accent" />
        Plugin types in Flex
      </p>

      <p className="text-slate-300 text-sm">
        Core plugins are built into Flex. Partner plugins are the contracts for EzTrac and dhub-rpt.
        Extension add-ons such as PagerDuty, Jira, and Snowflake install on top.
      </p>

      <div className="overflow-x-auto">
        <table className="w-full text-xs text-left">
          <thead>
            <tr className="text-flex-muted border-b border-flex-border/40">
              <th className="py-2 pr-4">Type</th>
              <th className="py-2">Example</th>
            </tr>
          </thead>
          <tbody className="text-slate-300">
            <tr className="border-b border-flex-border/20">
              <td className="py-2 pr-4">Core plugin</td>
              <td className="py-2">flex.dashboard, flex.governance</td>
            </tr>
            <tr className="border-b border-flex-border/20">
              <td className="py-2 pr-4">Partner plugin</td>
              <td className="py-2">flex.partner.eztrac, flex.partner.dhub-rpt</td>
            </tr>
            <tr className="border-b border-flex-border/20">
              <td className="py-2 pr-4">Extension add-on</td>
              <td className="py-2">flex.ext.snowflake, flex.ext.jira</td>
            </tr>
            <tr>
              <td className="py-2 pr-4">VS Code extension</td>
              <td className="py-2">A .vsix package, separate from Flex plugins</td>
            </tr>
          </tbody>
        </table>
      </div>

      <ol className="list-decimal list-inside space-y-1.5 text-slate-300 text-sm">
        <li>
          <Link to="/plugins" className="text-flex-accent underline">
            Tools {'->'} Plugins & Extensions
          </Link>
        </li>
        <li>
          Open <strong>Partner plugins</strong> to test EzTrac or dhub-rpt
        </li>
        <li>Open <strong>All plugin APIs</strong> to see plugin IDs and datasets</li>
        <li>Open <strong>Extension add-ons</strong> to install Snowflake or Jira</li>
      </ol>
    </div>
  );
}
