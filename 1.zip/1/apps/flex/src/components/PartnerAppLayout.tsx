import { Link, Outlet } from 'react-router-dom';
import type { PartnerId } from '../pages/partner-apps/PartnerExternalApp';

/** Minimal chrome — simulates EzTrac / dhub-rpt as a separate app (not Flex UI). */
export function PartnerAppLayout({ lockedPartner }: { lockedPartner?: PartnerId }) {
  const title = lockedPartner === 'eztrac' ? 'EzTrac' : lockedPartner === 'dhub-rpt' ? 'dhub-rpt' : null;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-4">
          {title ? (
            <span className="text-sm font-semibold text-slate-100">{title} plugin console</span>
          ) : (
            <>
              <Link to="/apps/eztrac" className="text-sm font-semibold hover:text-white text-slate-400">
                EzTrac
              </Link>
              <span className="text-slate-700">|</span>
              <Link to="/apps/dhub-rpt" className="text-sm font-semibold hover:text-white text-slate-400">
                dhub-rpt
              </Link>
            </>
          )}
        </div>
        <p className="text-xs text-slate-500">
          Plugins only — open{' '}
          <a href="http://localhost:5173/" target="_blank" rel="noreferrer" className="text-emerald-400 underline">
            Flex
          </a>{' '}
          in another tab
        </p>
      </header>
      <main className="p-4 md:p-8 max-w-4xl mx-auto">
        <Outlet />
      </main>
    </div>
  );
}
