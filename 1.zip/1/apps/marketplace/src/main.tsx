import React, { useCallback, useEffect, useMemo, useState } from 'react';
import ReactDOM from 'react-dom/client';
import {
  ArrowUpRight,
  Check,
  Download,
  PackageCheck,
  RefreshCw,
  Search,
  Store,
  Trash2,
} from 'lucide-react';
import './styles.css';

type AppId = 'eztrac' | 'rpt';
type DatasetDirection = 'inbound' | 'outbound' | 'bidirectional';

interface PluginDataset {
  name: string;
  description: string;
  direction: DatasetDirection;
}

interface PublishedPlugin {
  pluginId: string;
  name: string;
  version: string;
  description: string;
  targetApp: AppId;
  publisher?: string;
  icon?: string;
  category?: string;
  permissions?: string[];
  kind?: 'core' | 'extension';
  datasets?: PluginDataset[];
  publishedAt: string;
}

const API_URL = import.meta.env.VITE_FLEX_API_URL ?? 'http://localhost:3847';

const APPS: Record<AppId, { label: string; url: string; summary: string }> = {
  eztrac: {
    label: 'EzTrac',
    url: 'http://localhost:5174/',
    summary: 'Finance forecasting, budget variance, and governed inbound requests.',
  },
  rpt: {
    label: 'dhub-rpt',
    url: 'http://localhost:5175/',
    summary: 'Resource planning, allocation, and capacity sync with Flex.',
  },
};

async function readJson<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, init);
  const text = await res.text();
  const json = (text ? JSON.parse(text) : {}) as T & { error?: string };
  if (!res.ok) throw new Error(json.error ?? `Marketplace API ${res.status}`);
  return json as T;
}

function directionLabel(direction: DatasetDirection) {
  if (direction === 'inbound') return 'Sends to Flex';
  if (direction === 'bidirectional') return 'Read + send';
  return 'Reads Flex';
}

function PluginCard({
  plugin,
  installed,
  busy,
  onInstall,
  onUninstall,
}: {
  plugin: PublishedPlugin;
  installed: boolean;
  busy: boolean;
  onInstall: () => void;
  onUninstall: () => void;
}) {
  const datasets = plugin.datasets ?? [];
  return (
    <article className="panel card">
      <div className="card-head">
        <div className="title-row">
          <span className="icon" aria-hidden>
            {plugin.icon || <Store size={20} />}
          </span>
          <div>
            <h3>{plugin.name}</h3>
            <p className="plugin-id">{plugin.pluginId}</p>
          </div>
        </div>
        <span className={`badge ${installed ? 'good' : ''}`}>
          {installed ? 'Installed' : `v${plugin.version}`}
        </span>
      </div>

      <p className="desc">{plugin.description}</p>

      <div className="meta">
        <span className="badge">{plugin.publisher ?? 'Flex'}</span>
        {plugin.category && <span className="badge">{plugin.category}</span>}
        {plugin.kind && <span className="badge">{plugin.kind}</span>}
      </div>

      <div className="datasets">
        {datasets.slice(0, 4).map((dataset) => (
          <div className="dataset" key={dataset.name}>
            <span>{dataset.description || dataset.name}</span>
            <span className={dataset.direction === 'inbound' ? 'badge warn' : 'badge'}>
              {directionLabel(dataset.direction)}
            </span>
          </div>
        ))}
        {datasets.length === 0 && (
          <div className="dataset">
            <span>Plugin metadata</span>
            <span className="badge">No datasets</span>
          </div>
        )}
      </div>

      <div className="actions">
        {installed ? (
          <button className="btn danger" type="button" disabled={busy} onClick={onUninstall}>
            <Trash2 size={16} />
            Uninstall
          </button>
        ) : (
          <button className="btn primary" type="button" disabled={busy} onClick={onInstall}>
            <Download size={16} />
            Install
          </button>
        )}
      </div>
    </article>
  );
}

function App() {
  const [selectedApp, setSelectedApp] = useState<AppId>('eztrac');
  const [published, setPublished] = useState<PublishedPlugin[]>([]);
  const [installed, setInstalled] = useState<string[]>([]);
  const [search, setSearch] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const selectedMeta = APPS[selectedApp];

  const reload = useCallback(async () => {
    setBusy(true);
    setError(null);
    try {
      const [plugins, installs] = await Promise.all([
        readJson<PublishedPlugin[]>(`/api/v1/partner-marketplace?app=${selectedApp}`),
        readJson<string[]>(`/api/v1/partner-marketplace/installed?app=${selectedApp}`),
      ]);
      setPublished(plugins);
      setInstalled(installs);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load marketplace');
    } finally {
      setBusy(false);
    }
  }, [selectedApp]);

  useEffect(() => {
    void reload();
  }, [reload]);

  const installedSet = useMemo(() => new Set(installed), [installed]);
  const filtered = published.filter((plugin) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (
      plugin.name.toLowerCase().includes(q) ||
      plugin.description.toLowerCase().includes(q) ||
      plugin.pluginId.toLowerCase().includes(q)
    );
  });

  const install = async (pluginId: string) => {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const result = await readJson<{ installed: string[] }>('/api/v1/partner-marketplace/install', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ app: selectedApp, pluginId }),
      });
      setInstalled(result.installed);
      setMessage(`Installed ${pluginId} in ${selectedMeta.label}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Install failed');
    } finally {
      setBusy(false);
    }
  };

  const uninstall = async (pluginId: string) => {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      const result = await readJson<{ installed: string[] }>('/api/v1/partner-marketplace/uninstall', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ app: selectedApp, pluginId }),
      });
      setInstalled(result.installed);
      setMessage(`Uninstalled ${pluginId} from ${selectedMeta.label}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Uninstall failed');
    } finally {
      setBusy(false);
    }
  };

  const installAll = async () => {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      let next = installed;
      for (const plugin of filtered) {
        if (next.includes(plugin.pluginId)) continue;
        const result = await readJson<{ installed: string[] }>('/api/v1/partner-marketplace/install', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ app: selectedApp, pluginId: plugin.pluginId }),
        });
        next = result.installed;
      }
      setInstalled(next);
      setMessage(`Installed ${filtered.length} visible plugin(s) in ${selectedMeta.label}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Install all failed');
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark">
            <Store size={22} />
          </span>
          <div>
            <h1>Flex Marketplace</h1>
            <p className="muted">Install Flex-published plugins into partner apps.</p>
          </div>
        </div>
        <a className="btn" href="http://localhost:5173/plugins" target="_blank" rel="noreferrer">
          Flex publisher
          <ArrowUpRight size={15} />
        </a>
      </header>

      <section className="hero">
        <div className="panel hero-main">
          <h2>Choose an app, then install the plugins it needs.</h2>
          <p>
            Flex publishes plugins to this marketplace. EzTrac and dhub-rpt install only the plugins they need,
            then use those plugins inside their own apps to read Flex data or send governed requests back to Flex.
          </p>
        </div>
        <div className="panel hero-side">
          <div className="stat">
            <span className="muted">Selected app</span>
            <strong>{selectedMeta.label}</strong>
          </div>
          <div className="stat">
            <span className="muted">Available</span>
            <strong>{published.length}</strong>
          </div>
          <div className="stat">
            <span className="muted">Installed</span>
            <strong>{installed.length}</strong>
          </div>
        </div>
      </section>

      <section className="toolbar" aria-label="Marketplace filters">
        <label className="search">
          <Search size={16} />
          <input
            type="search"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search plugins"
          />
        </label>
        <div className="segments">
          {(Object.keys(APPS) as AppId[]).map((appId) => (
            <button
              key={appId}
              className={selectedApp === appId ? 'active' : ''}
              type="button"
              onClick={() => setSelectedApp(appId)}
            >
              {APPS[appId].label}
            </button>
          ))}
        </div>
      </section>

      <div className="actions">
        <button className="btn" type="button" disabled={busy} onClick={() => void reload()}>
          <RefreshCw size={16} />
          Refresh
        </button>
        <button className="btn primary" type="button" disabled={busy || filtered.length === 0} onClick={() => void installAll()}>
          <PackageCheck size={16} />
          Install visible
        </button>
        <a className="btn" href={selectedMeta.url} target="_blank" rel="noreferrer">
          Open {selectedMeta.label}
          <ArrowUpRight size={15} />
        </a>
      </div>

      <p className="notice">{selectedMeta.summary}</p>
      {message && (
        <p className="notice">
          <Check size={16} /> {message}
        </p>
      )}
      {error && <p className="notice error">{error}. Start the API with npm run api and publish from Flex.</p>}

      {filtered.length === 0 ? (
        <section className="panel empty">
          <h3>No plugins published for {selectedMeta.label}</h3>
          <p className="muted">Open Flex publisher, publish plugins for this app, then refresh.</p>
        </section>
      ) : (
        <section className="grid">
          {filtered.map((plugin) => (
            <PluginCard
              key={plugin.pluginId}
              plugin={plugin}
              installed={installedSet.has(plugin.pluginId)}
              busy={busy}
              onInstall={() => void install(plugin.pluginId)}
              onUninstall={() => void uninstall(plugin.pluginId)}
            />
          ))}
        </section>
      )}
    </main>
  );
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
