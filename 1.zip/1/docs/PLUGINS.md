# Flex Plugin API

Flex has two plugin types:

| Type | Install? | Examples |
|------|----------|----------|
| **Core** | Built into Flex (always on) | Dashboard, Governance, Chargeback |
| **Extension** | Install from **Tools → Extensions → Marketplace** | PagerDuty, Teams, Snowflake, Jira |

Partner apps (EzTrac, dhub-rpt) use dedicated partner plugin IDs via `flex-plugin-sdk`:

- `flex.partner.eztrac`
- `flex.partner.dhub-rpt`

These are partner contracts, not marketplace extensions.

## Architecture

```mermaid
flowchart LR
  subgraph Consumers
    EZ[EzTrac]
    DH[dhub-rpt]
    EXT[Extension / scripts]
  end

  subgraph Flex
    MKT[Marketplace]
    INST[Installed extensions]
    HOST[FlexPluginHost]
    CORE[Core plugins]
  end

  MKT -->|Install| INST
  CORE --> HOST
  INST --> HOST
  EZ --> SDK[flex-plugin-sdk]
  DH --> SDK
  EXT --> SDK
  SDK -->|postMessage / window.FlexPlugins| HOST
```

## Install extensions (VS Code–style)

1. Open Flex → **Tools → Extensions**
2. **Marketplace** tab → choose an extension → **Install**
3. **Installed** tab → Enable / Disable / Uninstall
4. Installed extensions register in `window.FlexPlugins.catalog()` and the plugin host

State is stored in `localStorage` key `flex_installed_extensions_v1`.

## Marketplace registry prototype

The architecture-compatible registry is available in the local API service with in-memory storage. It uses the production-shaped endpoints without PostgreSQL or blob storage:

| Method | Endpoint | Purpose |
|--------|----------|---------|
| `GET` | `/api/v1/plugins/search?q=pdf&category=export` | Search marketplace metadata |
| `GET` | `/api/v1/plugins/:id/versions` | List immutable releases |
| `GET` | `/api/v1/apps/:appId/installations` | List plugins installed into one host app |
| `POST` | `/api/v1/apps/:appId/installations` | Install `{ "pluginId": "...", "version": "..." }` |
| `DELETE` | `/api/v1/apps/:appId/installations/:pluginId` | Uninstall from that host app |

The prototype registry seeds PDF Exporter, Anomaly Alerts, and Snowflake Export. All package URLs and checksums are memory-only placeholders (`memory://...`) so the API contract is ready before real CDN/S3 storage exists.

## React host SDK

`flex-plugin-sdk` now exposes the host-side primitives from the target architecture:

- `PluginHost` owns lifecycle, scoped storage, event bus, permissions, request handlers, and slot registrations.
- `PluginProvider` places the host into React context.
- `Slot` renders plugin contributions for named surfaces such as `sidebar`, `toolbar`, or `main-panel`.
- `MemoryPluginRegistry` provides local marketplace and installation state for development.

Example:

```tsx
const host = new PluginHost({
  appId: 'flex-app-001',
  registry: new MemoryPluginRegistry([pluginManifest]),
  sandbox: 'iframe',
  permissions: ['ui', 'event', 'storage', 'network'],
});

await host.install('com.flex.pdf-exporter');
await host.enable('com.flex.pdf-exporter');
```

## Separate Marketplace Flow

The plugin marketplace is now a separate app:

| App | URL | Role |
|-----|-----|------|
| Flex | `http://localhost:5173/plugins` | Publish plugin contracts to marketplace |
| Marketplace | `http://localhost:5176/` | Pick EzTrac or dhub-rpt, then install/uninstall plugins |
| EzTrac | `http://localhost:5174/` | Use installed plugins to read Flex or send data to Flex |
| dhub-rpt | `http://localhost:5175/` | Use installed plugins to read Flex or send data to Flex |

Run everything:

```bash
npm run api
npm run dev:all
```

Flow:

1. Start the shared API with `npm run api`.
2. Open Flex → **Marketplace Publisher** and publish selected plugins to EzTrac, dhub-rpt, or both.
3. Open the separate Marketplace app and select the target app.
4. Install the extension into that app.
5. Open EzTrac or dhub-rpt. Installed plugins appear in the app with Read and Send-to-Flex actions.

Inbound produce actions such as `inbound_request` create pending requests in **Governance → Data Exchange Hub**. Flex admins approve or reject those requests before the transfer is treated as accepted.

Published marketplace state is stored by `services/flex-api` under:

- `partnerMarketplacePublished`
- `partnerInstalledByApp`

Flex state sync preserves these fields so publishing is not lost when the web app syncs its current state to the API.

### Marketplace extensions

| Plugin ID | Purpose |
|-----------|---------|
| `flex.ext.pagerduty` | Page on critical/high anomalies |
| `flex.ext.teams` | Post messages to Teams channels |
| `flex.ext.snowflake` | Export chargeback + usage manifests |
| `flex.ext.jira` | Create Jira tickets from anomalies |

## Core plugin catalog

| Plugin ID | UI route | Consume | Produce |
|-----------|----------|---------|---------|
| `flex.dashboard` | `/` | KPIs, usage trend | KPI snapshot (demo) |
| `flex.governance` | `/govern/exchange` | Requests, datasets, audit | `inbound_request` |
| `flex.settings` | `/settings` | Preferences, roles | `preferences` |
| `flex.cloud-usage` | `/cloud` | Usage history, forecast | — |
| `flex.optimization` | `/optimization` | Savings opportunities | `advance_stage` |
| `flex.anomalies` | `/anomalies` | Events, feed | `resolve_anomaly`, `create_anomaly` |
| `flex.chargeback` | `/chargeback` | Showback, tags | `update_budget` |
| `flex.workforce` | `/workforce` | Squad matrix | `acknowledge_signal` |
| `flex.resources` | `/resources` | Allocation matrix | — |
| `flex.alignment` | `/govern/alignment` | Rows, score | `resolve_conflict` |
| `flex.integrations` | `/govern/partners` | Apps, consumption* | `simulate_inbound_sync`, `pull_outbound` |
| `flex.partner.eztrac` | `/apps/eztrac` | `consumption_status` | `request_sync`, `inbound_request`, `pull_published` |
| `flex.partner.dhub-rpt` | `/apps/dhub-rpt` | `consumption_status` | `request_sync`, `inbound_request`, `pull_published` |
| `flex.assistant` | `/assistant` | Knowledge context | `chat_intent` |
| `flex.extension` | Extension | Badge snapshot | `page_context` |

\* `partner_consumption` requires `params: { partner: 'eztrac' | 'dhub-rpt' }`.

## Browser API

When Flex is loaded:

```javascript
// Catalog (core + enabled extensions)
const plugins = window.FlexPlugins.catalog();

// Consume — e.g. Snowflake export after installing extension
const { records } = await window.FlexPlugins.consume({
  pluginId: 'flex.ext.snowflake',
  dataset: 'export_manifest',
});

// Produce — e.g. Jira ticket
await window.FlexPlugins.produce({
  pluginId: 'flex.ext.jira',
  dataset: 'create_ticket',
  records: [{ anomalyId: 'an-1', projectKey: 'FIN' }],
});
```

## npm SDK

```bash
npm install flex-plugin-sdk
```

```typescript
import { createFlexPluginClient, FlexPluginIds } from 'flex-plugin-sdk';

const client = createFlexPluginClient();
await client.consume({ pluginId: FlexPluginIds.chargeback, dataset: 'team_showback' });
```

Extension IDs are only available after install + enable in Flex.

## Adding a new marketplace extension

1. Add `apps/flex/src/plugins/marketplace/bundles/your.plugin.ts` with `definePlugin` and `kind: 'extension'`
2. Register in `marketplace/bundles/index.ts`
3. Add listing in `marketplace/catalog.ts`
4. Rebuild Flex

## Source layout

```
apps/flex/src/plugins/
  corePlugins.ts           # Built-in areas
  manager.ts               # Core + installed extensions
  registry.ts              # Host lookup
  pluginInstallStore.ts    # localStorage install state
  marketplace/
    catalog.ts             # Marketplace listings
    bundles/*.plugin.ts    # Extension implementations
packages/flex-plugin-sdk/  # External npm client
```

---

*API version 1.0.0 — demo; production would add signed packages, REST, and OAuth.*
