import * as vscode from 'vscode';

const API = vscode.workspace.getConfiguration('flex').get<string>('apiUrl') ?? 'http://localhost:3847';

let output: vscode.OutputChannel;

async function api<T>(path: string, body?: unknown): Promise<T> {
  const res = await fetch(`${API}${path}`, {
    method: body ? 'POST' : 'GET',
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = (await res.json()) as T & { ok?: boolean; error?: string };
  if (!res.ok) {
    throw new Error(('error' in json && json.error) || `HTTP ${res.status}`);
  }
  return json;
}

function show(data: unknown, title: string) {
  output.appendLine(`\n--- ${title} ---`);
  output.appendLine(JSON.stringify(data, null, 2));
  output.show(true);
}

export function activate(context: vscode.ExtensionContext) {
  output = vscode.window.createOutputChannel('Flex FinOps');

  context.subscriptions.push(
    vscode.commands.registerCommand('flex.connect', async () => {
      try {
        const health = await api<{ ok: boolean }>('/health');
        vscode.window.showInformationMessage(`Flex API connected (${API})`);
        show(health, 'Health');
      } catch (e) {
        vscode.window.showErrorMessage(
          `Flex API not running. Start: npm run api — ${e instanceof Error ? e.message : e}`
        );
      }
    }),

    vscode.commands.registerCommand('flex.getKpis', async () => {
      try {
        const data = await api('/api/v1/consume', {
          pluginId: 'flex.dashboard',
          dataset: 'kpi_snapshot',
        });
        show(data, 'Dashboard KPIs');
      } catch (e) {
        vscode.window.showErrorMessage(String(e));
      }
    }),

    vscode.commands.registerCommand('flex.getChargeback', async () => {
      try {
        const data = await api('/api/v1/consume', {
          pluginId: 'flex.chargeback',
          dataset: 'team_showback',
        });
        show(data, 'Team chargeback');
      } catch (e) {
        vscode.window.showErrorMessage(String(e));
      }
    }),

    vscode.commands.registerCommand('flex.getPendingApprovals', async () => {
      try {
        const data = await api('/api/v1/consume', {
          pluginId: 'flex.governance',
          dataset: 'data_requests',
        });
        show(data, 'Data requests');
      } catch (e) {
        vscode.window.showErrorMessage(String(e));
      }
    }),

    vscode.commands.registerCommand('flex.sendEzTracSync', async () => {
      try {
        const data = await api('/api/v1/produce', {
          pluginId: 'flex.integrations',
          dataset: 'simulate_inbound_sync',
          records: [{ partner: 'eztrac' }],
          sourceApp: 'eztrac',
        });
        show(data, 'EzTrac sync');
        vscode.window.showInformationMessage('Sent to Flex — refresh Flex app to see pending approval');
      } catch (e) {
        vscode.window.showErrorMessage(String(e));
      }
    }),

    vscode.commands.registerCommand('flex.sendInboundRequest', async () => {
      try {
        const data = await api('/api/v1/produce', {
          pluginId: 'flex.governance',
          dataset: 'inbound_request',
          records: [
            {
              fromApp: 'eztrac',
              dataset: 'forecast_variance',
              recordCount: 800,
              purpose: 'Inbound from VS Code extension',
            },
          ],
          sourceApp: 'eztrac',
        });
        show(data, 'Inbound request');
        vscode.window.showInformationMessage('Inbound request created in Flex API');
      } catch (e) {
        vscode.window.showErrorMessage(String(e));
      }
    }),

    vscode.commands.registerCommand('flex.openApp', () => {
      void vscode.env.openExternal(vscode.Uri.parse('http://localhost:5173'));
    })
  );

  output.appendLine('Flex FinOps extension ready. Run "Flex: Connect to API" (npm run api first).');
}

export function deactivate() {
  output?.dispose();
}
