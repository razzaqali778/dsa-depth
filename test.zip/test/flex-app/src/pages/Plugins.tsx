import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  ChevronDown,
  ChevronUp,
  Download,
  Send,
  CheckCircle2,
  Code2,
} from 'lucide-react';
import { PageHeader } from '../components/PageHeader';
import { Badge } from '../components/Badge';
import { ExtensionsGuide } from '../components/ExtensionsGuide';
import { FeaturePluginsPanel } from '../components/FeaturePluginsPanel';
import { InstalledExtensionsList, PluginMarketplace } from '../components/PluginMarketplace';
import { isPluginEnabled } from '../plugins/manager';
import { ExtensionTryResult } from '../components/ExtensionTryResult';
import { useFlexPlugins } from '../hooks/useFlexPlugins';
import { PLUGIN_PRESETS, defaultPartnerForPreset, type PluginPreset } from '../lib/pluginPresets';
import type { PluginConsumeResult, PluginProduceResult } from '../plugins/types';

type ViewMode = 'features' | 'marketplace' | 'installed' | 'connect' | 'browse';

function recordsPreview(records: unknown[]): { columns: string[]; rows: Record<string, unknown>[] } | null {
  if (!records.length || typeof records[0] !== 'object' || records[0] === null) return null;
  const rows = records as Record<string, unknown>[];
  const columns = Object.keys(rows[0]).slice(0, 6);
  return { columns, rows: rows.slice(0, 8) };
}

export function Plugins() {
  const { host, catalog } = useFlexPlugins();
  const [view, setView] = useState<ViewMode>('features');
  const [activePreset, setActivePreset] = useState<PluginPreset>(PLUGIN_PRESETS[0]);
  const [partner, setPartner] = useState<'eztrac' | 'dhub-rpt'>('eztrac');
  const [busy, setBusy] = useState(false);
  const [getResult, setGetResult] = useState<PluginConsumeResult | null>(null);
  const [sendResult, setSendResult] = useState<PluginProduceResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showDev, setShowDev] = useState(false);

  const getPresets = useMemo(
    () => PLUGIN_PRESETS.filter((p) => p.kind === 'get' && isPluginEnabled(p.pluginId)),
    [catalog]
  );
  const sendPresets = useMemo(
    () => PLUGIN_PRESETS.filter((p) => p.kind === 'send' && isPluginEnabled(p.pluginId)),
    [catalog]
  );

  const runGet = async (preset: PluginPreset) => {
    setBusy(true);
    setError(null);
    setGetResult(null);
    setSendResult(null);
    setActivePreset(preset);
    try {
      const out = host.consume({
        pluginId: preset.pluginId,
        dataset: preset.dataset,
        params: preset.params,
      });
      if ('ok' in out && out.ok) setGetResult(out);
      else setError('error' in out && out.error ? out.error : 'Could not load data');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed');
    } finally {
      setBusy(false);
    }
  };

  const runSend = async (preset: PluginPreset, selectedPartner: 'eztrac' | 'dhub-rpt') => {
    setBusy(true);
    setError(null);
    setGetResult(null);
    setSendResult(null);
    setActivePreset(preset);
    try {
      const out = await host.produce({
        pluginId: preset.pluginId,
        dataset: preset.dataset,
        records: [{ partner: selectedPartner }],
        sourceApp: selectedPartner,
      });
      if ('ok' in out && out.ok) setSendResult(out);
      else setError('error' in out && out.error ? out.error : 'Could not send');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed');
    } finally {
      setBusy(false);
    }
  };

  const preview = getResult ? recordsPreview(getResult.records) : null;

  return (
    <div className="page-shell max-w-4xl">
      <PageHeader
        title="Extensions"
        description="Turn features on or off per area, add partner extensions, or connect EzTrac and dhub-rpt."
        action={
          <Link
            to="/partner"
            target="_blank"
            rel="noreferrer"
            className="text-sm px-3 py-1.5 rounded-lg bg-flex-accent/15 text-flex-accent border border-flex-accent/40"
          >
            Open partner console ↗
          </Link>
        }
      />

      <div className="mb-6 flex flex-wrap gap-2">
        {(
          [
            ['features', 'Feature plugins'],
            ['marketplace', 'Add-ons'],
            ['installed', 'Installed'],
            ['connect', 'Connect apps'],
            ['browse', 'All APIs'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setView(id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium border ${
              view === id
                ? 'border-flex-accent/50 bg-flex-accent/15 text-flex-accent'
                : 'border-flex-border/40 text-flex-muted'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {view === 'features' && <FeaturePluginsPanel host={host} />}
      {view === 'features' && (
        <p className="text-xs text-flex-muted -mt-4">
          Tip: Disabled features disappear from the sidebar, dashboard hub, and search (⇧⌘F).
        </p>
      )}

      {view !== 'features' && view !== 'connect' && <ExtensionsGuide />}

      {view === 'marketplace' && <PluginMarketplace host={host} />}
      {view === 'installed' && <InstalledExtensionsList host={host} />}

      {view === 'connect' && (
        <div className="space-y-8">
          <section>
            <h2 className="font-display font-semibold text-base flex items-center gap-2 mb-1">
              <Download className="w-5 h-5 text-flex-accent2" />
              Get data from Flex
            </h2>
            <p className="text-sm text-flex-muted mb-4">
              Another app reads Flex — like exporting a report, but live.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {getPresets.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  disabled={busy}
                  onClick={() => runGet(preset)}
                  className="text-left p-4 rounded-xl glass border border-flex-border/40 hover:border-flex-accent2/40 hover:bg-flex-surface/30 transition-colors disabled:opacity-50"
                >
                  <p className="font-medium text-sm">{preset.label}</p>
                  <p className="text-xs text-flex-muted mt-1">{preset.description}</p>
                </button>
              ))}
            </div>
          </section>

          <section>
            <h2 className="font-display font-semibold text-base flex items-center gap-2 mb-1">
              <Send className="w-5 h-5 text-flex-warning" />
              Send data to Flex
            </h2>
            <p className="text-sm text-flex-muted mb-4">
              A partner asks Flex for data — you approve it in Governance.
            </p>
            <div className="space-y-3">
              {sendPresets.map((preset) => (
                <div
                  key={preset.id}
                  className="glass rounded-xl p-4 border border-flex-border/40 flex flex-col sm:flex-row sm:items-center gap-4"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm">{preset.label}</p>
                    <p className="text-xs text-flex-muted mt-1">{preset.description}</p>
                  </div>
                  {(preset.sendForm === 'partner-sync' || preset.sendForm === 'partner-pull') && (
                    <select
                      value={
                        preset.id.includes('dhub') && preset.sendForm === 'partner-sync'
                          ? 'dhub-rpt'
                          : preset.id.includes('eztrac') && preset.sendForm === 'partner-sync'
                            ? 'eztrac'
                            : partner
                      }
                      onChange={(e) => setPartner(e.target.value as 'eztrac' | 'dhub-rpt')}
                      className="px-3 py-2 rounded-lg bg-flex-surface border border-flex-border text-sm shrink-0"
                    >
                      <option value="eztrac">EzTrac</option>
                      <option value="dhub-rpt">dhub-rpt</option>
                    </select>
                  )}
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() =>
                      runSend(
                        preset,
                        preset.sendForm === 'partner-sync'
                          ? defaultPartnerForPreset(preset.id)
                          : partner
                      )
                    }
                    className="px-4 py-2 rounded-lg bg-flex-warning/20 text-flex-warning border border-flex-warning/40 text-sm font-medium hover:bg-flex-warning/30 shrink-0 disabled:opacity-50"
                  >
                    Run
                  </button>
                </div>
              ))}
            </div>
          </section>

          {error && (
            <div className="p-4 rounded-xl border border-flex-danger/40 bg-flex-danger/10 text-sm text-flex-danger">
              {error}
            </div>
          )}

          {sendResult?.ok && (
            <div className="p-5 rounded-xl border border-flex-success/40 bg-flex-success/10">
              <p className="font-medium text-flex-success flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                {sendResult.message}
              </p>
              {activePreset.routeAfterSend && (
                <Link
                  to={activePreset.routeAfterSend}
                  className="inline-flex items-center gap-1 mt-3 text-sm text-flex-accent hover:underline"
                >
                  {activePreset.routeLabel ?? 'Open next step'}
                  <ArrowRight className="w-4 h-4" />
                </Link>
              )}
            </div>
          )}

          {getResult?.ok && (
            <div className="glass rounded-xl p-5 border border-flex-success/30">
              <p className="text-sm font-medium text-flex-success mb-3 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                Loaded {getResult.meta.recordCount} record(s) — {activePreset.label}
              </p>
              {preview ? (
                <div className="table-scroll">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-left text-flex-muted border-b border-flex-border/40">
                        {preview.columns.map((c) => (
                          <th key={c} className="p-2 font-medium">
                            {c}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {preview.rows.map((row, i) => (
                        <tr key={i} className="border-b border-flex-border/20">
                          {preview.columns.map((c) => (
                            <td key={c} className="p-2 text-slate-300">
                              {String(row[c] ?? '—').slice(0, 40)}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {getResult.meta.recordCount > 8 && (
                    <p className="text-xs text-flex-muted mt-2">Showing first 8 rows</p>
                  )}
                </div>
              ) : (
                <pre className="text-xs font-mono text-slate-300 overflow-x-auto">
                  {JSON.stringify(getResult.records, null, 2)}
                </pre>
              )}
            </div>
          )}
        </div>
      )}

      {view === 'browse' && (
        <BrowseAllAreas catalog={catalog} host={host} busy={busy} setBusy={setBusy} />
      )}

      <section className="mt-10 border-t border-flex-border/40 pt-6">
        <button
          type="button"
          onClick={() => setShowDev(!showDev)}
          className="flex items-center gap-2 text-sm text-flex-muted hover:text-slate-200"
        >
          <Code2 className="w-4 h-4" />
          For developers (API & code)
          {showDev ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
        {showDev && (
          <div className="mt-4 glass rounded-xl p-4 text-xs text-flex-muted space-y-3">
            <p>
              Optional: open DevTools (<kbd className="px-1 rounded bg-flex-surface">F12</kbd> or{' '}
              <kbd className="px-1 rounded bg-flex-surface">⌘⌥I</kbd>) on this Flex tab, then paste:
            </p>
            <p className="font-medium text-slate-300">Same tab as Flex:</p>
            <pre className="p-3 rounded-lg bg-flex-bg border border-flex-border/40 text-flex-accent overflow-x-auto font-mono text-[11px]">
{`await window.FlexPlugins.consume({
  pluginId: 'flex.ext.snowflake',
  dataset: 'export_manifest',
});`}
            </pre>
            <p className="font-medium text-slate-300 mt-2">Different tab/window (EzTrac, etc.):</p>
            <pre className="p-3 rounded-lg bg-flex-bg border border-flex-border/40 text-flex-accent overflow-x-auto font-mono text-[11px]">
{`// Run in the OTHER window's console:
const flexWin = window.open('http://localhost:5173/plugins');
// After Flex loads:
await flexWin.FlexPlugins.flexRemote.consume(window, flexWin, {
  pluginId: 'flex.ext.snowflake',
  dataset: 'export_manifest',
});`}
            </pre>
            <p className="text-flex-warning">
              <code>window.FlexPlugins</code> is undefined in other windows by design — use{' '}
              <code>flexRemote</code> with a reference to the Flex tab.
            </p>
            <p>
              Partner apps: <Badge variant="neutral">flex-plugin-sdk</Badge> · Docs:{' '}
              <code>docs/PLUGINS.md</code>
            </p>
          </div>
        )}
      </section>
    </div>
  );
}

function BrowseAllAreas({
  catalog,
  host,
  busy,
  setBusy,
}: {
  catalog: ReturnType<typeof useFlexPlugins>['catalog'];
  host: ReturnType<typeof useFlexPlugins>['host'];
  busy: boolean;
  setBusy: (v: boolean) => void;
}) {
  const [areaId, setAreaId] = useState(catalog[0]?.id ?? '');
  const [lastGet, setLastGet] = useState<PluginConsumeResult | null>(null);
  const [browseError, setBrowseError] = useState<string | null>(null);

  const area = catalog.find((p) => p.id === areaId);
  const outbound = area?.datasets.filter((d) => d.direction === 'outbound' || d.direction === 'bidirectional') ?? [];
  const inbound = area?.datasets.filter((d) => d.direction === 'inbound') ?? [];
  const extensions = catalog.filter((p) => p.kind === 'extension');
  const core = catalog.filter((p) => p.kind !== 'extension');

  const runDataset = async (dataset: string, kind: 'get' | 'send') => {
    if (!areaId) return;
    setBusy(true);
    setBrowseError(null);
    setLastGet(null);
    try {
      if (kind === 'get') {
        const params =
          areaId === 'flex.integrations' && dataset === 'partner_consumption'
            ? { partner: 'eztrac' as const }
            : undefined;
        const out = host.consume({ pluginId: areaId, dataset, params });
        if ('ok' in out && out.ok) setLastGet(out);
        else setBrowseError('error' in out && out.error ? out.error : 'Failed');
      } else {
        await host.produce({
          pluginId: areaId,
          dataset,
          records: dataset === 'simulate_inbound_sync' ? [{ partner: 'eztrac' }] : [{}],
        });
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      {extensions.length === 0 && (
        <p className="text-sm text-flex-warning glass rounded-lg p-3 border border-flex-warning/30">
          No extensions in the catalog yet. Install one from the <strong>Marketplace</strong> tab first.
        </p>
      )}
      <label className="block text-sm text-flex-muted">
        Plugin (core + installed extensions)
        <select
          value={areaId}
          onChange={(e) => setAreaId(e.target.value)}
          className="mt-1 w-full px-3 py-2 rounded-lg bg-flex-surface border border-flex-border text-sm text-slate-200"
        >
          {extensions.length > 0 && (
            <optgroup label="Installed extensions">
              {extensions.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </optgroup>
          )}
          <optgroup label="Core Flex">
            {core.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </optgroup>
        </select>
      </label>
      {area && (
        <p className="text-sm text-flex-muted">{area.description}</p>
      )}
      {outbound.length > 0 && (
        <div>
          <p className="text-xs font-semibold uppercase text-flex-muted mb-2">You can get</p>
          <div className="flex flex-wrap gap-2">
            {outbound.map((d) => (
              <button
                key={d.name}
                type="button"
                disabled={busy}
                onClick={() => runDataset(d.name, 'get')}
                className="px-3 py-1.5 rounded-lg text-xs border border-flex-accent2/30 text-flex-accent2 hover:bg-flex-accent2/10"
              >
                {d.description.slice(0, 40)}
              </button>
            ))}
          </div>
        </div>
      )}
      {inbound.length > 0 && (
        <div>
          <p className="text-xs font-semibold uppercase text-flex-muted mb-2">You can send</p>
          <div className="flex flex-wrap gap-2">
            {inbound.map((d) => (
              <button
                key={d.name}
                type="button"
                disabled={busy}
                onClick={() => runDataset(d.name, 'send')}
                className="px-3 py-1.5 rounded-lg text-xs border border-flex-warning/30 text-flex-warning hover:bg-flex-warning/10"
              >
                {d.description.slice(0, 40)}
              </button>
            ))}
          </div>
        </div>
      )}
      <ExtensionTryResult result={lastGet} error={browseError} />
      <Link to={area?.route ?? '/'} className="text-sm text-flex-accent hover:underline inline-flex items-center gap-1">
        Open {area?.name} screen <ArrowRight className="w-3.5 h-3.5" />
      </Link>
    </div>
  );
}
