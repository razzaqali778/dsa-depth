import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Download, Eye, Plus, Send, Trash2, X, CheckCircle2, Users } from 'lucide-react';
import { ApprovalImpactModal } from '../components/ApprovalImpactModal';
import { ApprovalOutcomeNotification } from '../components/ApprovalOutcomeNotification';
import { PageHeader } from '../components/PageHeader';
import { Badge } from '../components/Badge';
import { TransferActivity } from '../components/TransferActivity';
import { FieldBoundaryModal } from '../components/FieldBoundaryModal';
import { useGovernanceEmbedded } from '../hooks/useGovernanceEmbedded';
import { simulateApprovalImpact } from '../lib/approvalImpact';
import { useFlex } from '../store/FlexContext';
import type { DataRequest, PublishedDataset } from '../types';

const appLabels = { eztrac: 'EzTrac', 'dhub-rpt': 'dhub-rpt (RTP)' };

export function DataExchange() {
  const {
    dataRequests,
    publishedDatasets,
    transferLog,
    kpis,
    approveRequest,
    rejectRequest,
    publishDataset,
    unpublishDataset,
    createDataset,
    archiveDataRequest,
    pendingCount,
    lastActionError,
    settings,
  } = useFlex();

  const location = useLocation();
  const embedded = useGovernanceEmbedded();
  const [previewRequest, setPreviewRequest] = useState<DataRequest | null>(null);
  const [publishPreview, setPublishPreview] = useState<PublishedDataset | null>(null);
  const [publishFlash, setPublishFlash] = useState<string | null>(null);
  const [notifyPrompt, setNotifyPrompt] = useState<{
    request: DataRequest;
    outcome: 'approved' | 'rejected';
  } | null>(null);
  const [showCreateDataset, setShowCreateDataset] = useState(false);
  const [newDataset, setNewDataset] = useState({ name: '', description: '', schema: 'field1,field2' });

  const pending = dataRequests.filter((r) => r.status === 'pending');
  const history = dataRequests.filter((r) => r.status !== 'pending');

  useEffect(() => {
    const previewId = (location.state as { previewRequestId?: string } | null)?.previewRequestId;
    if (!previewId) return;
    const req = dataRequests.find((r) => r.id === previewId && r.status === 'pending');
    if (req) setPreviewRequest(req);
    window.history.replaceState({}, document.title);
  }, [location.state, dataRequests]);

  const impact = previewRequest ? simulateApprovalImpact(previewRequest, kpis) : null;

  const confirmApprove = () => {
    if (!previewRequest) return;
    const req = previewRequest;
    if (!approveRequest(req.id)) return;
    setPreviewRequest(null);
    setNotifyPrompt({ request: req, outcome: 'approved' });
  };

  return (
    <div className={embedded ? undefined : 'page-shell'}>
      {!embedded && (
        <PageHeader
          title="Data Exchange Hub"
          description="Approve inbound requests from EzTrac and dhub-rpt, or publish datasets for them to consume."
          action={
            pendingCount > 0 ? (
              <Badge variant="warning">{pendingCount} awaiting approval</Badge>
            ) : undefined
          }
        />
      )}

      {notifyPrompt && (
        <ApprovalOutcomeNotification
          request={notifyPrompt.request}
          outcome={notifyPrompt.outcome}
          onDismiss={() => setNotifyPrompt(null)}
        />
      )}

      {publishFlash && (
        <div className="mb-6 p-4 rounded-xl border border-flex-success/40 bg-flex-success/10 flex gap-3">
          <CheckCircle2 className="w-5 h-5 text-flex-success shrink-0" />
          <p className="text-sm font-medium text-flex-success">{publishFlash}</p>
        </div>
      )}

      {lastActionError && (
        <div className="mb-6 p-4 rounded-xl border border-flex-danger/40 bg-flex-danger/10 text-sm text-flex-danger">
          {lastActionError}
        </div>
      )}

      <p className="text-xs text-flex-muted mb-4">
        Role: <span className="text-flex-accent capitalize">{settings.userRole}</span> — RBAC enforced on approve & publish
      </p>

      <section className="mb-10">
        <h3 className="font-display font-semibold text-lg mb-4 flex items-center gap-2">
          <Download className="w-5 h-5 text-flex-accent" />
          Inbound requests (approval required)
        </h3>
        {pending.length === 0 ? (
          <div className="glass rounded-2xl p-8 text-center text-flex-muted">
            <p>No pending requests.</p>
            <p className="text-sm mt-2">
              Go to <strong className="text-slate-200">Partner apps</strong> tab → simulate a request from EzTrac
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {pending.map((r) => (
              <div
                key={r.id}
                className="glass rounded-2xl p-5 shadow-card border-l-4 border-flex-warning animate-pulse"
                style={{ animationDuration: '2s' }}
              >
                <div className="flex flex-col gap-4">
                  <div>
                    <p className="font-semibold">{r.dataset}</p>
                    <p className="text-sm text-flex-muted mt-1">
                      From <Badge variant="info">{appLabels[r.fromApp]}</Badge> ·{' '}
                      {r.recordCount.toLocaleString()} records
                    </p>
                    <p className="text-sm mt-2">{r.purpose}</p>
                    <p className="text-xs text-flex-muted mt-1">
                      {new Date(r.requestedAt).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setPreviewRequest(r)}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-flex-accent/15 text-flex-accent border border-flex-accent/40 hover:bg-flex-accent/25 text-sm font-medium"
                    >
                      <Eye className="w-4 h-4" />
                      Preview impact
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!rejectRequest(r.id)) return;
                        setNotifyPrompt({ request: r, outcome: 'rejected' });
                      }}
                      className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-flex-danger/20 text-flex-danger border border-flex-danger/40 hover:bg-flex-danger/30 text-sm font-medium"
                    >
                      <X className="w-4 h-4" />
                      Reject
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="mb-10">
        <h3 className="font-display font-semibold text-lg mb-4">Request history</h3>
        <div className="table-scroll">
          <div className="glass rounded-2xl overflow-x-auto">
            <table className="w-full text-sm min-w-[400px]">
              <thead>
                <tr className="border-b border-flex-border/60 text-left text-flex-muted">
                  <th className="p-3">Dataset</th>
                  <th className="p-3">Source</th>
                  <th className="p-3">Records</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {history.map((r) => (
                  <tr key={r.id} className="border-b border-flex-border/30">
                    <td className="p-3 font-mono text-xs">{r.dataset}</td>
                    <td className="p-3">{appLabels[r.fromApp]}</td>
                    <td className="p-3">{r.recordCount}</td>
                    <td className="p-3 flex items-center gap-2">
                      <Badge variant={r.status === 'approved' ? 'success' : 'danger'}>
                        {r.status}
                      </Badge>
                      <button
                        type="button"
                        onClick={() => archiveDataRequest(r.id)}
                        className="p-1 text-flex-muted hover:text-flex-danger"
                        aria-label="Archive"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section>
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <h3 className="font-display font-semibold text-lg flex items-center gap-2">
            <Send className="w-5 h-5 text-flex-accent2" />
            Published datasets (outbound)
          </h3>
          <button
            type="button"
            onClick={() => setShowCreateDataset(!showCreateDataset)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-flex-accent/15 text-flex-accent border border-flex-accent/30"
          >
            <Plus className="w-3.5 h-3.5" />
            New dataset
          </button>
        </div>
        {showCreateDataset && (
          <div className="glass rounded-xl p-4 mb-4 border border-flex-accent/30">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input placeholder="Dataset name" value={newDataset.name} onChange={(e) => setNewDataset({ ...newDataset, name: e.target.value })} className="px-3 py-2 rounded-lg bg-flex-surface border border-flex-border text-sm" />
              <input placeholder="Schema (comma-separated)" value={newDataset.schema} onChange={(e) => setNewDataset({ ...newDataset, schema: e.target.value })} className="px-3 py-2 rounded-lg bg-flex-surface border border-flex-border text-sm" />
              <input placeholder="Description" value={newDataset.description} onChange={(e) => setNewDataset({ ...newDataset, description: e.target.value })} className="px-3 py-2 rounded-lg bg-flex-surface border border-flex-border text-sm sm:col-span-2" />
            </div>
            <button
              type="button"
              onClick={() => {
                if (!newDataset.name.trim()) return;
                createDataset({
                  name: newDataset.name,
                  description: newDataset.description || 'Custom dataset',
                  schema: newDataset.schema.split(',').map((s) => s.trim()).filter(Boolean),
                  consumers: [],
                  recordCount: 0,
                });
                setNewDataset({ name: '', description: '', schema: 'field1,field2' });
                setShowCreateDataset(false);
              }}
              className="mt-3 px-4 py-2 rounded-lg bg-flex-accent text-flex-bg text-sm font-medium"
            >
              Create draft
            </button>
          </div>
        )}
        <div className="grid grid-cols-1 gap-4">
          {publishedDatasets.map((d) => (
            <div key={d.id} className="glass rounded-2xl p-5 shadow-card">
              <div className="flex justify-between items-start gap-2">
                <div>
                  <p className="font-semibold font-mono text-sm">{d.name}</p>
                  <Badge variant={d.status === 'active' ? 'success' : 'neutral'} className="mt-2">
                    {d.status}
                  </Badge>
                </div>
                {d.status === 'draft' && (
                  <button
                    type="button"
                    onClick={() => setPublishPreview(d)}
                    className="px-3 py-1.5 rounded-lg bg-flex-accent2/20 text-flex-accent2 border border-flex-accent2/40 text-xs font-medium hover:bg-flex-accent2/30 shrink-0"
                  >
                    Review & publish
                  </button>
                )}
                {d.status === 'active' && (
                  <button
                    type="button"
                    onClick={() => unpublishDataset(d.id)}
                    className="px-3 py-1.5 rounded-lg bg-flex-warning/15 text-flex-warning border border-flex-warning/30 text-xs font-medium shrink-0"
                  >
                    Unpublish
                  </button>
                )}
              </div>
              <p className="text-sm text-flex-muted mt-3">{d.description}</p>
              {d.consumers.length > 0 ? (
                <p className="text-xs mt-2 flex items-center gap-1.5 text-flex-accent">
                  <Users className="w-3.5 h-3.5 shrink-0" />
                  Consumed by {d.consumers.map((c) => appLabels[c as keyof typeof appLabels] ?? c).join(' · ')}
                </p>
              ) : d.status === 'draft' ? (
                <p className="text-xs mt-2 text-flex-warning">Not yet consumed — publish to deliver to EzTrac / dhub-rpt</p>
              ) : null}
              {d.lastPublished && (
                <p className="text-xs text-flex-muted mt-1">
                  Last sent: {new Date(d.lastPublished).toLocaleString()} ·{' '}
                  {d.recordCount.toLocaleString()} rows
                </p>
              )}
            </div>
          ))}
        </div>
      </section>

      <section className="mt-10 pt-8 border-t border-flex-border/50">
        <h3 className="font-display font-semibold text-lg mb-2">Audit trail</h3>
        <p className="text-xs text-flex-muted mb-4">
          Only place for transfer history — not repeated on Dashboard or Integrations.
        </p>
        <TransferActivity entries={transferLog} limit={10} />
      </section>

      {previewRequest && impact && (
        <ApprovalImpactModal
          request={previewRequest}
          impact={impact}
          onConfirm={confirmApprove}
          onClose={() => setPreviewRequest(null)}
        />
      )}

      {publishPreview && (
        <FieldBoundaryModal
          dataset={publishPreview}
          onConfirm={() => {
            if (publishDataset(publishPreview.id)) {
              setPublishFlash(`Published ${publishPreview.name} — undo available for 8s.`);
              setTimeout(() => setPublishFlash(null), 4000);
            }
            setPublishPreview(null);
          }}
          onClose={() => setPublishPreview(null)}
        />
      )}
    </div>
  );
}
