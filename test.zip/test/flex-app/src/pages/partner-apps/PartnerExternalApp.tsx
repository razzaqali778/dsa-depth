import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  Database,
  Radio,
  RefreshCw,
  Send,
} from 'lucide-react';
import { Badge } from '../../components/Badge';
import { isFlexReachable, partnerConsume, partnerProduce } from '../../lib/flexPartnerClient';
import { PLUGIN_PRESETS, type PluginPreset } from '../../lib/pluginPresets';
import type { PluginConsumeResult, PluginProduceResult } from '../../plugins/types';

export type PartnerId = 'eztrac' | 'dhub-rpt';

const PARTNER_META: Record<
  PartnerId,
  { title: string; subtitle: string; accent: string; border: string; badge: string }
> = {
  eztrac: {
    title: 'EzTrac',
    subtitle: 'Finance & variance — consumes Flex via plugins only',
    accent: 'text-emerald-400',
    border: 'border-emerald-500/30',
    badge: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40',
  },
  'dhub-rpt': {
    title: 'dhub-rpt',
    subtitle: 'Planning & capacity — consumes Flex via plugins only',
    accent: 'text-violet-400',
    border: 'border-violet-500/30',
    badge: 'bg-violet-500/15 text-violet-300 border-violet-500/40',
  },
};

function presetForPartner(p: PluginPreset, partner: PartnerId): boolean {
  if (p.id.includes('eztrac') && partner !== 'eztrac') return false;
  if (p.id.includes('dhub') && partner !== 'dhub-rpt') return false;
  if (p.kind === 'get' && p.dataset === 'partner_consumption') {
    return p.params?.partner === partner;
  }
  if (p.kind === 'send' && p.sendForm === 'partner-sync') {
    return p.id.includes(partner === 'eztrac' ? 'eztrac' : 'dhub');
  }
  if (p.kind === 'send' && p.id.includes('eztrac') && partner !== 'eztrac') return false;
  if (p.kind === 'send' && p.id.includes('dhub') && partner !== 'dhub-rpt') return false;
  return true;
}

export function PartnerExternalApp({ partner }: { partner: PartnerId }) {
  const meta = PARTNER_META[partner];
  const [connected, setConnected] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<unknown>(null);
  const [error, setError] = useState<string | null>(null);
  const [recordCount, setRecordCount] = useState(800);
  const [purpose, setPurpose] = useState(`Data refresh from ${meta.title}`);

  const getPresets = useMemo(
    () => PLUGIN_PRESETS.filter((p) => p.kind === 'get' && presetForPartner(p, partner)),
    [partner]
  );
  const sendPresets = useMemo(
    () => PLUGIN_PRESETS.filter((p) => p.kind === 'send' && presetForPartner(p, partner)),
    [partner]
  );

  const check = useCallback(async () => {
    const ok = await isFlexReachable();
    setConnected(ok);
    return ok;
  }, []);

  useEffect(() => {
    void check();
    const t = setInterval(() => void check(), 5000);
    return () => clearInterval(t);
  }, [check]);

  const runGet = async (preset: PluginPreset) => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab (same browser), then retry.');
        return;
      }
      const params =
        preset.dataset === 'partner_consumption' ? { partner } : preset.params;
      const out = await partnerConsume({
        pluginId: preset.pluginId,
        dataset: preset.dataset,
        params,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Consume failed');
    } finally {
      setBusy(false);
    }
  };

  const runSync = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const out = await partnerProduce({
        pluginId: 'flex.integrations',
        dataset: 'simulate_inbound_sync',
        records: [{ partner }],
        sourceApp: partner,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Produce failed');
    } finally {
      setBusy(false);
    }
  };

  const runInbound = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const dataset = partner === 'eztrac' ? 'forecast_variance' : 'capacity_forecast';
      const out = await partnerProduce({
        pluginId: 'flex.governance',
        dataset: 'inbound_request',
        records: [
          {
            fromApp: partner,
            dataset,
            recordCount,
            purpose,
          },
        ],
        sourceApp: partner,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Produce failed');
    } finally {
      setBusy(false);
    }
  };

  const runPull = async () => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      if (!(await check())) {
        setError('Open Flex in another tab first.');
        return;
      }
      const out = await partnerProduce({
        pluginId: 'flex.integrations',
        dataset: 'pull_outbound',
        records: [{ partner }],
        sourceApp: partner,
      });
      setResult(out);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Produce failed');
    } finally {
      setBusy(false);
    }
  };

  const successMessage =
    result && typeof result === 'object' && result !== null && 'ok' in result
      ? (result as PluginConsumeResult | PluginProduceResult).ok
        ? 'message' in result
          ? String((result as PluginProduceResult).message)
          : `Loaded ${(result as PluginConsumeResult).meta?.recordCount ?? 0} record(s)`
        : null
      : null;

  return (
    <div>
      <div className={`rounded-2xl border p-6 mb-6 ${meta.border} bg-slate-900/80`}>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className={`text-xs font-semibold uppercase tracking-wide ${meta.accent}`}>
              Partner application
            </p>
            <h1 className="text-2xl font-bold mt-1">{meta.title}</h1>
            <p className="text-sm text-slate-400 mt-1">{meta.subtitle}</p>
          </div>
          <span className={`text-xs px-2.5 py-1 rounded-full border ${meta.badge}`}>
            sourceApp: {partner}
          </span>
        </div>
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 mb-6 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm font-medium flex items-center gap-2">
            <Radio className={`w-4 h-4 ${meta.accent}`} />
            Flex plugin bridge
          </p>
          {connected === true && <Badge variant="success">Connected</Badge>}
          {connected === false && <Badge variant="danger">Flex not reachable</Badge>}
          {connected === null && <Badge variant="neutral">Checking…</Badge>}
        </div>
        <p className="text-xs text-slate-500">
          No REST API. This app calls <code className="text-slate-300">consume</code> /{' '}
          <code className="text-slate-300">produce</code> on Flex plugins via BroadcastChannel.
          Keep <strong>Flex</strong> open in another tab on this site.
        </p>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => void check()}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs border border-slate-700"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
          <a
            href="/"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs border border-emerald-600/40 text-emerald-400"
          >
            Open Flex
          </a>
        </div>
      </div>

      <section className="mb-8">
        <h2 className="font-semibold text-sm flex items-center gap-2 mb-3 text-slate-200">
          <ArrowDownToLine className="w-4 h-4 text-sky-400" />
          Consume — read from Flex
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {getPresets.map((preset) => (
            <button
              key={preset.id}
              type="button"
              disabled={busy}
              onClick={() => void runGet(preset)}
              className="text-left p-3 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-sky-500/40 text-sm disabled:opacity-50"
            >
              <p className="font-medium">{preset.label}</p>
              <p className="text-xs text-slate-500 mt-1">{preset.description}</p>
              <p className="text-[10px] font-mono text-slate-600 mt-2">
                {preset.pluginId} → {preset.dataset}
              </p>
            </button>
          ))}
        </div>
      </section>

      <section className="mb-8">
        <h2 className="font-semibold text-sm flex items-center gap-2 mb-3 text-slate-200">
          <ArrowUpFromLine className="w-4 h-4 text-amber-400" />
          Produce — send to Flex
        </h2>
        <div className="space-y-3">
          <button
            type="button"
            disabled={busy}
            onClick={() => void runSync()}
            className="w-full text-left p-3 rounded-xl border border-amber-500/25 bg-amber-500/5 hover:bg-amber-500/10 text-sm disabled:opacity-50"
          >
            <p className="font-medium flex items-center gap-2">
              <Send className="w-4 h-4" />
              Simulate inbound sync
            </p>
            <p className="text-xs text-slate-500 mt-1 font-mono">
              flex.integrations → simulate_inbound_sync
            </p>
          </button>

          <div className="p-4 rounded-xl border border-slate-800 space-y-3">
            <p className="font-medium text-sm flex items-center gap-2">
              <Database className="w-4 h-4 text-violet-400" />
              Governed inbound request
            </p>
            <p className="text-xs text-slate-500 font-mono">flex.governance → inbound_request</p>
            <label className="block text-xs text-slate-400">
              Record count
              <input
                type="number"
                value={recordCount}
                onChange={(e) => setRecordCount(Number(e.target.value))}
                className="mt-1 block w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm"
              />
            </label>
            <label className="block text-xs text-slate-400">
              Purpose
              <input
                type="text"
                value={purpose}
                onChange={(e) => setPurpose(e.target.value)}
                className="mt-1 block w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm"
              />
            </label>
            <button
              type="button"
              disabled={busy}
              onClick={() => void runInbound()}
              className="px-4 py-2 rounded-lg text-sm bg-violet-600 hover:bg-violet-500 disabled:opacity-50"
            >
              Send inbound request
            </button>
          </div>

          <button
            type="button"
            disabled={busy}
            onClick={() => void runPull()}
            className="w-full text-left p-3 rounded-xl border border-slate-800 text-sm disabled:opacity-50"
          >
            <p className="font-medium">Pull published datasets</p>
            <p className="text-xs text-slate-500 mt-1 font-mono">
              flex.integrations → pull_outbound
            </p>
          </button>
        </div>
      </section>

      {error && (
        <div className="p-4 rounded-xl border border-red-500/40 bg-red-500/10 text-sm text-red-300 mb-4">
          {error}
        </div>
      )}

      {successMessage && (
        <div className="p-4 rounded-xl border border-emerald-500/40 bg-emerald-500/10 text-sm text-emerald-300 mb-4">
          {successMessage}
          <Link
            to="/govern/exchange"
            target="_blank"
            rel="noreferrer"
            className="block mt-2 underline"
          >
            View approvals in Flex →
          </Link>
        </div>
      )}

      {result !== null && (
        <div className="rounded-xl p-4 border border-slate-800 bg-slate-950">
          <p className="text-xs font-semibold uppercase text-slate-500 mb-2">Plugin response</p>
          <pre className="text-xs font-mono text-slate-400 overflow-x-auto max-h-72">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}

      <p className="text-xs text-slate-600 mt-8">
        SDK: <code className="text-slate-400">flex-plugin-sdk</code> with{' '}
        <code className="text-slate-400">createFlexPluginClient()</code> — no apiUrl.{' '}
        <Link to="/partner" className="text-emerald-500 underline">
          Partner console
        </Link>
      </p>
    </div>
  );
}
