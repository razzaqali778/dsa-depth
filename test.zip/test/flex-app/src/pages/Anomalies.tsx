import { CheckCircle, ChevronDown, ChevronUp, Plus, RotateCcw, Search, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { PageHeader } from '../components/PageHeader';
import { Badge } from '../components/Badge';
import { AnomalyStoryPanel } from '../components/AnomalyStoryPanel';
import { AssignOwnerPrompt } from '../components/AssignOwnerPrompt';
import { buildAnomalyStory } from '../lib/anomalyStory';
import { useFlex } from '../store/FlexContext';
import type { Anomaly } from '../types';

const severityVariant = {
  critical: 'danger' as const,
  high: 'warning' as const,
  medium: 'info' as const,
  low: 'neutral' as const,
};

const emptyForm = {
  title: '',
  service: 'EC2',
  severity: 'medium' as Anomaly['severity'],
  impact: '',
  deltaPercent: 0,
};

export function Anomalies() {
  const { anomalies, transferLog, resolveAnomaly, reopenAnomaly, assignAnomalyOwner, createAnomaly, updateAnomaly, deleteAnomaly } = useFlex();
  const [filter, setFilter] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [editId, setEditId] = useState<string | null>(null);

  const filtered =
    filter === 'all' ? anomalies : anomalies.filter((a) => a.status === filter);

  const submitForm = () => {
    if (!form.title.trim()) return;
    if (editId) {
      updateAnomaly(editId, {
        title: form.title,
        service: form.service,
        severity: form.severity,
        impact: form.impact,
      });
      setEditId(null);
    } else {
      createAnomaly({
        title: form.title,
        service: form.service,
        severity: form.severity,
        impact: form.impact || 'Under review',
        detectedAt: new Date().toISOString(),
        status: 'open',
        deltaPercent: form.deltaPercent,
      });
    }
    setForm(emptyForm);
    setShowForm(false);
  };

  const startEdit = (a: Anomaly) => {
    setEditId(a.id);
    setForm({
      title: a.title,
      service: a.service,
      severity: a.severity,
      impact: a.impact,
      deltaPercent: a.deltaPercent,
    });
    setShowForm(true);
  };

  return (
    <div className="page-shell">
      <PageHeader
        title="Anomaly Detection"
        description="Create, assign, resolve, and track cost anomalies with incident stories."
        action={
          <div className="flex gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => { setShowForm(!showForm); setEditId(null); setForm(emptyForm); }}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium bg-flex-accent/15 text-flex-accent border border-flex-accent/30"
            >
              <Plus className="w-4 h-4" />
              New anomaly
            </button>
            <div className="flex gap-1.5 overflow-x-auto">
              {(['all', 'open', 'investigating', 'resolved'] as const).map((f) => (
                <button
                  key={f}
                  type="button"
                  onClick={() => setFilter(f)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs capitalize whitespace-nowrap ${
                    filter === f
                      ? 'bg-flex-accent/20 text-flex-accent border border-flex-accent/40'
                      : 'text-flex-muted hover:bg-flex-surface border border-transparent'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        }
      />

      {showForm && (
        <div className="glass rounded-xl p-4 mb-6 border border-flex-accent/30">
          <h4 className="font-medium mb-3">{editId ? 'Edit anomaly' : 'Report new anomaly'}</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <input
              placeholder="Title"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              className="px-3 py-2 rounded-lg bg-flex-surface border border-flex-border text-sm"
            />
            <input
              placeholder="Service (e.g. EC2)"
              value={form.service}
              onChange={(e) => setForm({ ...form, service: e.target.value })}
              className="px-3 py-2 rounded-lg bg-flex-surface border border-flex-border text-sm"
            />
            <select
              value={form.severity}
              onChange={(e) => setForm({ ...form, severity: e.target.value as Anomaly['severity'] })}
              className="px-3 py-2 rounded-lg bg-flex-surface border border-flex-border text-sm"
            >
              {(['critical', 'high', 'medium', 'low'] as const).map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <input
              placeholder="Impact (e.g. +$5K projected)"
              value={form.impact}
              onChange={(e) => setForm({ ...form, impact: e.target.value })}
              className="px-3 py-2 rounded-lg bg-flex-surface border border-flex-border text-sm"
            />
          </div>
          <div className="flex gap-2 mt-3">
            <button type="button" onClick={submitForm} className="px-4 py-2 rounded-lg bg-flex-accent text-flex-bg text-sm font-medium">
              {editId ? 'Save' : 'Create'}
            </button>
            <button type="button" onClick={() => { setShowForm(false); setEditId(null); }} className="px-4 py-2 rounded-lg text-sm text-flex-muted">
              Cancel
            </button>
          </div>
        </div>
      )}

      <div className="space-y-3 sm:space-y-4">
        {filtered.map((a) => {
          const expanded = expandedId === a.id;
          const story = buildAnomalyStory(a, transferLog);
          return (
            <div key={a.id} className="glass rounded-xl sm:rounded-2xl p-4 sm:p-5 shadow-card">
              <div className="flex flex-col sm:flex-row sm:flex-wrap sm:items-start sm:justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-sm sm:text-base break-words">{a.title}</h3>
                    <Badge variant={severityVariant[a.severity]}>{a.severity}</Badge>
                    <Badge variant={a.status === 'resolved' ? 'success' : 'warning'}>{a.status}</Badge>
                  </div>
                  <p className="text-xs sm:text-sm text-flex-muted mt-2">
                    {a.service} · {new Date(a.detectedAt).toLocaleString()}
                  </p>
                  <p className="text-sm mt-2 text-flex-accent break-words">{a.impact}</p>
                  <AssignOwnerPrompt
                    anomaly={a}
                    onAssign={(_id, name, squad) => assignAnomalyOwner(a.id, name, squad)}
                  />
                </div>
                <div className="flex flex-wrap gap-2 shrink-0">
                  <button type="button" onClick={() => startEdit(a)} className="px-3 py-2 rounded-lg text-xs bg-flex-surface border border-flex-border">
                    Edit
                  </button>
                  <button type="button" onClick={() => setExpandedId(expanded ? null : a.id)} className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-flex-accent/10 text-flex-accent border border-flex-accent/30 text-sm font-medium">
                    {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    Story
                  </button>
                  {a.status !== 'resolved' ? (
                    <button type="button" onClick={() => resolveAnomaly(a.id)} className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-flex-success/20 text-flex-success border border-flex-success/40 text-sm font-medium">
                      <CheckCircle className="w-4 h-4" />
                      Resolve
                    </button>
                  ) : (
                    <button type="button" onClick={() => reopenAnomaly(a.id)} className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs border border-flex-border">
                      <RotateCcw className="w-3.5 h-3.5" />
                      Reopen
                    </button>
                  )}
                  <button type="button" onClick={() => deleteAnomaly(a.id)} className="p-2 rounded-lg text-flex-danger hover:bg-flex-danger/10" aria-label="Delete">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              {expanded && <AnomalyStoryPanel phases={story} />}
            </div>
          );
        })}
      </div>

      <div className="mt-6 sm:mt-8 glass rounded-xl sm:rounded-2xl p-4 sm:p-6 flex flex-col sm:flex-row items-start gap-4">
        <Search className="w-8 h-8 text-flex-muted shrink-0" />
        <div className="min-w-0">
          <p className="font-medium text-sm sm:text-base">Correlated with transfers & deploys</p>
          <p className="text-sm text-flex-muted mt-1">
            Publish anomaly_feed in Governance → Exchange so EzTrac risk models stay in sync.
          </p>
        </div>
      </div>
    </div>
  );
}
