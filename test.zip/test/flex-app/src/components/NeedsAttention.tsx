import { Link } from 'react-router-dom';
import { GitCompareArrows } from 'lucide-react';
import { alignmentScore } from '../data/alignment';
import { useFlex } from '../store/FlexContext';

/** One strip on Dashboard — links out, no duplicate actions. */
export function NeedsAttention() {
  const { pendingCount, kpis } = useFlex();

  if (pendingCount === 0 && kpis.openAnomalies === 0 && alignmentScore >= 80) return null;

  return (
    <div className="glass rounded-xl p-4 mb-6 flex flex-wrap gap-4 items-center justify-between border border-flex-warning/30">
      <p className="text-sm font-medium">Needs attention</p>
      <div className="flex flex-wrap gap-3 text-sm">
        {pendingCount > 0 && (
          <Link to="/govern/exchange" className="text-flex-warning hover:underline">
            {pendingCount} approval{pendingCount > 1 ? 's' : ''} → Governance
          </Link>
        )}
        {kpis.openAnomalies > 0 && (
          <Link to="/anomalies" className="text-flex-danger hover:underline">
            {kpis.openAnomalies} anomalies →
          </Link>
        )}
        {alignmentScore < 80 && (
          <Link to="/govern/alignment" className="text-flex-accent flex items-center gap-1 hover:underline">
            <GitCompareArrows className="w-4 h-4" />
            Alignment {alignmentScore}% →
          </Link>
        )}
      </div>
    </div>
  );
}
