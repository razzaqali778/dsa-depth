import { Link } from 'react-router-dom';
import { MousePointerClick } from 'lucide-react';

export function ExtensionsGuide() {
  return (
    <div className="glass rounded-xl p-4 sm:p-5 border border-flex-accent/25 text-sm space-y-4">
      <p className="font-semibold flex items-center gap-2">
        <MousePointerClick className="w-4 h-4 text-flex-accent" />
        One extension per feature (like VS Code)
      </p>

      <p className="text-slate-300 text-sm">
        Each Flex screen is a separate extension: Dashboard, Chargeback, Governance, Anomalies, etc.
        Disable an extension → its menu item and page go away. Add-ons (PagerDuty, Snowflake) install
        on top.
      </p>

      <div className="overflow-x-auto">
        <table className="w-full text-xs text-left">
          <thead>
            <tr className="text-flex-muted border-b border-flex-border/40">
              <th className="py-2 pr-4">VS Code</th>
              <th className="py-2">Flex</th>
            </tr>
          </thead>
          <tbody className="text-slate-300">
            <tr className="border-b border-flex-border/20">
              <td className="py-2 pr-4">Python extension</td>
              <td className="py-2">Dashboard feature pack</td>
            </tr>
            <tr className="border-b border-flex-border/20">
              <td className="py-2 pr-4">Disable extension</td>
              <td className="py-2">Disable → hides sidebar + blocks route</td>
            </tr>
            <tr className="border-b border-flex-border/20">
              <td className="py-2 pr-4">Built-in extensions</td>
              <td className="py-2">Feature packs (cannot uninstall)</td>
            </tr>
            <tr>
              <td className="py-2 pr-4">Marketplace add-on</td>
              <td className="py-2">PagerDuty, Jira, Snowflake…</td>
            </tr>
          </tbody>
        </table>
      </div>

      <ol className="list-decimal list-inside space-y-1.5 text-slate-300 text-sm">
        <li>
          <Link to="/plugins" className="text-flex-accent underline">
            Tools → Extensions
          </Link>
        </li>
        <li>
          Filter <strong>Feature packs</strong> — try disabling <strong>Chargeback</strong>
        </li>
        <li>Check sidebar: Chargeback disappears</li>
        <li>Filter <strong>Add-ons</strong> → Install Snowflake</li>
      </ol>
    </div>
  );
}
