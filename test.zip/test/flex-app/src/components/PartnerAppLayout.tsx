import { Link, Outlet } from 'react-router-dom';

/** Minimal chrome — simulates EzTrac / dhub-rpt as a separate app (not Flex UI). */
export function PartnerAppLayout() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-4">
          <Link to="/apps/eztrac" className="text-sm font-semibold hover:text-white text-slate-400">
            EzTrac
          </Link>
          <span className="text-slate-700">|</span>
          <Link to="/apps/dhub-rpt" className="text-sm font-semibold hover:text-white text-slate-400">
            dhub-rpt
          </Link>
        </div>
        <p className="text-xs text-slate-500">
          Plugins only — open{' '}
          <a href="/" target="_blank" rel="noreferrer" className="text-emerald-400 underline">
            Flex
          </a>{' '}
          in another tab
        </p>
      </header>
      <main className="p-4 md:p-8 max-w-4xl mx-auto">
        <Outlet />
      </main>
    </div>
  );
}
