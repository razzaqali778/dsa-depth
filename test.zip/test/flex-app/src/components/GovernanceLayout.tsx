import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { Shield } from 'lucide-react';
import { PageHeader } from './PageHeader';
import { Badge } from './Badge';
import { GOVERNANCE_TABS } from '../lib/navStructure';
import { useExtensionNav } from '../hooks/useExtensionNav';
import { useFlex } from '../store/FlexContext';

export function GovernanceLayout() {
  const { pendingCount } = useFlex();
  const location = useLocation();
  const { isEnabled } = useExtensionNav();
  const tabs = GOVERNANCE_TABS.filter((t) => isEnabled(t.pluginId));

  return (
    <div className="page-shell">
      <PageHeader
        title="Governance"
        description="One workflow: trigger partner requests → approve & publish → verify alignment across apps."
        action={
          pendingCount > 0 ? (
            <Badge variant="warning">{pendingCount} awaiting approval</Badge>
          ) : undefined
        }
      />

      <div className="mb-6 flex items-start gap-3 p-4 rounded-xl border border-flex-accent/20 bg-flex-accent/5 text-sm">
        <Shield className="w-5 h-5 text-flex-accent shrink-0 mt-0.5" />
        <p className="text-flex-muted">
          <strong className="text-slate-200">Step 1</strong> — Partner apps ·{' '}
          <strong className="text-slate-200">Step 2</strong> — Approvals & publish ·{' '}
          <strong className="text-slate-200">Step 3</strong> — Alignment check
        </p>
      </div>

      <nav
        className="flex gap-1 p-1 mb-6 rounded-xl bg-flex-surface/50 border border-flex-border/50 overflow-x-auto"
        aria-label="Governance sections"
      >
        {tabs.map((tab) => {
          const active = location.pathname.startsWith(tab.to);
          return (
            <NavLink
              key={tab.to}
              to={tab.to}
              className={`flex-1 min-w-[120px] px-3 py-2.5 rounded-lg text-center transition-colors ${
                active
                  ? 'bg-flex-accent/15 text-flex-accent border border-flex-accent/30'
                  : 'text-flex-muted hover:text-slate-200 hover:bg-flex-surface/80 border border-transparent'
              }`}
            >
              <span className="block text-sm font-medium">{tab.label}</span>
              <span className="block text-[10px] mt-0.5 opacity-80 hidden sm:block">{tab.short}</span>
            </NavLink>
          );
        })}
      </nav>

      <Outlet />
    </div>
  );
}
