import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { DASHBOARD_HUB } from '../lib/navStructure';
import { filterRoutesByFeaturePlugins } from '../lib/featurePlugins';

export function DashboardHub() {
  return (
    <section className="mt-8">
      <h2 className="font-display font-semibold text-base mb-1">Explore by area</h2>
      <p className="text-xs text-flex-muted mb-4">
        Only enabled feature plugins appear — manage them in Extensions.
      </p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {DASHBOARD_HUB.map((group) => {
          const links = filterRoutesByFeaturePlugins(group.links);
          if (!links.length) return null;
          return (
          <div
            key={group.section}
            className="glass rounded-xl p-4 border border-flex-border/40 hover:border-flex-accent/25 transition-colors"
          >
            <p className="text-sm font-semibold text-slate-200">{group.section}</p>
            <p className="text-xs text-flex-muted mt-0.5 mb-3">{group.description}</p>
            <ul className="space-y-1.5">
              {links.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="flex items-center justify-between text-sm text-flex-muted hover:text-flex-accent group"
                  >
                    <span>{link.label}</span>
                    <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          );
        })}
      </div>
    </section>
  );
}
