import { BUILTIN_MARKETPLACE } from '../plugins/marketplace/builtinCatalog';
import { isPluginEnabled } from '../plugins/manager';
import { pluginIdForPath } from '../plugins/marketplace/routeRegistry';

/** Built-in Flex feature packs (one plugin per screen) — excludes flex.ext.* add-ons */
export const FEATURE_PLUGIN_LIST = BUILTIN_MARKETPLACE.filter(
  (l) => l.builtin && !l.id.startsWith('flex.ext.')
);

export function isFeatureRouteEnabled(routeOrTo: string): boolean {
  const pluginId = pluginIdForPath(routeOrTo);
  if (!pluginId) return true;
  return isPluginEnabled(pluginId);
}

type Routable = { route?: string; to?: string; pluginId?: string };

export function filterRoutesByFeaturePlugins<T extends Routable>(items: T[]): T[] {
  return items.filter((item) => {
    const path = item.route ?? item.to ?? '/';
    const pluginId = item.pluginId ?? pluginIdForPath(path);
    if (!pluginId) return true;
    return isPluginEnabled(pluginId);
  });
}
