import type { FlexState } from '../store/flexTypes';

const API_URL = import.meta.env.VITE_FLEX_API_URL ?? 'http://localhost:3847';

let syncTimer: ReturnType<typeof setTimeout> | null = null;

/** Push Flex state to local API (VS Code extension reads the same data). */
export function scheduleSyncStateToApi(state: FlexState): void {
  if (syncTimer) clearTimeout(syncTimer);
  syncTimer = setTimeout(() => {
    void syncStateToApi(state);
  }, 400);
}

export async function syncStateToApi(state: FlexState): Promise<boolean> {
  try {
    const res = await fetch(`${API_URL}/api/v1/sync`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(state),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function pullStateFromApi(): Promise<FlexState | null> {
  try {
    const res = await fetch(`${API_URL}/api/v1/state`);
    if (!res.ok) return null;
    return (await res.json()) as FlexState;
  } catch {
    return null;
  }
}

export function getFlexApiUrl(): string {
  return API_URL;
}
