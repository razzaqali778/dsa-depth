import type { PluginConsumeRequest, PluginProduceRequest } from '../plugins/types';
import {
  FLEX_PLUGIN_CHANNEL,
  type FlexPluginBridgeMessage,
  type FlexPluginBridgeResponse,
} from './pluginBridge';

/**
 * Call Flex from another tab/window on the same origin (EzTrac, dhub-rpt demo).
 * Requires Flex app open in another tab — uses BroadcastChannel (no flexWin hack).
 */
export function partnerFlexRequest<T>(
  method: FlexPluginBridgeMessage['method'],
  payload?: PluginConsumeRequest | PluginProduceRequest
): Promise<T> {
  if (typeof BroadcastChannel === 'undefined') {
    return Promise.reject(new Error('BroadcastChannel not supported in this browser'));
  }

  return new Promise((resolve, reject) => {
    const bc = new BroadcastChannel(FLEX_PLUGIN_CHANNEL);
    const id = `fp-partner-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    const onMsg = (ev: MessageEvent) => {
      const data = ev.data as FlexPluginBridgeResponse | undefined;
      if (!data || data.channel !== FLEX_PLUGIN_CHANNEL || data.id !== id) return;
      bc.removeEventListener('message', onMsg);
      bc.close();
      if (data.ok) resolve(data.result as T);
      else reject(new Error(data.error ?? 'Flex plugin request failed'));
    };

    bc.addEventListener('message', onMsg);
    bc.postMessage({
      channel: FLEX_PLUGIN_CHANNEL,
      id,
      method,
      payload,
    } satisfies FlexPluginBridgeMessage);

    setTimeout(() => {
      bc.removeEventListener('message', onMsg);
      bc.close();
      reject(
        new Error(
          'Cannot reach Flex. Open Flex in another tab (same browser, e.g. / or /plugins), then try again.'
        )
      );
    }, 10000);
  });
}

export function partnerCatalog() {
  return partnerFlexRequest<unknown[]>('catalog', undefined);
}

export function partnerConsume(req: PluginConsumeRequest & { params?: Record<string, unknown> }) {
  return partnerFlexRequest<unknown>('consume', req);
}

export function partnerProduce(req: PluginProduceRequest) {
  return partnerFlexRequest<unknown>('produce', req);
}

/** Quick health check — true if Flex tab is listening */
export async function isFlexReachable(): Promise<boolean> {
  try {
    await partnerCatalog();
    return true;
  } catch {
    return false;
  }
}
