import { EXTENSION_BUNDLES } from './marketplace/bundles';
import { MARKETPLACE_CATALOG } from './marketplace/catalog';
import {
  getInstalledExtensions,
  installExtension,
  isExtensionInstalled,
  isExtensionEnabled,
  setExtensionEnabled,
  uninstallExtension,
} from './pluginInstallStore';
import { isBuiltinExtension } from './marketplace/catalog';
import { ensureBuiltinExtensions } from './pluginInstallStore';
import type {
  FlexPluginDefinition,
  InstalledExtension,
  MarketplaceListing,
  PluginCatalogEntry,
} from './types';

function ensureStore() {
  ensureBuiltinExtensions();
}

export function getEnabledExtensionPlugins(): FlexPluginDefinition[] {
  ensureStore();
  return getInstalledExtensions()
    .filter((e) => e.enabled)
    .map((e) => EXTENSION_BUNDLES[e.id])
    .filter((p): p is FlexPluginDefinition => !!p);
}

/** Active plugins = installed + enabled only (VS Code model) */
export function listActivePlugins(): FlexPluginDefinition[] {
  return getEnabledExtensionPlugins();
}

export function isPluginEnabled(pluginId: string): boolean {
  ensureStore();
  const row = getInstalledExtensions().find((e) => e.id === pluginId);
  return row?.enabled ?? false;
}

export function getActivePlugin(id: string): FlexPluginDefinition | undefined {
  return listActivePlugins().find((p) => p.manifest.id === id);
}

export function getPluginCatalog(): PluginCatalogEntry[] {
  return listActivePlugins().map((p) => ({
    ...p.manifest,
    kind: p.manifest.kind ?? 'core',
    datasetCount: p.manifest.datasets.length,
  }));
}

export function getCorePluginCatalog(): PluginCatalogEntry[] {
  return getEnabledExtensionPlugins()
    .filter((p) => p.manifest.kind !== 'extension' && !p.manifest.id.startsWith('flex.ext.'))
    .map((p) => ({
      ...p.manifest,
      kind: 'core' as const,
      datasetCount: p.manifest.datasets.length,
    }));
}

export function listMarketplace(): MarketplaceListing[] {
  return MARKETPLACE_CATALOG;
}

export function listInstalledExtensions(): InstalledExtension[] {
  return getInstalledExtensions();
}

export function installFromMarketplace(id: string): InstalledExtension | { error: string } {
  const listing = MARKETPLACE_CATALOG.find((l) => l.id === id);
  if (!listing) return { error: 'Extension not found in marketplace' };
  if (!EXTENSION_BUNDLES[id]) return { error: 'Extension bundle missing' };
  return installExtension(id, listing.version, { source: 'marketplace' });
}

export { parseExtensionPackage, installFromPackage, installFromPackageUrl } from './marketplace/packageInstaller';

export function uninstallFromMarketplace(id: string): { ok: boolean; error?: string } {
  if (isBuiltinExtension(id)) {
    return { ok: false, error: 'Built-in feature packs cannot be uninstalled — use Disable instead' };
  }
  const ok = uninstallExtension(id);
  return ok ? { ok: true } : { ok: false, error: 'Extension not installed' };
}

export function toggleExtension(id: string, enabled: boolean): void {
  if (!isExtensionInstalled(id)) return;
  setExtensionEnabled(id, enabled);
}

export function extensionInstallState(id: string): 'not_installed' | 'disabled' | 'enabled' {
  if (!isExtensionInstalled(id)) return 'not_installed';
  return isExtensionEnabled(id) ? 'enabled' : 'disabled';
}
