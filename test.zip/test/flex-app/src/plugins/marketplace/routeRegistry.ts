/** Maps app routes → plugin id (VS Code: extension contributes views/commands) */

export const ALWAYS_ON_PATHS = new Set(['/plugins', '/settings', '/partner']);

const PATH_PLUGIN: [string, string][] = [
  ['/', 'flex.dashboard'],
  ['/govern/exchange', 'flex.governance'],
  ['/govern/partners', 'flex.integrations'],
  ['/govern/alignment', 'flex.alignment'],
  ['/cloud', 'flex.cloud-usage'],
  ['/optimization', 'flex.optimization'],
  ['/anomalies', 'flex.anomalies'],
  ['/chargeback', 'flex.chargeback'],
  ['/workforce', 'flex.workforce'],
  ['/resources', 'flex.resources'],
  ['/assistant', 'flex.assistant'],
  ['/settings', 'flex.settings'],
];

export function pluginIdForPath(pathname: string): string | null {
  if (ALWAYS_ON_PATHS.has(pathname)) return null;
  const match = PATH_PLUGIN.find(([path]) => pathname === path || pathname.startsWith(`${path}/`));
  return match?.[1] ?? null;
}

export function isPathAlwaysOn(pathname: string): boolean {
  return ALWAYS_ON_PATHS.has(pathname) || pathname.startsWith('/plugins');
}
