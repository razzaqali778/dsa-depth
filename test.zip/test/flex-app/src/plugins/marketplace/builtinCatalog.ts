import { CORE_PLUGINS } from '../corePlugins';
import type { MarketplaceListing, MarketplaceCategory } from '../types';

const ICONS: Record<string, string> = {
  'flex.dashboard': '📊',
  'flex.governance': '🛡️',
  'flex.integrations': '🔗',
  'flex.alignment': '↔️',
  'flex.cloud-usage': '☁️',
  'flex.optimization': '💰',
  'flex.anomalies': '⚠️',
  'flex.chargeback': '🧾',
  'flex.workforce': '👥',
  'flex.resources': '⚡',
  'flex.assistant': '✨',
  'flex.settings': '⚙️',
  'flex.extension': '🧩',
};

const CATEGORY_MAP: Record<string, MarketplaceCategory> = {
  overview: 'overview',
  governance: 'governance',
  cost: 'cost',
  org: 'organization',
  tools: 'tools',
  extension: 'integrations',
};

/** One marketplace extension per Flex feature — pre-installed like VS Code built-ins */
export const BUILTIN_MARKETPLACE: MarketplaceListing[] = CORE_PLUGINS.map((p) => {
  const m = p.manifest;
  return {
    id: m.id,
    name: m.name,
    version: m.version,
    description: m.description,
    longDescription: `${m.description} Install or disable this feature pack like a VS Code extension.`,
    publisher: 'Flex',
    icon: ICONS[m.id] ?? '📦',
    category: CATEGORY_MAP[m.category] ?? 'tools',
    route: m.route,
    permissions: m.datasets.slice(0, 4).map((d) => d.description),
    installs: 0,
    builtin: true,
  };
});
