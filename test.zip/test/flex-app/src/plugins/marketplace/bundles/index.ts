import type { FlexPluginDefinition } from '../../types';
import { CORE_PLUGINS } from '../../corePlugins';
import { jiraPlugin } from './jira.plugin';
import { pagerdutyPlugin } from './pagerduty.plugin';
import { snowflakePlugin } from './snowflake.plugin';
import { teamsPlugin } from './teams.plugin';

const coreBundles = Object.fromEntries(CORE_PLUGINS.map((p) => [p.manifest.id, p]));

/** Every installable extension bundle (feature packs + partner add-ons) */
export const EXTENSION_BUNDLES: Record<string, FlexPluginDefinition> = {
  ...coreBundles,
  [pagerdutyPlugin.manifest.id]: pagerdutyPlugin,
  [teamsPlugin.manifest.id]: teamsPlugin,
  [snowflakePlugin.manifest.id]: snowflakePlugin,
  [jiraPlugin.manifest.id]: jiraPlugin,
};

export function getExtensionBundle(id: string): FlexPluginDefinition | undefined {
  return EXTENSION_BUNDLES[id];
}

export { jiraPlugin, pagerdutyPlugin, snowflakePlugin, teamsPlugin };
