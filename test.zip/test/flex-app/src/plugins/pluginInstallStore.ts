import { MARKETPLACE_CATALOG } from './marketplace/catalog';
import type { InstalledExtension } from './types';

const STORAGE_KEY = 'flex_installed_extensions_v1';
const SEEDED_KEY = 'flex_extensions_seeded_v2';

const CHANGE_EVENT = 'flex-extensions-changed';

function readAll(): InstalledExtension[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as InstalledExtension[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeAll(list: InstalledExtension[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  window.dispatchEvent(new CustomEvent(CHANGE_EVENT));
}

export function getInstalledExtensions(): InstalledExtension[] {
  return readAll();
}

export function isExtensionInstalled(id: string): boolean {
  return readAll().some((e) => e.id === id);
}

export function isExtensionEnabled(id: string): boolean {
  const row = readAll().find((e) => e.id === id);
  return row?.enabled ?? false;
}

export function installExtension(
  id: string,
  version: string,
  meta?: Pick<InstalledExtension, 'source' | 'packagePath'>
): InstalledExtension {
  const list = readAll().filter((e) => e.id !== id);
  const entry: InstalledExtension = {
    id,
    version,
    installedAt: new Date().toISOString(),
    enabled: true,
    source: meta?.source ?? 'marketplace',
    packagePath: meta?.packagePath,
  };
  writeAll([...list, entry]);
  return entry;
}

export function uninstallExtension(id: string): boolean {
  const listing = MARKETPLACE_CATALOG.find((l) => l.id === id);
  if (listing?.builtin) return false;
  writeAll(readAll().filter((e) => e.id !== id));
  return true;
}

/** Pre-install all built-in feature packs (like VS Code built-in extensions) */
export function ensureBuiltinExtensions(): void {
  const builtins = MARKETPLACE_CATALOG.filter((l) => l.builtin);
  const current = readAll();
  const byId = new Map(current.map((e) => [e.id, e]));
  let changed = false;

  for (const b of builtins) {
    if (!byId.has(b.id)) {
      byId.set(b.id, {
        id: b.id,
        version: b.version,
        installedAt: new Date().toISOString(),
        enabled: true,
        source: 'marketplace',
      });
      changed = true;
    }
  }

  if (changed || !localStorage.getItem(SEEDED_KEY)) {
    writeAll([...byId.values()]);
    localStorage.setItem(SEEDED_KEY, '1');
  }
}

export function setExtensionEnabled(id: string, enabled: boolean): void {
  writeAll(
    readAll().map((e) => (e.id === id ? { ...e, enabled } : e))
  );
}

export function subscribeExtensionChanges(cb: () => void): () => void {
  const handler = () => cb();
  window.addEventListener(CHANGE_EVENT, handler);
  return () => window.removeEventListener(CHANGE_EVENT, handler);
}
