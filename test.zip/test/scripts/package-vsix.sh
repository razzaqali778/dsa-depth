#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/flex-vscode"

if [ -f "$HOME/.nvm/nvm.sh" ]; then
  # shellcheck source=/dev/null
  . "$HOME/.nvm/nvm.sh"
  nvm use 20 >/dev/null 2>&1 || nvm use 22 >/dev/null 2>&1 || true
fi

if ! node -e "const v=process.versions.node.split('.').map(Number); process.exit(v[0]>=20?0:1)"; then
  echo "Node 20+ required to package VSIX. Install: nvm install 20"
  exit 1
fi

npm run compile
npx --yes @vscode/vsce@2.26.1 package --no-dependencies
echo ""
echo "VSIX: $ROOT/flex-vscode/flex-finops-0.1.0.vsix"
