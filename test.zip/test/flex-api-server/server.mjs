import cors from 'cors';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { catalog, consume, produce } from './pluginApi.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.FLEX_API_PORT ?? 3847);
const STATE_FILE = process.env.FLEX_STATE_FILE ?? path.join(__dirname, 'runtime-state.json');
const SEED_FILE = path.join(__dirname, 'seed-state.json');

let state = loadState();

function loadState() {
  try {
    if (fs.existsSync(STATE_FILE)) {
      return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    }
  } catch {
    /* ignore */
  }
  try {
    return JSON.parse(fs.readFileSync(SEED_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function saveState() {
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}

const app = express();
app.use(cors());
app.use(express.json({ limit: '4mb' }));

app.get('/health', (_req, res) => {
  res.json({ ok: true, service: 'flex-api', port: PORT });
});

app.get('/api/v1/state', (_req, res) => {
  res.json(state);
});

app.post('/api/v1/sync', (req, res) => {
  if (!req.body || typeof req.body !== 'object') {
    res.status(400).json({ ok: false, error: 'Expected Flex state JSON' });
    return;
  }
  state = req.body;
  saveState();
  res.json({ ok: true, message: 'State synced from Flex app' });
});

app.get('/api/v1/catalog', (_req, res) => {
  res.json(catalog());
});

app.post('/api/v1/consume', (req, res) => {
  const result = consume(state, req.body ?? {});
  if (result.ok === false) {
    res.status(400).json(result);
    return;
  }
  res.json(result);
});

app.post('/api/v1/produce', (req, res) => {
  const result = produce(state, req.body ?? {});
  saveState();
  res.json(result);
});

app.listen(PORT, () => {
  console.log(`Flex API listening on http://localhost:${PORT}`);
  console.log(`  Health:  GET  /health`);
  console.log(`  Plugins: POST /api/v1/consume | /api/v1/produce`);
  console.log(`  Sync:    POST /api/v1/sync (from Flex web app)`);
});
