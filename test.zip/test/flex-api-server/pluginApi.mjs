/** Plugin consume/produce against shared FlexState JSON (demo). */

const CATALOG = [
  { id: 'flex.dashboard', name: 'Dashboard', datasets: ['kpi_snapshot', 'usage_trend'] },
  { id: 'flex.governance', name: 'Governance', datasets: ['data_requests', 'published_datasets', 'inbound_request'] },
  { id: 'flex.integrations', name: 'Integrations', datasets: ['simulate_inbound_sync', 'pull_outbound', 'partner_consumption'] },
  { id: 'flex.chargeback', name: 'Chargeback', datasets: ['team_showback'] },
  { id: 'flex.anomalies', name: 'Anomalies', datasets: ['anomaly_events'] },
  { id: 'flex.cloud-usage', name: 'Cloud usage', datasets: ['usage_history'] },
];

export function catalog() {
  return CATALOG.map((p) => ({ ...p, datasetCount: p.datasets.length }));
}

function meta(dataset, records) {
  return {
    exportedAt: new Date().toISOString(),
    recordCount: records.length,
    schema: records[0] ? Object.keys(records[0]) : [],
  };
}

export function consume(state, { pluginId, dataset, params }) {
  const s = state;
  switch (pluginId) {
    case 'flex.dashboard':
      if (dataset === 'kpi_snapshot' || !dataset) {
        const records = [
          {
            ...s.kpis,
            pendingApprovals: (s.dataRequests ?? []).filter((r) => r.status === 'pending').length,
          },
        ];
        return { ok: true, pluginId, dataset: 'kpi_snapshot', records, meta: meta('kpi_snapshot', records) };
      }
      break;
    case 'flex.governance':
      if (dataset === 'data_requests' || !dataset) {
        const records = s.dataRequests ?? [];
        return { ok: true, pluginId, dataset: 'data_requests', records, meta: meta('data_requests', records) };
      }
      if (dataset === 'published_datasets') {
        const records = s.publishedDatasets ?? [];
        return { ok: true, pluginId, dataset, records, meta: meta('published_datasets', records) };
      }
      break;
    case 'flex.chargeback':
      if (dataset === 'team_showback' || !dataset) {
        const records = s.chargeback ?? [];
        return { ok: true, pluginId, dataset: 'team_showback', records, meta: meta('team_showback', records) };
      }
      break;
    case 'flex.anomalies':
      if (dataset === 'anomaly_events' || !dataset) {
        const records = s.anomalies ?? [];
        return { ok: true, pluginId, dataset: 'anomaly_events', records, meta: meta('anomaly_events', records) };
      }
      break;
    case 'flex.integrations':
      if (dataset === 'partner_consumption') {
        const partner = params?.partner;
        if (!partner) return { ok: false, error: 'params.partner required (eztrac | dhub-rpt)' };
        const records = (s.publishedDatasets ?? [])
          .filter((d) => d.status === 'published' && d.consumers?.includes(partner))
          .map((d) => ({ name: d.name, recordCount: d.recordCount, lastPublished: d.lastPublished }));
        return { ok: true, pluginId, dataset, records, meta: meta(dataset, records) };
      }
      break;
    default:
      break;
  }
  return { ok: false, error: `Unknown consume: ${pluginId}/${dataset}` };
}

export function produce(state, req) {
  const { pluginId, dataset, records, sourceApp } = req;

  if (pluginId === 'flex.governance' && dataset === 'inbound_request') {
    const row = records[0];
    const created = {
      id: `dr-${Date.now()}`,
      fromApp: row.fromApp,
      dataset: row.dataset,
      requestedAt: new Date().toISOString(),
      status: 'pending',
      recordCount: row.recordCount,
      purpose: row.purpose,
    };
    state.dataRequests = [created, ...(state.dataRequests ?? [])];
    state.kpis = {
      ...state.kpis,
      pendingApprovals: (state.kpis?.pendingApprovals ?? 0) + 1,
    };
    return {
      ok: true,
      pluginId,
      dataset,
      message: `Inbound request ${created.id} created (pending approval)`,
      affectedIds: [created.id],
    };
  }

  if (pluginId === 'flex.integrations' && dataset === 'simulate_inbound_sync') {
    const partner = records[0]?.partner ?? sourceApp;
    if (partner !== 'eztrac' && partner !== 'dhub-rpt') {
      return { ok: false, error: 'partner must be eztrac or dhub-rpt' };
    }
    const datasetName = partner === 'eztrac' ? 'forecast_variance' : 'capacity_forecast';
    const created = {
      id: `dr-${Date.now()}`,
      fromApp: partner,
      dataset: datasetName,
      requestedAt: new Date().toISOString(),
      status: 'pending',
      recordCount: Math.floor(Math.random() * 500) + 100,
      purpose: partner === 'eztrac' ? 'Sync from EzTrac (VS Code / API)' : 'Sync from dhub-rpt (VS Code / API)',
    };
    state.dataRequests = [created, ...(state.dataRequests ?? [])];
    state.kpis = {
      ...state.kpis,
      pendingApprovals: (state.kpis?.pendingApprovals ?? 0) + 1,
    };
    return {
      ok: true,
      pluginId,
      dataset,
      message: `Inbound sync from ${partner}: ${created.dataset}`,
      affectedIds: [created.id],
    };
  }

  return {
    ok: true,
    pluginId,
    dataset,
    message: `Recorded ${records?.length ?? 0} record(s) for ${dataset}`,
  };
}
