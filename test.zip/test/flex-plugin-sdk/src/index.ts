export const FLEX_PLUGIN_CHANNEL = 'flex-plugin-api';
export const PLUGIN_API_VERSION = '1.0.0';

export interface PluginConsumeRequest {
  pluginId: string;
  dataset?: string;
  params?: Record<string, unknown>;
}

export interface PluginProduceRequest {
  pluginId: string;
  dataset: string;
  records: unknown[];
  sourceApp?: 'eztrac' | 'dhub-rpt';
  metadata?: Record<string, unknown>;
}

export interface FlexPluginClientOptions {
  /** Target window when using postMessage (e.g. Flex side panel). */
  target?: Window;
  /** Use BroadcastChannel to reach Flex in another tab (same origin). Default true when no target. */
  useBroadcast?: boolean;
  /** REST API (VS Code, Node) — default http://localhost:3847 */
  apiUrl?: string;
  timeoutMs?: number;
}

interface BridgeMessage {
  channel: typeof FLEX_PLUGIN_CHANNEL;
  id: string;
  method: 'catalog' | 'consume' | 'produce';
  payload?: PluginConsumeRequest | PluginProduceRequest;
}

interface BridgeResponse {
  channel: typeof FLEX_PLUGIN_CHANNEL;
  id: string;
  ok: boolean;
  result?: unknown;
  error?: string;
}

type FlexPluginsApi = {
  catalog: () => unknown;
  consume: (r: PluginConsumeRequest) => unknown;
  produce: (r: PluginProduceRequest) => unknown;
};

function broadcastRequest<T>(
  method: BridgeMessage['method'],
  payload: PluginConsumeRequest | PluginProduceRequest | undefined,
  timeoutMs: number
): Promise<T> {
  return new Promise((resolve, reject) => {
    const bc = new BroadcastChannel(FLEX_PLUGIN_CHANNEL);
    const id = `fpsdk-bc-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const onMsg = (ev: MessageEvent) => {
      const data = ev.data as BridgeResponse | undefined;
      if (!data || data.channel !== FLEX_PLUGIN_CHANNEL || data.id !== id) return;
      bc.removeEventListener('message', onMsg);
      bc.close();
      if (data.ok) resolve(data.result as T);
      else reject(new Error(data.error ?? 'Flex plugin request failed'));
    };
    bc.addEventListener('message', onMsg);
    bc.postMessage({ channel: FLEX_PLUGIN_CHANNEL, id, method, payload } satisfies BridgeMessage);
    setTimeout(() => {
      bc.removeEventListener('message', onMsg);
      bc.close();
      reject(new Error('flex-plugin-sdk: Flex not reachable via BroadcastChannel — is Flex tab open?'));
    }, timeoutMs);
  });
}

async function restRequest<T>(
  method: BridgeMessage['method'],
  payload: PluginConsumeRequest | PluginProduceRequest | undefined,
  apiUrl: string
): Promise<T> {
  const path =
    method === 'catalog' ? '/api/v1/catalog' : method === 'consume' ? '/api/v1/consume' : '/api/v1/produce';
  const res = await fetch(`${apiUrl}${path}`, {
    method: method === 'catalog' ? 'GET' : 'POST',
    headers: method === 'catalog' ? undefined : { 'Content-Type': 'application/json' },
    body: method === 'catalog' ? undefined : JSON.stringify(payload),
  });
  const json = (await res.json()) as T & { error?: string };
  if (!res.ok) throw new Error(json.error ?? `Flex API ${res.status}`);
  return json;
}

function request<T>(
  method: BridgeMessage['method'],
  payload: PluginConsumeRequest | PluginProduceRequest | undefined,
  options: FlexPluginClientOptions
): Promise<T> {
  const apiUrl = options.apiUrl ?? (typeof process !== 'undefined' ? process.env.FLEX_API_URL : undefined);
  if (apiUrl) {
    return restRequest<T>(method, payload, apiUrl);
  }

  const caller =
    typeof window !== 'undefined' ? window : undefined;
  if (!caller) {
    return Promise.reject(
      new Error('flex-plugin-sdk: use apiUrl for Node/VS Code or open in browser with Flex tab')
    );
  }

  const target = options.target;
  const localApi = (caller as Window & { FlexPlugins?: FlexPluginsApi }).FlexPlugins;

  /** Same tab/window as Flex — call API directly */
  if (!target && localApi) {
    if (method === 'catalog') return Promise.resolve(localApi.catalog() as T);
    if (method === 'consume' && payload) {
      return Promise.resolve(localApi.consume(payload as PluginConsumeRequest) as T);
    }
    if (method === 'produce' && payload) {
      return Promise.resolve(localApi.produce(payload as PluginProduceRequest) as T);
    }
  }

  /** Another tab — BroadcastChannel (same origin, Flex tab open) */
  const useBroadcast = options.useBroadcast !== false;
  if (!target && useBroadcast && typeof BroadcastChannel !== 'undefined') {
    return broadcastRequest<T>(method, payload, options.timeoutMs ?? 10000);
  }

  if (!target) {
    return Promise.reject(
      new Error(
        'flex-plugin-sdk: Open Flex in another tab (same browser) or pass options.target = flexWindow.'
      )
    );
  }

  /** Same-origin: optional direct call on target without postMessage */
  try {
    const targetApi = (target as Window & { FlexPlugins?: FlexPluginsApi }).FlexPlugins;
    if (targetApi) {
      if (method === 'catalog') return Promise.resolve(targetApi.catalog() as T);
      if (method === 'consume' && payload) {
        return Promise.resolve(targetApi.consume(payload as PluginConsumeRequest) as T);
      }
      if (method === 'produce' && payload) {
        return Promise.resolve(targetApi.produce(payload as PluginProduceRequest) as T);
      }
    }
  } catch {
    /* cross-origin — fall through to postMessage */
  }

  return new Promise((resolve, reject) => {
    const id = `fpsdk-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const timeout = options.timeoutMs ?? 10000;

    const handler = (event: MessageEvent) => {
      const data = event.data as BridgeResponse | undefined;
      if (!data || data.channel !== FLEX_PLUGIN_CHANNEL || data.id !== id) return;
      caller.removeEventListener('message', handler);
      if (data.ok) resolve(data.result as T);
      else reject(new Error(data.error ?? 'Flex plugin request failed'));
    };

    caller.addEventListener('message', handler);
    target.postMessage(
      { channel: FLEX_PLUGIN_CHANNEL, id, method, payload } satisfies BridgeMessage,
      '*'
    );

    setTimeout(() => {
      caller.removeEventListener('message', handler);
      reject(
        new Error(
          'flex-plugin-sdk: bridge timeout — is Flex open, same browser profile, and extensions enabled?'
        )
      );
    }, timeout);
  });
}

/** Client for Flex plugin API — use in partner apps, scripts, or extension pages */
export class FlexPluginClient {
  constructor(private options: FlexPluginClientOptions = {}) {}

  catalog() {
    return request<unknown[]>('catalog', undefined, this.options);
  }

  consume(req: PluginConsumeRequest) {
    return request<unknown>('consume', req, this.options);
  }

  produce(req: PluginProduceRequest) {
    return request<unknown>('produce', req, this.options);
  }
}

export function createFlexPluginClient(options?: FlexPluginClientOptions) {
  return new FlexPluginClient(options);
}

/** Known plugin IDs */
export const FlexPluginIds = {
  dashboard: 'flex.dashboard',
  governance: 'flex.governance',
  settings: 'flex.settings',
  cloudUsage: 'flex.cloud-usage',
  optimization: 'flex.optimization',
  anomalies: 'flex.anomalies',
  chargeback: 'flex.chargeback',
  workforce: 'flex.workforce',
  resources: 'flex.resources',
  alignment: 'flex.alignment',
  integrations: 'flex.integrations',
  assistant: 'flex.assistant',
  extension: 'flex.extension',
  /** Installed from Extensions marketplace */
  pagerduty: 'flex.ext.pagerduty',
  teams: 'flex.ext.teams',
  snowflake: 'flex.ext.snowflake',
  jira: 'flex.ext.jira',
} as const;
