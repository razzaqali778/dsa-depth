# flex-plugin-sdk

TypeScript client for the **Flex Plugin API** — consume FinOps data or send governed updates from partner apps (EzTrac, dhub-rpt) or your own integrations.

## Install

```bash
npm install flex-plugin-sdk
```

For local development in this monorepo:

```bash
npm install ./flex-plugin-sdk
```

## Usage (browser, Flex app open)

```typescript
import { createFlexPluginClient, FlexPluginIds } from 'flex-plugin-sdk';

const client = createFlexPluginClient();

// List plugins
const catalog = await client.catalog();

// Read KPIs
const kpis = await client.consume({
  pluginId: FlexPluginIds.dashboard,
  dataset: 'kpi_snapshot',
});

// Simulate EzTrac inbound request
await client.produce({
  pluginId: FlexPluginIds.integrations,
  dataset: 'simulate_inbound_sync',
  records: [{ partner: 'eztrac' }],
});
```

When Flex is embedded in the Chrome extension side panel, pass the panel `contentWindow` as `target` if calling from an external page.

## Direct API (same origin)

If your script runs inside the Flex app:

```javascript
const data = await window.FlexPlugins.consume({
  pluginId: 'flex.governance',
  dataset: 'data_requests',
});
```

## Plugin catalog

| Plugin ID | Area |
|-----------|------|
| `flex.dashboard` | Dashboard KPIs |
| `flex.governance` | Approvals & publish |
| `flex.settings` | RBAC & preferences |
| `flex.cloud-usage` | Usage & forecast |
| `flex.optimization` | Savings lifecycle |
| `flex.anomalies` | Cost incidents |
| `flex.chargeback` | Team showback |
| `flex.workforce` | Squad × infra |
| `flex.resources` | Allocations |
| `flex.alignment` | Cross-app drift |
| `flex.integrations` | Partner sync |
| `flex.assistant` | AI context |
| `flex.extension` | Extension snapshot |

See [docs/PLUGINS.md](../docs/PLUGINS.md) for dataset schemas and produce payloads.
