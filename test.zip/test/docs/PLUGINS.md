# Flex Plugin API

Flex has two plugin types:

| Type | Install? | Examples |
|------|----------|----------|
| **Core** | Built into Flex (always on) | Dashboard, Governance, Chargeback |
| **Extension** | Install from **Tools → Extensions → Marketplace** | PagerDuty, Teams, Snowflake, Jira |

Partner apps (EzTrac, dhub-rpt) use the same consume/produce API via `flex-plugin-sdk` — they do not install into Flex like extensions.

## Architecture

```mermaid
flowchart LR
  subgraph Consumers
    EZ[EzTrac]
    DH[dhub-rpt]
    EXT[Extension / scripts]
  end

  subgraph Flex
    MKT[Marketplace]
    INST[Installed extensions]
    HOST[FlexPluginHost]
    CORE[Core plugins]
  end

  MKT -->|Install| INST
  CORE --> HOST
  INST --> HOST
  EZ --> SDK[flex-plugin-sdk]
  DH --> SDK
  EXT --> SDK
  SDK -->|postMessage / window.FlexPlugins| HOST
```

## Install extensions (VS Code–style)

1. Open Flex → **Tools → Extensions**
2. **Marketplace** tab → choose an extension → **Install**
3. **Installed** tab → Enable / Disable / Uninstall
4. Installed extensions register in `window.FlexPlugins.catalog()` and the plugin host

State is stored in `localStorage` key `flex_installed_extensions_v1`.

### Marketplace extensions

| Plugin ID | Purpose |
|-----------|---------|
| `flex.ext.pagerduty` | Page on critical/high anomalies |
| `flex.ext.teams` | Post messages to Teams channels |
| `flex.ext.snowflake` | Export chargeback + usage manifests |
| `flex.ext.jira` | Create Jira tickets from anomalies |

## Core plugin catalog

| Plugin ID | UI route | Consume | Produce |
|-----------|----------|---------|---------|
| `flex.dashboard` | `/` | KPIs, usage trend | KPI snapshot (demo) |
| `flex.governance` | `/govern/exchange` | Requests, datasets, audit | `inbound_request` |
| `flex.settings` | `/settings` | Preferences, roles | `preferences` |
| `flex.cloud-usage` | `/cloud` | Usage history, forecast | — |
| `flex.optimization` | `/optimization` | Savings opportunities | `advance_stage` |
| `flex.anomalies` | `/anomalies` | Events, feed | `resolve_anomaly`, `create_anomaly` |
| `flex.chargeback` | `/chargeback` | Showback, tags | `update_budget` |
| `flex.workforce` | `/workforce` | Squad matrix | `acknowledge_signal` |
| `flex.resources` | `/resources` | Allocation matrix | — |
| `flex.alignment` | `/govern/alignment` | Rows, score | `resolve_conflict` |
| `flex.integrations` | `/govern/partners` | Apps, consumption* | `simulate_inbound_sync`, `pull_outbound` |
| `flex.assistant` | `/assistant` | Knowledge context | `chat_intent` |
| `flex.extension` | Extension | Badge snapshot | `page_context` |

\* `partner_consumption` requires `params: { partner: 'eztrac' | 'dhub-rpt' }`.

## Browser API

When Flex is loaded:

```javascript
// Catalog (core + enabled extensions)
const plugins = window.FlexPlugins.catalog();

// Consume — e.g. Snowflake export after installing extension
const { records } = await window.FlexPlugins.consume({
  pluginId: 'flex.ext.snowflake',
  dataset: 'export_manifest',
});

// Produce — e.g. Jira ticket
await window.FlexPlugins.produce({
  pluginId: 'flex.ext.jira',
  dataset: 'create_ticket',
  records: [{ anomalyId: 'an-1', projectKey: 'FIN' }],
});
```

## npm SDK

```bash
npm install flex-plugin-sdk
```

```typescript
import { createFlexPluginClient, FlexPluginIds } from 'flex-plugin-sdk';

const client = createFlexPluginClient();
await client.consume({ pluginId: FlexPluginIds.chargeback, dataset: 'team_showback' });
```

Extension IDs are only available after install + enable in Flex.

## Adding a new marketplace extension

1. Add `flex-app/src/plugins/marketplace/bundles/your.plugin.ts` with `definePlugin` and `kind: 'extension'`
2. Register in `marketplace/bundles/index.ts`
3. Add listing in `marketplace/catalog.ts`
4. Rebuild Flex

## Source layout

```
flex-app/src/plugins/
  corePlugins.ts           # Built-in areas
  manager.ts               # Core + installed extensions
  registry.ts              # Host lookup
  pluginInstallStore.ts    # localStorage install state
  marketplace/
    catalog.ts             # Marketplace listings
    bundles/*.plugin.ts    # Extension implementations
flex-plugin-sdk/           # External npm client
```

---

*API version 1.0.0 — demo; production would add signed packages, REST, and OAuth.*
