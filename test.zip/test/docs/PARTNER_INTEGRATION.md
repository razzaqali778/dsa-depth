# Partner integration

> **VS Code:** Install the `.vsix` package — see [VSCODE_EXTENSION.md](./VSCODE_EXTENSION.md).  
> **All consume/produce examples:** [CONSUME_PRODUCE_EXAMPLES.md](./CONSUME_PRODUCE_EXAMPLES.md) and `~/test/examples-all.mjs`.

Plugins let partners **get & send data** via the plugin API:

Plugins exist so **other apps** can:

- **consume** — read Flex data (KPIs, chargeback, approvals, …)
- **produce** — send data into Flex (inbound requests, partner sync, …)

## Partner apps (EzTrac & dhub-rpt)

Simulated external applications — **plugins only**, no REST:

| App | URL |
|-----|-----|
| **EzTrac** | http://localhost:5173/apps/eztrac |
| **dhub-rpt** | http://localhost:5173/apps/dhub-rpt |

1. **Tab A:** Flex → `http://localhost:5173/` (keep open)
2. **Tab B:** EzTrac or dhub-rpt app (links above)
3. Use **Consume** / **Produce** — same plugin bridge as production partners

## Quick demo (Partner console)

1. **Tab A:** Open Flex → `http://localhost:5173/` (keep open)
2. **Tab B:** **Partner console** → `http://localhost:5173/partner`
3. Status should show **Connected**
4. Click **Get team chargeback** or **EzTrac sends a data request**
5. In Tab A, open **Governance → Approvals** to see inbound data

No console code. Uses `BroadcastChannel` between tabs (same origin).

## From your own app (npm)

```bash
npm install ./flex-plugin-sdk
```

```typescript
import { createFlexPluginClient, FlexPluginIds } from 'flex-plugin-sdk';

// Flex must be open in another tab (same browser)
const client = createFlexPluginClient({ useBroadcast: true });

// GET from Flex
const kpis = await client.consume({
  pluginId: FlexPluginIds.dashboard,
  dataset: 'kpi_snapshot',
});

// SEND to Flex
await client.produce({
  pluginId: FlexPluginIds.governance,
  dataset: 'inbound_request',
  records: [{
    fromApp: 'eztrac',
    dataset: 'forecast_variance',
    recordCount: 500,
    purpose: 'Q3 refresh',
  }],
  sourceApp: 'eztrac',
});
```

## Plugin IDs (features)

| Action | pluginId | dataset |
|--------|----------|---------|
| KPIs | `flex.dashboard` | `kpi_snapshot` |
| Pending approvals | `flex.governance` | `data_requests` |
| Chargeback | `flex.chargeback` | `team_showback` |
| EzTrac sync | `flex.integrations` | `simulate_inbound_sync` |
| Inbound request | `flex.governance` | `inbound_request` |

See [PLUGINS.md](./PLUGINS.md) for the full catalog.

## Dev-only (not for EzTrac / rpt)

- `flex-api-server` + VS Code `.vsix` — local REST bridge for Node; **not** the partner contract

## Not supported yet

- Cross-origin pages (different domain than Flex) without a signed embed/iframe strategy
