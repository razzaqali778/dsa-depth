export const NodeAppUrl = 'http://localhost:3000';
export const ScalaAppUrl = 'http://127.0.0.1:9090/v1';
export const ADMIN_NP_USER_ID = '';

export enum CalendarsPaths {
  All = '/calendars',
  AllHours = '/calendars/hours',
}

export enum AuditsPaths {
  All = '/audits',
  CalendarsHours = '/calendars/hours',
}

export enum CostGroupsPaths {
  All = '/costGroups',
  Single = '/costGroup',
}

export enum EngagementsPaths {
  All = '/engagements',
  Single = '/engagement',
}

export enum PersonsPaths {
  All = '/people',
  Single = '/person',
}

export enum RatesPaths {
  All = '/rates',
  Single = '/rate',
}

export enum CostCalcPaths {
  All = '/cost-calc/effort',
}
