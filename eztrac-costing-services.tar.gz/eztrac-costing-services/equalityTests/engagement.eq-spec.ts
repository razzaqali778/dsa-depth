import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import {
  ADMIN_NP_USER_ID,
  EngagementsPaths,
  NodeAppUrl,
  ScalaAppUrl,
} from './constants';
import { callOneService, callTwoServices } from './utils';
import { RequestTypes } from './types';
import { CreateEngagementModel } from '../src/engagement/entities/engagement.entity';
import { NameToId } from '../src/utils';

describe('Engagement Equality (e2e)', () => {
  let app: INestApplication;
  const newTestEngagement: CreateEngagementModel = {
    name: 'Equality Test Engagement',
    costGroupId: '',
    purchaseOrder: 'Equality Test Purchase Order',
    modifiedBy: 'Equality Test User',
    isActive: false,
  };

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    if (!ADMIN_NP_USER_ID) console.error('PROVIDE ADMIN_NP_USER_ID');
  });

  it('/ (GET) engagements', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: EngagementsPaths.All,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);
  });

  it('/ (GET) engagements active', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: `${EngagementsPaths.All}?isActive=true`,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);
  });

  it('/ (GET) engagements inactive', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: `${EngagementsPaths.All}?isActive=false`,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);
  });

  it('/ (POST) engagements', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: EngagementsPaths.All,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);

    // // STEP 1 - DELETE EXISTING TEST ENTRY
    await callOneService({
      url: `${NodeAppUrl}${EngagementsPaths.All}/delete/${NameToId(
        newTestEngagement.name,
      )}`,
      method: RequestTypes.delete,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
      },
    });
    newTestEngagement.costGroupId =
      nodeData.data[nodeData.data.length - 1].costGroupId;

    // STEP 2 - SCALA POST - should be ok because entry does not exist
    const scalaPostData = await callOneService({
      url: `${ScalaAppUrl}${EngagementsPaths.All}`,
      method: RequestTypes.post,
      body: newTestEngagement,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 3 - SCALA POST AGAIN - should not be ok because entry does exist
    const scalaPostDataOneMoreTime = await callOneService({
      url: `${ScalaAppUrl}${EngagementsPaths.All}`,
      method: RequestTypes.post,
      body: newTestEngagement,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 4 - SCALA POST WRONG COST GROUP - should not be ok because entry has wrong cost group
    const scalaPostDataWrongCostGroup = await callOneService({
      url: `${ScalaAppUrl}${EngagementsPaths.All}`,
      method: RequestTypes.post,
      body: {
        ...newTestEngagement,
        name: 'Sth new',
        costGroupId: 'Not existing cost group for equality test',
      },
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 5 - delete after scala test
    const deleteData = await callOneService({
      url: `${NodeAppUrl}${EngagementsPaths.All}/delete/${NameToId(
        newTestEngagement.name,
      )}`,
      method: RequestTypes.delete,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
      },
    });
    expect(deleteData.data.name).toEqual(newTestEngagement.name);

    // STEP 6 - NODE POST - should be ok because entry does not exist
    const nodePostData = await callOneService({
      url: `${NodeAppUrl}${EngagementsPaths.All}`,
      method: RequestTypes.post,
      body: newTestEngagement,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 7 - NODE POST AGAIN - should not be ok because entry does exist
    const nodePostDataOneMoreTime = await callOneService({
      url: `${NodeAppUrl}${EngagementsPaths.All}`,
      method: RequestTypes.post,
      body: newTestEngagement,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 8 - NODE POST WRONG COST GROUP - should not be ok because entry has wrong cost group
    const nodePostDataWrongCostGroup = await callOneService({
      url: `${NodeAppUrl}${EngagementsPaths.All}`,
      method: RequestTypes.post,
      body: {
        ...newTestEngagement,
        name: 'Sth new',
        costGroupId: 'Not existing cost group for equality test',
      },
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    expect(scalaPostData.data).toStrictEqual(nodePostData.data);
    expect(scalaPostDataOneMoreTime.error).toBeDefined();
    expect(scalaPostDataWrongCostGroup.error).toBeDefined();
    expect(nodePostDataOneMoreTime.data.statusCode).toEqual(404);
    expect(nodePostDataWrongCostGroup.data.statusCode).toEqual(404);

    const [nodeDataAfter, scalaDataAfter] = await callTwoServices({
      url: EngagementsPaths.All,
      method: RequestTypes.get,
    });

    expect(nodeDataAfter.data).toBeDefined();
    expect(scalaDataAfter.data).toBeDefined();

    expect(scalaDataAfter.data).toStrictEqual(nodeDataAfter.data);

    expect(
      nodeDataAfter.data.find((e) => (e.name = newTestEngagement.name)),
    ).toBeTruthy();
    expect(
      scalaDataAfter.data.find((e) => (e.name = newTestEngagement.name)),
    ).toBeTruthy();
  }, 10000);

  it('/ (PUT) updates cost group', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: EngagementsPaths.All,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);

    const entryBefore = nodeData.data.find(
      (e) => e.name === newTestEngagement.name,
    );

    newTestEngagement.costGroupId =
      nodeData.data[nodeData.data.length - 1].costGroupId;

    const updateData = {
      ...newTestEngagement,
      id: NameToId(newTestEngagement.name),
      isActive: !entryBefore.isActive,
      purchaseOrder: 'Something Different',
    };

    // STEP 1 - SCALA PUT - update test entry isActive and purchaseOrder status
    const scalaPutData = await callOneService({
      url: `${ScalaAppUrl}${EngagementsPaths.Single}/${updateData.id}`,
      method: RequestTypes.put,
      body: updateData,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 2 - check if update correct
    const [nodeDataAfterScalaRequest, scalaDataAfterScalaRequest] =
      await callTwoServices({
        url: EngagementsPaths.All,
        method: RequestTypes.get,
      });

    expect(nodeDataAfterScalaRequest.data).toBeDefined();
    expect(scalaDataAfterScalaRequest.data).toBeDefined();
    expect(scalaDataAfterScalaRequest.data).toStrictEqual(
      nodeDataAfterScalaRequest.data,
    );

    const entryAfterScala = nodeDataAfterScalaRequest.data.find(
      (e) => e.name === newTestEngagement.name,
    );
    expect(entryAfterScala.isActive).toEqual(!entryBefore.isActive);
    expect(entryAfterScala.purchaseOrder).toEqual(updateData.purchaseOrder);

    // STEP 3 - NODE PUT - update test entry isActive and excludeFromDistributions status
    const nodePutData = await callOneService({
      url: `${NodeAppUrl}${EngagementsPaths.Single}/${updateData.id}`,
      method: RequestTypes.put,
      body: {
        ...updateData,
        isActive: !updateData.isActive,
        purchaseOrder: newTestEngagement.purchaseOrder,
      },
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 4 - check if responses from put have the same structure
    expect(nodePutData.data).toEqual({
      ...scalaPutData.data,
      isActive: !scalaPutData.data.isActive,
      purchaseOrder: newTestEngagement.purchaseOrder,
    });

    // STEP 5 - check if node update was correct
    const [nodeDataAfterNodeRequest, scalaDataAfterNodeRequest] =
      await callTwoServices({
        url: EngagementsPaths.All,
        method: RequestTypes.get,
      });

    expect(nodeDataAfterNodeRequest.data).toBeDefined();
    expect(scalaDataAfterNodeRequest.data).toBeDefined();
    expect(scalaDataAfterNodeRequest.data).toStrictEqual(
      nodeDataAfterNodeRequest.data,
    );

    const entryAfterNode = nodeDataAfterNodeRequest.data.find(
      (e) => e.name === newTestEngagement.name,
    );
    expect(entryAfterNode.isActive).toEqual(entryBefore.isActive);
    expect(entryAfterNode.purchaseOrder).toEqual(entryBefore.purchaseOrder);
  }, 10000);
});
