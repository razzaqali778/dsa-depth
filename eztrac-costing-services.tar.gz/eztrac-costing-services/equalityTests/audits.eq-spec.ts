import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import { AuditsPaths } from './constants';
import { callTwoServices } from './utils';
import { RequestTypes } from './types';

describe('Audits Equality (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/ (GET) audits', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: AuditsPaths.All,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toHaveLength(nodeData.data.length);

    const testRandomArray = Array.from({ length: 100 }, () =>
      Math.floor(Math.random() * 100),
    );

    testRandomArray.forEach((i) => {
      const { modifiedTime: scalaModifiedTime, ...restScalaData } =
        scalaData.data[i];
      const { modifiedTime: nodeModifiedTime, ...restNodeData } =
        nodeData.data[i];
      expect(restScalaData).toStrictEqual(restNodeData);
    });

    //data comparison for all records was taking too long, so we are testing only 100 random
  }, 10000);
});
