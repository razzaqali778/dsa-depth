import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import { PersonsPaths, NodeAppUrl, ADMIN_NP_USER_ID } from './constants';
import {
  callOneService,
  callTwoServices,
  getRandomElementFromArray,
} from './utils';
import { RequestTypes } from './types';
import { NameToId } from '../src/utils';
import { CreatePersonModel } from '../src/person/entities/person.entity';

let randomPerson = {
  personId: 'person',
  costGroupId: 'random',
  rateId: 'random',
  rateName: 'rateName',
  costGroupName: 'costGroupName',
};

describe('Person Equality (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  describe('PEOPLE', () => {
    it('/ (GET) gets all people without additional params', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: PersonsPaths.All,
        method: RequestTypes.get,
      });
      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);

      randomPerson = getRandomElementFromArray(nodeData.data);
      randomPerson.costGroupId = NameToId(randomPerson.costGroupName);
      randomPerson.rateId = NameToId(randomPerson.rateName);

      const isActive = nodeData.data.find((d) => d.isActive);
      const isNotActive = nodeData.data.find((d) => !d.isActive);
      expect(isActive).toBeDefined();
      expect(isNotActive).toBeDefined();
    });

    it('/ (GET) gets all without additional params inactive', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.All}?isActive=false`,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);

      nodeData.data.forEach((d) => expect(d.isActive).toEqual(false));
    });

    it('/ (GET) gets all without additional params active', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.All}?isActive=true`,
        method: RequestTypes.get,
      });
      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);
      nodeData.data.forEach((d) => expect(d.isActive).toEqual(true));
    });

    it('/ (GET) gets all people matching query', async () => {
      const query = `an`;
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.All}?q=${query}`,
        method: RequestTypes.get,
      });
      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);
    });

    it('/ (GET) gets all ACTIVE people by cost group when no active status provided', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.All}?costGroupId=${randomPerson.costGroupId}`,
        method: RequestTypes.get,
      });
      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);

      const isActiveNode = nodeData.data.find((d) => d.isActive);
      const isNotActiveNode = nodeData.data.find((d) => !d.isActive);
      expect(isActiveNode).toBeDefined();
      expect(isNotActiveNode).toBeUndefined();

      const isActiveScala = scalaData.data.find((d) => d.isActive);
      const isNotActiveScala = scalaData.data.find((d) => !d.isActive);
      expect(isActiveScala).toBeDefined();
      expect(isNotActiveScala).toBeUndefined();
    });

    it('/ (GET) gets all people by cost group inactive', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.All}?costGroupId=${randomPerson.costGroupId}&isActive=false`,
        method: RequestTypes.get,
      });
      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);
      nodeData.data.forEach((d) => expect(d.isActive).toEqual(false));
    });

    it('/ (GET) gets all people by cost group active', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.All}?costGroupId=${randomPerson.costGroupId}&isActive=true`,
        method: RequestTypes.get,
      });
      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);
      nodeData.data.forEach((d) => expect(d.isActive).toEqual(true));
    });

    it('/ (GET) gets all ACTIVE people by rate when no active status provided', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.All}?rateId=${randomPerson.rateId}`,
        method: RequestTypes.get,
      });
      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);

      const isActiveNode = nodeData.data.find((d) => d.isActive);
      const isNotActiveNode = nodeData.data.find((d) => !d.isActive);
      expect(isActiveNode).toBeDefined();
      expect(isNotActiveNode).toBeUndefined();

      const isActiveScala = scalaData.data.find((d) => d.isActive);
      const isNotActiveScala = scalaData.data.find((d) => !d.isActive);
      expect(isActiveScala).toBeDefined();
      expect(isNotActiveScala).toBeUndefined();
    });

    it('/ (GET) gets all people by rate inactive', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.All}?rateId=${randomPerson.rateId}&isActive=false`,
        method: RequestTypes.get,
      });
      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);
      nodeData.data.forEach((d) => expect(d.isActive).toEqual(false));
    });

    it('/ (GET) gets all people by rate active', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.All}?rateId=${randomPerson.rateId}&isActive=true`,
        method: RequestTypes.get,
      });
      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);
      nodeData.data.forEach((d) => expect(d.isActive).toEqual(true));
    });
  });

  describe('PERSON', () => {
    beforeAll(async () => {
      if (!ADMIN_NP_USER_ID) console.error('PROVIDE ADMIN_NP_USER_ID');

      const all = await callOneService({
        url: `${NodeAppUrl}${PersonsPaths.All}`,
        method: RequestTypes.get,
      });

      randomPerson = getRandomElementFromArray(all.data);
      randomPerson.costGroupId = NameToId(randomPerson.costGroupName);
      randomPerson.rateId = NameToId(randomPerson.rateName);
    });
    it('/ (GET) gets existing user ', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.Single}/${randomPerson.personId}`,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData).toStrictEqual(scalaData);

      expect(nodeData.data.personId).toEqual(randomPerson.personId);
      expect(scalaData.data.personId).toEqual(randomPerson.personId);
    });

    it('/ (GET) gets not existing user ', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.Single}/NOT_EXISTING_PERSON`,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.error).toBeDefined();
      expect(nodeData.data.statusCode).toStrictEqual(404);
    });

    it('/ (PUT) creates user when proper rate and cost group ids provided', async () => {
      const newPerson: CreatePersonModel = {
        personId: NameToId('Equality test person id'),
        personName: 'Equality test person id',
        rateName: randomPerson.rateName,
        costGroupName: randomPerson.costGroupName,
        isActive: false,
        isEmployee: false,
        modifiedBy: 'Equality test modified by',
      };

      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.Single}`,
        method: RequestTypes.put,
        body: newPerson,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData.data).toStrictEqual(scalaData.data);

      const [allNodeData, allScalaData] = await callTwoServices({
        url: PersonsPaths.All,
        method: RequestTypes.get,
      });
      expect(allNodeData.data).toBeDefined();
      expect(allScalaData.data).toBeDefined();
      expect(allNodeData).toStrictEqual(allScalaData);

      const isOurUser = allNodeData.data.find(
        (u) => u.personId === newPerson.personId,
      );
      expect(isOurUser).toStrictEqual(nodeData.data);
    });

    it('/ (PUT) throws error when trying to create user with incorrect cost group id', async () => {
      const newPerson: CreatePersonModel = {
        personId: NameToId('Equality test person id'),
        personName: 'Equality test person id',
        rateName: randomPerson.rateName,
        costGroupName: 'NOT EXISTING COST GROUP',
        isActive: false,
        isEmployee: false,
        modifiedBy: 'Equality test modified by',
      };

      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.Single}`,
        method: RequestTypes.put,
        body: newPerson,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.error).toBeDefined();
      expect(nodeData.data.statusCode).toStrictEqual(404);
    }, 10000);

    it('/ (PUT) throws error when trying to create user with incorrect rate id', async () => {
      const newPerson: CreatePersonModel = {
        personId: NameToId('Equality test person id'),
        personName: 'Equality test person id',
        rateName: 'NOT EXISTING RATE NAME',
        costGroupName: randomPerson.costGroupName,
        isActive: false,
        isEmployee: false,
        modifiedBy: 'Equality test modified by',
      };

      const [nodeData, scalaData] = await callTwoServices({
        url: `${PersonsPaths.Single}`,
        method: RequestTypes.put,
        body: newPerson,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.error).toBeDefined();
      expect(nodeData.data.statusCode).toStrictEqual(404);
    }, 10000);

    it('/ (PATCH) updates user active status when user exists', async () => {
      const [nodeDataBefore, scalaDataBefore] = await callTwoServices({
        url: `${PersonsPaths.Single}/${randomPerson.personId}`,
        method: RequestTypes.get,
      });

      expect(nodeDataBefore.data).toBeDefined();
      expect(scalaDataBefore.data).toBeDefined();
      expect(nodeDataBefore.data).toStrictEqual(scalaDataBefore.data);

      const [updateNodeData, updateScalaData] = await callTwoServices({
        url: `${PersonsPaths.Single}/${randomPerson.personId}`,
        method: RequestTypes.patch,
        body: {
          isActive: !nodeDataBefore.data.isActive,
        },
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: '*/*',
          'Content-Type': 'application/json',
        },
      });

      expect(updateNodeData.data).toBeDefined();
      expect(updateScalaData.data).toBeDefined();

      expect(updateNodeData).toStrictEqual(updateScalaData);
      expect(updateNodeData.data).toEqual(!nodeDataBefore.data.isActive);
      expect(updateScalaData.data).toEqual(!scalaDataBefore.data.isActive);

      const [nodeDataAfter, scalaDataAfter] = await callTwoServices({
        url: `${PersonsPaths.Single}/${randomPerson.personId}`,
        method: RequestTypes.get,
      });

      expect(nodeDataAfter.data).toBeDefined();
      expect(scalaDataAfter.data).toBeDefined();
      expect(nodeDataAfter.data).toStrictEqual(scalaDataAfter.data);

      expect(nodeDataAfter.data.isActive).toStrictEqual(
        !nodeDataBefore.data.isActive,
      );
    }, 10000);

    it('/ (PATCH) does not update user active status when user does not exist', async () => {
      const [updateNodeData, updateScalaData] = await callTwoServices({
        url: `${PersonsPaths.Single}/NOT_EXISTING_USER`,
        method: RequestTypes.patch,
        body: {
          isActive: false,
        },
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      expect(updateNodeData.data).toBeDefined();
      expect(updateNodeData.data.statusCode).toEqual(404);
      expect(updateScalaData.error).toBeDefined();
    });
  });
});
