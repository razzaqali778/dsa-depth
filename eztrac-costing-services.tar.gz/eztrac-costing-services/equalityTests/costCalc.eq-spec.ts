import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import {
  CalendarsPaths,
  CostCalcPaths,
  CostGroupsPaths,
  EngagementsPaths,
  PersonsPaths,
  RatesPaths,
  ScalaAppUrl,
  NodeAppUrl,
} from './constants';
import {
  callOneService,
  callTwoServices,
  getRandomElementFromArray,
} from './utils';
import { RequestTypes } from './types';
import { EffortCostingBodyModel } from 'src/costCalc/entities/costCalc.entity';
import { Person } from 'src/person/entities/person.entity';
import { CalendarHours } from 'src/calendar/entities/calendar.entity';
import { CostGroup } from 'src/costGroup/entities/costGroup.entity';
import { Engagement } from 'src/engagement/entities/engagement.entity';
import { Rate } from 'src/rate/entities/rate.entity';

describe('Cost Calc Equality (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/ (POST) Cost Calc for single data', async () => {
    const [nodePeople, scalaPeople] = await callTwoServices({
      url: PersonsPaths.All,
      method: RequestTypes.get,
    });
    const [nodeCalendars, scalaCalendars] = await callTwoServices({
      url: CalendarsPaths.AllHours,
      method: RequestTypes.get,
    });
    const [nodeCostGroups, scalaCostGroups] = await callTwoServices({
      url: CostGroupsPaths.All,
      method: RequestTypes.get,
    });
    const [nodeEngagements, scalaEngagements] = await callTwoServices({
      url: EngagementsPaths.All,
      method: RequestTypes.get,
    });
    const [nodeRates, scalaRates] = await callTwoServices({
      url: RatesPaths.All,
      method: RequestTypes.get,
    });

    const randomPerson: Person = getRandomElementFromArray(nodePeople.data);
    const randomCalendar: CalendarHours = getRandomElementFromArray(
      nodeCalendars.data,
    );
    const randomCostGroup: CostGroup = getRandomElementFromArray(
      nodeCostGroups.data,
    );
    const randomEngagement: Engagement = getRandomElementFromArray(
      nodeEngagements.data,
    );
    const randomRate: Rate = getRandomElementFromArray(nodeRates.data);

    const requestData: EffortCostingBodyModel = {
      teamId: 'TEST-TEAM123',
      timeFrameId: 42312,
      participants: [
        {
          userId: randomPerson.personId,
          percent: 50,
        },
      ],
      genericParticipants: [
        {
          numberOfPeople: 20,
          rateId: randomRate.id,
          costGroupId: randomCostGroup.id,
        },
      ],
      engagements: [
        {
          engagementId: randomEngagement.id,
          amount: 15,
        },
      ],
    };

    const scalaPostData = await callOneService({
      url: `${ScalaAppUrl}${CostCalcPaths.All}`,
      method: RequestTypes.post,
      body: [requestData],
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
      },
    });

    const nodePostData = await callOneService({
      url: `${NodeAppUrl}${CostCalcPaths.All}`,
      method: RequestTypes.post,
      body: [requestData],
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
      },
    });

    expect(nodePostData.data[0].teamMemberCosts).toEqual(
      expect.arrayContaining(scalaPostData.data[0].teamMemberCosts),
    );

    const [nodePeopleAfter, scalaPeopleAfter] = await callTwoServices({
      url: PersonsPaths.All,
      method: RequestTypes.get,
    });
    const [nodeCalendarsAfter, scalaCalendarsAfter] = await callTwoServices({
      url: CalendarsPaths.AllHours,
      method: RequestTypes.get,
    });
    const [nodeCostGroupsAfter, scalaCostGroupsAfter] = await callTwoServices({
      url: CostGroupsPaths.All,
      method: RequestTypes.get,
    });
    const [nodeEngagementsAfter, scalaEngagementsAfter] = await callTwoServices(
      {
        url: EngagementsPaths.All,
        method: RequestTypes.get,
      },
    );
    const [nodeRatesAfter, scalaRatesAfter] = await callTwoServices({
      url: RatesPaths.All,
      method: RequestTypes.get,
    });

    expect(nodePeopleAfter).toStrictEqual(nodePeople);
    expect(nodeCalendarsAfter).toStrictEqual(nodeCalendars);
    expect(nodeCostGroupsAfter).toStrictEqual(nodeCostGroups);
    expect(nodeEngagementsAfter).toStrictEqual(nodeEngagements);
    expect(nodeRatesAfter).toStrictEqual(nodeRates);

    expect(nodePeopleAfter).toStrictEqual(scalaPeopleAfter);
    expect(nodeCalendarsAfter).toStrictEqual(scalaCalendarsAfter);
    expect(nodeCostGroupsAfter).toStrictEqual(scalaCostGroupsAfter);
    expect(nodeEngagementsAfter).toStrictEqual(scalaEngagementsAfter);
    expect(nodeRatesAfter).toStrictEqual(scalaRatesAfter);
  }, 20000);

  it('/ (POST) Cost Calc for multiple data', async () => {
    const peopleAll = await callOneService({
      url: `${NodeAppUrl}${PersonsPaths.All}`,
      method: RequestTypes.get,
    });
    const costGroupsAll = await callOneService({
      url: `${NodeAppUrl}${CostGroupsPaths.All}`,
      method: RequestTypes.get,
    });
    const engagementsAll = await callOneService({
      url: `${NodeAppUrl}${EngagementsPaths.All}`,
      method: RequestTypes.get,
    });
    const ratesAll = await callOneService({
      url: `${NodeAppUrl}${RatesPaths.All}`,
      method: RequestTypes.get,
    });

    const randomPerson: Person = getRandomElementFromArray(peopleAll.data);
    const randomPerson2: Person = getRandomElementFromArray(peopleAll.data);
    const randomCostGroup: CostGroup = getRandomElementFromArray(
      costGroupsAll.data,
    );
    const randomCostGroup2: CostGroup = getRandomElementFromArray(
      costGroupsAll.data,
    );
    const randomEngagement: Engagement = getRandomElementFromArray(
      engagementsAll.data,
    );
    const randomEngagement2: Engagement = getRandomElementFromArray(
      engagementsAll.data,
    );
    const randomRate: Rate = getRandomElementFromArray(ratesAll.data);
    const randomRate2: Rate = getRandomElementFromArray(ratesAll.data);

    const requestData: EffortCostingBodyModel = {
      teamId: 'TEST-TEAM123',
      timeFrameId: 42312,
      participants: [
        {
          userId: randomPerson.personId,
          percent: 50,
        },
      ],
      genericParticipants: [
        {
          numberOfPeople: 20,
          rateId: randomRate.id,
          costGroupId: randomCostGroup.id,
        },
      ],
      engagements: [
        {
          engagementId: randomEngagement.id,
          amount: 15,
        },
      ],
    };

    const requestData2: EffortCostingBodyModel = {
      teamId: 'TEST-TEAM123',
      timeFrameId: 42308,
      participants: [
        {
          userId: randomPerson2.personId,
          percent: 90,
        },
      ],
      genericParticipants: [
        {
          numberOfPeople: 120,
          rateId: randomRate2.id,
          costGroupId: randomCostGroup2.id,
        },
      ],
      engagements: [
        {
          engagementId: randomEngagement2.id,
          amount: 40,
        },
        {
          engagementId: randomEngagement2.id,
          amount: 17,
        },
        {
          engagementId: randomEngagement.id,
          amount: 99,
        },
      ],
    };

    const scalaPostDataSingle = await callOneService({
      url: `${ScalaAppUrl}${CostCalcPaths.All}`,
      method: RequestTypes.post,
      body: [requestData],
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
      },
    });

    const nodePostDataSingle = await callOneService({
      url: `${NodeAppUrl}${CostCalcPaths.All}`,
      method: RequestTypes.post,
      body: [requestData],
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
      },
    });

    const scalaPostData = await callOneService({
      url: `${ScalaAppUrl}${CostCalcPaths.All}`,
      method: RequestTypes.post,
      body: [requestData, requestData2],
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
      },
    });

    const nodePostData = await callOneService({
      url: `${NodeAppUrl}${CostCalcPaths.All}`,
      method: RequestTypes.post,
      body: [requestData, requestData2],
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
      },
    });

    expect(nodePostData.data[0].teamMemberCosts).toEqual(
      expect.arrayContaining(scalaPostData.data[0].teamMemberCosts),
    );
    expect(nodePostData.data[1].teamMemberCosts).toEqual(
      expect.arrayContaining(scalaPostData.data[1].teamMemberCosts),
    );

    expect(nodePostData.data[0].teamMemberCosts).toEqual(
      expect.arrayContaining(nodePostDataSingle.data[0].teamMemberCosts),
    );
    expect(scalaPostData.data[0].teamMemberCosts).toEqual(
      expect.arrayContaining(scalaPostDataSingle.data[0].teamMemberCosts),
    );
  }, 10000);

  it('/ (POST) Cost Calc for data with errors', async () => {
    const requestData: EffortCostingBodyModel = {
      teamId: 'WRONG_TEAM',
      timeFrameId: 1,
      participants: [
        {
          userId: 'WRONG_PERSON',
          percent: 20,
        },
      ],
      genericParticipants: [
        {
          numberOfPeople: 50,
          rateId: 'WRONG_RATE',
          costGroupId: 'WRONG_COST_GROUP',
        },
      ],
      engagements: [
        {
          engagementId: 'WRONG_ENGAGEMENT',
          amount: 70,
        },
      ],
    };

    const scalaPostData = await callOneService({
      url: `${ScalaAppUrl}${CostCalcPaths.All}`,
      method: RequestTypes.post,
      body: [requestData],
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
      },
    });

    const nodePostData = await callOneService({
      url: `${NodeAppUrl}${CostCalcPaths.All}`,
      method: RequestTypes.post,
      body: [requestData],
      headers: {
        Accept: '*/*',
        'Content-Type': 'application/json',
      },
    });

    expect(nodePostData.data[0].teamMemberCosts).toEqual(
      expect.arrayContaining(scalaPostData.data[0].teamMemberCosts),
    );
  }, 10000);
});
