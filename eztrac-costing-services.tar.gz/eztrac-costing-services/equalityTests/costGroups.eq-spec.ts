import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import {
  ADMIN_NP_USER_ID,
  CostGroupsPaths,
  NodeAppUrl,
  ScalaAppUrl,
} from './constants';
import { callOneService, callTwoServices } from './utils';
import { RequestTypes } from './types';
import { CreateCostGroupModel } from '../src/costGroup/entities/costGroup.entity';
import { NameToId } from '../src/utils';

describe('Cost Groups Equality (e2e)', () => {
  let app: INestApplication;
  const newTestCostGroup: CreateCostGroupModel = {
    name: 'Equality Test Cost Group',
    costCenter: 'Equality Test Cost Center',
    isActive: true,
    modifiedBy: 'Equality Test User',
    excludeFromDistributions: false,
  };

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    if (!ADMIN_NP_USER_ID) console.error('PROVIDE ADMIN_NP_USER_ID');
  });

  it('/ (GET) cost groups', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: CostGroupsPaths.All,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);
  });

  it('/ (GET) cost groups active', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: `${CostGroupsPaths.All}?isActive=true`,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);
  });

  it('/ (GET) cost groups inactive', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: `${CostGroupsPaths.All}?isActive=false`,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);
  });

  it('/ (POST) cost groups', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: CostGroupsPaths.All,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);

    // STEP 1 - DELETE EXISTING TEST ENTRY
    await callOneService({
      url: `${NodeAppUrl}${CostGroupsPaths.All}/delete/${NameToId(
        newTestCostGroup.name,
      )}`,
      method: RequestTypes.delete,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
      },
    });

    // STEP 2 - SCALA POST - should be ok because entry does not exist
    const scalaPostData = await callOneService({
      url: `${ScalaAppUrl}${CostGroupsPaths.All}`,
      method: RequestTypes.post,
      body: newTestCostGroup,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 3 - SCALA POST AGAIN - should not be ok because entry does exist
    const scalaPostDataOneMoreTime = await callOneService({
      url: `${ScalaAppUrl}${CostGroupsPaths.All}`,
      method: RequestTypes.post,
      body: newTestCostGroup,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 4 - delete after scala test
    const deleteData = await callOneService({
      url: `${NodeAppUrl}${CostGroupsPaths.All}/delete/${NameToId(
        newTestCostGroup.name,
      )}`,
      method: RequestTypes.delete,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
      },
    });
    expect(deleteData.data.name).toEqual(newTestCostGroup.name);

    // STEP 5 - NODE POST - should be ok because entry does not exist
    const nodePostData = await callOneService({
      url: `${NodeAppUrl}${CostGroupsPaths.All}`,
      method: RequestTypes.post,
      body: newTestCostGroup,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 6 - NODE POST AGAIN - should not be ok because entry does exist
    const nodePostDataOneMoreTime = await callOneService({
      url: `${NodeAppUrl}${CostGroupsPaths.All}`,
      method: RequestTypes.post,
      body: newTestCostGroup,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    expect(scalaPostData.data).toStrictEqual(nodePostData.data);
    expect(scalaPostDataOneMoreTime.error).toBeDefined();
    expect(nodePostDataOneMoreTime.data.statusCode).toEqual(404);

    const [nodeDataAfter, scalaDataAfter] = await callTwoServices({
      url: CostGroupsPaths.All,
      method: RequestTypes.get,
    });

    expect(nodeDataAfter.data).toBeDefined();
    expect(scalaDataAfter.data).toBeDefined();

    expect(scalaDataAfter.data).toStrictEqual(nodeDataAfter.data);

    expect(
      nodeDataAfter.data.find((e) => (e.name = newTestCostGroup.name)),
    ).toBeTruthy();
    expect(
      scalaDataAfter.data.find((e) => (e.name = newTestCostGroup.name)),
    ).toBeTruthy();
  }, 10000);

  it('/ (PUT) updates cost group', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: CostGroupsPaths.All,
      method: RequestTypes.get,
    });

    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(scalaData.data).toStrictEqual(nodeData.data);

    const entryBefore = nodeData.data.find(
      (e) => e.name === newTestCostGroup.name,
    );

    const updateData = {
      ...newTestCostGroup,
      id: NameToId(newTestCostGroup.name),
      isActive: !entryBefore.isActive,
      excludeFromDistributions: !entryBefore.excludeFromDistributions,
    };

    // STEP 1 - SCALA PUT - update test entry isActive and excludeFromDistributions status
    const scalaPutData = await callOneService({
      url: `${ScalaAppUrl}${CostGroupsPaths.Single}/${updateData.id}`,
      method: RequestTypes.put,
      body: updateData,
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 2 - check if update correct
    const [nodeDataAfterScalaRequest, scalaDataAfterScalaRequest] =
      await callTwoServices({
        url: CostGroupsPaths.All,
        method: RequestTypes.get,
      });

    expect(nodeDataAfterScalaRequest.data).toBeDefined();
    expect(scalaDataAfterScalaRequest.data).toBeDefined();
    expect(scalaDataAfterScalaRequest.data).toStrictEqual(
      nodeDataAfterScalaRequest.data,
    );

    const entryAfterScala = nodeDataAfterScalaRequest.data.find(
      (e) => e.name === newTestCostGroup.name,
    );
    expect(entryAfterScala.isActive).toEqual(!entryBefore.isActive);
    expect(entryAfterScala.excludeFromDistributions).toEqual(
      !entryBefore.excludeFromDistributions,
    );

    // STEP 3 - NODE PUT - update test entry isActive and excludeFromDistributions status
    const nodePutData = await callOneService({
      url: `${NodeAppUrl}${CostGroupsPaths.Single}/${updateData.id}`,
      method: RequestTypes.put,
      body: {
        ...updateData,
        isActive: !updateData.isActive,
        excludeFromDistributions: !updateData.excludeFromDistributions,
      },
      headers: {
        'user-id': ADMIN_NP_USER_ID,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    });

    // STEP 4 - check if responses from put are the same
    expect(nodePutData.data).toEqual({
      ...scalaPutData.data,
      isActive: !scalaPutData.data.isActive,
      excludeFromDistributions: !scalaPutData.data.excludeFromDistributions,
    });

    // STEP 5 - check if node update was correct
    const [nodeDataAfterNodeRequest, scalaDataAfterNodeRequest] =
      await callTwoServices({
        url: CostGroupsPaths.All,
        method: RequestTypes.get,
      });

    expect(nodeDataAfterNodeRequest.data).toBeDefined();
    expect(scalaDataAfterNodeRequest.data).toBeDefined();
    expect(scalaDataAfterNodeRequest.data).toStrictEqual(
      nodeDataAfterNodeRequest.data,
    );

    const entryAfterNode = nodeDataAfterNodeRequest.data.find(
      (e) => e.name === newTestCostGroup.name,
    );
    expect(entryAfterNode.isActive).toEqual(entryBefore.isActive);
    expect(entryAfterNode.excludeFromDistributions).toEqual(
      entryBefore.excludeFromDistributions,
    );
  });
});
