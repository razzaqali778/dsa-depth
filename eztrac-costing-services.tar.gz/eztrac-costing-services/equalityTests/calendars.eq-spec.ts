import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import { CalendarsPaths } from './constants';
import { callTwoServices } from './utils';
import { RequestTypes } from './types';

describe('Calendars Equality (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/ (GET) calendars', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: CalendarsPaths.All,
      method: RequestTypes.get,
    });
    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(nodeData).toStrictEqual(scalaData);
  });

  it('/ (GET) calendars hours', async () => {
    const [nodeData, scalaData] = await callTwoServices({
      url: CalendarsPaths.AllHours,
      method: RequestTypes.get,
    });
    expect(nodeData.data).toBeDefined();
    expect(scalaData.data).toBeDefined();
    expect(nodeData).toStrictEqual(scalaData);
  });
});
