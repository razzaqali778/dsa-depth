import { NodeAppUrl, ScalaAppUrl } from './constants';
import { RequestType } from './types';

export const callOneService = async ({
  url,
  method,
  body,
  headers,
}: RequestType): Promise<{ data?: any; error?: any }> =>
  fetch(url, {
    method,
    ...(headers && { headers }),
    ...(body && { body: JSON.stringify(body) }),
  })
    .then((res) => res.json())
    .then((data) => ({ data }))
    .catch((error) => ({ error }));

export const callTwoServices = async (
  params: RequestType,
): Promise<{ data?: any; error?: any }[]> =>
  await Promise.all([
    callOneService({ ...params, url: `${NodeAppUrl}${params.url}` }),
    callOneService({ ...params, url: `${ScalaAppUrl}${params.url}` }),
  ]);

export const getRandomElementFromArray = (arr: any[]) =>
  arr[Math.floor(Math.random() * arr.length)];
