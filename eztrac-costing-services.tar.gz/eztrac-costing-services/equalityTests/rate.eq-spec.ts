import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import {
  ADMIN_NP_USER_ID,
  NodeAppUrl,
  RatesPaths,
  ScalaAppUrl,
} from './constants';
import { callOneService, callTwoServices } from './utils';
import { RequestTypes } from './types';
import { NameToId } from '../src/utils';
import { CreateRateModel } from 'src/rate/entities/rate.entity';

describe('Rate Equality (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  describe('/ (GET) ', () => {
    let randomRate = {
      id: 'random',
      name: 'random',
    };

    it('all rates properly', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: RatesPaths.All,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(scalaData.data).toHaveLength(nodeData.data.length);
      expect(nodeData.data).toStrictEqual(scalaData.data);

      randomRate =
        nodeData.data[Math.floor(Math.random() * nodeData.data.length)];
    });

    it('all active rates properly', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${RatesPaths.All}?isActive=true`,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(scalaData.data).toHaveLength(nodeData.data.length);
      nodeData.data.forEach((rate) => expect(rate.isActive).toEqual(true));
      expect(nodeData.data).toStrictEqual(scalaData.data);
    });

    it('all inactive rates properly', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${RatesPaths.All}?isActive=false`,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(scalaData.data).toHaveLength(nodeData.data.length);
      nodeData.data.forEach((rate) => expect(rate.isActive).toEqual(false));
      expect(nodeData.data).toStrictEqual(scalaData.data);
    });

    it('rate properly by id', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${RatesPaths.Single}/${randomRate.id}`,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(nodeData.data).toStrictEqual(scalaData.data);
      expect(nodeData.data.id).toStrictEqual(randomRate.id);
    });

    it('rate properly by id when no such a rate', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: `${RatesPaths.Single}/NOT_EXISTING`,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.error).toBeDefined();
      expect(nodeData.data.statusCode).toStrictEqual(404);
    });
  });

  describe('/ (POST) ', () => {
    const newTestRate: CreateRateModel = {
      name: 'Equality Test Rate',
      hourlyRate: 50,
      calendarId: 'Equality Test Calendar',
      isActive: false,
      modifiedBy: 'Equality Test modified by',
    };

    it('adding rate flow working properly', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: RatesPaths.All,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(scalaData.data).toStrictEqual(nodeData.data);

      // // STEP 1 - DELETE EXISTING TEST ENTRY
      await callOneService({
        url: `${NodeAppUrl}${RatesPaths.Single}/delete/${NameToId(
          newTestRate.name,
        )}`,
        method: RequestTypes.delete,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
        },
      });

      // STEP 2 - SCALA POST - should be ok because entry does not exist
      const scalaPostData = await callOneService({
        url: `${ScalaAppUrl}${RatesPaths.All}`,
        method: RequestTypes.post,
        body: newTestRate,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      // STEP 3 - SCALA POST AGAIN - should not be ok because entry does exist
      const scalaPostDataOneMoreTime = await callOneService({
        url: `${ScalaAppUrl}${RatesPaths.All}`,
        method: RequestTypes.post,
        body: newTestRate,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      // STEP 4 - delete after scala test
      const deleteData = await callOneService({
        url: `${NodeAppUrl}${RatesPaths.Single}/delete/${NameToId(
          newTestRate.name,
        )}`,
        method: RequestTypes.delete,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
        },
      });
      expect(deleteData.data.name).toEqual(newTestRate.name);

      // STEP 5 - NODE POST - should be ok because entry does not exist
      const nodePostData = await callOneService({
        url: `${NodeAppUrl}${RatesPaths.All}`,
        method: RequestTypes.post,
        body: newTestRate,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      // STEP 6 - NODE POST AGAIN - should not be ok because entry does exist
      const nodePostDataOneMoreTime = await callOneService({
        url: `${NodeAppUrl}${RatesPaths.All}`,
        method: RequestTypes.post,
        body: newTestRate,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      expect(scalaPostData.data).toStrictEqual(nodePostData.data);
      expect(scalaPostDataOneMoreTime.error).toBeDefined();
      expect(nodePostDataOneMoreTime.data.statusCode).toEqual(404);

      const [nodeDataAfter, scalaDataAfter] = await callTwoServices({
        url: RatesPaths.All,
        method: RequestTypes.get,
      });

      expect(nodeDataAfter.data).toBeDefined();
      expect(scalaDataAfter.data).toBeDefined();

      expect(scalaDataAfter.data).toStrictEqual(nodeDataAfter.data);

      expect(
        nodeDataAfter.data.find((e) => (e.name = newTestRate.name)),
      ).toBeTruthy();
      expect(
        scalaDataAfter.data.find((e) => (e.name = newTestRate.name)),
      ).toBeTruthy();
    }, 10000);
  });

  describe('/ (PUT) ', () => {
    const newTestRate: CreateRateModel = {
      name: 'Equality Test Rate',
      hourlyRate: 50,
      calendarId: 'Equality Test Calendar',
      isActive: false,
      modifiedBy: 'Equality Test modified by',
    };

    it('changing rate flow working propetly', async () => {
      const [nodeData, scalaData] = await callTwoServices({
        url: RatesPaths.All,
        method: RequestTypes.get,
      });

      expect(nodeData.data).toBeDefined();
      expect(scalaData.data).toBeDefined();
      expect(scalaData.data).toStrictEqual(nodeData.data);

      const entryBefore = nodeData.data.find(
        (e) => e.name === newTestRate.name,
      );

      const updateData = {
        ...newTestRate,
        id: NameToId(newTestRate.name),
        isActive: !entryBefore.isActive,
        hourlyRate: 321,
      };

      // STEP 1 - SCALA PUT - update test entry isActive and hourlyRate status
      const scalaPutData = await callOneService({
        url: `${ScalaAppUrl}${RatesPaths.Single}/${updateData.id}`,
        method: RequestTypes.put,
        body: updateData,
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      // STEP 2 - check if update correct
      const [nodeDataAfterScalaRequest, scalaDataAfterScalaRequest] =
        await callTwoServices({
          url: RatesPaths.All,
          method: RequestTypes.get,
        });

      expect(nodeDataAfterScalaRequest.data).toBeDefined();
      expect(scalaDataAfterScalaRequest.data).toBeDefined();
      expect(scalaDataAfterScalaRequest.data).toStrictEqual(
        nodeDataAfterScalaRequest.data,
      );

      const entryAfterScala = nodeDataAfterScalaRequest.data.find(
        (e) => e.name === newTestRate.name,
      );
      expect(entryAfterScala.isActive).toEqual(!entryBefore.isActive);
      expect(entryAfterScala.hourlyRate).toEqual(updateData.hourlyRate);

      // STEP 3 - NODE PUT - update test entry isActive and hourlyRate status
      const nodePutData = await callOneService({
        url: `${NodeAppUrl}${RatesPaths.Single}/${updateData.id}`,
        method: RequestTypes.put,
        body: {
          ...updateData,
          isActive: !updateData.isActive,
          hourlyRate: newTestRate.hourlyRate,
        },
        headers: {
          'user-id': ADMIN_NP_USER_ID,
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      // STEP 4 - check if responses from put have the same structure
      expect(nodePutData.data).toEqual({
        ...scalaPutData.data,
        isActive: !entryAfterScala.isActive,
        hourlyRate: newTestRate.hourlyRate,
      });

      // STEP 5 - check if node update was correct
      const [nodeDataAfterNodeRequest, scalaDataAfterNodeRequest] =
        await callTwoServices({
          url: RatesPaths.All,
          method: RequestTypes.get,
        });

      expect(nodeDataAfterNodeRequest.data).toBeDefined();
      expect(scalaDataAfterNodeRequest.data).toBeDefined();
      expect(scalaDataAfterNodeRequest.data).toStrictEqual(
        nodeDataAfterNodeRequest.data,
      );

      const entryAfterNode = nodeDataAfterNodeRequest.data.find(
        (e) => e.name === newTestRate.name,
      );
      expect(entryAfterNode.isActive).toEqual(entryBefore.isActive);
      expect(entryAfterNode.hourlyRate).toEqual(entryBefore.hourlyRate);
    }, 10000);
  });
});
