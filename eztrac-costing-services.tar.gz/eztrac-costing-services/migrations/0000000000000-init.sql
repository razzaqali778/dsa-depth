--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cost_group_insert_update_trg_f(); Type: FUNCTION; Schema: public; Owner: EzTracAdminUser
--

CREATE FUNCTION public.cost_group_insert_update_trg_f() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
	INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity)
    VALUES ('cost_group', NEW.cost_group_id, current_timestamp, NEW.modified_by,
        json_build_object(
            'id', NEW.cost_group_id,
            'name', NEW.cost_group_name,
            'costCenter', NEW.cost_center,
            'isActive', NEW.is_active
        )
    );
    RETURN NEW;
END;

$$;


ALTER FUNCTION public.cost_group_insert_update_trg_f() OWNER TO "EzTracAdminUser";

--
-- Name: person_insert_update_trg_f(); Type: FUNCTION; Schema: public; Owner: EzTracAdminUser
--

CREATE FUNCTION public.person_insert_update_trg_f() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
	INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity)
    VALUES ('person', NEW.user_id, current_timestamp, NEW.modified_by,
        json_build_object(
            'id', NEW.user_id,
            'name', NEW.user_name,
            'rateId', NEW.rate_id,
            'costGroupId', NEW.cost_group_id,
            'isEmployee', NEW.is_employee,
            'isActive', NEW.is_active
        )
    );
    RETURN NEW;
END;

$$;


ALTER FUNCTION public.person_insert_update_trg_f() OWNER TO "EzTracAdminUser";

--
-- Name: rate_insert_update_trg_f(); Type: FUNCTION; Schema: public; Owner: EzTracAdminUser
--

CREATE FUNCTION public.rate_insert_update_trg_f() RETURNS trigger
    LANGUAGE plpgsql
    AS $$

BEGIN
	INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity)
    VALUES ('rate', NEW.rate_id, current_timestamp, NEW.modified_by,
        json_build_object(
            'id', NEW.rate_id,
            'name', NEW.rate_name,
            'hourlyRate', NEW.hourly_rate,
            'isActive', NEW.is_active,
            'calendar_id', NEW.calendar_id
        )
    );
    RETURN NEW;
END;

$$;


ALTER FUNCTION public.rate_insert_update_trg_f() OWNER TO "EzTracAdminUser";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.audit (
    entity_type text NOT NULL,
    entity_key text NOT NULL,
    modified_time timestamp with time zone NOT NULL,
    user_id text NOT NULL,
    entity jsonb NOT NULL
);


ALTER TABLE public.audit OWNER TO "EzTracAdminUser";

--
-- Name: calendar; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.calendar (
    calendar_id text NOT NULL,
    calendar_name text NOT NULL
);


ALTER TABLE public.calendar OWNER TO "EzTracAdminUser";

--
-- Name: calendar_timeframe_hours; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.calendar_timeframe_hours (
    calendar_id text NOT NULL,
    timeframe_id bigint NOT NULL,
    employee_hours numeric(3,0) NOT NULL,
    contractor_hours numeric(3,0) NOT NULL
);


ALTER TABLE public.calendar_timeframe_hours OWNER TO "EzTracAdminUser";

--
-- Name: cost_group; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.cost_group (
    cost_group_id text NOT NULL,
    cost_group_name text NOT NULL,
    cost_center text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL,
    exclude_from_distributions boolean DEFAULT false NOT NULL
);


ALTER TABLE public.cost_group OWNER TO "EzTracAdminUser";

--
-- Name: engagement; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.engagement (
    engagement_id text NOT NULL,
    engagement_name text NOT NULL,
    cost_group_id text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL,
    engagement_purchase_order text
);


ALTER TABLE public.engagement OWNER TO "EzTracAdminUser";

--
-- Name: person; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.person (
    user_id text NOT NULL,
    user_name text NOT NULL,
    rate_id text NOT NULL,
    cost_group_id text NOT NULL,
    is_employee boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL
);


ALTER TABLE public.person OWNER TO "EzTracAdminUser";

--
-- Name: rate; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.rate (
    rate_id text NOT NULL,
    rate_name text NOT NULL,
    hourly_rate bigint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL,
    calendar_id text DEFAULT 'US-VARIABLE'::text NOT NULL
);


ALTER TABLE public.rate OWNER TO "EzTracAdminUser";

--
-- Name: audit audit_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.audit
    ADD CONSTRAINT audit_pkey PRIMARY KEY (entity_type, entity_key, modified_time);


--
-- Name: calendar calendar_name_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_name_uk UNIQUE (calendar_name);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (calendar_id);


--
-- Name: calendar_timeframe_hours calendar_timeframe_hours_pk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.calendar_timeframe_hours
    ADD CONSTRAINT calendar_timeframe_hours_pk PRIMARY KEY (calendar_id, timeframe_id);


--
-- Name: cost_group cost_group_name_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.cost_group
    ADD CONSTRAINT cost_group_name_uk UNIQUE (cost_group_name);


--
-- Name: cost_group cost_group_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.cost_group
    ADD CONSTRAINT cost_group_pkey PRIMARY KEY (cost_group_id);


--
-- Name: engagement engagement_name_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.engagement
    ADD CONSTRAINT engagement_name_uk UNIQUE (engagement_name);


--
-- Name: engagement engagement_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.engagement
    ADD CONSTRAINT engagement_pkey PRIMARY KEY (engagement_id);


--
-- Name: person person_user_id_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_user_id_pkey PRIMARY KEY (user_id);


--
-- Name: rate rate_name_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_name_uk UNIQUE (rate_name);


--
-- Name: rate rate_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_pkey PRIMARY KEY (rate_id);


--
-- Name: fki_audit_person_user_id_fk; Type: INDEX; Schema: public; Owner: EzTracAdminUser
--

CREATE INDEX fki_audit_person_user_id_fk ON public.audit USING btree (user_id);


--
-- Name: cost_group cost_group_audit_trg; Type: TRIGGER; Schema: public; Owner: EzTracAdminUser
--

CREATE TRIGGER cost_group_audit_trg BEFORE INSERT OR UPDATE ON public.cost_group FOR EACH ROW EXECUTE FUNCTION public.cost_group_insert_update_trg_f();


--
-- Name: person person_audit_trg; Type: TRIGGER; Schema: public; Owner: EzTracAdminUser
--

CREATE TRIGGER person_audit_trg BEFORE INSERT OR UPDATE ON public.person FOR EACH ROW EXECUTE FUNCTION public.person_insert_update_trg_f();


--
-- Name: rate rate_audit_trg; Type: TRIGGER; Schema: public; Owner: EzTracAdminUser
--

CREATE TRIGGER rate_audit_trg BEFORE INSERT OR UPDATE ON public.rate FOR EACH ROW EXECUTE FUNCTION public.rate_insert_update_trg_f();


--
-- Name: calendar_timeframe_hours calendar_timeframe_hours_calendar_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.calendar_timeframe_hours
    ADD CONSTRAINT calendar_timeframe_hours_calendar_id_fk FOREIGN KEY (calendar_id) REFERENCES public.calendar(calendar_id);


--
-- Name: engagement cost_group_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.engagement
    ADD CONSTRAINT cost_group_id_fk FOREIGN KEY (cost_group_id) REFERENCES public.cost_group(cost_group_id);


--
-- Name: person person_cost_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_cost_group_id_fkey FOREIGN KEY (cost_group_id) REFERENCES public.cost_group(cost_group_id);


--
-- Name: person person_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_rate_id_fkey FOREIGN KEY (rate_id) REFERENCES public.rate(rate_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: rdsadmin
--

GRANT ALL ON SCHEMA public TO PUBLIC;
GRANT USAGE ON SCHEMA public TO eztrac_ro;


--
-- Name: FUNCTION cost_group_insert_update_trg_f(); Type: ACL; Schema: public; Owner: EzTracAdminUser
--

REVOKE ALL ON FUNCTION public.cost_group_insert_update_trg_f() FROM PUBLIC;
GRANT ALL ON FUNCTION public.cost_group_insert_update_trg_f() TO "CostingAppUser";


--
-- Name: FUNCTION person_insert_update_trg_f(); Type: ACL; Schema: public; Owner: EzTracAdminUser
--

REVOKE ALL ON FUNCTION public.person_insert_update_trg_f() FROM PUBLIC;
GRANT ALL ON FUNCTION public.person_insert_update_trg_f() TO "CostingAppUser";


--
-- Name: FUNCTION rate_insert_update_trg_f(); Type: ACL; Schema: public; Owner: EzTracAdminUser
--

REVOKE ALL ON FUNCTION public.rate_insert_update_trg_f() FROM PUBLIC;
GRANT ALL ON FUNCTION public.rate_insert_update_trg_f() TO "CostingAppUser";


--
-- Name: TABLE audit; Type: ACL; Schema: public; Owner: EzTracAdminUser
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE public.audit TO "CostingAppUser";
GRANT SELECT ON TABLE public.audit TO eztrac_ro;


--
-- Name: TABLE calendar; Type: ACL; Schema: public; Owner: EzTracAdminUser
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE public.calendar TO "CostingAppUser";
GRANT SELECT ON TABLE public.calendar TO eztrac_ro;


--
-- Name: TABLE calendar_timeframe_hours; Type: ACL; Schema: public; Owner: EzTracAdminUser
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE public.calendar_timeframe_hours TO "CostingAppUser";
GRANT SELECT ON TABLE public.calendar_timeframe_hours TO eztrac_ro;


--
-- Name: TABLE cost_group; Type: ACL; Schema: public; Owner: EzTracAdminUser
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE public.cost_group TO "CostingAppUser";
GRANT SELECT ON TABLE public.cost_group TO eztrac_ro;


--
-- Name: TABLE engagement; Type: ACL; Schema: public; Owner: EzTracAdminUser
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE public.engagement TO "CostingAppUser";
GRANT SELECT ON TABLE public.engagement TO eztrac_ro;


--
-- Name: TABLE person; Type: ACL; Schema: public; Owner: EzTracAdminUser
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE public.person TO "CostingAppUser";
GRANT SELECT ON TABLE public.person TO eztrac_ro;


--
-- Name: TABLE rate; Type: ACL; Schema: public; Owner: EzTracAdminUser
--

GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLE public.rate TO "CostingAppUser";
GRANT SELECT ON TABLE public.rate TO eztrac_ro;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: EzTracAdminUser
--

ALTER DEFAULT PRIVILEGES FOR ROLE "EzTracAdminUser" IN SCHEMA public GRANT SELECT ON TABLES  TO eztrac_ro;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: -; Owner: EzTracAdminUser
--

ALTER DEFAULT PRIVILEGES FOR ROLE "EzTracAdminUser" GRANT ALL ON SEQUENCES  TO "CostingAppUser";


--
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: -; Owner: EzTracAdminUser
--

ALTER DEFAULT PRIVILEGES FOR ROLE "EzTracAdminUser" GRANT ALL ON TYPES  TO "CostingAppUser";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: EzTracAdminUser
--

ALTER DEFAULT PRIVILEGES FOR ROLE "EzTracAdminUser" REVOKE ALL ON FUNCTIONS  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE "EzTracAdminUser" GRANT ALL ON FUNCTIONS  TO "CostingAppUser";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: EzTracAdminUser
--

ALTER DEFAULT PRIVILEGES FOR ROLE "EzTracAdminUser" GRANT SELECT,INSERT,REFERENCES,DELETE,TRIGGER,UPDATE ON TABLES  TO "CostingAppUser";


--
-- PostgreSQL database dump complete
--

