import request from 'supertest';
import { StatusCodes } from 'http-status-codes';
import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../src/app.module';
import { INestApplication } from '@nestjs/common';
import {
  CreateEngagementLessModel,
  CreateEngagementModel,
  Engagement,
} from '../src/engagement/entities/engagement.entity';
import { manageEngagementsUserHeader } from './utils';
import { EngagementsPaths } from './constantsPaths';
import { PROVIDERS } from '../src/constants';

describe('Engagements', () => {
  let app: INestApplication;
  let server;
  let moduleFixture: TestingModule;
  const papiClient = {
    getEntitlementsForUser: (userId: string, appIds: string[]) =>
      new Promise((resolve) =>
        resolve([
          { code: 'EZTRAC-MANAGE-ENGAGEMENTS', application: { id: 'eztrac' } },
        ]),
      ),
  };

  beforeAll(async () => {
    moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.papiClient)
      .useValue(papiClient)
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    server = app.getHttpServer();
  });

  it('create engagement', async () => {
    // Arrange
    const createEngagementModel: CreateEngagementModel = {
      name: 'New engagement',
      costGroupId: 'TEST-GROUP',
      purchaseOrder: '12345',
      isActive: true,
      modifiedBy: 'will-be-replaced',
    };

    // Act
    const response = await request(server)
      .post(EngagementsPaths.All)
      .send(createEngagementModel)
      .set(manageEngagementsUserHeader);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.CREATED);

    const engagements = (await request(server).get(EngagementsPaths.All)).body;
    const createdEngagement = engagements.find(
      (e: Engagement) => e.name === createEngagementModel.name,
    );
    expect(createdEngagement).toBeDefined();
  });

  it('update engagement', async () => {
    // Arrange
    const createEngagementModel: CreateEngagementModel = {
      name: 'update engagement test',
      costGroupId: 'TEST-GROUP',
      purchaseOrder: '12345',
      isActive: true,
      modifiedBy: 'will-be-replaced',
    };

    const createdEngagement: Engagement = (
      await request(server)
        .post(EngagementsPaths.All)
        .send(createEngagementModel)
        .set(manageEngagementsUserHeader)
    ).body;

    const updateEngagementModel: CreateEngagementLessModel = {
      ...createdEngagement,
      name: 'Test engagement updated',
      costGroupId: 'NEW-TEST-GROUP',
      isActive: false,
      purchaseOrder: 'new purchase order',
    };

    // Act
    const response = await request(server)
      .put(`${EngagementsPaths.Single}/${updateEngagementModel.id}`)
      .send(updateEngagementModel)
      .set(manageEngagementsUserHeader);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.OK);

    const engagements: Engagement[] = (
      await request(server).get(EngagementsPaths.All)
    ).body;
    const updatedEngagement = engagements.find(
      (e) => e.id === updateEngagementModel.id,
    );
    expect(updatedEngagement).toEqual(updateEngagementModel);
  });
});
