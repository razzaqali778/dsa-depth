export enum PROVIDERS {
  database = 'DATABASE_CONNECTION',
  config = 'CONFIG',
  entitlements = 'ENTITLEMENTS',
  authRequest = 'AUTH_REQUEST',
  papiClient = 'PAPI_CLIENT',
}
