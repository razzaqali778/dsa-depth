import request from 'supertest';
import { StatusCodes } from 'http-status-codes';
import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../src/app.module';
import { INestApplication } from '@nestjs/common';
import { adminUserHeader } from './utils';
import { PROVIDERS } from '../src/constants';
import {
  CostGroup,
  CreateCostGroupModel,
  UpdateCostGroupModel,
} from 'src/costGroup/entities/costGroup.entity';
import { CostGroupsPaths } from './constantsPaths';

describe('Cost groups', () => {
  let app: INestApplication;
  let server;
  let moduleFixture: TestingModule;
  const papiClient = {
    getEntitlementsForUser: (userId: string, appIds: string[]) =>
      new Promise((resolve) =>
        resolve([{ code: 'EZTRAC-ADMIN-USER', application: { id: 'eztrac' } }]),
      ),
  };

  beforeAll(async () => {
    moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.papiClient)
      .useValue(papiClient)
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    server = app.getHttpServer();
  });

  it('create cost group', async () => {
    // Arrange
    const createCostGroupModel: CreateCostGroupModel = {
      name: 'New cost group',
      costCenter: 'cost center',
      isActive: true,
      modifiedBy: 'will-be-replaced',
      excludeFromDistributions: false,
    };

    // Act
    const response = await request(server)
      .post(CostGroupsPaths.All)
      .send(createCostGroupModel)
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.CREATED);

    const costGroups = (await request(server).get(CostGroupsPaths.All)).body;
    const createdCostGroup = costGroups.find(
      (cg: CostGroup) => cg.name === createCostGroupModel.name,
    );

    expect(createdCostGroup).toBeDefined();
  });

  it('update cost group', async () => {
    // Arrange
    const createCostGroupModel: CreateCostGroupModel = {
      name: 'New cost group to be updated',
      costCenter: 'cost center',
      isActive: true,
      modifiedBy: 'will-be-replaced',
      excludeFromDistributions: false,
    };

    const createdCostGroup: CostGroup = (
      await request(server)
        .post(CostGroupsPaths.All)
        .send(createCostGroupModel)
        .set(adminUserHeader)
    ).body;

    const updateCostGroupModel: UpdateCostGroupModel = {
      ...createdCostGroup,
      name: 'Updated cost group',
      costCenter: 'new cost center',
      isActive: false,
      excludeFromDistributions: true,
    };

    // Act
    const response = await request(server)
      .put(`${CostGroupsPaths.Single}/${updateCostGroupModel.id}`)
      .send(updateCostGroupModel)
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.OK);

    const costGroups: CostGroup[] = (
      await request(server).get(CostGroupsPaths.All)
    ).body;
    const updatedCostGroup = costGroups.find(
      (cg) => cg.id === updateCostGroupModel.id,
    );
    expect(updatedCostGroup).toEqual(updateCostGroupModel);
  });
});
