import { QueryFile } from 'pg-promise';
import { join as joinPath } from 'path';
import { getDb } from './db';

const cleanupAllSqlFilePath = 'sql/teardown.sql';

const cleanupAllQuery = new QueryFile(
  joinPath(__dirname, cleanupAllSqlFilePath),
  { minify: true },
);

const cleanupDatabase = async () => {
  const dbInstance = await getDb();
  await dbInstance.none(cleanupAllQuery);
};

export const databaseCleaner = {
  cleanupDatabase,
};
