import { configProvider } from '../../src/common/config/config.provider';
import pgPromise from 'pg-promise';

let dbInstance: any;

export const getDb = async () => {
  if (!dbInstance) {
    const credentials = await configProvider.useFactory();
    const dbName = credentials.get('costingDb').database;
    if (dbName !== 'CostingDb-IT') {
      throw Error('wrong database!');
    }
    const dbConfig = {
      ...credentials.get('costingDb'),
      allowExitOnIdle: true,
    };
    const pgp = pgPromise();
    dbInstance = pgp(dbConfig);
  }
  return dbInstance;
};
