import pgMigrationRunner from 'node-pg-migrate';
import { RunMigration } from 'node-pg-migrate/dist/migration';
import { MigrationDirection } from 'node-pg-migrate/dist/types';
import { Client } from 'pg';
import { seedData } from './dataSeed';
import { databaseCleaner } from './cleanupDatabase';
import { configProvider } from '../../src/common/config/config.provider';

const runMigrations = async (): Promise<RunMigration[]> => {
  const credentials = await configProvider.useFactory();
  const dbConfig = {
    ...credentials.get('costingDb'),
    allowExitOnIdle: true,
  };
  const client = new Client(dbConfig);
  await client.connect();
  const pgMigrationOptions = {
    dbClient: client,
    dir: 'migrations',
    direction: 'up' as MigrationDirection,
    migrationsTable: 'pgmigrations',
  };
  const migrationResponse = await pgMigrationRunner(pgMigrationOptions);
  console.log(migrationResponse);

  await client.end();
  return migrationResponse;
};

export const setupIntegrationTestDatabase = async () => {
  console.log('setupIntegrationTestDatabase');
  await databaseCleaner.cleanupDatabase();
  await runMigrations();
  await seedData();
};
