--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: rate; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('HIGH-RATE', 'High Rate', 125, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('VISTEX-SOW', 'Vistex SOW', 205, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('COG-DATA-INDIA', 'Cog Data India', 32, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('COG-DATA-ONSHORE', 'Cog Data Onshore', 100, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('WORKFORCE-O365', 'Workforce O365', 50, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('RELEASE-MANAGER', 'Release Manager', 80, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('PRODUCT-DEV-OPS', 'Product Dev Ops', 55, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ADMIN-ASSISTANT', 'Admin Assistant', 40, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('INDIA', 'India', 24, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('STANDARD3-FY2016', 'Standard3 (FY2016)', 98, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('STANDARD2-FY2016', 'Standard2 (FY2016)', 86, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('FUJITSU-AMERICAN-FARMERS', 'Fujitsu American Farmers', 350, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('DATA-OPS-OFFSHORE', 'Data Ops - Offshore', 50, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('DATA-OPS-ONSHORE', 'Data Ops - Onshore', 100, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('NETEFFECTS-SOW', 'NetEffects SOW', 105, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('INDIA-PRE-FY2017', 'India (Pre FY2017)', 20, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('STANDARD-PRE-FY2017', 'Standard (Pre FY2017)', 74, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('PIVOTAL-INFRASTRUCTURE-ARCHITECT', 'Pivotal - Infrastructure Architect', 224, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('PIVOTAL-SPECIALTY-DEVELOPER', 'Pivotal - Specialty Developer', 145, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ASYNCHRONY-DEVELOPER-3', 'Asynchrony - Developer 3', 165, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ASYNCHRONY-DEVELOPER-2', 'Asynchrony - Developer 2', 125, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ASYNCHRONY-DEVELOPER-1', 'Asynchrony - Developer 1', 85, false, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('OPERATIONS-RESEARCH-HIGH', 'Operations Research-High', 200, true, 'automatic', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('DAUGHERTY-SOW', 'Daugherty SOW', 117, true, 'CLLANG', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('MEXICO', 'Mexico', 30, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('BRAZIL-COGNIZANT-SOW', 'Brazil Cognizant SOW', 47, true, 'automatic', 'BRZ-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('L2-SUPPORT-US', 'L2 Support US', 45, true, 'CLLANG', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('L2-SUPPORT-BLR', 'L2 Support BLR', 8, true, 'CLLANG', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('PRODUCT-SPECIALIST', 'Product Specialist', 50, true, 'TLYOUN', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('UNKNOWN', 'Unknown', 100, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('US-CO-OP', 'US Co-Op', 25, true, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ABAP-DEVELOPERS', 'ABAP Developers', 90, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ERNST--YOUNG', 'Ernst & Young', 265, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('INDIA-OFFSHORE-COG', 'India Offshore-Cog', 50, true, 'CLLANG', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('SLALOM-SOW', 'Slalom SOW', 161, true, 'TCPOTTS', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('DATA-DAUGHERTY-SOW', 'Data Daugherty SOW', 106, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ASYNCHRONY-CUSTOMER-360-SOW', 'Asynchrony Customer 360 SOW', 140, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ASYNCHRONY-COMPANY-360-SOW', 'Asynchrony Company 360 SOW', 140, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ASYNCHRONY-PRODUCT-360-SOW', 'Asynchrony Product 360 SOW', 144, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('DATA-VISTEX', 'Data Vistex', 130, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ELD-PROGRAM', 'ELD Program', 50, true, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('SPARKGEO-GEOTRELLIS', 'Sparkgeo Geotrellis', 108, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('SAP-PRODUCT--COSTING', 'SAP Product  Costing', 130, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('VISTEX-SOW-OFFSHORE', 'Vistex SOW Offshore', 65, true, 'CLLANG', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('DATA-TECH-PARTNERS', 'Data Tech Partners', 182, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('FI-HIGH-RATE', 'FI High Rate', 120, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('EY-SOW', 'E&Y SOW', 255, true, 'CLLANG', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('EXTRA-HIGH-RATE', 'Extra High Rate', 150, true, 'VFUPAMA', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('HIGH-RATE-LEPSI', 'High Rate LEPSI', 119, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('BRAZIL', 'Brazil', 72, true, 'CLLANG', 'BRZ-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('BOUNDLESS-SOW', 'Boundless SOW', 167, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('COGNIZANT-STAFF-AUG', 'Cognizant Staff Aug', 115, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('COGNIZANT-FRONTIER-SOW', 'Cognizant Frontier SOW', 40, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('OCI-SOW', 'OCI SOW', 138, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('INDIA-CAPG-SOW', 'India CapG SOW', 38, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('1904-LABS-SOW', '1904 Labs SOW', 135, false, 'JASKIDI', 'STD-FIXED');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ASYNCHRONY-SOW', 'Asynchrony SOW', 155, true, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('SOUTH-AMERICA', 'South America (Argentina)', 34, true, 'CLLANG', 'ARG-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ESOCIAL---BLR', 'eSocial Cog - BLR', 30, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ESOCIAL-COG---BRZ', 'eSocial Cog - BRZ', 61, false, 'JASKIDI', 'BRZ-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('COORDINATE-COG', 'Coordinate Cog', 110, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ECOM-COG---OFFSHORE', 'eCOM Cog - Offshore', 30, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ACCOUNT-PLANNING-COG-OFFSHORE', 'Account Planning Cog offshore', 30, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('PD-PODS-COG-OFFSHORE', 'PD Pods Cog offshore', 35, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ASYNCHRONY-INTEGRATIONSOW', 'Asynchrony IntegrationSOW', 140, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('COG-ACS2-ONSHORE', 'Cog ACS2 Onshore SOW', 110, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('GVEG-SE-SF-MIT-COG-OFFSHORE', 'PD GVEG SE-SF-MIT Cog Offshore', 33, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ESOCIAL-COG---INDIA', 'LAGO Cog - India', 43, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('DATA-COG-HUNGRY-RATE', 'Data Cog Hungary Rate', 65, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('FUJITSU-SOW-ON-SITE', 'Fujitsu SOW On-site', 136, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('FUJITSU-SOW-OFFSHORE', 'Fujitsu SOW offshore', 56, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('COG-FRONTIER-AEM', 'COG Frontier AEM', 130, false, 'JASKIDI', 'STD-FIXED');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('LABVANTAGE-COG-SOW', 'LabVantage Cog SOW', 135, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('LABVANTAGE-PM-COG-SOW', 'LabVantage PM Cog SOW', 108, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('SLALOM-SENIOR-ENGINEER-SOW', 'Slalom Senior Engineer SOW', 200, false, 'JASKIDI', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('DATA-LOW-RATE', 'Data Low Rate', 50, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('ANALYTICS-GEOSPATIAL-COGNIZANT-SOW', 'Analytics Geospatial Cognizant SOW', 140, true, 'CEMARS', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('CAP-GEMINI-ONSHORE', 'Cap Gemini Onshore', 105, true, 'RCNATA', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('CLIMATE-STANDARD', 'Climate Standard', 100, true, 'RCNATA', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('CLIMATE-JUNIOR', 'Climate Junior', 52, true, 'RCNATA', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('3B-PMO-COORDINATORS', '3B PMO coordinators', 68, true, 'GNPGQ', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('CLIMATE-MED', 'Climate Med', 77, true, 'RCNATA', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('FICO-SAP-ANALYST-CAP-GEMINI-SOW', 'FICO SAP Analyst Cap Gemini SOW', 105, true, 'RCNATA', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('NOVACOAST-IAM-HIGH', 'Novacoast IAM High ', 188, true, 'RCNATA', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('NOVACOAST-IAM', 'Novacoast IAM', 153, true, 'RCNATA', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('COG-HIGH-RATE', 'Cog High Rate', 140, true, 'RCSCHU1', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('STANDARD', 'Standard', 120, true, 'CLLANG', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('TEST-TEAM', 'Test team', 0, true, 'GNFSP', 'US-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('EQUALITY-TEST-RATE', 'Equality Test Rate', 50, false, 'goiyo', 'Equality Test Calendar');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('TEST-REATE', 'test rate', 10, true, 'GNPGQ', 'ARG-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('NEW-TEST-RATE', 'new test rate', 12, true, 'GNPGQ', 'BRZ-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('TEST-DEV', 'TEST Dev', 15, false, 'GOIYO', 'STD-FIXED');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('TEST-DEVV', 'TEST DEVv', 20, false, 'GOIYO', 'ARG-VARIABLE');
INSERT INTO public.rate (rate_id, rate_name, hourly_rate, is_active, modified_by, calendar_id) VALUES ('TEST-RATE', 'Test rate', 100, true, 'GNPGQ', 'TEST-CALENDAR')


--
-- PostgreSQL database dump complete
--

