--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('cost_group', 'HISTORIC', '2017-08-17 19:00:59.682103+00', 'MDLIND1', '{"id": "HISTORIC", "name": "Historic-Deprecated-", "isActive": false, "costCenter": "Unknown"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('cost_group', 'HISTORIC', '2017-08-17 19:01:08.348059+00', 'MDLIND1', '{"id": "HISTORIC", "name": "Historic-Deprecated", "isActive": false, "costCenter": "Unknown"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'FELHE', '2017-08-18 18:21:04.159676+00', 'CLLANG', '{"id": "FELHE", "name": "El Hellaoui, Fouad", "rateId": "VISTEX-SOW", "isActive": true, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEVELOPMENT"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'SCHET', '2017-08-18 18:26:27.896947+00', 'CLLANG', '{"id": "SCHET", "name": "Chetireddy, Surender", "rateId": "STANDARD", "isActive": true, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEVELOPMENT"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'MANSA1', '2017-08-18 18:31:46.861331+00', 'CLLANG', '{"id": "MANSA1", "name": "Ansar, Mohamed Riazudeen", "rateId": "INDIA", "isActive": true, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEVELOPMENT"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'SKUMA36', '2017-08-18 18:39:26.882539+00', 'CLLANG', '{"id": "SKUMA36", "name": "Kumaraswamy, Shandrakanth", "rateId": "INDIA", "isActive": true, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEVELOPMENT"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'RKALR', '2017-08-18 18:39:44.287521+00', 'CLLANG', '{"id": "RKALR", "name": "Kalrayan, Ravindharan", "rateId": "INDIA", "isActive": true, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEVELOPMENT"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'NRAEDD', '2017-08-18 18:53:56.105336+00', 'CLLANG', '{"id": "NRAEDD", "name": "Aeddula, Nikhil R", "rateId": "DATA-OPS-ONSHORE", "isActive": false, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEVELOPMENT"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'VNOOK', '2017-08-18 18:54:16.263671+00', 'CLLANG', '{"id": "VNOOK", "name": "Nookala, Venkatesh", "rateId": "RELEASE-MANAGER", "isActive": false, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEVELOPMENT"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'BPAND1', '2017-08-18 18:57:50.438219+00', 'CLLANG', '{"id": "BPAND1", "name": "Panda, Byomakesh", "rateId": "STANDARD", "isActive": false, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEVELOPMENT"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'RNATH1', '2017-08-22 15:59:48.093784+00', 'CLLANG', '{"id": "RNATH1", "name": "Nathanson, Rebecca", "rateId": "1904-LABS-SOW", "isActive": true, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEV-PTP-SOW-EXC"}');
INSERT INTO public.audit (entity_type, entity_key, modified_time, user_id, entity) VALUES ('person', 'SANNE1', '2017-08-22 16:00:20.101799+00', 'CLLANG', '{"id": "SANNE1", "name": "Anne, Saradruthi", "rateId": "STANDARD", "isActive": true, "isEmployee": false, "costGroupId": "PE-PRODUCT-DEVELOPMENT"}');