--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('ELYTB', 'Mannava, Guru', 'STANDARD', 'ITCS-GLB-DATA-ASSETS-CNT', false, false, 'GOIYO');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('GLQRE', 'Sara Lorio', 'STANDARD', 'ITCS-PROD-PLTFM-DESIGN-DCT', true, true, 'GCCYW');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('GNXAH', 'Justyna Blonka', 'STANDARD', 'CLIM-ENG-PLATFORM', true, false, 'GNXAH');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('ANSOUZ', 'Accenture, Adriano', 'BRAZIL', 'PE-BRAZIL-IT-CNT', false, false, 'GNXAH');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('DAAABE', 'Dale Aaberg', '3B-PMO-COORDINATORS', 'CLIM-CSP-IT-CNT', false, false, 'GNFSP');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('ARENO', 'Aaron Reno', 'STANDARD', 'ITCS-PROD-PLTFM-OPERATIONS-DCT', true, false, 'GNFSP');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('ADANI1', 'Daniela, Ale', 'SOUTH-AMERICA', 'PE-SOUTH-AMERICA-IT-CNT', false, false, 'GNFSP');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('EFHVW', 'Pawel Gortowski', 'ABAP-DEVELOPERS', 'CLIM-CSP-IT-CNT', false, true, 'GNFSP');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('AUALC', 'Allana Grotto', '3B-PMO-COORDINATORS', 'CLIM-CSP-IT-CNT', true, true, 'GNFSP');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('TKIRK', 'Kirk, Todd', 'STANDARD', 'ITCS-PROD-PLTFM-FIELD-CNT', false, false, 'GNXAH');
INSERT INTO public.person (user_id, user_name, rate_id, cost_group_id, is_employee, is_active, modified_by) VALUES ('AABBCC', 'Aa, Bb', 'TEST-RATE', 'ITCS-PROD-PLTFM-FIELD-CNT', true, true, 'GNXAH');


--
-- PostgreSQL database dump complete
--

