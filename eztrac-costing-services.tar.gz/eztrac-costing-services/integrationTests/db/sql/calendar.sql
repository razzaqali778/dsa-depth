--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

INSERT INTO public.calendar (calendar_id, calendar_name) VALUES ('US-VARIABLE', 'US Variable');
INSERT INTO public.calendar (calendar_id, calendar_name) VALUES ('ARG-VARIABLE', 'Argentina Variable');
INSERT INTO public.calendar (calendar_id, calendar_name) VALUES ('BRZ-VARIABLE', 'Brazil Variable');
INSERT INTO public.calendar (calendar_id, calendar_name) VALUES ('STD-FIXED', 'Fixed Length');
INSERT INTO public.calendar (calendar_id, calendar_name) VALUES ('GER-VARIABLE', 'Germany Variable');
INSERT INTO public.calendar (calendar_id, calendar_name) VALUES ('TEST-CALENDAR', 'Test calendar');


--
-- PostgreSQL database dump complete
--

