import { IDatabase } from 'pg-promise';
import { QueryFile } from 'pg-promise';
import { join as joinPath } from 'path';
import { getDb } from './db';

const calendarsFilePath = 'sql/calendar.sql';
const calendarTimeframeHoursFilePath = 'sql/calendarTimeframeHours.sql';
const ratesFilePath = 'sql/rate.sql';
const personsFilePath = 'sql/person.sql';
const engagementsFilePath = 'sql/engagement.sql';
const costGroupsFilePath = 'sql/costGroup.sql';
const auditFilePath = 'sql/audit.sql';

export async function seedData() {
  const db: IDatabase<any> = await getDb();
  const calendarsPath = joinPath(__dirname, calendarsFilePath);
  const calendarTimeframeHoursPath = joinPath(
    __dirname,
    calendarTimeframeHoursFilePath,
  );
  const ratesPath = joinPath(__dirname, ratesFilePath);
  const personsPath = joinPath(__dirname, personsFilePath);
  const engagementsPath = joinPath(__dirname, engagementsFilePath);
  const costGroupsPath = joinPath(__dirname, costGroupsFilePath);
  const auditPath = joinPath(__dirname, auditFilePath);

  const calendarsSql = new QueryFile(calendarsPath, { minify: true });
  const calendarTimeframeHoursSql = new QueryFile(calendarTimeframeHoursPath, {
    minify: true,
  });
  const ratesSql = new QueryFile(ratesPath, { minify: true });
  const personsSql = new QueryFile(personsPath, { minify: true });
  const engagementsSql = new QueryFile(engagementsPath, { minify: true });
  const costGroupsSql = new QueryFile(costGroupsPath, { minify: true });
  const auditSql = new QueryFile(auditPath, { minify: true });

  await db.none(calendarsSql);
  await db.none(calendarTimeframeHoursSql);
  await db.none(ratesSql);
  await db.none(costGroupsSql);
  await db.none(personsSql);
  await db.none(engagementsSql);
  await db.none(auditSql);
}
