const getUserProfileHeader = (entitlement: string) => ({
  'user-profile': JSON.stringify({
    id: 'testUser',
    entitlements: {
      eztrac: [entitlement],
    },
  }),
  'user-id': 'test-user',
});

export const manageEngagementsUserHeader = getUserProfileHeader(
  'EZTRAC-MANAGE-ENGAGEMENTS',
);
export const adminUserHeader = getUserProfileHeader('EZTRAC-ADMIN-USER');
