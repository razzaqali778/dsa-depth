import request from 'supertest';
import { CalendarsPaths } from './constantsPaths';
import { StatusCodes } from 'http-status-codes';
import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../src/app.module';
import { INestApplication } from '@nestjs/common';
import { EffortCostingBodyModel } from 'src/costCalc/entities/costCalc.entity';

describe('Cost calc', () => {
  let app: INestApplication;
  let server;
  let moduleFixture: TestingModule;

  beforeAll(async () => {
    moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    server = app.getHttpServer();
  });

  it('returns costs for participants, generic participants and engagements', async () => {
    // Arrange
    const user1 = 'ANSOUZ';
    const user2 = 'GLQRE';
    const user3 = 'AUALC';
    const user1Rate = 72;
    const user2Rate = 120;
    const user3Rate = 68;
    const genericParticipantRate = 125;
    const user1Percent = 100;
    const user2Percent = 50;
    const user3Percent = 100;
    const employeeHoursUSOct = 176;
    const employeeHoursUSNov = 176;
    const contractorHoursBrzOct = 168;
    const numberOfPeople = 2;

    const requestBody: EffortCostingBodyModel[] = [
      {
        teamId: 'teamId',
        timeFrameId: 42310,
        participants: [
          {
            userId: user1,
            percent: user1Percent,
          },
          {
            userId: user2,
            percent: user2Percent,
          },
        ],
        engagements: [
          {
            engagementId: 'MY-TEST-ENGAGEMENT',
            amount: 1200,
          },
        ],
      },
      {
        teamId: 'teamId2',
        timeFrameId: 42311,
        participants: [
          {
            userId: user3,
            percent: user3Percent,
          },
        ],
        genericParticipants: [
          {
            numberOfPeople: numberOfPeople,
            rateId: 'HIGH-RATE',
            costGroupId: 'CLIM-CLOUD-DEV',
          },
        ],
      },
    ];

    // Act
    const response = await request(server)
      .post('/cost-calc/effort')
      .send(requestBody);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.OK);
    expect(response.body).toHaveLength(2);
    expect(response.body).toEqual([
      {
        teamId: requestBody[0].teamId,
        timeFrameId: requestBody[0].timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: 'PE-BRAZIL-IT-CNT',
            cost: (user1Rate * contractorHoursBrzOct * user1Percent) / 100,
            personId: user1,
          },
          {
            costGroupId: 'ITCS-PROD-PLTFM-DESIGN-DCT',
            cost: (user2Rate * employeeHoursUSOct * user2Percent) / 100,
            personId: user2,
          },
          {
            costGroupId: 'SLALOM-SCIENCE-AT-SCALE-PHASE-3',
            cost: 1200,
            engagementId: 'MY-TEST-ENGAGEMENT',
          },
        ],
      },
      {
        teamId: requestBody[1].teamId,
        timeFrameId: requestBody[1].timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: 'CLIM-CSP-IT-CNT',
            cost: (user3Rate * employeeHoursUSNov * user3Percent) / 100,
            personId: user3,
          },
          {
            costGroupId: 'CLIM-CLOUD-DEV',
            cost: genericParticipantRate * employeeHoursUSOct * numberOfPeople,
            personId: 'GENERIC-PERSON',
          },
        ],
      },
    ]);
  });

  it('does not combine costs when participants or generic participants have the same cost group (and does not combine engagements)', async () => {
    // Arrange
    const user1 = 'DAAABE';
    const user2 = 'AUALC';
    const user1Percent = 100;
    const user2Percent = 50;
    const user12Rate = 68;
    const numberOfPeople = 2;
    const employeeHoursUSOct = 176;
    const contractorHoursUsOct = 176;
    const genericParticipantRate = 125;

    const requestBody: EffortCostingBodyModel[] = [
      {
        teamId: 'teamId',
        timeFrameId: 42310,
        participants: [
          {
            userId: user1,
            percent: user1Percent,
          },
          {
            userId: user2,
            percent: user2Percent,
          },
        ],
        genericParticipants: [
          {
            numberOfPeople: numberOfPeople,
            rateId: 'HIGH-RATE',
            costGroupId: 'CLIM-CSP-IT-CNT',
          },
        ],
        engagements: [
          {
            engagementId: 'TEST-ENG-123',
            amount: 1200,
          },
        ],
      },
    ];

    // Act
    const response = await request(server)
      .post('/cost-calc/effort')
      .send(requestBody);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.OK);
    expect(response.body).toHaveLength(1);
    expect(response.body).toEqual([
      {
        teamId: requestBody[0].teamId,
        timeFrameId: requestBody[0].timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: 'CLIM-CSP-IT-CNT',
            cost: (user12Rate * user1Percent * contractorHoursUsOct) / 100,
            personId: user1,
          },
          {
            costGroupId: 'CLIM-CSP-IT-CNT',
            cost: (user12Rate * user2Percent * employeeHoursUSOct) / 100,
            personId: user2,
          },
          {
            costGroupId: 'CLIM-CSP-IT-CNT',
            cost: genericParticipantRate * numberOfPeople * employeeHoursUSOct,
            personId: 'GENERIC-PERSON',
          },
          {
            costGroupId: 'CLIM-CSP-IT-CNT',
            cost: 1200,
            engagementId: 'TEST-ENG-123',
          },
        ],
      },
    ]);
  });

  it('returns default cost values when user id is not found', async () => {
    // Arrange
    const user1 = 'does-not-exist';
    const requestBody: EffortCostingBodyModel[] = [
      {
        teamId: 'teamId',
        timeFrameId: 42310,
        participants: [
          {
            userId: user1,
            percent: 100,
          },
        ],
      },
    ];

    // Act
    const response = await request(server)
      .post('/cost-calc/effort')
      .send(requestBody);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.OK);
    expect(response.body).toHaveLength(1);
    expect(response.body).toEqual([
      {
        teamId: requestBody[0].teamId,
        timeFrameId: requestBody[0].timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: 'UNKNOWN-COST-GROUP',
            cost: 16000,
          },
        ],
      },
    ]);
  });

  it('returns default cost values when calendar time frame hours is not found', async () => {
    // Arrange
    const userId = 'AABBCC';
    const requestBody: EffortCostingBodyModel[] = [
      {
        teamId: 'teamId',
        timeFrameId: 42310,
        participants: [
          {
            userId: userId,
            percent: 100,
          },
        ],
      },
    ];

    // Act
    const response = await request(server)
      .post('/cost-calc/effort')
      .send(requestBody);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.OK);
    expect(response.body).toHaveLength(1);
    expect(response.body).toEqual([
      {
        teamId: requestBody[0].teamId,
        timeFrameId: requestBody[0].timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: 'ITCS-PROD-PLTFM-FIELD-CNT',
            cost: 16000,
            personId: userId,
          },
        ],
      },
    ]);
  });
});
