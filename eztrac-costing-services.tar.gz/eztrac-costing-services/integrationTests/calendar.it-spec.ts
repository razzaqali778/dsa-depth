import request from 'supertest';
import { CalendarsPaths } from './constantsPaths';
import { StatusCodes } from 'http-status-codes';
import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../src/app.module';
import { INestApplication } from '@nestjs/common';

describe('Calendars (GET) ', () => {
  let app: INestApplication;
  let server;
  let moduleFixture: TestingModule;

  beforeAll(async () => {
    moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    server = app.getHttpServer();
  });

  it('returns all calendars', async () => {
    // Act
    const response = await request(server).get(CalendarsPaths.All);
    // Assert
    expect(response.statusCode).toEqual(StatusCodes.OK);
  });

  it('returns all calendar hours', async () => {
    // Act
    const response = await request(server).get(CalendarsPaths.AllHours);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.OK);
  });
});
