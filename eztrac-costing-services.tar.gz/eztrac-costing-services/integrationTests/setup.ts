import { setupIntegrationTestDatabase } from './db/setupTestDatabase';

module.exports = async function (globalConfig, projectConfig) {
  await setupIntegrationTestDatabase();
};
