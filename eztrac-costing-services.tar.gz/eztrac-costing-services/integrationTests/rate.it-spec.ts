import request from 'supertest';
import { StatusCodes } from 'http-status-codes';
import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../src/app.module';
import { INestApplication } from '@nestjs/common';
import { adminUserHeader } from './utils';
import { PROVIDERS } from '../src/constants';
import {
  CreateRateModel,
  Rate,
  UpdateRateModel,
} from '../src/rate/entities/rate.entity';
import { RatesPaths } from '../equalityTests/constants';

describe('Rates', () => {
  let app: INestApplication;
  let server;
  let moduleFixture: TestingModule;
  const papiClient = {
    getEntitlementsForUser: (userId: string, appIds: string[]) =>
      new Promise((resolve) =>
        resolve([{ code: 'EZTRAC-ADMIN-USER', application: { id: 'eztrac' } }]),
      ),
  };

  beforeAll(async () => {
    moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.papiClient)
      .useValue(papiClient)
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
    server = app.getHttpServer();
  });

  it('create rate', async () => {
    // Arrange
    const createRateModel: CreateRateModel = {
      name: 'New rate',
      hourlyRate: 120,
      calendarId: 'US-VARIABLE',
      isActive: true,
      modifiedBy: 'will-be-replaced',
    };

    // Act
    const response = await request(server)
      .post(RatesPaths.All)
      .send(createRateModel)
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.CREATED);

    const rates = (await request(server).get(RatesPaths.All)).body;
    const createdRate = rates.find(
      (r: Rate) => r.name === createRateModel.name,
    );

    expect(createdRate).toBeDefined();
  });

  it('update rate', async () => {
    // Arrange
    const createRateModel: CreateRateModel = {
      name: 'New rate to be updated',
      hourlyRate: 120,
      calendarId: 'US-VARIABLE',
      isActive: true,
      modifiedBy: 'will-be-replaced',
    };

    const createdRate: Rate = (
      await request(server)
        .post(RatesPaths.All)
        .send(createRateModel)
        .set(adminUserHeader)
    ).body;

    const updateRateModel: UpdateRateModel = {
      ...createdRate,
      name: 'Updated rate',
      calendarId: 'NEW-TEST-GROUP',
      isActive: false,
      hourlyRate: 100,
    };

    // Act
    const response = await request(server)
      .put(`${RatesPaths.Single}/${updateRateModel.id}`)
      .send(updateRateModel)
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).toEqual(StatusCodes.OK);

    const rates: Rate[] = (await request(server).get(RatesPaths.All)).body;
    const updatedRate = rates.find((r) => r.id === updateRateModel.id);
    expect(updatedRate).toEqual(updateRateModel);
  });
});
