import { PapiClient } from 'src/common/papi/papi-client.entity';

const createEntitlement = (name: string) => ({
    application: {
        id: 'eztrac'
    },
    code: name
})

enum POSSIBLE_ENTITLEMENTS {
    admin= 'eztrac-admin-user',
    manageEngagements= 'eztrac-manage-engagements',
    managePeople='eztrac-manage-people'
}

const ENTITLEMENTS_FOR_USER = {
    'ADMIN': [createEntitlement(POSSIBLE_ENTITLEMENTS.admin)],
    'MANAGE_ENGAGEMENTS': [createEntitlement(POSSIBLE_ENTITLEMENTS.manageEngagements)],
    'MANAGE_PEOPLE': [createEntitlement(POSSIBLE_ENTITLEMENTS.managePeople)],
    'INVALID': []
}


export async function setupTestPapiClient(): Promise<PapiClient> {
  return {
    getEntitlementsForUser: async (user) => ENTITLEMENTS_FOR_USER[user] || ENTITLEMENTS_FOR_USER['INVALID']
  }
}