import { NameToId } from "../src/utils"

export const mapAuditEntityToDBEntry = audit => ({
      entity_key: audit.entityKey,
      entity_type: audit.entityType,
      user_id: audit.userId,
      modified_time: audit.modifiedTime,
      entity: audit.entity
})
  
export  const mapCalendarEntityToDbEntry = calendar=> ({
    calendar_id: calendar.calendarId,
    calendar_name: calendar.calendarName,
  })
  
 export const mapCalendarHoursEntityToDbEntry = calendarHour => ({
    calendar_id: calendarHour.calendarId,
    timeframe_id: calendarHour.timeFrameId,
    employee_hours: calendarHour.employeeHours,
    contractor_hours: calendarHour.contractorHours
  })
  
export const mapCostGroupEntityToDBEntry = costGroup => ({
    cost_group_id: costGroup.id,
    cost_group_name: costGroup.name,
    cost_center: costGroup.costCenter,
    is_active: costGroup.isActive,
    modified_by: costGroup.modifiedBy,
    exclude_from_distributions: costGroup.excludeFromDistributions
})

export const mapEngagementsEntityToDbEntry = engagement => ({
  engagement_id: engagement.id,
  engagement_name: engagement.name,
  cost_group_id: engagement.costGroupId,
  is_active: engagement.isActive,
  modified_by: engagement.modifiedBy,
  engagement_purchase_order: engagement.purchaseOrder
})

export const mapRatesEntityToDbEntry = rate => ({
  rate_id: rate.id,
  rate_name: rate.name,
  hourly_rate: rate.hourlyRate,
  is_active: rate.isActive,
  modified_by: rate.modifiedBy,
  calendar_id: rate.calendarId,
})

export const mapPersonEntityToDbEntry = person => ({
  user_id: person.personId,
  user_name: person.personName,
  rate_id: NameToId(person.rateName),
  cost_group_id: NameToId(person.costGroupName),
  is_employee: person.isEmployee,
  is_active: person.isActive,
  modified_by: person.modifiedBy,
})