import { newDb } from 'pg-mem';
import { Kysely, PostgresDialect } from 'kysely';
import { DB } from '../src/common/db/database';
import * as fs from 'fs';
import { seedData } from './data-seed';

export async function setupTestDb(): Promise<Kysely<DB>> {
  const inMemoryDb = newDb();
  inMemoryDb.public.none(fs.readFileSync('test-utils/dbSchemaDump.sql', 'utf8'));

  const pgAdapter = inMemoryDb.adapters.createPg();
  const kyselyDb = new Kysely<DB>({
    dialect: new PostgresDialect({
      pool: new pgAdapter.Pool(),
    }),
  });
  await seedData(kyselyDb);
  return kyselyDb;
}
