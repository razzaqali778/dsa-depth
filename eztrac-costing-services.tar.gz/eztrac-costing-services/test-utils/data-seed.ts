import { Kysely } from 'kysely';
import { DB } from 'src/common/db/database';
import { mapAuditEntityToDBEntry, mapCalendarEntityToDbEntry, mapCostGroupEntityToDBEntry, mapCalendarHoursEntityToDbEntry, mapEngagementsEntityToDbEntry, mapPersonEntityToDbEntry, mapRatesEntityToDbEntry } from './data-mappers';
import { createAudit, createCalendar, createCostGroup, createCalendarHours, createEngagement, createPerson, createRate } from './data-utils';

const insertAudits = [createAudit('test'), createAudit('test2')]
const insertCalendars = Array.from(Array(2).keys()).map(i => createCalendar(i))
const insertCalendarHours = [
  createCalendarHours(0,1,20),
  createCalendarHours(0,2,1),
  createCalendarHours(1,2,50),
]
const insertCostGroups = [...Array.from(Array(4).keys()).map(k => createCostGroup(k, Math.random() < 0.5))
, createCostGroup(4, true)]

const insertEngagementsForCostGroup2 = Array.from(Array(2).keys()).map(k => createEngagement(k, insertCostGroups[2].id,  Math.random() < 0.5))
const insertEngagementsForCostGroup3 = Array.from(Array(2).keys()).map(k => createEngagement(k + 2, insertCostGroups[3].id,  Math.random() < 0.5))
const insertEngagements = [...insertEngagementsForCostGroup2, ...insertEngagementsForCostGroup3];

const insertRates = [
  ...Array.from(Array(4).keys()).map(k => createRate(k, Math.floor(Math.random() * 101) + 50, Math.random() < 0.5)),
  createRate(4, 50, true)
]

const insertPeopleWithData1 = Array.from(Array(5).keys()).map(k => createPerson(k, insertCostGroups[2].name, insertRates[1].name ,  Math.random() < 0.5,  Math.random() < 0.5))
const insertPeopleWithData2 = Array.from(Array(5).keys()).map(k => createPerson(k + 5,  insertCostGroups[3].name, insertRates[2].name,  Math.random() < 0.5,  Math.random() < 0.5))
const insertPeople = [...insertPeopleWithData1, ...insertPeopleWithData2, createPerson(11,  insertCostGroups[4].name, insertRates[4].name,  Math.random() < 0.5,  Math.random() < 0.5)];


export const testData = {
  audits: insertAudits.map((audit) => ({
    ...audit,
    entity: JSON.parse(audit.entity as string),
  })),
  calendars: insertCalendars,
  calendarTimeframeHours: insertCalendarHours,
  costGroups: insertCostGroups,
  engagements: insertEngagements,
  rates: insertRates,
  peoples: insertPeople
};

export async function seedData(db: Kysely<DB>) {
  await Promise.all([
    insertAudits.map((audit) =>
      db.insertInto('audit').values(mapAuditEntityToDBEntry(audit)).execute(),
    ),
    insertCostGroups.map((costGroup) =>
      db.insertInto('cost_group').values(mapCostGroupEntityToDBEntry(costGroup)).execute(),
    ),
    insertCalendars.map((calendar) => 
      db.insertInto('calendar').values(mapCalendarEntityToDbEntry(calendar)).execute()
    ),
    insertCalendarHours.map(calendarHour => 
      db.insertInto('calendar_timeframe_hours').values(mapCalendarHoursEntityToDbEntry(calendarHour)).execute()
    ),
    insertEngagements.map(engagement => 
      db.insertInto('engagement').values(mapEngagementsEntityToDbEntry(engagement)).execute()
    ),
    insertRates.map(rate => 
      db.insertInto('rate').values(mapRatesEntityToDbEntry(rate)).execute()
    ),
    insertPeople.map(people => 
      db.insertInto('person').values(mapPersonEntityToDbEntry(people)).execute()
    )
  ]
  );
}
