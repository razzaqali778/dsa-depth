import { Audit } from "src/audits/entities/audit.entity"
import { Calendar, CalendarHours } from "src/calendar/entities/calendar.entity"
import { CostGroup } from "src/costGroup/entities/costGroup.entity"
import { Engagement } from "src/engagement/entities/engagement.entity"
import { Person } from "src/person/entities/person.entity"
import { Rate } from "src/rate/entities/rate.entity"
import { NameToId } from "../src/utils"

export const createCalendar = (id: number): Calendar => ({
    calendarId: `calendar_${id}`,
    calendarName: `calendar_name_${id}`,
})
export const createCalendarHours = (calendarId: number, timeframeId: number, hour: number): CalendarHours => ({
    calendarId: `calendar_${calendarId}`,
    name: `calendar_name_${calendarId}`,
    timeFrameId: timeframeId,
    employeeHours: hour,
    contractorHours: hour*10
})
export const createAudit = (name: string): Audit => ({
    entityKey: `${name}_key`,
    entityType: `${name}_type`,
    userId: `${name}_user`,
    modifiedTime: new Date(),
    entity: `{"name": "${name}_test_name"}`,
})
export const createCostGroup = (id: number, isActive?: boolean, exclude?: boolean): CostGroup => ({
    id: NameToId(`cost_group_name_${id}`),
    name:`cost_group_name_${id}`,
    costCenter: `cost_group_cost_center_${id}`,
    isActive: !!isActive,
    modifiedBy: `modified_by_${id}`,
    excludeFromDistributions: !!exclude
})
export const createEngagement = (id: number, costGroupId: string, isActive?: boolean): Engagement => ({
    id: NameToId(`engagement_name_${id}`),
    name:`engagement_name_${id}`,
    purchaseOrder: `engagement_purchase_order_${id}`,
    isActive: !!isActive,
    modifiedBy: `modified_by_${id}`,
    costGroupId:  costGroupId,
})
export const createRate = (id: number, hourlyRate: number, isActive: boolean, calendarId?: number): Rate => ({
    id: NameToId(`rate_name_${id}`),
    name:`rate_name_${id}`,
    hourlyRate: hourlyRate,
    isActive: isActive,
    modifiedBy: `modified_by_${id}`,
    calendarId: `calendar_${calendarId || id}`,
})
export const createPerson = (id: number, costGroupName: string, rateName: string, isActive?: boolean, isEmployee?: boolean): Person => ({
    personId: NameToId(`person_name_${id}`),
    personName: `person_name_${id}`,
    rateName: rateName,
    costGroupName: costGroupName,
    isActive: !!isActive,
    isEmployee: !!isEmployee,
    modifiedBy: `modified_by_${id}`,
})

export const createParticipant = (userId: string, percent: number) => ({
    userId,
    percent
})

export const createGenericParticipant = (numberOfPeople, rateId, costGroupId) => ({
    numberOfPeople,
    rateId: NameToId(`rate_name_${rateId}`),
    costGroupId: NameToId(`cost_group_name_${costGroupId}`),
})

export const createEffortEngagement = (engagementId: string, amount: number) => ({
    engagementId,
    amount
})