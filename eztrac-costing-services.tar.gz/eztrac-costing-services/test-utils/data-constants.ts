export enum POSSIBLE_USER_HEADERS {
    admin= 'ADMIN',
    manageEngagements= 'MANAGE_ENGAGEMENTS',
    managePeople= 'MANAGE_PEOPLE',
    invalid= 'INVALID'
}