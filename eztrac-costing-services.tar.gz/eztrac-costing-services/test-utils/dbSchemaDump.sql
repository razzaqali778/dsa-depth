--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11
-- Dumped by pg_dump version 14.6 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cost_group_insert_update_trg_f(); Type: FUNCTION; Schema: public; Owner: -
--

-- CREATE FUNCTION public.cost_group_insert_update_trg_f() RETURNS trigger
--     LANGUAGE plpgsql
--     AS $$

-- BEGIN
-- 	INSERT INTO audit (entity_type, entity_key, modified_time, user_id, entity)
--     VALUES ('cost_group', NEW.cost_group_id, current_timestamp, NEW.modified_by,
--         json_build_object(
--             'id', NEW.cost_group_id,
--             'name', NEW.cost_group_name,
--             'costCenter', NEW.cost_center,
--             'isActive', NEW.is_active
--         )
--     );
--     RETURN NEW;
-- END;

-- $$;


--
-- Name: person_insert_update_trg_f(); Type: FUNCTION; Schema: public; Owner: -
--

-- CREATE FUNCTION public.person_insert_update_trg_f() RETURNS trigger
--     LANGUAGE plpgsql
--     AS $$

-- BEGIN
-- 	INSERT INTO audit (entity_type, entity_key, modified_time, user_id, entity)
--     VALUES ('person', NEW.user_id, current_timestamp, NEW.modified_by,
--         json_build_object(
--             'id', NEW.user_id,
--             'name', NEW.user_name,
--             'rateId', NEW.rate_id,
--             'costGroupId', NEW.cost_group_id,
--             'isEmployee', NEW.is_employee,
--             'isActive', NEW.is_active
--         )
--     );
--     RETURN NEW;
-- END;

-- $$;


--
-- Name: rate_insert_update_trg_f(); Type: FUNCTION; Schema: public; Owner: -
--

-- CREATE FUNCTION public.rate_insert_update_trg_f() RETURNS trigger
--     LANGUAGE plpgsql
--     AS $$

-- BEGIN
-- 	INSERT INTO audit (entity_type, entity_key, modified_time, user_id, entity)
--     VALUES ('rate', NEW.rate_id, current_timestamp, NEW.modified_by,
--         json_build_object(
--             'id', NEW.rate_id,
--             'name', NEW.rate_name,
--             'hourlyRate', NEW.hourly_rate,
--             'isActive', NEW.is_active,
--             'calendar_id', NEW.calendar_id
--         )
--     );
--     RETURN NEW;
-- END;

-- $$;


SET default_table_access_method = heap;

--
-- Name: audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit (
    entity_type text NOT NULL,
    entity_key text NOT NULL,
    modified_time timestamp with time zone NOT NULL,
    user_id text NOT NULL,
    entity jsonb NOT NULL
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar (
    calendar_id text NOT NULL,
    calendar_name text NOT NULL
);


--
-- Name: calendar_timeframe_hours; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_timeframe_hours (
    calendar_id text NOT NULL,
    timeframe_id bigint NOT NULL,
    employee_hours integer NOT NULL,
    contractor_hours integer NOT NULL
    -- looks like pg-mem does not support numeric
    -- employee_hours numeric(3,0) NOT NULL,
    -- contractor_hours numeric(3,0) NOT NULL
);


--
-- Name: cost_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_group (
    cost_group_id text NOT NULL,
    cost_group_name text NOT NULL,
    cost_center text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL,
    exclude_from_distributions boolean DEFAULT false NOT NULL
);


--
-- Name: engagement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engagement (
    engagement_id text NOT NULL,
    engagement_name text NOT NULL,
    cost_group_id text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL,
    engagement_purchase_order text
);


--
-- Name: person; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person (
    user_id text NOT NULL,
    user_name text NOT NULL,
    rate_id text NOT NULL,
    cost_group_id text NOT NULL,
    is_employee boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL
);


--
-- Name: rate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate (
    rate_id text NOT NULL,
    rate_name text NOT NULL,
    hourly_rate bigint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL,
    calendar_id text DEFAULT 'US-VARIABLE'::text NOT NULL
);


--
-- Name: audit audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit
    ADD CONSTRAINT audit_pkey PRIMARY KEY (entity_type, entity_key, modified_time);


--
-- Name: calendar calendar_name_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_name_uk UNIQUE (calendar_name);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (calendar_id);


--
-- Name: calendar_timeframe_hours calendar_timeframe_hours_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_timeframe_hours
    ADD CONSTRAINT calendar_timeframe_hours_pk PRIMARY KEY (calendar_id, timeframe_id);


--
-- Name: cost_group cost_group_name_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_group
    ADD CONSTRAINT cost_group_name_uk UNIQUE (cost_group_name);


--
-- Name: cost_group cost_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_group
    ADD CONSTRAINT cost_group_pkey PRIMARY KEY (cost_group_id);


--
-- Name: engagement engagement_name_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement
    ADD CONSTRAINT engagement_name_uk UNIQUE (engagement_name);


--
-- Name: engagement engagement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement
    ADD CONSTRAINT engagement_pkey PRIMARY KEY (engagement_id);


--
-- Name: person person_user_id_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_user_id_pkey PRIMARY KEY (user_id);


--
-- Name: rate rate_name_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_name_uk UNIQUE (rate_name);


--
-- Name: rate rate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_pkey PRIMARY KEY (rate_id);


--
-- Name: fki_audit_person_user_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_audit_person_user_id_fk ON public.audit USING btree (user_id);


--
-- Name: cost_group cost_group_audit_trg; Type: TRIGGER; Schema: public; Owner: -
--

-- CREATE TRIGGER cost_group_audit_trg BEFORE INSERT OR UPDATE ON public.cost_group FOR EACH ROW EXECUTE FUNCTION public.cost_group_insert_update_trg_f();


--
-- Name: person person_audit_trg; Type: TRIGGER; Schema: public; Owner: -
--

-- CREATE TRIGGER person_audit_trg BEFORE INSERT OR UPDATE ON public.person FOR EACH ROW EXECUTE FUNCTION public.person_insert_update_trg_f();


--
-- Name: rate rate_audit_trg; Type: TRIGGER; Schema: public; Owner: -
--

-- CREATE TRIGGER rate_audit_trg BEFORE INSERT OR UPDATE ON public.rate FOR EACH ROW EXECUTE FUNCTION public.rate_insert_update_trg_f();


--
-- Name: calendar_timeframe_hours calendar_timeframe_hours_calendar_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_timeframe_hours
    ADD CONSTRAINT calendar_timeframe_hours_calendar_id_fk FOREIGN KEY (calendar_id) REFERENCES public.calendar(calendar_id);


--
-- Name: engagement cost_group_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engagement
    ADD CONSTRAINT cost_group_id_fk FOREIGN KEY (cost_group_id) REFERENCES public.cost_group(cost_group_id);


--
-- Name: person person_cost_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_cost_group_id_fkey FOREIGN KEY (cost_group_id) REFERENCES public.cost_group(cost_group_id);


--
-- Name: person person_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_rate_id_fkey FOREIGN KEY (rate_id) REFERENCES public.rate(rate_id);


--
-- PostgreSQL database dump complete
--

