const fs = require("fs");
const path = require("path");
const cwd = process.cwd();

const PATHS = {
  servicesPath: path.join(cwd, "src"),
  serviceControllerTplPath: path.join(
    cwd,
    "scripts/generateServiceByTemplate/templates/service.controller.ts.tpl"
  ),
  serviceModuleTplPath: path.join(
    cwd,
    "scripts/generateServiceByTemplate/templates/service.module.ts.tpl"
  ),
  serviceRepositoryTplPath: path.join(
    cwd,
    "scripts/generateServiceByTemplate/templates/service.repository.ts.tpl"
  ),
  serviceServiceTplPath: path.join(
    cwd,
    "scripts/generateServiceByTemplate/templates/service.service.ts.tpl"
  ),

  serviceEntityTplPath: path.join(
    cwd,
    "scripts/generateServiceByTemplate/templates/service.entity.ts.tpl"
  ),

  serviceRepositoryTestTplPath: path.join(
    cwd,
    "scripts/generateServiceByTemplate/templates/service.repository.spec.ts.tpl"
  ),
  serviceControllerTestTplPath: path.join(
    cwd,
    "scripts/generateServiceByTemplate/templates/service.controller.spec.ts.tpl"
  ),
};


const REPLACE_PATTERN = "{serviceName}";
const REPLACE_PATTERN_UPPER = "{serviceNameUpper}";
const SERVICE_PARTS = {
  ServiceController: {
    path: "service.controller.ts",
    tpl: fs.readFileSync(PATHS.serviceControllerTplPath).toString(),
    created: "",
  },
  ServiceModule: {
    path: "service.module.ts",
    tpl: fs.readFileSync(PATHS.serviceModuleTplPath).toString(),
    created: "",
  },
  ServiceRepository: {
    path: "service.repository.ts",
    tpl: fs.readFileSync(PATHS.serviceRepositoryTplPath).toString(),
    created: "",
  },
  ServiceService: {
    path: "service.service.ts",
    tpl: fs.readFileSync(PATHS.serviceServiceTplPath).toString(),
    created: "",
  },

  ServiceEntity: {
    path: "entities/service.entity.ts",
    tpl: fs.readFileSync(PATHS.serviceEntityTplPath).toString(),
    created: "",
  },

  ServiceRepositoryTest: {
    path: "tests/service.repository.spec.ts",
    tpl: fs.readFileSync(PATHS.serviceRepositoryTestTplPath).toString(),
    created: "",
  },
  ServiceControllerTest: {
    path: "tests/service.controller.spec.ts",
    tpl: fs.readFileSync(PATHS.serviceControllerTestTplPath).toString(),
    created: "",
  },
};

const toCamelCase = (name) =>
  name
    .replace(/(?:^\w|[A-Z]|\b\w)/g, function (word, index) {
      return word.toUpperCase();
    })
    .replace(/\-|\_|\s+/g, "");

const toFirstLower = (name) => name.charAt(0).toLowerCase() + name.slice(1);

const createDirectory = (path, name) => {
  if (fs.existsSync(path)) {
    throw new Error(`Directory ${name} already exists in this location`);
  } else {
    fs.mkdirSync(path);
    fs.mkdirSync(`${path}/entities`)
    fs.mkdirSync(`${path}/tests`)
  }
};

const createComponent = () => {
  const name = process.argv.slice(2).join(" ");
  if (!name) {
    throw new Error("Provide name for the service");
  }
  const camelCaseName = toCamelCase(name.toLowerCase());
  const lowerCaseName = toFirstLower(camelCaseName);

  const dirPath = `${PATHS.servicesPath}/${lowerCaseName}`;
  createDirectory(dirPath, lowerCaseName);

  Object.entries(SERVICE_PARTS).map(([key, value]) => {
    const transformed = value.tpl
      ? value.tpl.split(REPLACE_PATTERN).join(lowerCaseName).split(REPLACE_PATTERN_UPPER).join(camelCaseName)
      : "";
    const path = `${dirPath}/${value.path.replace("service", lowerCaseName)}`;
    fs.writeFileSync(path, transformed, "utf8");
  });
};

createComponent();