import { Injectable } from '@nestjs/common';
import { {serviceNameUpper}Repository } from './{serviceName}.repository';

@Injectable()
export class {serviceNameUpper}Service {
  constructor(private repository: {serviceNameUpper}Repository) {}
  async getAll(): Promise<any[]> {
    return this.repository.getAll();
  }

}
