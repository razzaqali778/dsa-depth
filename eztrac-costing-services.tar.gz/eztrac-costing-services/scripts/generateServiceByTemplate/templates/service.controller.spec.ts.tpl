import { Test, TestingModule } from '@nestjs/testing';
import { {serviceNameUpper}Controller } from '../{serviceName}.controller';

describe('{serviceNameUpper}Controller', () => {
  let controller: {serviceNameUpper}Controller;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [{serviceNameUpper}Controller],
    })
      .useMocker(() => ({

      }))
      .compile();

    controller = module.get<{serviceNameUpper}Controller>({serviceNameUpper}Controller);
  });

  it('getAll', async () => {
    const result = await controller.getAll();
    expect(result.length).toBeDefined();
  });
});
