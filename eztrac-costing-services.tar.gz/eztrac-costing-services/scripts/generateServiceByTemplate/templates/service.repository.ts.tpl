import { Inject, Injectable } from '@nestjs/common';
import { Kysely } from 'kysely';
import { DB } from 'src/common/db/database';
import { PROVIDERS } from '../constants';

@Injectable()
export class {serviceNameUpper}Repository {
  constructor(
    @Inject(PROVIDERS.database)
    private db: Kysely<DB>,
  ) {}
  async getAll(): Promise<any> {
    return this.db
      .selectFrom('')
      .select()
      .execute();
  }
}
