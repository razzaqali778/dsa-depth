import { Controller, Get } from '@nestjs/common';
import { {serviceNameUpper}Service } from './{serviceName}.service';

@Controller('{serviceName}')
export class {serviceNameUpper}Controller {
  constructor(private readonly {serviceName}Service: {serviceNameUpper}Service) {}

  @Get()
  getAll() {
    return this.{serviceName}Service.getAll();
  }
}
