import { Test, TestingModule } from '@nestjs/testing';
import { {serviceNameUpper}Repository } from '../{serviceName}.repository';
import { setupTestDb } from '../../../test-utils/setup-test-db';
import { PROVIDERS } from '../../constants';
import { CommonModule } from '../../common/common.module';

describe('{serviceNameUpper}Service', () => {
  let service: {serviceNameUpper}Repository;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [CommonModule],
      providers: [{serviceNameUpper}Repository],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    service = module.get<{serviceNameUpper}Repository>({serviceNameUpper}Repository);
  });

  it('should return all ', async () => {
    const data = await service.getAll();
    expect(data.length).toBeDefined()
  });
});
