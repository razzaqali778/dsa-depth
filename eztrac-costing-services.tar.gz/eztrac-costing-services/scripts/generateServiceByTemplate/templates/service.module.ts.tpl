import { Module } from '@nestjs/common';
import { {serviceNameUpper}Repository } from './{serviceName}.repository';
import { {serviceNameUpper}Controller } from './{serviceName}.controller';
import { {serviceNameUpper}Service } from './{serviceName}.service';

@Module({
  controllers: [{serviceNameUpper}Controller],
  providers: [{serviceNameUpper}Repository, {serviceNameUpper}Service],
})
export class {serviceNameUpper}Module {}
