# connect to database through ssh and run this command to generate schema dump
# before using generated scripts to set up pg-mem database any triggers and functions have to be commented out or removed (it seems like pg-mem does not support them)
pg_dump --schema-only --no-owner --no-acl --disable-triggers --no-comments --no-publications --no-security-labels --no-subscriptions --no-tablespaces --host localhost --port 6999 --user <user> --password  <dbName> > schemaDump.sql
