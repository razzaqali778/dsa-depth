import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PROVIDERS } from '../src/constants';
import { setupTestDb } from '../test-utils/setup-test-db';
import { testData } from '../test-utils/data-seed';

describe('CalendarsController (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/ (GET) all Calendars', async () => {
    const expected = testData.calendars;

    const response = await request(app.getHttpServer())
      .get('/calendars')
      .expect(200);
    expect(response.body).toEqual(expected);
  });

  it('/ (GET) all Calendar hours', async () => {
    const expectedCalendarHours = testData.calendarTimeframeHours;

    const response = await request(app.getHttpServer())
      .get('/calendars/hours')
      .expect(200);
    expect(response.body).toEqual(expectedCalendarHours);
  });
});
