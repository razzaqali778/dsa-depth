import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PROVIDERS } from '../src/constants';
import { setupTestDb } from '../test-utils/setup-test-db';
import { testData } from '../test-utils/data-seed';
import { EffortCostingBodyModel } from '../src/costCalc/entities/costCalc.entity';

describe('CostCalc (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/ (POST) returns proper data when request data is ok', async () => {
    const requestData: EffortCostingBodyModel = {
      teamId: 'testTeamId',
      timeFrameId: 3,
      participants: [
        {
          userId: testData.peoples[10].personId,
          percent: 50,
        },
      ],
      genericParticipants: [
        {
          numberOfPeople: 20,
          rateId: testData.rates[4].id,
          costGroupId: testData.costGroups[4].id,
        },
      ],
      engagements: [
        {
          engagementId: testData.engagements[2].id,
          amount: 15,
        },
      ],
    };

    const expectedResponse = {
      teamId: requestData.teamId,
      timeFrameId: requestData.timeFrameId,
      teamMemberCosts: [
        {
          costGroupId: testData.costGroups[4].id,
          cost: 4000,
          personId: testData.peoples[10].personId,
        },
        {
          costGroupId: testData.costGroups[4].id,
          cost: 160000,
          personId: 'GENERIC-PERSON',
        },
        {
          costGroupId: testData.engagements[2].costGroupId,
          cost: 15,
          engagementId: testData.engagements[2].id,
        },
      ],
    };

    const response = await request(app.getHttpServer())
      .post('/cost-calc/effort')
      .send([requestData]);

    expect(response.body).toHaveLength(1);
    expect(response.body).toEqual([expectedResponse]);
  });
});
