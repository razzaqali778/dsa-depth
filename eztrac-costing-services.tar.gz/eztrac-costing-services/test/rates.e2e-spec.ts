import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PROVIDERS } from '../src/constants';
import { setupTestDb } from '../test-utils/setup-test-db';
import { testData } from '../test-utils/data-seed';
import { setupTestPapiClient } from '../test-utils/setup-test-papi-client';
import { createRate } from '../test-utils/data-utils';
import { POSSIBLE_USER_HEADERS } from '../test-utils/data-constants';
import { NameToId } from '../src/utils';

describe('RatesController (e2e)', () => {
  let app: INestApplication;
  let server;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .overrideProvider(PROVIDERS.papiClient)
      .useFactory({
        factory: async () => await setupTestPapiClient(),
      })
      .compile();

    app = moduleFixture.createNestApplication();
    server = app.getHttpServer();
    await app.init();
  });

  describe('/ (GET) ', () => {
    it('working properly without additional params', async () => {
      const response = await request(server).get('/rates').expect(200);
      expect(response.body).toEqual(expect.arrayContaining(testData.rates));
      expect(response.body).toHaveLength(testData.rates.length);
    });

    it('working properly with isActive parameter', async () => {
      for (const activeValue of [true, false]) {
        const response = await request(server)
          .get(`/rates?isActive=${activeValue}`)
          .expect(200);

        for (const resp of response.body) {
          expect(resp.isActive).toBe(activeValue);
        }
      }
    });

    it('getting rate by id working properly', async () => {
      const response = await request(server).get(
        `/rate/${testData.rates[0].id}`,
      );
      expect(response.status).toEqual(200);
    });

    it('throws not found error when the provided rate id does not exist', async () => {
      const nonExistingId = 'nonExistingId';
      const response = await request(server).get(`/rate/${nonExistingId}`);
      expect(response.status).toEqual(404);
    });
  });

  describe('/ (DELETE) ', () => {
    const newRate = createRate(15, 50, false);
    it('flow is working properly', async () => {
      const responseBefore = await request(server).get('/rates');

      const response = await request(server)
        .post('/rates')
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newRate);
      expect(response.body).toBeDefined();
      expect(response.body).toEqual({
        ...newRate,
        id: NameToId(newRate.name),
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfter = await request(server).get('/rates');
      expect(responseAfter.body).toHaveLength(responseBefore.body.length + 1);
      expect(
        responseAfter.body.find((cG) => cG.id === newRate.id),
      ).toBeTruthy();

      const deleteResponse = await request(server)
        .delete(`/rate/delete/${newRate.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin);
      expect(deleteResponse.body).toBeDefined();
      expect(deleteResponse.body).toEqual({
        ...newRate,
        id: NameToId(newRate.name),
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfterDelete = await request(server).get('/rates');

      expect(responseAfterDelete.body).toHaveLength(responseBefore.body.length);
      expect(responseAfterDelete.body).toStrictEqual(responseBefore.body);
      expect(responseAfterDelete.body.find((cG) => cG.id === newRate.id))
        .toBeFalsy;
    });
  });

  describe('/ (POST) ', () => {
    const newRate = createRate(15, 10, false);

    it('working properly when entry doesn`t exist ', async () => {
      const responseBefore = await request(server).get('/rates');

      const response = await request(server)
        .post('/rates')
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newRate);
      expect(response.body).toBeDefined();
      expect(response.body).toEqual({
        ...newRate,
        id: NameToId(newRate.name),
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfter = await request(server).get('/rates');
      expect(responseAfter.body).toHaveLength(responseBefore.body.length + 1);
    });

    it('throws forbidden error when no user id provided ', async () => {
      const response = await request(server).post('/rates').send(newRate);
      expect(response.status).toEqual(403);
    });

    it('throws forbidden error when user with bad permissions try to edit ', async () => {
      const response = await request(server)
        .post('/rates')
        .set('user-id', POSSIBLE_USER_HEADERS.invalid)
        .send(newRate);
      expect(response.status).toEqual(403);
    });
  });

  describe('/ (PUT) ', () => {
    const newRate = createRate(20, 12, false);
    it('throws error when entry doesn`t exist ', async () => {
      const response = await request(server)
        .put(`/rate/${newRate.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newRate);
      expect(response.status).toEqual(404);
    });

    it('working properly when entry already exists ', async () => {
      const responseBefore = await request(server).get('/rates');

      const response = await request(server)
        .put(`/rate/${newRate.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send({ ...testData.rates[0], isActive: true });
      expect(response.body).toBeDefined();
      expect(response.body).toEqual({
        ...testData.rates[0],
        isActive: true,
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfter = await request(server).get('/rates');
      expect(responseAfter.body).toHaveLength(responseBefore.body.length);
    });

    it('throws forbidden error when no user id provided ', async () => {
      const response = await request(server)
        .put(`/rate/${newRate.id}`)
        .send(newRate);
      expect(response.status).toEqual(403);
    });

    it('throws forbidden error when user with bad permissions try to edit ', async () => {
      const response = await request(server)
        .put(`/rate/${newRate.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.invalid)
        .send(newRate);
      expect(response.status).toEqual(403);
    });
  });
});
