import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PROVIDERS } from '../src/constants';
import { setupTestDb } from '../test-utils/setup-test-db';
import { testData } from '../test-utils/data-seed';
import { Person } from '../src/person/entities/person.entity';
import { POSSIBLE_USER_HEADERS } from '../test-utils/data-constants';
import { createPerson } from '../test-utils/data-utils';
import { setupTestPapiClient } from '../test-utils/setup-test-papi-client';

describe('PersonController (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .overrideProvider(PROVIDERS.papiClient)
      .useFactory({
        factory: async () => await setupTestPapiClient(),
      })
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  describe('/PERSON ', () => {
    it('/ (GET) - existing user', async () => {
      const response = await request(app.getHttpServer())
        .get(`/person/${testData.peoples[0].personId}`)
        .expect(200);
      expect(response.body).toEqual(testData.peoples[0]);
    });

    it('/ (GET) - not existing user', async () => {
      const response = await request(app.getHttpServer())
        .get(`/person/not_existing`)
        .expect(404);
      expect(response.statusCode).toEqual(404);
    });

    it('/ (PUT) - creates user when proper rate and cost group ids', async () => {
      const newPerson = {
        ...createPerson(
          20,
          testData.costGroups[2].name,
          testData.rates[2].name,
          true,
          false,
        ),
        rateId: testData.rates[2].id,
        costGroupId: testData.costGroups[2].id,
      };
      const response = await request(app.getHttpServer())
        .put(`/person`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newPerson);

      expect(response.body).toBeDefined();
      expect(response.body.personId).toEqual(newPerson.personId);
      expect(response.body.personName).toEqual(newPerson.personName);
      expect(response.body.rateName).toEqual(newPerson.rateName);
      expect(response.body.costGroupName).toEqual(newPerson.costGroupName);
      expect(response.body.isActive).toEqual(newPerson.isActive);
      expect(response.body.modifiedBy).toEqual(POSSIBLE_USER_HEADERS.admin);
    });

    it('/ (PUT) - throws when invalid cost group id', async () => {
      const newPerson = {
        ...createPerson(20, 'invalid', testData.rates[2].name, true, false),
        rateId: testData.rates[2].id,
        costGroupId: 'invalid',
      };
      const response = await request(app.getHttpServer())
        .put(`/person`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newPerson);
      expect(response.statusCode).toEqual(404);
    });

    it('/ (PUT) - throws when invalid rate id', async () => {
      const newPerson = {
        ...createPerson(
          20,
          testData.costGroups[2].name,
          'invalid',
          true,
          false,
        ),
        rateId: 'invalid',
        costGroupId: testData.costGroups[2].id,
      };
      const response = await request(app.getHttpServer())
        .put(`/person`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newPerson);
      expect(response.statusCode).toEqual(404);
    });

    it('/ (PUT) - throws when invalid permissions', async () => {
      const newPerson = {
        ...createPerson(20, 'invalid', testData.rates[2].name, true, false),
        rateId: testData.rates[2].id,
        costGroupId: 'invalid',
      };
      const response = await request(app.getHttpServer())
        .put(`/person`)
        .set('user-id', 'invalid')
        .send(newPerson);
      expect(response.statusCode).toEqual(403);
    });

    it('/ (PATCH) - updates user active status when user exists', async () => {
      const updateData = {
        isActive: !testData.peoples[0].isActive,
      };
      const response = await request(app.getHttpServer())
        .patch(`/person/${testData.peoples[0].personId}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(updateData);

      expect(response.body).toBeDefined();
    });

    it('/ (PATCH) - returns proper error when user doesn`t exist', async () => {
      const updateData = {
        isActive: !testData.peoples[0].isActive,
      };
      const response = await request(app.getHttpServer())
        .patch(`/person/invalid`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(updateData);

      expect(response.body.statusCode).toEqual(404);
    });

    it('/ (PATCH) - returns proper error when not proper permissions', async () => {
      const updateData = {
        isActive: !testData.peoples[0].isActive,
      };
      const response = await request(app.getHttpServer())
        .patch(`/person/${testData.peoples[0].personId}`)
        .set('user-id', 'invalid')
        .send(updateData);

      expect(response.body.statusCode).toEqual(403);
    });
  });

  describe('/PEOPLE', () => {
    const allPeople = testData.peoples;
    it('/ (GET) - no params', async () => {
      const response = await request(app.getHttpServer())
        .get('/people')
        .expect(200);
      expect(response.body).toEqual(expect.arrayContaining(allPeople));
      expect(response.body).toHaveLength(allPeople.length);
    });

    it('/ (GET) - query', async () => {
      const response = await request(app.getHttpServer())
        .get('/people?q=AABB')
        .expect(200);
      const expected = allPeople.filter((person) =>
        person.personId.includes('AABB'),
      );
      expect(response.body).toEqual(expect.arrayContaining(expected));
      expect(response.body).toHaveLength(expected.length);
    });

    it('/ (GET) - by cost group', async () => {
      const response = await request(app.getHttpServer())
        .get(`/people?costGroupId=${testData.costGroups[1].id}`)
        .expect(200);
      response.body.forEach((data: Person) => {
        expect(data.costGroupName).toEqual(testData.costGroups[1].name);
        expect(data.isActive).toEqual(true);
      });
    });

    it('/ (GET) - by cost group - inactive', async () => {
      const response = await request(app.getHttpServer())
        .get(`/people?costGroupId=${testData.costGroups[1].id}&isActive=false`)
        .expect(200);
      response.body.forEach((data: Person) => {
        expect(data.costGroupName).toEqual(testData.costGroups[1].name);
        expect(data.isActive).toEqual(false);
      });
    });

    it('/ (GET) - by rate', async () => {
      const response = await request(app.getHttpServer())
        .get(`/people?rateId=${testData.rates[1].id}`)
        .expect(200);
      response.body.forEach((data: Person) => {
        expect(data.rateName).toEqual(testData.rates[1].name);
        expect(data.isActive).toEqual(true);
      });
    });

    it('/ (GET) - by rate - inactive', async () => {
      const response = await request(app.getHttpServer())
        .get(`/people?rateId=${testData.rates[1].id}&isActive=false`)
        .expect(200);
      response.body.forEach((data: Person) => {
        expect(data.rateName).toEqual(testData.rates[1].name);
        expect(data.isActive).toEqual(false);
      });
    });

    it('/ (GET) - by active status - active', async () => {
      const response = await request(app.getHttpServer())
        .get(`/people?isActive=true`)
        .expect(200);
      response.body.forEach((data: Person) => {
        expect(data.isActive).toEqual(true);
      });
    });

    it('/ (GET) -  by active status - inactive', async () => {
      const response = await request(app.getHttpServer())
        .get(`/people?isActive=false`)
        .expect(200);
      response.body.forEach((data: Person) => {
        expect(data.isActive).toEqual(false);
      });
    });
  });
});
