import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PROVIDERS } from '../src/constants';
import { setupTestDb } from '../test-utils/setup-test-db';
import { testData } from '../test-utils/data-seed';
import { setupTestPapiClient } from '../test-utils/setup-test-papi-client';
import { createEngagement } from '../test-utils/data-utils';
import { POSSIBLE_USER_HEADERS } from '../test-utils/data-constants';
import { NameToId } from '../src/utils';

describe('EngagementsController (e2e)', () => {
  let app: INestApplication;
  let server;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .overrideProvider(PROVIDERS.papiClient)
      .useFactory({
        factory: async () => await setupTestPapiClient(),
      })
      .compile();

    app = moduleFixture.createNestApplication();
    server = app.getHttpServer();
    await app.init();
  });

  describe('/ (GET) ', () => {
    it('working properly without additional params', async () => {
      const response = await request(server).get('/engagements').expect(200);
      expect(response.body).toEqual(testData.engagements);
      expect(response.body).toHaveLength(testData.engagements.length);
    });

    it('working properly with isActive parameter', async () => {
      for (const activeValue of [true, false]) {
        const response = await request(server)
          .get(`/engagements?isActive=${activeValue}`)
          .expect(200);

        for (const resp of response.body) {
          expect(resp.isActive).toBe(activeValue);
        }
      }
    });
  });

  describe('/ (POST) ', () => {
    const newEngagement = createEngagement(
      15,
      testData.costGroups[3].id,
      false,
    );

    it('working properly when entry doesn`t exist ', async () => {
      const responseBefore = await request(server).get('/engagements');

      const response = await request(server)
        .post('/engagements')
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newEngagement);
      expect(response.body).toBeDefined();
      expect(response.body).toEqual({
        ...newEngagement,
        id: NameToId(newEngagement.name),
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfter = await request(server).get('/engagements');
      expect(responseAfter.body).toHaveLength(responseBefore.body.length + 1);
    });

    it('throws forbidden error when no user id provided ', async () => {
      const response = await request(server)
        .post('/engagements')
        .send(newEngagement);
      expect(response.status).toEqual(403);
    });

    it('throws forbidden error when user with bad permissions try to edit ', async () => {
      const response = await request(server)
        .post('/engagements')
        .set('user-id', POSSIBLE_USER_HEADERS.invalid)
        .send(newEngagement);
      expect(response.status).toEqual(403);
    });
  });

  describe('/ (DELETE) ', () => {
    const newEngagement = createEngagement(
      15,
      testData.costGroups[3].id,
      false,
    );
    it('flow is working properly', async () => {
      const responseBefore = await request(server).get('/engagements');

      const response = await request(server)
        .post('/engagements')
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newEngagement);
      expect(response.body).toBeDefined();
      expect(response.body).toEqual({
        ...newEngagement,
        id: NameToId(newEngagement.name),
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfter = await request(server).get('/engagements');
      expect(responseAfter.body).toHaveLength(responseBefore.body.length + 1);
      expect(
        responseAfter.body.find((cG) => cG.id === newEngagement.id),
      ).toBeTruthy();

      const deleteResponse = await request(server)
        .delete(`/engagements/delete/${newEngagement.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin);
      expect(deleteResponse.body).toBeDefined();
      expect(deleteResponse.body).toEqual({
        ...newEngagement,
        id: NameToId(newEngagement.name),
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfterDelete = await request(server).get('/engagements');
      expect(responseAfterDelete.body).toHaveLength(responseBefore.body.length);
      expect(responseAfterDelete.body).toStrictEqual(responseBefore.body);
      expect(responseAfterDelete.body.find((cG) => cG.id === newEngagement.id))
        .toBeFalsy;
    });
  });

  describe('/ (PUT) ', () => {
    const newEngagement = createEngagement(
      15,
      testData.costGroups[3].id,
      false,
    );
    it('throws error when entry doesn`t exist ', async () => {
      const response = await request(server)
        .put(`/engagement/${newEngagement.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newEngagement);
      expect(response.status).toEqual(404);
    });

    it('working properly when entry already exists ', async () => {
      const responseBefore = await request(server).get('/engagements');

      const response = await request(server)
        .put(`/engagement/${newEngagement.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send({ ...testData.engagements[0], isActive: true });
      expect(response.body).toBeDefined();
      expect(response.body).toEqual({
        ...testData.engagements[0],
        isActive: true,
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfter = await request(server).get('/engagements');
      expect(responseAfter.body).toHaveLength(responseBefore.body.length);
    });

    it('throws forbidden error when no user id provided ', async () => {
      const response = await request(server)
        .put(`/engagement/${newEngagement.id}`)
        .send(newEngagement);
      expect(response.status).toEqual(403);
    });

    it('throws forbidden error when user with bad permissions try to edit ', async () => {
      const response = await request(server)
        .put(`/engagement/${newEngagement.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.invalid)
        .send(newEngagement);
      expect(response.status).toEqual(403);
    });
  });
});
