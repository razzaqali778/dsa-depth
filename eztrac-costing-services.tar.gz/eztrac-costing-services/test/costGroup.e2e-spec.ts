import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PROVIDERS } from '../src/constants';
import { setupTestDb } from '../test-utils/setup-test-db';
import { testData } from '../test-utils/data-seed';
import { POSSIBLE_USER_HEADERS } from '../test-utils/data-constants';
import { createCostGroup } from '../test-utils/data-utils';
import { setupTestPapiClient } from '../test-utils/setup-test-papi-client';
import { NameToId } from '../src/utils';

describe('CostGroupController (e2e)', () => {
  let app: INestApplication;
  let server;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .overrideProvider(PROVIDERS.papiClient)
      .useFactory({
        factory: async () => await setupTestPapiClient(),
      })
      .compile();

    app = moduleFixture.createNestApplication();
    server = app.getHttpServer();
    await app.init();
  });

  describe('/ (GET) ', () => {
    it('working properly without additional params', async () => {
      const response = await request(server).get('/costGroups').expect(200);
      expect(response.body).toEqual(
        expect.arrayContaining(testData.costGroups),
      );
      expect(response.body).toHaveLength(testData.costGroups.length);
    });

    it('working properly with isActive parameter', async () => {
      for (const activeValue of [true, false]) {
        const response = await request(server)
          .get(`/costGroups?isActive=${activeValue}`)
          .expect(200);

        for (const resp of response.body) {
          expect(resp.isActive).toBe(activeValue);
        }
      }
    });
  });

  describe('/ (POST) ', () => {
    const newCostGroup = createCostGroup(15);

    it('working properly when entry doesn`t exist ', async () => {
      const responseBefore = await request(server).get('/costGroups');

      const response = await request(server)
        .post('/costGroups')
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newCostGroup);
      expect(response.body).toBeDefined();
      expect(response.body).toEqual({
        ...newCostGroup,
        id: NameToId(newCostGroup.name),
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfter = await request(server).get('/costGroups');
      expect(responseAfter.body).toHaveLength(responseBefore.body.length + 1);
    });

    it('throws forbidden error when no user id provided ', async () => {
      const response = await request(server)
        .post('/costGroups')
        .send(newCostGroup);
      expect(response.status).toEqual(403);
    });

    it('throws forbidden error when user with bad permissions try to edit ', async () => {
      const response = await request(server)
        .post('/costGroups')
        .set('user-id', POSSIBLE_USER_HEADERS.invalid)
        .send(newCostGroup);
      expect(response.status).toEqual(403);
    });
  });

  describe('/ (DELETE) ', () => {
    const newCostGroup = createCostGroup(15);
    it('flow is working properly', async () => {
      const responseBefore = await request(server).get('/costGroups');

      const response = await request(server)
        .post('/costGroups')
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newCostGroup);
      expect(response.body).toBeDefined();
      expect(response.body).toEqual({
        ...newCostGroup,
        id: NameToId(newCostGroup.name),
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfter = await request(server).get('/costGroups');
      expect(responseAfter.body).toHaveLength(responseBefore.body.length + 1);
      expect(
        responseAfter.body.find((cG) => cG.id === newCostGroup.id),
      ).toBeTruthy();

      const deleteResponse = await request(server)
        .delete(`/costGroups/delete/${newCostGroup.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin);
      expect(deleteResponse.body).toBeDefined();
      expect(deleteResponse.body).toEqual({
        ...newCostGroup,
        id: NameToId(newCostGroup.name),
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfterDelete = await request(server).get('/costGroups');
      expect(responseAfterDelete.body).toHaveLength(responseBefore.body.length);
      expect(responseAfterDelete.body).toStrictEqual(responseBefore.body);
      expect(responseAfterDelete.body.find((cG) => cG.id === newCostGroup.id))
        .toBeFalsy;
    });
  });

  describe('/ (PUT) ', () => {
    const newCostGroup = createCostGroup(15);
    it('throws error when entry doesn`t exist ', async () => {
      const response = await request(server)
        .put(`/costGroup/${newCostGroup.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send(newCostGroup);
      expect(response.status).toEqual(404);
    });

    it('working properly when entry already exists ', async () => {
      const responseBefore = await request(server).get('/costGroups');

      const response = await request(server)
        .put(`/costGroup/${newCostGroup.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.admin)
        .send({ ...testData.costGroups[0], isActive: true });
      expect(response.body).toBeDefined();
      expect(response.body).toEqual({
        ...testData.costGroups[0],
        isActive: true,
        modifiedBy: POSSIBLE_USER_HEADERS.admin,
      });

      const responseAfter = await request(server).get('/costGroups');
      expect(responseAfter.body).toHaveLength(responseBefore.body.length);
    });

    it('throws forbidden error when no user id provided ', async () => {
      const response = await request(server)
        .put(`/costGroup/${newCostGroup.id}`)
        .send(newCostGroup);
      expect(response.status).toEqual(403);
    });

    it('throws forbidden error when user with bad permissions try to edit ', async () => {
      const response = await request(server)
        .put(`/costGroup/${newCostGroup.id}`)
        .set('user-id', POSSIBLE_USER_HEADERS.invalid)
        .send(newCostGroup);
      expect(response.status).toEqual(403);
    });
  });
});
