import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { PROVIDERS } from '../src/constants';
import { setupTestDb } from '../test-utils/setup-test-db';
import { testData } from '../test-utils/data-seed';

describe('AuditsController (e2e)', () => {
  let app: INestApplication;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/ (GET)', async () => {
    const expected = testData.audits.map((audit) => ({
      ...audit,
      modifiedTime: audit.modifiedTime.toISOString(),
    }));

    const response = await request(app.getHttpServer())
      .get('/audits/')
      .expect(200);
    expect(response.body).toEqual(expect.arrayContaining(expected));
    expect(response.body).toHaveLength(testData.audits.length);
  });
});
