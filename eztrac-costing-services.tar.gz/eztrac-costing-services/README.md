## Description

Backend services for ez-trac costing, with a postgres backend. Handles people, number of hours in month,cost groups, and rates.

## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ npm run start

# watch mode
$ npm run dev

# production mode
$ npm run prod
```

## Test

```bash
# unit tests
$ npm run test

# integration tests
$ npm run test:integration

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```
