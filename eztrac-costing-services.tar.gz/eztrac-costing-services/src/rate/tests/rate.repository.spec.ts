import { Test, TestingModule } from '@nestjs/testing';
import { RateRepository } from '../rate.repository';
import { setupTestDb } from 'test-utils/setup-test-db';
import { CommonModule } from '../../common/common.module';
import { testData } from 'test-utils/data-seed';
import { Rate } from '../entities/rate.entity';
import { PROVIDERS } from 'src/constants';
import { createRate } from 'test-utils/data-utils';

describe('RateService', () => {
  let service: RateRepository;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [CommonModule],
      providers: [RateRepository],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    service = module.get<RateRepository>(RateRepository);
  });

  it('should return all ', async () => {
    const expected = testData.rates;

    const data: Rate[] = await service.getAll();
    expect(data).toHaveLength(expected.length);
    expect(data).toEqual(expected);
  });

  it('should return all inactive', async () => {
    const data: Rate[] = await service.getAll(false);
    data.forEach((d) => {
      expect(d.isActive).toEqual(false);
    });
  });

  it('should return all active', async () => {
    const data: Rate[] = await service.getAll(true);
    data.forEach((d) => {
      expect(d.isActive).toEqual(true);
    });
  });

  it('should return by id', async () => {
    const data: Rate = await service.byId(testData.rates[0].id);
    expect(data).toBeDefined();
    expect(data.id).toEqual(testData.rates[0].id);
  });

  it('should return by name', async () => {
    const data: Rate = await service.byName(testData.rates[1].name);
    expect(data).toBeDefined();
    expect(data.name).toEqual(testData.rates[1].name);
  });

  it('should create new rate', async () => {
    const beforeAdd: Rate[] = await service.getAll(false);
    const newRate = createRate(15, 20, false);
    const data: Rate = await service.createOrUpdateOne(newRate);
    const afterAdd: Rate[] = await service.getAll(false);

    expect(data).toBeDefined();
    expect(data).toEqual(newRate);
    expect(afterAdd).toHaveLength(beforeAdd.length + 1);
  });
});
