import { Test, TestingModule } from '@nestjs/testing';
import { testData } from 'test-utils/data-seed';
import { RatesController } from '../rates.controller';
import { RateController } from '../rate.controller';
import { Rate } from '../entities/rate.entity';
import { createRate } from 'test-utils/data-utils';

describe('RateController', () => {
  let controller: RatesController;
  let controllerSingle: RateController;

  const allRates: Rate[] = testData.rates;
  const newRate: Rate = createRate(12, 12, true);

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [RateController, RatesController],
    })
      .useMocker(() => ({
        getAll: jest.fn().mockResolvedValue(allRates),
        getById: jest.fn().mockResolvedValue(allRates[0]),
        getByName: jest.fn().mockResolvedValue(allRates[1]),
        createOrUpdateOne: jest.fn().mockResolvedValue(newRate),
        updateOne: jest.fn().mockResolvedValue(newRate),
      }))
      .compile();

    controller = module.get<RatesController>(RatesController);
    controllerSingle = module.get<RateController>(RateController);
  });

  it('getAll', async () => {
    const result = await controller.getAll();
    expect(result).toEqual(allRates);
  });

  it('getById', async () => {
    const result = await controllerSingle.getById(allRates[0].id);
    expect(result).toEqual(allRates[0]);
  });

  it('createOne', async () => {
    const result = await controller.createOne(newRate, { user: 'user' });
    expect(result).toEqual(newRate);
  });

  it('update', async () => {
    const result = await controllerSingle.update(
      { ...testData.rates[0], hourlyRate: 70 },
      { user: 'user' },
    );
    expect(result).toBeDefined();
  });
});
