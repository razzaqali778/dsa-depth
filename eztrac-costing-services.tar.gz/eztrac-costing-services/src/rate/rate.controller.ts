import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Put,
  Req,
  UseGuards,
} from '@nestjs/common';
import { Roles } from '../common/roles/roles.decorator';
import { Role } from '../common/roles/roles.enum';
import { RolesGuard } from '../common/roles/roles.guard';
import { UpdateRateModel } from './entities/rate.entity';
import { RateService } from './rate.service';

@Controller('rate')
export class RateController {
  constructor(private readonly rateService: RateService) {}

  @Get(':id')
  getById(@Param('id') rateId: string) {
    return this.rateService.getById(rateId);
  }

  @Put('/:id')
  @UseGuards(RolesGuard)
  @Roles(Role.MANAGE_RATES)
  update(@Body() rate: UpdateRateModel, @Req() req) {
    return this.rateService.updateOne(rate, req.user);
  }

  @Delete('/delete/:id')
  @UseGuards(RolesGuard)
  @Roles(Role.MANAGE_RATES)
  deleteOne(@Param('id') rateId) {
    return this.rateService.deleteOne(rateId);
  }
}
