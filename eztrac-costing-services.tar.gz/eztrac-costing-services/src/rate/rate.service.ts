import { Injectable } from '@nestjs/common';
import { RateRepository } from './rate.repository';
import {
  throwHttpErrorBadRequest,
  throwHttpErrorNotFound,
} from '../httpErrorUtils';
import {
  UpdateRateModel as UpdateRateModel,
  CreateRateModel as CreateRateModel,
  Rate,
} from './entities/rate.entity';
import { NameToId } from '../utils';

@Injectable()
export class RateService {
  constructor(private repository: RateRepository) {}

  async getAll(isActive?: boolean): Promise<Rate[]> {
    return this.repository.getAll(isActive);
  }

  async getById(rateId: string): Promise<Rate> {
    const result = await this.repository.byId(rateId);
    if (!result)
      throwHttpErrorNotFound(`Unable to find rate with id: ${rateId}`);
    return result;
  }

  async getByName(rateName: string): Promise<Rate> {
    const result = await this.repository.byName(rateName);
    if (!result) {
      throwHttpErrorNotFound(`Unable to find rate with name: ${rateName}`);
    }
    return result;
  }

  async createOrUpdateOne(
    newRate: CreateRateModel,
    userId: string,
  ): Promise<Rate> {
    const updatedRate = {
      ...newRate,
      id: NameToId(newRate.name),
      modifiedBy: userId,
    };

    const exists = await this.repository.byId(updatedRate.id);
    if (exists)
      throwHttpErrorBadRequest(
        `Rate with provided name: ${updatedRate.name} already exists`,
      );

    return this.repository.createOrUpdateOne(updatedRate);
  }

  async deleteOne(rateId: Rate['id']): Promise<Rate> {
    return this.repository.deleteOne(rateId);
  }

  async updateOne(rate: UpdateRateModel, userId: string): Promise<Rate> {
    const exists = await this.repository.byId(rate.id);
    if (!exists)
      throwHttpErrorNotFound(`Unable to find rate with id: ${rate.id}`);

    const updatedRate = {
      ...rate,
      modifiedBy: userId,
      isActive: rate.isActive === undefined ? true : rate.isActive,
    };

    return this.repository.updateOne(updatedRate);
  }
}
