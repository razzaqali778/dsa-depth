import {
  IsBoolean,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class Rate {
  id: string;
  name: string;
  hourlyRate: number;
  isActive: boolean;
  modifiedBy: string;
  calendarId: string;
}

export class DbRate {
  id: string;
  name: string;
  hourlyRate: string;
  isActive: boolean;
  modifiedBy: string;
  calendarId: string;
}

export class CreateRateModel {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsNumber()
  @IsNotEmpty()
  hourlyRate: number;

  @IsString()
  @IsNotEmpty()
  calendarId: string;

  @IsBoolean()
  @IsNotEmpty()
  isActive: boolean;

  @IsString()
  @IsNotEmpty()
  modifiedBy: string;
}

export class UpdateRateModel {
  @IsString()
  @IsNotEmpty()
  id: string;

  @IsString()
  @IsNotEmpty()
  name: string;

  @IsNumber()
  @IsNotEmpty()
  hourlyRate: number;

  @IsString()
  @IsNotEmpty()
  calendarId: string;

  @IsBoolean()
  @IsOptional()
  isActive: boolean;

  @IsString()
  @IsOptional()
  modifiedBy: string;
}
