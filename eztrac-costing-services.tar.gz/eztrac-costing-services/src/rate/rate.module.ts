import { Module } from '@nestjs/common';
import { RateRepository } from './rate.repository';
import { RateController } from './rate.controller';
import { RatesController } from './rates.controller';
import { RateService } from './rate.service';

@Module({
  controllers: [RateController, RatesController],
  providers: [RateRepository, RateService],
  exports: [RateService],
})
export class RateModule {}
