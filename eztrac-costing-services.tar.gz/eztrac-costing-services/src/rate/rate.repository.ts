import { Inject, Injectable } from '@nestjs/common';
import { Kysely } from 'kysely';
import { DB } from 'src/common/db/database';
import { PROVIDERS } from '../constants';
import { DbRate, Rate } from './entities/rate.entity';

@Injectable()
export class RateRepository {
  constructor(
    @Inject(PROVIDERS.database)
    private db: Kysely<DB>,
  ) {}

  getBaseQuery() {
    return this.db
      .selectFrom('rate')
      .select([
        'rate.rate_id as id',
        'rate.rate_name as name',
        'rate.hourly_rate as hourlyRate',
        'rate.is_active as isActive',
        'rate.modified_by as modifiedBy',
        'rate.calendar_id as calendarId',
      ]);
  }

  mapRate(rate: DbRate): Rate {
    return {
      ...rate,
      hourlyRate: Number(rate.hourlyRate),
    };
  }

  async getAll(isActive?: boolean): Promise<Rate[]> {
    let rates;
    if (isActive !== undefined) {
      rates = await this.getBaseQuery()
        .where('rate.is_active', '=', isActive)
        .execute();
    } else {
      rates = await this.getBaseQuery().execute();
    }
    return rates.map(this.mapRate);
  }

  async byId(id: string): Promise<Rate> {
    const rate = await this.getBaseQuery()
      .where('rate.rate_id', '=', id)
      .executeTakeFirst();

    if (rate) return this.mapRate(rate);
  }

  async byName(name: string): Promise<Rate> {
    const rate = await this.getBaseQuery()
      .where('rate.rate_name', '=', name)
      .executeTakeFirst();

    if (rate) return this.mapRate(rate);
  }

  async deleteOne(id: Rate['id']): Promise<Rate> {
    const toDelete = await this.byId(id);
    if (!toDelete) return;

    await this.db.deleteFrom('rate').where('rate.rate_id', '=', id).execute();

    return toDelete;
  }

  async createOrUpdateOne(rate: Rate): Promise<Rate> {
    const { name, hourlyRate, calendarId, isActive, modifiedBy, id } = rate;
    return this.mapRate(
      await this.db
        .insertInto('rate')
        .values({
          rate_id: id,
          rate_name: name,
          hourly_rate: hourlyRate,
          is_active: isActive,
          modified_by: modifiedBy,
          calendar_id: calendarId,
        })
        .returning([
          'rate.rate_id as id',
          'rate.rate_name as name',
          'rate.hourly_rate as hourlyRate',
          'rate.is_active as isActive',
          'rate.modified_by as modifiedBy',
          'rate.calendar_id as calendarId',
        ])
        .executeTakeFirst(),
    );
  }

  async updateOne(rate: Rate): Promise<Rate> {
    const { hourlyRate, calendarId, isActive, modifiedBy, id, name } = rate;

    return this.mapRate(
      await this.db
        .updateTable('rate')
        .set({
          rate_name: name,
          hourly_rate: hourlyRate,
          is_active: isActive,
          modified_by: modifiedBy,
          calendar_id: calendarId,
        })
        .where('rate.rate_id', '=', id)
        .returning([
          'rate.rate_id as id',
          'rate.rate_name as name',
          'rate.hourly_rate as hourlyRate',
          'rate.is_active as isActive',
          'rate.modified_by as modifiedBy',
          'rate.calendar_id as calendarId',
        ])
        .executeTakeFirst(),
    );
  }
}
