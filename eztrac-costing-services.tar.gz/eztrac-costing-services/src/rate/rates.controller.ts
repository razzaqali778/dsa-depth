import {
  Body,
  Controller,
  Get,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { Roles } from '../common/roles/roles.decorator';
import { Role } from '../common/roles/roles.enum';
import { RolesGuard } from '../common/roles/roles.guard';
import { CreateRateModel } from './entities/rate.entity';
import { RateService } from './rate.service';

@Controller('rates')
export class RatesController {
  constructor(private readonly ratesService: RateService) {}

  @Get()
  getAll(@Query() query?) {
    const isActive = query?.isActive;
    return this.ratesService.getAll(isActive);
  }

  @Post()
  @UseGuards(RolesGuard)
  @Roles(Role.MANAGE_RATES)
  createOne(@Body() newRate: CreateRateModel, @Req() req) {
    return this.ratesService.createOrUpdateOne(newRate, req.user);
  }
}
