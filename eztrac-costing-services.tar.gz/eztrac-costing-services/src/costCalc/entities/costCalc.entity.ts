import { Type } from 'class-transformer';
import {
  IsArray,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  ValidateNested,
} from 'class-validator';
import { CalendarHours } from 'src/calendar/entities/calendar.entity';
import { CostGroup } from 'src/costGroup/entities/costGroup.entity';
import { Engagement } from 'src/engagement/entities/engagement.entity';
import { Person } from 'src/person/entities/person.entity';
import { Rate } from 'src/rate/entities/rate.entity';

export interface EffortCostingResult {
  teamId: string;
  timeFrameId: bigint;
  teamMemberCosts: CostGroupCost[];
}

export interface CostErrorsResponse {
  errors: string[];
  data: CostGroupCost[];
}

export class ParticipantModel {
  @IsString()
  @IsNotEmpty()
  userId: string;

  @IsNumber()
  @IsNotEmpty()
  percent: number;
}

export class GenericParticipantModel {
  @IsNumber()
  @IsNotEmpty()
  numberOfPeople: number;

  @IsString()
  @IsNotEmpty()
  rateId: string;

  @IsString()
  @IsNotEmpty()
  costGroupId: string;
}

export class EffortEngagementModel {
  @IsString()
  @IsNotEmpty()
  engagementId: string;

  @IsNumber()
  @IsNotEmpty()
  amount: number;
}

export class EffortCostingBodyModel {
  @IsString()
  @IsNotEmpty()
  teamId: string;

  @IsNumber()
  @IsNotEmpty()
  timeFrameId: number;

  @IsArray()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => ParticipantModel)
  participants?: ParticipantModel[];

  @IsArray()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => GenericParticipantModel)
  genericParticipants?: GenericParticipantModel[];

  @IsArray()
  @IsOptional()
  @ValidateNested({ each: true })
  @Type(() => EffortEngagementModel)
  engagements?: EffortEngagementModel[];
}

export interface MappedMonthlyRate {
  rateId: Rate['id'];
  isActive: Rate['isActive'];
  timeFrameId: CalendarHours['timeFrameId'];
  employeeMonthlyRate: number;
  contractorMonthlyRate: number;
  blendedMonthlyRate: number;
}

export interface CostGroupCost {
  costGroupId: CostGroup['id'];
  cost: number;
  engagementId?: Engagement['id'];
  personId?: Person['personId'];
}
