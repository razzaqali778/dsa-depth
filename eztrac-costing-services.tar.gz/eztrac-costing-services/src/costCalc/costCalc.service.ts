import { Injectable } from '@nestjs/common';
import { PersonService } from '../person/person.service';
import { CalendarService } from '../calendar/calendar.service';
import { CostGroupService } from '../costGroup/costGroup.service';
import { EngagementService } from '../engagement/engagement.service';
import { RateService } from '../rate/rate.service';
import {
  CostGroupCost,
  EffortCostingBodyModel,
} from './entities/costCalc.entity';
import { mapMonthlyRates } from './utils';
import { invalidDataResponse } from './validators';
import { specificPeopleCostGenerator } from './costGenerators/specificPeopleCostGenerator';
import { genericPeopleCostGenerator } from './costGenerators/genericPeopleCostGenerator';
import { engagementCostGenerator } from './costGenerators/engagementCostGenerator';

@Injectable()
export class CostCalcService {
  constructor(
    private readonly personService: PersonService,
    private readonly costGroupService: CostGroupService,
    private readonly rateService: RateService,
    private readonly calendarService: CalendarService,
    private readonly engagementService: EngagementService,
  ) {}

  async calculate(efforts: EffortCostingBodyModel[]): Promise<any[]> {
    const uniquePeopleIds = new Set<string>();
    const uniqueTimeFrameIds = new Set<number>();
    efforts.forEach((effort) => {
      effort.participants.forEach((participant) =>
        uniquePeopleIds.add(participant.userId),
      );
      uniqueTimeFrameIds.add(effort.timeFrameId);
    });

    const people = await this.personService.getAllSimpleByIds([
      ...uniquePeopleIds,
    ]);

    const calendarsForTimeFrames =
      await this.calendarService.getAllCalendarsByTimeFrames([
        ...uniqueTimeFrameIds,
      ]);

    const costGroups = await this.costGroupService.getAll();
    const rates = await this.rateService.getAll();
    const engagements = await this.engagementService.getAll();

    return efforts.map((effort) => {
      const mappedRates = mapMonthlyRates(
        rates,
        calendarsForTimeFrames,
        effort.timeFrameId,
      );

      const { errors: specificPeopleErrors, data: specificPeopleCosts } =
        specificPeopleCostGenerator(people, mappedRates, costGroups, effort);

      const { errors: genericPeopleErrors, data: genericParticipantsCosts } =
        genericPeopleCostGenerator(mappedRates, costGroups, effort);

      const allErrors = [...specificPeopleErrors, ...genericPeopleErrors];

      const engagementsCosts = engagementCostGenerator(engagements, effort);

      const costs: CostGroupCost[] = specificPeopleCosts
        .concat(genericParticipantsCosts)
        .concat(engagementsCosts)
        .filter(Boolean)
        .filter((c) => c.cost && c.cost > 0);

      // todo: send all errors to teams channel? previously it was send to slack
      console.info(allErrors.length && invalidDataResponse(effort, allErrors));

      return {
        teamId: effort.teamId,
        timeFrameId: effort.timeFrameId,
        teamMemberCosts: costs,
      };
    });
  }
}
