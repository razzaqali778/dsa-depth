import {
  Body,
  Controller,
  HttpCode,
  ParseArrayPipe,
  Post,
} from '@nestjs/common';
import { CostCalcService } from './costCalc.service';
import { EffortCostingBodyModel } from './entities/costCalc.entity';

@Controller('cost-calc')
export class CostCalcController {
  constructor(private readonly costCalcService: CostCalcService) {}

  @Post('/effort')
  @HttpCode(200)
  calculate(
    @Body(new ParseArrayPipe({ items: EffortCostingBodyModel }))
    efforts: EffortCostingBodyModel[],
  ) {
    return this.costCalcService.calculate(efforts);
  }
}
