import { CostGroup } from 'src/costGroup/entities/costGroup.entity';
import { PersonSimple } from 'src/person/entities/person.entity';
import {
  CostErrorsResponse,
  EffortCostingBodyModel,
  MappedMonthlyRate,
} from '../entities/costCalc.entity';
import { UNDEFINED_GROUP } from '../constants';
import { validateParticipant } from '../validators';
import { findMatchingRate } from '../utils';

export const specificPeopleCostGenerator = (
  peopleMap: PersonSimple[],
  rateMap: MappedMonthlyRate[],
  costGroups: CostGroup[],
  effort: EffortCostingBodyModel,
): CostErrorsResponse => {
  if (!effort.participants || !effort.participants.length)
    return { data: [], errors: [] };

  let errors = [];

  const data = effort.participants.map((participant) => {
    const matchingPerson: PersonSimple | undefined = peopleMap.find(
      (p) => p.id === participant.userId,
    );
    const participantErrors = validateParticipant({
      participant,
      person: matchingPerson,
      rateMap,
      costGroups,
    });
    errors = errors.concat(participantErrors);

    const rate = findMatchingRate(
      rateMap,
      matchingPerson?.rateId,
      effort.timeFrameId,
    );
    const monthlyRate = matchingPerson?.isEmployee
      ? rate.employeeMonthlyRate
      : rate.contractorMonthlyRate;
    const cost = {
      costGroupId: matchingPerson?.costGroupId || UNDEFINED_GROUP,
      cost: Math.floor((monthlyRate * participant.percent) / 100),
      personId: matchingPerson?.id,
    };

    return cost;
  });

  return {
    errors: errors.filter((e) => e),
    data,
  };
};
