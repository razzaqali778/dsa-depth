import { Engagement } from 'src/engagement/entities/engagement.entity';
import { UNDEFINED_GROUP } from '../constants';
import {
  CostGroupCost,
  EffortCostingBodyModel,
} from '../entities/costCalc.entity';

export const engagementCostGenerator = (
  engagementMap: Engagement[],
  effort: EffortCostingBodyModel,
): CostGroupCost[] => {
  if (!effort.engagements || !effort.engagements.length) return [];
  return effort.engagements.map((engagement) => {
    const costGroupId =
      engagementMap.find((e) => e.id === engagement.engagementId)
        ?.costGroupId || UNDEFINED_GROUP;
    return {
      costGroupId,
      cost: engagement.amount,
      engagementId: engagement.engagementId,
    };
  });
};
