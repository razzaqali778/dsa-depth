import { CostGroup } from 'src/costGroup/entities/costGroup.entity';
import {
  MappedMonthlyRate,
  EffortCostingBodyModel,
  CostErrorsResponse,
} from '../entities/costCalc.entity';
import { validateGenericParticipant } from '../validators';
import { findMatchingRate } from '../utils';
import { GENERIC_PERSON_ID } from '../constants';

export const genericPeopleCostGenerator = (
  rateMap: MappedMonthlyRate[],
  costGroups: CostGroup[],
  effort: EffortCostingBodyModel,
): CostErrorsResponse => {
  if (!effort.genericParticipants || !effort.genericParticipants.length)
    return { data: [], errors: [] };
  let errors = [];
  const data = effort.genericParticipants.map((genericParticipant) => {
    const participantErrors = validateGenericParticipant({
      genericParticipant,
      rateMap,
      costGroups,
    });
    errors = errors.concat(participantErrors);

    const rate = findMatchingRate(
      rateMap,
      genericParticipant.rateId,
      effort.timeFrameId,
    );
    return {
      costGroupId: genericParticipant.costGroupId,
      cost: Math.floor(
        rate.blendedMonthlyRate * genericParticipant.numberOfPeople,
      ),
      personId: GENERIC_PERSON_ID,
    };
  });

  return {
    errors: errors.filter((e) => e),
    data,
  };
};
