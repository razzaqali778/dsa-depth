import { Person, PersonSimple } from 'src/person/entities/person.entity';
import { NameToId } from 'src/utils';
import {
  createCostGroup,
  createGenericParticipant,
  createParticipant,
  createPerson,
  createRate,
} from 'test-utils/data-utils';
import { mapMonthlyRates } from '../utils';
import {
  invalidGenericParticipantCostGroup,
  invalidGenericParticipantRate,
  invalidParticipantPercent,
  invalidPersonCostGroup,
  invalidPersonRate,
  validateGenericParticipant,
  validateParticipant,
} from '../validators';

describe('Cost Calc validators test', () => {
  const PARTICIPANT_TEST_ID = 15;
  const PARTICIPANT_TEST_RATE_ID = 10;
  const PARTICIPANT_TEST_COST_GROUP_ID = 20;
  const genericParticipant = createGenericParticipant(
    20,
    PARTICIPANT_TEST_RATE_ID,
    PARTICIPANT_TEST_COST_GROUP_ID,
  );
  const participant = createParticipant(PARTICIPANT_TEST_ID.toString(), 70);
  const participantWrongPercent = createParticipant(
    PARTICIPANT_TEST_ID.toString(),
    -70,
  );

  const person: Person = createPerson(
    PARTICIPANT_TEST_ID,
    `cost_group_name_${PARTICIPANT_TEST_COST_GROUP_ID}`,
    `rate_name_${PARTICIPANT_TEST_RATE_ID}`,
  );
  const personSimple: PersonSimple = {
    ...person,
    id: person.personId,
    name: person.personName,
    rateId: NameToId(person.rateName),
    costGroupId: NameToId(person.costGroupName),
  };

  const matchingActiveRate = mapMonthlyRates(
    [createRate(PARTICIPANT_TEST_RATE_ID, 20, true)],
    [],
  );
  const matchingInActiveRate = mapMonthlyRates(
    [createRate(PARTICIPANT_TEST_RATE_ID, 20, false)],
    [],
  );
  const invalidRate = mapMonthlyRates([createRate(40, 20, true)], []);

  const matchingActiveCostGroup = createCostGroup(
    PARTICIPANT_TEST_COST_GROUP_ID,
    true,
  );
  const matchingInactiveCostGroup = createCostGroup(
    PARTICIPANT_TEST_COST_GROUP_ID,
    false,
  );
  const invalidCostGroup = createCostGroup(60, true);

  describe('validateGenericParticipant', () => {
    it('should return no errors when provided data is ok', () => {
      const response = validateGenericParticipant({
        genericParticipant,
        rateMap: matchingActiveRate,
        costGroups: [matchingActiveCostGroup],
      });
      expect(response).toEqual([]);
    });

    it('should return proper errors when person rate and cost group are matching but not active', () => {
      const response = validateGenericParticipant({
        genericParticipant,
        rateMap: matchingInActiveRate,
        costGroups: [matchingInactiveCostGroup],
      });
      expect(response).toEqual([
        invalidGenericParticipantRate(`RATE-NAME-${PARTICIPANT_TEST_RATE_ID}`),
        invalidGenericParticipantCostGroup(
          `COST-GROUP-NAME-${PARTICIPANT_TEST_COST_GROUP_ID}`,
        ),
      ]);
    });

    it('should return proper errors when person rate and cost group are not existing', () => {
      const response = validateGenericParticipant({
        genericParticipant,
        rateMap: invalidRate,
        costGroups: [invalidCostGroup],
      });
      expect(response).toEqual([
        invalidGenericParticipantRate(`RATE-NAME-${PARTICIPANT_TEST_RATE_ID}`),
        invalidGenericParticipantCostGroup(
          `COST-GROUP-NAME-${PARTICIPANT_TEST_COST_GROUP_ID}`,
        ),
      ]);
    });
  });

  describe('validateParticipant', () => {
    it('should return no errors when provided data is ok', () => {
      const response = validateParticipant({
        participant,
        person: personSimple,
        rateMap: matchingActiveRate,
        costGroups: [matchingActiveCostGroup],
      });
      expect(response).toEqual([]);
    });

    it('should return proper errors when provided user has invalid percent', () => {
      const response = validateParticipant({
        participant: participantWrongPercent,
        person: personSimple,
        rateMap: matchingActiveRate,
        costGroups: [matchingActiveCostGroup],
      });
      expect(response).toEqual([
        invalidParticipantPercent(participantWrongPercent),
      ]);
    });

    it('should return proper errors when person rate and cost group are matching but not active', () => {
      const response = validateParticipant({
        participant,
        person: personSimple,
        rateMap: matchingInActiveRate,
        costGroups: [matchingInactiveCostGroup],
      });
      expect(response).toEqual([
        invalidPersonRate(personSimple),
        invalidPersonCostGroup(personSimple),
      ]);
    });

    it('should return proper errors when person rate and cost group are not existing', () => {
      const response = validateParticipant({
        participant,
        person: personSimple,
        rateMap: invalidRate,
        costGroups: [invalidCostGroup],
      });
      expect(response).toEqual([
        invalidPersonRate(personSimple),
        invalidPersonCostGroup(personSimple),
      ]);
    });
  });
});
