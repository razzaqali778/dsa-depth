import { Test, TestingModule } from '@nestjs/testing';
import { testData } from 'test-utils/data-seed';
import { CostCalcController } from '../costCalc.controller';
import { EffortCostingBodyModel } from '../entities/costCalc.entity';

describe('CostCalcController', () => {
  let controller: CostCalcController;

  const request: EffortCostingBodyModel = {
    teamId: 'testTeamId',
    timeFrameId: 3,
    participants: [
      {
        userId: testData.peoples[0].personId,
        percent: 50,
      },
    ],
    genericParticipants: [
      {
        numberOfPeople: 20,
        rateId: testData.rates[0].id,
        costGroupId: testData.costGroups[0].id,
      },
    ],
    engagements: [
      {
        engagementId: testData.engagements[0].id,
        amount: 15,
      },
    ],
  };

  const response = {
    teamId: request.teamId,
    timeFrameId: Number(request.timeFrameId),
    teamMemberCosts: [],
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CostCalcController],
    })
      .useMocker(() => ({
        calculate: jest.fn().mockResolvedValue([response]),
      }))
      .compile();

    controller = module.get<CostCalcController>(CostCalcController);
  });

  it('getAll', async () => {
    const result = await controller.calculate([request]);
    expect(result.length).toBeDefined();
    expect(result).toHaveLength(1);
    expect(result).toEqual([response]);
  });
});
