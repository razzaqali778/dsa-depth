import { Person, PersonSimple } from 'src/person/entities/person.entity';
import { NameToId } from 'src/utils';
import {
  createCostGroup,
  createEngagement,
  createGenericParticipant,
  createParticipant,
  createPerson,
  createRate,
} from 'test-utils/data-utils';
import {
  EffortCostingBodyModel,
  EffortEngagementModel,
} from '../entities/costCalc.entity';
import { mapMonthlyRates } from '../utils';
import {
  invalidGenericParticipantCostGroup,
  invalidGenericParticipantRate,
  invalidPersonCostGroup,
  invalidPersonRate,
} from '../validators';
import { genericPeopleCostGenerator } from '../costGenerators/genericPeopleCostGenerator';
import { specificPeopleCostGenerator } from '../costGenerators/specificPeopleCostGenerator';
import { engagementCostGenerator } from '../costGenerators/engagementCostGenerator';
import { GENERIC_PERSON_ID } from '../constants';

describe('Cost Calc cost Generators test', () => {
  const PARTICIPANT_TEST_ID = 15;
  const PARTICIPANT_TEST_RATE_ID = 10;
  const PARTICIPANT_TEST_COST_GROUP_ID = 20;
  const TEST_ENGAGEMENT_ID = 50;

  const genericParticipant = createGenericParticipant(
    20,
    PARTICIPANT_TEST_RATE_ID,
    PARTICIPANT_TEST_COST_GROUP_ID,
  );
  const participant = createParticipant(
    `PERSON-NAME-${PARTICIPANT_TEST_ID}`,
    70,
  );

  const person: Person = createPerson(
    PARTICIPANT_TEST_ID,
    `cost_group_name_${PARTICIPANT_TEST_COST_GROUP_ID}`,
    `rate_name_${PARTICIPANT_TEST_RATE_ID}`,
  );
  const personSimple: PersonSimple = {
    ...person,
    id: person.personId,
    name: person.personName,
    rateId: NameToId(person.rateName),
    costGroupId: NameToId(person.costGroupName),
  };

  const matchingActiveRate = mapMonthlyRates(
    [createRate(PARTICIPANT_TEST_RATE_ID, 20, true)],
    [],
  );
  const matchingInActiveRate = mapMonthlyRates(
    [createRate(PARTICIPANT_TEST_RATE_ID, 20, false)],
    [],
  );

  const matchingActiveCostGroup = createCostGroup(
    PARTICIPANT_TEST_COST_GROUP_ID,
    true,
  );
  const matchingInactiveCostGroup = createCostGroup(
    PARTICIPANT_TEST_COST_GROUP_ID,
    false,
  );

  const testEffortEngagement: EffortEngagementModel = {
    engagementId: `${TEST_ENGAGEMENT_ID}`,
    amount: 100,
  };
  const testEngagement = createEngagement(TEST_ENGAGEMENT_ID, '15');

  describe('specificPeopleCostGenerator', () => {
    const testEffort: EffortCostingBodyModel = {
      teamId: 'team',
      timeFrameId: 2,
      participants: [participant],
    };
    it('should map properly when proper data provided', () => {
      const response = specificPeopleCostGenerator(
        [personSimple],
        matchingActiveRate,
        [matchingActiveCostGroup],
        testEffort,
      );
      expect(response).toEqual({
        data: [
          {
            cost: 2240,
            costGroupId: matchingActiveCostGroup.id,
            personId: personSimple.id,
          },
        ],
        errors: [],
      });
    });

    it('should return with errors when inactive data provided', () => {
      const response = specificPeopleCostGenerator(
        [personSimple],
        matchingInActiveRate,
        [matchingInactiveCostGroup],
        testEffort,
      );
      expect(response).toEqual({
        data: [
          {
            cost: 2240,
            costGroupId: matchingActiveCostGroup.id,
            personId: personSimple.id,
          },
        ],
        errors: [
          invalidPersonRate(personSimple),
          invalidPersonCostGroup(personSimple),
        ],
      });
    });

    it('should return empty when no participants in effort', () => {
      const response = specificPeopleCostGenerator(
        [personSimple],
        matchingInActiveRate,
        [matchingInactiveCostGroup],
        { ...testEffort, participants: undefined },
      );
      expect(response).toEqual({
        data: [],
        errors: [],
      });
    });
  });

  describe('genericPeopleCostGenerator', () => {
    const testEffort: EffortCostingBodyModel = {
      teamId: 'team',
      timeFrameId: 2,
      genericParticipants: [genericParticipant],
    };
    it('should map properly when proper data provided', () => {
      const response = genericPeopleCostGenerator(
        matchingActiveRate,
        [matchingActiveCostGroup],
        testEffort,
      );
      expect(response).toEqual({
        data: [
          {
            cost: 64000,
            costGroupId: matchingActiveCostGroup.id,
            personId: GENERIC_PERSON_ID,
          },
        ],
        errors: [],
      });
    });

    it('should return with errors when inactive data provided', () => {
      const response = genericPeopleCostGenerator(
        matchingInActiveRate,
        [matchingInactiveCostGroup],
        testEffort,
      );
      expect(response).toEqual({
        data: [
          {
            cost: 64000,
            costGroupId: matchingActiveCostGroup.id,
            personId: GENERIC_PERSON_ID,
          },
        ],
        errors: [
          invalidGenericParticipantRate(genericParticipant.rateId),
          invalidGenericParticipantCostGroup(genericParticipant.costGroupId),
        ],
      });
    });

    it('should return empty when no generic participants in effort', () => {
      const response = genericPeopleCostGenerator(
        matchingInActiveRate,
        [matchingInactiveCostGroup],
        { ...testEffort, genericParticipants: undefined },
      );
      expect(response).toEqual({
        data: [],
        errors: [],
      });
    });
  });

  describe('engagementCostGenerator', () => {
    const testEffort: EffortCostingBodyModel = {
      teamId: 'team',
      timeFrameId: 2,
      engagements: [testEffortEngagement],
    };
    it('should map properly when proper data provided', () => {
      const response = engagementCostGenerator([testEngagement], testEffort);
      expect(response).toEqual([
        {
          cost: 100,
          costGroupId: 'UNKNOWN-COST-GROUP',
          engagementId: `${TEST_ENGAGEMENT_ID}`,
        },
      ]);
    });

    it('should return empty when no engagements in effort', () => {
      const response = engagementCostGenerator([testEngagement], {
        ...testEffort,
        engagements: undefined,
      });
      expect(response).toEqual([]);
    });
  });
});
