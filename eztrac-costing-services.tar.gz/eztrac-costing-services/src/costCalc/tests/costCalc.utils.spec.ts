import { createCalendarHours, createRate } from 'test-utils/data-utils';
import { calculateMonthlyRate, mapMonthlyRates } from '../utils';

describe('Cost Calc utils test', () => {
  describe('calculateMonthlyRate', () => {
    it('should return proper data when all needed numbers provided', () => {
      const data = {
        hourlyRate: 5,
        employeeHours: 10,
        contractorHours: 15,
      };
      const response = calculateMonthlyRate(...Object.values(data));
      expect(response).toEqual({
        employeeMonthlyRate: data.hourlyRate * data.employeeHours,
        contractorMonthlyRate: data.hourlyRate * data.contractorHours,
        blendedMonthlyRate:
          (data.hourlyRate * (data.contractorHours + data.employeeHours)) / 2,
      });
    });

    it('should return proper data when all not all needed numbers provided', () => {
      const testEmployeeHours = 15;
      const response = calculateMonthlyRate(undefined, testEmployeeHours);
      expect(response).toEqual({
        employeeMonthlyRate: 100 * testEmployeeHours,
        contractorMonthlyRate: 100 * 160,
        blendedMonthlyRate: (100 * (160 + testEmployeeHours)) / 2,
      });
    });
  });

  describe('mapMonthlyRates', () => {
    it('should map properly when all data available', () => {
      const CALENDAR_ID = 5;
      const rates = [createRate(15, 20, false, CALENDAR_ID)];
      const calendars = [createCalendarHours(CALENDAR_ID, 10, 20)];
      const response = mapMonthlyRates(rates, calendars);
      const expectedResponse = {
        rateId: rates[0].id,
        isActive: rates[0].isActive,
        timeFrameId: calendars[0].timeFrameId,
        employeeMonthlyRate: rates[0].hourlyRate * calendars[0].employeeHours,
        contractorMonthlyRate:
          rates[0].hourlyRate * calendars[0].contractorHours,
        blendedMonthlyRate:
          (rates[0].hourlyRate *
            (calendars[0].employeeHours + calendars[0].contractorHours)) /
          2,
      };

      expect(response[0]).toEqual(expectedResponse);
    });

    it('should map properly when all data available', () => {
      const rates = [createRate(15, 20, false, 7)];
      const calendars = [createCalendarHours(5, 10, 20)];
      const response = mapMonthlyRates(rates, calendars);
      const expectedResponse = {
        rateId: rates[0].id,
        isActive: rates[0].isActive,
        timeFrameId: undefined,
        employeeMonthlyRate: rates[0].hourlyRate * 160,
        contractorMonthlyRate: rates[0].hourlyRate * 160,
        blendedMonthlyRate: (rates[0].hourlyRate * (160 + 160)) / 2,
      };

      expect(response[0]).toEqual(expectedResponse);
    });
  });
});
