import { CalendarHours } from '../calendar/entities/calendar.entity';
import { Rate } from '../rate/entities/rate.entity';
import { DEFAULT_HOUR_EMPLOYEE_VALUES } from './constants';
import {
  EffortCostingBodyModel,
  MappedMonthlyRate,
} from './entities/costCalc.entity';

export const calculateMonthlyRate = (
  hourlyRate: number = DEFAULT_HOUR_EMPLOYEE_VALUES.hourlyRate,
  employeeHours: number = DEFAULT_HOUR_EMPLOYEE_VALUES.hours,
  contractorHours: number = DEFAULT_HOUR_EMPLOYEE_VALUES.hours,
) => ({
  employeeMonthlyRate: hourlyRate * employeeHours,
  contractorMonthlyRate: hourlyRate * contractorHours,
  blendedMonthlyRate: (hourlyRate * (contractorHours + employeeHours)) / 2,
});

export const mapMonthlyRates = (
  rates: Rate[],
  calendars: CalendarHours[],
  timeFrameId?: EffortCostingBodyModel['timeFrameId'],
): MappedMonthlyRate[] =>
  rates.map((rate) => {
    const matchingTimeFrame = calendars.find(
      (calendar) =>
        calendar.calendarId === rate.calendarId &&
        (timeFrameId ? calendar.timeFrameId === timeFrameId : true),
    );
    return {
      rateId: rate.id,
      isActive: rate.isActive,
      timeFrameId: matchingTimeFrame?.timeFrameId,
      ...calculateMonthlyRate(
        rate.hourlyRate,
        matchingTimeFrame?.employeeHours,
        matchingTimeFrame?.contractorHours,
      ),
    };
  });

export const findMatchingRate = (
  rates: MappedMonthlyRate[],
  rateId: string,
  timeFrameId: number,
) =>
  rates.find(
    (rate) =>
      rate.rateId === rateId &&
      (rate.timeFrameId ? Number(timeFrameId) === rate.timeFrameId : true),
  ) || calculateMonthlyRate();
