import { Module } from '@nestjs/common';
import { CostCalcController } from './costCalc.controller';
import { CostCalcService } from './costCalc.service';
import { CalendarsModule } from '../calendar/calendar.module';
import { CostGroupModule } from '../costGroup/costGroup.module';
import { EngagementModule } from '../engagement/engagement.module';
import { PersonModule } from '../person/person.module';
import { RateModule } from '../rate/rate.module';

@Module({
  controllers: [CostCalcController],
  providers: [CostCalcService],
  imports: [
    CalendarsModule,
    CostGroupModule,
    EngagementModule,
    PersonModule,
    RateModule,
  ],
})
export class CostCalcModule {}
