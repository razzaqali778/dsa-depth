import { CostGroup } from 'src/costGroup/entities/costGroup.entity';
import { Person, PersonSimple } from 'src/person/entities/person.entity';
import {
  EffortCostingBodyModel,
  GenericParticipantModel,
  MappedMonthlyRate,
  ParticipantModel,
} from './entities/costCalc.entity';

export const userNotFoundMsg = (participantId: Person['personId']) =>
  `User ${participantId} was not found`;
export const invalidParticipantPercent = (participant: ParticipantModel) =>
  `User ${participant.userId} has an invalid participation percentage of ${participant.percent}`;
export const invalidPersonRate = (person: PersonSimple) =>
  `User ${person.id} has rate ${person.rateId} which is inactive or missing`;
export const invalidPersonCostGroup = (person: PersonSimple) =>
  `User ${person.id} has cost group ${person.costGroupId} which is inactive or missing`;

export const invalidGenericParticipantPercent = (percent: number) =>
  `A generic participant has an invalid participation percentage of ${percent}`;
export const invalidGenericParticipantRate = (rateId: string) =>
  `A generic participant has rate ${rateId} which is inactive or missing`;
export const invalidGenericParticipantCostGroup = (costGroupId: string) =>
  `A generic participant has cost group ${costGroupId} which is inactive or missing`;

export const invalidDataResponse = (
  effort: EffortCostingBodyModel,
  errors: string[],
) =>
  `The effort of team ${effort.teamId} in time frame ${
    effort.timeFrameId
  } had the following errors ... \n ${errors.join(' \n')}`;

const validateIfPersonExists = (person: PersonSimple, participantId: string) =>
  !person && userNotFoundMsg(participantId);

const validateParticipationPct = (
  percent: ParticipantModel['percent'],
  message: string,
) => {
  if (percent <= 0) return message;
  return;
};

const validateRate = (
  personRate: PersonSimple['rateId'],
  rateMap: MappedMonthlyRate[],
  message: string,
) => {
  const existing = rateMap.find((rate) => rate.rateId === personRate);
  if (!existing || !existing.isActive) return message;
  return;
};

const validateCostGroup = (
  personCostGroup: PersonSimple['costGroupId'],
  costGroups: CostGroup[],
  message: string,
) => {
  const existing = costGroups.find(
    (costGroup) => costGroup.id === personCostGroup,
  );

  if (!existing || !existing.isActive) return message;
  return;
};

export const validateGenericParticipant = ({
  genericParticipant,
  rateMap,
  costGroups,
}: {
  genericParticipant: GenericParticipantModel;
  rateMap: MappedMonthlyRate[];
  costGroups: CostGroup[];
}) => {
  const errors = [];
  errors.push(
    validateParticipationPct(
      genericParticipant.numberOfPeople,
      invalidGenericParticipantPercent(genericParticipant.numberOfPeople),
    ),
  );
  errors.push(
    validateRate(
      genericParticipant.rateId,
      rateMap,
      invalidGenericParticipantRate(genericParticipant.rateId),
    ),
  );
  errors.push(
    validateCostGroup(
      genericParticipant.costGroupId,
      costGroups,
      invalidGenericParticipantCostGroup(genericParticipant.costGroupId),
    ),
  );
  return errors.filter(Boolean);
};

export const validateParticipant = ({
  participant,
  person,
  rateMap,
  costGroups,
}: {
  participant: ParticipantModel;
  person?: PersonSimple;
  rateMap: MappedMonthlyRate[];
  costGroups: CostGroup[];
}) => {
  const errors = [];

  errors.push(validateIfPersonExists(person, participant.userId));
  errors.push(
    validateParticipationPct(
      participant.percent,
      invalidParticipantPercent(participant),
    ),
  );

  person &&
    errors.push(
      validateRate(person.rateId, rateMap, invalidPersonRate(person)),
    );
  person &&
    errors.push(
      validateCostGroup(
        person.costGroupId,
        costGroups,
        invalidPersonCostGroup(person),
      ),
    );
  return errors.filter(Boolean);
};
