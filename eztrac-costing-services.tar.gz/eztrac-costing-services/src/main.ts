import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { json } from 'express';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.setGlobalPrefix('v1', { exclude: ['ping'] });
  app.use(json({ limit: '50mb' }));

  const config = new DocumentBuilder()
    .setTitle('EZ-Trac costing services')
    .setDescription('EZ-Trac Cost Calculations Engine')
    .setVersion('1.0')
    .addTag('costing-services')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document);

  app.useGlobalPipes(new ValidationPipe());

  const port = parseInt(process.env.PORT || '3000', 10);
  await app.listen(port);
}

bootstrap();
