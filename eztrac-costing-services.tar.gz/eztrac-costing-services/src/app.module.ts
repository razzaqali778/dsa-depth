import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AuditsModule } from './audits/audits.module';
import { CommonModule } from './common/common.module';
import { CalendarsModule } from './calendar/calendar.module';
import { PersonModule } from './person/person.module';
import { CostGroupModule } from './costGroup/costGroup.module';
import { EngagementModule } from './engagement/engagement.module';
import { RateModule } from './rate/rate.module';
import { CostCalcModule } from './costCalc/costCalc.module';

@Module({
  imports: [
    AuditsModule,
    CommonModule,
    CostGroupModule,
    CalendarsModule,
    EngagementModule,
    RateModule,
    PersonModule,
    CostCalcModule,
  ],
  controllers: [AppController],
})
export class AppModule {}
