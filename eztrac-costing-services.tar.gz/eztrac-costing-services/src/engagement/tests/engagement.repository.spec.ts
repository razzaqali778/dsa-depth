import { Test, TestingModule } from '@nestjs/testing';
import { EngagementRepository } from '../engagement.repository';
import { setupTestDb } from 'test-utils/setup-test-db';
import { CommonModule } from '../../common/common.module';
import { testData } from 'test-utils/data-seed';
import { Engagement } from '../entities/engagement.entity';
import { PROVIDERS } from 'src/constants';
import { createEngagement } from 'test-utils/data-utils';

describe('EngagementService', () => {
  let service: EngagementRepository;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [CommonModule],
      providers: [EngagementRepository],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    service = module.get<EngagementRepository>(EngagementRepository);
  });

  it('should return all ', async () => {
    const expected = testData.engagements;

    const data: Engagement[] = await service.getAll();
    expect(data).toHaveLength(expected.length);
    expect(data).toEqual(expected);
  });

  it('should return all inactive', async () => {
    const data: Engagement[] = await service.getAll(false);
    data.forEach((d) => {
      expect(d.isActive).toEqual(false);
    });
  });

  it('should return all active', async () => {
    const data: Engagement[] = await service.getAll(true);
    data.forEach((d) => {
      expect(d.isActive).toEqual(true);
    });
  });

  it('should return by id', async () => {
    const data: Engagement = await service.byId(testData.engagements[0].id);
    expect(data).toBeDefined();
    expect(data.id).toEqual(testData.engagements[0].id);
  });

  it('should return by name', async () => {
    const data: Engagement = await service.byName(testData.engagements[0].name);
    expect(data).toBeDefined();
    expect(data.name).toEqual(testData.engagements[0].name);
  });

  it('should create new engagement', async () => {
    const beforeAdd: Engagement[] = await service.getAll(false);
    const newCostGroup = createEngagement(15, testData.costGroups[3].id, false);
    const data: Engagement = await service.createOrUpdateOne(newCostGroup);
    const afterAdd: Engagement[] = await service.getAll(false);

    expect(data).toBeDefined();
    expect(data).toEqual(newCostGroup);
    expect(afterAdd).toHaveLength(beforeAdd.length + 1);
  });

  it('should update existing engagement', async () => {
    const beforeAdd: Engagement[] = await service.getAll(true);
    const modifiedCostGroup = {
      ...testData.engagements[0],
      purchaseOrder: 'test',
    };
    const data: Engagement = await service.updateOne(modifiedCostGroup);
    const afterAdd: Engagement[] = await service.getAll(true);

    expect(data).toBeDefined();
    expect(data.purchaseOrder).toEqual('test');
    expect(afterAdd).toHaveLength(beforeAdd.length);
  });
});
