import { Test, TestingModule } from '@nestjs/testing';
import { testData } from 'test-utils/data-seed';
import { createEngagement } from 'test-utils/data-utils';
import { EngagementsController } from '../engagements.controller';
import { EngagementController } from '../engagement.controller';
import { Engagement } from '../entities/engagement.entity';

describe('EngagementController', () => {
  let controller: EngagementsController;
  let controllerSingle: EngagementController;

  const expectedEngagements: Engagement[] = testData.engagements;
  const newEngagement: Engagement = createEngagement(
    10,
    testData.costGroups[3].id,
    true,
  );

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [EngagementController, EngagementsController],
    })
      .useMocker(() => ({
        getAll: jest.fn().mockResolvedValue(expectedEngagements),
        createOrUpdateOne: jest.fn().mockResolvedValue(newEngagement),
        updateOne: jest.fn().mockResolvedValue(newEngagement),
      }))
      .compile();

    controller = module.get<EngagementsController>(EngagementsController);
    controllerSingle = module.get<EngagementController>(EngagementController);
  });

  it('getAll', async () => {
    const result = await controller.getAll();
    expect(result).toEqual(expectedEngagements);
  });

  it('createOne', async () => {
    const result = await controller.createOne(newEngagement, { user: 'user' });
    expect(result).toEqual(newEngagement);
  });

  it('update', async () => {
    const result = await controllerSingle.update(
      { ...testData.engagements[0], purchaseOrder: 'new one' },
      { user: 'user' },
    );
    expect(result).toBeDefined();
  });
});
