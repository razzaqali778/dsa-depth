import { Inject, Injectable } from '@nestjs/common';
import { Kysely } from 'kysely';
import { DB } from 'src/common/db/database';
import { PROVIDERS } from '../constants';
import { Engagement } from './entities/engagement.entity';

@Injectable()
export class EngagementRepository {
  constructor(
    @Inject(PROVIDERS.database)
    private db: Kysely<DB>,
  ) {}
  getBaseQuery() {
    return this.db
      .selectFrom('engagement')
      .select([
        'engagement.engagement_id as id',
        'engagement.engagement_name as name',
        'engagement_purchase_order as purchaseOrder',
        'cost_group_id as costGroupId',
        'engagement.is_active as isActive',
        'engagement.modified_by as modifiedBy',
      ]);
  }
  async getAll(isActive?: boolean): Promise<Engagement[]> {
    let baseQuery = this.getBaseQuery();

    if (isActive !== undefined)
      baseQuery = baseQuery.where('engagement.is_active', '=', isActive);
    return baseQuery.execute();
  }

  async byId(id: string): Promise<Engagement> {
    return this.getBaseQuery()
      .where('engagement.engagement_id', '=', id)
      .executeTakeFirst();
  }

  async byName(name: string): Promise<Engagement> {
    return this.getBaseQuery()
      .where('engagement.engagement_name', '=', name)
      .executeTakeFirst();
  }

  async deleteOne(id: Engagement['id']): Promise<Engagement> {
    const toDelete = await this.byId(id);
    if (!toDelete) return;

    await this.db
      .deleteFrom('engagement')
      .where('engagement.engagement_id', '=', id)
      .execute();

    return toDelete;
  }

  async createOrUpdateOne(engagement: Engagement): Promise<Engagement> {
    const { name, costGroupId, isActive, modifiedBy, purchaseOrder, id } =
      engagement;
    return this.db
      .insertInto('engagement')
      .values({
        engagement_id: id,
        engagement_name: name,
        cost_group_id: costGroupId,
        is_active: isActive,
        modified_by: modifiedBy,
        engagement_purchase_order: purchaseOrder,
      })
      .returning([
        'engagement.engagement_id as id',
        'engagement.engagement_name as name',
        'engagement_purchase_order as purchaseOrder',
        'cost_group_id as costGroupId',
        'engagement.is_active as isActive',
        'engagement.modified_by as modifiedBy',
      ])
      .executeTakeFirst();
  }

  async updateOne(engagement: Engagement): Promise<Engagement> {
    const { costGroupId, isActive, modifiedBy, purchaseOrder, id, name } =
      engagement;

    return this.db
      .updateTable('engagement')
      .set({
        engagement_name: name,
        cost_group_id: costGroupId,
        is_active: isActive,
        modified_by: modifiedBy,
        engagement_purchase_order: purchaseOrder,
      })
      .where('engagement.engagement_id', '=', id)
      .returning([
        'engagement.engagement_id as id',
        'engagement.engagement_name as name',
        'engagement_purchase_order as purchaseOrder',
        'cost_group_id as costGroupId',
        'engagement.is_active as isActive',
        'engagement.modified_by as modifiedBy',
      ])
      .executeTakeFirst();
  }
}
