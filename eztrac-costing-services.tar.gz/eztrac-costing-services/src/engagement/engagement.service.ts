import { Injectable } from '@nestjs/common';
import { NameToId } from '../utils';
import { EngagementRepository } from './engagement.repository';
import {
  CreateEngagementLessModel,
  CreateEngagementModel,
  Engagement,
} from './entities/engagement.entity';
import {
  throwHttpErrorBadRequest,
  throwHttpErrorNotFound,
} from '../httpErrorUtils';
import { CostGroupService } from '../costGroup/costGroup.service';

@Injectable()
export class EngagementService {
  constructor(
    private repository: EngagementRepository,
    private readonly costGroupService: CostGroupService,
  ) {}
  async getAll(isActive?: boolean): Promise<Engagement[]> {
    return this.repository.getAll(isActive);
  }

  async createOrUpdateOne(
    newEngagement: CreateEngagementModel,
    userId: string,
  ): Promise<Engagement> {
    const updatedEngagement = {
      ...newEngagement,
      id: NameToId(newEngagement.name),
      modifiedBy: userId,
    };
    const exists = await this.repository.byId(updatedEngagement.id);
    if (exists) {
      throwHttpErrorBadRequest(
        `Engagement with provided name: ${updatedEngagement.name} already exists`,
      );
    }
    await this.costGroupService.getById(newEngagement.costGroupId);

    return this.repository.createOrUpdateOne(updatedEngagement);
  }

  async deleteOne(engagementId: Engagement['id']): Promise<Engagement> {
    return this.repository.deleteOne(engagementId);
  }

  async updateOne(
    engagement: CreateEngagementLessModel,
    userId: string,
  ): Promise<Engagement> {
    const exists = await this.repository.byId(engagement.id);
    if (!exists)
      throwHttpErrorNotFound(
        `Unable to find engagement with id: ${engagement.id}`,
      );

    const updatedEngagement = {
      ...engagement,
      modifiedBy: userId,
      isActive: engagement.isActive !== undefined ? engagement.isActive : true,
    };

    return this.repository.updateOne(updatedEngagement);
  }
}
