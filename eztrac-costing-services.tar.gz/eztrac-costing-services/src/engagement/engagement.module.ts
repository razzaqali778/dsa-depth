import { Module } from '@nestjs/common';
import { EngagementRepository } from './engagement.repository';
import { EngagementController } from './engagement.controller';
import { EngagementsController } from './engagements.controller';
import { EngagementService } from './engagement.service';
import { CostGroupModule } from '../costGroup/costGroup.module';

@Module({
  controllers: [EngagementController, EngagementsController],
  providers: [EngagementRepository, EngagementService],
  exports: [EngagementService],
  imports: [CostGroupModule],
})
export class EngagementModule {}
