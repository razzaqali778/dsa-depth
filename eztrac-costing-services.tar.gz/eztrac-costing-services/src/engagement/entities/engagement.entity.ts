import { IsBoolean, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class Engagement {
  id: string;
  name: string;
  purchaseOrder: string;
  costGroupId: string;
  isActive: boolean;
  modifiedBy: string;
}

export class CreateEngagementModel {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  costGroupId: string;

  @IsString()
  @IsNotEmpty()
  purchaseOrder: string;

  @IsBoolean()
  @IsNotEmpty()
  isActive: boolean;

  @IsString()
  @IsNotEmpty()
  modifiedBy: string;
}

export class CreateEngagementLessModel {
  @IsString()
  @IsNotEmpty()
  id: string;

  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  costGroupId: string;

  @IsString()
  @IsNotEmpty()
  purchaseOrder: string;

  @IsBoolean()
  @IsOptional()
  isActive: boolean;

  @IsString()
  @IsOptional()
  modifiedBy: string;
}
