import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { Roles } from '../common/roles/roles.decorator';
import { Role } from '../common/roles/roles.enum';
import { RolesGuard } from '../common/roles/roles.guard';
import { EngagementService } from './engagement.service';
import { CreateEngagementModel } from './entities/engagement.entity';

@Controller('engagements')
export class EngagementsController {
  constructor(private readonly engagementService: EngagementService) {}

  @Get()
  getAll(@Query() query?) {
    const isActive = query?.isActive;
    return this.engagementService.getAll(isActive);
  }

  @Post()
  @UseGuards(RolesGuard)
  @Roles(Role.MANAGE_ENGAGEMENTS)
  createOne(@Body() newEngagement: CreateEngagementModel, @Req() req) {
    return this.engagementService.createOrUpdateOne(newEngagement, req.user);
  }

  @Delete('/delete/:id')
  @UseGuards(RolesGuard)
  @Roles(Role.MANAGE_ENGAGEMENTS)
  deleteOne(@Param('id') engagementId) {
    return this.engagementService.deleteOne(engagementId);
  }
}
