import { Body, Controller, Put, Req, UseGuards } from '@nestjs/common';
import { RolesGuard } from '../common/roles/roles.guard';
import { Roles } from '../common/roles/roles.decorator';
import { Role } from '../common/roles/roles.enum';
import { EngagementService } from './engagement.service';
import { CreateEngagementLessModel } from './entities/engagement.entity';

@UseGuards(RolesGuard)
@Controller('engagement')
export class EngagementController {
  constructor(private readonly engagementService: EngagementService) {}

  @Put('/:id')
  @Roles(Role.MANAGE_ENGAGEMENTS)
  update(@Body() engagement: CreateEngagementLessModel, @Req() req) {
    return this.engagementService.updateOne(engagement, req.user);
  }
}
