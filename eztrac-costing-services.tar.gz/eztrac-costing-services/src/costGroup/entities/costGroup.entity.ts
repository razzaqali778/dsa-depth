import { IsBoolean, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class CostGroup {
  id: string;
  name: string;
  costCenter: string;
  isActive: boolean;
  modifiedBy: string;
  excludeFromDistributions: boolean;
}

export class CreateCostGroupModel {
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  costCenter: string;

  @IsBoolean()
  @IsNotEmpty()
  isActive: boolean;

  @IsString()
  @IsNotEmpty()
  modifiedBy: string;

  @IsBoolean()
  @IsNotEmpty()
  excludeFromDistributions: boolean;
}

export class UpdateCostGroupModel {
  @IsString()
  @IsNotEmpty()
  id: string;

  @IsString()
  @IsNotEmpty()
  name: string;

  @IsString()
  @IsNotEmpty()
  costCenter: string;

  @IsBoolean()
  @IsNotEmpty()
  isActive: boolean;

  @IsString()
  @IsOptional()
  modifiedBy: string;

  @IsBoolean()
  @IsOptional()
  excludeFromDistributions: boolean;
}
