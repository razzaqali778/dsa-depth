import { Inject, Injectable } from '@nestjs/common';
import { Kysely } from 'kysely';
import { DB } from 'src/common/db/database';
import { PROVIDERS } from '../constants';
import { CostGroup } from './entities/costGroup.entity';

@Injectable()
export class CostGroupRepository {
  constructor(
    @Inject(PROVIDERS.database)
    private db: Kysely<DB>,
  ) {}
  getBaseQuery() {
    return this.db
      .selectFrom('cost_group')
      .select([
        'cost_group.cost_center as costCenter',
        'cost_group.cost_group_id as id',
        'cost_group.cost_group_name as name',
        'cost_group.exclude_from_distributions as excludeFromDistributions',
        'cost_group.is_active as isActive',
        'cost_group.modified_by as modifiedBy',
      ]);
  }
  async getAll(isActive?: boolean): Promise<CostGroup[]> {
    let baseQuery = this.getBaseQuery();
    if (isActive !== undefined)
      baseQuery = baseQuery.where('cost_group.is_active', '=', isActive);
    return baseQuery.execute();
  }

  async byId(id: string): Promise<CostGroup> {
    return this.getBaseQuery()
      .where('cost_group.cost_group_id', '=', id)
      .executeTakeFirst();
  }

  async byName(name: string): Promise<CostGroup> {
    return this.getBaseQuery()
      .where('cost_group.cost_group_name', '=', name)
      .executeTakeFirst();
  }

  async deleteOne(costGroupId: CostGroup['id']): Promise<CostGroup> {
    const toDelete = await this.byId(costGroupId);
    if (!toDelete) return;

    await this.db
      .deleteFrom('cost_group')
      .where('cost_group_id', '=', costGroupId)
      .executeTakeFirst();

    return toDelete;
  }

  async createOrUpdateOne(costGroup: CostGroup): Promise<CostGroup> {
    const {
      name,
      costCenter,
      isActive,
      modifiedBy,
      excludeFromDistributions,
      id,
    } = costGroup;
    return this.db
      .insertInto('cost_group')
      .values({
        cost_group_id: id,
        cost_group_name: name,
        cost_center: costCenter,
        is_active: isActive,
        modified_by: modifiedBy,
        exclude_from_distributions: excludeFromDistributions,
      })
      .returning([
        'cost_group.cost_center as costCenter',
        'cost_group.cost_group_id as id',
        'cost_group.cost_group_name as name',
        'cost_group.exclude_from_distributions as excludeFromDistributions',
        'cost_group.is_active as isActive',
        'cost_group.modified_by as modifiedBy',
      ])
      .executeTakeFirst();
  }

  async updateOne(costGroup: CostGroup): Promise<CostGroup> {
    const {
      costCenter,
      isActive,
      modifiedBy,
      excludeFromDistributions,
      id,
      name,
    } = costGroup;

    return this.db
      .updateTable('cost_group')
      .set({
        cost_group_name: name,
        is_active: isActive,
        exclude_from_distributions: excludeFromDistributions,
        modified_by: modifiedBy,
        cost_center: costCenter,
      })
      .where('cost_group.cost_group_id', '=', id)
      .returning([
        'cost_group.cost_center as costCenter',
        'cost_group.cost_group_id as id',
        'cost_group.cost_group_name as name',
        'cost_group.exclude_from_distributions as excludeFromDistributions',
        'cost_group.is_active as isActive',
        'cost_group.modified_by as modifiedBy',
      ])
      .executeTakeFirst();
  }
}
