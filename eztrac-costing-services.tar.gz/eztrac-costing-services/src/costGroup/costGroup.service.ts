import { Injectable } from '@nestjs/common';
import { NameToId } from '../utils';
import { CostGroupRepository } from './costGroup.repository';
import {
  CostGroup,
  UpdateCostGroupModel,
  CreateCostGroupModel,
} from './entities/costGroup.entity';
import {
  throwHttpErrorBadRequest,
  throwHttpErrorNotFound,
} from '../httpErrorUtils';

@Injectable()
export class CostGroupService {
  constructor(private repository: CostGroupRepository) {}
  async getAll(isActive?: boolean): Promise<CostGroup[]> {
    return this.repository.getAll(isActive);
  }

  async createOrUpdateOne(
    newCostGroup: CreateCostGroupModel,
    userId: string,
  ): Promise<CostGroup> {
    const updatedCostGroup = {
      ...newCostGroup,
      id: NameToId(newCostGroup.name),
      excludeFromDistributions: !!newCostGroup.excludeFromDistributions,
      modifiedBy: userId,
    };
    const exists = await this.repository.byId(updatedCostGroup.id);
    if (exists) {
      throwHttpErrorBadRequest(
        `Cost group with provided name: ${updatedCostGroup.name} already exists`,
      );
    }
    return this.repository.createOrUpdateOne(updatedCostGroup);
  }

  async deleteOne(costGroupId: CostGroup['id']): Promise<CostGroup> {
    return this.repository.deleteOne(costGroupId);
  }

  async updateOne(
    costGroup: UpdateCostGroupModel,
    userId: string,
  ): Promise<CostGroup> {
    const exists = await this.repository.byId(costGroup.id);
    if (!exists)
      throwHttpErrorNotFound(
        `Unable to find cost group with name: ${costGroup.name}`,
      );
    const updatedCostGroup = {
      ...costGroup,
      id: exists.id,
      modifiedBy: userId,
    };
    return this.repository.updateOne(updatedCostGroup);
  }

  async getByName(costGroupName: string): Promise<CostGroup> {
    const exists = await this.repository.byName(costGroupName);
    if (!exists)
      throwHttpErrorNotFound(
        `Unable to find cost group with name: ${costGroupName}`,
      );
    return exists;
  }

  async getById(costGroupId: string): Promise<CostGroup> {
    const exists = await this.repository.byId(costGroupId);
    if (!exists)
      throwHttpErrorNotFound(
        `Unable to find cost group with id: ${costGroupId}`,
      );
    return exists;
  }
}
