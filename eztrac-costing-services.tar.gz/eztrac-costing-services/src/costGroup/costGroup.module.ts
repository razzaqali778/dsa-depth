import { Module } from '@nestjs/common';
import { CostGroupRepository } from './costGroup.repository';
import { CostGroupController } from './costGroup.controller';
import { CostGroupsController } from './costGroups.controller';
import { CostGroupService } from './costGroup.service';

@Module({
  controllers: [CostGroupController, CostGroupsController],
  providers: [CostGroupRepository, CostGroupService],
  exports: [CostGroupService],
})
export class CostGroupModule {}
