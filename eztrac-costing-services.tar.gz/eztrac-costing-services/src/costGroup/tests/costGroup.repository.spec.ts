import { Test, TestingModule } from '@nestjs/testing';
import { CostGroupRepository } from '../costGroup.repository';
import { setupTestDb } from '../../../test-utils/setup-test-db';
import { PROVIDERS } from '../../constants';
import { CommonModule } from '../../common/common.module';
import { CostGroup } from '../entities/costGroup.entity';
import { testData } from 'test-utils/data-seed';
import { createCostGroup } from 'test-utils/data-utils';

describe('CostGroupService', () => {
  let service: CostGroupRepository;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [CommonModule],
      providers: [CostGroupRepository],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    service = module.get<CostGroupRepository>(CostGroupRepository);
  });

  it('should return all ', async () => {
    const expected = testData.costGroups;

    const data: CostGroup[] = await service.getAll();
    expect(data).toHaveLength(expected.length);
    expect(data).toEqual(expected);
  });

  it('should return all inactive', async () => {
    const data: CostGroup[] = await service.getAll(false);
    data.forEach((d) => {
      expect(d.isActive).toEqual(false);
    });
  });

  it('should return all active', async () => {
    const data: CostGroup[] = await service.getAll(true);
    data.forEach((d) => {
      expect(d.isActive).toEqual(true);
    });
  });

  it('should return by id', async () => {
    const data: CostGroup = await service.byId(testData.costGroups[0].id);
    expect(data).toBeDefined();
    expect(data.id).toEqual(testData.costGroups[0].id);
  });

  it('should return by name', async () => {
    const data: CostGroup = await service.byName(testData.costGroups[0].name);
    expect(data).toBeDefined();
    expect(data.name).toEqual(testData.costGroups[0].name);
  });

  it('should create new cost group', async () => {
    const beforeAdd: CostGroup[] = await service.getAll(false);
    const newCostGroup = createCostGroup(15, false);
    const data: CostGroup = await service.createOrUpdateOne(newCostGroup);
    const afterAdd: CostGroup[] = await service.getAll(false);

    expect(data).toBeDefined();
    expect(data).toEqual(newCostGroup);
    expect(afterAdd).toHaveLength(beforeAdd.length + 1);
  });
});
