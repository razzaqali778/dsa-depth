import { Test, TestingModule } from '@nestjs/testing';
import { testData } from 'test-utils/data-seed';
import { createCostGroup } from 'test-utils/data-utils';
import { CostGroupController } from '../costGroup.controller';
import { CostGroupsController } from '../costGroups.controller';
import { CostGroup } from '../entities/costGroup.entity';

describe('CostGroupController', () => {
  let controller: CostGroupsController;
  let controllerSingle: CostGroupController;
  const expectedCostGroups: CostGroup[] = testData.costGroups;
  const newCostGroup: CostGroup = createCostGroup(15, false, true);

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CostGroupsController, CostGroupController],
    })
      .useMocker(() => ({
        getAll: jest.fn().mockResolvedValue(expectedCostGroups),
        createOrUpdateOne: jest.fn().mockResolvedValue(newCostGroup),
        updateOne: jest.fn().mockResolvedValue(newCostGroup),
      }))
      .compile();

    controller = module.get<CostGroupsController>(CostGroupsController);
    controllerSingle = module.get<CostGroupController>(CostGroupController);
  });

  it('getAll', async () => {
    const result = await controller.getAll();
    expect(result).toEqual(expectedCostGroups);
  });

  it('createOne', async () => {
    const result = await controller.createOrUpdateOne(newCostGroup, {
      user: 'user',
    });
    expect(result).toEqual(newCostGroup);
  });

  it('update', async () => {
    const result = await controllerSingle.update(
      { ...testData.costGroups[0], costCenter: 'TEST' },
      { user: 'user' },
    );
    expect(result).toBeDefined();
  });
});
