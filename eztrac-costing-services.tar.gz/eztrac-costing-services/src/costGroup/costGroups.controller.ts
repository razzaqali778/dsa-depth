import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { Roles } from '../common/roles/roles.decorator';
import { Role } from '../common/roles/roles.enum';
import { RolesGuard } from '../common/roles/roles.guard';
import { CostGroupService } from './costGroup.service';
import { CreateCostGroupModel } from './entities/costGroup.entity';

@Controller('costGroups')
export class CostGroupsController {
  constructor(private readonly costGroupService: CostGroupService) {}

  @Get()
  getAll(@Query() query?) {
    const isActive = query?.isActive;
    return this.costGroupService.getAll(isActive);
  }

  @Post()
  @UseGuards(RolesGuard)
  @Roles(Role.MANAGE_COST_GROUPS)
  createOrUpdateOne(@Body() newCostGroup: CreateCostGroupModel, @Req() req) {
    return this.costGroupService.createOrUpdateOne(newCostGroup, req.user);
  }

  @Delete('/delete/:id')
  @UseGuards(RolesGuard)
  @Roles(Role.MANAGE_COST_GROUPS)
  deleteOne(@Param('id') costGroupId) {
    return this.costGroupService.deleteOne(costGroupId);
  }
}
