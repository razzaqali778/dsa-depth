import { Body, Controller, Put, Req, UseGuards } from '@nestjs/common';
import { Roles } from '../common/roles/roles.decorator';
import { Role } from '../common/roles/roles.enum';
import { RolesGuard } from '../common/roles/roles.guard';
import { CostGroupService } from './costGroup.service';
import { UpdateCostGroupModel } from './entities/costGroup.entity';

@Controller('costGroup')
@UseGuards(RolesGuard)
export class CostGroupController {
  constructor(private readonly costGroupService: CostGroupService) {}

  @Put('/:id')
  @Roles(Role.MANAGE_COST_GROUPS)
  update(@Body() costGroup: UpdateCostGroupModel, @Req() req) {
    return this.costGroupService.updateOne(costGroup, req.user);
  }
}
