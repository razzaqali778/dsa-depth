export interface AuthRequestClient {
  request: (
    method: string,
    url: string,
    payload?: string | object,
  ) => Promise<any>;
}
