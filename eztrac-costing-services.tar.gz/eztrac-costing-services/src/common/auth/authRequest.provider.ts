import { ConfidentialClientApplication } from '@azure/msal-node';
import { PROVIDERS } from '../../constants';
import { Config } from '@monsantoit/config';
import { AuthRequestClient } from './authRequest.entity';
import agent from 'superagent';
import { Config as ConfigType } from '../config/config.entity';

const authRequestClient = (config: Config<ConfigType>): AuthRequestClient => {
  const clientId = config.get('oauth-client.id');
  const clientSecret = config.get('oauth-client.secret');
  const tenantId = config.get('oauth-client.tenant-id');

  if (!tenantId) {
    throw new Error('oauth-client.tenant-id is required for client-credential token acquisition');
  }

  // Reuse one CCA so MSAL's in-memory token cache survives across requests.
  const cca = new ConfidentialClientApplication({
    auth: {
      clientId,
      clientSecret,
      authority: `https://login.microsoftonline.com/${tenantId}`,
    },
  });

  const getToken = async () => {
    const result = await cca.acquireTokenByClientCredential({
      scopes: [`${clientId}/.default`],
    });

    if (!result?.accessToken) {
      throw new Error('Failed to acquire Azure AD access token');
    }

    return result.accessToken;
  };

  return {
    request: async (method: string, url: string, payload?: string | object) => {
      const token = await getToken();
      const request = agent(method, url).set('Authorization', `Bearer ${token}`);
      if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method.toUpperCase()))
        request.send(payload);
      return request;
    },
  };
};

export const authRequestProvider = {
  provide: PROVIDERS.authRequest,
  useFactory: async (config: Config<ConfigType>) =>
    await authRequestClient(config),
  inject: [PROVIDERS.config],
};
