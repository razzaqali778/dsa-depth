import type { ColumnType } from 'kysely';

export type Generated<T> =
  T extends ColumnType<infer S, infer I, infer U>
    ? ColumnType<S, I | undefined, U>
    : ColumnType<T, T | undefined, T>;

export type Int8 = ColumnType<
  string,
  string | number | bigint,
  string | number | bigint
>;

export type Json = ColumnType<JsonValue, string, string>;

export type JsonArray = JsonValue[];

export type JsonObject = {
  [K in string]?: JsonValue;
};

export type JsonPrimitive = boolean | null | number | string;

export type JsonValue = JsonArray | JsonObject | JsonPrimitive;

export type Numeric = ColumnType<string, string | number, string | number>;

export type Timestamp = ColumnType<Date, Date | string, Date | string>;

export interface Audit {
  entity_type: string;
  entity_key: string;
  modified_time: Timestamp;
  user_id: string;
  entity: Json;
}

export interface Calendar {
  calendar_id: string;
  calendar_name: string;
}

export interface CalendarTimeframeHours {
  calendar_id: string;
  timeframe_id: Int8;
  employee_hours: Numeric;
  contractor_hours: Numeric;
}

export interface CostGroup {
  cost_group_id: string;
  cost_group_name: string;
  cost_center: string;
  is_active: Generated<boolean>;
  modified_by: Generated<string>;
  exclude_from_distributions: Generated<boolean>;
}

export interface Engagement {
  engagement_id: string;
  engagement_name: string;
  cost_group_id: string;
  is_active: Generated<boolean>;
  modified_by: Generated<string>;
  engagement_purchase_order: string | null;
}

export interface Person {
  user_id: string;
  user_name: string;
  rate_id: string;
  cost_group_id: string;
  is_employee: Generated<boolean>;
  is_active: Generated<boolean>;
  modified_by: Generated<string>;
}

export interface Rate {
  rate_id: string;
  rate_name: string;
  hourly_rate: Int8;
  is_active: Generated<boolean>;
  modified_by: Generated<string>;
  calendar_id: Generated<string>;
}

export interface DB {
  audit: Audit;
  calendar: Calendar;
  calendar_timeframe_hours: CalendarTimeframeHours;
  cost_group: CostGroup;
  engagement: Engagement;
  person: Person;
  rate: Rate;
}
