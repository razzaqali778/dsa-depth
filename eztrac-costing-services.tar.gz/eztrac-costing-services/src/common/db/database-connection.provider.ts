import { PROVIDERS } from '../../constants';
import { Kysely, PostgresDialect } from 'kysely';
import { DB } from 'src/common/db/database';
import { Pool, PoolConfig } from 'pg';
import { Config } from '@monsantoit/config';
import { Config as ConfigType } from '../config/config.entity';

const MAX_REQUEST_DURATION = 10 * 60 * 1000;
const MAX_CLIENTS_COUNT = 200;
const CONNECTION_TIMEOUT = 50000;

const connectionConfig = (config: Config<ConfigType>): PoolConfig => {
  const credentials = config.get('costingDb');
  return {
    host: credentials.host,
    port: credentials.port,
    database: credentials.database,
    user: credentials.user,
    password: credentials.password,
    max: MAX_CLIENTS_COUNT,
    connectionTimeoutMillis: CONNECTION_TIMEOUT,
    idleTimeoutMillis: MAX_REQUEST_DURATION,
    ssl: credentials.ssl,
  };
};

const dbConnection = (config: Config<ConfigType>) =>
  new Kysely<DB>({
    dialect: new PostgresDialect({
      pool: new Pool(connectionConfig(config)),
    }),
  });

export const databaseConnectionProvider = {
  provide: PROVIDERS.database,
  useFactory: (config: Config<ConfigType>) => dbConnection(config),
  inject: [PROVIDERS.config],
};
