import defaultConfig = require('./default');

module.exports = {
  ...defaultConfig,
  'ez-trac-urls': {
    'ez-trac-core': 'eztrac core services local url',
  },
  costingDb: {
    ...defaultConfig['costingDb'],
    host: 'localhost',
    port: 5435,
  },
};
