import _ from 'lodash';
import defaultConfig = require('./default');

const inCI = process.argv.indexOf('--ci') > -1;

module.exports = _.merge(defaultConfig, {
  costingDb: {
    user: 'vault://secret/ez-trac/it/db/admin-user-name',
    password: 'vault://secret/ez-trac/it/db/admin-user-password',
    host: inCI ? 'vault://secret/ez-trac/it/db/host' : 'localhost',
    port: inCI ? 5432 : 5436,
    ssl: { rejectUnauthorized: false },
    database: 'CostingDb-IT',
  },
  'eztrac-approle': {
    role_name: 'workforce-dev-admins-eztrac-np',
  },
});
