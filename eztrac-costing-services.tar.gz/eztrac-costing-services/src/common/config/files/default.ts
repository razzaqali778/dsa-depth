import { Config } from '../config.entity';

const config: Config = {
  'oauth-client': {
    id: 'vault://secret/ez-trac/costing-services/np/oauth-azure/client-id',
    secret:
      'vault://secret/ez-trac/costing-services/np/oauth-azure/client-secret',
    // Same Bayer tenant previously defaulted by @monsantoit/oauth-azure.
    'tenant-id': 'fcb2b37b-5da0-466b-9b83-0014b67a7c78',
  },
  costingDb: {
    user: 'vault://secret/ez-trac/costing-services/np/db/app-user-name',
    password: 'vault://secret/ez-trac/costing-services/np/db/app-user-password',
    host: 'vault://secret/ez-trac/np/db/new-host',
    port: 5432,
    ssl: { rejectUnauthorized: false },
    database: 'vault://secret/ez-trac/costing-services/np/db/db-name',
  },
  'ez-trac-urls': {
    'ez-trac-core': 'https://ez-trac-core-services.velocity-np.ag',
  },
  'velocity-home': {
    value: 'velocity-np.ag',
  },
  'eztrac-approle': {
    role_name: '',
  },
};

module.exports = config;
