import defaultConfig = require('./default');
import merge from 'lodash/merge';

module.exports = merge(defaultConfig, {});
