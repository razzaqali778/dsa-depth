import merge from 'lodash/merge';
import npConfig = require('./fargate-np');

module.exports = merge(npConfig, {
  'oauth-client': {
    id: 'vault://secret/ez-trac/costing-services/prod/oauth-azure/client-id',
    secret:
      'vault://secret/ez-trac/costing-services/prod/oauth-azure/client-secret',
  },
  costingDb: {
    user: 'vault://secret/ez-trac/costing-services/prod/db/app-user-name',
    password:
      'vault://secret/ez-trac/costing-services/prod/db/app-user-password',
    host: 'vault://secret/ez-trac/prod/db/new-host',
    port: 5432,
    database: 'vault://secret/ez-trac/costing-services/prod/db/db-name',
  },
  'ez-trac-urls': {
    'ez-trac-core': 'https://ez-trac-core-services.velocity.ag',
  },
  'velocity-home': {
    value: 'velocity.ag',
  },
  'eztrac-approle': {
    role_name: 'workforce-dev-admins-eztrac-prod',
  },
});
