import { Config, source, processor, env } from '@monsantoit/config';
import { PROVIDERS } from '../../constants';
import { Config as ConfigType } from './config.entity';
import {
  determineEnvironmentFileName,
  isFargate,
} from '@monsantoit/config-velocity-store';
import fetchCA from '@monsantoit/fetch-rds-ca';

console.info(
  `NODE_ENV: ${process.env.NODE_ENV}, FARGATE_ENV: ${process.env.FARGATE_ENV}, isFargate: ${isFargate}`,
);

// Build in Jenkins/GHA/CodeBuild
const inCI = process.argv.indexOf('--ci') > -1;

const environmentFileName =
  process.env.NODE_ENV === 'production' && isFargate
    ? `${determineEnvironmentFileName()}`
    : `${process.env.CONFIG_ENV || process.env.NODE_ENV || 'default'}`;

console.info(
  `Configuration Environment - IsFargate: ${isFargate}, environmentFileName: ${environmentFileName}`,
);

const config = new Config<ConfigType>({
  sources: [
    source.fromJS({
      src: `${__dirname}/files/${environmentFileName || 'default'}`,
    }),
  ],
  processors: [
    processor.readVaultFromConfig({
      enabled: env.inDevelopment || (env.inIntegrationTest && !inCI),
      auth: { type: 'local' },
    }),
    processor.readVaultFromConfig({
      enabled: env.inIntegrationTest && inCI,
      auth: {
        type: 'appRole',
        roleId: process.env.APPROLE_ID,
        secretId: process.env.APPROLE_SECRET,
      },
    }),
    processor.readVaultFromConfig({
      enabled: env.inProduction,
      auth: {
        type: 'awsRole',
        roleName: { inConfig: 'eztrac-approle.role_name' },
      },
    }),
  ],
  required: [],
});

export const configProvider = {
  provide: PROVIDERS.config,
  useFactory: async () => {
    if (config.initalized) return config;
    await config.init();
    if (process.env.NODE_ENV === 'production') {
      const ca = await fetchCA();
      config.set('costingDb.ssl', { rejectUnauthorized: true, ca });
    }
    return config;
  },
};
