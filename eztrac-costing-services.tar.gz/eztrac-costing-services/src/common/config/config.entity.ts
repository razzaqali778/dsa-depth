export interface Config {
  'oauth-client': {
    id: string;
    secret: string;
    'tenant-id': string;
  };
  costingDb: {
    user: string;
    password: string;
    host: string;
    port: any;
    database: string;
    ssl: any;
  };
  'ez-trac-urls': {
    'ez-trac-core': string;
  };
  'velocity-home': {
    value: string;
  };
  'eztrac-approle': {
    role_name: string;
  };
}
