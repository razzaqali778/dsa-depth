import { Global, Module } from '@nestjs/common';
import { configProvider } from './config/config.provider';
import { databaseConnectionProvider } from './db/database-connection.provider';
import { papiClientProvider } from './papi/papi-client.provider';
import { entitlementsClientProvider } from './entitlements/entitlements.provider';
import { authRequestProvider } from './auth/authRequest.provider';

@Global()
@Module({
  providers: [
    configProvider,
    databaseConnectionProvider,
    authRequestProvider,
    papiClientProvider,
    entitlementsClientProvider,
  ],
  exports: [
    configProvider,
    databaseConnectionProvider,
    entitlementsClientProvider,
  ],
})
export class CommonModule {}
