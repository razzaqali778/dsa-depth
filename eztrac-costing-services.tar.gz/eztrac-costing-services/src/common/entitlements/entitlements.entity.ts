export type Entitlement = {
  application: {
    id: string;
  };
  code: string;
};

export interface EntitlementsClient {
  getUserEntitlements: (
    userId: string,
    appIds: [string],
  ) => Promise<Record<string, string[]>>;
}
