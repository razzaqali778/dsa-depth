import { PROVIDERS } from '../../constants';
import { PapiClient } from '../papi/papi-client.entity';
import { Entitlement, EntitlementsClient } from './entitlements.entity';
import groupBy from 'lodash/groupBy';

export const entitlementsClient = (
  papiClient: PapiClient,
): EntitlementsClient => ({
  getUserEntitlements: async (userId: string, appIds: [string]) => {
    if (!userId) {
      throw new Error('No valid userId provided');
    }

    const entitlementData = await papiClient.getEntitlementsForUser(
      userId,
      appIds,
    );

    const grouped = groupBy(
      entitlementData,
      (item: Entitlement) => item.application.id,
    );

    const entitlements: Record<string, string[]> = {};
    Object.keys(grouped).forEach((appCode: string) => {
      entitlements[`${appCode.toUpperCase()}`] = grouped[appCode].map(
        (ent: Entitlement) => ent.code.toUpperCase(),
      );
    });

    return entitlements;
  },
});

export const entitlementsClientProvider = {
  provide: PROVIDERS.entitlements,
  useFactory: async (papiClient: PapiClient) => entitlementsClient(papiClient),
  inject: [PROVIDERS.papiClient],
};
