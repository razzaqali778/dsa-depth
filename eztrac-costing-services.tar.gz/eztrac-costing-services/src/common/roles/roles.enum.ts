export enum Role {
  MANAGE_RATES = 'manage-rates',
  MANAGE_PEOPLE = 'manage-people',
  MANAGE_ENGAGEMENTS = 'manage-engagements',
  MANAGE_COST_GROUPS = 'manage-cost-groups',
}
