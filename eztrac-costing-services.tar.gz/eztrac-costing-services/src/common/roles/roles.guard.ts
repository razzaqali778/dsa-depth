import {
  Injectable,
  CanActivate,
  ExecutionContext,
  Inject,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PROVIDERS } from '../../constants';
import { Role } from './roles.enum';
import { ROLES_KEY } from './roles.decorator';
import * as appConfig from '../config/application.conf.json';
import { EntitlementsClient } from '../entitlements/entitlements.entity';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    @Inject(PROVIDERS.entitlements)
    private entitlementsClient: EntitlementsClient,
  ) {}

  async canActivate(context: ExecutionContext) {
    const request = context.switchToHttp().getRequest();
    const userId = request.headers['user-id'] as string;
    if (!userId) {
      return false;
    }
    request.user = userId;

    const requiredRoles = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    const appName = appConfig.authorization['entitlement-app-name'];
    const requiredEntitlements = [];

    requiredRoles.forEach((role) => {
      const roleEntitlements = (
        appConfig.authorization.contexts as Record<
          string,
          { entitlements: string[] }
        >
      )[role].entitlements;
      requiredEntitlements.push(...(roleEntitlements || []));
    });

    if (!requiredEntitlements) {
      return true;
    }

    const userEntitlements = await this.entitlementsClient.getUserEntitlements(
      userId,
      [appName],
    );

    if (
      !Object.keys(userEntitlements).length ||
      !requiredEntitlements.some((entitlement: string) => {
        return userEntitlements[appName.toUpperCase()].includes(
          entitlement.toUpperCase(),
        );
      })
    ) {
      return false;
    }

    return true;
  }
}
