import { Entitlement } from '../entitlements/entitlements.entity';

export interface GraphQLPayload {
  query: string;
  variables: object | undefined;
}

export interface PapiClient {
  getEntitlementsForUser: (
    userId: string,
    appIds: string[],
  ) => Promise<Entitlement[]>;
}
