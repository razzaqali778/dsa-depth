import { PROVIDERS } from '../../constants';
import { Response } from 'superagent';
import { Entitlement } from '../entitlements/entitlements.entity';
import { GraphQLPayload, PapiClient } from './papi-client.entity';
import { Config } from '@monsantoit/config';
import { AuthRequestClient } from '../auth/authRequest.entity';
import { Config as ConfigType } from '../config/config.entity';

const url = (config: Config<ConfigType>) =>
  `https://profile.${config.get('velocity-home.value')}/v3/graphql`;

const callGraphQl = (
  authRequestClient,
  config,
  payload: GraphQLPayload,
): Promise<Response> => {
  return authRequestClient.request('POST', url(config), payload);
};

export const papiClient = (
  config: Config<ConfigType>,
  authRequestClient: AuthRequestClient,
): PapiClient => ({
  getEntitlementsForUser: async (
    userId: string,
    appIds: string[],
  ): Promise<Entitlement[]> => {
    const query = `query($userId:String!, $appIds:[String!]!){
            entitlements: getEntitlementsForUser(userId: $userId,appIds:$appIds){
              code
              application{
                id
              }
            }
          }
        `;

    const { body } = await callGraphQl(authRequestClient, config, {
      query,
      variables: { userId, appIds },
    });
    return body.data.entitlements;
  },
});

export const papiClientProvider = {
  provide: PROVIDERS.papiClient,
  useFactory: async (
    config: Config<ConfigType>,
    authRequest: AuthRequestClient,
  ) => papiClient(config, authRequest),
  inject: [PROVIDERS.config, PROVIDERS.authRequest],
};
