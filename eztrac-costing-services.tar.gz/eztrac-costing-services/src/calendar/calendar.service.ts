import { Injectable } from '@nestjs/common';
import { CalendarRepository } from './calendar.repository';
import { Calendar, CalendarHours } from './entities/calendar.entity';

@Injectable()
export class CalendarService {
  constructor(private repository: CalendarRepository) {}
  async getAllCalendars(): Promise<Calendar[]> {
    return this.repository.getAllCalendars();
  }
  async getAllCalendarsHours(): Promise<CalendarHours[]> {
    return this.repository.getAllCalendarsHours();
  }
  async getAllCalendarsByTimeFrames(
    timeFrameIds: number[],
  ): Promise<CalendarHours[]> {
    return this.repository.getAllCalendarsByTimeFrames(timeFrameIds);
  }
}
