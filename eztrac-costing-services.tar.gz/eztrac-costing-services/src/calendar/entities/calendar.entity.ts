export class Calendar {
  calendarId: string;
  calendarName: string;
}

export class CalendarHours {
  calendarId: string;
  name: string;
  timeFrameId: number;
  employeeHours: number;
  contractorHours: number;
}
