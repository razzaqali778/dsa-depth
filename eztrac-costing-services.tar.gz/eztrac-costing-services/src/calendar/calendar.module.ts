import { Module } from '@nestjs/common';
import { CalendarRepository } from './calendar.repository';
import { CalendarController } from './calendar.controller';
import { CalendarService } from './calendar.service';

@Module({
  controllers: [CalendarController],
  providers: [CalendarRepository, CalendarService],
  exports: [CalendarService],
})
export class CalendarsModule {}
