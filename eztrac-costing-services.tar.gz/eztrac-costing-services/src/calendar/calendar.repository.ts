import { Inject, Injectable } from '@nestjs/common';
import { Kysely } from 'kysely';
import { DB } from 'src/common/db/database';
import { PROVIDERS } from '../constants';
import { Calendar, CalendarHours } from './entities/calendar.entity';

@Injectable()
export class CalendarRepository {
  constructor(
    @Inject(PROVIDERS.database)
    private db: Kysely<DB>,
  ) {}

  private getCalendarHoursQuery() {
    return this.db
      .selectFrom('calendar')
      .select([
        'calendar.calendar_id as calendarId',
        'calendar.calendar_name as name',
      ])
      .innerJoin(
        'calendar_timeframe_hours',
        'calendar.calendar_id',
        'calendar_timeframe_hours.calendar_id',
      )
      .select([
        'calendar_timeframe_hours.contractor_hours as contractorHours',
        'calendar_timeframe_hours.employee_hours as employeeHours',
        'calendar_timeframe_hours.timeframe_id as timeFrameId',
      ]);
  }

  async getAllCalendars(): Promise<Calendar[]> {
    return this.db
      .selectFrom('calendar')
      .select([
        'calendar.calendar_id as calendarId',
        'calendar.calendar_name as calendarName',
      ])
      .execute();
  }
  async getAllCalendarsHours(): Promise<CalendarHours[]> {
    const calendarHours = await this.getCalendarHoursQuery().execute();

    return calendarHours.map((calendarHour) => ({
      ...calendarHour,
      timeFrameId: Number(calendarHour.timeFrameId),
      employeeHours: Number(calendarHour.employeeHours),
      contractorHours: Number(calendarHour.contractorHours),
    }));
  }
  async getAllCalendarsByTimeFrames(
    timeFrameIds: number[],
  ): Promise<CalendarHours[]> {
    if (timeFrameIds.length === 0) return [];
    const calendarHours = await this.getCalendarHoursQuery()
      .where(
        'timeframe_id',
        'in',
        timeFrameIds.map((t) => t.toString()),
      )
      .execute();

    return calendarHours.map((calendarHour) => ({
      ...calendarHour,
      timeFrameId: Number(calendarHour.timeFrameId),
      employeeHours: Number(calendarHour.employeeHours),
      contractorHours: Number(calendarHour.contractorHours),
    }));
  }
}
