import { Controller, Get } from '@nestjs/common';
import { CalendarService } from './calendar.service';

@Controller('calendars')
export class CalendarController {
  constructor(private readonly calendarService: CalendarService) {}

  @Get()
  getAllCalendars() {
    return this.calendarService.getAllCalendars();
  }
  @Get('/hours')
  getAllCalendarsHours() {
    return this.calendarService.getAllCalendarsHours();
  }
}
