import { Test, TestingModule } from '@nestjs/testing';
import { CalendarRepository } from '../calendar.repository';
import { setupTestDb } from '../../../test-utils/setup-test-db';
import { PROVIDERS } from '../../constants';
import { CommonModule } from '../../common/common.module';
import { testData } from 'test-utils/data-seed';
import { Calendar, CalendarHours } from '../entities/calendar.entity';

describe('CalendarService', () => {
  let service: CalendarRepository;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [CommonModule],
      providers: [CalendarRepository],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    service = module.get<CalendarRepository>(CalendarRepository);
  });

  it('should return all calendars', async () => {
    const expected = testData.calendars;

    const calendars: Calendar[] = await service.getAllCalendars();

    expect(calendars).toHaveLength(expected.length);
    expect(calendars).toEqual(expected);
  });

  it('should return all calendars hours', async () => {
    const expected = testData.calendarTimeframeHours;

    const calendarHours: CalendarHours[] = await service.getAllCalendarsHours();

    expect(calendarHours).toHaveLength(expected.length);
    expect(calendarHours).toEqual(expected);
  });

  it('should return all calendars hours matching timeframeId', async () => {
    const expected = testData.calendarTimeframeHours[0];

    const calendarHours = await service.getAllCalendarsByTimeFrames([
      testData.calendarTimeframeHours[0].timeFrameId,
      123124,
    ]);
    expect(calendarHours).toHaveLength(1);
    expect(calendarHours[0]).toEqual(expected);
  });
});
