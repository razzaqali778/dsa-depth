import { Test, TestingModule } from '@nestjs/testing';
import {
  mapCalendarEntityToDbEntry,
  mapCalendarHoursEntityToDbEntry,
} from 'test-utils/data-mappers';
import { testData } from 'test-utils/data-seed';
import { CalendarController } from '../calendar.controller';

describe('CalendarController', () => {
  let controller: CalendarController;
  const expectedCalendars = mapCalendarEntityToDbEntry(testData.calendars);
  const expectedCalendarHours = mapCalendarHoursEntityToDbEntry(
    testData.calendarTimeframeHours,
  );

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CalendarController],
    })
      .useMocker(() => ({
        getAllCalendars: jest.fn().mockResolvedValue(expectedCalendars),
        getAllCalendarsHours: jest
          .fn()
          .mockResolvedValue(expectedCalendarHours),
      }))
      .compile();

    controller = module.get<CalendarController>(CalendarController);
  });

  it('getAllCalendars', async () => {
    const calendars = await controller.getAllCalendars();
    expect(calendars).toEqual(expectedCalendars);
  });

  it('getAllCalendarsHours', async () => {
    const calendarHours = await controller.getAllCalendarsHours();
    expect(calendarHours).toEqual(expectedCalendars);
  });
});
