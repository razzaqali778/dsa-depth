import { Test, TestingModule } from '@nestjs/testing';
import { testData } from 'test-utils/data-seed';
import { createPerson } from 'test-utils/data-utils';
import { Person } from '../entities/person.entity';
import { PeopleController } from '../people.controller';
import { PersonController } from '../person.controller';

describe('PersonController', () => {
  let controller: PeopleController;
  let controllerSingle: PersonController;

  const expectedPeople: Person[] = testData.peoples;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PersonController, PeopleController],
    })
      .useMocker(() => ({
        getAll: jest.fn().mockResolvedValue(expectedPeople),
        getByPersonId: jest.fn().mockResolvedValue(expectedPeople[0]),
        createOrUpdateOne: jest.fn().mockResolvedValue(expectedPeople[0]),
        updatePersonActiveStatus: jest
          .fn()
          .mockResolvedValue(expectedPeople[0]),
      }))
      .compile();

    controllerSingle = module.get<PersonController>(PersonController);
    controller = module.get<PeopleController>(PeopleController);
  });

  it('getAll', async () => {
    const result = await controller.getAll();
    expect(result.length).toBeDefined();
  });

  it('getSingle', async () => {
    const result = await controllerSingle.getSingle('/person');
    expect(result).toBeDefined();
    expect(result).toEqual(expectedPeople[0]);
  });

  it('createOne', async () => {
    const result = await controllerSingle.createOne(
      createPerson(
        11,
        testData.costGroups[2].name,
        testData.rates[2].name,
        true,
      ),
      'test_user',
    );
    expect(result).toBeDefined();
    expect(result).toEqual(expectedPeople[0]);
  });

  it('update active status', async () => {
    const result = await controllerSingle.updatePersonActiveStatus(
      'personId',
      { isActive: false },
      'test_user',
    );
    expect(result).toBeDefined();
    expect(result).toEqual(expectedPeople[0]);
  });
});
