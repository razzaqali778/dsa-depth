import { Test, TestingModule } from '@nestjs/testing';
import { PersonRepository } from '../person.repository';
import { setupTestDb } from '../../../test-utils/setup-test-db';
import { PROVIDERS } from '../../constants';
import { CommonModule } from '../../common/common.module';
import { testData } from 'test-utils/data-seed';
import { Person, PersonSimple } from '../entities/person.entity';
import { createPerson } from 'test-utils/data-utils';
import { NameToId } from 'src/utils';

describe('PersonService', () => {
  let service: PersonRepository;
  const allPeople = testData.peoples;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [CommonModule],
      providers: [PersonRepository],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    service = module.get<PersonRepository>(PersonRepository);
  });

  afterEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [CommonModule],
      providers: [PersonRepository],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    service = module.get<PersonRepository>(PersonRepository);
  });

  describe('getAll', () => {
    it('should return all ', async () => {
      const expected = testData.peoples;

      const data: Person[] = await service.getAll();
      expect(data).toHaveLength(expected.length);
      expect(data).toEqual(expect.arrayContaining(expected));
    });

    it('should return all inactive', async () => {
      const data: Person[] = await service.getAll(false);
      data.forEach((d) => {
        expect(d.isActive).toEqual(false);
      });
    });

    it('should return all active', async () => {
      const data: Person[] = await service.getAll(true);
      data.forEach((d) => {
        expect(d.isActive).toEqual(true);
      });
    });
  });

  describe('getAllByQuery', () => {
    it('should return all matching query ', async () => {
      const expected = testData.peoples;

      const data: Person[] = await service.getAllByQuery('erso');
      expect(data).toHaveLength(expected.length);
      expect(data).toEqual(expect.arrayContaining(expected));
      data.forEach((d) => {
        expect(d.personName).toContain('erso');
      });
    });

    it('should return empty when no match', async () => {
      const data: Person[] = await service.getAllByQuery('testing');
      expect(data).toHaveLength(0);
    });
  });

  describe('getAllByRateId', () => {
    it('should return all active', async () => {
      const data: Person[] = await service.getAllByRateId(
        testData.rates[2].id,
        true,
      );
      data.forEach((d) => {
        expect(d.rateName).toEqual(testData.rates[2].name);
        expect(d.isActive).toEqual(true);
      });
    });

    it('should return all inactive', async () => {
      const data: Person[] = await service.getAllByRateId(
        testData.rates[2].id,
        false,
      );
      data.forEach((d) => {
        expect(d.rateName).toEqual(testData.rates[2].name);
        expect(d.isActive).toEqual(false);
      });
    });

    it('should return empty when no match', async () => {
      const data: Person[] = await service.getAllByRateId(
        'invalid_rate',
        false,
      );
      expect(data).toHaveLength(0);
    });
  });

  describe('getAllSimpleByIds', () => {
    it('should return all by ids', async () => {
      const data: PersonSimple[] = await service.getAllSimpleByIds([
        testData.peoples[0].personId,
        testData.peoples[1].personId,
        'wrong',
      ]);

      const expectedPerson = testData.peoples[0];
      expect(data).toHaveLength(2);
      expect(data[0]).toEqual({
        id: expectedPerson.personId,
        name: expectedPerson.personName,
        costGroupId: NameToId(expectedPerson.costGroupName),
        rateId: NameToId(expectedPerson.rateName),
        isEmployee: expectedPerson.isEmployee,
        isActive: expectedPerson.isActive,
        modifiedBy: expectedPerson.modifiedBy,
      });
    });

    it('should return all inactive', async () => {
      const data: Person[] = await service.getAllByRateId(
        testData.rates[2].id,
        false,
      );
      data.forEach((d) => {
        expect(d.rateName).toEqual(testData.rates[2].name);
        expect(d.isActive).toEqual(false);
      });
    });

    it('should return empty when no match', async () => {
      const data: Person[] = await service.getAllByRateId(
        'invalid_rate',
        false,
      );
      expect(data).toHaveLength(0);
    });
  });

  describe('getAllByCostGroupId', () => {
    it('should return all active', async () => {
      const data: Person[] = await service.getAllByCostGroupId(
        testData.costGroups[2].id,
        true,
      );
      data.forEach((d) => {
        expect(d.costGroupName).toEqual(testData.costGroups[2].name);
        expect(d.isActive).toEqual(true);
      });
    });

    it('should return all inactive', async () => {
      const data: Person[] = await service.getAllByCostGroupId(
        testData.costGroups[2].id,
        false,
      );
      data.forEach((d) => {
        expect(d.costGroupName).toEqual(testData.costGroups[2].name);
        expect(d.isActive).toEqual(false);
      });
    });

    it('should return empty when no match', async () => {
      const data: Person[] = await service.getAllByCostGroupId(
        'invalid_cost_group',
        false,
      );
      expect(data).toHaveLength(0);
    });
  });

  describe('getById', () => {
    it('should return one when available', async () => {
      const data: Person = await service.getById(allPeople[0].personId);
      expect(data).toBeDefined();
      expect(data).toEqual(allPeople[0]);
    });

    it('should return empty when person not available', async () => {
      const data: Person[] = await service.getAllByCostGroupId(
        'not_existing',
        true,
      );
      expect(data).toEqual([]);
    });
  });

  describe('createOrUpdateOne', () => {
    it('should update person data', async () => {
      const before = await service.getById(allPeople[0].personId);
      const modifiedPerson = {
        ...allPeople[0],
        isActive: false,
        rateId: testData.rates[0].id,
        costGroupId: testData.costGroups[0].id,
      };
      const data: Person = await service.createOrUpdateOne(modifiedPerson);
      expect(data).toBeDefined();
      const after = await service.getById(allPeople[0].personId);

      expect(before.costGroupName).not.toEqual(after.costGroupName);
      expect(before.rateName).not.toEqual(after.rateName);

      expect(after.rateName).toEqual(testData.rates[0].name);
      expect(after.costGroupName).toEqual(testData.costGroups[0].name);
      expect(after.isActive).toEqual(modifiedPerson.isActive);
    });

    it('should create person if person does not exist', async () => {
      const newPerson = {
        ...createPerson(
          20,
          testData.costGroups[2].name,
          testData.rates[2].name,
          true,
          false,
        ),
        rateId: testData.rates[2].id,
        costGroupId: testData.costGroups[2].id,
      };
      const before = await service.getById(newPerson.personId);
      expect(before).toEqual(undefined);

      const data: Person = await service.createOrUpdateOne(newPerson);
      expect(data).toBeDefined();
      const after = await service.getById(newPerson.personId);

      expect(after.personId).toEqual(newPerson.personId);
      expect(after.personName).toEqual(newPerson.personName);
      expect(after.rateName).toEqual(testData.rates[2].name);
      expect(after.costGroupName).toEqual(testData.costGroups[2].name);
      expect(after.isActive).toEqual(newPerson.isActive);
    });
  });

  describe('updatePerson', () => {
    it('should update person active status ', async () => {
      const before = await service.getById(allPeople[0].personId);
      const modifiedPerson = {
        ...allPeople[0],
        isActive: !allPeople[0].isActive,
        modifiedBy: 'testUser',
      };
      const data: Person = await service.updatePerson(modifiedPerson);
      expect(data).toBeDefined();
      const after = await service.getById(allPeople[0].personId);

      expect(before.isActive).not.toEqual(after.isActive);
      expect(before.modifiedBy).not.toEqual(after.modifiedBy);

      expect(after.modifiedBy).toEqual(modifiedPerson.modifiedBy);
      expect(after.isActive).toEqual(modifiedPerson.isActive);
    });
  });
});
