import { Injectable } from '@nestjs/common';
import { throwHttpErrorNotFound } from '../httpErrorUtils';
import { RateService } from '../rate/rate.service';
import { CostGroupService } from '../costGroup/costGroup.service';
import {
  CreatePersonModel,
  Person,
  PersonSimple,
} from './entities/person.entity';
import { PersonRepository } from './person.repository';

@Injectable()
export class PersonService {
  constructor(
    private repository: PersonRepository,
    private readonly costGroupService: CostGroupService,
    private readonly rateService: RateService,
  ) {}
  async getAll(isActive?: boolean): Promise<Person[]> {
    return this.repository.getAll(isActive);
  }

  async getAllSimpleByIds(personIds: string[]): Promise<PersonSimple[]> {
    return this.repository.getAllSimpleByIds(personIds);
  }

  async getAllByQuery(query: string): Promise<Person[]> {
    return this.repository.getAllByQuery(query);
  }

  async getAllByCostGroupId(
    costGroupId: string,
    isActive = true,
  ): Promise<Person[]> {
    return this.repository.getAllByCostGroupId(costGroupId, isActive);
  }

  async getAllByRateId(rateId: string, isActive = true): Promise<Person[]> {
    return this.repository.getAllByRateId(rateId, isActive);
  }

  async getByPersonId(personId: string): Promise<Person> {
    const person = await this.repository.getById(personId);
    if (!person)
      throwHttpErrorNotFound(`Unable to find person with id: ${personId}`);
    return person;
  }

  async createOrUpdateOne(
    newPerson: CreatePersonModel,
    userId: string,
  ): Promise<Person> {
    const existingCostGroup = await this.costGroupService.getByName(
      newPerson.costGroupName,
    );
    const existingRate = await this.rateService.getByName(newPerson.rateName);
    const updatedPerson = {
      ...newPerson,
      costGroupId: existingCostGroup.id,
      rateId: existingRate.id,
      modifiedBy: userId,
    };
    return this.repository.createOrUpdateOne(updatedPerson);
  }

  async updatePersonActiveStatus(
    personId: string,
    isActive: boolean,
    userId: string,
  ): Promise<boolean> {
    const existingPerson = await this.repository.getById(personId);
    if (!existingPerson)
      throwHttpErrorNotFound(`Unable to find user with id: ${personId}`);

    const updatedPerson = {
      ...existingPerson,
      isActive,
      modifiedBy: userId,
    };

    await this.repository.updatePerson(updatedPerson);
    return isActive;
  }
}
