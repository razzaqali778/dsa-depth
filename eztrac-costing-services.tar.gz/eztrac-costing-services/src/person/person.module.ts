import { Module } from '@nestjs/common';
import { PersonRepository } from './person.repository';
import { PersonController } from './person.controller';
import { PeopleController } from './people.controller';
import { PersonService } from './person.service';
import { CostGroupModule } from '../costGroup/costGroup.module';
import { RateModule } from '../rate/rate.module';

@Module({
  controllers: [PersonController, PeopleController],
  providers: [PersonRepository, PersonService],
  imports: [CostGroupModule, RateModule],
  exports: [PersonService],
})
export class PersonModule {}
