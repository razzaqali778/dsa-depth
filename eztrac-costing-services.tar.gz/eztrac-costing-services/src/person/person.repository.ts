import { Inject, Injectable } from '@nestjs/common';
import { Kysely, sql } from 'kysely';
import { DB } from 'src/common/db/database';
import { PROVIDERS } from '../constants';
import {
  Person,
  PersonForCreation,
  PersonSimple,
} from './entities/person.entity';

@Injectable()
export class PersonRepository {
  constructor(
    @Inject(PROVIDERS.database)
    private db: Kysely<DB>,
  ) {}

  getExtendedQuery() {
    return this.db
      .selectFrom('person')
      .select([
        'person.user_id as personId',
        'person.user_name as personName',
        'person.is_employee as isEmployee',
        'person.is_active as isActive',
        'person.modified_by as modifiedBy',
      ])
      .innerJoin(
        'cost_group',
        'person.cost_group_id',
        'cost_group.cost_group_id',
      )
      .select('cost_group.cost_group_name as costGroupName')
      .innerJoin('rate', 'person.rate_id', 'rate.rate_id')
      .select('rate.rate_name as rateName');
  }

  async getAll(isActive?: boolean): Promise<Person[]> {
    let query = this.getExtendedQuery();

    if (isActive !== undefined)
      query = query.where('person.is_active', '=', isActive);
    return query.execute();
  }

  async getAllByQuery(query: string): Promise<Person[]> {
    const adjustedQuery = `%${query.toLowerCase()}%`;
    return this.getExtendedQuery()
      .where((eb) =>
        eb.or([
          eb(sql`lower(person.user_name)`, 'like', adjustedQuery),
          eb(sql`lower(person.user_id)`, 'like', adjustedQuery),
        ]),
      )
      .execute();
  }

  async getAllByRateId(rateId: string, isActive: boolean): Promise<Person[]> {
    return await this.getExtendedQuery()
      .where('person.rate_id', '=', rateId)
      .where('person.is_active', '=', isActive)
      .execute();
  }

  async getAllByCostGroupId(
    costGroupId: string,
    isActive: boolean,
  ): Promise<Person[]> {
    return this.getExtendedQuery()
      .where('person.cost_group_id', '=', costGroupId)
      .where('person.is_active', '=', isActive)
      .execute();
  }

  async getById(id: string): Promise<Person> {
    return this.getExtendedQuery()
      .where('person.user_id', '=', id)
      .executeTakeFirst();
  }

  async getAllSimpleByIds(ids: string[]): Promise<PersonSimple[]> {
    if (ids.length === 0) return [];
    return this.db
      .selectFrom('person')
      .select([
        'person.user_id as id',
        'person.user_name as name',
        'person.cost_group_id as costGroupId',
        'person.rate_id as rateId',
        'person.is_employee as isEmployee',
        'person.is_active as isActive',
        'person.modified_by as modifiedBy',
      ])
      .where('person.user_id', 'in', ids)
      .execute();
  }

  async createOrUpdateOne(person: PersonForCreation): Promise<Person> {
    const {
      personId,
      personName,
      costGroupId,
      rateId,
      isActive,
      modifiedBy,
      isEmployee,
    } = person;
    await this.db
      .deleteFrom('person')
      .where('person.user_id', '=', personId)
      .execute();
    await this.db
      .insertInto('person')
      .values({
        user_id: personId,
        user_name: personName,
        rate_id: rateId,
        cost_group_id: costGroupId,
        is_employee: isEmployee,
        is_active: isActive,
        modified_by: modifiedBy,
      })
      .execute();

    return this.getExtendedQuery()
      .where('person.user_id', '=', personId)
      .executeTakeFirst();
  }

  async updatePerson(person: Person) {
    const { isActive, modifiedBy, personId } = person;

    await this.db
      .updateTable('person')
      .where('person.user_id', '=', personId)
      .set({
        modified_by: modifiedBy,
        is_active: isActive,
      })
      .execute();

    return this.getExtendedQuery()
      .where('person.user_id', '=', personId)
      .executeTakeFirst();
  }
}
