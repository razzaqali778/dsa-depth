import { Transform } from 'class-transformer';
import { IsBoolean, IsOptional, IsString, IsNotEmpty } from 'class-validator';

export interface Person {
  personId: string;
  personName: string;
  rateName: string;
  costGroupName: string;
  isEmployee: boolean;
  isActive: boolean;
  modifiedBy: string;
}

export interface PersonSimple {
  id: string;
  name: string;
  rateId: string;
  costGroupId: string;
  isEmployee: boolean;
  isActive: boolean;
  modifiedBy: string;
}

export interface PersonForCreation {
  personId: string;
  personName: string;
  rateName: string;
  rateId: string;
  costGroupName: string;
  costGroupId: string;
  isEmployee: boolean;
  isActive: boolean;
  modifiedBy: string;
}

export class PeopleGetQuery {
  @IsString()
  @IsOptional()
  q: string;

  @IsString()
  @IsOptional()
  costGroupId: string;

  @IsString()
  @IsOptional()
  rateId: string;

  @IsBoolean()
  @IsOptional()
  @Transform(({ value }) => value !== 'false')
  isActive: boolean;
}

export class CreatePersonModel {
  @IsString()
  @IsNotEmpty()
  personId: string;

  @IsString()
  @IsNotEmpty()
  personName: string;

  @IsString()
  @IsNotEmpty()
  rateName: string;

  @IsString()
  @IsNotEmpty()
  costGroupName: string;

  @IsBoolean()
  @IsNotEmpty()
  isActive: boolean;

  @IsBoolean()
  @IsNotEmpty()
  isEmployee: boolean;

  @IsString()
  @IsNotEmpty()
  modifiedBy: string;
}

export class UpdatePersonStatusModel {
  @IsBoolean()
  @IsNotEmpty()
  isActive: boolean;
}
