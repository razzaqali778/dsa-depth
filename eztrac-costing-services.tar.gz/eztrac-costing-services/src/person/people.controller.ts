import { Controller, Get, Query } from '@nestjs/common';
import { PeopleGetQuery } from './entities/person.entity';
import { PersonService } from './person.service';

@Controller('people')
export class PeopleController {
  constructor(private readonly personService: PersonService) {}

  @Get()
  getAll(@Query() query?: PeopleGetQuery) {
    if (!query || !Object.entries(query).length)
      return this.personService.getAll();

    for (const [key, value] of Object.entries(query)) {
      switch (key) {
        case 'q':
          return this.personService.getAllByQuery(value);
        case 'costGroupId':
          return this.personService.getAllByCostGroupId(value, query.isActive);
        case 'rateId':
          return this.personService.getAllByRateId(value, query.isActive);
        default:
          return this.personService.getAll(query.isActive);
      }
    }
  }
}
