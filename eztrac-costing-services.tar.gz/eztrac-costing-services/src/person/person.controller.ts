import {
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Put,
  Req,
  UseGuards,
} from '@nestjs/common';
import { Roles } from '../common/roles/roles.decorator';
import { Role } from '../common/roles/roles.enum';
import { RolesGuard } from '../common/roles/roles.guard';
import {
  CreatePersonModel,
  UpdatePersonStatusModel,
} from './entities/person.entity';
import { PersonService } from './person.service';

@Controller('person')
export class PersonController {
  constructor(private readonly personService: PersonService) {}

  @Get('/:personId')
  getSingle(@Param('personId') personId) {
    return this.personService.getByPersonId(personId);
  }

  @Put()
  @UseGuards(RolesGuard)
  @Roles(Role.MANAGE_PEOPLE)
  createOne(@Body() newPerson: CreatePersonModel, @Req() req) {
    return this.personService.createOrUpdateOne(newPerson, req.user);
  }

  @Patch('/:personId')
  @UseGuards(RolesGuard)
  @Roles(Role.MANAGE_PEOPLE)
  updatePersonActiveStatus(
    @Param('personId') personId,
    @Body() activeStatus: UpdatePersonStatusModel,
    @Req() req,
  ) {
    return this.personService.updatePersonActiveStatus(
      personId,
      activeStatus.isActive,
      req.user,
    );
  }
}
