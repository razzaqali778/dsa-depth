import { HttpException, HttpStatus } from '@nestjs/common';

export function throwHttpErrorNotFound(message: string) {
  throw new HttpException(`${message}`, HttpStatus.NOT_FOUND);
}

export function throwHttpErrorBadRequest(message: string) {
  throw new HttpException(`${message}`, HttpStatus.BAD_REQUEST);
}
