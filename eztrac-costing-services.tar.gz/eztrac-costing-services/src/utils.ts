export function NameToId(name: string): string {
  const dashRegex = /[_:;+\.,\(\)\{\}\[\]<>|'`\/\\\s]/gm;
  const removeRegex = /[~!@$$%^&*?=]/gm;
  const boundaryDashRegex = /(-$)|(^-)/gm;
  return name
    .replace(dashRegex, '-')
    .replace(removeRegex, '')
    .replace(boundaryDashRegex, '')
    .toUpperCase();
}
