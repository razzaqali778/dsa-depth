import { Controller, Get, Req, Res, Next } from '@nestjs/common';
import { NextFunction, Request, Response } from 'express';

@Controller()
export class AppController {
  @Get('ping')
  async getPingPage(
    @Req() request: Request,
    @Res() response: Response,
    @Next() next: NextFunction,
  ) {
    const pkg = {
      name: process.env.npm_package_name,
      version: process.env.npm_package_version,
    };
    const pingPage = await import('@monsantoit/ping-page');
    return pingPage.default(pkg)(request, response, next);
  }
}
