import { Controller, Get } from '@nestjs/common';
import { AuditsService } from './audits.service';

@Controller('audits')
export class AuditsController {
  constructor(private readonly auditsService: AuditsService) {}

  @Get()
  findAll() {
    return this.auditsService.findAll();
  }
}
