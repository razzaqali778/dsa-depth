import { Inject, Injectable } from '@nestjs/common';
import { Kysely } from 'kysely';
import { DB } from 'src/common/db/database';
import { PROVIDERS } from '../constants';
import { Audit } from './entities/audit.entity';

@Injectable()
export class AuditsRepository {
  constructor(
    @Inject(PROVIDERS.database)
    private db: Kysely<DB>,
  ) {}
  async findAll(): Promise<Audit[]> {
    return this.db
      .selectFrom('audit')
      .select([
        'audit.entity',
        'audit.entity_key as entityKey',
        'audit.entity_type as entityType',
        'audit.user_id as userId',
        'audit.modified_time as modifiedTime',
      ])
      .orderBy('audit.modified_time', 'desc')
      .execute();
  }
}
