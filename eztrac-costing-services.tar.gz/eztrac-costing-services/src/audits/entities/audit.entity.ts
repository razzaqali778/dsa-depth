import { JsonValue } from 'src/common/db/database';

export class Audit {
  entity: JsonValue;
  entityKey: string;
  entityType: string;
  userId: string;
  modifiedTime: Date;
}
