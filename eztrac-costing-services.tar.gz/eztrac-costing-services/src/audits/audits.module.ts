import { Module } from '@nestjs/common';
import { AuditsRepository } from './audits.repository';
import { AuditsController } from './audits.controller';
import { AuditsService } from './audits.service';

@Module({
  controllers: [AuditsController],
  providers: [AuditsRepository, AuditsService],
})
export class AuditsModule {}
