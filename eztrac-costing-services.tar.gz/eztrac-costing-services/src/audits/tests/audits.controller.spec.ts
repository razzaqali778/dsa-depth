import { Test, TestingModule } from '@nestjs/testing';
import { AuditsController } from '../audits.controller';
import { Audit } from '../entities/audit.entity';

describe('AuditsController', () => {
  let controller: AuditsController;
  const expected: Audit[] = [
    {
      entity: { name: 'entity name' },
      entityKey: 'controller_audit',
      entityType: 'controller_type',
      userId: 'test_user',
      modifiedTime: new Date(),
    },
  ];

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [AuditsController],
    })
      .useMocker(() => ({ findAll: jest.fn().mockResolvedValue(expected) }))
      .compile();

    controller = module.get<AuditsController>(AuditsController);
  });

  it('findAll', async () => {
    const audits = await controller.findAll();

    expect(audits).toEqual(expected);
  });
});
