import { Test, TestingModule } from '@nestjs/testing';
import { AuditsRepository } from '../audits.repository';
import { setupTestDb } from '../../../test-utils/setup-test-db';
import { PROVIDERS } from '../../constants';
import { CommonModule } from '../../common/common.module';
import { Audit } from '../entities/audit.entity';
import { testData } from 'test-utils/data-seed';

describe('AuditsService', () => {
  let service: AuditsRepository;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [CommonModule],
      providers: [AuditsRepository],
    })
      .overrideProvider(PROVIDERS.database)
      .useFactory({
        factory: async () => await setupTestDb(),
      })
      .compile();

    service = module.get<AuditsRepository>(AuditsRepository);
  });

  it('should return all audits', async () => {
    const expected = testData.audits;

    const audits: Audit[] = await service.findAll();

    expect(audits).toHaveLength(expected.length);
    expect(audits).toEqual(expected);
  });
});
