import { Injectable } from '@nestjs/common';
import { AuditsRepository } from './audits.repository';
import { Audit } from './entities/audit.entity';

@Injectable()
export class AuditsService {
  constructor(private repository: AuditsRepository) {}
  async findAll(): Promise<Audit[]> {
    return this.repository.findAll();
  }
}
