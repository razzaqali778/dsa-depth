--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

--
-- Name: audit; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.audit (
    entity_type text NOT NULL,
    entity_key text NOT NULL,
    modified_time timestamp with time zone NOT NULL,
    user_id text NOT NULL,
    entity jsonb NOT NULL
);


ALTER TABLE public.audit OWNER TO "EzTracAdminUser";

--
-- Name: calendar; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.calendar (
    calendar_id text NOT NULL,
    calendar_name text NOT NULL
);


ALTER TABLE public.calendar OWNER TO "EzTracAdminUser";

--
-- Name: calendar_timeframe_hours; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.calendar_timeframe_hours (
    calendar_id text NOT NULL,
    timeframe_id bigint NOT NULL,
    employee_hours numeric(3,0) NOT NULL,
    contractor_hours numeric(3,0) NOT NULL
);


ALTER TABLE public.calendar_timeframe_hours OWNER TO "EzTracAdminUser";

--
-- Name: cost_group; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.cost_group (
    cost_group_id text NOT NULL,
    cost_group_name text NOT NULL,
    cost_center text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL,
    exclude_from_distributions boolean DEFAULT false NOT NULL
);


ALTER TABLE public.cost_group OWNER TO "EzTracAdminUser";

--
-- Name: engagement; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.engagement (
    engagement_id text NOT NULL,
    engagement_name text NOT NULL,
    cost_group_id text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL,
    engagement_purchase_order text
);


ALTER TABLE public.engagement OWNER TO "EzTracAdminUser";

--
-- Name: person; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.person (
    user_id text NOT NULL,
    user_name text NOT NULL,
    rate_id text NOT NULL,
    cost_group_id text NOT NULL,
    is_employee boolean DEFAULT true NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL
);


ALTER TABLE public.person OWNER TO "EzTracAdminUser";

--
-- Name: rate; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.rate (
    rate_id text NOT NULL,
    rate_name text NOT NULL,
    hourly_rate bigint NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    modified_by text DEFAULT 'automatic'::text NOT NULL,
    calendar_id text DEFAULT 'US-VARIABLE'::text NOT NULL
);


ALTER TABLE public.rate OWNER TO "EzTracAdminUser";

--
-- Name: audit audit_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.audit
    ADD CONSTRAINT audit_pkey PRIMARY KEY (entity_type, entity_key, modified_time);


--
-- Name: calendar calendar_name_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_name_uk UNIQUE (calendar_name);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (calendar_id);


--
-- Name: calendar_timeframe_hours calendar_timeframe_hours_pk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.calendar_timeframe_hours
    ADD CONSTRAINT calendar_timeframe_hours_pk PRIMARY KEY (calendar_id, timeframe_id);


--
-- Name: cost_group cost_group_name_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.cost_group
    ADD CONSTRAINT cost_group_name_uk UNIQUE (cost_group_name);


--
-- Name: cost_group cost_group_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.cost_group
    ADD CONSTRAINT cost_group_pkey PRIMARY KEY (cost_group_id);


--
-- Name: engagement engagement_name_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.engagement
    ADD CONSTRAINT engagement_name_uk UNIQUE (engagement_name);


--
-- Name: engagement engagement_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.engagement
    ADD CONSTRAINT engagement_pkey PRIMARY KEY (engagement_id);


--
-- Name: person person_user_id_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_user_id_pkey PRIMARY KEY (user_id);


--
-- Name: rate rate_name_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_name_uk UNIQUE (rate_name);


--
-- Name: rate rate_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_pkey PRIMARY KEY (rate_id);


--
-- Name: fki_audit_person_user_id_fk; Type: INDEX; Schema: public; Owner: EzTracAdminUser
--

CREATE INDEX fki_audit_person_user_id_fk ON public.audit USING btree (user_id);


--
-- Name: calendar_timeframe_hours calendar_timeframe_hours_calendar_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.calendar_timeframe_hours
    ADD CONSTRAINT calendar_timeframe_hours_calendar_id_fk FOREIGN KEY (calendar_id) REFERENCES public.calendar(calendar_id);


--
-- Name: engagement cost_group_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.engagement
    ADD CONSTRAINT cost_group_id_fk FOREIGN KEY (cost_group_id) REFERENCES public.cost_group(cost_group_id);


--
-- Name: person person_cost_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_cost_group_id_fkey FOREIGN KEY (cost_group_id) REFERENCES public.cost_group(cost_group_id);


--
-- Name: person person_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_rate_id_fkey FOREIGN KEY (rate_id) REFERENCES public.rate(rate_id);


--
-- PostgreSQL database dump complete
--

