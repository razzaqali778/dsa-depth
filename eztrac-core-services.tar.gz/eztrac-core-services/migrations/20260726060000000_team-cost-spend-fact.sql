-- Up Migration
CREATE TABLE IF NOT EXISTS public.team_cost_spend (
  timeframe_id bigint NOT NULL,
  team_id text NOT NULL,
  vip_initiative_id text NOT NULL,
  cost_group_id text NOT NULL DEFAULT '',
  engagement_id text NOT NULL DEFAULT '',
  person_id text NOT NULL DEFAULT '',
  spend bigint NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (
    timeframe_id,
    team_id,
    vip_initiative_id,
    cost_group_id,
    engagement_id,
    person_id
  )
);

ALTER TABLE public.team_cost_spend
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'team_cost_spend_pkey'
      AND conrelid = 'public.team_cost_spend'::regclass
  ) THEN
    ALTER TABLE public.team_cost_spend
      ADD CONSTRAINT team_cost_spend_pkey PRIMARY KEY (
        timeframe_id,
        team_id,
        vip_initiative_id,
        cost_group_id,
        engagement_id,
        person_id
      );
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_team_cost_spend_timeframe
  ON public.team_cost_spend (timeframe_id);

CREATE INDEX IF NOT EXISTS idx_team_cost_spend_timeframe_team_initiative
  ON public.team_cost_spend (timeframe_id, team_id, vip_initiative_id);

CREATE OR REPLACE FUNCTION public.refresh_team_cost_spend(p_team_cost_id bigint)
RETURNS void AS $$
BEGIN
  DELETE FROM public.team_cost_spend spend
  USING public.team_cost effort
  WHERE effort.team_cost_id = p_team_cost_id
    AND spend.timeframe_id = effort.timeframe_id
    AND spend.team_id = effort.team_id;

  INSERT INTO public.team_cost_spend (
    timeframe_id,
    team_id,
    vip_initiative_id,
    cost_group_id,
    engagement_id,
    person_id,
    spend
  )
  SELECT
    effort.timeframe_id,
    effort.team_id,
    allocation.vip_initiative_id,
    COALESCE(breakdown.cost_group_id, ''),
    COALESCE(breakdown.engagement_id, ''),
    COALESCE(breakdown.person_id, ''),
    SUM(ROUND((allocation.team_cost_pct::numeric * breakdown.cost::numeric) / 100)::bigint) AS spend
  FROM public.team_cost effort
  JOIN public.team_cost_allocation allocation
    ON allocation.team_cost_id = effort.team_cost_id
  JOIN public.team_cost_breakdown breakdown
    ON breakdown.team_cost_id = effort.team_cost_id
  WHERE effort.team_cost_id = p_team_cost_id
    AND allocation.team_cost_pct > 0
    AND breakdown.cost > 0
    AND allocation.vip_initiative_id IS NOT NULL
  GROUP BY
    effort.timeframe_id,
    effort.team_id,
    allocation.vip_initiative_id,
    COALESCE(breakdown.cost_group_id, ''),
    COALESCE(breakdown.engagement_id, ''),
    COALESCE(breakdown.person_id, '')
  ON CONFLICT (
    timeframe_id,
    team_id,
    vip_initiative_id,
    cost_group_id,
    engagement_id,
    person_id
  ) DO UPDATE SET
    spend = EXCLUDED.spend,
    updated_at = now();
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION public.refresh_team_cost_spend_trigger()
RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    PERFORM public.refresh_team_cost_spend(OLD.team_cost_id);
    RETURN OLD;
  END IF;

  IF TG_OP = 'UPDATE' AND OLD.team_cost_id IS DISTINCT FROM NEW.team_cost_id THEN
    PERFORM public.refresh_team_cost_spend(OLD.team_cost_id);
  END IF;

  PERFORM public.refresh_team_cost_spend(NEW.team_cost_id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_refresh_team_cost_spend_allocation ON public.team_cost_allocation;
DROP TRIGGER IF EXISTS trg_refresh_team_cost_spend_breakdown ON public.team_cost_breakdown;

CREATE TRIGGER trg_refresh_team_cost_spend_allocation
AFTER INSERT OR UPDATE OR DELETE ON public.team_cost_allocation
FOR EACH ROW EXECUTE FUNCTION public.refresh_team_cost_spend_trigger();

CREATE TRIGGER trg_refresh_team_cost_spend_breakdown
AFTER INSERT OR UPDATE OR DELETE ON public.team_cost_breakdown
FOR EACH ROW EXECUTE FUNCTION public.refresh_team_cost_spend_trigger();

INSERT INTO public.team_cost_spend (
  timeframe_id,
  team_id,
  vip_initiative_id,
  cost_group_id,
  engagement_id,
  person_id,
  spend
)
SELECT
  effort.timeframe_id,
  effort.team_id,
  allocation.vip_initiative_id,
  COALESCE(breakdown.cost_group_id, ''),
  COALESCE(breakdown.engagement_id, ''),
  COALESCE(breakdown.person_id, ''),
  SUM(ROUND((allocation.team_cost_pct::numeric * breakdown.cost::numeric) / 100)::bigint) AS spend
FROM public.team_cost effort
JOIN public.team_cost_allocation allocation
  ON allocation.team_cost_id = effort.team_cost_id
JOIN public.team_cost_breakdown breakdown
  ON breakdown.team_cost_id = effort.team_cost_id
WHERE allocation.team_cost_pct > 0
  AND breakdown.cost > 0
  AND allocation.vip_initiative_id IS NOT NULL
GROUP BY
  effort.timeframe_id,
  effort.team_id,
  allocation.vip_initiative_id,
  COALESCE(breakdown.cost_group_id, ''),
  COALESCE(breakdown.engagement_id, ''),
  COALESCE(breakdown.person_id, '')
ON CONFLICT (
  timeframe_id,
  team_id,
  vip_initiative_id,
  cost_group_id,
  engagement_id,
  person_id
) DO UPDATE SET
  spend = EXCLUDED.spend,
  updated_at = now();

-- Down Migration
DROP TRIGGER IF EXISTS trg_refresh_team_cost_spend_breakdown ON public.team_cost_breakdown;
DROP TRIGGER IF EXISTS trg_refresh_team_cost_spend_allocation ON public.team_cost_allocation;
DROP FUNCTION IF EXISTS public.refresh_team_cost_spend_trigger();
DROP FUNCTION IF EXISTS public.refresh_team_cost_spend(bigint);
DROP TABLE IF EXISTS public.team_cost_spend;