-- Up Migration
CREATE TABLE public.org (
    org_id text PRIMARY KEY,
    org_name text UNIQUE NOT NULL,
    is_active boolean NOT NULL DEFAULT true
);

INSERT INTO public.org (org_id, org_name, is_active) VALUES ('UNKNOWN-ORG', 'Unknown Org', false);

ALTER TABLE public.platform ADD org_id text DEFAULT 'UNKNOWN-ORG' NOT NULL;

ALTER TABLE public.platform
ADD CONSTRAINT fk_org_id FOREIGN KEY (org_id) REFERENCES public.org(org_id)
ON DELETE SET DEFAULT;

-- Down Migration
ALTER TABLE public.platform DROP CONSTRAINT fk_org_id;
ALTER TABLE public.platform DROP COLUMN org_id;
DROP TABLE public.org;
