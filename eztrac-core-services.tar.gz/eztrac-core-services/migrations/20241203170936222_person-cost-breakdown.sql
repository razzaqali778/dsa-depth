-- Up Migration
ALTER TABLE public.team_cost_breakdown ADD person_id text

-- Down Migration
ALTER TABLE public.team_cost_breakdown DROP COLUMN person_id