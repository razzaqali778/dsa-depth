--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.9 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: execute(text); Type: FUNCTION; Schema: public; Owner: EzTracAdminUser
--

CREATE FUNCTION public.execute(text) RETURNS void
    LANGUAGE plpgsql STRICT
    AS $_$
BEGIN EXECUTE $1; END;
$_$;


ALTER FUNCTION public.execute(text) OWNER TO "EzTracAdminUser";

--
-- Name: update_service_team_team_cost_on_service_team_update(); Type: FUNCTION; Schema: public; Owner: EzTracAdminUser
--

-- CREATE FUNCTION public.update_service_team_team_cost_on_service_team_update() RETURNS trigger
--     LANGUAGE plpgsql
--     AS $$
-- BEGIN
--     UPDATE service_team_teams
--     SET cost = subquery.team_cost
--     FROM (
--              SELECT service_team_id, timeframe_id, team_id,
--                  (ROUND(COALESCE(team_cost.cost, 0) * NEW.effort_fee_percent / 100)) as team_cost
--              FROM service_team_teams
--                  JOIN timeframe using (timeframe_id)
--                  LEFT JOIN team_cost using (team_id, timeframe_id)
--              WHERE service_team_id = NEW.service_team_id
--                    AND timeframe_end_date > current_date
--          ) subquery
--     WHERE service_team_teams.service_team_id = subquery.service_team_id
--           AND service_team_teams.timeframe_id = subquery.timeframe_id
--           AND service_team_teams.team_id = subquery.team_id;
--     RETURN NEW;
-- END;
-- $$;


-- ALTER FUNCTION public.update_service_team_team_cost_on_service_team_update() OWNER TO "EzTracAdminUser";

--
-- Name: update_team_cost_cost_on_breakdown_delete(); Type: FUNCTION; Schema: public; Owner: EzTracAdminUser
--

CREATE FUNCTION public.update_team_cost_cost_on_breakdown_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
        UPDATE public.team_cost
        SET cost = (
            SELECT coalesce(SUM(cost), 0)
            FROM public.team_cost_breakdown
            WHERE team_cost_id = OLD.team_cost_id
        )
        WHERE team_cost_id = OLD.team_cost_id;
        RETURN OLD;
    END;
$$;


ALTER FUNCTION public.update_team_cost_cost_on_breakdown_delete() OWNER TO "EzTracAdminUser";

--
-- Name: update_team_cost_cost_on_breakdown_insert(); Type: FUNCTION; Schema: public; Owner: EzTracAdminUser
--

CREATE FUNCTION public.update_team_cost_cost_on_breakdown_insert() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
        UPDATE public.team_cost
        SET cost = (
            SELECT coalesce(SUM(cost), 0)
            FROM public.team_cost_breakdown
            WHERE team_cost_id = NEW.team_cost_id
        )
        WHERE team_cost_id = NEW.team_cost_id;
        RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_team_cost_cost_on_breakdown_insert() OWNER TO "EzTracAdminUser";

--
-- Name: update_team_inactive_start_date(); Type: FUNCTION; Schema: public; Owner: EzTracAdminUser
--

CREATE FUNCTION public.update_team_inactive_start_date() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	IF NEW.is_active = false AND NEW.inactive_start_date IS NULL THEN
    	NEW.inactive_start_date = now();
    END IF;
    IF NEW.is_active = true AND NEW.inactive_start_date IS NOT NULL THEN
    	NEW.inactive_start_date = NULL;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_team_inactive_start_date() OWNER TO "EzTracAdminUser";

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: community; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.community (
    community_id text NOT NULL,
    community_name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    platform_id text DEFAULT 'UNKNOWN-PLATFORM'::text NOT NULL
);


ALTER TABLE public.community OWNER TO "EzTracAdminUser";

--
-- Name: forecast_person; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.forecast_person (
    team_cost_id bigint NOT NULL,
    people_number numeric DEFAULT 0 NOT NULL,
    rate_id integer DEFAULT 0 NOT NULL,
    external_rate_id text DEFAULT 'STANDARD'::text NOT NULL,
    cost_group_id text DEFAULT 'UNKNOWN'::text NOT NULL
);


ALTER TABLE public.forecast_person OWNER TO "EzTracAdminUser";

--
-- Name: person; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.person (
    user_id text NOT NULL,
    name text NOT NULL,
    rate_id integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.person OWNER TO "EzTracAdminUser";

--
-- Name: platform; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.platform (
    platform_id text NOT NULL,
    platform_name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.platform OWNER TO "EzTracAdminUser";

--
-- Name: rate; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.rate (
    rate_name text NOT NULL,
    hourly_rate bigint NOT NULL,
    export_role text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    rate_id integer NOT NULL
);


ALTER TABLE public.rate OWNER TO "EzTracAdminUser";

--
-- Name: rate_rate_id_seq; Type: SEQUENCE; Schema: public; Owner: EzTracAdminUser
--

CREATE SEQUENCE public.rate_rate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rate_rate_id_seq OWNER TO "EzTracAdminUser";

--
-- Name: rate_rate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: EzTracAdminUser
--

ALTER SEQUENCE public.rate_rate_id_seq OWNED BY public.rate.rate_id;


--
-- Name: seq; Type: SEQUENCE; Schema: public; Owner: EzTracAdminUser
--

CREATE SEQUENCE public.seq
    START WITH 1488
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seq OWNER TO "EzTracAdminUser";

--
-- Name: service_team; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.service_team (
    team_name text NOT NULL,
    description text,
    service_team_id text NOT NULL,
    effort_fee_percent numeric(3,1) DEFAULT 0.0 NOT NULL,
    "interval" numeric(2,1) DEFAULT 1.0 NOT NULL
);


ALTER TABLE public.service_team OWNER TO "EzTracAdminUser";

--
-- Name: service_team_breakdown; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.service_team_breakdown (
    service_team_id text NOT NULL,
    timeframe_id bigint NOT NULL,
    cost_group_id text NOT NULL,
    cost bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.service_team_breakdown OWNER TO "EzTracAdminUser";

--
-- Name: service_team_people; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.service_team_people (
    user_id text NOT NULL,
    timeframe_id bigint NOT NULL,
    inactive_date timestamp without time zone,
    rate_id integer DEFAULT 6 NOT NULL,
    service_team_id text NOT NULL
);


ALTER TABLE public.service_team_people OWNER TO "EzTracAdminUser";

--
-- Name: service_team_teams; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.service_team_teams (
    timeframe_id bigint NOT NULL,
    cost integer DEFAULT 0 NOT NULL,
    team_id text NOT NULL,
    service_team_id text NOT NULL
);


ALTER TABLE public.service_team_teams OWNER TO "EzTracAdminUser";

--
-- Name: team; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.team (
    team_name text NOT NULL,
    inactive_start_date timestamp without time zone,
    team_id text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    community_id text NOT NULL
);


ALTER TABLE public.team OWNER TO "EzTracAdminUser";

--
-- Name: team_cost; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.team_cost (
    timeframe_id bigint NOT NULL,
    cost bigint DEFAULT '0'::bigint NOT NULL,
    team_cost_id bigint DEFAULT nextval('public.seq'::regclass) NOT NULL,
    team_id text
);


ALTER TABLE public.team_cost OWNER TO "EzTracAdminUser";

--
-- Name: team_cost_allocation; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.team_cost_allocation (
    team_cost_id bigint,
    team_cost_pct bigint DEFAULT 0 NOT NULL,
    vip_initiative_id text,
    team_cost_allocation_id integer NOT NULL
);


ALTER TABLE public.team_cost_allocation OWNER TO "EzTracAdminUser";

--
-- Name: team_cost_allocation_team_cost_allocation_id_seq; Type: SEQUENCE; Schema: public; Owner: EzTracAdminUser
--

CREATE SEQUENCE public.team_cost_allocation_team_cost_allocation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_cost_allocation_team_cost_allocation_id_seq OWNER TO "EzTracAdminUser";

--
-- Name: team_cost_allocation_team_cost_allocation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: EzTracAdminUser
--

ALTER SEQUENCE public.team_cost_allocation_team_cost_allocation_id_seq OWNED BY public.team_cost_allocation.team_cost_allocation_id;


--
-- Name: team_cost_breakdown; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.team_cost_breakdown (
    team_cost_id integer NOT NULL,
    cost_group_id text NOT NULL,
    cost integer DEFAULT 0 NOT NULL,
    engagement_id text
);


ALTER TABLE public.team_cost_breakdown OWNER TO "EzTracAdminUser";

--
-- Name: team_cost_engagement; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.team_cost_engagement (
    team_cost_id bigint NOT NULL,
    amount_type text,
    engagement_id text NOT NULL,
    amount integer NOT NULL,
    amount_details text,
    comment text
);


ALTER TABLE public.team_cost_engagement OWNER TO "EzTracAdminUser";

--
-- Name: team_cost_member; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.team_cost_member (
    user_id text NOT NULL,
    team_cost_id bigint NOT NULL,
    participation_pct smallint NOT NULL,
    rate_id integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.team_cost_member OWNER TO "EzTracAdminUser";

--
-- Name: timeframe; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.timeframe (
    timeframe_id bigint NOT NULL,
    timeframe_name text,
    timeframe_start_date timestamp with time zone,
    timeframe_end_date timestamp with time zone,
    lockdown boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.timeframe OWNER TO "EzTracAdminUser";

--
-- Name: team_cost_vw; Type: VIEW; Schema: public; Owner: EzTracAdminUser
--

CREATE VIEW public.team_cost_vw AS
 SELECT team.team_name,
    timeframe.timeframe_name,
    team_cost.cost,
    team_cost.team_cost_id,
    team_cost.timeframe_id,
    team_cost.team_id,
    team.inactive_start_date,
    timeframe.timeframe_start_date,
    timeframe.timeframe_end_date
   FROM ((public.team_cost
     JOIN public.team USING (team_id))
     JOIN public.timeframe USING (timeframe_id))
  ORDER BY timeframe.timeframe_start_date, team.team_name;


ALTER TABLE public.team_cost_vw OWNER TO "EzTracAdminUser";

--
-- Name: timeframe_workdays; Type: TABLE; Schema: public; Owner: EzTracAdminUser
--

CREATE TABLE public.timeframe_workdays (
    timeframe_id bigint NOT NULL,
    country text NOT NULL,
    workday_hours text NOT NULL
);


ALTER TABLE public.timeframe_workdays OWNER TO "EzTracAdminUser";

--
-- Name: rate rate_id; Type: DEFAULT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.rate ALTER COLUMN rate_id SET DEFAULT nextval('public.rate_rate_id_seq'::regclass);


--
-- Name: team_cost_allocation team_cost_allocation_id; Type: DEFAULT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost_allocation ALTER COLUMN team_cost_allocation_id SET DEFAULT nextval('public.team_cost_allocation_team_cost_allocation_id_seq'::regclass);


--
-- Name: community community_pk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.community
    ADD CONSTRAINT community_pk PRIMARY KEY (community_id);


--
-- Name: community community_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.community
    ADD CONSTRAINT community_uk UNIQUE (community_name);


--
-- Name: forecast_person forecast_person_primary_key; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.forecast_person
    ADD CONSTRAINT forecast_person_primary_key PRIMARY KEY (team_cost_id, external_rate_id, cost_group_id);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (user_id);


--
-- Name: platform platform_pk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.platform
    ADD CONSTRAINT platform_pk PRIMARY KEY (platform_id);


--
-- Name: platform platform_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.platform
    ADD CONSTRAINT platform_uk UNIQUE (platform_name);


--
-- Name: rate rate_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_pkey PRIMARY KEY (rate_id);


--
-- Name: rate rate_uk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_uk UNIQUE (rate_name);


--
-- Name: service_team_breakdown service_team_breakdown_pk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team_breakdown
    ADD CONSTRAINT service_team_breakdown_pk PRIMARY KEY (service_team_id, timeframe_id, cost_group_id);


--
-- Name: service_team service_team_name_ukey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team
    ADD CONSTRAINT service_team_name_ukey UNIQUE (team_name);


--
-- Name: service_team_people service_team_people_pk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team_people
    ADD CONSTRAINT service_team_people_pk PRIMARY KEY (user_id, timeframe_id, service_team_id);


--
-- Name: service_team service_team_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team
    ADD CONSTRAINT service_team_pkey PRIMARY KEY (service_team_id);


--
-- Name: service_team_teams service_team_teams_pk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team_teams
    ADD CONSTRAINT service_team_teams_pk PRIMARY KEY (timeframe_id, service_team_id, team_id);


--
-- Name: team_cost_allocation team_cost_allocation_natural_key; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost_allocation
    ADD CONSTRAINT team_cost_allocation_natural_key UNIQUE (team_cost_id, vip_initiative_id);


--
-- Name: team_cost_allocation team_cost_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost_allocation
    ADD CONSTRAINT team_cost_allocation_pkey PRIMARY KEY (team_cost_allocation_id);


--
-- Name: team_cost team_cost_natural_key; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost
    ADD CONSTRAINT team_cost_natural_key UNIQUE (timeframe_id, team_id);


--
-- Name: team_cost team_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost
    ADD CONSTRAINT team_cost_pkey PRIMARY KEY (team_cost_id);


--
-- Name: team team_id; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_id PRIMARY KEY (team_id);


--
-- Name: team_cost_member team_member_primary_key; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost_member
    ADD CONSTRAINT team_member_primary_key PRIMARY KEY (user_id, team_cost_id);


--
-- Name: team team_name_ak; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_name_ak UNIQUE (team_name);


--
-- Name: timeframe timeframe_name_unique; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.timeframe
    ADD CONSTRAINT timeframe_name_unique UNIQUE (timeframe_name);


--
-- Name: timeframe timeframe_pk; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.timeframe
    ADD CONSTRAINT timeframe_pk PRIMARY KEY (timeframe_id);


--
-- Name: timeframe_workdays timeframe_workdays_pkey; Type: CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.timeframe_workdays
    ADD CONSTRAINT timeframe_workdays_pkey PRIMARY KEY (timeframe_id, country);


--
-- Name: fki_team_community_id_fk; Type: INDEX; Schema: public; Owner: EzTracAdminUser
--

CREATE INDEX fki_team_community_id_fk ON public.team USING btree (community_id);


--
-- Name: team_cost_breakdown_team_cost_id_idk; Type: INDEX; Schema: public; Owner: EzTracAdminUser
--

CREATE INDEX team_cost_breakdown_team_cost_id_idk ON public.team_cost_breakdown USING btree (team_cost_id);


--
-- Name: team_cost_engagement_primary_key; Type: INDEX; Schema: public; Owner: EzTracAdminUser
--

CREATE INDEX team_cost_engagement_primary_key ON public.team_cost_engagement USING btree (team_cost_id, engagement_id);


--
-- Name: service_team service_team_teams_calc_serviced_teams_update_trg; Type: TRIGGER; Schema: public; Owner: EzTracAdminUser
--

-- CREATE TRIGGER service_team_teams_calc_serviced_teams_update_trg AFTER UPDATE ON public.service_team FOR EACH ROW EXECUTE FUNCTION public.update_service_team_team_cost_on_service_team_update();


--
-- Name: team_cost_breakdown team_cost_breakdown_calc_team_cost_delete_trg; Type: TRIGGER; Schema: public; Owner: EzTracAdminUser
--

CREATE TRIGGER team_cost_breakdown_calc_team_cost_delete_trg AFTER DELETE ON public.team_cost_breakdown FOR EACH ROW EXECUTE FUNCTION public.update_team_cost_cost_on_breakdown_delete();


--
-- Name: team_cost_breakdown team_cost_breakdown_calc_team_cost_insert_trg; Type: TRIGGER; Schema: public; Owner: EzTracAdminUser
--

CREATE TRIGGER team_cost_breakdown_calc_team_cost_insert_trg AFTER INSERT ON public.team_cost_breakdown FOR EACH ROW EXECUTE FUNCTION public.update_team_cost_cost_on_breakdown_insert();


--
-- Name: team team_insert_update_trg; Type: TRIGGER; Schema: public; Owner: EzTracAdminUser
--

CREATE TRIGGER team_insert_update_trg BEFORE INSERT OR UPDATE ON public.team FOR EACH ROW EXECUTE FUNCTION public.update_team_inactive_start_date();


--
-- Name: community community_platform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.community
    ADD CONSTRAINT community_platform_id_fkey FOREIGN KEY (platform_id) REFERENCES public.platform(platform_id);


--
-- Name: team_cost_allocation effort_allocation_team_cost_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost_allocation
    ADD CONSTRAINT effort_allocation_team_cost_id_fkey FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: forecast_person forecast_person_cost_id_foreign_key; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.forecast_person
    ADD CONSTRAINT forecast_person_cost_id_foreign_key FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: service_team_breakdown service_team_breakdown_service_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team_breakdown
    ADD CONSTRAINT service_team_breakdown_service_team_id_fkey FOREIGN KEY (service_team_id) REFERENCES public.service_team(service_team_id);


--
-- Name: service_team_breakdown service_team_breakdown_timeframe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team_breakdown
    ADD CONSTRAINT service_team_breakdown_timeframe_id_fkey FOREIGN KEY (timeframe_id) REFERENCES public.timeframe(timeframe_id);


--
-- Name: service_team_people service_team_people_timeframe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team_people
    ADD CONSTRAINT service_team_people_timeframe_id_fkey FOREIGN KEY (timeframe_id) REFERENCES public.timeframe(timeframe_id);


--
-- Name: service_team_people service_team_people_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team_people
    ADD CONSTRAINT service_team_people_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.person(user_id);


--
-- Name: service_team_teams service_team_team_timeframe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team_teams
    ADD CONSTRAINT service_team_team_timeframe_id_fkey FOREIGN KEY (timeframe_id) REFERENCES public.timeframe(timeframe_id);


--
-- Name: service_team_teams service_team_teams_service_team_id_p_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.service_team_teams
    ADD CONSTRAINT service_team_teams_service_team_id_p_fkey FOREIGN KEY (service_team_id) REFERENCES public.service_team(service_team_id);


--
-- Name: team team_community_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_community_id_fk FOREIGN KEY (community_id) REFERENCES public.community(community_id);


--
-- Name: team_cost_breakdown team_cost_breakdown_team_cost_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost_breakdown
    ADD CONSTRAINT team_cost_breakdown_team_cost_id_fkey FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: team_cost_engagement team_cost_engagement_team_cost_id; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost_engagement
    ADD CONSTRAINT team_cost_engagement_team_cost_id FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: team_cost_member team_cost_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost_member
    ADD CONSTRAINT team_cost_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.person(user_id);


--
-- Name: team_cost team_cost_timeframe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost
    ADD CONSTRAINT team_cost_timeframe_id_fkey FOREIGN KEY (timeframe_id) REFERENCES public.timeframe(timeframe_id);


--
-- Name: team_cost team_id_f; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost
    ADD CONSTRAINT team_id_f FOREIGN KEY (team_id) REFERENCES public.team(team_id);


--
-- Name: team_cost_member team_member_team_cost_id_foreign_key; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.team_cost_member
    ADD CONSTRAINT team_member_team_cost_id_foreign_key FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: timeframe_workdays timeframe_workdays_timeframe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: EzTracAdminUser
--

ALTER TABLE ONLY public.timeframe_workdays
    ADD CONSTRAINT timeframe_workdays_timeframe_id_fkey FOREIGN KEY (timeframe_id) REFERENCES public.timeframe(timeframe_id);


--
-- PostgreSQL database dump complete
--

