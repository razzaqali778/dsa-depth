module.exports = {
  env: {
    "es6": true
  },
  parserOptions: {
    "ecmaVersion": "latest",
    requireConfigFile: false,
    "sourceType": "module",
  },
  overrides: [
    {
      // eslint rules to be discussed
      files: ['*.ts', '*.tsx'],
      parser: '@typescript-eslint/parser',
      plugins: ['@typescript-eslint'],
      extends: ['./node_modules/gts'],
      "rules": {
        "node/no-unpublished-import": 0,
        "node/no-unpublished-require": 0,
        "@typescript-eslint/no-unused-vars": [
          1,
          {argsIgnorePattern: "^_", varsIgnorePattern: "^_"}
        ],
        "@typescript-eslint/no-explicit-any": 1 //warning for now, ideally should be 2 - error
      },
      settings: {
        'import/resolver': {
          node: {
            extensions: ['.ts', '.tsx'],
          },
        },
      },
    }
  ],
};
