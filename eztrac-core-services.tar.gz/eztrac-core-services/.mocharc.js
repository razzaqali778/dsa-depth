module.exports = {
    exit: true,
    recursive: true,
    colors: true,
    reporter: 'list',
    require: ['test/setup', 'test/prepare']
}
