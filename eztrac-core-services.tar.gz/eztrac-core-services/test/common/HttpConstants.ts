export const CONTENT_TYPE = 'content-type';
export const APPLICATION_JSON_WITH_CHARSET = 'application/json; charset=utf-8';

export const adminUser = 'ADMIN_USER';
export const invalidUser = 'INVALID_USER';
export const writeUser = 'WRITE_USER';
export const defaultUser = 'DEFAULT_USER';
export const teamManagerUser = 'MANAGE-TEAMS';

export const DEFAULT_USER_HEADER = {
  id: 'DEFAULT_USER',
  entitlements: {
    eztrac: ['some-entitlement'],
  },
};
const ADMIN_USER_HEADER = {
  id: adminUser,
  entitlements: {
    eztrac: ['eztrac-admin-user'],
  },
};
const EFFORT_WRITE_USER_HEADER = {
  id: 'EFFORT_WRITE_USER',
  entitlements: {
    eztrac: ['eztrac-write-user'],
  },
};
const TEAM_MANAGER_HEADER = {
  id: teamManagerUser,
  entitlements: {
    eztrac: ['eztrac-manage-teams'],
  },
};

const userHeader = (header: {id: string; entitlements: {}}) => ({
  'user-profile': JSON.stringify(header),
});

export const adminUserHeader = userHeader(ADMIN_USER_HEADER);

export const teamManagerUserHeader = userHeader(TEAM_MANAGER_HEADER);

export const effortWriteUserHeader = userHeader(EFFORT_WRITE_USER_HEADER);

export const unauthorizedUserHeader = userHeader(DEFAULT_USER_HEADER);
