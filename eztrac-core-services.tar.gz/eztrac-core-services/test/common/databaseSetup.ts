import 'reflect-metadata';
import {IBackup, newDb} from 'pg-mem';
import fs from 'fs';
import {seedData} from './dataSeed';
import {IDatabase} from 'pg-promise';
import {registerDependenciesWithDatabase} from './baseBuilders';
import {container} from 'tsyringe';

let backup: IBackup;

export async function setupCoreDatabase() {
  let existingDb;
  try {
    existingDb = container.resolve('pg-mem-database');
  } catch (e) {
    //database not registered, proceed
  }
  if (existingDb) {
    backup.restore();
    registerDependenciesWithDatabase(existingDb as IDatabase<{}>);
    return;
  }
  const dbSetup = newDb();
  dbSetup.public.none(fs.readFileSync('dbSchemaDump.sql', 'utf8'));

  const pg = dbSetup.adapters.createPgPromise();
  const db = (await pg.connect()) as IDatabase<{}>;

  await seedData(db);

  backup = dbSetup.backup();

  container.register('pg-mem-database', {
    useValue: db,
  });

  registerDependenciesWithDatabase(db);
}
