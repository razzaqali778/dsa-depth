import sinon from 'sinon';
import {papiClient} from '../../src/util/client/papiClient';
import {adminUser, invalidUser, teamManagerUser, writeUser} from './HttpConstants';

const appId = 'eztrac';

const writeEntitlements = [
  {
    application: {
      id: appId,
    },
    code: 'eztrac-write-user',
  },
];

const teamManagerEntitlements = [
  {
    application: {
      id: appId,
    },
    code: 'eztrac-manage-teams',
  },
];

const adminEntitlements = [
  ...writeEntitlements,
  ...teamManagerEntitlements,
  {
    application: {
      id: appId,
    },
    code: 'eztrac-admin-user',
  },
];

export function stubGetEntitlementsForUser() {
  const sandbox = sinon.createSandbox();
  const getEntitlements = sandbox.stub(papiClient, 'getEntitlementsForUser');
  getEntitlements.withArgs(invalidUser, [appId]).resolves([]);
  getEntitlements.withArgs(adminUser, [appId]).resolves(adminEntitlements);
  getEntitlements.withArgs(writeUser, [appId]).resolves(writeEntitlements);
  getEntitlements.withArgs(teamManagerUser, [appId]).resolves(teamManagerEntitlements);
}
