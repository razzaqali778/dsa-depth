import {IDatabase} from 'pg-promise';
import moment from 'moment';
import {TimeFrame} from 'src/api/timeframe/models';
import {Effort, EffortMember} from 'src/api/effort/models';
import {EffortAllocation} from 'src/api/effort/allocation/models';
import {Team} from 'src/api/team/models';

export const orgs = [
  {id: 'DTCS', name: 'DTCS Org', isActive: true},
  {id: 'TANDE', name: 'T&E Org', isActive: true},
  {id: 'PHARMA', name: 'Pharma', isActive: true},
  {id: 'CONSUMER-HEALTH', name: 'Consumer Health', isActive: true},
  {id: 'INACTIVE-ORG', name: 'Inactive Org', isActive: false},
];

export const platforms = [
  {id: 'FLINTSTONE-PLATFORM', name: 'Flintstone Platform', isActive: true, orgId: orgs[0].id},
  {id: 'JETSONS-PLATFORM', name: 'Jetsons Platform', isActive: true, orgId: orgs[1].id},
  {id: 'INACTIVE-PLATFORM', name: 'Old Platform', isActive: false, orgId: orgs[1].id},
];

export const communities = [
  {
    id: 'WILMA-COMMUNITY',
    name: 'Wilma Community',
    isActive: true,
    platformId: platforms[0].id,
  },
  {
    id: 'BETTY-COMMUNITY',
    name: 'Betty Community',
    isActive: true,
    platformId: platforms[1].id,
  },
  {
    id: 'INACTIVE-COMMUNITY',
    name: 'Old community',
    isActive: false,
    platformId: platforms[2].id,
  },
];

export const [team1Name, team1Id] = ['Rod dev team', 'ROD-DEV-TEAM'];

export const teams = [
  {
    id: team1Id,
    name: team1Name,
    isActive: true,
    communityId: communities[0].id,
  },
  {
    id: 'RICOCHET-DEV-TEAM',
    name: 'Ricochet',
    isActive: true,
    communityId: communities[1].id,
  },
  {
    id: 'TEAM-ROCKET-DEV-TEAM',
    name: 'Team Rocket',
    isActive: false,
    communityId: communities[1].id,
  },
];

export const persons = [
  {id: 'GNPGQ', name: 'Pat Gaffney'},
  {id: 'PRGAFF', name: 'Graham'},
  {id: 'NVSADO', name: 'Nat Attack'},
  {id: 'TJSIM', name: 'Thomas'},
];

function changeTimezoneToUtc(date: Date): Date {
  return new Date(
    Date.UTC(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      date.getHours(),
      date.getMinutes(),
      date.getSeconds(),
      date.getMilliseconds()
    )
  );
}

export const getTimeFrameStartAndEndDate = (date: Date) => {
  const utcDate = changeTimezoneToUtc(date);
  const startDate = new Date(utcDate);
  const endDate = new Date(utcDate);
  startDate.setDate(1);
  endDate.setMonth(endDate.getMonth() + 1);
  endDate.setDate(0);
  return {
    startDate: startDate,
    endDate: endDate,
  };
};

const addYears = (date: Date, years: number) =>
  new Date(date.getFullYear() + years, date.getMonth(), 1);

export const addMonths = (date: Date, months: number) =>
  new Date(date.getFullYear(), date.getMonth() + months, 1);

export const pastTimeFrame: TimeFrame = {
  id: BigInt(1),
  name: 'This month last year',
  lockdown: true,
  isActive: true,
  ...getTimeFrameStartAndEndDate(addYears(new Date(), -1)),
};

export const inActiveTimeFrame: TimeFrame = {
  id: BigInt(2),
  name: 'Very old time frame',
  lockdown: true,
  isActive: false,
  ...getTimeFrameStartAndEndDate(addYears(new Date(), -2)),
};

export const currentTimeFrame: TimeFrame = {
  id: BigInt(3),
  name: 'Current time frame',
  lockdown: false,
  isActive: true,
  ...getTimeFrameStartAndEndDate(new Date()),
};

export const futureTimeFrame: TimeFrame = {
  id: BigInt(4),
  name: 'This month next year',
  lockdown: false,
  isActive: true,
  ...getTimeFrameStartAndEndDate(addYears(new Date(), 1)),
};

export const timeFrames = [inActiveTimeFrame, pastTimeFrame, currentTimeFrame, futureTimeFrame];

export const efforts: Effort[] = [
  {
    id: BigInt(1),
    timeFrameId: currentTimeFrame.id,
    teamId: teams[0].id,
    cost: 100n,
  },
  {
    id: BigInt(2),
    timeFrameId: currentTimeFrame.id,
    teamId: teams[1].id,
    cost: 200n,
  },
  {
    id: BigInt(3),
    timeFrameId: futureTimeFrame.id,
    teamId: teams[0].id,
    cost: 300n,
  },
  {
    id: BigInt(4),
    timeFrameId: futureTimeFrame.id,
    teamId: teams[1].id,
    cost: 0n,
  },
  {id: BigInt(5), timeFrameId: pastTimeFrame.id, teamId: teams[0].id, cost: 0n},
];

export const effortMembers = [
  {effortId: efforts[0].id, userId: persons[0].id, percent: 100},
  {effortId: efforts[0].id, userId: persons[1].id, percent: 100},
  {effortId: efforts[1].id, userId: persons[3].id, percent: 50},
  {effortId: efforts[4].id, userId: persons[3].id, percent: 100},
];

export const effortAllocations = [
  {
    effortId: efforts[0].id,
    percentageOfTeamCost: BigInt(50),
    initiativeId: 'vipInitiativeId1',
  },
  {
    effortId: efforts[0].id,
    percentageOfTeamCost: BigInt(50),
    initiativeId: 'vipInitiativeId2',
  },
  {
    effortId: efforts[1].id,
    percentageOfTeamCost: BigInt(100),
    initiativeId: 'vipInitiativeId3',
  },
  {
    effortId: efforts[2].id,
    percentageOfTeamCost: BigInt(90),
    initiativeId: 'vipInitiativeId4',
  },
  {
    effortId: efforts[2].id,
    percentageOfTeamCost: BigInt(10),
    initiativeId: 'vipInitiativeId5',
  },
  {
    effortId: efforts[3].id,
    percentageOfTeamCost: BigInt(100),
    initiativeId: 'vipInitiativeId6',
  },
];

export const effortEngagements = [
  {effortId: efforts[0].id, amount: 100, engagementId: 'engagement1'},
  {effortId: efforts[1].id, amount: 1000, engagementId: 'engagement1'},
  {effortId: efforts[2].id, amount: 200, engagementId: 'engagement2'},
  {effortId: efforts[3].id, amount: 2000, engagementId: 'engagement2'},
];

const costGroups = ['PE-PRODUCT-DEVELOPMENT', 'PE-PRODUCT-DEVELOPMENT2', 'PE-PRODUCT-DEVELOPMENT3'];

export const effortCostBreakdowns = [
  {
    effortId: efforts[0].id,
    costGroupId: costGroups[0],
    cost: 1901,
    personId: null,
    engagementId: effortEngagements[0].engagementId,
  },
  {
    effortId: efforts[0].id,
    costGroupId: costGroups[1],
    cost: 1701,
    personId: effortMembers[0].userId,
    engagementId: null,
  },
  {
    effortId: efforts[1].id,
    costGroupId: costGroups[2],
    cost: 1201,
    personId: effortMembers[2].userId,
    engagementId: null,
  },
  {
    effortId: efforts[2].id,
    costGroupId: costGroups[0],
    cost: 1911,
    personId: null,
    engagementId: effortEngagements[2].engagementId,
  },
  {
    effortId: efforts[3].id,
    costGroupId: costGroups[2],
    cost: 901,
    personId: null,
    engagementId: effortEngagements[3].engagementId,
  },
];

export const forecastPersons = [
  {
    effortId: efforts[2].id,
    peopleNumber: 2,
    costGroupId: costGroups[0],
    rateId: 'STANDARD',
  },
  {
    effortId: efforts[2].id,
    peopleNumber: 1,
    costGroupId: costGroups[1],
    rateId: 'SOUTH-AMERICA',
  },
  {
    effortId: efforts[2].id,
    peopleNumber: 3,
    costGroupId: costGroups[2],
    rateId: 'STANDARD',
  },
  {
    effortId: efforts[1].id,
    peopleNumber: 2.5,
    costGroupId: costGroups[0],
    rateId: 'STANDARD',
  },
];

const getDateString = (date: Date | string, day: number) =>
  moment(date).clone().add(day, 'days').format('YYYY-MM-DD');

const getWorkdayHours = (date: Date | string) => {
  const workdDaysHours = [
    {day: getDateString(date, 2), hours: 24},
    {day: getDateString(date, 7), hours: 20},
    {day: getDateString(date, 9), hours: 16},
    {day: getDateString(date, 12), hours: 24},
    {day: getDateString(date, 13), hours: 24},
    {day: getDateString(date, 23), hours: 16},
    {day: getDateString(date, 28), hours: 20},
  ];
  return JSON.stringify(workdDaysHours);
};

const workdays = timeFrames
  .filter(tf => tf.id !== inActiveTimeFrame.id)
  .map(tf => ({
    timeframeId: tf.id,
    country: 'US',
    workdayHours: getWorkdayHours(tf.startDate),
  }));

const orgQuery =
  'INSERT INTO public.org (org_id, org_name, is_active) VALUES (${id}, ${name}, ${isActive})';

const platformQuery =
  'INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES (${id}, ${name}, ${isActive}, ${orgId})';

const communityQuery =
  'INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES (${id}, ${name}, ${isActive}, ${platformId})';

const teamQuery =
  'INSERT INTO public.team (team_id, team_name, is_active, community_id) VALUES (${id}, ${name}, ${isActive}, ${communityId})';

const timeFrameQuery =
  'INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES ($<id>, $<name>, $<startDate>, $<endDate>, $<lockdown>, $<isActive>)';

const personQuery = 'INSERT INTO public.person (user_id, name) VALUES (${id}, ${name})';

const effortsQuery =
  'INSERT INTO public.team_cost (team_cost_id, timeframe_id, team_id, cost) VALUES (${id}, ${timeFrameId}, ${teamId}, ${cost})';

const effortMemberQuery =
  'INSERT INTO public.team_cost_member (user_id, team_cost_id, participation_pct) VALUES (${userId}, ${effortId}, ${percent})';

const effortAllocationQuery =
  'INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (${effortId}, ${percentageOfTeamCost}, ${initiativeId})';

const effortEngagementsQuery =
  'INSERT INTO public.team_cost_engagement (team_cost_id, amount, engagement_id) VALUES (${effortId}, ${amount}, ${engagementId})';

const effortCostBreakdownQuery =
  'INSERT INTO public.team_cost_breakdown (team_cost_id, cost_group_id, cost, person_id, engagement_id) VALUES (${effortId}, ${costGroupId}, ${cost}, ${personId}, ${engagementId})';

const forecastPersonsQuery =
  'INSERT INTO public.forecast_person (team_cost_id, people_number, external_rate_id, cost_group_id) VALUES (${effortId}, ${peopleNumber}, ${rateId}, ${costGroupId})';

const workdayHoursQuery =
  'INSERT INTO public.timeframe_workdays (timeframe_id, country, workday_hours) VALUES (${timeframeId}, ${country}, ${workdayHours})';

export async function seedData(db: IDatabase<{}>) {
  await db.tx(t => {
    const queries = orgs
      .map(o => t.none(orgQuery, o))
      .concat(
        platforms.map(p => t.none(platformQuery, p)),
        communities.map(c => t.none(communityQuery, c)),
        timeFrames.map(tf => t.none(timeFrameQuery, tf)),
        teams.map(team => t.none(teamQuery, team)),
        persons.map(p => t.none(personQuery, p)),
        efforts.map(e => t.none(effortsQuery, e)),
        effortMembers.map(em => t.none(effortMemberQuery, em)),
        effortAllocations.map(ea => t.none(effortAllocationQuery, ea)),
        effortEngagements.map(ee => t.none(effortEngagementsQuery, ee)),
        effortCostBreakdowns.map(ecb => t.none(effortCostBreakdownQuery, ecb)),
        forecastPersons.map(fp => t.none(forecastPersonsQuery, fp)),
        workdays.map(d => t.none(workdayHoursQuery, d))
      );
    return t.batch(queries);
  });
}

export async function seedTimeFrames(db: IDatabase<{}>, timeFrames: TimeFrame[]) {
  await db.tx(t => {
    const queries = timeFrames.map(tf => t.none(timeFrameQuery, tf));
    return t.batch(queries);
  });
}

export async function seedEfforts(db: IDatabase<{}>, efforts: Effort[]) {
  await db.tx(t => {
    const queries = efforts.map(e => t.none(effortsQuery, e));
    return t.batch(queries);
  });
}

export async function seedTeams(db: IDatabase<{}>, teams: Team[]) {
  await db.tx(t => {
    const queries = teams.map(team => t.none(teamQuery, team));
    return t.batch(queries);
  });
}

export async function seedPersons(db: IDatabase<{}>, persons: {id: string; name: string}[]) {
  await db.tx(t => {
    const queries = persons.map(p => t.none(personQuery, p));
    return t.batch(queries);
  });
}

export async function seedEffortMembers(db: IDatabase<{}>, effortMembers: Partial<EffortMember>[]) {
  await db.tx(t => {
    const queries = effortMembers.map(em => t.none(effortMemberQuery, em));
    return t.batch(queries);
  });
}

export async function seedEffortAllocations(
  db: IDatabase<{}>,
  effortAllocations: Partial<EffortAllocation>[]
) {
  await db.tx(t => {
    const queries = effortAllocations.map(ea => t.none(effortAllocationQuery, ea));
    return t.batch(queries);
  });
}

export const testData = {
  orgs,
  platforms,
  communities,
  timeFrames,
  teams,
  persons,
  efforts,
  effortMembers,
  effortAllocations,
  effortEngagements,
  effortCostBreakdowns,
  forecastPersons,
  workdays,
};
