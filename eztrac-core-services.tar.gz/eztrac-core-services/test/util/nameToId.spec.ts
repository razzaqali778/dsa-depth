import {expect} from 'chai';
import {NameToId} from '../../src/util/nameToId';

describe('Name to id function', () => {
  it('removes multiple white spaces', () => {
    const name = '  test white    spaces ';
    const id = NameToId(name);
    expect(id).to.eq('TEST-WHITE-SPACES');
  });
  it('removes defined characters', () => {
    const name = '~~name-  !#?test~!@#$%^&*?=';
    const id = NameToId(name);
    expect(id).to.eq('NAME-TEST');
  });
  it('replaces defined characters with hyphen', () => {
    const name = "_a:~b;c+d.e,f(g)h{i} j[k]l<m>n|o'p`q/r\\";
    const id = NameToId(name);
    expect(id).to.eq('A-B-C-D-E-F-G-H-I-J-K-L-M-N-O-P-Q-R');
  });
  it('returns empty string when name consists only of characters to be removed or replaced', () => {
    const name = '!#  ||';
    const id = NameToId(name);
    expect(id).to.eq('');
  });
});
