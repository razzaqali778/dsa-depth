const prepare = require('mocha-prepare')
import config from '../src/config/index'
import { stubGetEntitlementsForUser } from './common/papiClientStub';
import { setupIntegrationTestDatabase } from '../integrationTests/db/setupTestDatabase'
const {setupCoreDatabase} = require("./common/databaseSetup");

// mocha-prepare adds hooks for asynchronous setup. This allows the config library to
// initalize from multiple sources and processors prior to the test suite
// See: https://config.phoenix-tools-np.io/testing/
prepare(
    async (done) => {
        config
            .init()
            .then(async () => {
                if (process.env.NODE_ENV === 'integration-test') {
                    await setupIntegrationTestDatabase()
                } else {
                    await setupCoreDatabase()
                }
                done()
            })
            .catch(done) // pass the error along so the call-stack shows what's up.
        stubGetEntitlementsForUser()
    }
)
