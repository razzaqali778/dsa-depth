const chai = require('chai')
const chaiAsPromised = require('chai-as-promised')
const sinon = require('sinon')
const sinonChai = require('sinon-chai')

// example of using the should DSL without having to import it anywhere
// see chai docs
global.should = chai.should()
chai.use(chaiAsPromised)
chai.use(sinonChai)
chai.use(require('chai-things'));
global.sinon = sinon
sinon.useFakeTimers({
  now: new Date(2023, 10, 13, 0, 0),
  shouldAdvanceTime: true,
  toFake: ['Date'],
});
