import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';
import chai from 'chai';
import * as core from 'express-serve-static-core';
import {StatusCodes} from 'http-status-codes';
import supertest from 'supertest';
import {HTTPError} from 'superagent';
import {DEFAULT_USER_HEADER} from '../../common/HttpConstants';
import {currentTimeFrame, effortCostBreakdowns, efforts} from '../../common/dataSeed';
import {EffortSpending} from 'src/api/spend/spendService';

chai.use(require('chai-as-promised'));

describe('Spend route', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Returns spend for efforts in time range', async () => {
    function getSpendSum(effortSpending: EffortSpending) {
      return effortSpending.initiatives.reduce((sum, current) => sum + Number(current.spend), 0);
    }
    const startTimeFrame = currentTimeFrame.id;
    const endTimeFrame = currentTimeFrame.id;
    const response = await supertest(app)
      .get(`/spend/startTimeFrame/${startTimeFrame}/endTimeFrame/${endTimeFrame}`)
      .set(DEFAULT_USER_HEADER);
    const effortSpending: EffortSpending[] = response.body;
    const effortSpendSum1 = getSpendSum(effortSpending[0]);
    const effortSpendSum2 = getSpendSum(effortSpending[1]);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(effortSpending[0].teamId).to.eq(efforts[0].teamId);
    expect(effortSpending[0].timeFrameId).to.eq(Number(efforts[0].timeFrameId));
    expect(effortSpending[1].teamId).to.eq(efforts[1].teamId);
    expect(effortSpending[1].timeFrameId).to.eq(Number(efforts[1].timeFrameId));
    expect(effortSpendSum1).to.eq(
      (Math.round(Number(effortCostBreakdowns[0].cost) / 2) +
        Math.round(Number(effortCostBreakdowns[1].cost) / 2)) *
        2
    );
    expect(effortSpendSum2).to.eq(effortCostBreakdowns[2].cost);
  });

  it('Throws error when start time frame params are not valid', async () => {
    const startTimeFrame = 'abc';
    const endTimeFrame = '123';
    const response = await supertest(app)
      .get(`/spend/startTimeFrame/${startTimeFrame}/endTimeFrame/${endTimeFrame}`)
      .set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
    const error = response.error as HTTPError;
    expect(error.text).to.include('startTimeFrame');
  });

  it('Throws error when end time frame params are not valid', async () => {
    const startTimeFrame = '123';
    const endTimeFrame = '1 1 ';
    const response = await supertest(app)
      .get(`/spend/startTimeFrame/${startTimeFrame}/endTimeFrame/${endTimeFrame}`)
      .set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
    const error = response.error as HTTPError;
    expect(error.text).to.include('endTimeFrame');
  });
});
