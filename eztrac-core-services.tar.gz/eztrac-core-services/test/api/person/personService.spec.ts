import sinon from 'sinon';
import {personRepository} from '../../../src/api/person/personRepository';
import {papiClient} from '../../../src/util/client/papiClient';
import {getOrCreatePeople} from '../../../src/api/person/personService';

describe('Person service', () => {
  const sandbox = sinon.createSandbox();

  after(() => sandbox.restore());

  it('gets or creates correct people', async () => {
    // Arrange
    const localId = 'locallyExistingId';
    const papiId = 'idToGetFromPapi';
    const notExistingId = 'idNotExistingInPapi';
    const papiName = 'user from papi';
    const peopleIds = [localId, papiId, notExistingId];

    const createPersonStub = sandbox.stub(personRepository, 'createPerson');
    sandbox.stub(personRepository, 'getExistingPersons').resolves([localId]);
    sandbox
      .stub(papiClient, 'getUsersById')
      .resolves([{id: papiId, name: papiName, manager: {name: 'manager'}}]);

    // Act
    await getOrCreatePeople(peopleIds);

    // Assert
    sinon.assert.callCount(createPersonStub, 2);
    sinon.assert.calledWithExactly(createPersonStub.getCall(0), papiId, papiName);
    sinon.assert.calledWithExactly(createPersonStub.getCall(1), notExistingId, notExistingId);
  });
});
