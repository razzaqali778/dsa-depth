import {expect} from 'chai';
import {AppContext} from '../../../src/api/AppContext';
import {setupCoreDatabase} from '../../common/databaseSetup';
import {
  addMonths,
  getTimeFrameStartAndEndDate,
  seedEfforts,
  seedTeams,
  seedTimeFrames,
  teams,
  testData,
} from '../../common/dataSeed';
import {container} from 'tsyringe';
import chai from 'chai';
import {Effort} from '../../../src/api/effort/models';
import {TimeFrame} from '../../../src/api/timeframe/models';
import {updateTeam} from '../../../src/api/team/teamService';
import {Team} from '../../../src/api/team/models';
import {NotFoundError} from '../../../src/api/types/NotFoundError';
import {BadRequestError} from '../../../src/api/types/BadRequestError';
chai.use(require('chai-as-promised'));

describe('Team service', () => {
  const timeFrame: TimeFrame = {
    id: 7n,
    name: 'Time frame month ago',
    lockdown: false,
    isActive: true,
    ...getTimeFrameStartAndEndDate(addMonths(new Date(), -1)),
  };

  const team: Team = {
    id: 'teamId',
    name: 'team to be updated',
    isActive: true,
    communityId: testData.communities[0].id,
  };

  const effort: Effort = {
    id: BigInt(6),
    timeFrameId: timeFrame.id,
    teamId: team.id,
    cost: 0n,
  };

  before(async () => {
    await setupCoreDatabase();
  });

  it('throws notFoundError when team does not exist ', async () => {
    const updatedTeam: Team = {
      id: 'bad_id',
      communityId: 'community',
      isActive: true,
      name: 'not existing team',
    };
    await expect(updateTeam(updatedTeam.id, updatedTeam)).to.be.rejectedWith(NotFoundError);
  });
  it('throws BadRequestError when active team cannot be deactivated', async () => {
    const updatedTeam: Team = {
      ...teams[0],
      isActive: false,
    };
    await expect(updateTeam(updatedTeam.id, updatedTeam)).to.be.rejectedWith(BadRequestError);
  });
  it('updates team', async () => {
    const db = container.resolve(AppContext).db;
    await seedTimeFrames(db, [timeFrame]);
    await seedTeams(db, [team]);
    await seedEfforts(db, [effort]);
    const updatedTeam: Team = {
      id: team.id,
      name: 'updated name',
      communityId: testData.communities[1].id,
      isActive: false,
    };
    const result = await updateTeam(updatedTeam.id, updatedTeam);
    expect(result).to.deep.eq(updatedTeam);
  });
});
