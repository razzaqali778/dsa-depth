import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';

import chai from 'chai';
import * as core from 'express-serve-static-core';
import {StatusCodes} from 'http-status-codes';
import {teamManagerUserHeader, unauthorizedUserHeader} from '../../common/HttpConstants';
import {teams, testData} from '../../common/dataSeed';
import supertest from 'supertest';
import {CreateTeamModel, Team} from '../../../src/api/team/models';

chai.use(require('chai-as-promised'));

describe('Team route post', () => {
  let app: core.Express;

  const teamToCreate: CreateTeamModel = {
    name: 'new team',
    communityId: testData.communities[0].id,
    isActive: true,
  };

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Creates team', async () => {
    const response = await supertest(app)
      .post('/team')
      .set(teamManagerUserHeader)
      .send(teamToCreate);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const team: Team = response.body;
    expect(team).to.deep.eq({id: 'NEW-TEAM', ...teamToCreate});
  });

  it('Fails when team with given name already exists', async () => {
    const badNewTeam = {
      name: teams[0].name,
      communityId: testData.communities[0].id,
      isActive: true,
    };
    const response = await supertest(app).post('/team').set(teamManagerUserHeader).send(badNewTeam);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails when invalid team name is provided', async () => {
    const badNewTeam = {
      name: '@@@',
      communityId: testData.communities[0].id,
      isActive: true,
    };
    const response = await supertest(app).post('/team').set(teamManagerUserHeader).send(badNewTeam);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails when user is not authorized to create teams', async () => {
    const response = await supertest(app)
      .post('/team')
      .set(unauthorizedUserHeader)
      .send(teamToCreate);
    expect(response.statusCode).to.eq(StatusCodes.FORBIDDEN);
  });

  it('Fails when empty body object is provided', async () => {
    const response = await supertest(app).post('/team').set(teamManagerUserHeader).send({});
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails when invalid body object is provided', async () => {
    const response = await supertest(app).post('/team').set(teamManagerUserHeader).send({
      teamId: 'not right',
      teamName: 'wrong properties',
    });
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
