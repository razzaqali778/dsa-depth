import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';

import chai from 'chai';
import * as core from 'express-serve-static-core';
import {StatusCodes} from 'http-status-codes';
import {teamManagerUserHeader, unauthorizedUserHeader} from '../../common/HttpConstants';
import {team1Id, teams} from '../../common/dataSeed';
import supertest from 'supertest';
import {Team} from '../../../src/api/team/models';

chai.use(require('chai-as-promised'));

describe('Team route put', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Updates team by id', async () => {
    const updatedTeam: Team = {
      ...teams[0],
      name: 'updated name',
    };
    const response = await supertest(app)
      .put(`/team/${updatedTeam.id}`)
      .set(teamManagerUserHeader)
      .send(updatedTeam);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const team: Team = response.body;
    expect(team).to.deep.eq(updatedTeam);
  });

  it('Fails when user is not authorized to modify teams', async () => {
    const response = await supertest(app)
      .put(`/team/${team1Id}`)
      .set(unauthorizedUserHeader)
      .send(teams[0]);
    expect(response.statusCode).to.eq(StatusCodes.FORBIDDEN);
  });

  it('Fails when empty body object is provided', async () => {
    const response = await supertest(app)
      .put(`/team/${team1Id}`)
      .set(teamManagerUserHeader)
      .send({});
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails when invalid body object is provided', async () => {
    const response = await supertest(app).put(`/team/${team1Id}`).set(teamManagerUserHeader).send({
      teamId: 'not right',
      teamName: 'wrong properties',
    });
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
