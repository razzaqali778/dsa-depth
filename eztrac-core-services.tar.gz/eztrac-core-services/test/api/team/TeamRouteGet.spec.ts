import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';

import chai from 'chai';
import * as core from 'express-serve-static-core';
import {StatusCodes} from 'http-status-codes';
import {
  APPLICATION_JSON_WITH_CHARSET,
  CONTENT_TYPE,
  DEFAULT_USER_HEADER,
} from '../../common/HttpConstants';
import {team1Id, teams, teams as testTeams} from '../../common/dataSeed';
import _ from 'lodash';
import supertest from 'supertest';
import {TeamStructure, Team} from 'src/api/team/models';

chai.use(require('chai-as-promised'));

const isTeamStructure = function (ts: TeamStructure) {
  return (
    ts.teamId &&
    ts.teamName &&
    ts.communityName &&
    ts.communityId &&
    ts.platformName &&
    ts.platformId &&
    ts.orgName &&
    ts.orgId
  );
};

describe('Team route', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Returns all teams from database', async () => {
    const response = await supertest(app).get('/teams').set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
    const body: Team[] = response.body;
    expect(body.length).to.eq(testTeams.length);
  });

  it('Returns active teams', async () => {
    const response = await supertest(app).get('/teams?q').set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
    const body: Team[] = response.body;
    expect(body.length).to.deep.eq(testTeams.filter(t => t.isActive).length);
  });

  it('Returns active teams starting with Ri', async () => {
    const teamFilterString = 'Ri';
    const expectedLength = testTeams.filter(
      t => t.isActive && t.name.includes(teamFilterString)
    ).length;
    const response = await supertest(app)
      .get(`/teams?q=${teamFilterString}`)
      .set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
    const body: Team[] = response.body;
    expect(body.length).to.eq(expectedLength);
  });

  it('Returns inactive teams', async () => {
    const response = await supertest(app).get('/teams?isActive=false').set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
    const body: Team[] = response.body;
    expect(body.length).to.deep.eq(testTeams.filter(t => !t.isActive).length);
  });

  it('Returns teams with organizational detail', async () => {
    const response = await supertest(app).get('/teamStructure').set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
    const resultTeamStructures: TeamStructure[] = response.body;
    expect(resultTeamStructures.length).to.eq(testTeams.length);
    expect(_.every(resultTeamStructures, (ts: TeamStructure) => isTeamStructure(ts))).to.be.true;
  });

  it('Returns team by id', async () => {
    const response = await supertest(app).get(`/team/${team1Id}`).set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const team: Team = response.body;
    expect(team).to.deep.eq(teams[0]);
  });

  it('Fails when invalid q query parameters are provided', async () => {
    const response = await supertest(app).get('/teams?q=abc&q=123').set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails when invalid isActive query parameter is provided', async () => {
    const response = await supertest(app).get('/teams?isActive=notBool').set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
