import * as core from 'express-serve-static-core';
import {setupCoreDatabase} from '../../common/databaseSetup';
import supertest from 'supertest';
import {adminUserHeader} from '../../common/HttpConstants';
import {expect} from 'chai';
import {StatusCodes} from 'http-status-codes';
import {Community} from '../../../src/api/community/models';
import {testData} from '../../common/dataSeed';

describe('Communities POST', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Creates a new community', async () => {
    const newCommunity = {
      name: 'New Community',
      isActive: true,
      platformId: testData.platforms[0].id,
    };
    const response = await supertest(app)
      .post('/communities')
      .set(adminUserHeader)
      .send(newCommunity);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const community: Community = response.body;
    expect(community.name).to.eq(newCommunity.name);
    expect(community.isActive).to.eq(newCommunity.isActive);
    expect(community.platformId).to.eq(newCommunity.platformId);
  });

  it('Fails to create a community with missing fields', async () => {
    const incompleteCommunity = {
      name: 'Incomplete Community',
    };
    const response = await supertest(app)
      .post('/communities')
      .set(adminUserHeader)
      .send(incompleteCommunity);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails to create a community with non existent platform id', async () => {
    const invalidCommunity = {
      name: 'Community with invalid platform',
      isActive: true,
      platformId: 'non-existent-platform',
    };
    const response = await supertest(app)
      .post('/communities')
      .set(adminUserHeader)
      .send(invalidCommunity);
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
  });

  it('Fails to create a community with invalid data', async () => {
    const invalidCommunity = {
      name: 'Invalid Community',
      isActive: 'not-a-boolean',
      platformId: 'non-existent-platform',
    };
    const response = await supertest(app)
      .post('/communities')
      .set(adminUserHeader)
      .send(invalidCommunity);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails to create a community with existing id', async () => {
    const existingCommunity = {
      name: testData.communities[0].name,
      isActive: true,
      platformId: testData.platforms[0].id,
    };
    const response = await supertest(app)
      .post('/communities')
      .set(adminUserHeader)
      .send(existingCommunity);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
