import * as core from 'express-serve-static-core';
import {setupCoreDatabase} from '../../common/databaseSetup';
import supertest from 'supertest';
import {adminUserHeader} from '../../common/HttpConstants';
import {expect} from 'chai';
import {StatusCodes} from 'http-status-codes';
import {Community} from '../../../src/api/community/models';
import {testData} from '../../common/dataSeed';

describe('Communities PUT', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Updates an existing community', async () => {
    const updatedCommunity = {
      name: 'Updated Community',
      isActive: false,
      platformId: testData.platforms[0].id,
    };
    const response = await supertest(app)
      .put(`/communities/${testData.communities[0].id}`)
      .set(adminUserHeader)
      .send(updatedCommunity);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const community: Community = response.body;
    expect(community.name).to.eq(updatedCommunity.name);
    expect(community.isActive).to.eq(updatedCommunity.isActive);
    expect(community.platformId).to.eq(updatedCommunity.platformId);
  });

  it('Fails to update a community with invalid data', async () => {
    const invalidCommunity = {
      name: 'Invalid Community',
      isActive: 'not-a-boolean',
      platformId: 'non-existent-platform',
    };
    const response = await supertest(app)
      .put(`/communities/${testData.communities[0].id}`)
      .set(adminUserHeader)
      .send(invalidCommunity);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails to update a non-existent community', async () => {
    const updatedCommunity = {
      name: 'Non-existent Community',
      isActive: true,
      platformId: testData.platforms[0].id,
    };
    const response = await supertest(app)
      .put('/communities/non-existent-id')
      .set(adminUserHeader)
      .send(updatedCommunity);
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
  });

  it('Fails to update a community with missing fields', async () => {
    const incompleteCommunity = {
      name: 'Incomplete Community',
    };
    const response = await supertest(app)
      .put(`/communities/${testData.communities[0].id}`)
      .set(adminUserHeader)
      .send(incompleteCommunity);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
