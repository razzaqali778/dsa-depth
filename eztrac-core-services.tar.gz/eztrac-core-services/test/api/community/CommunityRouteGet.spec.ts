import * as core from 'express-serve-static-core';
import {setupCoreDatabase} from '../../common/databaseSetup';
import supertest from 'supertest';
import {unauthorizedUserHeader} from '../../common/HttpConstants';
import {expect} from 'chai';
import {StatusCodes} from 'http-status-codes';
import {Community} from '../../../src/api/community/models';
import {testData} from '../../common/dataSeed';

describe('Communities GET', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Returns all communities', async () => {
    const response = await supertest(app).get('/communities').set(unauthorizedUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const communities: Community[] = response.body;
    expect(communities.length).to.eq(testData.communities.length);
  });

  it('Does no return communities with invalid active filter', async () => {
    const response = await supertest(app)
      .get('/communities?isActive=xxx')
      .set(unauthorizedUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Returns communities with active filter true', async () => {
    const response = await supertest(app)
      .get('/communities?isActive=true')
      .set(unauthorizedUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const communities: Community[] = response.body;
    expect(communities.length).to.eq(2);
  });

  it('Returns communities with active filter false', async () => {
    const response = await supertest(app)
      .get('/communities?isActive=false')
      .set(unauthorizedUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const communities: Community[] = response.body;
    expect(communities.length).to.eq(1);
    expect(communities[0].id).to.eq('INACTIVE-COMMUNITY');
  });

  it('Returns all communities with both filters', async () => {
    const response = await supertest(app)
      .get(`/communities?isActive=false&platformId=${testData.platforms[2].id}`)
      .set(unauthorizedUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const communities: Community[] = response.body;
    expect(communities.length).to.eq(1);
    expect(communities[0].id).to.eq('INACTIVE-COMMUNITY');
  });

  it('All communities with both filters returning no values', async () => {
    const response = await supertest(app)
      .get(`/communities?isActive=false&platformId=${testData.platforms[1].id}`)
      .set(unauthorizedUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const communities: Community[] = response.body;
    expect(communities.length).to.eq(0);
  });

  it('Returns all communities with platform filter', async () => {
    const response = await supertest(app)
      .get(`/communities?platformId=${testData.platforms[0].id}`)
      .set(unauthorizedUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const communities: Community[] = response.body;
    expect(communities.length).to.eq(1);
    expect(communities[0].id).to.eq('WILMA-COMMUNITY');
  });

  it('Returns no communities with invalid platform filter', async () => {
    const response = await supertest(app)
      .get('/communities?platformId=199')
      .set(unauthorizedUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const communities: Community[] = response.body;
    expect(communities.length).to.eq(0);
  });
});
