import {expect} from 'chai';
import supertest from 'supertest';
import * as core from 'express-serve-static-core';
import {setupCoreDatabase} from '../../common/databaseSetup';
import {testData} from '../../common/dataSeed';
import {unauthorizedUserHeader} from '../../common/HttpConstants';

describe('Org API', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  describe('GET /orgs', () => {
    it('should return all orgs when isActive filter is not provided', async () => {
      const response = await supertest(app).get('/orgs').set(unauthorizedUserHeader);

      expect(response.status).to.equal(200);
      expect(response.body).to.deep.equal(testData.orgs);
    });

    it('should return active orgs when isActive=true', async () => {
      const response = await supertest(app).get('/orgs?isActive=true').set(unauthorizedUserHeader);

      expect(response.status).to.equal(200);
      expect(response.body).to.deep.equal(testData.orgs.filter(org => org.isActive));
    });

    it('should return inactive orgs when isActive=false', async () => {
      const response = await supertest(app).get('/orgs?isActive=false').set(unauthorizedUserHeader);

      expect(response.status).to.equal(200);
      expect(response.body).to.deep.equal(testData.orgs.filter(org => !org.isActive));
    });
  });
});
