import {expect} from 'chai';
import {container} from 'tsyringe';
import sinon from 'sinon';
import {AppContext} from '../../../src/api/AppContext';
import {NotFoundError} from '../../../src/api/types/NotFoundError';
import * as orgService from '../../../src/api/org/orgService';
import {Org, OrgId} from '../../../src/api/org/models';
import {OrgRepository} from 'src/api/org/orgRepository';

describe('orgService', () => {
  let sandbox: sinon.SinonSandbox;
  let orgRepositoryStub: sinon.SinonStubbedInstance<OrgRepository>;
  let appContextStub: sinon.SinonStubbedInstance<AppContext>;

  beforeEach(() => {
    sandbox = sinon.createSandbox();
    orgRepositoryStub = {
      getOrgById: sandbox.stub(),
      getOrgs: sandbox.stub(),
    };
    appContextStub = {
      repositories: {
        orgRepository: orgRepositoryStub,
      },
    } as unknown as sinon.SinonStubbedInstance<AppContext>;
    sandbox.stub(container, 'resolve').returns(appContextStub);
  });

  afterEach(() => {
    sandbox.restore();
  });

  describe('getOrgByIdOrThrow', () => {
    it('should return the org when found', async () => {
      const orgId: OrgId = '123';
      const expectedOrg: Org = {id: orgId, name: 'Test Org', isActive: true};
      orgRepositoryStub.getOrgById.resolves(expectedOrg);

      const result = await orgService.getOrgByIdOrThrow(orgId);

      expect(result).to.equal(expectedOrg);
      expect(orgRepositoryStub.getOrgById.calledOnceWith(orgId)).to.be.true;
    });

    it('should throw NotFoundError when org is not found', async () => {
      const orgId: OrgId = '123';
      orgRepositoryStub.getOrgById.resolves(null);

      try {
        await orgService.getOrgByIdOrThrow(orgId);
        expect.fail('Expected NotFoundError to be thrown');
      } catch (error) {
        expect(error).to.be.instanceOf(NotFoundError);
        expect((error as NotFoundError).message).to.equal(`Unable to find org with id of ${orgId}`);
      }

      expect(orgRepositoryStub.getOrgById.calledOnceWith(orgId)).to.be.true;
    });
  });
});
