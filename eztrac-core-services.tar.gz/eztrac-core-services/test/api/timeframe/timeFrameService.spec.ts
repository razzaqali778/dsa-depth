import sinon from 'sinon';
import {timeFrameRepository} from '../../../src/api/timeframe/timeFrameRepository';
import {expect} from 'chai';
import {validateTimeFrameRange} from '../../../src/api/timeframe/timeFrameService';
import chai from 'chai';
chai.use(require('chai-as-promised'));

describe('Time frame service', () => {
  describe('validateTimeFrameRange', () => {
    const startTimeFrameId = 42301n;
    const endTimeFrameId = 42312n;

    const sandbox = sinon.createSandbox();

    afterEach(() => sandbox.restore());

    it('throws error when start time frame does not exist', () => {
      // Arrange
      sandbox.stub(timeFrameRepository, 'getTimeFrameById').resolves(null);

      // Act
      const validationResult = validateTimeFrameRange(startTimeFrameId, endTimeFrameId);

      // Assert
      expect(validationResult).to.be.rejectedWith(
        `Unable to find time frame with id of ${startTimeFrameId}`
      );
    });

    it('throws error when end time frame does not exist', () => {
      // Arrange
      const stub = sandbox.stub(timeFrameRepository, 'getTimeFrameById');
      stub.onFirstCall().resolves({
        id: startTimeFrameId,
        name: 'time frame',
        startDate: new Date(),
        endDate: new Date(),
        lockdown: false,
        isActive: true,
      });
      stub.onSecondCall().resolves(null);

      // Act
      const validationResult = validateTimeFrameRange(startTimeFrameId, endTimeFrameId);

      // Assert
      expect(validationResult).to.be.rejectedWith(
        `Unable to find time frame with id of ${endTimeFrameId}`
      );
    });

    it('throws error when start time frame is after end time frame', () => {
      // Arrange
      const stub = sandbox.stub(timeFrameRepository, 'getTimeFrameById');
      stub.onFirstCall().resolves({
        id: startTimeFrameId,
        name: 'time frame',
        startDate: Date.parse('2023-11-01').toString(),
        endDate: Date.parse('2023-11-30').toString(),
        lockdown: false,
        isActive: true,
      });
      stub.onSecondCall().resolves({
        id: startTimeFrameId,
        name: 'time frame',
        startDate: Date.parse('2023-10-01').toString(),
        endDate: Date.parse('2023-10-31').toString(),
        lockdown: false,
        isActive: true,
      });

      // Act
      const validationResult = validateTimeFrameRange(startTimeFrameId, endTimeFrameId);

      // Assert
      expect(validationResult).to.be.rejectedWith('start time frame must be before end time frame');
    });

    it('does not throw error when time frames are valid', () => {
      // Arrange
      const stub = sandbox.stub(timeFrameRepository, 'getTimeFrameById');
      stub.onFirstCall().resolves({
        id: startTimeFrameId,
        name: 'time frame',
        startDate: Date.parse('2023-11-01').toString(),
        endDate: Date.parse('2023-11-30').toString(),
        lockdown: false,
        isActive: true,
      });
      stub.onSecondCall().resolves({
        id: startTimeFrameId,
        name: 'time frame',
        startDate: Date.parse('2023-12-01').toString(),
        endDate: Date.parse('2023-12-31').toString(),
        lockdown: false,
        isActive: true,
      });

      // Act
      const validationResult = validateTimeFrameRange(startTimeFrameId, endTimeFrameId);

      // Assert
      expect(validationResult).to.be.fulfilled;
    });
  });
});
