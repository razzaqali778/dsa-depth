import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';
import chai from 'chai';
import * as core from 'express-serve-static-core';
import {StatusCodes} from 'http-status-codes';
import {currentTimeFrame, futureTimeFrame, testData} from '../../common/dataSeed';
import supertest from 'supertest';
import {HTTPError} from 'superagent';
import {adminUserHeader, unauthorizedUserHeader} from '../../common/HttpConstants';
import {TimeFrame} from 'src/api/timeframe/models';

chai.use(require('chai-as-promised'));

describe('Time frames route', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Returns all time frames', async () => {
    const response = await supertest(app).get('/timeframes');
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const body: TimeFrame[] = response.body;
    expect(body.length).to.eq(testData.timeFrames.length);
  });

  it('Returns current time frame', async () => {
    const response = await supertest(app).get('/timeframes/current');
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const timeFrame: TimeFrame = response.body;
    expect(timeFrame.id).to.eq(Number(currentTimeFrame.id));
  });

  it('Return time frame by id', async () => {
    const response = await supertest(app).get(`/timeframes/${currentTimeFrame.id}`);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const timeFrame: TimeFrame = response.body;
    expect(timeFrame.id).to.eq(Number(currentTimeFrame.id));
  });

  it('Returns current time frame with offset', async () => {
    const offset = 12;
    const response = await supertest(app).get(`/timeframes/current/offset/${offset}`);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const timeFrame: TimeFrame = response.body;
    expect(timeFrame.id).to.eq(Number(futureTimeFrame.id));
  });

  it('Throws error when offset param is not valid int', async () => {
    const offset = '12 abc';
    const response = await supertest(app).get(`/timeframes/current/offset/${offset}`);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
    const error = response.error as HTTPError;
    expect(error.text).to.include('offset');
  });

  it('Throws error when time frame at given offset does not exist', async () => {
    const offset = 5;
    const response = await supertest(app).get(`/timeframes/current/offset/${offset}`);
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
    const error = response.error as HTTPError;
    expect(error.text).to.include(`Unable to find time frame at given offset ${offset}`);
  });
  it('Changes the lockdown status of time frame with given id', async () => {
    const lockdownStatus = true;
    const timeFrameId = currentTimeFrame.id;
    const response = await supertest(app)
      .patch(`/timeframes/${timeFrameId}`)
      .set(adminUserHeader)
      .send({lockdown: lockdownStatus});
    const getResponse = await supertest(app).get(`/timeframes/${currentTimeFrame.id}`);
    const updatedTimeFrame: TimeFrame = getResponse.body;

    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(updatedTimeFrame.lockdown).to.eq(lockdownStatus);
  });
  it('Fails to update lockdown status when body object is invalid', async () => {
    const lockdownStatus = 'invalidStatus';
    const timeFrameId = currentTimeFrame.id;
    const invalidStatusResponse = await supertest(app)
      .patch(`/timeframes/${timeFrameId}`)
      .set(adminUserHeader)
      .send({lockdown: lockdownStatus});
    expect(invalidStatusResponse.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
  it('Fails to update lockdown status when time frame is not found', async () => {
    const lockdownStatus = false;
    const timeFrameId = '111';
    const response = await supertest(app)
      .patch(`/timeframes/${timeFrameId}`)
      .set(adminUserHeader)
      .send({lockdown: lockdownStatus});
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
  });
  it('Fails to update lockdown status when user is not eztrac admin', async () => {
    const lockdownStatus = false;
    const timeFrameId = currentTimeFrame.id;
    const response = await supertest(app)
      .patch(`/timeframes/${timeFrameId}`)
      .set(unauthorizedUserHeader)
      .send({lockdown: lockdownStatus});
    expect(response.statusCode).to.eq(StatusCodes.FORBIDDEN);
  });
});
