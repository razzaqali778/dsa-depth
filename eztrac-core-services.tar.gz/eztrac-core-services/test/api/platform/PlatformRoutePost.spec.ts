import * as core from 'express-serve-static-core';
import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';
import supertest from 'supertest';
import {testData} from '../../common/dataSeed';
import {adminUserHeader} from '../../common/HttpConstants';
import {StatusCodes} from 'http-status-codes';
import {Platform} from '../../../src/api/platform/models';

describe('POST /api/platforms', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Creates a new platform', async () => {
    const newPlatform = {
      name: 'New Platform',
      isActive: true,
      orgId: testData.orgs[0].id,
    };
    const response = await supertest(app).post('/platforms').set(adminUserHeader).send(newPlatform);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const platform: Platform = response.body;
    expect(platform.name).to.eq(newPlatform.name);
    expect(platform.isActive).to.eq(newPlatform.isActive);
  });

  it('Fails to create a platform with missing fields', async () => {
    const incompletePlatform = {
      name: 'Incomplete Platform',
    };
    const response = await supertest(app)
      .post('/platforms')
      .set(adminUserHeader)
      .send(incompletePlatform);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails to create a platform with invalid data', async () => {
    const invalidPlatform = {
      name: 'Invalid Platform',
      isActive: 'not-a-boolean',
      orgId: testData.orgs[0].id,
    };
    const response = await supertest(app)
      .post('/platforms')
      .set(adminUserHeader)
      .send(invalidPlatform);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails to create a platform with non existent org id', async () => {
    const platformWithInvalidOrg = {
      name: 'Invalid Org',
      isActive: true,
      orgId: 'non-existent-org',
    };
    const response = await supertest(app)
      .post('/platforms')
      .set(adminUserHeader)
      .send(platformWithInvalidOrg);
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
  });

  it('Fails to create a platform with existing name', async () => {
    const existingPlatform = {
      name: testData.platforms[0].name,
      isActive: true,
      orgId: testData.orgs[0].id,
    };
    const response = await supertest(app)
      .post('/platforms')
      .set(adminUserHeader)
      .send(existingPlatform);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
