import * as core from 'express-serve-static-core';
import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';
import supertest from 'supertest';
import {testData} from '../../common/dataSeed';
import {adminUserHeader} from '../../common/HttpConstants';
import {StatusCodes} from 'http-status-codes';
import {Platform} from '../../../src/api/platform/models';

describe('PUT /api/platforms/:id', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Updates an existing platform', async () => {
    const updatedPlatform = {
      name: 'Updated Platform',
      isActive: false,
      orgId: testData.platforms[0].orgId,
    };
    const response = await supertest(app)
      .put(`/platforms/${testData.platforms[0].id}`)
      .set(adminUserHeader)
      .send(updatedPlatform);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    const platform: Platform = response.body;
    expect(platform.name).to.eq(updatedPlatform.name);
    expect(platform.isActive).to.eq(updatedPlatform.isActive);
  });

  it('Fails to update a platform with invalid data', async () => {
    const invalidPlatform = {
      name: 'Invalid Platform',
      isActive: 'not-a-boolean',
      orgId: testData.orgs[0].id,
    };
    const response = await supertest(app)
      .put(`/platforms/${testData.platforms[0].id}`)
      .set(adminUserHeader)
      .send(invalidPlatform);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Fails to update a non-existent platform', async () => {
    const updatedPlatform = {
      name: 'Non-existent Platform',
      isActive: true,
      orgId: testData.orgs[0].id,
    };
    const response = await supertest(app)
      .put('/platforms/non-existent-id')
      .set(adminUserHeader)
      .send(updatedPlatform);
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
  });

  it('Fails to update a platform with non-existent org', async () => {
    const updatedPlatform = {
      name: testData.platforms[0].name,
      isActive: true,
      orgId: 'non-existent-org',
    };
    const response = await supertest(app)
      .put(`/platforms/${testData.platforms[0].id}`)
      .set(adminUserHeader)
      .send(updatedPlatform);
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
  });

  it('Fails to update a platform with missing fields', async () => {
    const incompletePlatform = {
      name: 'Incomplete Platform',
    };
    const response = await supertest(app)
      .put(`/platforms/${testData.platforms[0].id}`)
      .set(adminUserHeader)
      .send(incompletePlatform);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
