import * as core from 'express-serve-static-core';
import {setupCoreDatabase} from '../../common/databaseSetup';
import supertest from 'supertest';

import {expect} from 'chai';
import {StatusCodes} from 'http-status-codes';
import {unauthorizedUserHeader} from '../../common/HttpConstants';
import {Platform} from '../../../src/api/platform/models';
import {testData} from '../../common/dataSeed';

describe('Platforms', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Returns all platforms', async () => {
    const response = await supertest(app).get('/platforms').set(unauthorizedUserHeader);

    expect(response.statusCode).to.eq(StatusCodes.OK);
    const platforms: Platform[] = response.body;
    expect(platforms.length).to.eq(testData.platforms.length);
  });

  it('Returns active platforms', async () => {
    const response = await supertest(app)
      .get('/platforms?isActive=true')
      .set(unauthorizedUserHeader);

    expect(response.statusCode).to.eq(StatusCodes.OK);
    const platforms: Platform[] = response.body;
    expect(platforms.length).to.eq(2);
  });

  it('Returns inactive platforms', async () => {
    const response = await supertest(app)
      .get('/platforms?isActive=false')
      .set(unauthorizedUserHeader);

    expect(response.statusCode).to.eq(StatusCodes.OK);
    const platforms: Platform[] = response.body;
    expect(platforms.length).to.eq(1);
    expect(platforms[0].id).to.eq('INACTIVE-PLATFORM');
  });

  it('Returns status for invalid parameter', async () => {
    const response = await supertest(app)
      .get('/platforms?isActive=xxx')
      .set(unauthorizedUserHeader);

    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
