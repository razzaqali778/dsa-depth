import {
  currentTimeFrame,
  effortAllocations,
  effortEngagements,
  effortMembers,
  efforts as seedEfforts,
  futureTimeFrame,
  teams,
} from '../../common/dataSeed';
import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';
import {
  getFullEffortEntitiesByTeamStartAndEndTimeFrameId,
  getFullEffortEntityByTeamAndTimeFrame,
} from '../../../src/api/effort/effortService';

const chai = require('chai');
chai.use(require('chai-as-promised'));

const effortId = seedEfforts.filter(
  e => e.teamId === teams[1].id && e.timeFrameId === currentTimeFrame.id
)[0].id;

const effortAllocationObjects = effortAllocations
  .filter(ea => ea.effortId === effortId)
  .map(ea => {
    return {
      percentageOfTeamCost: Number(ea.percentageOfTeamCost),
      initiativeId: ea.initiativeId,
    };
  });

const effortMemberObjects = effortMembers.map(em => {
  return {
    ...em,
    effortId: Number(em.effortId),
  };
});

describe('Get Full Effort', () => {
  before(async () => {
    await setupCoreDatabase();
  });

  it('returns an effort based on a valid team and time frame', async () => {
    const effort = await getFullEffortEntityByTeamAndTimeFrame(teams[1].id, currentTimeFrame.id);

    expect(BigInt(effort.timeFrameId)).to.eq(currentTimeFrame.id);
    expect(effort.teamId).to.eq(teams[1].id);
    expect(effort.allocations).to.deep.eq(effortAllocationObjects);
    expect(effort.members).to.deep.eq(
      effortMemberObjects
        .filter(em => BigInt(em.effortId) === effortId)
        .map(em => ({
          percent: em.percent,
          userId: em.userId,
        }))
    );
    expect(effort.engagements).to.deep.eq(
      effortEngagements
        .filter(ee => BigInt(ee.effortId) === effortId)
        .map(ee => ({
          amount: ee.amount,
          engagementId: ee.engagementId,
          amountDetails: null,
          comment: null,
        }))
    );
    expect(effort.forecastPeople).to.deep.eq([
      {
        numberOfPeople: 2.5,
        costGroupId: 'PE-PRODUCT-DEVELOPMENT',
        rateId: 'STANDARD',
      },
    ]);
  });

  it('fails if team id is invalid', async () => {
    const effort = await getFullEffortEntityByTeamAndTimeFrame('BAD-TEAM', currentTimeFrame.id);
    expect(effort).to.equal(undefined);
    // .to.eventually.be.rejected.and.be.an.instanceOf(NotFoundError)
    // .and.have.property('message', 'Unable to find team with id of BAD-TEAM');
  });

  it('fails if time frame id is invalid', async () => {
    const effort = await getFullEffortEntityByTeamAndTimeFrame(teams[1].id, -9999n);
    expect(effort).to.eq(undefined);
  });

  it('returns all efforts for a given team within a range of time frame ids', async () => {
    const result = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teams[1].id,
      currentTimeFrame.id,
      futureTimeFrame.id
    );

    expect(result.length).to.eq(2);
    expect(result[0]).to.deep.eq({
      id: 2,
      timeFrameId: 3,
      teamId: 'RICOCHET-DEV-TEAM',
      allocations: [
        {
          percentageOfTeamCost: 100,
          initiativeId: 'vipInitiativeId3',
        },
      ],
      members: [
        {
          userId: 'TJSIM',
          percent: 50,
        },
      ],
      forecastPeople: [
        {
          numberOfPeople: 2.5,
          rateId: 'STANDARD',
          costGroupId: 'PE-PRODUCT-DEVELOPMENT',
        },
      ],
      engagements: [
        {
          amount: 1000,
          engagementId: 'engagement1',
          amountDetails: null,
          comment: null,
        },
      ],
      costBreakdowns: [
        {
          costGroupId: 'PE-PRODUCT-DEVELOPMENT3',
          cost: 1201,
          engagementId: null,
          personId: 'TJSIM',
        },
      ],
    });

    expect(result[1]).to.deep.eq({
      id: 4,
      timeFrameId: 4,
      teamId: 'RICOCHET-DEV-TEAM',
      allocations: [
        {
          percentageOfTeamCost: 100,
          initiativeId: 'vipInitiativeId6',
        },
      ],
      members: [],
      forecastPeople: [],
      engagements: [
        {
          amount: 2000,
          engagementId: 'engagement2',
          amountDetails: null,
          comment: null,
        },
      ],
      costBreakdowns: [
        {
          costGroupId: 'PE-PRODUCT-DEVELOPMENT3',
          cost: 901,
          engagementId: 'engagement2',
          personId: null,
        },
      ],
    });
  });

  it('fails if start time frame id is invalid', async () => {
    const effort = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teams[1].id,
      -9999n,
      futureTimeFrame.id
    );
    expect(effort).to.deep.equal([]);
  });

  it('fails if end time frame id is invalid', async () => {
    const effort = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teams[1].id,
      currentTimeFrame.id,
      -9999n
    );
    expect(effort).to.deep.equal([]);
  });

  it('fails if start time frame is after end time frame', async () => {
    const effort = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teams[1].id,
      futureTimeFrame.id,
      currentTimeFrame.id
    );
    expect(effort).to.deep.equal([]);
  });
});
