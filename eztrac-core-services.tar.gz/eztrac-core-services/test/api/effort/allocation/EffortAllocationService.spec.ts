import {
  byTimeFrame,
  updateEffortAllocations,
} from '../../../../src/api/effort/allocation/effortAllocationService';
import {currentTimeFrame} from '../../../common/dataSeed';
import {expect} from 'chai';
import {NotFoundError} from '../../../../src/api/types/NotFoundError';
import {setupCoreDatabase} from '../../../common/databaseSetup';
import {effortAllocations, efforts, team1Id} from '../../../common/dataSeed';
import {TimeFrameAllocation} from '../../../../src/api/effort/allocation/models';

const chai = require('chai');
chai.use(require('chai-as-promised'));

const timeFrameId1: bigint = efforts[0].timeFrameId;
const timeFrameId2: bigint = efforts[2].timeFrameId;
const pastTimeFrameId: bigint = efforts[4].timeFrameId;
const existingPct1: bigint = effortAllocations[1].percentageOfTeamCost;
const existingPct2: bigint = effortAllocations[2].percentageOfTeamCost;
const existingVIPId1: string = effortAllocations[0].initiativeId;
const existingVIPId2: string = effortAllocations[1].initiativeId;
const existingVIPId3: string = effortAllocations[2].initiativeId;

const timeFrameAllocations_newPct1: TimeFrameAllocation = {
  timeFrameId: timeFrameId1,
  allocations: [
    {initiativeId: existingVIPId1, percentageOfTeamCost: 40n},
    {initiativeId: existingVIPId2, percentageOfTeamCost: 60n},
  ],
};

const timeFrameAllocations_newPct2: TimeFrameAllocation = {
  timeFrameId: timeFrameId2,
  allocations: [{initiativeId: existingVIPId3, percentageOfTeamCost: 80n}],
};

const timeFrameAllocations_old: TimeFrameAllocation = {
  timeFrameId: pastTimeFrameId,
  allocations: [{initiativeId: existingVIPId3, percentageOfTeamCost: 80n}],
};

const timeFrameAllocations_newInitiatives2: TimeFrameAllocation = {
  timeFrameId: timeFrameId2,
  allocations: [{initiativeId: 'new-vip-id-1', percentageOfTeamCost: 20n}],
};

const timeFrameAllocations_initiatives_old: TimeFrameAllocation = {
  timeFrameId: pastTimeFrameId,
  allocations: [{initiativeId: 'new-vip-id-1', percentageOfTeamCost: 20n}],
};

const timeFrameAllocations_over100: TimeFrameAllocation = {
  timeFrameId: timeFrameId2,
  allocations: [
    {initiativeId: existingVIPId3, percentageOfTeamCost: existingPct2},
    {initiativeId: existingVIPId2, percentageOfTeamCost: existingPct1},
  ],
};

const timeFrameAllocations_negativePct: TimeFrameAllocation = {
  timeFrameId: timeFrameId2,
  allocations: [{initiativeId: existingVIPId3, percentageOfTeamCost: -20n}],
};

describe('Effort Allocation Service', () => {
  before(async () => {
    await setupCoreDatabase();
  });

  describe('Get Effort Allocations', () => {
    it('returns effort allocations based on a valid time frame', async () => {
      const effortAllocations = await byTimeFrame(currentTimeFrame.id);
      for (const effortAllocation of effortAllocations) {
        expect(BigInt(effortAllocation.timeFrameId)).to.eq(currentTimeFrame.id);
      }
    });

    it('fails if time frame id is invalid', async () => {
      await expect(byTimeFrame(-9999n))
        .to.eventually.be.rejected.and.be.an.instanceOf(NotFoundError)
        .and.have.property('message', 'Unable to find time frame with id of -9999');
    });
  });

  describe('Update Effort Allocations', () => {
    // it('updates allocation pcts for existing allocations of an effort - in one timeframe', async () => {
    //   const result = await updateEffortAllocations(team1Id, [timeFrameAllocations_newPct1], false);

    //   const expected = effortCostBreakdowns[0].cost + effortCostBreakdowns[1].cost;
    //   expect(result).to.deep.eq(expected);
    // });

    // it('updates allocation pcts for existing allocations of an effort - in multiple timeframes', async () => {
    //   const result = await updateEffortAllocations(
    //     team1Id,
    //     [timeFrameAllocations_newPct1, timeFrameAllocations_newPct2],
    //     false
    //   );
    //   const expected =
    //     effortCostBreakdowns[0].cost +
    //     effortCostBreakdowns[1].cost +
    //     effortCostBreakdowns[3].cost +
    //     effortCostBreakdowns[4].cost;
    //   expect(result).to.deep.eq(expected);
    // });

    // it('adds a new initiative to multiple efforts, one timeframe, and sets the allocation pct', async () => {
    //   const result = await updateEffortAllocations(
    //     team1Id,
    //     [timeFrameAllocations_newInitiatives1],
    //     false
    //   );
    //   const expected = effortCostBreakdowns[0].cost + effortCostBreakdowns[1].cost;
    //   expect(result).to.deep.eq(expected);
    // });

    // it('adds a new initiative to multiple efforts, multiple timeframes, and sets the allocation pct', async () => {
    //   const result = await updateEffortAllocations(
    //     team1Id,
    //     [timeFrameAllocations_newInitiatives1, timeFrameAllocations_newInitiatives2],
    //     false
    //   );
    //   const expected =
    //     effortCostBreakdowns[0].cost +
    //     effortCostBreakdowns[1].cost +
    //     effortCostBreakdowns[3].cost +
    //     effortCostBreakdowns[4].cost;
    //   expect(result).to.deep.eq(expected);
    // });

    it('fails when team id is invalid', async () => {
      await expect(updateEffortAllocations('wrongId', [timeFrameAllocations_newPct1], false))
        .to.eventually.be.rejected.and.be.an.instanceOf(NotFoundError)
        .and.have.property('message', 'Unable to find team with id of wrongId');
    });

    it('fails when the allocation percentage is more than 100', async () => {
      await expect(updateEffortAllocations(team1Id, [timeFrameAllocations_over100], false))
        .to.eventually.be.rejected.and.be.an.instanceOf(Error)
        .and.have.property(
          'message',
          'Unable to assign more than 100% to percentage of team cost.'
        );
    });

    it('fails when the allocation percentage is a negative number', async () => {
      await expect(updateEffortAllocations(team1Id, [timeFrameAllocations_negativePct], false))
        .to.eventually.be.rejected.and.be.an.instanceOf(Error)
        .and.have.property('message', 'Unable to assign negative percentage of team cost.');
    });

    it('fails when trying to update two effort allocations with the same time frame, sent as separate objects instead of one object', async () => {
      await expect(
        updateEffortAllocations(
          team1Id,
          [timeFrameAllocations_newPct2, timeFrameAllocations_newInitiatives2],
          false
        )
      )
        .to.eventually.be.rejected.and.be.an.instanceOf(Error)
        .and.have.property(
          'message',
          'Unable to add a separate allocation with a duplicated timeFrameId (4)'
        );
    });

    it('fails when trying to update a past timeframe without the needed authorization', async () => {
      await expect(
        updateEffortAllocations(
          team1Id,
          [timeFrameAllocations_old, timeFrameAllocations_initiatives_old],
          false
        )
      )
        .to.eventually.be.rejected.and.be.an.instanceOf(Error)
        .and.have.property('message', 'User is not authorized to perform this operation');
    });
  });
});
