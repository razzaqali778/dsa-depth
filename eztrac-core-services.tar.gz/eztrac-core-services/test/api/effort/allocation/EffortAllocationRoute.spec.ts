import 'reflect-metadata';
import {expect} from 'chai';
import {setupCoreDatabase} from '../../../common/databaseSetup';
import {
  currentTimeFrame,
  pastTimeFrame,
  efforts,
  effortAllocations,
} from '../../../common/dataSeed';
import {TimeFrameAllocation} from '../../../../src/api/effort/allocation/models';
import sinon from 'sinon';
import chai from 'chai';
import * as core from 'express-serve-static-core';
import {StatusCodes} from 'http-status-codes';
import {
  APPLICATION_JSON_WITH_CHARSET,
  CONTENT_TYPE,
  effortWriteUserHeader,
  adminUserHeader,
  unauthorizedUserHeader,
} from '../../../common/HttpConstants';
import supertest from 'supertest';
chai.use(require('chai-as-promised'));

describe('Effort Allocations Route', () => {
  let app: core.Express;
  const sandbox = sinon.createSandbox();

  before(async () => {
    app = require('../../../../server').app;
    await setupCoreDatabase();
  });

  after(() => {
    sandbox.restore();
  });

  const timeFrameAllocations1: TimeFrameAllocation = {
    timeFrameId: efforts[0].timeFrameId,
    allocations: [
      {
        initiativeId: effortAllocations[0].initiativeId,
        percentageOfTeamCost: effortAllocations[0].percentageOfTeamCost,
      },
      {
        initiativeId: 'newInitiativeId',
        percentageOfTeamCost: 50n,
      },
    ],
  };

  const timeFrameAllocations_lockedTimeFrame: TimeFrameAllocation = {
    timeFrameId: pastTimeFrame.id,
    allocations: [
      {
        initiativeId: 'newInitiativeId',
        percentageOfTeamCost: 50n,
      },
    ],
  };

  /* GET */

  it('returns allocation for the given time frame', async () => {
    const theTimeFrameId = currentTimeFrame.id;
    const response = await supertest(app).get(`/efforts/allocations/timeframes/${theTimeFrameId}`);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
    expect(response.body).to.be.not.null;
    for (const effortAllocation of response.body) {
      expect(BigInt(effortAllocation.timeFrameId)).to.eq(theTimeFrameId);
    }
  });

  it("fails if the provided time frame id doesn't exist", async () => {
    const theTimeFrameId = 9999n;
    const response = await supertest(app)
      .get(`/efforts/allocations/timeframes/${theTimeFrameId}`)
      .set(effortWriteUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
  });

  /* PATCH */

  it('fails if request body is empty', async () => {
    const theTeam = efforts[0].teamId;
    const response = await supertest(app)
      .patch(`/efforts/allocations/team/${theTeam}`)
      .set(effortWriteUserHeader)
      .send({});
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('updates allocations for a team and multiple time frames', async () => {
    const theTeam = efforts[0].teamId;
    const theTimeFrameAllocations = [timeFrameAllocations1];

    const response = await supertest(app)
      .patch(`/efforts/allocations/team/${theTeam}`)
      .set(effortWriteUserHeader)
      .send(theTimeFrameAllocations);
    expect(response.statusCode).to.eq(StatusCodes.OK);
  });

  it('fails when team with given id does not exist', async () => {
    const theTeam = 'wrongId';
    const theTimeFrameAllocations = [timeFrameAllocations1];
    const response = await supertest(app)
      .patch(`/efforts/allocations/team/${theTeam}`)
      .set(effortWriteUserHeader)
      .send(theTimeFrameAllocations);
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
  });

  it('fails if user is not authorized to make changes to effort allocations', async () => {
    const theTeam = efforts[0].teamId;
    const theTimeFrameAllocations = [timeFrameAllocations1];
    const response = await supertest(app)
      .patch(`/efforts/allocations/team/${theTeam}`)
      .set(unauthorizedUserHeader)
      .send(theTimeFrameAllocations);
    expect(response.statusCode).to.eq(StatusCodes.FORBIDDEN);
  });

  it('allows admin users to make changes to locked periods', async () => {
    const theTeam = efforts[0].teamId;
    const theTimeFrameAllocations = [timeFrameAllocations_lockedTimeFrame];
    const response = await supertest(app)
      .patch(`/efforts/allocations/team/${theTeam}`)
      .set(adminUserHeader)
      .send(theTimeFrameAllocations);
    expect(response.statusCode).to.eq(StatusCodes.OK);
  });

  it('fails if user is not authorized to make changes to locked periods', async () => {
    const theTeam = efforts[0].teamId;
    const theTimeFrameAllocations = [timeFrameAllocations_lockedTimeFrame];
    const response = await supertest(app)
      .patch(`/efforts/allocations/team/${theTeam}`)
      .set(effortWriteUserHeader)
      .send(theTimeFrameAllocations);
    expect(response.statusCode).to.eq(StatusCodes.FORBIDDEN);
  });
});
