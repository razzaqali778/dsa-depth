import {expect} from 'chai';
import {AppContext} from '../../../../src/api/AppContext';
import {setupCoreDatabase} from '../../../common/databaseSetup';
import {
  addMonths,
  currentTimeFrame,
  getTimeFrameStartAndEndDate,
  seedEffortAllocations,
  seedEfforts,
  seedTimeFrames,
  teams,
} from '../../../common/dataSeed';
import {container} from 'tsyringe';
import chai from 'chai';
import {Effort} from 'src/api/effort/models';
import {TimeFrame} from 'src/api/timeframe/models';
import {EffortAllocation} from 'src/api/effort/allocation/models';
chai.use(require('chai-as-promised'));

describe('Effort allocation repository', () => {
  const timeFrames: TimeFrame[] = [
    {
      id: 5n,
      name: 'Time frame 3 months ago',
      lockdown: false,
      isActive: true,
      ...getTimeFrameStartAndEndDate(addMonths(new Date(), -3)),
    },
    {
      id: 6n,
      name: 'Time frame 2 months ago',
      lockdown: false,
      isActive: true,
      ...getTimeFrameStartAndEndDate(addMonths(new Date(), -2)),
    },
    {
      id: 7n,
      name: 'Time frame month ago',
      lockdown: false,
      isActive: true,
      ...getTimeFrameStartAndEndDate(addMonths(new Date(), -1)),
    },
  ];
  const efforts: Effort[] = [
    {
      id: BigInt(6),
      timeFrameId: timeFrames[0].id,
      teamId: teams[0].id,
      cost: 0n,
    },
    {
      id: BigInt(7),
      timeFrameId: timeFrames[1].id,
      teamId: teams[1].id,
      cost: 0n,
    },
    {
      id: BigInt(8),
      timeFrameId: timeFrames[2].id,
      teamId: teams[0].id,
      cost: 0n,
    },
    {
      id: BigInt(9),
      timeFrameId: currentTimeFrame.id,
      teamId: teams[2].id,
      cost: 0n,
    },
  ];
  const effortAllocations: Partial<EffortAllocation>[] = [
    {
      effortId: efforts[0].id,
      percentageOfTeamCost: BigInt(50),
      initiativeId: 'vipInitiativeId1',
    },
    {
      effortId: efforts[1].id,
      percentageOfTeamCost: BigInt(100),
      initiativeId: 'vipInitiativeId3',
    },
    {
      effortId: efforts[2].id,
      percentageOfTeamCost: BigInt(90),
      initiativeId: 'vipInitiativeId4',
    },
    {
      effortId: efforts[3].id,
      percentageOfTeamCost: BigInt(100),
      initiativeId: 'vipInitiativeId6',
    },
  ];

  before(async () => {
    await setupCoreDatabase();
    const db = container.resolve(AppContext).db;
    await seedTimeFrames(db, timeFrames);
    await seedEfforts(db, efforts);
    await seedEffortAllocations(db, effortAllocations);
  });

  it('returns effort allocations in given time range', async () => {
    const r = container.resolve(AppContext).repositories;
    const allocations = await r.effortAllocationsRepository.getEffortAllocationsByTimeRange(
      timeFrames[0].id,
      timeFrames[2].id
    );
    expect(allocations).to.have.length(3);
    expect(allocations.map(a => a.timeFrameId)).to.deep.equal([
      Number(timeFrames[0].id),
      Number(timeFrames[1].id),
      Number(timeFrames[2].id),
    ]);
  });
});
