import {expect} from 'chai';
import {AppContext} from '../../../../src/api/AppContext';
import {setupCoreDatabase} from '../../../common/databaseSetup';
import {
  currentTimeFrame,
  futureTimeFrame,
  inActiveTimeFrame,
  persons,
} from '../../../common/dataSeed';
import {container} from 'tsyringe';
import chai from 'chai';
chai.use(require('chai-as-promised'));

describe('Effort members repository', () => {
  before(async () => {
    await setupCoreDatabase();
  });

  describe('getEffortMembersByTimeframeAndPerson', () => {
    it('returns proper efforts for timeframe and person when available', async () => {
      const r = container.resolve(AppContext).repositories;
      const efforts = await r.effortMembersRepository.getEffortMembersByTimeframeAndPerson(
        currentTimeFrame.id,
        persons[0].id
      );
      for (const effortMember of efforts) {
        expect(effortMember).to.haveOwnProperty('timeFrameId', Number(currentTimeFrame.id));
        expect(effortMember).to.haveOwnProperty('teamId');
        expect(effortMember).to.haveOwnProperty('userId', persons[0].id);
        expect(effortMember).to.haveOwnProperty('percent');
      }
    });

    it('returns empty array when efforts not available for timeframe and person', async () => {
      const r = container.resolve(AppContext).repositories;
      const efforts = await r.effortMembersRepository.getEffortMembersByTimeframeAndPerson(
        inActiveTimeFrame.id,
        persons[0].id
      );
      expect(efforts).to.have.length(0);
    });
  });

  describe('getEffortMembersByTimeframe', () => {
    it('returns proper efforts for timeframe and person when available', async () => {
      const r = container.resolve(AppContext).repositories;
      const efforts = await r.effortMembersRepository.getEffortMembersByTimeframe(
        currentTimeFrame.id
      );
      for (const effortMember of efforts) {
        expect(effortMember).to.haveOwnProperty('timeFrameId', Number(currentTimeFrame.id));
        expect(effortMember).to.haveOwnProperty('teamId');
        expect(effortMember).to.haveOwnProperty('userId');
        expect(effortMember).to.haveOwnProperty('percent');
      }
    });

    it('returns empty array when efforts not available for timeframe and person', async () => {
      const r = container.resolve(AppContext).repositories;
      const efforts = await r.effortMembersRepository.getEffortMembersByTimeframe(
        inActiveTimeFrame.id
      );
      expect(efforts).to.have.length(0);
    });
  });

  describe('getForecastedEffortMembersByTimeframe', () => {
    it('returns proper efforts for timeframe and person when available', async () => {
      const r = container.resolve(AppContext).repositories;
      const efforts = await r.effortMembersRepository.getForecastedEffortMembersByTimeframe(
        futureTimeFrame.id
      );
      for (const effortMember of efforts) {
        expect(effortMember).to.haveOwnProperty('timeFrameId', Number(futureTimeFrame.id));
        expect(effortMember).to.haveOwnProperty('teamName');
        expect(effortMember).to.haveOwnProperty('teamId');
        expect(effortMember).to.haveOwnProperty('numberOfPeople');
        expect(effortMember).to.haveOwnProperty('costGroupId');
        expect(effortMember).to.haveOwnProperty('rateId');
      }
    });

    it('returns empty array when efforts not available for timeframe and person', async () => {
      const r = container.resolve(AppContext).repositories;
      const efforts = await r.effortMembersRepository.getForecastedEffortMembersByTimeframe(
        inActiveTimeFrame.id
      );
      expect(efforts).to.have.length(0);
    });
  });
});
