import {expect} from 'chai';
import {currentTimeFrame, futureTimeFrame, pastTimeFrame, team1Id} from '../../common/dataSeed';
import {every, some} from 'lodash';
import {setupCoreDatabase} from '../../common/databaseSetup';
import chai from 'chai';
import * as core from 'express-serve-static-core';
import {StatusCodes} from 'http-status-codes';
import {
  APPLICATION_JSON_WITH_CHARSET,
  CONTENT_TYPE,
  DEFAULT_USER_HEADER,
} from '../../common/HttpConstants';
import supertest from 'supertest';

chai.use(require('chai-as-promised'));

describe('Full Effort Route', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  it('Retrieves a full effort object based on a team and time frame ', async () => {
    const theTeamId = team1Id;
    const theTimeFrameId = currentTimeFrame.id;
    const response = await supertest(app)
      .get(`/efforts/full/team/${theTeamId}/timeframe/${theTimeFrameId}`)
      .set(DEFAULT_USER_HEADER);
    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
    expect(response.body).to.be.not.null;
    expect(response.body.timeFrameId).to.eq(Number(theTimeFrameId));
    expect(response.body.teamId).to.eq(theTeamId);
  });

  it('Retrieves all the full efforts for a given team and range of time frames', async () => {
    const startTimeFrameId = pastTimeFrame.id;
    const endTimeFrameId = futureTimeFrame.id;
    const response = await supertest(app)
      .get(
        `/efforts/full/team/${team1Id}?startTimeFrame=${startTimeFrameId}&endTimeFrame=${endTimeFrameId}`
      )
      .set(DEFAULT_USER_HEADER);

    expect(response.statusCode).to.eq(StatusCodes.OK);

    const efforts = response.body;
    expect(efforts.length).to.be.greaterThanOrEqual(2);
    expect(every(efforts, e => e.teamId === team1Id)).to.be.true;
    expect(some(efforts, e => BigInt(e.timeFrameId) === startTimeFrameId)).to.be.true;
    expect(some(efforts, e => BigInt(e.timeFrameId) === endTimeFrameId)).to.be.true;
  });

  it('Retrieves all the full efforts for a given team and invalid range of time frames', async () => {
    const startTimeFrameId = 9999n;
    const endTimeFrameId = 19999n;
    const response = await supertest(app)
      .get(
        `/efforts/full/team/${team1Id}?startTimeFrame=${startTimeFrameId}&endTimeFrame=${endTimeFrameId}`
      )
      .set(DEFAULT_USER_HEADER);

    expect(response.statusCode).to.eq(StatusCodes.OK);
    expect(response.body).to.deep.equal([]);
  });

  it('it fails if either the start or end time frame id parameters are not provided for the multi time frame path', async () => {
    const responseNoEndParam = await supertest(app)
      .get(`/efforts/full/team/${team1Id}?startTimeFrame=${pastTimeFrame.id}`)
      .set(DEFAULT_USER_HEADER);
    expect(responseNoEndParam.statusCode).to.eq(StatusCodes.BAD_REQUEST);

    const responseNoStartParam = await supertest(app)
      .get(`/efforts/full/team/${team1Id}?endTimeFrame=${pastTimeFrame.id}`)
      .set(DEFAULT_USER_HEADER);
    expect(responseNoStartParam.statusCode).to.eq(StatusCodes.BAD_REQUEST);

    const responseNoParams = await supertest(app)
      .get(`/efforts/full/team/${team1Id}`)
      .set(DEFAULT_USER_HEADER);
    expect(responseNoParams.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
