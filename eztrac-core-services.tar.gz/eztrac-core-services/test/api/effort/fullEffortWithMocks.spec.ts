import 'reflect-metadata';
import {container} from 'tsyringe';
import {AppContext} from '../../../src/api/AppContext';
import {expect} from 'chai';
import {buildRepositories} from '../../common/baseBuilders';
import * as sinon from 'sinon';
import {Effort, EffortEntity} from '../../../src/api/effort/models';
import {TimeFrameId} from '../../../src/api/timeframe/models';
import {getFullEffortEntitiesByTeamStartAndEndTimeFrameId} from '../../../src/api/effort/effortService';
import {EffortEngagement} from 'src/api/effort/engagement/models';

describe('Full Effort Service with database mock', () => {
  const teamId = '301';
  const startTimeFrame = 42100n;
  const endTimeFrame = 42111n;
  const ef: Effort = {
    id: 128228n,
    timeFrameId: 42001n,
    teamId: '301',
    cost: 0n,
  };
  const allocations = [
    {
      percentageOfTeamCost: 15n,
      initiativeId: '475c5800-79e4-11ea-98b8-43dde22e6b7e',
    },
    {
      percentageOfTeamCost: 0n,
      initiativeId: '4c590830-6acb-11ea-940c-1d1fd3a9157c',
    },
    {
      percentageOfTeamCost: 2n,
      initiativeId: 'f56b49d0-76ca-11e7-a313-c34179e60a86',
    },
  ];
  const effortAllocations = allocations.map(a => ({
    ...a,
    effortId: ef.id,
    teamId: ef.teamId,
    timeFrameId: ef.timeFrameId,
  }));
  const costBreakdowns = [
    {
      costGroupId: 'ITCS-PROD-PLTFM-CUSTOMER-CNT',
      cost: 21120n,
    },
    {
      costGroupId: 'ITCS-PROD-PLTFM-CUSTOMER-DCT',
      cost: 22080n,
    },
    {
      costGroupId: 'ITCS-PROD-PLTFM-CUSTOMER-SOW',
      cost: 86000n,
      engagementId: 'COGNIZANT-ACS2-ECOMMERCE-IMPLEMENTATION',
    },
    {
      costGroupId: 'ITCS-PROD-PLTFM-DESIGN-CNT',
      cost: 21120n,
    },
  ];
  const effortCostBreakdowns = costBreakdowns.map(b => ({
    ...b,
    effortId: 128228n,
  }));
  const engagements = [
    {
      amount: 86000n,
      engagementId: 'COGNIZANT-ACS2-ECOMMERCE-IMPLEMENTATION',
    },
  ];
  const effortEngagements = engagements.map(e => ({
    ...e,
    effortId: 128228n,
    timeFrameId: ef.timeFrameId,
    teamId: ef.teamId,
  })) as EffortEngagement[];
  const members = [
    {
      userId: 'CAGGARW',
      percent: 100,
    },
    {
      userId: 'GKNPK',
      percent: 100,
    },
    {
      userId: 'GLYCL',
      percent: 100,
    },
  ];
  const effortMembers = members.map(m => ({
    ...m,
    effortId: 128228n,
    timeFrameId: ef.timeFrameId,
    teamId: ef.teamId,
  }));

  const resultEffort: EffortEntity = {
    timeFrameId: 42001n,
    teamId: '301',
    id: 128228n,
    allocations: allocations,
    costBreakdowns: costBreakdowns,
    engagements: engagements,
    forecastPeople: [],
    members: members,
  };

  const effortRepository = {
    getEffortByTeamAndTimeframes: () => {
      return Promise.resolve([ef]);
    },
    getEffortsByTeamsAndTimeFrames: () => {
      return Promise.resolve([ef]);
    },
    getEffortCostBreakdownsByEffortIds: () => {
      return Promise.resolve(effortCostBreakdowns);
    },
  };

  const effortAllocationsRepository = {
    getEffortAllocationsByTeamsAndTimeFrames: () => {
      return Promise.resolve(effortAllocations);
    },
    getAllocationsByEffortIds: () => {
      return Promise.resolve(effortAllocations);
    },
  };

  const timeFrameRepository = {
    getTimeFrameIdsInRange: () => {
      const tfId: TimeFrameId = 123n;
      return Promise.resolve([tfId]);
    },
  };

  const teamRepository = {
    getTeamById: () => {
      return Promise.resolve({
        id: '1',
        name: 'TeamName',
        communityId: 'CommunityId',
        isActive: true,
      });
    },
  };

  const effortEngagementsRepository = {
    getEffortEngagementsByEffortIds: () => {
      return Promise.resolve(effortEngagements);
    },
  };

  const effortMembersRepository = {
    getMembersByEffortIds: () => {
      return Promise.resolve(effortMembers);
    },
    getForecastedMembersByEffortIds: () => {
      return Promise.resolve([]);
    },
  };

  before(() => {
    const dbMock = sinon.mock();

    container.register('Database', {
      useValue: dbMock,
    });

    container.register('Repositories', {
      useValue: buildRepositories(
        effortRepository,
        timeFrameRepository,
        teamRepository,
        effortAllocationsRepository,
        effortEngagementsRepository,
        effortMembersRepository
      ),
    });

    container.register('AppContext', {
      useClass: AppContext,
    });
  });

  it('TS is run successfully', async () => {
    const efforts = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teamId,
      startTimeFrame,
      endTimeFrame
    );

    expect(efforts).to.deep.equal([resultEffort]);
  });
});
