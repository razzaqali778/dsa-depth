import {expect} from 'chai';
import {throwNotFoundError} from '../../../../src/api/effort/utils';
import {DEFAULT_HOURS_AMOUNT} from '../../../../src/api/effort/engagement/effortEngagementService';
import {EngagementCalcInfo, EffortEngagement} from '../../../../src/api/effort/engagement/models';
import {calculateCost} from '../../../../src/api/effort/engagement/utils';

export const createTestEngagementResponse = (
  id: string,
  timeFrameId: bigint,
  amount: bigint,
  amountDetails?: EngagementCalcInfo
): EffortEngagement => ({
  teamId: `${id}-team_id`,
  timeFrameId,
  comment: `${id}-comment`,
  // teamCostId: Number(amount),
  engagementId: `${id}-engagement_id`,
  amount: amount,
  amountDetails,
});

describe('Effort Engagements Utils', () => {
  describe('throwNotFoundError', () => {
    const testDataValues = [
      {name: 'string', data: 'stringData'},
      {name: 'number', data: 123},
      {name: 'bigint', data: 1234n},
    ];
    for (const testData of testDataValues) {
      it(`should return proper error for ${testData.name} id type`, () => {
        try {
          throwNotFoundError(testData.name, testData.data);
        } catch (e: unknown) {
          const error = e as Error;
          expect(error.message).to.eq(
            `Unable to find ${testData.name} with id of ${testData.data}`
          );
        }
      });
    }
  });

  describe('calculateCost', () => {
    const testData = [
      {
        people: 1,
        hourlyRate: 1,
        comment: 'comment',
      },
      {
        people: 2,
        hourlyRate: 2.0,
      },
    ];
    const amountFromTestData =
      testData[0].people * testData[0].hourlyRate + testData[1].people * testData[1].hourlyRate;

    it('should calculate properly for default amount of hours ', () => {
      const result = calculateCost(testData, DEFAULT_HOURS_AMOUNT);
      expect(result).to.eq(amountFromTestData * DEFAULT_HOURS_AMOUNT);
    });

    it('should calculate properly for different amount of hours ', () => {
      const result = calculateCost(testData, 10);
      expect(result).to.eq(amountFromTestData * 10);
    });

    it('should calculate properly when data array is empty ', () => {
      const result = calculateCost([], DEFAULT_HOURS_AMOUNT);
      expect(result).to.eq(0);
    });
  });
});
