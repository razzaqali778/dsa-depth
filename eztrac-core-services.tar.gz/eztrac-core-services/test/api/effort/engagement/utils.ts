import {effortEngagements, efforts} from '../../../../test/common/dataSeed';

export const findTestEngagementsForTeam = (teamId: string) => {
  const extendedData = effortEngagements.map(engagement => ({
    ...engagement,
    effort: efforts.find(effort => effort.id === engagement.effortId),
  }));

  return extendedData.filter(data => data.effort?.teamId === teamId);
};
