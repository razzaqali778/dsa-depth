import {expect} from 'chai';
import {AppContext} from '../../../../src/api/AppContext';
import {setupCoreDatabase} from '../../../common/databaseSetup';
import {futureTimeFrame, pastTimeFrame, teams, timeFrames} from '../../../common/dataSeed';
import {container} from 'tsyringe';
import chai from 'chai';
import {findTestEngagementsForTeam} from './utils';
chai.use(require('chai-as-promised'));

describe('Effort engagements repository', () => {
  before(async () => {
    await setupCoreDatabase();
  });

  describe('getEffortEngagementsByTimeFrames', () => {
    it('returns proper timeframes when available', async () => {
      const r = container.resolve(AppContext).repositories;
      const timeframes = await r.effortEngagementsRepository.getEffortEngagementsByTimeFrames(
        pastTimeFrame.id,
        futureTimeFrame.id
      );
      expect(timeframes).to.have.length(timeFrames.length);
    });

    it('returns empty array when timeframes not available', async () => {
      const r = container.resolve(AppContext).repositories;
      const timeframes = await r.effortEngagementsRepository.getEffortEngagementsByTimeFrames(
        futureTimeFrame.id,
        pastTimeFrame.id
      );
      expect(timeframes).to.have.length(0);
    });
  });

  describe('getEffortEngagementsByTeam', () => {
    it('returns proper team timeframes when available', async () => {
      const r = container.resolve(AppContext).repositories;
      const timeframesForTeam = await r.effortEngagementsRepository.getEffortEngagementsByTeam(
        teams[0].id
      );

      const engagementsExpected = findTestEngagementsForTeam(teams[0].id);
      expect(timeframesForTeam).to.have.length(engagementsExpected.length);
      for (const timeframe of timeframesForTeam) {
        expect(timeframe.teamId).to.eq(teams[0].id);
      }
    });

    it('returns proper team timeframes when not available', async () => {
      const r = container.resolve(AppContext).repositories;
      const timeframesForTeam = await r.effortEngagementsRepository.getEffortEngagementsByTeam(
        teams[2].id
      );

      expect(timeframesForTeam).to.have.length(0);
    });
  });

  describe('getEffortEngagementsByTeamAndTimeframes', () => {
    it('returns proper engagements for team, timeframes range', async () => {
      const r = container.resolve(AppContext).repositories;
      const engagementsForTeam =
        await r.effortEngagementsRepository.getEffortEngagementsByTeamAndTimeframes(
          teams[0].id,
          pastTimeFrame.id,
          futureTimeFrame.id
        );
      expect(engagementsForTeam).to.have.length(2);
      for (const engagement of engagementsForTeam) {
        expect(engagement.teamId).to.eq(teams[0].id);
        expect(engagement.timeFrameId).to.be.above(Number(pastTimeFrame.id) - 1);
        expect(engagement.timeFrameId).to.be.below(Number(futureTimeFrame.id) + 1);
      }
    });

    it('returns proper engagements for team, timeframes range when no data', async () => {
      const r = container.resolve(AppContext).repositories;
      const engagementsForTeam =
        await r.effortEngagementsRepository.getEffortEngagementsByTeamAndTimeframes(
          teams[2].id,
          futureTimeFrame.id,
          futureTimeFrame.id
        );
      expect(engagementsForTeam).to.have.length(0);
    });
  });
});
