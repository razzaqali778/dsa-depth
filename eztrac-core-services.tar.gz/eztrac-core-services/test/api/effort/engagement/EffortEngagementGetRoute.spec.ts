import 'reflect-metadata';
import {expect} from 'chai';
import {setupCoreDatabase} from '../../../common/databaseSetup';
import {
  currentTimeFrame,
  effortEngagements,
  futureTimeFrame,
  pastTimeFrame,
  teams,
} from '../../../common/dataSeed';
import chai from 'chai';
import * as core from 'express-serve-static-core';
import {StatusCodes} from 'http-status-codes';
import {
  DEFAULT_USER_HEADER,
  APPLICATION_JSON_WITH_CHARSET,
  CONTENT_TYPE,
} from '../../../common/HttpConstants';
import supertest from 'supertest';
import {findTestEngagementsForTeam} from './utils';
chai.use(require('chai-as-promised'));

describe('Effort Engagements GET Route', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../../server').app;
    await setupCoreDatabase();
  });

  describe('/efforts/engagements route working properly', () => {
    it('returns engagements for the given time frames range', async () => {
      const response = await supertest(app)
        .get(
          `/efforts/engagements?startTimeFrame=${pastTimeFrame.id}&endTimeFrame=${futureTimeFrame.id}`
        )
        .set(DEFAULT_USER_HEADER);
      expect(response.statusCode).to.eq(StatusCodes.OK);
      expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
      expect(response.body).to.be.not.null;
      expect(response.body).to.have.length(effortEngagements.length);
    });

    it('returns proper engagements for the given time frames range', async () => {
      const theTimeFrameId = currentTimeFrame.id;
      const response = await supertest(app)
        .get(`/efforts/engagements?startTimeFrame=${theTimeFrameId}&endTimeFrame=${theTimeFrameId}`)
        .set(DEFAULT_USER_HEADER);
      expect(response.statusCode).to.eq(StatusCodes.OK);
      expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
      expect(response.body).to.be.not.null;
      for (const effortEngagement of response.body) {
        expect(BigInt(effortEngagement.timeFrameId)).to.eq(theTimeFrameId);
      }
    });

    it("fails if provided time frame id doesn't exist", async () => {
      const theTimeFrameId = 9999n;
      const response = await supertest(app)
        .get(
          `/efforts/engagements?startTimeFrame=${theTimeFrameId}&endTimeFrame=${currentTimeFrame.id}`
        )
        .set(DEFAULT_USER_HEADER);
      expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
    });

    it('fails if not all time frames provided', async () => {
      const response = await supertest(app)
        .get(`/efforts/engagements?startTimeFrame=${currentTimeFrame.id}`)
        .set(DEFAULT_USER_HEADER);
      expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
    });
  });

  describe('/efforts/engagements/team/:teamId route working properly', () => {
    it('returns engagements for the given time frames range and team Id', async () => {
      const response = await supertest(app)
        .get(
          `/efforts/engagements/team/${teams[0].id}?startTimeFrame=${pastTimeFrame.id}&endTimeFrame=${futureTimeFrame.id}`
        )
        .set(DEFAULT_USER_HEADER);
      expect(response.statusCode).to.eq(StatusCodes.OK);
      expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
      expect(response.body).to.be.not.null;
      const teamEngagements = findTestEngagementsForTeam(teams[0].id);
      expect(response.body).to.have.length(teamEngagements.length);
    });

    it('returns engagements for the given time frames range and team Id when it has no engagements', async () => {
      const response = await supertest(app)
        .get(
          `/efforts/engagements/team/${teams[2].id}?startTimeFrame=${pastTimeFrame.id}&endTimeFrame=${futureTimeFrame.id}`
        )
        .set(DEFAULT_USER_HEADER);
      expect(response.statusCode).to.eq(StatusCodes.OK);
      expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
      expect(response.body).to.be.not.null;
      expect(response.body).to.have.length(0);
    });

    it('returns engagements for the given time frames range and team Id when team has no engagements in timeframes ranfe', async () => {
      const response = await supertest(app)
        .get(
          `/efforts/engagements/team/${teams[1].id}?startTimeFrame=${pastTimeFrame.id}&endTimeFrame=${pastTimeFrame.id}`
        )
        .set(DEFAULT_USER_HEADER);
      expect(response.statusCode).to.eq(StatusCodes.OK);
      expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
      expect(response.body).to.be.not.null;
      expect(response.body).to.have.length(0);
    });

    it("fails if provided time frame id doesn't exist", async () => {
      const theTimeFrameId = 9999n;
      const response = await supertest(app)
        .get(
          `/efforts/engagements/team/${teams[1].id}?startTimeFrame=${theTimeFrameId}&endTimeFrame=${futureTimeFrame.id}`
        )
        .set(DEFAULT_USER_HEADER);
      expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
    });

    it("returns empty when team doesn't exist", async () => {
      const response = await supertest(app)
        .get(
          `/efforts/engagements/team/TEST_TEAM?startTimeFrame=${currentTimeFrame.id}&endTimeFrame=${futureTimeFrame.id}`
        )
        .set(DEFAULT_USER_HEADER);
      expect(response.statusCode).to.eq(StatusCodes.OK);
      expect(response.headers[CONTENT_TYPE]).to.equal(APPLICATION_JSON_WITH_CHARSET);
      expect(response.body).to.be.not.null;
      expect(response.body).to.have.length(0);
    });
  });
});
