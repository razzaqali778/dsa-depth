import {expect} from 'chai';
import {AppContext} from '../../../src/api/AppContext';
import {setupCoreDatabase} from '../../common/databaseSetup';
import {
  addMonths,
  futureTimeFrame,
  getTimeFrameStartAndEndDate,
  seedEfforts,
  seedTimeFrames,
  teams,
} from '../../common/dataSeed';
import {container} from 'tsyringe';
import chai from 'chai';
import {Effort} from 'src/api/effort/models';
import {TimeFrame} from 'src/api/timeframe/models';
chai.use(require('chai-as-promised'));

describe('Effort repository', () => {
  const timeFrames: TimeFrame[] = [
    {
      id: 5n,
      name: 'Time frame 1 month in future',
      lockdown: false,
      isActive: true,
      ...getTimeFrameStartAndEndDate(addMonths(new Date(), 1)),
    },
    {
      id: 6n,
      name: 'Time frame 2 months in future',
      lockdown: false,
      isActive: true,
      ...getTimeFrameStartAndEndDate(addMonths(new Date(), 2)),
    },
    {
      id: 7n,
      name: 'Time frame month ago',
      lockdown: false,
      isActive: true,
      ...getTimeFrameStartAndEndDate(addMonths(new Date(), -1)),
    },
  ];
  const efforts: Effort[] = [
    {
      id: BigInt(6),
      timeFrameId: timeFrames[0].id,
      teamId: teams[0].id,
      cost: 0n,
    },
    {
      id: BigInt(7),
      timeFrameId: timeFrames[1].id,
      teamId: teams[0].id,
      cost: 0n,
    },
    {
      id: BigInt(8),
      timeFrameId: timeFrames[2].id,
      teamId: teams[0].id,
      cost: 0n,
    },
  ];

  before(async () => {
    await setupCoreDatabase();
    const db = container.resolve(AppContext).db;
    await seedTimeFrames(db, timeFrames);
    await seedEfforts(db, efforts);
  });

  it('returns efforts by team id and with start date after given date', async () => {
    const r = container.resolve(AppContext).repositories;
    const efforts = await r.effortRepository.getEffortsByTeamAndStartDate(teams[0].id, new Date());
    expect(efforts).to.have.length(3);
    expect(efforts.map(e => e.timeFrameId)).to.deep.equal([
      Number(futureTimeFrame.id),
      Number(timeFrames[0].id),
      Number(timeFrames[1].id),
    ]);
  });
});
