import {expect} from 'chai';
import chai from 'chai';
import supertest from 'supertest';
import * as core from 'express-serve-static-core';
import {setupCoreDatabase} from '../../common/databaseSetup';
import {unauthorizedUserHeader} from '../../common/HttpConstants';
import {StatusCodes} from 'http-status-codes';
import sinon from 'sinon';

chai.use(require('chai-as-promised'));

describe('Team Costing route', () => {
  let app: core.Express;
  const sandbox = sinon.createSandbox();

  beforeEach(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
  });

  afterEach(() => {
    sandbox.restore();
  });

  describe('multiple teams', () => {
    it('recosts all standard teams for all non historic time frames', async () => {
      // to do
    });

    it('fails if profile does not match recosting auth context', async () => {
      const response = await supertest(app).put('/cost/standard-teams').set(unauthorizedUserHeader);
      expect(response.statusCode).to.eq(StatusCodes.FORBIDDEN);
    });
  });
});
