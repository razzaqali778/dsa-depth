import {TeamStructure} from 'src/api/team/models';
import {Workday} from 'src/api/timeframe/models';
import {PersonCostingData} from 'src/util/client/eztracCostingClient';
import {Initiative} from 'src/util/client/eztracVipClient';
import {User} from 'src/util/client/papiClient';

const timeFrameId = BigInt(42201);
const teamId = 'teamId';
const effort1Id = BigInt(1);
const user1 = {
  id: 'user1',
  name: 'User 1',
  manager: {name: 'Manager 1'},
};
const user2 = {
  id: 'user2',
  name: 'User 2',
  manager: {name: 'Manager 1'},
};
const user3 = {
  id: 'user3',
  name: 'User 3',
  manager: {name: 'Manager 2'},
};
const user4 = {
  id: 'user4',
  name: 'User 4',
  manager: {name: 'Manager 1'},
};

export const teams: TeamStructure[] = [
  {
    teamId: teamId,
    teamName: 'team name',
    communityId: 'community1Id',
    communityName: 'Community 1',
    platformId: 'platformId',
    platformName: 'Platform 1',
    orgId: 'orgId',
    orgName: 'Org 1',
    isActive: true,
  },
  {
    teamId: 'teamId1',
    teamName: 'team name 2',
    communityId: 'community2Id',
    communityName: 'Community 2',
    platformId: 'platform2d',
    platformName: 'Platform 2',
    orgId: 'org2Id',
    orgName: 'Org 2',
    isActive: true,
  },
];

function getDate(dateString: string): Date {
  const date = new Date(dateString);
  date.setUTCHours(12);
  return date;
}

export const workdays: Workday[] = [
  {
    date: getDate('2022-09-01'),
    hours: 24,
  },
  {
    date: getDate('2022-09-02'),
    hours: 24,
  },
  {
    date: getDate('2022-09-03'),
    hours: 24,
  },
  {
    date: getDate('2022-09-04'),
    hours: 24,
  },
  {
    date: getDate('2022-09-05'),
    hours: 14,
  },
  {
    date: getDate('2022-09-08'),
    hours: 24,
  },
  {
    date: getDate('2022-09-09'),
    hours: 16,
  },
];

export const people: User[] = [user1, user2, user3, user4];

export const personCostingData: PersonCostingData[] = [
  {
    personId: user1.id,
    personName: user1.name,
    costGroupName: 'cost group 1',
    isActive: true,
    isEmployee: true,
    rateName: 'rate name',
  },
  {
    personId: user2.id,
    personName: user2.name,
    costGroupName: 'cost group 2',
    isActive: true,
    isEmployee: true,
    rateName: 'rate name 2',
  },
  {
    personId: user3.id,
    personName: user3.name,
    costGroupName: 'cost group 3',
    isActive: true,
    isEmployee: true,
    rateName: 'rate name 3',
  },
  {
    personId: user4.id,
    personName: user4.name,
    costGroupName: 'cost group 4',
    isActive: true,
    isEmployee: true,
    rateName: 'rate name 4',
  },
];

const initative1: Initiative = {
  id: 'initiative1Id',
  name: 'Initiative 1',
  activityId: 'activity 1',
  typeId: 'type 1',
};

const initative2: Initiative = {
  id: 'initiative2Id',
  name: 'Initiative 2',
  activityId: 'activity 2',
  typeId: 'type 2',
};

const initative3: Initiative = {
  id: 'initiative3Id',
  name: 'Initiative 3',
  activityId: 'activity 3',
  typeId: 'type 3',
};

const initative4: Initiative = {
  id: 'initiative4Id',
  name: 'Initiative 4',
  activityId: 'activity 4',
  typeId: 'type 4',
};

const initative5: Initiative = {
  id: 'initiative5Id',
  name: 'Initiative 5',
  activityId: 'activity 5',
  typeId: 'type 5',
};

export const initiatives: Map<string, Initiative> = new Map([
  [initative1.id, initative1],
  [initative2.id, initative2],
  [initative3.id, initative3],
  [initative4.id, initative4],
  [initative5.id, initative5],
]);

export const effort1 = {
  timeFrameId,
  teamId,
  allocations: [
    {
      effortId: effort1Id,
      initiativeId: initative1.id,
      percentageOfTeamCost: 50n,
    },
    {
      effortId: effort1Id,
      initiativeId: initative2.id,
      percentageOfTeamCost: 20n,
    },
    {
      effortId: effort1Id,
      initiativeId: initative3.id,
      percentageOfTeamCost: 30n,
    },
  ],
  members: [
    {
      userId: user1.id,
      percent: 100,
    },
    {
      userId: user2.id,
      percent: 50,
    },
    {
      userId: user3.id,
      percent: 70,
    },
    {
      userId: user4.id,
      percent: 20,
    },
  ],
};
