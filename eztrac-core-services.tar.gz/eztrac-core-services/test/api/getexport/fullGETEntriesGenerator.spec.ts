import {initiatives, people, personCostingData, teams, workdays} from './GETExportTestData';
import {expect} from 'chai';
import sinon from 'sinon';
import {papiClient, User} from '../../../src/util/client/papiClient';
import {eztracCostingClient, PersonCostingData} from '../../../src/util/client/eztracCostingClient';
import {eztracVipClient, Initiative} from '../../../src/util/client/eztracVipClient';
import {container} from 'tsyringe';
import {buildRepositories} from '../../common/baseBuilders';
import {AppContext} from '../../../src/api/AppContext';
import {generateFullGetEntries} from '../../../src/api/GETExport/fullGetEntriesGenerator';
import {Effort, EffortMember} from 'src/api/effort/models';
import {FullGetEntry} from 'src/api/GETExport/models';
import {EffortAllocation} from 'src/api/effort/allocation/models';
import {TeamStructure} from '../../../src/api/team/models';
import {Workday} from '../../../src/api/timeframe/models';

const getFullGETEntry = (
  workday: Workday,
  person: User,
  initiative: Initiative,
  costingData: PersonCostingData,
  team: TeamStructure,
  hoursMultiplier = 1
): FullGetEntry => ({
  date: workday.date,
  hours: workday.hours * hoursMultiplier,
  person,
  initiative,
  team,
  costingData,
});

const childInitiative1: Initiative = {
  ...[...initiatives][1][1],
  financeCode: 'codeChild1',
  status: 'status child 1',
};
const parentInitiative: Initiative = {
  ...[...initiatives][0][1],
  financeCode: 'code1',
  status: 'status parent',
};
const initiative: Initiative = {
  ...[...initiatives][2][1],
  financeCode: 'code3',
  status: 'status 3',
};

const initiativeTransformed = {...initiative, fundingInitiative: initiative};
const childInitiativeTransformed = {
  ...childInitiative1,
  fundingInitiative: childInitiative1,
};
const parentInitiativeTransformed = {
  ...parentInitiative,
  fundingInitiative: parentInitiative,
};

const generateInitiativeHierarchy = (): Initiative[] => [
  {...initiative},
  {
    ...parentInitiative,
    children: [
      {
        ...childInitiative1,
      },
    ],
  },
];
const timeFrameId = BigInt(422012);

const efforts: Effort[] = [
  {
    id: BigInt(1),
    teamId: teams[0].teamId,
    timeFrameId,
    cost: 100n,
  },
  {
    id: BigInt(2),
    teamId: teams[1].teamId,
    timeFrameId,
    cost: 100n,
  },
];
const generateAllocations = (): EffortAllocation[] => [
  {
    ...efforts[0],
    effortId: efforts[0].id,
    initiativeId: parentInitiative.id,
    percentageOfTeamCost: 50n,
  },
  {
    ...efforts[0],
    effortId: efforts[0].id,
    initiativeId: childInitiative1.id,
    percentageOfTeamCost: 50n,
  },
  {
    ...efforts[1],
    effortId: efforts[1].id,
    initiativeId: initiative.id,
    percentageOfTeamCost: 100n,
  },
];

const generateMembers = (): EffortMember[] => [
  {
    effortId: efforts[0].id,
    userId: people[0].id,
    percent: 100,
  },
  {
    effortId: efforts[0].id,
    userId: people[1].id,
    percent: 50,
  },
  {
    effortId: efforts[1].id,
    userId: people[1].id,
    percent: 50,
  },
];

const timeFrameRepository = {
  getWorkdaysByTimeFrameIdAndCountry: () => {
    return Promise.resolve([workdays[0], workdays[1]]);
  },
};

describe('Generate full GET entries', () => {
  const sandbox = sinon.createSandbox();
  let allocations: EffortAllocation[];
  let members: EffortMember[];
  let initiativeHierarchy: Initiative[];

  beforeEach(() => {
    allocations = generateAllocations();
    members = generateMembers();
    initiativeHierarchy = generateInitiativeHierarchy();
    const effortRepository = {
      getEffortsByTeamsAndTimeFrames: () => {
        return Promise.resolve(efforts);
      },
      getEffortMembersByTimeframes: () => {
        return Promise.resolve(members);
      },
    };
    const effortAllocationsRepository = {
      getEffortAllocationsByTeamsAndTimeFrames: () => {
        return Promise.resolve(allocations);
      },
    };
    const dbMock = sinon.mock();

    container.register('Database', {
      useValue: dbMock,
    });
    container.register('AppContext', {
      useClass: AppContext,
    });
    container.register('Repositories', {
      useValue: buildRepositories(
        effortRepository,
        timeFrameRepository,
        {},
        effortAllocationsRepository,
        {},
        {}
      ),
    });
    sandbox.stub(papiClient, 'getUsersById').resolves(people);
    sandbox.stub(eztracCostingClient, 'getPersonCostingData').resolves(personCostingData);
    sandbox.stub(eztracVipClient, 'getInitiativeHierarchy').resolves(initiativeHierarchy);
  });
  afterEach(() => {
    sandbox.restore();
  });

  it('returns list of GET entries', async () => {
    const expected: FullGetEntry[] = [
      getFullGETEntry(
        workdays[0],
        people[0],
        parentInitiativeTransformed,
        personCostingData[0],
        teams[0]
      ),
      getFullGETEntry(
        workdays[1],
        people[0],
        parentInitiativeTransformed,
        personCostingData[0],
        teams[0],
        0.5
      ),
      getFullGETEntry(
        workdays[1],
        people[0],
        childInitiativeTransformed,
        personCostingData[0],
        teams[0],
        0.5
      ),
      getFullGETEntry(
        workdays[0],
        people[1],
        childInitiativeTransformed,
        personCostingData[1],
        teams[0]
      ),
      getFullGETEntry(
        workdays[1],
        people[1],
        initiativeTransformed,
        personCostingData[1],
        teams[1]
      ),
    ];
    const result = await generateFullGetEntries(teams, timeFrameId);
    expect(result).to.have.lengthOf(5);
    expect(result).to.deep.equal(expected);
  });
  it('returns list of GET entries omitting allocations with percentageOfTeamCost < 0', async () => {
    allocations[0].percentageOfTeamCost = 0n;
    const expected: FullGetEntry[] = [
      getFullGETEntry(
        workdays[0],
        people[0],
        childInitiativeTransformed,
        personCostingData[0],
        teams[0]
      ),
      getFullGETEntry(
        workdays[0],
        people[1],
        childInitiativeTransformed,
        personCostingData[1],
        teams[0],
        0.5
      ),
      getFullGETEntry(
        workdays[0],
        people[1],
        initiativeTransformed,
        personCostingData[1],
        teams[1],
        0.5
      ),
      getFullGETEntry(
        workdays[1],
        people[1],
        initiativeTransformed,
        personCostingData[1],
        teams[1],
        0.5
      ),
    ];
    const result = await generateFullGetEntries(teams, timeFrameId);
    expect(result).to.deep.equal(expected);
  });
  it('returns list of GET entries omitting allocations with matching initiative with undefined activity id', async () => {
    initiativeHierarchy[0].activityId = undefined;
    const expected: FullGetEntry[] = [
      getFullGETEntry(
        workdays[0],
        people[0],
        parentInitiativeTransformed,
        personCostingData[0],
        teams[0]
      ),
      getFullGETEntry(
        workdays[1],
        people[0],
        parentInitiativeTransformed,
        personCostingData[0],
        teams[0],
        0.5
      ),
      getFullGETEntry(
        workdays[1],
        people[0],
        childInitiativeTransformed,
        personCostingData[0],
        teams[0],
        0.5
      ),
      getFullGETEntry(
        workdays[0],
        people[1],
        childInitiativeTransformed,
        personCostingData[1],
        teams[0]
      ),
    ];
    const result = await generateFullGetEntries(teams, timeFrameId);
    expect(result).to.deep.equal(expected);
  });
  it('returns list of GET entries omitting members with 0 percent allocation', async () => {
    members[0].percent = 0;
    const expected: FullGetEntry[] = [
      getFullGETEntry(
        workdays[0],
        people[1],
        parentInitiativeTransformed,
        personCostingData[1],
        teams[0],
        0.5
      ),
      getFullGETEntry(
        workdays[0],
        people[1],
        childInitiativeTransformed,
        personCostingData[1],
        teams[0],
        0.5
      ),
      getFullGETEntry(
        workdays[1],
        people[1],
        initiativeTransformed,
        personCostingData[1],
        teams[1]
      ),
    ];
    const result = await generateFullGetEntries(teams, timeFrameId);
    expect(result).to.deep.equal(expected);
  });
});
