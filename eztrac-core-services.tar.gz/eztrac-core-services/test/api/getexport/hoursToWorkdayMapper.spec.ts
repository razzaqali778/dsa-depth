import {initiatives, people, personCostingData, teams, workdays} from './GETExportTestData';
import {expect} from 'chai';
import {mapHoursToWorkdays} from '../../../src/api/GETExport/hoursToWorkdayMapper';

const totalHours = 64;

const workdaysToAllocate = [workdays[0], workdays[5], workdays[6]];

describe('Map hours to workdays:', () => {
  it('single person all hours on a single initiative', () => {
    const personAllocation = [
      {
        hours: totalHours,
        person: people[0],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[0],
      },
    ];
    const expected = [
      {
        ...personAllocation[0],
        date: workdays[0].date,
        hours: workdays[0].hours,
      },
      {
        ...personAllocation[0],
        date: workdays[5].date,
        hours: workdays[5].hours,
      },
      {
        ...personAllocation[0],
        date: workdays[6].date,
        hours: workdays[6].hours,
      },
    ];
    const result = mapHoursToWorkdays(personAllocation, workdaysToAllocate);
    expect(result).to.deep.equal(expected);
  });
  it('two people all hours on a single initiative', () => {
    const personAllocation = [
      {
        hours: totalHours,
        person: people[0],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[0],
      },
      {
        hours: totalHours,
        person: people[1],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[1],
      },
    ];
    const expected = [
      {
        ...personAllocation[0],
        date: workdays[0].date,
        hours: workdays[0].hours,
      },
      {
        ...personAllocation[0],
        date: workdays[5].date,
        hours: workdays[5].hours,
      },
      {
        ...personAllocation[0],
        date: workdays[6].date,
        hours: workdays[6].hours,
      },
      {
        ...personAllocation[1],
        date: workdays[0].date,
        hours: workdays[0].hours,
      },
      {
        ...personAllocation[1],
        date: workdays[5].date,
        hours: workdays[5].hours,
      },
      {
        ...personAllocation[1],
        date: workdays[6].date,
        hours: workdays[6].hours,
      },
    ];
    const result = mapHoursToWorkdays(personAllocation, workdaysToAllocate);
    expect(result).to.deep.equal(expected);
  });
  it('one person all hours on a single initiative, another person only partial hours on same initiative', () => {
    const personAllocation = [
      {
        hours: totalHours,
        person: people[0],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[0],
      },
      {
        hours: totalHours * 0.5,
        person: people[1],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[1],
      },
    ];
    const expected = [
      {
        ...personAllocation[0],
        date: workdays[0].date,
        hours: workdays[0].hours,
      },
      {
        ...personAllocation[0],
        date: workdays[5].date,
        hours: workdays[5].hours,
      },
      {
        ...personAllocation[0],
        date: workdays[6].date,
        hours: workdays[6].hours,
      },
      {
        ...personAllocation[1],
        date: workdaysToAllocate[0].date,
        hours: workdaysToAllocate[0].hours,
      },
      {
        ...personAllocation[1],
        date: workdaysToAllocate[1].date,
        hours: 8,
      },
    ];
    const result = mapHoursToWorkdays(personAllocation, workdaysToAllocate);
    expect(result).to.deep.equal(expected);
  });
  it('one person hours split across multiple initiatives, single team', () => {
    const personAllocation = [
      {
        hours: totalHours * 0.75,
        person: people[0],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[0],
      },
      {
        hours: totalHours * 0.25,
        person: people[0],
        team: teams[0],
        initiative: [...initiatives][1][1],
        costingData: personCostingData[0],
      },
    ];
    const expected = [
      {
        ...personAllocation[0],
        date: workdaysToAllocate[0].date,
        hours: workdaysToAllocate[0].hours,
      },
      {
        ...personAllocation[0],
        date: workdaysToAllocate[1].date,
        hours: workdaysToAllocate[1].hours,
      },
      {
        ...personAllocation[1],
        date: workdaysToAllocate[2].date,
        hours: workdaysToAllocate[2].hours,
      },
    ];
    const result = mapHoursToWorkdays(personAllocation, workdaysToAllocate);
    expect(result).to.deep.equal(expected);
  });
  it('one person hours split across multiple teams, single initiative', () => {
    const personAllocation = [
      {
        hours: totalHours * 0.5,
        person: people[0],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[0],
      },
      {
        hours: totalHours * 0.5,
        person: people[0],
        team: teams[1],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[0],
      },
    ];
    const expected = [
      {
        ...personAllocation[0],
        date: workdaysToAllocate[0].date,
        hours: workdaysToAllocate[0].hours,
      },
      {
        ...personAllocation[0],
        date: workdaysToAllocate[1].date,
        hours: 8,
      },
      {
        ...personAllocation[1],
        date: workdaysToAllocate[1].date,
        hours: 16,
      },
      {
        ...personAllocation[1],
        date: workdaysToAllocate[2].date,
        hours: workdaysToAllocate[2].hours,
      },
    ];
    const result = mapHoursToWorkdays(personAllocation, workdaysToAllocate);
    expect(result).to.deep.equal(expected);
  });
  it('one person all hours on a single initiative, another person hours split into two initiatives', () => {
    const personAllocation = [
      {
        hours: 64,
        person: people[0],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[0],
      },
      {
        hours: 20,
        person: people[1],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[1],
      },
      {
        hours: 12,
        person: people[1],
        team: teams[0],
        initiative: [...initiatives][1][1],
        costingData: personCostingData[1],
      },
    ];
    const expected = [
      {
        ...personAllocation[0],
        date: workdays[0].date,
        hours: workdays[0].hours,
      },
      {
        ...personAllocation[0],
        date: workdays[5].date,
        hours: workdays[5].hours,
      },
      {
        ...personAllocation[0],
        date: workdays[6].date,
        hours: workdays[6].hours,
      },
      {
        ...personAllocation[1],
        date: workdays[0].date,
        hours: 20,
      },
      {
        ...personAllocation[2],
        date: workdays[0].date,
        hours: 4,
      },
      {
        ...personAllocation[2],
        date: workdays[5].date,
        hours: 8,
      },
    ];
    const result = mapHoursToWorkdays(personAllocation, workdaysToAllocate);
    expect(result).to.deep.equal(expected);
  });
});
