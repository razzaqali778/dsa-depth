import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';
import * as core from 'express-serve-static-core';
import {currentTimeFrame, testData} from '../../common/dataSeed';
import {StatusCodes} from 'http-status-codes';
import supertest from 'supertest';
import sinon from 'sinon';
import {papiClient} from '../../../src/util/client/papiClient';
import {eztracCostingClient} from '../../../src/util/client/eztracCostingClient';
import {eztracVipClient} from '../../../src/util/client/eztracVipClient';
import {adminUserHeader} from '../../common/HttpConstants';
import {FullGetEntry} from 'src/api/GETExport/models';

const initiativeHierarchy = testData.effortAllocations.map(ea => ({
  id: ea.initiativeId,
  name: `${ea.initiativeId} name`,
  typeId: `${ea.initiativeId}_typeId`,
  activityId: `${ea.initiativeId}_activityId`,
}));

const people = testData.persons.map(p => ({
  id: p.id,
  name: p.name,
  manager: {name: `${p.id} manager`},
}));

const personCostingData = testData.persons.map(p => ({
  personId: p.id,
  personName: p.name,
  costGroupName: `${p.id} cost group`,
  rateName: `${p.id} rate`,
  isActive: true,
  isEmployee: true,
}));

describe('Get Export Service', () => {
  let app: core.Express;
  const sandbox = sinon.createSandbox();

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
    sandbox.stub(papiClient, 'getUsersById').resolves(people);
    sandbox.stub(eztracCostingClient, 'getPersonCostingData').resolves(personCostingData);
    sandbox.stub(eztracCostingClient, 'getCalendarHours').resolves([]);
    sandbox.stub(eztracVipClient, 'getInitiativeHierarchy').resolves(initiativeHierarchy);
  });

  after(() => {
    sandbox.restore();
  });

  it('Returns GET entries for a time frame and community', async () => {
    const communityId = testData.communities[0].id;
    const {statusCode, body} = await supertest(app)
      .get(`/getExport/timeFrameId/${currentTimeFrame.id}/communityId/${communityId}`)
      .set(adminUserHeader);

    expect(statusCode).to.eq(StatusCodes.OK);
    expect(body).to.be.not.null;
    expect(body.length).to.equal(14);
    expect(body).to.satisfy((entries: FullGetEntry[]) =>
      entries.every(e => e.team.communityId === communityId)
    );
  });

  it('Returns GET entries for a time frame and platform', async () => {
    const platformId = testData.platforms[1].id;
    const {statusCode, body} = await supertest(app)
      .get(`/getExport/timeFrameId/${currentTimeFrame.id}/platformId/${platformId}`)
      .set(adminUserHeader);

    expect(statusCode).to.eq(StatusCodes.OK);
    expect(body).to.be.not.null;
    expect(body.length).to.be.equal(4);
    expect(body).to.satisfy((entries: FullGetEntry[]) =>
      entries.every(e => e.team.platformId === platformId)
    );
  });

  it('Returns GET entries for a time frame and given teams', async () => {
    const teams = testData.teams;
    const {statusCode, body: entries} = await supertest(app)
      .get(
        `/getExport/timeFrameId/${currentTimeFrame.id}/teams?teamId=${teams[0].id}&teamId=${teams[1].id}`
      )
      .set(adminUserHeader);

    expect(statusCode).to.eq(StatusCodes.OK);
    expect(entries).to.be.not.null;
    expect(entries.length).to.equal(18);
    expect(entries).to.satisfy((entries: FullGetEntry[]) =>
      entries.every(e => e.team.teamId === teams[0].id || e.team.teamId === teams[1].id)
    );
  });

  it('Fails when wrong query parameters provided', async () => {
    const teams = testData.teams;
    const {statusCode} = await supertest(app)
      .get(
        `/getExport/timeFrameId/${currentTimeFrame.id}/teams?wrongParameter=${teams[0].id}&teamId=${teams[1].id}`
      )
      .set(adminUserHeader);

    expect(statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });

  it('Returns GET entries for all of a time frame', async () => {
    const {statusCode, body} = await supertest(app)
      .get(`/getExport/timeFrameId/${currentTimeFrame.id}/all`)
      .set(adminUserHeader);

    expect(statusCode).to.eq(StatusCodes.OK);
    expect(body).to.be.not.null;
    expect(body.length).to.equal(18);
  });
});
