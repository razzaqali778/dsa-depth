import {initiatives, people, personCostingData, teams, workdays} from './GETExportTestData';
import {expect} from 'chai';
import {combineGETEntries} from '../../../src/api/GETExport/getEntriesCombiner';

describe('Combine GET entries', () => {
  it('combines entries that have the same person, date, and activity id', () => {
    const personAllocation = [
      {
        hours: 32,
        person: people[0],
        team: teams[0],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[0],
      },
      {
        hours: 32,
        person: people[0],
        team: teams[1],
        initiative: [...initiatives][0][1],
        costingData: personCostingData[0],
      },
    ];
    const getEntries = [
      {
        ...personAllocation[0],
        date: workdays[0].date,
        hours: workdays[0].hours,
      },
      {
        ...personAllocation[0],
        date: workdays[5].date,
        hours: 8,
      },
      {
        ...personAllocation[1],
        date: workdays[5].date,
        hours: 16,
      },
      {
        ...personAllocation[1],
        date: workdays[6].date,
        hours: workdays[6].hours,
      },
    ];
    const expected = [
      {
        ...personAllocation[0],
        date: workdays[0].date,
        hours: workdays[0].hours,
      },
      {
        ...personAllocation[1],
        date: workdays[5].date,
        hours: 24,
      },
      {
        ...personAllocation[1],
        date: workdays[6].date,
        hours: workdays[6].hours,
      },
    ];
    const result = combineGETEntries(getEntries);
    expect(result).to.deep.equal(expected);
  });
});
