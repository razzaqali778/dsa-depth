import {expect} from 'chai';
import {transformAndFlatten} from '../../../src/api/GETExport/initiativeTransformation';
import {Initiative} from '../../../src/util/client/eztracVipClient';

describe('Transform to initiatives map', () => {
  it('from initiatives hierarchy with all the properties filled in', () => {
    const childInitiative1: Initiative = {
      id: 'childInitiative1',
      name: 'Child initiative 1',
      typeId: 'typeChild1',
      activityId: 'activityChild1',
      financeCode: 'codeChild1',
      status: 'status child 1',
      fundingInitiative: undefined,
    };
    const childInitiative2: Initiative = {
      id: 'childInitiative2',
      name: 'Child initiative 2',
      typeId: 'typeChild2',
      activityId: 'activityChild2',
      financeCode: 'codeChild2',
      status: 'status child 2',
      fundingInitiative: undefined,
    };
    const parentInitiative: Initiative = {
      id: 'parentInitiative',
      name: 'Parent initiative',
      typeId: 'type1',
      activityId: 'activity1',
      financeCode: 'code1',
      status: 'status parent',
      fundingInitiative: undefined,
    };
    const initiativeHierarchy: Initiative[] = [
      {
        ...parentInitiative,
        children: [
          {
            ...childInitiative1,
            children: [
              {
                ...childInitiative2,
              },
            ],
          },
        ],
      },
    ];
    const expected: Map<string, Initiative> = new Map([
      [parentInitiative.id, {...parentInitiative, fundingInitiative: parentInitiative}],
      [childInitiative1.id, {...childInitiative1, fundingInitiative: childInitiative1}],
      [childInitiative2.id, {...childInitiative2, fundingInitiative: childInitiative2}],
    ]);

    const result = transformAndFlatten(initiativeHierarchy);
    expect(result).to.have.lengthOf(3);
    expect([...result]).to.deep.equal([...expected]);
  });
  it('from initiatives hierarchy with all non-required properties omitted', () => {
    const childInitiative1: Initiative = {
      id: 'childInitiative1',
      name: 'Child initiative 1',
      typeId: 'typeChild1',
    };
    const childInitiative2: Initiative = {
      id: 'childInitiative2',
      name: 'Child initiative 2',
      typeId: 'typeChild2',
    };
    const parentInitiative: Initiative = {
      id: 'parentInitiative',
      name: 'Parent initiative',
      typeId: 'type1',
    };
    const initiativeHierarchy: Initiative[] = [
      {
        ...parentInitiative,
        children: [
          {
            ...childInitiative1,
            children: [
              {
                ...childInitiative2,
              },
            ],
          },
        ],
      },
    ];
    const partialUndefinedInitiative = {
      fundingInitiative: undefined,
      activityId: undefined,
      financeCode: undefined,
      status: undefined,
    };
    const expected: Map<string, Initiative> = new Map([
      [parentInitiative.id, {...parentInitiative, ...partialUndefinedInitiative}],
      [childInitiative1.id, {...childInitiative1, ...partialUndefinedInitiative}],
      [childInitiative2.id, {...childInitiative2, ...partialUndefinedInitiative}],
    ]);

    const result = transformAndFlatten(initiativeHierarchy);
    expect(result).to.have.lengthOf(3);
    expect([...result]).to.deep.equal([...expected]);
  });
  it('from initiatives hierarchy with children non-required properties omitted', () => {
    const childInitiative1: Initiative = {
      id: 'childInitiative1',
      name: 'Child initiative 1',
      typeId: 'typeChild1',
    };
    const childInitiative2: Initiative = {
      id: 'childInitiative2',
      name: 'Child initiative 2',
      typeId: 'typeChild2',
    };
    const parentInitiative: Initiative = {
      id: 'parentInitiative',
      name: 'Parent initiative',
      typeId: 'type1',
      activityId: 'activity1',
      financeCode: 'code1',
      status: 'status parent',
      fundingInitiative: undefined,
    };
    const initiativeHierarchy: Initiative[] = [
      {
        ...parentInitiative,
        children: [
          {
            ...childInitiative1,
            children: [
              {
                ...childInitiative2,
              },
            ],
          },
        ],
      },
    ];
    const expected: Map<string, Initiative> = new Map([
      [parentInitiative.id, {...parentInitiative, fundingInitiative: parentInitiative}],
      [
        childInitiative1.id,
        {
          ...parentInitiative,
          ...childInitiative1,
          fundingInitiative: parentInitiative,
        },
      ],
      [
        childInitiative2.id,
        {
          ...parentInitiative,
          ...childInitiative2,
          fundingInitiative: parentInitiative,
        },
      ],
    ]);

    const result = transformAndFlatten(initiativeHierarchy);
    expect(result).to.have.lengthOf(3);
    expect([...result]).to.deep.equal([...expected]);
  });
  it('from initiatives hierarchy with last child non-required properties omitted', () => {
    const childInitiative1: Initiative = {
      id: 'childInitiative1',
      name: 'Child initiative 1',
      typeId: 'typeChild1',
      activityId: 'activityChild1',
      financeCode: 'codeChild1',
      status: 'status child 1',
      fundingInitiative: undefined,
    };
    const childInitiative2: Initiative = {
      id: 'childInitiative2',
      name: 'Child initiative 2',
      typeId: 'typeChild2',
    };
    const parentInitiative: Initiative = {
      id: 'parentInitiative',
      name: 'Parent initiative',
      typeId: 'type1',
      activityId: 'activity1',
      financeCode: 'code1',
      status: 'status parent',
      fundingInitiative: undefined,
    };
    const initiativeHierarchy: Initiative[] = [
      {
        ...parentInitiative,
        children: [
          {
            ...childInitiative1,
            children: [
              {
                ...childInitiative2,
              },
            ],
          },
        ],
      },
    ];
    const expected: Map<string, Initiative> = new Map([
      [parentInitiative.id, {...parentInitiative, fundingInitiative: parentInitiative}],
      [childInitiative1.id, {...childInitiative1, fundingInitiative: childInitiative1}],
      [
        childInitiative2.id,
        {
          ...childInitiative1,
          ...childInitiative2,
          fundingInitiative: childInitiative1,
        },
      ],
    ]);

    const result = transformAndFlatten(initiativeHierarchy);
    expect(result).to.have.lengthOf(3);
    expect([...result]).to.deep.equal([...expected]);
  });
});
