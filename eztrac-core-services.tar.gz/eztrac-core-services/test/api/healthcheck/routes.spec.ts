import {expect} from 'chai';
import {setupCoreDatabase} from '../../common/databaseSetup';
import chai from 'chai';
import * as core from 'express-serve-static-core';
import {StatusCodes} from 'http-status-codes';
import supertest from 'supertest';
import {
  seedEffortAllocations,
  seedEffortMembers,
  seedEfforts,
  seedPersons,
  seedTeams,
  seedTimeFrames,
} from '../../common/dataSeed';
import {adminUserHeader} from '../../common/HttpConstants';
import {allocationsNot100Error, noCostsError} from '../../../src/api/healthcheck/effortHealthCheck';
import {HealthCheck} from '../../../src/api/healthcheck/models';
import {
  effortAllocations,
  efforts,
  effortMembers,
  teams,
  timeFrames,
  persons,
  team3,
  team1,
  initiatives,
} from './healthCheckTestData';
import {container} from 'tsyringe';
import {AppContext} from '../../../src/api/AppContext';
import sinon from 'sinon';
import {eztracVipClient} from '../../../src/util/client/eztracVipClient';

chai.use(require('chai-as-promised'));

describe('Health check route end to end tests', () => {
  let app: core.Express;

  before(async () => {
    app = require('../../../server').app;
    await setupCoreDatabase();
    const db = container.resolve(AppContext).db;
    await seedTimeFrames(db, timeFrames);
    await seedTeams(
      db,
      teams.map(t => ({
        id: t.teamId,
        name: t.teamName,
        communityId: t.communityId,
        isActive: t.isActive,
      }))
    );
    await seedPersons(db, persons);
    await seedEfforts(db, efforts);
    await seedEffortMembers(db, effortMembers);
    await seedEffortAllocations(db, effortAllocations);

    const sandbox = sinon.createSandbox();
    sandbox.stub(eztracVipClient, 'getInitiativeHierarchy').resolves(initiatives);
  });

  it('returns health check for time frame id with a single effort, no errors', async () => {
    const timeFrameId = timeFrames[4].id;
    const response = await supertest(app)
      .get(`/healthCheck/efforts/timeFrameId/${timeFrameId}`)
      .set(adminUserHeader);
    const result = response.body;
    expect(result.length).to.eq(0);
    expect(response.statusCode).to.eq(StatusCodes.OK);
  });

  it('returns health check for time frame id with single effort, single error', async () => {
    const timeFrameId = timeFrames[3].id;
    const response = await supertest(app)
      .get(`/healthCheck/efforts/timeFrameId/${timeFrameId}`)
      .set(adminUserHeader);
    const result = response.body;
    expect(result).to.not.be.null;
    expect(result[0].timeFrameName).to.eq(timeFrames[3].name);
    expect(result[0].teamName).to.eq(team3.teamName);
    expect(result[0].teamId).to.eq(team3.teamId);
    expect(result[0].errors[0]).to.eq(allocationsNot100Error(0n));
    expect(response.statusCode).to.eq(StatusCodes.OK);
  });

  it('returns health check for time frame id with multiple efforts, first one with multiple errors', async () => {
    const timeFrameId = timeFrames[2].id;
    const response = await supertest(app)
      .get(`/healthCheck/efforts/timeFrameId/${timeFrameId}`)
      .set(adminUserHeader);
    const result = response.body;
    expect(result).to.not.be.null;
    // Helper to find a result by teamId
    const findByTeamId = (teamId: string) =>
      (result as HealthCheck[]).find(r => r.teamId === teamId);

    const team3Result = findByTeamId(team3.teamId);
    expect(team3Result).to.not.be.undefined;
    expect(team3Result!.timeFrameName).to.eq(timeFrames[2].name);
    expect(team3Result!.teamId).to.eq(team3.teamId);
    expect(team3Result!.teamName).to.eq(team3.teamName);
    expect(team3Result!.errors).to.include(noCostsError);
    expect(team3Result!.errors).to.include(allocationsNot100Error(90n));

    const team1Result = findByTeamId(team1.teamId);
    expect(team1Result).to.not.be.undefined;
    expect(team1Result!.timeFrameName).to.eq(timeFrames[2].name);
    expect(team1Result!.teamId).to.eq(team1.teamId);
    expect(team1Result!.teamName).to.eq(team1.teamName);
    expect(team1Result!.errors).to.include(noCostsError);
    expect(response.statusCode).to.eq(StatusCodes.OK);
  });

  it('fails if provided time frame id does not exist', async () => {
    const badTimeFrameId = 999n;
    const response = await supertest(app)
      .get(`/healthCheck/efforts/timeFrameId/${badTimeFrameId}`)
      .set(adminUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.NOT_FOUND);
  });

  it('fails if provided time frame id is invalid', async () => {
    const badTimeFrameId = 'aaa';
    const response = await supertest(app)
      .get(`/healthCheck/efforts/timeFrameId/${badTimeFrameId}`)
      .set(adminUserHeader);
    expect(response.statusCode).to.eq(StatusCodes.BAD_REQUEST);
  });
});
