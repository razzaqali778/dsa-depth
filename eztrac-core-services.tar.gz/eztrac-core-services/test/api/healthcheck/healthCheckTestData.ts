import {TimeFrame} from '../../../src/api/timeframe/models';
import {
  addMonths,
  communities,
  getTimeFrameStartAndEndDate,
  orgs,
  platforms,
} from '../../common/dataSeed';
import {TeamStructure} from '../../../src/api/team/models';
import {Initiative} from '../../../src/util/client/eztracVipClient';
import {transformAndFlatten} from '../../../src/api/GETExport/initiativeTransformation';
import {GenericParticipant, Participant} from '../../../src/api/person/models';
import {Effort, EffortEntity, EffortMember} from '../../../src/api/effort/models';
import {EffortAllocation} from '../../../src/api/effort/allocation/models';
import {InitiativeAllocation} from '../../../src/api/initiative/initiative';

export const timeFrames: TimeFrame[] = [
  {
    id: 10n,
    name: 'Time frame - current',
    lockdown: false,
    isActive: true,
    ...getTimeFrameStartAndEndDate(new Date()),
  },
  {
    id: 11n,
    name: 'Time frame 1 month in future',
    lockdown: false,
    isActive: true,
    ...getTimeFrameStartAndEndDate(addMonths(new Date(), 1)),
  },
  {
    id: 12n,
    name: 'Time frame 2 months in future',
    lockdown: false,
    isActive: true,
    ...getTimeFrameStartAndEndDate(addMonths(new Date(), 2)),
  },
  {
    id: 13n,
    name: 'Time frame 1 month ago',
    lockdown: false,
    isActive: true,
    ...getTimeFrameStartAndEndDate(addMonths(new Date(), -1)),
  },
  {
    id: 14n,
    name: 'Time frame 2 months ago',
    lockdown: false,
    isActive: true,
    ...getTimeFrameStartAndEndDate(addMonths(new Date(), -2)),
  },
];

export const team1: TeamStructure = {
  teamId: 'TEST-TEAM11',
  teamName: 'Test team 11',
  communityId: communities[0].id,
  platformId: platforms[0].id,
  communityName: communities[0].name,
  platformName: platforms[0].name,
  orgId: orgs[0].id,
  orgName: orgs[0].name,
  isActive: true,
};
export const team2: TeamStructure = {
  teamId: 'TEST-TEAM12',
  teamName: 'Test team 12',
  communityId: communities[0].id,
  platformId: platforms[0].id,
  communityName: communities[0].name,
  platformName: platforms[0].name,
  orgId: orgs[0].id,
  orgName: orgs[0].name,
  isActive: true,
};
export const team3: TeamStructure = {
  teamId: 'TEST-TEAM13',
  teamName: 'Test team 13',
  communityId: communities[0].id,
  platformId: platforms[0].id,
  communityName: communities[0].name,
  platformName: platforms[0].name,
  orgId: orgs[0].id,
  orgName: orgs[0].name,
  isActive: true,
};

export const teams = [team1, team2, team3];

export const fundedInit1: Initiative = {
  id: 'FUNDED-11',
  name: 'Funding Initiative 11',
  typeId: 'sth11',
  status: 'Funded',
};
export const fundedInit2: Initiative = {
  id: 'FUNDED-12',
  name: 'Funding Initiative 12',
  typeId: 'sth12',
  status: 'Funded',
};
export const completedInit1: Initiative = {
  id: 'COMPLETED-11',
  name: 'Completed Initiative 11',
  typeId: 'sth11',
  status: 'Completed',
};
export const completedInit2: Initiative = {
  id: 'COMPLETED-12',
  name: 'Completed Initiative 12',
  typeId: 'sth12',
  status: 'Completed',
};
export const planningInit1: Initiative = {
  id: 'PLANNING-11',
  name: 'Planning Initiative 11',
  typeId: 'sth11',
  status: 'Planning',
};
export const planningInit2: Initiative = {
  id: 'PLANNING-12',
  name: 'Planning Initiative 12',
  typeId: 'sth12',
  status: 'Planning',
};

export const initiatives = [
  fundedInit1,
  fundedInit2,
  completedInit1,
  completedInit2,
  planningInit1,
  planningInit2,
];
export const initMap = transformAndFlatten(initiatives);
export const participant1: Participant = {userId: 'PERSON-1', percent: 100};
export const forecastPeople: GenericParticipant = {
  numberOfPeople: 1,
  rateId: 'SOME-RATE',
  costGroupId: 'SOME-COST-GROUP',
};

export const efforts: Effort[] = [
  {id: BigInt(6), timeFrameId: timeFrames[0].id, teamId: teams[0].teamId, cost: 0n},
  {id: BigInt(7), timeFrameId: timeFrames[1].id, teamId: teams[1].teamId, cost: 0n},
  {id: BigInt(8), timeFrameId: timeFrames[2].id, teamId: teams[2].teamId, cost: 0n},
  {id: BigInt(9), timeFrameId: timeFrames[0].id, teamId: teams[1].teamId, cost: 0n},
  {id: BigInt(10), timeFrameId: timeFrames[1].id, teamId: teams[2].teamId, cost: 0n},
  {id: BigInt(11), timeFrameId: timeFrames[2].id, teamId: teams[0].teamId, cost: 0n},
  {id: BigInt(12), timeFrameId: timeFrames[3].id, teamId: teams[2].teamId, cost: 0n},
  {id: BigInt(13), timeFrameId: timeFrames[4].id, teamId: teams[0].teamId, cost: 0n},
];

export const effortMembers: Partial<EffortMember>[] = [
  {
    userId: participant1.userId,
    effortId: efforts[0].id,
    percent: 100,
  },
  {
    userId: participant1.userId,
    effortId: efforts[1].id,
    percent: 100,
  },
  {
    userId: participant1.userId,
    effortId: efforts[3].id,
    percent: 100,
  },
  {
    userId: participant1.userId,
    effortId: efforts[4].id,
    percent: 100,
  },
  {
    userId: participant1.userId,
    effortId: efforts[6].id,
    percent: 100,
  },
  {
    userId: participant1.userId,
    effortId: efforts[7].id,
    percent: 100,
  },
];

export const persons: {id: string; name: string}[] = [{id: participant1.userId, name: 'TestName'}];

export const effortAllocations: Partial<EffortAllocation>[] = [
  {
    effortId: efforts[0].id,
    percentageOfTeamCost: BigInt(50),
    initiativeId: fundedInit1.id,
  },
  {
    effortId: efforts[1].id,
    percentageOfTeamCost: BigInt(100),
    initiativeId: fundedInit2.id,
  },
  {
    effortId: efforts[2].id,
    percentageOfTeamCost: BigInt(90),
    initiativeId: planningInit1.id,
  },
  {
    effortId: efforts[3].id,
    percentageOfTeamCost: BigInt(100),
    initiativeId: planningInit2.id,
  },
  {
    effortId: efforts[4].id,
    percentageOfTeamCost: BigInt(100),
    initiativeId: completedInit1.id,
  },
  {
    effortId: efforts[5].id,
    percentageOfTeamCost: BigInt(100),
    initiativeId: completedInit2.id,
  },
  {
    effortId: efforts[7].id,
    percentageOfTeamCost: BigInt(100),
    initiativeId: fundedInit1.id,
  },
];

export const initiativeHierarchy: Initiative[] = effortAllocations.map(ea => ({
  id: ea.initiativeId!,
  name: `${ea.initiativeId} name`,
  typeId: `${ea.initiativeId}_typeId`,
  activityId: `${ea.initiativeId}_activityId`,
}));

export const effortEntities: EffortEntity[] = [
  {
    timeFrameId: timeFrames[0].id,
    teamId: team1.teamId,
    allocations: [new InitiativeAllocation(fundedInit1.id, 100n)],
    members: [participant1],
    forecastPeople: undefined,
  },
  {
    timeFrameId: timeFrames[0].id,
    teamId: team1.teamId,
    allocations: undefined,
    members: undefined,
    forecastPeople: undefined,
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[0].id,
    teamId: team1.teamId,
    allocations: [new InitiativeAllocation(fundedInit1.id, 100n)],
    members: undefined,
    forecastPeople: undefined,
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[0].id,
    teamId: team1.teamId,
    allocations: [new InitiativeAllocation(fundedInit1.id, 100n)],
    members: undefined,
    forecastPeople: [forecastPeople],
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[1].id,
    teamId: team1.teamId,
    allocations: [new InitiativeAllocation(fundedInit1.id, 100n)],
    members: undefined,
    forecastPeople: [forecastPeople],
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[0].id,
    teamId: team1.teamId,
    allocations: [
      new InitiativeAllocation(fundedInit1.id, 50n),
      new InitiativeAllocation(fundedInit2.id, 25n),
    ],
    members: [participant1],
    forecastPeople: undefined,
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[0].id,
    teamId: team1.teamId,
    allocations: [
      new InitiativeAllocation(fundedInit1.id, 25n),
      new InitiativeAllocation(fundedInit2.id, 25n),
      new InitiativeAllocation(completedInit1.id, 25n),
      new InitiativeAllocation(completedInit2.id, 25n),
    ],
    members: [participant1],
    forecastPeople: undefined,
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[0].id,
    teamId: team1.teamId,
    allocations: [
      new InitiativeAllocation(fundedInit1.id, 25n),
      new InitiativeAllocation(fundedInit2.id, 25n),
      new InitiativeAllocation(planningInit1.id, 25n),
      new InitiativeAllocation(planningInit2.id, 25n),
    ],
    members: [participant1],
    forecastPeople: undefined,
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[1].id,
    teamId: team1.teamId,
    allocations: [
      new InitiativeAllocation(fundedInit1.id, 25n),
      new InitiativeAllocation(fundedInit2.id, 25n),
      new InitiativeAllocation(planningInit1.id, 25n),
      new InitiativeAllocation(planningInit2.id, 25n),
    ],
    members: [participant1],
    forecastPeople: undefined,
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[0].id,
    teamId: team1.teamId,
    allocations: [new InitiativeAllocation(fundedInit1.id, 100n)],
    members: [participant1],
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[0].id,
    teamId: team2.teamId,
    allocations: undefined,
    members: undefined,
    forecastPeople: undefined,
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[0].id,
    teamId: team3.teamId,
    allocations: [
      new InitiativeAllocation(fundedInit1.id, 25n),
      new InitiativeAllocation(fundedInit2.id, 25n),
      new InitiativeAllocation(completedInit1.id, 25n),
      new InitiativeAllocation(completedInit2.id, 25n),
    ],
    members: [participant1],
    forecastPeople: undefined,
    engagements: undefined,
  },
  {
    timeFrameId: timeFrames[4].id,
    teamId: team1.teamId,
    allocations: [new InitiativeAllocation(fundedInit1.id, 100n)],
    members: [participant1],
    forecastPeople: undefined,
    engagements: undefined,
  },
];
