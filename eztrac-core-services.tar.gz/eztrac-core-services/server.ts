import express, {NextFunction, Request, Response, Express} from 'express';
import path from 'path';
import 'reflect-metadata';
import {container} from 'tsyringe';
import {AppContext} from './src/api/AppContext';
import {db} from './src/db/dbManager';
import {effortRepository} from './src/api/effort/effortRepository';
import {timeFrameRepository} from './src/api/timeframe/timeFrameRepository';
import {teamRepository} from './src/api/team/teamRepository';
import {platformRepository} from './src/api/platform/platformRepository';
import {effortAllocationsRepository} from './src/api/effort/allocation/effortAllocationsRepository';
import {effortEngagementsRepository} from './src/api/effort/engagement/effortEngagementsRepository';
import {effortMembersRepository} from './src/api/effort/members/effortMembersRepository';
import {personRepository} from './src/api/person/personRepository';
import {communityRepository} from './src/api/community/communityRepository';
import {orgRepository} from './src/api/org/orgRepository';
import {spendRepository} from './src/api/spend/spendRepository';
import {StatusCodes} from 'http-status-codes';

import costCalcApi from './src/api/costcalc/routes';
import effortApi from './src/api/effort/effortRoute';
import getExportApi from './src/api/GETExport/routes';
import timeFrameApi from './src/api/timeframe/routes';
import effortAllocationApi from './src/api/effort/allocation/effortAllocationRoute';
import teamApi from './src/api/team/teamRoute';
import spendApi from './src/api/spend/routes';
import healthCheckApi from './src/api/healthcheck/routes';
import effortEngagementApi from './src/api/effort/engagement/effortEngagementRoute';
import effortMembersApi from './src/api/effort/members/effortMemberRoute';
import platformApi from './src/api/platform/platformRoute';
import communityApi from './src/api/community/communityRoute';
import orgApi from './src/api/org/orgRoute';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
(BigInt.prototype as any).toJSON = function () {
  return this.toString();
};

// Date values are serialized to epoch milliseconds on a per-response basis by the
// `apiResponse` middleware instead of here, to avoid mutating Date.prototype globally.

const dbInstance = db();

container.register('Database', {
  useValue: dbInstance,
});

container.register('Repositories', {
  useValue: {
    effortRepository: effortRepository,
    timeFrameRepository: timeFrameRepository,
    teamRepository: teamRepository,
    effortAllocationsRepository: effortAllocationsRepository,
    effortEngagementsRepository: effortEngagementsRepository,
    effortMembersRepository: effortMembersRepository,
    personRepository: personRepository,
    platformRepository: platformRepository,
    communityRepository: communityRepository,
    orgRepository: orgRepository,
    spendRepository: spendRepository,
  },
});

container.register('AppContext', {
  useClass: AppContext,
});

const compression = require('compression');
const pingPage = require('@monsantoit/ping-page');
const bodyParser = require('body-parser');

const swaggerMiddleware = require('./src/middleware/swagger');

const pkg = require(path.resolve('./package.json'));

const appBaseUrl = '';
const v2AppBaseUrl = '/v2';
const app: Express = express();

const localDevelopment = process.env.NODE_ENV === 'development';
if (localDevelopment) {
  app.use(require('cors')());
  const profileMiddleware = require('@monsantoit/profile-middleware');
  const localDevProfile = {
    id: 'test_user',
    entitlements: {
      'ez-trac': ['eztrac-admin-user'],
    },
  };
  app.use(profileMiddleware({localDevProfile: localDevProfile}));
}

app.use(bodyParser.json({limit: '50mb'}));
app.use(compression());
app.get(`/ping|${appBaseUrl}/ping`, pingPage(pkg)); // for accessing through ocelot

app.use(`${appBaseUrl}/`, costCalcApi.router);
app.use(`${appBaseUrl}/`, effortApi.router);
app.use(`${appBaseUrl}/`, getExportApi.router);
app.use(`${appBaseUrl}/`, effortAllocationApi.router);
app.use(`${appBaseUrl}/`, teamApi.router);
app.use(`${appBaseUrl}/`, timeFrameApi.router);
app.use(`${appBaseUrl}/`, spendApi.router);
app.use(`${appBaseUrl}/`, healthCheckApi.router);
app.use(`${appBaseUrl}/`, effortEngagementApi.router);
app.use(`${appBaseUrl}/`, effortMembersApi.router);
app.use(`${appBaseUrl}/`, platformApi.router);
app.use(`${appBaseUrl}/`, communityApi.router);
app.use(`${appBaseUrl}/`, orgApi.router);

// v2 routes for backwards compatibility
app.use(`${v2AppBaseUrl}/`, costCalcApi.router);
app.use(`${v2AppBaseUrl}/`, effortApi.router);
app.use(`${v2AppBaseUrl}/`, getExportApi.router);
app.use(`${v2AppBaseUrl}/`, effortAllocationApi.router);
app.use(`${v2AppBaseUrl}/`, teamApi.router);
app.use(`${v2AppBaseUrl}/`, timeFrameApi.router);
app.use(`${v2AppBaseUrl}/`, spendApi.router);
app.use(`${v2AppBaseUrl}/`, healthCheckApi.router);
app.use(`${v2AppBaseUrl}/`, effortEngagementApi.router);
app.use(`${v2AppBaseUrl}/`, effortMembersApi.router);
app.use(`${v2AppBaseUrl}/`, platformApi.router);
app.use(`${v2AppBaseUrl}/`, communityApi.router);
app.use(`${v2AppBaseUrl}/`, orgApi.router);

swaggerMiddleware(app, appBaseUrl);

app.use('/*', (err: Error, req: Request, res: Response, next: NextFunction) => {
  if (err.status) {
    console.error(err);
    res.status(err.status).send({message: err.message});
  } else {
    next(err);
  }
});

app.use('/*', (err: unknown, req: Request, res: Response, _next: NextFunction) => {
  // handle uncaught errors
  console.error(err);
  // Do not call next(err) here: the response has already been fully sent, so forwarding to
  // Express's default error handler only produces a spurious "Cannot set headers after they are
  // sent to the client" error on every 500 response.
  if (res.headersSent) return;
  res.status(StatusCodes.INTERNAL_SERVER_ERROR).send();
});

const setupServer = () => {
  const port = parseInt(process.env.PORT || '3560', 10);
  const hostname = process.env.NODE_ENV === 'production' ? undefined : '127.0.0.1'; // unlike default, only reachable from this machine
  /* eslint-disable @typescript-eslint/ban-ts-comment */
  // @ts-ignore for now TODO
  const server = app.listen(port, hostname, () => {
    const address = server.address();
    // @ts-ignore for now TODO
    const url = `http://${address.host || 'localhost'}:${port}`;
    console.info(`Listening at ${url}${appBaseUrl}/`);
    console.info(`Swagger at ${url}${appBaseUrl}/v1/docs`);
  });
  /* eslint-enable @typescript-eslint/ban-ts-comment */

  return server;
};

const start = async () => setupServer();

module.exports = {start, app};
