--
-- PostgreSQL database dump
--

-- Dumped from database version 12.8
-- Dumped by pg_dump version 14.4

--
-- Name: community; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.community (
    community_id text NOT NULL,
    community_name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    platform_id text DEFAULT 'UNKNOWN-PLATFORM'::text NOT NULL
);


--
-- Name: forecast_person; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forecast_person (
    team_cost_id bigint NOT NULL,
    people_number numeric DEFAULT 0 NOT NULL,
    rate_id integer DEFAULT 0 NOT NULL,
    external_rate_id text DEFAULT 'STANDARD'::text NOT NULL,
    cost_group_id text DEFAULT 'UNKNOWN'::text NOT NULL
);


--
-- Name: person; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person (
    user_id text NOT NULL,
    name text NOT NULL,
    rate_id integer DEFAULT 0 NOT NULL
);

--
-- Name: org; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.org (
    org_id text NOT NULL,
    org_name text NOT NULL,
    is_active boolean NOT NULL DEFAULT true
);


--
-- Name: platform; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform (
    platform_id text NOT NULL,
    platform_name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    org_id text DEFAULT 'UNKNOWN-ORG'::text NOT NULL
);


--
-- Name: rate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate (
    rate_name text NOT NULL,
    hourly_rate bigint NOT NULL,
    export_role text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    rate_id integer NOT NULL
);


--
-- Name: rate_rate_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rate_rate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rate_rate_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rate_rate_id_seq OWNED BY public.rate.rate_id;


--
-- Name: seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.seq
    START WITH 1488
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team (
    team_name text NOT NULL,
    inactive_start_date timestamp without time zone,
    team_id text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    community_id text NOT NULL
);


--
-- Name: team_cost; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_cost (
    timeframe_id bigint NOT NULL,
    cost bigint DEFAULT '0'::bigint NOT NULL,
    team_cost_id bigint DEFAULT nextval('public.seq'::regclass) NOT NULL,
    team_id text
);


--
-- Name: team_cost_allocation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_cost_allocation (
    team_cost_id bigint,
    team_cost_pct bigint DEFAULT 0 NOT NULL,
    vip_initiative_id text,
    team_cost_allocation_id integer NOT NULL
);


--
-- Name: team_cost_allocation_team_cost_allocation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.team_cost_allocation_team_cost_allocation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: team_cost_allocation_team_cost_allocation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.team_cost_allocation_team_cost_allocation_id_seq OWNED BY public.team_cost_allocation.team_cost_allocation_id;


--
-- Name: team_cost_breakdown; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_cost_breakdown (
    team_cost_id integer NOT NULL,
    cost_group_id text NOT NULL,
    cost integer DEFAULT 0 NOT NULL,
    engagement_id text,
    person_id text
);


--
-- Name: team_cost_engagement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_cost_engagement (
    team_cost_id bigint NOT NULL,
    amount_type text,
    engagement_id text NOT NULL,
    amount integer NOT NULL,
    comment text,
    amount_details text
);


--
-- Name: team_cost_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.team_cost_member (
    user_id text NOT NULL,
    team_cost_id bigint NOT NULL,
    participation_pct smallint NOT NULL,
    rate_id integer DEFAULT 0 NOT NULL
);


--
-- Name: timeframe; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timeframe (
    timeframe_id bigint NOT NULL,
    timeframe_name text,
    timeframe_start_date timestamp with time zone,
    timeframe_end_date timestamp with time zone,
    lockdown boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: team_cost_vw; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.team_cost_vw AS
 SELECT team.team_name,
    timeframe.timeframe_name,
    team_cost.cost,
    team_cost.team_cost_id,
    team_cost.timeframe_id,
    team_cost.team_id,
    team.inactive_start_date,
    timeframe.timeframe_start_date,
    timeframe.timeframe_end_date
   FROM ((public.team_cost
     JOIN public.team USING (team_id))
     JOIN public.timeframe USING (timeframe_id))
  ORDER BY timeframe.timeframe_start_date, team.team_name;


--
-- Name: timeframe_workdays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timeframe_workdays (
    timeframe_id bigint NOT NULL,
    country text NOT NULL,
    workday_hours text NOT NULL
);


--
-- Name: rate rate_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate ALTER COLUMN rate_id SET DEFAULT nextval('public.rate_rate_id_seq'::regclass);


--
-- Name: team_cost_allocation team_cost_allocation_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost_allocation ALTER COLUMN team_cost_allocation_id SET DEFAULT nextval('public.team_cost_allocation_team_cost_allocation_id_seq'::regclass);


--
-- Name: org org_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT org_pk PRIMARY KEY (org_id);


--
-- Name: community community_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community
    ADD CONSTRAINT community_pk PRIMARY KEY (community_id);


--
-- Name: community community_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.community
    ADD CONSTRAINT community_uk UNIQUE (community_name);


--
-- Name: forecast_person forecast_person_primary_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forecast_person
    ADD CONSTRAINT forecast_person_primary_key PRIMARY KEY (team_cost_id, external_rate_id, cost_group_id);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (user_id);


--
-- Name: platform platform_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform
    ADD CONSTRAINT platform_pk PRIMARY KEY (platform_id);


--
-- Name: platform platform_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform
    ADD CONSTRAINT platform_uk UNIQUE (platform_name);


--
-- Name: rate rate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_pkey PRIMARY KEY (rate_id);


--
-- Name: rate rate_uk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate
    ADD CONSTRAINT rate_uk UNIQUE (rate_name);


--
-- Name: team_cost_allocation team_cost_allocation_natural_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost_allocation
    ADD CONSTRAINT team_cost_allocation_natural_key UNIQUE (team_cost_id, vip_initiative_id);


--
-- Name: team_cost_allocation team_cost_allocation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost_allocation
    ADD CONSTRAINT team_cost_allocation_pkey PRIMARY KEY (team_cost_allocation_id);


--
-- Name: team_cost team_cost_natural_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost
    ADD CONSTRAINT team_cost_natural_key UNIQUE (timeframe_id, team_id);


--
-- Name: team_cost team_cost_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost
    ADD CONSTRAINT team_cost_pkey PRIMARY KEY (team_cost_id);


--
-- Name: team team_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_id PRIMARY KEY (team_id);


--
-- Name: team_cost_member team_member_primary_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost_member
    ADD CONSTRAINT team_member_primary_key PRIMARY KEY (user_id, team_cost_id);


--
-- Name: team team_name_ak; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_name_ak UNIQUE (team_name);


--
-- Name: timeframe timeframe_name_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timeframe
    ADD CONSTRAINT timeframe_name_unique UNIQUE (timeframe_name);


--
-- Name: timeframe timeframe_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timeframe
    ADD CONSTRAINT timeframe_pk PRIMARY KEY (timeframe_id);


--
-- Name: timeframe_workdays timeframe_workdays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timeframe_workdays
    ADD CONSTRAINT timeframe_workdays_pkey PRIMARY KEY (timeframe_id, country);


--
-- Name: fki_team_community_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_team_community_id_fk ON public.team USING btree (community_id);


--
-- Name: team_cost_breakdown_team_cost_id_idk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_cost_breakdown_team_cost_id_idk ON public.team_cost_breakdown USING btree (team_cost_id);


--
-- Name: team_cost_engagement_primary_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX team_cost_engagement_primary_key ON public.team_cost_engagement USING btree (team_cost_id, engagement_id);

--
-- Name: community community_platform_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

-- ALTER TABLE ONLY public.community
--     ADD CONSTRAINT community_platform_id_fkey FOREIGN KEY (platform_id) REFERENCES public.platform(platform_id);


--
-- Name: team_cost_allocation effort_allocation_team_cost_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost_allocation
    ADD CONSTRAINT effort_allocation_team_cost_id_fkey FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: forecast_person forecast_person_cost_id_foreign_key; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forecast_person
    ADD CONSTRAINT forecast_person_cost_id_foreign_key FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: team team_community_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_community_id_fk FOREIGN KEY (community_id) REFERENCES public.community(community_id);


--
-- Name: team_cost_breakdown team_cost_breakdown_team_cost_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost_breakdown
    ADD CONSTRAINT team_cost_breakdown_team_cost_id_fkey FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: team_cost_engagement team_cost_engagement_team_cost_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost_engagement
    ADD CONSTRAINT team_cost_engagement_team_cost_id FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: team_cost_member team_cost_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost_member
    ADD CONSTRAINT team_cost_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.person(user_id);


--
-- Name: team_cost team_cost_timeframe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost
    ADD CONSTRAINT team_cost_timeframe_id_fkey FOREIGN KEY (timeframe_id) REFERENCES public.timeframe(timeframe_id);


--
-- Name: team_cost team_id_f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost
    ADD CONSTRAINT team_id_f FOREIGN KEY (team_id) REFERENCES public.team(team_id);


--
-- Name: team_cost_member team_member_team_cost_id_foreign_key; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.team_cost_member
    ADD CONSTRAINT team_member_team_cost_id_foreign_key FOREIGN KEY (team_cost_id) REFERENCES public.team_cost(team_cost_id);


--
-- Name: timeframe_workdays timeframe_workdays_timeframe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timeframe_workdays
    ADD CONSTRAINT timeframe_workdays_timeframe_id_fkey FOREIGN KEY (timeframe_id) REFERENCES public.timeframe(timeframe_id);


--
-- PostgreSQL database dump complete
--

