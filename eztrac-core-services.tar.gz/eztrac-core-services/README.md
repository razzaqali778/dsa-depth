# EZ-Trac Core Services

TypeScript/Express REST API for EZ-Trac core data: teams, efforts, engagements, allocations, platforms, communities, time frames, spend, cost calculation, and GET export. Persists to PostgreSQL and is consumed by [eztrac-core-ui](https://github.com/bayer-int/eztrac-core-ui) and other EZ-Trac clients.

| | | |
|---|---|---|
| **Deployable** | `ez-trac-core-services-aws` | `https://devtools.bayer.com/deployment-approvals/deployables/ez-trac-core-services-aws` |
| **Ocelot** | `ez-trac-core-services.velocity-np.ag`, `ez-trac-core-services.velocity.ag` | [non-prod](https://devtools-np.bayer.com/ocelot?route=ez-trac-core-services.velocity-np.ag), [prod](https://devtools.bayer.com/ocelot?route=ez-trac-core-services.velocity.ag) |

## API overview

REST handlers live under `src/api/`. Routes are mounted at `/` and `/v2` (legacy compatibility). OpenAPI/Swagger is served when the server is running:

- **Swagger UI:** `http://127.0.0.1:3560/v1/docs` (local dev; port from `PORT`, default `3560`)
- **Spec:** `swagger.json`

| Area | Typical paths | Notes |
|---|---|---|
| Teams | `/team`, `/teamStructure`, … | CRUD and queries; write requires manage-teams |
| Efforts | `/effort`, … | Effort and full-effort reads |
| Engagements | `/effortEngagement`, … | Create/update/delete engagements |
| Members | `/effortMember`, … | Effort membership |
| Allocations | `/effortAllocation`, … | Hour allocations by time frame |
| Time frames | `/timeframe`, … | Workdays and time-frame maintenance (admin) |
| Platforms | `/platform`, … | Platform administration |
| Communities | `/community`, … | Community administration |
| Organizations | `/org`, … | Org hierarchy |
| Spend | `/spend`, … | Spend reporting |
| Cost calc | `/costcalc`, … | Team costing updates |
| GET export | `/GETExport`, … | GET reporting export |
| Health check | `/healthcheck`, … | Operational health endpoints |
| Ping | `/ping` | Load balancer / gateway ping |

Downstream HTTP services (costing, VIP) are configured in `src/config/files/` under `ez-trac-urls`.

## Tech stack

- **Runtime:** Node.js **22.22.3** (see `package.json` `engines` and `.nvmrc`)
- **HTTP:** Express 4, `swagger-tools`, Joi validation (`express-joi-validation`)
- **Data:** PostgreSQL (`pg-promise`), migrations via `node-pg-migrate`
- **DI:** `tsyringe`
- **Config / secrets:** [@monsantoit/config](https://config.phoenix-tools-np.io) with Vault resolution
- **Auth:** `@monsantoit/profile-middleware` (entitlements from Phoenix profile headers)
- **Tooling:** TypeScript, GTS (`gts lint` / `gts fix`), Mocha

## Dependencies

| Service | Non-prod | Prod |
|---|---|---|
| **ez-trac-costing** | `https://ez-trac-costing-services.velocity-np.ag` | `https://ez-trac-costing-services.velocity.ag` |
| **ez-trac-vip** | `https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services` | `https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services` |

## Entitlements

Authorization uses Phoenix entitlements (see `src/config/entitlementsConfig.ts` and `src/config/application.conf.json`). Entitlements are managed through [`EzTrac`](https://devtools-np.bayer.com/profile/applications/EZTRAC) PAPI application 

| Entitlement | Used for (examples) |
|---|---|
| `eztrac-write-user`, `eztrac-manage-efforts`, `eztrac-admin-user` | Effort writes, cost calc, many mutation paths |
| `eztrac-manage-teams`, `eztrac-admin-user` | Team create/update |
| `eztrac-admin-user` | Admin-only routes (e.g. some time-frame changes) |

In **local development** (`NODE_ENV=development`), the server applies a built-in dev profile with `eztrac-admin-user` so you can call the API on `127.0.0.1` without Ocelot. The UI still requires Ocelot for browser auth.

## Prerequisites

- **Node.js** `22.22.3` (see `package.json` `engines` and `.nvmrc`)
- **npm** access to Bayer Artifactory (`@monsantoit`, `@bayerit` packages)
- **Vault** CLI access for database and OAuth secrets (local and migrations)
- **PostgreSQL** reachable for local dev (see [DB access setup](https://github.com/bayer-int/eztrac-notes/blob/main/KT%20notes/DB_ACCESS.md); default `localhost:5435` in `src/config/files/development.ts`)

## Local development

### 1. Install dependencies

```bash
npm install
```

Configure [Bayer Artifactory npm](https://docs.int.bayer.com/cloud/devops/artifactory/npm/) if scoped packages fail to resolve.

### 2. Vault

Refresh local Vault auth before starting the app or running migrations. Config values use `vault://` URIs (see [Configuration](#configuration) and [Vault](#vault)).

[Using Vault on the CLI](https://docs.int.bayer.com/cloud/devops/vault/access-vault/#using-vault-on-the-cli)

### 3. Database

Set up local database access per [DB access setup](https://github.com/bayer-int/eztrac-notes/blob/main/KT%20notes/DB_ACCESS.md).

Database credentials are not stored in the repo. They are declared as `vault://` URIs under `/secret/ez-trac/...` in `src/config/files/development.ts` (and other environment files). At startup, the [@monsantoit/config](https://config.phoenix-tools-np.io) package resolves those URIs against Vault and supplies the connection values to the app (see `src/config/index.ts`).

Apply migrations when needed:

```bash
npm run migrate up
```

Migration connection settings are in `migration-config.json`.

### 4. Start the API

```bash
npm run dev
```

The server listens on **http://127.0.0.1:3560** (hostname restricted to localhost in non-production). Swagger: **http://127.0.0.1:3560/v1/docs**.

### 5. Use with eztrac-core-ui (optional)

To exercise the full stack locally, run this service and follow the UI repo’s Ocelot + `npm run dev` steps. Point the UI `local` binding for `ez-trac-core` at `http://127.0.0.1:3560` in [eztrac-core-ui `service-bindings.js`](https://github.com/bayer-int/eztrac-core-ui/blob/main/src/client/service-bindings.js) if you are not using the shared non-prod API.

## Scripts

| Script | Purpose |
|---|---|
| `npm run dev` | Dev server with reload (`ts-node-dev`, `NODE_ENV=development`) |
| `npm run build` | Compile TypeScript and run GTS lint |
| `npm run start` | Production server (`node ./dist/src/bin/www.js`) |
| `npm run test` | Compile, Mocha unit tests (`test/`), then lint |
| `npm run test:integration` | Integration tests (`integrationTests/`; `NODE_ENV=integration-test`) |
| `npm run test:coverage` | Unit tests with NYC HTML report |
| `npm run lint` / `npm run lint:fix` | GTS lint / auto-fix |
| `npm run migrate` | `node-pg-migrate` (see `migration-config.json`) |
| `npm run clean` | Remove `dist`, coverage, and generated public assets |
| `npm run audit` / `npm run audit:fix` | Dependency vulnerability scan / safe fixes |

See [docs/NODE-22-UPGRADE.md](./docs/NODE-22-UPGRADE.md) for the Node 22 upgrade assessment and [docs/PACKAGE-AUDIT-UPGRADE.md](./docs/PACKAGE-AUDIT-UPGRADE.md) for the dependency audit remediation.

**Pre-review manual testing:** see [../PRE-REVIEW-TESTING.md](../PRE-REVIEW-TESTING.md) at the EZTrac workspace root.

## Project layout

```
server.ts                 # Express app, route registration, /v2 mount
src/bin/www.ts            # Entry: config init, RDS CA (prod), start server
src/api/                  # Route modules (team, effort, platform, …)
src/config/               # @monsantoit/config sources and Vault processors
src/db/                   # Database manager
src/middleware/           # Swagger, API response helpers
migrations/               # SQL migrations (node-pg-migrate)
test/                     # Unit tests (*.spec.ts)
integrationTests/         # Integration tests (DB + HTTP)
swagger.json              # OpenAPI base spec
fg-deploy-overrides.json  # Fargate sizing overrides for fg-deploy
```

## Configuration

Environment-specific settings are merged from `src/config/files/` (`default`, `development`, `fargate-np`, `fargate-prod`, `integration-test`, etc.). `src/config/index.ts` selects the file based on `NODE_ENV`, Fargate, and `CONFIG_ENV`.

Full **@monsantoit/config** [documentation](https://backstage.int.bayer.com/catalog/default/Component/phoenix-config/docs/)

Vault URIs in config look like `vault://secret/path/to/secret/key` (`path/to/secret` = Vault path, `key` = field name).

## Testing

**Unit tests** — `npm run test` (runs on every PR via `.github/workflows/pr.yml`).

**Integration tests** — `npm run test:integration`. Locally, uses `localhost` and port `5436` (`src/config/files/integration-test.ts`). In CI, Vault AppRole credentials are supplied and tests run with `--ci` (see `.github/workflows/it.yml`).

## Deployment

Containers are deployed with [fg-deploy](https://docs.int.bayer.com/cloud/smart-aws/offering/service-catalog/fg-deploy/) via GitHub Actions calling [`fg-deploy.yaml`](https://github.com/bayer-int/phx-internal-ci-scripts/blob/v1/.github/workflows/fg-deploy.yaml) from [`bayer-int/phx-internal-ci-scripts`](https://github.com/bayer-int/phx-internal-ci-scripts).

Some fg-deploy settings (AWS account, AWS roles, and related metadata) live in the shared [`phoenix-metadata.json`](https://github.com/bayer-int/phx-internal-ci-scripts/blob/main/dependencies/phoenix-metadata.json) in that repo. This project’s service-specific Fargate sizing is in [`fg-deploy-overrides.json`](./fg-deploy-overrides.json).

| Workflow | Trigger | Purpose |
|---|---|---|
| `np.yml` | Push to `main` | Deploy to non-prod (`build_step: dev`) |
| `prepare.yml` | Manual | Version bump and deployment document (`build_step: prepare`) |
| `release.yml` | Manual | Promote approved version to prod (`build_step: release`) |
| `pr.yml` | Pull request | Unit tests + integration tests |

### Production release and approvals

1. Run **`prepare.yml`** — bumps version, builds, creates a deployment document for `ez-trac-core-services-aws`.
2. **Approve** the deployment in [Deployment Approvals](https://devtools.bayer.com/deployment-approvals/deployables/ez-trac-core-services-aws) ([process docs](https://docs.int.bayer.com/cloud/crop-science/development/tools/deployment-approvals/approvalProcess/#deployment-approvals-approval-process)).
3. Run **`release.yml`** with the approved `deployable_version`.

Non-prod deploys automatically on push to `main`.
