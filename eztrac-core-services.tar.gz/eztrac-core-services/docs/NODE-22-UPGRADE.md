# Node 22.22.3 upgrade — assessment and npm audit

**Date:** 2026-06-11  
**Repo:** `eztrac-core-services`  
**Previous Node:** 18.x (CI default `18.15.0`; `.nvmrc` was stale at `v16.9.1`)  
**Target Node:** `22.22.3` (LTS *Jod*, aligned with `eztrac-core-ui`)

## Recommendation

**Proceed with the upgrade.** Node runs the Express API in production (Fargate container) and in local dev/CI. Build, lint, and the full Mocha unit suite were verified on Node `22.22.3` with no Node-related failures.

Unlike `eztrac-core-ui`, this service **does** use Node at runtime in production. Node 22 is the current LTS line; Express 4.22.x, TypeScript 4.8, `pg-promise`, and `ts-node-dev` all work on Node 22 in this repo.

---

## What changed in the repo

| File | Change |
|---|---|
| `package.json` | `engines.node` → `22.22.3`; audit scripts added |
| `.nvmrc` | `v16.9.1` → `22.22.3` |
| `.github/workflows/*.yml` | CI / fg-deploy `node_version` default → `22.22.3` |
| `.codebuild/integration-tests.yaml` | CodeBuild runtime `nodejs` → `22` |
| `README.md` | Prerequisites and doc links updated |
| `eztrac-local-setup` | `core-api` uses Node `22.22.3` (see local-setup changes below) |

---

## Validation on Node 22.22.3

| Check | Result | Notes |
|---|---|---|
| `npm run build` | Pass | `tsc` + GTS lint (32 warnings, 0 errors — pre-existing) |
| `npm test` | Pass | 196 tests passed |
| `npm run lint` | Pass | Same 32 warnings as build |
| Production runtime | Expected OK | `node ./dist/src/bin/www.js`; Dockerfile uses `NODE_VERSION` build arg |

---

## Node 18 → 22 breaking changes — impact on this repo

This project is a **TypeScript/Express API** that runs on Node in Fargate and locally.

### Low / no impact

| Change | Why it does not block us |
|---|---|
| **OpenSSL 3** | Already required from Node 17+; RDS TLS via `@monsantoit/fetch-rds-ca` unchanged |
| **Global `fetch` / Web Crypto** | Stable since Node 18; `undici` also used directly for outbound HTTP |
| **npm 10** (bundled with Node 22) | Compatible with existing `package-lock.json` v3 |
| **TypeScript 4.8 + ts-node 10** | Compile and test runner work on Node 22 |

### Worth knowing (not blockers)

| Change | Relevance |
|---|---|
| **`import assert` removed** | No import assertions in app source |
| **Legacy `url.parse()` discouraged** | Existing deps may use legacy APIs internally; no failure observed |
| **`@monsantoit/eslint-config-velocity@8.3.2`** | Declares `node: >14 <17` (engine warning only; lint/build pass) |
| **`@monsantoit/config@3.1.6`** | Upgraded; drops `aws-sdk` v2 — see [PACKAGE-AUDIT-UPGRADE.md](./PACKAGE-AUDIT-UPGRADE.md) |
| **Phoenix `fg-deploy` shared CI workflow** | Accepts `node_version` input; defaults updated to `22.22.3`. Confirm Phoenix runners provide Node 22 if CI fails |
| **Docker base image** | `Dockerfile` uses `NODE_VERSION` build arg from fg-deploy — must match `22.22.3` in CI |

### Not applicable

- Native addons / `node-gyp` — none in direct dependencies
- ESM-only entry — app compiles to CommonJS (`tsc`)

---

## npm audit report (before remediation)

**Command:** `npm audit` (Node 18.20.8, npm 10.8.2)  
**Date:** 2026-06-11 (pre-upgrade baseline)

### Summary

| Severity | Count |
|---|---|
| Critical | 4 |
| High | 34 |
| Moderate | 30 |
| Low | 11 |
| **Total** | **79** |

**After remediation (2026-06-12):** `npm audit` → **0 vulnerabilities**. See [PACKAGE-AUDIT-UPGRADE.md](./PACKAGE-AUDIT-UPGRADE.md).

---

## Rollout checklist

1. Install Node `22.22.3` locally: `nvm install 22.22.3 && nvm use`
2. Run `npm ci && npm run build && npm test`
3. Merge Node version changes; confirm **PR / np-deploy / fg-deploy** CI passes on Node 22
4. Reinstall local deps if upgrading from Node 18: `FORCE=1 bash scripts/install.sh` in `eztrac-local-setup`
5. Long-term: evaluate replacing `swagger-tools` with maintained OpenAPI 3 middleware

---

## References

- [Node.js 22 release notes](https://nodejs.org/en/blog/release/v22.0.0)
- [Node.js 22 LTS (*Jod*)](https://nodejs.org/en/about/previous-releases)
- [eztrac-core-ui NODE-22-UPGRADE.md](https://github.com/bayer-int/eztrac-core-ui/blob/main/docs/NODE-22-UPGRADE.md)
