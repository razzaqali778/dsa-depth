# Package audit and upgrade (Node 22.22.3)

**Date:** 2026-06-12  
**Result:** `npm audit` → **0 vulnerabilities** (down from 57)  
**Validation:** lint, build, 196 unit tests — all pass on Node `22.22.3`

Pattern aligned with [`eztrac-core-ui`](../eztrac-core-ui/docs/PACKAGE-AUDIT-UPGRADE.md): safe `npm audit fix`, direct dependency bumps within compatible semver, and `package.json` `overrides` for transitive chains — **without** `npm audit fix --force` breaking upgrades (`swagger-tools@0.10.4`, `@monsantoit/config-velocity-store@2.0.1` as a blind force target, `mocha@8.1.3` downgrade, etc.).

---

## Summary

| Before | After |
|---|---|
| **57 vulnerabilities** (4 critical, 20 high, 29 moderate, 4 low) | **0 vulnerabilities** |
| `@monsantoit/config` 3.0.0 | `@monsantoit/config` **3.1.6** |
| `@monsantoit/config-velocity-store` ~1.0.0 | `@monsantoit/config-velocity-store` **~2.0.1** |
| `joi` ~17.7.1 | `joi` **~18.2.1** |
| `undici` ~5.29.0 | `undici` **~6.26.0** |
| `swagger-tools` ~0.9.8 (unchanged) | `swagger-tools` **~0.9.8** (transitives overridden) |
| `overrides`: `lodash` only | `overrides`: 25+ transitive patches (see below) |

---

## Strategy

| Approach | Used for | Rationale |
|---|---|---|
| **`npm audit fix`** (safe) | Initial lockfile refresh | Applied once; removed some low-risk patches but did not reach 0 alone |
| **Direct dependency bumps** | `@monsantoit/config`, `config-velocity-store`, `joi`, `undici` | Patched upstream packages without changing app source |
| **`overrides`** | `swagger-tools`, `pg-mem`/`@mikro-orm`, `gts`/`tmp`, AWS Smithy chain, shared transitives | Forces patched versions without major bumps on direct deps |
| **Scoped overrides** | `mime` under `swagger-tools` only | Global `mime@3` broke Express (`mime.lookup` removed); scoped `mime@1.6` fixes audit without runtime break |
| **Package alias** | `string` → `noop2` under `swagger-tools` | `string@*` has no patched release; only used by swagger-tools CLI bin, not runtime middleware |
| **Avoided** | `npm audit fix --force` | Would install breaking majors (swagger-tools 0.10.x, mocha 8.x downgrade, undici 8.x) |

---

## Direct dependency changes

| Package | Old → New | Change type | Breaking risk | Import / API impact |
|---|---|---|---|---|
| `@monsantoit/config` | 3.0.0 → **3.1.6** | Minor bump (same major) | Low | **No code changes.** Drops `aws-sdk` v2 and `request`; uses `@aws-sdk/*` v3, `node-vault@0.10` (`postman-request`), `superagent@9`. Config API (`Config`, `source`, `processor`, `env`) unchanged |
| `@monsantoit/config-velocity-store` | ~1.0.0 → **~2.0.1** | Major (package semver) | Low | **No code changes.** `determineEnvironmentFileName` and `isFargate` exports unchanged; removes nested `@monsantoit/config@1.2.2` (aws-sdk/request chain) |
| `joi` | ~17.7.1 → **~18.2.1** | Major | Low–medium | **No code changes.** `import Joi from 'joi'` and `Joi.object()` schemas work; `express-joi-validation@5` peer says joi 17 but runs on 18 in tests. No `Joi.link()` usage in this repo |
| `undici` | ~5.29.0 → **~6.26.0** | Major | Low | **Not imported in app source** (listed dependency; Node 22 has native `fetch`). Bump clears undici CVEs if used transitively or in future |
| `lodash` | ~4.18.1 | Unchanged | — | Override `"lodash": "$lodash"` still forces patched lodash for all transitives |
| `swagger-tools` | ~0.9.8 | Unchanged | — | Middleware at `/v1/docs` unchanged; transitive deps overridden (see below) |
| `express`, `superagent`, `mocha`, `pg-mem`, etc. | Prior audit pass | Unchanged | — | Retained from earlier Node 22 remediation |

---

## Transitive dependency patches (`overrides`)

### Global overrides (entire tree)

| Package | Override version | Fixes | Runtime exposure |
|---|---|---|---|
| `lodash` | `$lodash` (4.18.1) | Prototype pollution | Production — forced everywhere |
| `joi` | `$joi` (18.2.1) | RangeError / nested `link()` | Production — validation middleware |
| `uuid` | ^11.1.1 | Buffer bounds (v3/v5/v6) | Config / AWS SDK transitives |
| `serialize-javascript` | ^7.0.5 | RCE / DoS | Dev only — mocha |
| `tmp` | ^0.2.7 | Symlink / path traversal | Dev only — gts → inquirer |
| `fast-xml-parser` | ^5.8.0 | XML entity / injection CVEs | Config AWS SDK transitives |
| `js-yaml` | ^4.1.0 | Prototype pollution (`<<`) | Config / YAML loaders |
| `validator` | ^13.15.35 | ReDoS / URL bypass | swagger-tools → z-schema |
| `qs` | ^6.14.1 | Prototype pollution / DoS | HTTP parsers (scoped paths) |
| `form-data` | ^4.0.4 | Unsafe boundary random | superagent / legacy request chains |
| `tough-cookie` | ^4.1.3 | Prototype pollution | Legacy request (removed from main config tree) |
| `cookiejar` | ^2.1.4 | ReDoS | swagger-tools superagent |
| `extend` | ^3.0.2 | Prototype pollution | swagger-tools superagent |
| `debug` | ^4.3.4 | ReDoS | Various |
| `ms` | ^2.1.3 | ReDoS | debug transitive |
| `braces` | ^3.0.3 | Resource consumption | pg-mem → knex → liftoff |
| `micromatch` | ^4.0.8 | braces chain | pg-mem → knex |
| `multer` | ^2.1.1 | dicer / busboy / qs (swagger) | Swagger UI upload middleware |
| `@smithy/config-resolver` | ^4.4.0 | AWS region validation | Config startup (SSM/Secrets) |
| `@smithy/util-defaults-mode-node` | ^3.0.35 | Smithy chain | Config AWS SDK |
| `@aws-sdk/client-secrets-manager` | ^3.722.0 | Smithy / XML / uuid chain | Config startup |
| `@aws-sdk/client-ssm` | ^3.722.0 | Smithy / XML / uuid chain | Config startup |
| `@mikro-orm/core` | ^7.1.4 | Prototype pollution / SQL injection | **Test only** — pg-mem |
| `@mikro-orm/knex` | ^7.1.4 | mikro-orm chain | Test only |
| `@mikro-orm/postgresql` | ^7.1.4 | mikro-orm chain | Test only |
| `knex` | ^3.1.0 | liftoff / braces chain | Test only — pg-mem |

### Scoped overrides (`swagger-tools` subtree)

| Package | Override | Notes |
|---|---|---|
| `superagent` | ^3.8.3 | Patched 3.x (not app’s direct superagent@7) |
| `qs` | ^6.15.2 | Replaces swagger-tools’ pinned qs@4 |
| `form-data` | ^4.0.4 | Patched boundary generation |
| `body-parser` | ^1.20.3 | DoS / qs chain |
| `debug` | ^4.3.4 | ReDoS |
| `mime` | **^1.6.0** | **Must stay 1.x** — Express `res.json()` uses `mime.lookup`; global `mime@3` caused 72 test failures |
| `multer` | ^2.1.1 | Removes vulnerable dicer/busboy@0.3 |
| `string` | `npm:noop2@1.0.0` | CLI-only dep; middleware path does not use `string` |
| `z-schema` | ^5.0.5 | Pulls patched validator |

### `z-schema` nested override

```json
"z-schema": { "validator": "^13.15.35" }
```

---

## Import and runtime impact by upgraded package

| Package | Imported in app? | Risk if API changed |
|---|---|---|
| `@monsantoit/config` | Yes — `src/config/index.ts`, `logger.js` | Startup config / Vault; verified by full test suite |
| `@monsantoit/config-velocity-store` | Yes — `src/config/index.ts` | `determineEnvironmentFileName`, `isFargate` only |
| `joi` | Yes — all `validationSchema.ts` files | Request validation; 196 tests cover schemas |
| `swagger-tools` | Yes — `src/middleware/swagger.js`, type import in `swaggerTypes.ts` | OpenAPI 2 middleware + Swagger UI |
| `superagent` | Yes — `superagentWrapper.ts`, `papiClient.ts` | Outbound HTTP; direct dep still 7.x (unchanged) |
| `lodash` | Yes — config files, services | Standard helpers only |
| `undici` | **No** direct imports | Safe major bump for audit clearance |
| `pg-mem` / `@mikro-orm/*` | Test harness only | Overrides to mikro-orm 7.x; tests pass |
| `gts` / `tmp` | Dev lint only | tmp 0.2.7 via override |
| AWS SDK / Smithy | Transitive via config | Startup only; not user-input paths |

---

## Packages that could NOT be fixed without avoided changes

All 57 original findings are resolved. The following **would have** been breaking or unreliable via `npm audit fix --force` and were **not** used:

| Avoided change | Why skipped | How we fixed instead |
|---|---|---|
| `swagger-tools@0.10.4` | Major middleware upgrade; prior repo downgrade to 0.9.8 | Kept 0.9.8 + scoped overrides + `string` alias |
| `@monsantoit/config-velocity-store@2.0.1` via `--force` | Blind force alongside other breaks | **Intentional** direct bump to ~2.0.1 after API check (`determineEnvironmentFileName`, `isFargate` unchanged) |
| `mocha@8.1.3` | Downgrade from 10.x | `serialize-javascript@^7.0.5` override |
| `undici@8.4.1` | Major 8.x | Direct bump to `~6.26.0` |
| `joi@18` via `--force` with other breaks | Would have been bundled with bad force graph | Controlled direct bump to `~18.2.1` + tests |
| Global `mime@3` | Breaks Express `mime.lookup` | Scoped `mime@^1.6.0` under `swagger-tools` only |

---

## Pitfall: global `mime` override

During remediation, a global `"mime": "^3.0.0"` override cleared audit entries but broke Express responses:

```
TypeError: Cannot read properties of undefined (reading 'lookup')
  at ServerResponse.json (express/lib/response.js)
```

**Fix:** Remove global `mime` override; set `"swagger-tools": { "mime": "^1.6.0" }` only. Express keeps its own `mime@1.x`; swagger-tools superagent gets a patched 1.x.

---

## Engine warnings (non-blocking)

| Package | Declared engines | Observed on Node 22 |
|---|---|---|
| `@monsantoit/config@3.1.6` | `^20` | Works; engine warning only |
| `@monsantoit/eslint-config-velocity@8.3.2` | `>14 <17` | Works; engine warning only |

---

## Verification checklist (Node 22.22.3)

```bash
nvm use 22.22.3
npm ci
npm run audit          # expect: found 0 vulnerabilities
npm run lint           # pass (32 pre-existing warnings)
npm run build          # pass
npm test               # 196 passing
npm run dev            # http://127.0.0.1:3560/v1/docs
```

**Via Ocelot + local-setup:** http://localhost/ez-trac-core/teams (core-ui) + http://127.0.0.1:3560/v1/docs (core-api)

---

## Runtime: `/v2/*` returns 500/503 (local dev)

**Symptom:** `GET /v2/timeframes`, `/v2/teams`, `/v2/communities`, `/v2/platforms`, `/v2/orgs` all fail after the audit upgrade; unit tests still pass.

**Root cause (not joi/mime):** These routes query PostgreSQL via the SSH tunnel on **`localhost:5435`**. When the tunnel is down or drops, `pg-promise` throws `AggregateError: ECONNREFUSED` or `Connection terminated unexpectedly`. The generic Express error handler returned **500** with an empty body — easy to misread as a dependency regression.

**Evidence in `core-api.log`:**

```
AggregateError: connect ECONNREFUSED 127.0.0.1:5435
error: Connection terminated unexpectedly
```

When the tunnel is healthy, the same log shows successful `SELECT` queries for timeframe/team/community with no `TypeError` / `mime.lookup` stack traces.

**Fix (operational — no application code changes):**

Bring the DB tunnel up and ensure core-api starts (or restarts) while the tunnel is healthy. Temporary diagnostic edits to `server.ts`, `src/bin/www.ts`, `src/config/files/development.ts`, and `src/db/dbManager.ts` were reverted; they are not part of the audit remediation.

**What to do locally:**

1. VPN on · `vault login` · `aws sso login --profile eztrac-np`
2. `make up` from `eztrac-local-setup` (starts tunnel + core-api)
3. Confirm tunnel: `nc -z localhost 5435`
4. Restart core-api if the tunnel was restarted after the API started

Audit-related packages (`joi@18`, `@monsantoit/config@3.1.6`, scoped `mime@1.6`) were ruled out: route tests pass; Express still uses `send.mime@1.6.0`.

---

## Guidance for future upgrades

1. **Run `npm audit` first**, then `npm audit fix` (without `--force`). Re-audit and count remaining chains.
2. **Prefer direct bumps** on `@monsantoit/*` packages when a newer minor/patch drops vulnerable transitives (`@monsantoit/config` 3.0.0 → 3.1.6 removed aws-sdk v2 entirely).
3. **Use `overrides`** for unmaintained direct deps (`swagger-tools`) — scope overrides to the subtree (`swagger-tools.mime`) to avoid breaking Express.
4. **Never apply global overrides** for packages Express or other frameworks rely on (`mime`, `qs`, `body-parser`) without running the full Mocha suite.
5. **Avoid `npm audit fix --force`** — inspect each suggested major; replicate fixes via controlled overrides or direct bumps.
6. **Test after `joi` major bumps** — `express-joi-validation` peer may lag; run all route tests.
7. **Long-term:** replace `swagger-tools` with maintained OpenAPI 3 middleware (`@apidevtools/swagger-express-middleware` or similar) to eliminate legacy superagent 3.x / z-schema chains.
8. **Monitor `pg-mem`** — mikro-orm 7.x is forced via override; confirm compatibility when upgrading `pg-mem`.

---

## Files changed

| File | Change |
|---|---|
| `package.json` | Direct dep bumps; expanded `overrides` block |
| `package-lock.json` | Regenerated via `npm install` |
| `docs/PACKAGE-AUDIT-UPGRADE.md` | This document |
