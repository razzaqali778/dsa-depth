import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {databaseCleaner} from '../../db/cleanupDatabase';
import {adminUserHeader, unauthorizedUserHeader, writeUserHeader} from '../../utils';
import {EffortAllocationsPaths} from '../../constants';
import {getFullEffortEntityByTeamAndTimeFrame} from '../../../src/api/effort/effortService';
import {Express} from 'express';

describe('Effort Allocation (PATCH) ', () => {
  let app: Express;

  before(async () => {
    app = require('../../../server').app;
  });

  after(async () => {
    await databaseCleaner.cleanupEfforts();
  });

  it('updates allocations for a team and a not locked timeframe', async () => {
    // Arrange
    const teamId = 'TEST-TEAM123';
    const timeFrameId = '42412';
    const existingAllocation1 = {
      initiativeId: '20c07920-050d-11ea-9bb5-c5657d877734',
      percentageOfTeamCost: 10n,
    };
    const existingAllocation2 = {
      initiativeId: 'c5fa02f0-07db-11ea-9bb5-c5657d877734',
      percentageOfTeamCost: 20n,
    };
    const newAllocation = {
      initiativeId: 'new-test-initiative',
      percentageOfTeamCost: 30n,
    };

    const reqBody = [
      {
        timeFrameId: timeFrameId,
        allocations: [existingAllocation1, existingAllocation2, newAllocation],
      },
    ];

    // Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .send(reqBody)
      .set(writeUserHeader);

    const updatedEffort = await getFullEffortEntityByTeamAndTimeFrame(teamId, BigInt(timeFrameId));

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(updatedEffort?.allocations).to.have.length(3);
    expect(updatedEffort?.allocations?.[0]?.initiativeId).to.equal(
      existingAllocation1.initiativeId
    );
    expect(updatedEffort?.allocations?.[0]?.percentageOfTeamCost).to.equal(
      existingAllocation1.percentageOfTeamCost
    );
    expect(updatedEffort?.allocations?.[1]?.initiativeId).to.equal(
      existingAllocation2.initiativeId
    );
    expect(updatedEffort?.allocations?.[1]?.percentageOfTeamCost).to.equal(
      existingAllocation2.percentageOfTeamCost
    );
    expect(updatedEffort?.allocations?.[2]?.initiativeId).to.equal(newAllocation.initiativeId);
    expect(updatedEffort?.allocations?.[2]?.percentageOfTeamCost).to.equal(
      newAllocation.percentageOfTeamCost
    );
  });

  it('updates allocations for a team and a locked timeframe', async () => {
    // Arrange
    const teamId = 'TEST-TEAM123';
    const lockedTimeFrameId = '42302';
    const existingAllocation1 = {
      initiativeId: '20c07920-050d-11ea-9bb5-c5657d877734',
      percentageOfTeamCost: 10n,
    };
    const existingAllocation2 = {
      initiativeId: 'c5fa02f0-07db-11ea-9bb5-c5657d877734',
      percentageOfTeamCost: 20n,
    };
    const newAllocation = {
      initiativeId: 'new-test-initiative',
      percentageOfTeamCost: 30n,
    };

    const reqBody = [
      {
        timeFrameId: lockedTimeFrameId,
        allocations: [existingAllocation1, existingAllocation2, newAllocation],
      },
    ];

    // Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .send(reqBody)
      .set(adminUserHeader);

    const updatedEffort = await getFullEffortEntityByTeamAndTimeFrame(
      teamId,
      BigInt(lockedTimeFrameId)
    );

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(updatedEffort?.allocations).to.have.length(3);
    expect(updatedEffort?.allocations?.[0]?.initiativeId).to.equal(
      existingAllocation1.initiativeId
    );
    expect(updatedEffort?.allocations?.[0]?.percentageOfTeamCost).to.equal(
      existingAllocation1.percentageOfTeamCost
    );
    expect(updatedEffort?.allocations?.[1]?.initiativeId).to.equal(
      existingAllocation2.initiativeId
    );
    expect(updatedEffort?.allocations?.[1]?.percentageOfTeamCost).to.equal(
      existingAllocation2.percentageOfTeamCost
    );
    expect(updatedEffort?.allocations?.[2]?.initiativeId).to.equal(newAllocation.initiativeId);
    expect(updatedEffort?.allocations?.[2]?.percentageOfTeamCost).to.equal(
      newAllocation.percentageOfTeamCost
    );
  });

  it('updates allocations for a team and multiple timeframes', async () => {
    // Arrange
    const teamId = 'TEST-TEAM123';
    const timeFrameId1 = '42411';
    const timeFrameId2 = '42412';
    const initiativeId1 = '20c07920-050d-11ea-9bb5-c5657d877734';

    const updatedAllocation1 = {
      initiativeId: initiativeId1,
      percentageOfTeamCost: 30n,
    };

    const updatedAllocation2 = {
      initiativeId: initiativeId1,
      percentageOfTeamCost: 50n,
    };

    const reqBody = [
      {
        timeFrameId: timeFrameId1,
        allocations: [updatedAllocation1],
      },
      {
        timeFrameId: timeFrameId2,
        allocations: [updatedAllocation2],
      },
    ];
    // Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .send(reqBody)
      .set(writeUserHeader);

    const updatedEffort1 = await getFullEffortEntityByTeamAndTimeFrame(
      teamId,
      BigInt(timeFrameId1)
    );

    const updatedEffort2 = await getFullEffortEntityByTeamAndTimeFrame(
      teamId,
      BigInt(timeFrameId2)
    );

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(updatedEffort1?.allocations).to.have.length(1);
    expect(updatedEffort1?.allocations?.[0]?.initiativeId).to.equal(
      updatedAllocation1.initiativeId
    );
    expect(updatedEffort1?.allocations?.[0]?.percentageOfTeamCost).to.equal(
      updatedAllocation1.percentageOfTeamCost
    );
    expect(updatedEffort2?.allocations).to.have.length(1);
    expect(updatedEffort2?.allocations?.[0]?.initiativeId).to.equal(
      updatedAllocation2.initiativeId
    );
    expect(updatedEffort2?.allocations?.[0]?.percentageOfTeamCost).to.equal(
      updatedAllocation2.percentageOfTeamCost
    );
  });

  it('throws Not authorized when user does not have the permission to edit a not locked timeframe', async () => {
    //Arrange
    const teamId = 'TEST-TEAM123';
    const timeFrameId = '42412';
    const reqBody = [
      {
        timeFrameId: timeFrameId,
        allocations: [
          {
            initiativeId: '20c07920-050d-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 10n,
          },
          {
            initiativeId: 'c5fa02f0-07db-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 20n,
          },
          {
            initiativeId: 'new-test-initiative',
            percentageOfTeamCost: 30n,
          },
        ],
      },
    ];

    //Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .send(reqBody)
      .set(unauthorizedUserHeader);

    //Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('throws Not authorized when user does not have the permission to edit a locked timeframe', async () => {
    //Arrange
    const teamId = 'TEST-TEAM123';
    const lockedTimeFrameId = '42302';
    const reqBody = [
      {
        timeFrameId: lockedTimeFrameId,
        allocations: [
          {
            initiativeId: '20c07920-050d-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 10n,
          },
          {
            initiativeId: 'c5fa02f0-07db-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 20n,
          },
          {
            initiativeId: 'new-test-initiative',
            percentageOfTeamCost: 30n,
          },
        ],
      },
    ];

    //Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .send(reqBody)
      .set(writeUserHeader);

    //Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('throws Not authorized when user header is not being passed', async () => {
    //Arrange
    const teamId = 'TEST-TEAM123';
    const timeFrameId = '42412';
    const reqBody = [
      {
        timeFrameId: timeFrameId,
        allocations: [
          {
            initiativeId: '20c07920-050d-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 10n,
          },
          {
            initiativeId: 'c5fa02f0-07db-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 20n,
          },
          {
            initiativeId: 'new-test-initiative',
            percentageOfTeamCost: 30n,
          },
        ],
      },
    ];

    //Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .set(unauthorizedUserHeader)
      .send(reqBody);

    //Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('throws Bad Request error when request body is malformed', async () => {
    // Arrange
    const teamId = 'TEST-TEAM123';

    // Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .send({})
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });

  it('throws Bad Request when trying to assign more than 100% to percentage of effort allocations', async () => {
    //Arrange
    const teamId = 'TEST-TEAM123';
    const timeFrameId = '42412';
    const reqBody = [
      {
        timeFrameId: timeFrameId,
        allocations: [
          {
            initiativeId: '20c07920-050d-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 50n,
          },
          {
            initiativeId: 'c5fa02f0-07db-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 50n,
          },
          {
            initiativeId: 'new-test-initiative',
            percentageOfTeamCost: 30n,
          },
        ],
      },
    ];

    //Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .send(reqBody)
      .set(writeUserHeader);

    //Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });

  it('throws Bad Request when trying to assign a negative number to percentage of effort allocations', async () => {
    //Arrange
    const teamId = 'TEST-TEAM123';
    const timeFrameId = '42412';
    const reqBody = [
      {
        timeFrameId: timeFrameId,
        allocations: [
          {
            initiativeId: '20c07920-050d-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: -50n,
          },
        ],
      },
    ];

    //Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .send(reqBody)
      .set(writeUserHeader);

    //Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });

  it('throws Not Found error when the provided team does not exist', async () => {
    // Arrange
    const teamId = '123';
    const timeFrameId = '42412';
    const reqBody = [
      {
        timeFrameId: timeFrameId,
        allocations: [
          {
            initiativeId: '20c07920-050d-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 10n,
          },
          {
            initiativeId: 'c5fa02f0-07db-11ea-9bb5-c5657d877734',
            percentageOfTeamCost: 20n,
          },
          {
            initiativeId: 'new-test-initiative',
            percentageOfTeamCost: 30n,
          },
        ],
      },
    ];

    // Act
    const response = await supertest(app)
      .patch(`${EffortAllocationsPaths.Team}/${teamId}`)
      .send(reqBody)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.NOT_FOUND);
  });
});
