import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {effortAllocationsRepository} from '../../../src/api/effort/allocation/effortAllocationsRepository';
import {databaseCleaner} from '../../db/cleanupDatabase';
import {seedEffortAllocationData} from '../../db/dataSeed';
import {EffortAllocationsPaths} from '../../constants';
import {Express} from 'express';

describe('Effort Allocation (GET) ', () => {
  let app: Express;

  before(async () => {
    app = require('../../../server').app;
    await seedEffortAllocationData();
  });

  after(async () => {
    await databaseCleaner.cleanupEfforts();
  });

  it('returns effort allocations for the provided time frame id', async () => {
    // Arrange
    const timeFrameId = '42302';

    // Act
    const response = await supertest(app).get(
      `${EffortAllocationsPaths.GetByTimeFrame}/${timeFrameId}`
    );
    const expected = await effortAllocationsRepository.getEffortAllocationsByTimeFrame(
      BigInt(timeFrameId)
    );

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.have.length(2);
    for (const key in expected) {
      expect(BigInt(response.body[key].effortId)).to.equal(expected[key].effortId);
      expect(BigInt(response.body[key].timeFrameId)).to.equal(expected[key].timeFrameId);
      expect(response.body[key].teamId).to.equal(expected[key].teamId);
      expect(BigInt(response.body[key].percentageOfTeamCost)).to.equal(
        expected[key].percentageOfTeamCost
      );
      expect(response.body[key].initiativeId).to.eq(expected[key].initiativeId);
    }
  });

  it('throws Not Found error when provided time frame id does not exist', async () => {
    // Arrange
    const timeFrameId = '123';

    // Act
    const response = await supertest(app).get(
      `${EffortAllocationsPaths.GetByTimeFrame}/${timeFrameId}`
    );

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.NOT_FOUND);
  });

  it('throws Bad Request error when provided time frame id is malformed', async () => {
    // Arrange
    const timeFrameId = 'bad';

    // Act
    const response = await supertest(app).get(
      `${EffortAllocationsPaths.GetByTimeFrame}/${timeFrameId}`
    );

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });
});
