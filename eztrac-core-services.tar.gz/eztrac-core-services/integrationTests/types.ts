export enum RequestTypes {
  get = 'GET',
  put = 'PUT',
  post = 'POST',
  patch = 'PATCH',
  delete = 'DELETE',
}
export interface RequestType {
  url: string;
  method: RequestTypes;
  body?: unknown;
  headers?: {[key: string]: string};
}
