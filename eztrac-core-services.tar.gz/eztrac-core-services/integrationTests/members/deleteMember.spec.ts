import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import sinon from 'sinon';
import {eztracCostingClient} from '../../src/util/client/eztracCostingClient';
import {createTeam, unauthorizedUserHeader, writeUserHeader} from '../utils';
import {databaseCleaner} from '../db/cleanupDatabase';
import {updateTeamMembers} from '../../src/api/effort/members/effortMemberService';
import {getFullEffortEntityByTeamAndTimeFrame} from '../../src/api/effort/effortService';
import {Express} from 'express';

describe('Member (DELETE) ', () => {
  let app: Express;
  const sandbox = sinon.createSandbox();

  before(() => (app = require('../../server').app));

  afterEach(() => sandbox.restore());

  after(async () => await databaseCleaner.cleanupEfforts());

  it('throws Forbidden error when effortWrite entitlement id not present in request headers', async () => {
    // Act
    const response = await supertest(app)
      .delete('/efforts/timeframes/timeFrameId/team/teamId/user/personId')
      .set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('throws Not Found error when team does not exist', async () => {
    // Act
    const response = await supertest(app)
      .delete('/efforts/timeframes/12345/team/teamId/user/personId')
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.NOT_FOUND);
  });

  it('deletes member', async () => {
    // Arrange
    const teamId = await createTeam('delete member test team');
    const timeFrameId = 42401;
    const personId = 'abcd';
    const participants = [
      {
        userId: personId,
        percent: 80,
      },
      {
        userId: 'someOtherPerson',
        percent: 100,
      },
    ];

    const teamMemberCosts1 = [
      {
        costGroupId: 'theSameCostGroupForEveryMember',
        cost: BigInt(200),
      },
    ];
    const costingResponse1 = [
      {
        teamId: teamId,
        timeFrameId: BigInt(timeFrameId),
        teamMemberCosts: teamMemberCosts1,
      },
    ];

    const teamMemberCosts2 = [
      {
        costGroupId: 'theSameCostGroupForEveryMember',
        cost: BigInt(100),
      },
    ];
    const costingResponse2 = [
      {
        teamId: teamId,
        timeFrameId: BigInt(timeFrameId),
        teamMemberCosts: teamMemberCosts2,
      },
    ];

    const costingClientStub = sandbox.stub(eztracCostingClient, 'getEffortCostCalculation');
    costingClientStub.onFirstCall().resolves(costingResponse1);
    costingClientStub.onSecondCall().resolves(costingResponse2);

    await updateTeamMembers([BigInt(timeFrameId)], teamId, participants, [], true);

    // Act
    const response = await supertest(app)
      .delete(`/efforts/timeframes/${timeFrameId}/team/${teamId}/user/${personId}`)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);

    const effort = await getFullEffortEntityByTeamAndTimeFrame(teamId, BigInt(timeFrameId));
    expect(effort.members).to.have.length(1);
    expect(effort.members?.at(0)).to.deep.equal(participants[1]);
  });
});
