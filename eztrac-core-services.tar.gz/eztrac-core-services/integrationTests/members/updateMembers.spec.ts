import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import sinon from 'sinon';
import {eztracCostingClient} from '../../src/util/client/eztracCostingClient';
import {adminUserHeader, createTeam, unauthorizedUserHeader, writeUserHeader} from '../utils';
import {databaseCleaner} from '../db/cleanupDatabase';
import {EffortEntity} from '../../src/api/effort/models';
import {UpdateMembersMultiple} from '../../src/api/effort/members/validationSchema';
import {effortRepository} from '../../src/api/effort/effortRepository';
import {getFullEffortEntityByTeamAndTimeFrame} from '../../src/api/effort/effortService';
import {Express} from 'express';

describe('Member (PATCH, PUT) ', () => {
  let app: Express;
  const sandbox = sinon.createSandbox();

  const participantCost = 150;
  const genericParticipantCost = 120;

  const stubCostingClient = (request: UpdateMembersMultiple) => {
    const genericPeopleCosts = request.body.genericPeople.map(person => ({
      costGroupId: person.costGroupId,
      cost: BigInt(genericParticipantCost * person.numberOfPeople),
    }));
    const specificPeopleCosts = request.body.specificPeople.map(person => ({
      costGroupId: 'someCostGroup',
      cost: BigInt(participantCost),
      personId: person.userId,
    }));
    const teamMemberCosts = [...genericPeopleCosts, ...specificPeopleCosts];
    const response = request.body.timeFrameIds.map(timeFrameId => ({
      teamId: request.params.teamId,
      timeFrameId: BigInt(timeFrameId),
      teamMemberCosts: teamMemberCosts,
    }));

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves(response);
  };

  before(() => (app = require('../../server').app));

  afterEach(() => sandbox.restore());

  after(async () => await databaseCleaner.cleanupEfforts());

  it('throws Forbidden error when effortWrite entitlement id not present in request headers', async () => {
    // Act
    const response = await supertest(app)
      .patch('/efforts/members/team/teamId')
      .set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('throws Bad Request error when request body is malformed', async () => {
    // Arrange
    const memberEffortRequest = {
      timeFrameIds: ['bad'],
      abc: 'abc',
    };

    // Act
    const response = await supertest(app)
      .patch('/efforts/members/team/teamId')
      .send(memberEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });

  it('throws Not Found error when team does not exist', async () => {
    // Arrange
    const memberEffortRequest = {
      timeFrameIds: [123],
      specificPeople: [{userId: 'id', percent: 20}],
      genericPeople: [],
    };

    // Act
    const response = await supertest(app)
      .patch('/efforts/members/team/teamId')
      .send(memberEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.NOT_FOUND);
  });

  it('updates members', async () => {
    // Arrange
    const teamId = await createTeam('update members test team');
    const timeFrameId1 = 42401;
    const timeFrameId2 = 42402;
    const costGroup1 = 'costGroup1';

    const requestBody = {
      timeFrameIds: [timeFrameId1, timeFrameId2],
      specificPeople: [
        {
          userId: 'user1',
          percent: 20,
        },
        {
          userId: 'user2',
          percent: 100,
        },
      ],
      genericPeople: [
        {
          costGroupId: costGroup1,
          numberOfPeople: 2,
          rateId: 'rate',
        },
      ],
    };

    stubCostingClient({
      body: {
        genericPeople: requestBody.genericPeople.map(p => ({
          ...p,
          numberOfPeople: Number(p.numberOfPeople),
        })),
        specificPeople: requestBody.specificPeople,
        timeFrameIds: requestBody.timeFrameIds.map(id => BigInt(id)),
      },
      params: {teamId},
      query: {},
      headers: {},
      fields: {},
    });

    // Act
    const response = await supertest(app)
      .patch(`/efforts/members/team/${teamId}`)
      .send(requestBody)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const updatedEfforts: EffortEntity[] = response.body;
    expect(updatedEfforts).to.have.length(2);
    const updatedEffort1 = updatedEfforts.find(e => Number(e.timeFrameId) === timeFrameId1);
    const updatedEffort2 = updatedEfforts.find(e => Number(e.timeFrameId) === timeFrameId2);
    expect(updatedEffort1?.members).to.have.deep.members(requestBody.specificPeople);
    expect(updatedEffort1?.forecastPeople).to.have.deep.members(requestBody.genericPeople);
    expect(updatedEffort1?.costBreakdowns).to.have.length(3);
    expect(updatedEffort2?.members).to.have.deep.members(requestBody.specificPeople);
    expect(updatedEffort2?.forecastPeople).to.have.deep.members(requestBody.genericPeople);
    expect(updatedEffort2?.costBreakdowns).to.have.length(3);

    const efforts = await effortRepository.getEffortsByIds(updatedEfforts.map(e => e.id ?? 0n));
    expect(efforts.map(e => e.cost).every(c => c === 540n)).to.be.true;
  });

  it('does not allow to update locked months when user is not an admin', async () => {
    // Arrange
    const teamId = await createTeam('update members not an admin test team');
    const timeFrameId1 = 42201;

    const requestBody = {
      timeFrameIds: [timeFrameId1],
      specificPeople: [
        {
          userId: 'user1',
          percent: 20,
        },
      ],
      genericPeople: [
        {
          costGroupId: 'costGroup1',
          numberOfPeople: '2',
          rateId: 'rate',
        },
      ],
    };

    // Act
    const response = await supertest(app)
      .patch(`/efforts/members/team/${teamId}`)
      .send(requestBody)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('allows to update locked months when user is an admin', async () => {
    // Arrange
    const teamId = await createTeam('update members admin test team');
    const timeFrameId1 = 42201;

    const requestBody = {
      timeFrameIds: [timeFrameId1],
      specificPeople: [
        {
          userId: 'user1',
          percent: 20,
        },
      ],
      genericPeople: [
        {
          costGroupId: 'costGroup1',
          numberOfPeople: '2',
          rateId: 'rate',
        },
      ],
    };

    stubCostingClient({
      body: {
        genericPeople: requestBody.genericPeople.map(p => ({
          ...p,
          numberOfPeople: Number(p.numberOfPeople),
        })),
        specificPeople: requestBody.specificPeople,
        timeFrameIds: requestBody.timeFrameIds.map(id => BigInt(id)),
      },
      params: {teamId},
      query: {},
      headers: {},
      fields: {},
    });

    // Act
    const response = await supertest(app)
      .patch(`/efforts/members/team/${teamId}`)
      .send(requestBody)
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
  });

  it('adds one team member', async () => {
    // Arrange
    const teamId = await createTeam('add one member team test');
    const timeFrameId = 42401;
    const personId = 'abcd';
    const percent = 50;

    const requestBody = {
      percent: percent,
    };

    stubCostingClient({
      body: {
        genericPeople: [],
        specificPeople: [{userId: personId, percent: percent}],
        timeFrameIds: [BigInt(timeFrameId)],
      },
      params: {teamId},
      query: {},
      headers: {},
      fields: {},
    });

    // Act
    const response = await supertest(app)
      .put(`/efforts/timeframes/${timeFrameId}/team/${teamId}/user/${personId}`)
      .send(requestBody)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const effort = await getFullEffortEntityByTeamAndTimeFrame(teamId, BigInt(timeFrameId));
    expect(effort.members).to.have.deep.members([{userId: personId, percent: percent}]);
  });

  it('updates one team member', async () => {
    // Arrange
    const teamId = await createTeam('update one member team test');
    const timeFrameId = 42401;
    const personId = 'existingMember';
    const percent = 50;
    const existingMembers = [
      {userId: personId, percent: 100},
      {userId: 'anotherMember', percent: 80},
    ];

    await supertest(app)
      .patch(`/efforts/members/team/${teamId}`)
      .send({
        timeFrameIds: [timeFrameId],
        specificPeople: existingMembers,
        genericPeople: [],
      })
      .set(writeUserHeader);

    const requestBody = {
      percent: percent,
    };

    stubCostingClient({
      body: {
        genericPeople: [],
        specificPeople: [
          ...existingMembers.filter(m => m.userId !== personId),
          {userId: personId, percent},
        ],
        timeFrameIds: [BigInt(timeFrameId)],
      },
      params: {teamId},
      query: {},
      headers: {},
      fields: {},
    });

    // Act
    const response = await supertest(app)
      .put(`/efforts/timeframes/${timeFrameId}/team/${teamId}/user/${personId}`)
      .send(requestBody)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const effort = await getFullEffortEntityByTeamAndTimeFrame(teamId, BigInt(timeFrameId));
    expect(effort.members).to.have.deep.members([
      ...existingMembers.filter(m => m.userId !== personId),
      {userId: personId, percent: percent},
    ]);
  });
});
