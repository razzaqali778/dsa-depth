import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {createTeam} from '../utils';
import {databaseCleaner} from '../db/cleanupDatabase';
import {EffortEntity} from '../../src/api/effort/models';
import {effortRepository} from '../../src/api/effort/effortRepository';
import {Member, ForecastedTeamMember} from '../../src/api/effort/members/models';
import {personRepository} from '../../src/api/person/personRepository';
import {Express} from 'express';

describe('Member (GET) ', () => {
  let app: Express;
  let team1 = '';
  const teamName1 = 'get members team1';
  const teamName2 = 'get members team2';
  let team2 = '';
  const timeFrameId = 42310;
  const userId1 = 'userId';
  const userId2 = 'userId2';
  const costGroup1 = 'costGroup1';
  const costGroup2 = 'costGroup2';

  before(async () => {
    app = require('../../server').app;

    team1 = await createTeam(teamName1);
    team2 = await createTeam(teamName2);

    const effortsToCreate: EffortEntity[] = [
      {
        timeFrameId: BigInt(timeFrameId),
        teamId: team1,
        members: [
          {
            userId: userId1,
            percent: 50,
          },
          {
            userId: userId2,
            percent: 100,
          },
        ],
        forecastPeople: [
          {
            costGroupId: costGroup1,
            rateId: 'rate1',
            numberOfPeople: 2,
          },
        ],
        costBreakdowns: [
          {
            costGroupId: costGroup1,
            cost: 300n,
          },
        ],
      },
      {
        timeFrameId: BigInt(timeFrameId),
        teamId: team2,
        members: [
          {
            userId: userId1,
            percent: 70,
          },
        ],
        forecastPeople: [
          {
            costGroupId: costGroup2,
            rateId: 'rate2',
            numberOfPeople: 1,
          },
        ],
        costBreakdowns: [
          {
            costGroupId: costGroup2,
            cost: 200n,
          },
        ],
      },
    ];

    await Promise.all([userId1, userId2].map(id => personRepository.createPerson(id, id)));
    await Promise.all(effortsToCreate.map(effort => effortRepository.updateEffort(effort)));
  });

  after(async () => await databaseCleaner.cleanupEfforts());

  it('gets member data by timeFrame and userId', async () => {
    // Act
    const response = await supertest(app).get(`/efforts/timeframes/${timeFrameId}/user/${userId1}`);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const memberData: Member[] = response.body;
    expect(memberData).to.have.deep.members([
      {timeFrameId, teamId: team1, userId: userId1, percent: 50},
      {timeFrameId, teamId: team2, userId: userId1, percent: 70},
    ]);
  });

  it('gets member data by timeFrame', async () => {
    // Act
    const response = await supertest(app).get(`/efforts/timeframes/${timeFrameId}`);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const memberData: Member[] = response.body;
    expect(memberData).to.have.deep.members([
      {timeFrameId, teamId: team1, userId: userId1, percent: 50},
      {timeFrameId, teamId: team2, userId: userId1, percent: 70},
      {timeFrameId, teamId: team1, userId: userId2, percent: 100},
    ]);
  });

  it('gets placeholders data by timeFrame', async () => {
    // Act
    const response = await supertest(app).get(`/efforts/timeframes/${timeFrameId}/placeholders`);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const memberData: ForecastedTeamMember[] = response.body;
    expect(memberData).to.have.deep.members([
      {
        timeFrameId,
        teamName: teamName1,
        teamId: team1,
        numberOfPeople: 2,
        costGroupId: costGroup1,
        rateId: 'rate1',
      },
      {
        timeFrameId,
        teamName: teamName2,
        teamId: team2,
        numberOfPeople: 1,
        costGroupId: costGroup2,
        rateId: 'rate2',
      },
    ]);
  });
});
