import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {testPlatform} from '../db/dataSeed';
import {adminUserHeader, unauthorizedUserHeader} from '../utils';
import {Express} from 'express';

describe('Update Platform', () => {
  let app: Express;
  before(() => {
    app = require('../../server').app;
  });

  it('throws Unauthorized error when eztrac-admin entitlement id not present in request headers', async () => {
    // Act
    const response = await supertest(app)
      .put(`/platforms/${testPlatform.id}`)
      .set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('updates platform', async () => {
    // Arrange
    const platform = {
      name: 'Update test platform',
      isActive: false,
      orgId: testPlatform.orgId,
    };

    const {body: createdPlatform} = await supertest(app)
      .post('/platforms')
      .send(platform)
      .set(adminUserHeader);

    const updatedPlatform = {
      ...platform,
      name: 'Updated test platform',
    };

    // Act
    const response = await supertest(app)
      .put(`/platforms/${createdPlatform.id}`)
      .send(updatedPlatform)
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({id: createdPlatform.id, ...updatedPlatform});
  });
});
