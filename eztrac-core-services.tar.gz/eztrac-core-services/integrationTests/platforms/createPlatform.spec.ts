import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {testOrg, testPlatform} from '../db/dataSeed';
import {adminUserHeader, unauthorizedUserHeader} from '../utils';
import {Express} from 'express';

describe('Create Platform', () => {
  let app: Express;
  before(() => {
    app = require('../../server').app;
  });

  it('throws Forbidden error when eztrac-admin entitlement is not present in request headers', async () => {
    // Act
    const response = await supertest(app)
      .post('/platforms')
      .set('user-profile', JSON.stringify(unauthorizedUserHeader));

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('throws Bad Request error when request body is malformed', async () => {
    // Arrange
    const platformToCreate = {
      orgId: 'E2E-TEST-ORG',
      isActive: 'not good',
    };

    // Act
    const response = await supertest(app)
      .post('/platforms')
      .send(platformToCreate)
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });

  it('creates platform', async () => {
    // Arrange
    const platformToCreate = {
      name: 'Test platform',
      orgId: testOrg.id,
      isActive: true,
    };

    // Act
    const response = await supertest(app)
      .post('/platforms')
      .send(platformToCreate)
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({
      id: 'TEST-PLATFORM',
      ...platformToCreate,
    });
  });

  it('fails to create platform when platform with given name already exists', async () => {
    // Arrange
    const platformToCreate = {
      name: testPlatform.name,
      isActive: testPlatform.isActive,
      orgId: testPlatform.orgId,
    };
    // Act
    const response = await supertest(app)
      .post('/platforms')
      .send(platformToCreate)
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
    expect(response.body.message).to.equal('Platform with given name already exists');
  });
});
