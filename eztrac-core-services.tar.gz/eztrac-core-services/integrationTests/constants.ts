export const NodeAppUrl = 'https://ez-trac-core-services.velocity-np.ag';
export const ScalaAppUrl = 'https://ez-trac-core-services.velocity-np.ag/v2';
export const ADMIN_NP_USER_ID = '';

export enum EffortAllocationsPaths {
  GetByTimeFrame = '/efforts/allocations/timeframes',
  Team = '/efforts/allocations/team',
}

export enum EffortEngagementsPaths {
  All = '/efforts/engagements',
  GetByTeam = '/efforts/engagements/team',
}

export enum TeamsPath {
  Team = '/team',
}
