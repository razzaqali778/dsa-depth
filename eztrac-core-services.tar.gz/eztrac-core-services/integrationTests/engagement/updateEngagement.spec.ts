import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import sinon from 'sinon';
import {eztracCostingClient} from '../../src/util/client/eztracCostingClient';
import {createTeam, unauthorizedUserHeader, writeUserHeader} from '../utils';
import {databaseCleaner} from '../db/cleanupDatabase';
import {EffortEntity} from '../../src/api/effort/models';
import {effortRepository} from '../../src/api/effort/effortRepository';
import {EngagementCalcInfo} from '../../src/api/effort/engagement/models';
import {getFullEffortEntitiesByTeamStartAndEndTimeFrameId} from '../../src/api/effort/effortService';
import {Express} from 'express';

describe('Engagement (PATCH) ', () => {
  let app: Express;
  const sandbox = sinon.createSandbox();

  before(() => (app = require('../../server').app));

  afterEach(() => sandbox.restore());

  after(async () => await databaseCleaner.cleanupEfforts());

  it('throws Forbidden error when effortWrite entitlement id not present in request headers', async () => {
    // Act
    const response = await supertest(app)
      .patch('/efforts/engagements/team/teamId/timeFrame/timeFrameId/engagement/engagementId')
      .set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('throws Bad Request error when request body is malformed', async () => {
    // Arrange
    const engagementEffortRequest = {
      comment: 'bad',
    };

    // Act
    const response = await supertest(app)
      .patch('/efforts/engagements/team/teamId/timeFrame/timeFrameId/engagement/engagementId')
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });

  it('throws Not Found error when team id is invalid', async () => {
    // Arrange
    const engagementEffortRequest = {
      amount: 5,
      comment: null,
    };

    // Act
    const response = await supertest(app)
      .patch('/efforts/engagements/team/teamId/timeFrame/12345/engagement/engagementId')
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.NOT_FOUND);
  });

  it('updates engagement on one time frame', async () => {
    // Arrange
    const teamId = await createTeam('update one engagement test team');
    const timeFrameId = 42311n;
    const alreadyExistingEngagementId = 'ENGAGEMENT-UPDATE-ALREADY-EXISTING';
    const previousAmount = 60n;
    const engagement = {
      engagementId: alreadyExistingEngagementId,
      amount: 5n,
    };
    const existingEngagement = {
      amount: previousAmount,
      engagementId: alreadyExistingEngagementId,
      comment: 'xyz',
    };
    const existingBreakdown = {
      costGroupId: '3',
      engagementId: alreadyExistingEngagementId,
      cost: previousAmount,
    };

    const engagementEffortRequest = {
      amount: engagement.amount,
      comment: '',
    };

    const effort1 = {
      teamId: teamId,
      timeFrameId: timeFrameId,
      engagements: [existingEngagement],
      costBreakdowns: [existingBreakdown],
    } as EffortEntity;

    const effort2 = {
      teamId: teamId,
      timeFrameId: 42312n,
      engagements: [existingEngagement],
      costBreakdowns: [existingBreakdown],
    } as EffortEntity;

    await effortRepository.updateEffort(effort1);
    await effortRepository.updateEffort(effort2);

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves([
      {
        teamId: teamId,
        timeFrameId: timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: '3',
            cost: engagement.amount,
            engagementId: engagement.engagementId,
          },
        ],
      },
    ]);

    // Act
    const response = await supertest(app)
      .patch(
        `/efforts/engagements/team/${teamId}/timeFrame/${timeFrameId}/engagement/${engagement.engagementId}`
      )
      .query({all: false})
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({cost: 5});
    const updatedEfforts = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teamId,
      timeFrameId,
      42312n
    );
    expect(updatedEfforts).to.have.length(2);
    const updatedEffort1 = updatedEfforts.find(
      e => e.teamId === effort1.teamId && e.timeFrameId === effort1.timeFrameId
    );
    const updatedEffort2 = updatedEfforts.find(
      e => e.teamId === effort2.teamId && e.timeFrameId === effort2.timeFrameId
    );
    expect(updatedEffort1?.engagements).to.have.length(1);
    expect(updatedEffort1?.engagements?.at(0)?.amount).to.equal(Number(engagement.amount));
    expect(updatedEffort1?.costBreakdowns?.at(0)?.cost).to.equal(Number(engagement.amount));

    expect(updatedEffort2?.engagements?.at(0)?.amount).to.equal(Number(previousAmount));
    expect(updatedEffort2?.costBreakdowns?.at(0)?.cost).to.equal(Number(previousAmount));
  });

  it('updates engagement on given and all existing future time frames', async () => {
    // Arrange
    const teamId = await createTeam('update all engagements test team');
    const timeFrameId = 42401n;
    const alreadyExistingEngagementId = 'ENGAGEMENT-UPDATE-ALREADY-EXISTING';
    const previousAmount = 60n;
    const engagement = {
      engagementId: alreadyExistingEngagementId,
      amount: 5n,
      comment: 'comment123',
    };
    const existingEngagement = {
      amount: previousAmount,
      engagementId: alreadyExistingEngagementId,
      comment: 'xyz',
    };
    const existingBreakdown = {
      costGroupId: '3',
      engagementId: alreadyExistingEngagementId,
      cost: previousAmount,
    };

    const engagementEffortRequest = {
      amount: engagement.amount,
      comment: engagement.comment,
    };

    const effort1 = {
      teamId: teamId,
      timeFrameId: timeFrameId,
      engagements: [existingEngagement],
      costBreakdowns: [existingBreakdown],
    } as EffortEntity;

    const effort2 = {
      teamId: teamId,
      timeFrameId: 42402n,
      engagements: [existingEngagement],
      costBreakdowns: [existingBreakdown],
    } as EffortEntity;

    await effortRepository.updateEffort(effort1);
    await effortRepository.updateEffort(effort2);

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves([
      {
        teamId: teamId,
        timeFrameId: timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: '3',
            cost: engagement.amount,
            engagementId: engagement.engagementId,
          },
        ],
      },
      {
        teamId: teamId,
        timeFrameId: 42402n,
        teamMemberCosts: [
          {
            costGroupId: '3',
            cost: engagement.amount,
            engagementId: engagement.engagementId,
          },
        ],
      },
    ]);

    // Act
    const response = await supertest(app)
      .patch(
        `/efforts/engagements/team/${teamId}/timeFrame/${timeFrameId}/engagement/${engagement.engagementId}`
      )
      .query({all: true})
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({cost: 10});
    const updatedEfforts = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teamId,
      timeFrameId,
      42412n
    );
    expect(updatedEfforts).to.have.length(2);
    const updatedEffort1 = updatedEfforts.find(
      e => e.teamId === effort1.teamId && e.timeFrameId === effort1.timeFrameId
    );
    const updatedEffort2 = updatedEfforts.find(
      e => e.teamId === effort2.teamId && e.timeFrameId === effort2.timeFrameId
    );
    expect(updatedEffort1?.engagements).to.have.length(1);
    expect(updatedEffort1?.engagements?.at(0)?.amount).to.equal(Number(engagement.amount));
    expect(updatedEffort1?.costBreakdowns?.at(0)?.cost).to.equal(Number(engagement.amount));

    expect(updatedEffort2?.engagements).to.have.length(1);
    expect(updatedEffort2?.engagements?.at(0)?.amount).to.equal(Number(engagement.amount));
    expect(updatedEffort2?.costBreakdowns?.at(0)?.cost).to.equal(Number(engagement.amount));
  });

  it('updates calculated engagement', async () => {
    // Arrange
    const teamId = await createTeam('update one calculated engagement test team');
    const timeFrameId = 42311n;
    const alreadyExistingEngagementId = 'CALCULATED-ENGAGEMENT-UPDATE-ALREADY-EXISTING';
    const calendarId = 'US-VARIABLE';
    const calendarTimeFrameHours = 160;
    const previousAmountDetails = {
      calendarId: calendarId,
      rates: [
        {
          people: 2,
          hourlyRate: 10,
          comment: 'abc',
        },
      ],
    } as EngagementCalcInfo;
    const previousAmount = 2 * 10 * calendarTimeFrameHours;
    const updatedAmount = 1 * 5 * calendarTimeFrameHours;
    const engagement = {
      engagementId: alreadyExistingEngagementId,
      amountDetails: {
        calendarId,
        rates: [
          {
            people: 1,
            hourlyRate: 5,
          },
        ],
      },
      comment: 'comment123',
    };

    const engagementEffortRequest = {
      calcInfo: engagement.amountDetails,
      comment: engagement.comment,
    };

    const effort1 = {
      teamId: teamId,
      timeFrameId: timeFrameId,
      engagements: [
        {
          amountDetails: previousAmountDetails,
          engagementId: alreadyExistingEngagementId,
          comment: 'xyz',
          amount: BigInt(previousAmount),
        },
      ],
      costBreakdowns: [
        {
          costGroupId: '3',
          engagementId: alreadyExistingEngagementId,
          cost: BigInt(previousAmount),
        },
      ],
    } as EffortEntity;

    await effortRepository.updateEffort(effort1);

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves([
      {
        teamId: teamId,
        timeFrameId: timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: '3',
            cost: BigInt(updatedAmount),
            engagementId: engagement.engagementId,
          },
        ],
      },
    ]);

    sandbox.stub(eztracCostingClient, 'getCalendarHours').resolves([
      {
        name: 'US Calendar',
        timeFrameId: timeFrameId,
        employeeHours: 160,
        contractorHours: 160,
        calendarId: 'US-VARIABLE',
      },
    ]);

    // Act
    const response = await supertest(app)
      .patch(
        `/efforts/engagements/team/${teamId}/timeFrame/${timeFrameId}/engagement/${alreadyExistingEngagementId}/calculated`
      )
      .query({all: false})
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({cost: updatedAmount});
    const updatedEfforts = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teamId,
      timeFrameId,
      timeFrameId
    );
    expect(updatedEfforts).to.have.length(1);
    expect(updatedEfforts[0].engagements).to.have.length(1);
    expect(updatedEfforts[0].engagements?.at(0)?.amount).to.equal(updatedAmount);
    expect(updatedEfforts[0].costBreakdowns?.at(0)?.cost).to.equal(updatedAmount);
  });
});
