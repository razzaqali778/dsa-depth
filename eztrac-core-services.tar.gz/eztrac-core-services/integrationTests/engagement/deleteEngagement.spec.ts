import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import sinon from 'sinon';
import {eztracCostingClient} from '../../src/util/client/eztracCostingClient';
import {createTeam, unauthorizedUserHeader, writeUserHeader} from '../utils';
import {databaseCleaner} from '../db/cleanupDatabase';
import {EffortEntity} from '../../src/api/effort/models';
import {effortRepository} from '../../src/api/effort/effortRepository';
import {getFullEffortEntitiesByTeamStartAndEndTimeFrameId} from '../../src/api/effort/effortService';
import {Express} from 'express';

describe('Engagement (DELETE) ', () => {
  let app: Express;
  const sandbox = sinon.createSandbox();

  before(() => (app = require('../../server').app));

  afterEach(() => sandbox.restore());

  after(async () => await databaseCleaner.cleanupEfforts());

  it('throws Forbidden error when effortWrite entitlement id not present in request headers', async () => {
    // Act
    const response = await supertest(app)
      .delete('/efforts/engagements/team/TEAM-123/timeFrame/42311/engagement/42312')
      .set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('deletes effort engagement for given and future time frames when there is only one engagement', async () => {
    // Arrange
    const teamId = await createTeam('Delete engagement test team');
    const timeFrameId = 42309n;
    const engagementId = 'ENGAGEMENT-TO-BE-DELETED';
    const effort1 = {
      teamId: teamId,
      timeFrameId: 42310n,
      engagements: [
        {
          amount: 10n,
          engagementId: engagementId,
          comment: 'abc',
        },
        {
          amount: 10n,
          engagementId: 'SECOND-ENGAGEMENT-NOT-TO-BE-DELETED',
          comment: 'abc',
        },
      ],
    } as EffortEntity;
    const effort2 = {
      teamId: teamId,
      timeFrameId: 42311n,
      engagements: [
        {
          amount: 15n,
          engagementId: 'ENGAGEMENT-TO-NOT-BE-DELETED',
          comment: 'abc',
        },
      ],
    } as EffortEntity;
    const effort3 = {
      teamId: teamId,
      timeFrameId: 42309n,
      engagements: [
        {
          amount: 55n,
          engagementId: engagementId,
          comment: 'abc',
        },
      ],
    } as EffortEntity;

    await Promise.all(
      [effort1, effort2, effort3].map(effort => effortRepository.updateEffort(effort))
    );

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves([
      {
        teamId: teamId,
        timeFrameId: effort1.timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: '2',
            cost: 10n,
            engagementId: 'SECOND-ENGAGEMENT-NOT-TO-BE-DELETED',
          },
        ],
      },
      {
        teamId: teamId,
        timeFrameId: effort2.timeFrameId,
        teamMemberCosts: [
          {
            costGroupId: '2',
            cost: 15n,
            engagementId: 'ENGAGEMENT-TO-NOT-BE-DELETED',
          },
        ],
      },
    ]);

    // Act
    const response = await supertest(app)
      .delete(
        `/efforts/engagements/team/${teamId}/timeFrame/${timeFrameId}/engagement/${engagementId}`
      )
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({cost: 25});
    const updatedEfforts = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teamId,
      timeFrameId,
      42311n
    );
    expect(updatedEfforts).to.have.length(2);
    const simplifiedEfforts = updatedEfforts.map(e => ({
      engagements: e.engagements,
      costBreakdowns: e.costBreakdowns,
    }));
    expect(simplifiedEfforts).to.include.deep.members([
      {
        engagements: [
          {
            amount: 10,
            amountDetails: null,
            engagementId: 'SECOND-ENGAGEMENT-NOT-TO-BE-DELETED',
            comment: 'abc',
          },
        ],
        costBreakdowns: [
          {
            costGroupId: '2',
            cost: 10,
            engagementId: 'SECOND-ENGAGEMENT-NOT-TO-BE-DELETED',
            personId: null,
          },
        ],
      },
      {
        engagements: [
          {
            amount: 15,
            amountDetails: null,
            engagementId: 'ENGAGEMENT-TO-NOT-BE-DELETED',
            comment: 'abc',
          },
        ],
        costBreakdowns: [
          {
            costGroupId: '2',
            cost: 15,
            engagementId: 'ENGAGEMENT-TO-NOT-BE-DELETED',
            personId: null,
          },
        ],
      },
    ]);
  });
});
