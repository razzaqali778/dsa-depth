import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import sinon from 'sinon';
import {eztracCostingClient} from '../../src/util/client/eztracCostingClient';
import {createTeam, unauthorizedUserHeader, writeUserHeader} from '../utils';
import {EffortEntity} from '../../src/api/effort/models';
import {effortRepository} from '../../src/api/effort/effortRepository';
import {databaseCleaner} from '../db/cleanupDatabase';
import {getFullEffortEntitiesByTeamStartAndEndTimeFrameId} from '../../src/api/effort/effortService';
import {Express} from 'express';

describe('Engagement (POST) ', () => {
  let app: Express;
  const sandbox = sinon.createSandbox();

  before(() => (app = require('../../server').app));

  afterEach(() => sandbox.restore());

  after(async () => await databaseCleaner.cleanupEfforts());

  it('throws Forbidden error when effortWrite entitlement id not present in request headers', async () => {
    // Act
    const response = await supertest(app).post('/efforts/engagements').set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('throws Bad Request error when request body is malformed', async () => {
    // Arrange
    const engagementEffortRequest = {
      endTimeFrameId: 42312,
      amount: 'bad',
      engagementId: 12345,
    };

    // Act
    const response = await supertest(app)
      .post('/efforts/engagements')
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });

  it('throws Bad Request error when time frame range is invalid', async () => {
    // Arrange
    const engagementEffortRequest = {
      teamId: 'abc',
      startTimeFrameId: 42311,
      endTimeFrameId: 42304,
      amount: 5,
      comment: '',
      engagementId: 'aaa',
    };

    // Act
    const response = await supertest(app)
      .post('/efforts/engagements')
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });

  it('throws Not Found error when team id is invalid', async () => {
    // Arrange
    const engagementEffortRequest = {
      teamId: 'abc',
      startTimeFrameId: 42303,
      endTimeFrameId: 42304,
      amount: 5,
      comment: '',
      engagementId: 'aaa',
    };

    // Act
    const response = await supertest(app)
      .post('/efforts/engagements')
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.NOT_FOUND);
  });

  it('creates effort engagement on a team when no other efforts exist', async () => {
    // Arrange
    const teamId = await createTeam('Create engagement test team');
    const startTimeFrameId = 42311n;
    const endTimeFrameId = 42312n;
    const engagement = {
      engagementId: 'ENGAGEMENT-ID-TEST',
      amount: 5n,
      comment: 'comment123',
      amountDetails: null,
    };

    const engagementEffortRequest = {
      teamId: teamId,
      startTimeFrameId: startTimeFrameId,
      endTimeFrameId: endTimeFrameId,
      amount: engagement.amount,
      comment: engagement.comment,
      engagementId: engagement.engagementId,
    };

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves([
      {
        teamId: teamId,
        timeFrameId: startTimeFrameId,
        teamMemberCosts: [
          {
            costGroupId: '2',
            cost: engagement.amount,
            engagementId: engagement.engagementId,
          },
        ],
      },
      {
        teamId: teamId,
        timeFrameId: endTimeFrameId,
        teamMemberCosts: [
          {
            costGroupId: '2',
            cost: engagement.amount,
            engagementId: engagement.engagementId,
          },
        ],
      },
    ]);

    // Act
    const response = await supertest(app)
      .post('/efforts/engagements')
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({cost: 10});
    const updatedEfforts = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teamId,
      startTimeFrameId,
      endTimeFrameId
    );
    expect(updatedEfforts).to.have.length(2);
    expect(updatedEfforts).to.have.deep.members([
      {
        ...updatedEfforts[0],
        teamId,
        engagements: [
          {
            ...engagement,
            amount: Number(engagement.amount),
          },
        ],
        costBreakdowns: [
          {
            costGroupId: '2',
            cost: Number(engagement.amount),
            engagementId: engagement.engagementId,
            personId: null,
          },
        ],
      },
      {
        ...updatedEfforts[1],
        teamId,
        engagements: [
          {
            ...engagement,
            amount: Number(engagement.amount),
          },
        ],
        costBreakdowns: [
          {
            costGroupId: '2',
            cost: Number(engagement.amount),
            engagementId: engagement.engagementId,
            personId: null,
          },
        ],
      },
    ]);
  });
  it('creates effort engagement on a team when effort with this engagement id exists', async () => {
    // Arrange
    const teamId = await createTeam('Create engagement second test team');
    const startTimeFrameId = 42312n;
    const endTimeFrameId = 42312n;
    const alreadyExistingEngagementId = 'ENGAGEMENT-ALREADY-EXISTING';
    const engagement = {
      engagementId: 'ENGAGEMENT-ID-SECOND-TEST',
      amount: 5n,
      comment: 'comment123',
      amountDetails: null,
    };

    const engagementEffortRequest = {
      teamId: teamId,
      startTimeFrameId: startTimeFrameId,
      endTimeFrameId: endTimeFrameId,
      amount: engagement.amount,
      comment: engagement.comment,
      engagementId: engagement.engagementId,
    };

    const effort = {
      teamId: teamId,
      timeFrameId: startTimeFrameId,
      engagements: [
        {
          amount: 55n,
          engagementId: alreadyExistingEngagementId,
          comment: 'xyz',
        },
      ],
    } as EffortEntity;

    await effortRepository.updateEffort(effort);

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves([
      {
        teamId: teamId,
        timeFrameId: startTimeFrameId,
        teamMemberCosts: [
          {
            costGroupId: '2',
            cost: engagement.amount,
            engagementId: engagement.engagementId,
          },
          {
            costGroupId: '3',
            cost: 55n,
            engagementId: alreadyExistingEngagementId,
          },
        ],
      },
    ]);

    // Act
    const response = await supertest(app)
      .post('/efforts/engagements')
      .send(engagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({cost: 60});
    const updatedEfforts = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teamId,
      startTimeFrameId,
      endTimeFrameId
    );
    expect(updatedEfforts).to.have.length(1);
    expect(updatedEfforts[0].engagements).to.have.deep.members([
      {
        ...engagement,
        amount: Number(engagement.amount),
        amountDetails: null,
      },
      {
        ...effort.engagements?.at(0),
        amount: Number(effort.engagements?.at(0)?.amount),
        amountDetails: null,
      },
    ]);
    expect(updatedEfforts[0].costBreakdowns).to.have.deep.members([
      {
        costGroupId: '2',
        cost: Number(engagement.amount),
        engagementId: engagement.engagementId,
        personId: null,
      },
      {
        costGroupId: '3',
        cost: Number(55n),
        engagementId: alreadyExistingEngagementId,
        personId: null,
      },
    ]);
  });

  it('creates calculated effort engagement', async () => {
    // Arrange
    const teamId = await createTeam('Create calculated engagement test team');
    const startTimeFrameId = 42311n;
    const endTimeFrameId = 42311n;
    const engagement = {
      engagementId: 'CALCULATED-ENGAGEMENT-ID-TEST',
      comment: 'comment123',
      amountDetails: {
        calendarId: 'US-VARIABLE',
        rates: [
          {
            people: 3,
            hourlyRate: 20,
            comment: 'calculated comment',
          },
        ],
      },
    };

    const calculatedEngagementEffortRequest = {
      endTimeFrameId: endTimeFrameId,
      engagementCalcInfo: engagement.amountDetails,
      comment: engagement.comment,
    };

    sandbox.stub(eztracCostingClient, 'getCalendarHours').resolves([
      {
        name: 'US Calendar',
        timeFrameId: startTimeFrameId,
        employeeHours: 160,
        contractorHours: 160,
        calendarId: 'US-VARIABLE',
      },
    ]);

    sandbox.stub(eztracCostingClient, 'getEffortCostCalculation').resolves([
      {
        teamId: teamId,
        timeFrameId: startTimeFrameId,
        teamMemberCosts: [
          {
            costGroupId: '2',
            cost: 9600n,
            engagementId: engagement.engagementId,
          },
        ],
      },
    ]);

    // Act
    const response = await supertest(app)
      .post(
        `/efforts/engagements/team/${teamId}/timeFrame/${startTimeFrameId}/engagement/${engagement.engagementId}/calculated`
      )
      .send(calculatedEngagementEffortRequest)
      .set(writeUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({cost: 9600});
    const updatedEfforts = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teamId,
      startTimeFrameId,
      endTimeFrameId
    );
    expect(updatedEfforts).to.have.length(1);
    expect(updatedEfforts).to.have.deep.members([
      {
        ...updatedEfforts[0],
        teamId,
        timeFrameId: startTimeFrameId,
        engagements: [
          {
            ...engagement,
            amount: 9600,
          },
        ],
        costBreakdowns: [
          {
            costGroupId: '2',
            cost: 9600,
            engagementId: engagement.engagementId,
            personId: null,
          },
        ],
      },
    ]);
  });
});
