import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {EffortEntity} from '../../src/api/effort/models';
import {createTeam} from './../utils';
import {effortRepository} from '../../src/api/effort/effortRepository';
import {databaseCleaner} from '../db/cleanupDatabase';
import sinon from 'sinon';
import {eztracCostingClient} from '../../src/util/client/eztracCostingClient';
import {Express} from 'express';

describe('Engagement (GET) ', () => {
  let app: Express;
  const sandbox = sinon.createSandbox();

  let teamId: string;
  let teamId2: string;
  const effort1 = {
    teamId: '',
    timeFrameId: 42310n,
    engagements: [
      {
        amount: 10n,
        engagementId: 'ENGAGEMENT-1',
        comment: 'abc',
        amountDetails: {
          calendarId: 'US-VARIABLE',
          rates: [
            {
              people: 2,
              hourlyRate: 10,
              comment: 'calculated engagement comment',
            },
          ],
        },
      },
      {
        amount: 20n,
        engagementId: 'ENGAGEMENT-2',
      },
    ],
  } as EffortEntity;
  const effort2 = {
    teamId: '',
    timeFrameId: 42311n,
    engagements: [
      {
        amount: 15n,
        engagementId: 'ENGAGEMENT-1',
        comment: 'abc',
      },
    ],
  } as EffortEntity;
  const effort3 = {
    teamId: '',
    timeFrameId: 42309n,
    engagements: [
      {
        amount: 55n,
        engagementId: 'ENGAGEMENT-1',
        comment: 'abc',
      },
    ],
  } as EffortEntity;
  const effort4 = {
    teamId: '',
    timeFrameId: 42311n,
    engagements: [
      {
        amount: 50n,
        engagementId: 'ENGAGEMENT-8',
        comment: 'xyz',
      },
    ],
  } as EffortEntity;

  const mapToResult = (effort: EffortEntity) =>
    effort.engagements
      ? effort.engagements?.map(engagement => ({
          ...engagement,
          teamId: effort.teamId,
          timeFrameId: Number(effort.timeFrameId),
          comment: engagement.comment ?? null,
          amount: Number(engagement.amount),
          amountDetails: engagement.amountDetails ?? null,
        }))
      : [];

  before(async () => {
    app = require('../../server').app;

    sandbox.stub(eztracCostingClient, 'getCalendarHours').resolves([
      {
        name: 'US Calendar',
        timeFrameId: effort1.timeFrameId,
        employeeHours: 160,
        contractorHours: 160,
        calendarId: 'US-VARIABLE',
      },
    ]);

    teamId = await createTeam('Get engagements test team');
    teamId2 = await createTeam('Get engagements test second team');
    effort1.teamId = teamId;
    effort2.teamId = teamId;
    effort3.teamId = teamId;
    effort4.teamId = teamId2;
    await Promise.all(
      [effort1, effort2, effort3, effort4].map(effort => effortRepository.updateEffort(effort))
    );
  });

  after(async () => {
    sandbox.restore();
    await databaseCleaner.cleanupEfforts();
  });

  it('returns engagements for team in provided time frame range', async () => {
    // Arrange
    const startTimeFrameId = 42310n;
    const endTimeFrameId = 42312n;

    // Act
    const response = await supertest(app).get(
      `/efforts/engagements/team/${teamId}?startTimeFrame=${startTimeFrameId}&endTimeFrame=${endTimeFrameId}`
    );

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.have.length(3);
    expect(response.body).to.have.deep.members([...mapToResult(effort1), ...mapToResult(effort2)]);
  });

  it('returns all engagements for team', async () => {
    // Act
    const response = await supertest(app).get(`/efforts/engagements/team/${teamId}`);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.have.length(4);
    expect(response.body).to.have.deep.members([
      ...mapToResult(effort1),
      ...mapToResult(effort2),
      ...mapToResult(effort3),
    ]);
  });

  it('returns empty array when team does not exist', async () => {
    // Act
    const response = await supertest(app).get("/efforts/engagements/team/'NIE-MA-TAKIEGO'");

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.have.length(0);
  });

  it('returns engagements for all teams in provided time range', async () => {
    // Arrange
    const startTimeFrameId = 42310n;
    const endTimeFrameId = 42312n;

    // Act
    const response = await supertest(app).get(
      `/efforts/engagements?startTimeFrame=${startTimeFrameId}&endTimeFrame=${endTimeFrameId}`
    );

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.have.length(4);
    expect(response.body).to.have.deep.members([
      ...mapToResult(effort1),
      ...mapToResult(effort2),
      ...mapToResult(effort4),
    ]);
  });

  it('throws Bad Request error when time frames are invalid', async () => {
    // Arrange
    const startTimeFrameId = 42312n;
    const endTimeFrameId = 42310n;

    // Act
    const forTeamResponse = await supertest(app).get(
      `/efforts/engagements/team/SOME-TEAM?startTimeFrame=${startTimeFrameId}&endTimeFrame=${endTimeFrameId}`
    );
    const allResponse = await supertest(app).get(
      `/efforts/engagements?startTimeFrame=${startTimeFrameId}&endTimeFrame=${endTimeFrameId}`
    );

    // Assert
    expect(forTeamResponse.statusCode).to.equal(StatusCodes.BAD_REQUEST);
    expect(allResponse.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });
});
