import {teamRepository} from '../src/api/team/teamRepository';
import {NameToId} from '../src/util/nameToId';

const getUserProfileHeader = (entitlement: string) => ({
  'user-profile': JSON.stringify({
    id: 'testUser',
    entitlements: {
      eztrac: [entitlement],
    },
  }),
});

export const unauthorizedUserHeader = getUserProfileHeader('irrelevant-entitlement');
export const adminUserHeader = getUserProfileHeader('eztrac-admin-user');
export const writeUserHeader = getUserProfileHeader('eztrac-write-user');
export const teamManagerUserHeader = getUserProfileHeader('eztrac-manage-teams');

export const createTeam = async (teamName: string, isActive = true): Promise<string> => {
  const team = {
    name: teamName,
    communityId: 'E2E-TEST-COMMUNITY',
    isActive: isActive,
  };
  const teamId = NameToId(team.name);
  await teamRepository.create(team, teamId);
  return teamId;
};
