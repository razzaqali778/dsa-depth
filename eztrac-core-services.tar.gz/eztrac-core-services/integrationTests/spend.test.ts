import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {EffortEntity} from '../src/api/effort/models';
import {createTeam} from './utils';
import {effortRepository} from '../src/api/effort/effortRepository';
import {databaseCleaner} from './db/cleanupDatabase';
import sinon from 'sinon';
import {Express} from 'express';
import {personRepository} from '../src/api/person/personRepository';

describe('Spend (GET)', () => {
  let app: Express;
  const sandbox = sinon.createSandbox();

  let teamId: string;
  const user1 = 'spendUser1';
  const user2 = 'spendUser2';
  const user3 = 'spendUser3';
  const effort = {
    teamId: '',
    timeFrameId: 42310n,
    engagements: [
      {
        amount: 100n,
        engagementId: 'ENGAGEMENT-1',
      },
      {
        amount: 200n,
        engagementId: 'ENGAGEMENT-2',
      },
    ],
    allocations: [
      {
        initiativeId: 'init1',
        percentageOfTeamCost: 60n,
      },
      {
        initiativeId: 'init2',
        percentageOfTeamCost: 40n,
      },
    ],
    members: [
      {
        userId: user1,
        percent: 100,
      },
      {
        userId: user2,
        percent: 50,
      },
      {
        userId: user3,
        percent: 100,
      },
    ],
    costBreakdowns: [
      {
        costGroupId: 'costGroup',
        engagementId: 'ENGAGEMENT-2',
        cost: 200n,
      },
      {
        costGroupId: 'costGroup1',
        engagementId: 'ENGAGEMENT-1',
        cost: 100n,
      },
      {
        costGroupId: 'user1&2CostGroup',
        cost: 31680n,
      },
      {
        costGroupId: 'user3CostGroup',
        cost: 21120n,
      },
    ],
  } as EffortEntity;

  before(async () => {
    app = require('../server').app;
    teamId = await createTeam('Spend test team');
    await Promise.all([user1, user2, user3].map(id => personRepository.createPerson(id, id)));
    effort.teamId = teamId;
    await effortRepository.updateEffort(effort);
  });

  after(async () => {
    sandbox.restore();
    await databaseCleaner.cleanupEfforts();
  });

  it('returns spend in provided time frame range', async () => {
    // Arrange
    const startTimeFrameId = 42310n;
    const endTimeFrameId = 42312n;

    // Act
    const response = await supertest(app).get(
      `/spend/startTimeFrame/${startTimeFrameId}/endTimeFrame/${endTimeFrameId}`
    );

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const spendArray = response.body;
    expect(spendArray).to.have.length(1);
    expect(spendArray[0].initiatives).to.have.length(2);
    expect(spendArray[0].initiatives.map((i: {spend: number}) => i.spend)).to.have.members([
      31860, 21240,
    ]);
  });

  it('returns empty array when time frames are invalid', async () => {
    // Arrange
    const startTimeFrameId = 42312n;
    const endTimeFrameId = 42310n;

    // Act
    const response = await supertest(app).get(
      `/spend/startTimeFrame/${startTimeFrameId}/endTimeFrame/${endTimeFrameId}`
    );

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.have.length(0);
  });
});
