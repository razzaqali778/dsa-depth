import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {Express} from 'express';

describe('TimeFrames (GET) ', () => {
  let app: Express;

  before(async () => {
    app = require('../../server').app;
  });

  it('returns all time frames', async () => {
    // Act
    const response = await supertest(app).get('/timeframes');

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    response.body.should.all.have.property('id');
    response.body.should.all.have.property('name');
    response.body.should.all.have.property('startDate');
    response.body.should.all.have.property('endDate');
    response.body.should.all.have.property('lockdown');
    response.body.should.all.have.property('isActive');
  });

  it('returns current time frame', async () => {
    // Act
    const response = await supertest(app).get('/timeframes/current');

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);

    const startDate = new Date();
    startDate.setUTCDate(1);
    startDate.setUTCHours(0, 0, 0, 0);

    const endDate = new Date(startDate);
    endDate.setUTCMonth(endDate.getUTCMonth() + 1);
    endDate.setTime(endDate.getTime() - 1000);

    const timeFrame = response.body;
    expect(timeFrame.startDate).to.equal(startDate.getTime());
    expect(timeFrame.endDate).to.equal(endDate.getTime());
  });

  it('returns current time frame with offset', async () => {
    // Arrange
    const offset = 2;

    // Act
    const response = await supertest(app).get(`/timeframes/current/offset/${offset}`);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);

    const startDate = new Date();
    startDate.setUTCMonth(startDate.getUTCMonth() + offset);
    startDate.setUTCDate(1);
    startDate.setUTCHours(0, 0, 0, 0);

    const endDate = new Date(startDate);
    endDate.setUTCMonth(endDate.getUTCMonth() + 1);
    endDate.setTime(endDate.getTime() - 1000);

    const timeFrame = response.body;
    expect(timeFrame.startDate).to.equal(startDate.getTime());
    expect(timeFrame.endDate).to.equal(endDate.getTime());
  });

  it('returns time frame by id', async () => {
    // Arrange
    const id = 42208;

    // Act
    const response = await supertest(app).get(`/timeframes/${id}`);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);

    const startDate = Date.UTC(2022, 7, 1, 0, 0, 0, 0);
    const endDate = Date.UTC(2022, 7, 31, 23, 59, 59, 0);

    const timeFrame = response.body;
    expect(timeFrame.startDate).to.equal(startDate);
    expect(timeFrame.endDate).to.equal(endDate);
  });
});
