import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {adminUserHeader, unauthorizedUserHeader} from '../utils';
import {Express} from 'express';

describe('TimeFrames (GET) ', () => {
  let app: Express;

  before(async () => {
    app = require('../../server').app;
  });

  it('throws error when user is not authorized to update timeframe', async () => {
    // Arrange
    const id = 42208;
    const status = false;

    // Act
    const response = await supertest(app)
      .patch(`/timeframes/${id}`)
      .send({lockdown: status})
      .set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('updates time frame lockdown status', async () => {
    // Arrange
    const id = 42208;
    const beforeUpdate = await supertest(app).get(`/timeframes/${id}`);
    const status = !beforeUpdate.body.lockdown;

    // Act
    const response = await supertest(app)
      .patch(`/timeframes/${id}`)
      .send({lockdown: status})
      .set(adminUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const {body: updatedTimeFrame} = await supertest(app).get(`/timeframes/${id}`);
    expect(updatedTimeFrame.lockdown).to.equal(status);
  });
});
