import {IDatabase} from 'pg-promise';
import {QueryFile} from 'pg-promise';
import {join as joinPath} from 'path';
import {getDb} from './db';

export const testOrg = {
  id: 'E2E-TEST-ORG',
  name: 'E2E Test Org',
  isActive: true,
};

export const testPlatform = {
  id: 'E2E-TEST-PLATFORM',
  name: 'E2E Test Platform',
  isActive: true,
  orgId: testOrg.id,
};

export const testCommunity = {
  id: 'E2E-TEST-COMMUNITY',
  name: 'E2E Test Community',
  isActive: true,
  platformId: testPlatform.id,
};

export const testTeam = {
  id: 'E2E-TEST-TEAM',
  name: 'E2E Test Team',
  communityId: testCommunity.id,
  isActive: true,
};

const insertOrg =
  'INSERT INTO public.org (org_id, org_name, is_active) VALUES (${id}, ${name}, ${isActive})';

const insertPlatform =
  'INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES (${id}, ${name}, ${isActive}, ${orgId})';

const insertCommunity =
  'INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES (${id}, ${name}, ${isActive}, ${platformId})';

const insertTeam =
  'INSERT INTO public.team (team_id, team_name, is_active, community_id) VALUES (${id}, ${name}, ${isActive}, ${communityId})';

const timeframesFilePath = 'sql/timeframes.sql';
const timeframeWorkdaysFilePath = 'sql/timeframe_workdays.sql';
const platformsFilePath = 'sql/platforms.sql';
const communitiesFilePath = 'sql/communities.sql';
const teamsFilePath = 'sql/teams.sql';
const teamCostsFilePath = 'sql/team_costs.sql';
const teamCostAllocationsFilePath = 'sql/team_cost_allocations.sql';

export async function seedEffortAllocationData() {
  const db: IDatabase<{}> = getDb();
  const teamCostPath = joinPath(__dirname, teamCostsFilePath);
  const teamCostAllocationPath = joinPath(__dirname, teamCostAllocationsFilePath);

  const teamCostSql = new QueryFile(teamCostPath, {minify: true});
  const teamCostAllocationSql = new QueryFile(teamCostAllocationPath, {minify: true});
  await db.none(teamCostSql);
  await db.any(teamCostAllocationSql);
}

export async function seedData() {
  const db: IDatabase<{}> = getDb();
  const timeframePath = joinPath(__dirname, timeframesFilePath);
  const timeframeWorkdaysPath = joinPath(__dirname, timeframeWorkdaysFilePath);
  const platformPath = joinPath(__dirname, platformsFilePath);
  const communityPath = joinPath(__dirname, communitiesFilePath);
  const teamPath = joinPath(__dirname, teamsFilePath);

  const timeframeSql = new QueryFile(timeframePath, {minify: true});
  const timeframeWorkdaysSql = new QueryFile(timeframeWorkdaysPath, {
    minify: true,
  });
  const platformSql = new QueryFile(platformPath, {minify: true});
  const communitySql = new QueryFile(communityPath, {minify: true});
  const teamSql = new QueryFile(teamPath, {minify: true});

  await db.tx(t => {
    const queries = [
      t.none(insertOrg, testOrg),
      t.none(insertPlatform, testPlatform),
      t.none(insertCommunity, testCommunity),
      t.none(insertTeam, testTeam),
    ];
    return t.batch(queries);
  });

  await db.none(timeframeSql);
  await db.none(timeframeWorkdaysSql);
  await db.none(platformSql);
  await db.none(communitySql);
  await db.none(teamSql);
}
