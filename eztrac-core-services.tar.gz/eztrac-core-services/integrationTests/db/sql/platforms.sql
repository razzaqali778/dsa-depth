--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: platform; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('UNKNOWN-PLATFORM', 'Unknown Platform', false, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('IADT-PLATFORM', 'IADT', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('CUSTOMER-PLATFORM', 'Customer', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('OPERATIONS-PLATFORM', 'Operations', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('TECHNICAL-PLATFORMS', 'Tech Platforms', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('LT-OPS-PLATFORM', 'LT & Ops Platform', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('INTEGRATION-PLATFORM', 'Integration', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('ANALYTICS-PLATFORM', 'Decision Science', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('TRANSFORM-EXCELL-PLATFORM', 'Transformation & Excellence Platform', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('WORKFORCE-PLATFORM', 'Workforce', false, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('FIELD-PLATFORM', 'Pipeline', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('FINANCE-PLATFORM', 'Finance', false, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('DIGITAL-FOUNDATIONS-PLATFORM', 'Digital Foundations Platform', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('LAB-PLATFORM', 'Discovery & Lab', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('PERFORMANCE-SERVICE-MANAGEMENT', 'Performance & Service Management', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('PMO-PLATFORM', 'PMO', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('DESIGN-PLATFORM', 'Design', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('RD-PLATFORM', 'RD', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('PS-PLATFORM', 'PS', true, 'E2E-TEST-ORG');
INSERT INTO public.platform (platform_id, platform_name, is_active, org_id) VALUES ('CO-PLATFORM', 'CO', true, 'E2E-TEST-ORG');


--
-- PostgreSQL database dump complete
--

