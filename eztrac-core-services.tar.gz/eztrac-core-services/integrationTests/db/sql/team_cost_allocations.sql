--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: team_cost_allocation; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

-- generating team_cost_allocation_id from sequence --
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1488, 0, '68a0ecdf-fb38-4b6b-b3fa-6d0156b9bc07');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1488, 65, '905d69da-4fcc-4e3a-a3c8-d361caa4469d');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1488, 10, 'adaa5c8a-26e6-4e6e-815c-fc8fdf274941');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1488, 0, '58ae7003-73d1-416d-8731-b6ccdb286da6');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1488, 0, 'fe0b54eb-9c16-4880-b5b9-d9db28bae554');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1488, 0, '12256b15-07c1-49c9-8186-dc832a4abcc1');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1488, 0, 'eeed0716-0b43-4c1b-8c4b-dddfdedf5e52');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1489, 100, '5b2182ae-6a4c-4e95-958e-580bb06457bb');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1488, 15, '114d7487-d5ba-4885-82c7-de3ee14a1e58');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1488, 10, '46e9f1fa-0a32-451c-bf37-a1df408403f6');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1490, 29, '58c763c0-002d-11e7-8c34-bbc3bcdf3550');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1490, 29, '2c9a5690-002d-11e7-8c34-bbc3bcdf3550');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1491, 17, '712f3c0f-aab5-4544-a5c7-ca2156068e72');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1491, 49, '322ef390-40cc-4506-9dbc-e8db364c60f2');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1491, 34, 'ac979dc5-70ad-4942-b911-dd697c6cc3bd');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1502, 10, '20c07920-050d-11ea-9bb5-c5657d877734');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1502, 20, 'c5fa02f0-07db-11ea-9bb5-c5657d877734');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1516, 10, '20c07920-050d-11ea-9bb5-c5657d877734');
INSERT INTO public.team_cost_allocation (team_cost_id, team_cost_pct, vip_initiative_id) VALUES (1516, 20, 'c5fa02f0-07db-11ea-9bb5-c5657d877734');
--
-- Name: team_cost_allocation_team_cost_allocation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: EzTracAdminUser
--

SELECT pg_catalog.setval('public.team_cost_allocation_team_cost_allocation_id_seq', 276849, true);


--
-- PostgreSQL database dump complete
--

