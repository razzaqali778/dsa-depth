--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.9 (Homebrew)

--
-- Data for Name: timeframe; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42007, 'Jul 2020', '2020-07-01 00:00:00+00', '2020-07-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42008, 'Aug 2020', '2020-08-01 00:00:00+00', '2020-08-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42009, 'Sep 2020', '2020-09-01 00:00:00+00', '2020-09-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42010, 'Oct 2020', '2020-10-01 00:00:00+00', '2020-10-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42011, 'Nov 2020', '2020-11-01 00:00:00+00', '2020-11-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42012, 'Dec 2020', '2020-12-01 00:00:00+00', '2020-12-31 23:59:59.999+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32104, 'Jan 2018', '2018-01-01 00:00:00+00', '2018-01-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32105, 'Feb 2018', '2018-02-01 00:00:00+00', '2018-02-28 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32106, 'Mar 2018', '2018-03-01 00:00:00+00', '2018-03-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32107, 'Apr 2018', '2018-04-01 00:00:00+00', '2018-04-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32108, 'May 2018', '2018-05-01 00:00:00+00', '2018-05-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32109, 'Jun 2018', '2018-06-01 00:00:00+00', '2018-06-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32111, 'Aug 2018', '2018-08-01 00:00:00+00', '2018-08-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41809, 'Sep 2018', '2018-09-01 00:00:00+00', '2018-09-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41810, 'Oct 2018', '2018-10-01 00:00:00+00', '2018-10-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32110, 'Jul 2018', '2018-07-01 00:00:00+00', '2018-07-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32007, 'May 2017', '2017-05-01 00:00:00+00', '2017-05-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32008, 'Jun 2017', '2017-06-01 00:00:00+00', '2017-06-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32009, 'Jul 2017', '2017-07-01 00:00:00+00', '2017-07-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32010, 'Aug 2017', '2017-08-01 00:00:00+00', '2017-08-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17226, 'Sep 2015', '2015-09-01 00:00:00+00', '2015-09-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17227, 'Oct 2015', '2015-10-01 00:00:00+00', '2015-10-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17229, 'Dec 2015', '2015-12-01 00:00:00+00', '2015-12-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17230, 'Jan 2016', '2016-01-01 00:00:00+00', '2016-01-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17231, 'Feb 2016', '2016-02-01 00:00:00+00', '2016-02-29 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17232, 'Mar 2016', '2016-03-01 00:00:00+00', '2016-03-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17233, 'Apr 2016', '2016-04-01 00:00:00+00', '2016-04-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17234, 'May 2016', '2016-05-01 00:00:00+00', '2016-05-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17235, 'Jun 2016', '2016-06-01 00:00:00+00', '2016-06-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17236, 'Jul 2016', '2016-07-01 00:00:00+00', '2016-07-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17237, 'Aug 2016', '2016-08-01 00:00:00+00', '2016-08-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11643, 'Sep 2014', '2014-09-01 00:00:00+00', '2014-09-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11641, 'Oct 2014', '2014-10-01 00:00:00+00', '2014-10-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11635, 'Nov 2014', '2014-11-01 00:00:00+00', '2014-11-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11638, 'Dec 2014', '2014-12-01 00:00:00+00', '2014-12-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42002, 'Feb 2020', '2020-02-01 00:00:00+00', '2020-02-29 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42001, 'Jan 2020', '2020-01-01 00:00:00+00', '2020-01-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42003, 'Mar 2020', '2020-03-01 00:00:00+00', '2020-03-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42004, 'Apr 2020', '2020-04-01 00:00:00+00', '2020-04-30 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41901, 'Jan 2019', '2019-01-01 00:00:00+00', '2019-01-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41902, 'Feb 2019', '2019-02-01 00:00:00+00', '2019-02-28 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41903, 'Mar 2019', '2019-03-01 00:00:00+00', '2019-03-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41904, 'Apr 2019', '2019-04-01 00:00:00+00', '2019-04-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41905, 'May 2019', '2019-05-01 00:00:00+00', '2019-05-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41906, 'Jun 2019', '2019-06-01 00:00:00+00', '2019-06-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41907, 'Jul 2019', '2019-07-01 00:00:00+00', '2019-07-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41908, 'Aug 2019', '2019-08-01 00:00:00+00', '2019-08-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41909, 'Sep 2019', '2019-09-01 00:00:00+00', '2019-09-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41910, 'Oct 2019', '2019-10-01 00:00:00+00', '2019-10-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41911, 'Nov 2019', '2019-11-01 00:00:00+00', '2019-11-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41912, 'Dec 2019', '2019-12-01 00:00:00+00', '2019-12-31 23:59:59.999+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42005, 'May 2020', '2020-05-01 00:00:00+00', '2020-05-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42006, 'Jun 2020', '2020-06-01 00:00:00+00', '2020-06-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11634, 'Jan 2015', '2015-01-01 00:00:00+00', '2015-01-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11642, 'Feb 2015', '2015-02-01 00:00:00+00', '2015-02-28 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11637, 'Mar 2015', '2015-03-01 00:00:00+00', '2015-03-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11636, 'Apr 2015', '2015-04-01 00:00:00+00', '2015-04-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11644, 'May 2015', '2015-05-01 00:00:00+00', '2015-05-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11645, 'Jun 2015', '2015-06-01 00:00:00+00', '2015-06-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11640, 'Jul 2015', '2015-07-01 00:00:00+00', '2015-07-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (11639, 'Aug 2015', '2015-08-01 00:00:00+00', '2015-08-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (17228, 'Nov 2015', '2015-11-01 00:00:00+00', '2015-11-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (31999, 'Sep 2016', '2016-09-01 00:00:00+00', '2016-09-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32000, 'Oct 2016', '2016-10-01 00:00:00+00', '2016-10-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32001, 'Nov 2016', '2016-11-01 00:00:00+00', '2016-11-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32002, 'Dec 2016', '2016-12-01 00:00:00+00', '2016-12-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32003, 'Jan 2017', '2017-01-01 00:00:00+00', '2017-01-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32004, 'Feb 2017', '2017-02-01 00:00:00+00', '2017-02-28 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32005, 'Mar 2017', '2017-03-01 00:00:00+00', '2017-03-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32006, 'Apr 2017', '2017-04-01 00:00:00+00', '2017-04-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41811, 'Nov 2018', '2018-11-01 00:00:00+00', '2018-11-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32100, 'Sep 2017', '2017-09-01 00:00:00+00', '2017-09-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32101, 'Oct 2017', '2017-10-01 00:00:00+00', '2017-10-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32102, 'Nov 2017', '2017-11-01 00:00:00+00', '2017-11-30 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (32103, 'Dec 2017', '2017-12-01 00:00:00+00', '2017-12-31 23:59:59+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (41812, 'Dec 2018', '2018-12-01 00:00:00+00', '2018-12-31 23:59:59.999+00', true, false);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42101, 'Jan 2021', '2021-01-01 00:00:00+00', '2021-01-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42102, 'Feb 2021', '2021-02-01 00:00:00+00', '2021-02-28 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42103, 'Mar 2021', '2021-03-01 00:00:00+00', '2021-03-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42104, 'Apr 2021', '2021-04-01 00:00:00+00', '2021-04-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42105, 'May 2021', '2021-05-01 00:00:00+00', '2021-05-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42106, 'Jun 2021', '2021-06-01 00:00:00+00', '2021-06-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42107, 'Jul 2021', '2021-07-01 00:00:00+00', '2021-07-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42108, 'Aug 2021', '2021-08-01 00:00:00+00', '2021-08-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42109, 'Sep 2021', '2021-09-01 00:00:00+00', '2021-09-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42110, 'Oct 2021', '2021-10-01 00:00:00+00', '2021-10-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42202, 'Feb 2022', '2022-02-01 00:00:00+00', '2022-02-28 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42203, 'Mar 2022', '2022-03-01 00:00:00+00', '2022-03-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42204, 'Apr 2022', '2022-04-01 00:00:00+00', '2022-04-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42205, 'May 2022', '2022-05-01 00:00:00+00', '2022-05-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42209, 'Sep 2022', '2022-09-01 00:00:00+00', '2022-09-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42111, 'Nov 2021', '2021-11-01 00:00:00+00', '2021-11-30 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42210, 'Oct 2022', '2022-10-01 00:00:00+00', '2022-10-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42208, 'Aug 2022', '2022-08-01 00:00:00+00', '2022-08-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42112, 'Dec 2021', '2021-12-01 00:00:00+00', '2021-12-31 23:59:59.999+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42201, 'Jan 2022', '2022-01-01 00:00:00+00', '2022-01-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42206, 'Jun 2022', '2022-06-01 00:00:00+00', '2022-06-30 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42207, 'Jul 2022', '2022-07-01 00:00:00+00', '2022-07-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42212, 'Dec 2022', '2022-12-01 00:00:00+00', '2022-12-31 23:59:59.999+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42309, 'Sep 2023', '2023-09-01 00:00:00+00', '2023-09-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42311, 'Nov 2023', '2023-11-01 00:00:00+00', '2023-11-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42312, 'Dec 2023', '2023-12-01 00:00:00+00', '2023-12-31 23:59:59.999+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42211, 'Nov 2022', '2022-11-01 00:00:00+00', '2022-11-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42301, 'Jan 2023', '2023-01-01 00:00:00+00', '2023-01-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42302, 'Feb 2023', '2023-02-01 00:00:00+00', '2023-02-28 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42303, 'Mar 2023', '2023-03-01 00:00:00+00', '2023-03-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42304, 'Apr 2023', '2023-04-01 00:00:00+00', '2023-04-30 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42305, 'May 2023', '2023-05-01 00:00:00+00', '2023-05-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42306, 'Jun 2023', '2023-06-01 00:00:00+00', '2023-06-30 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42307, 'Jul 2023', '2023-07-01 00:00:00+00', '2023-07-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42308, 'Aug 2023', '2023-08-01 00:00:00+00', '2023-08-31 23:59:59+00', true, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42310, 'Oct 2023', '2023-10-01 00:00:00+00', '2023-10-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42401, 'Jan 2024', '2024-01-01 00:00:00+00', '2024-01-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42402, 'Feb 2024', '2024-02-01 00:00:00+00', '2024-02-29 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42403, 'Mar 2024', '2024-03-01 00:00:00+00', '2024-03-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42404, 'Apr 2024', '2024-04-01 00:00:00+00', '2024-04-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42405, 'May 2024', '2024-05-01 00:00:00+00', '2024-05-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42406, 'Jun 2024', '2024-06-01 00:00:00+00', '2024-06-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42407, 'Jul 2024', '2024-07-01 00:00:00+00', '2024-07-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42408, 'Aug 2024', '2024-08-01 00:00:00+00', '2024-08-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42409, 'Sep 2024', '2024-09-01 00:00:00+00', '2024-09-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42410, 'Oct 2024', '2024-10-01 00:00:00+00', '2024-10-31 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42411, 'Nov 2024', '2024-11-01 00:00:00+00', '2024-11-30 23:59:59+00', false, true);
INSERT INTO public.timeframe (timeframe_id, timeframe_name, timeframe_start_date, timeframe_end_date, lockdown, is_active) VALUES (42412, 'Dec 2024', '2024-12-01 00:00:00+00', '2024-12-31 23:59:59.999+00', false, true);


--
-- PostgreSQL database dump complete
--

