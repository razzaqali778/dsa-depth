--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: community; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('UNKNOWN-COMMUNITY', 'Unknown Community', false, 'UNKNOWN-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('IADT', 'IADT', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('SALES-COMMUNITY', 'Sales', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-PLATFORM-PLANNING', 'Planning', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('CUSTOMER-PRODUCT-MANAGEMENT', 'Customer Platform Product Management', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FIELD-COMMIT', 'Commit', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('INFORMATION-ASSETS', 'Information Assets', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-PLATFORM-CONNECTED-SYSTEMS', 'Connected Systems', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FIELD-MAKE', 'Make', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('CUSTOMER-MARKETING', 'Marketing', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-PLATFORM-DEMAND-PLANNING', 'Demand Planning', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-PLATFORM-ORDER-MGMT', 'Order Management', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FIELD-MAPS', 'Maps', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('SERVICE-COMMUNITY', 'Service', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('STRATEGY-COMMUNITY', 'Strategy', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('TECHNICAL-PLATFORMS', 'Tech Platforms', true, 'TECHNICAL-PLATFORMS');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PROD-MGMT-STRATEGY-OPS', 'Product Management - LT & Ops', true, 'LT-OPS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PELT', 'Products and Engineering LT', true, 'LT-OPS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PRODUCT360', 'Product360', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('LOCATION360', 'Location360', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('INTEGRATION-COMMUNITY', 'Integration', true, 'INTEGRATION-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('CUSTOMER360', 'Customer360', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('AGILE-OFFICE', 'Agile Office', true, 'TRANSFORM-EXCELL-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DS-CUSTOMER-CENTRICITY', 'DS - Customer Centricity', true, 'ANALYTICS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DS-CENTER-OF-EXCELLENCE', 'DS - Center of Excellence', true, 'ANALYTICS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DS-PREDICTIVE-PIPELINE', 'DS - Predictive Pipeline', true, 'ANALYTICS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DS-SMART-OPERATIONS', 'DS - Smart Operations', true, 'ANALYTICS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DS-LEADERSHIP', 'DS - Leadership', true, 'ANALYTICS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DS-CVS', 'DS - Connected Virtual Systems', true, 'ANALYTICS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('ANALYTICS', 'AP - Analytics', false, 'ANALYTICS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('SCIENCE-AT-SCALE', 'Science At Scale', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DIGITAL-COMMERCE', 'Digital Commerce', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DIGITAL-FINANCE', 'Digital Finance', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('ELD', 'Entry Level Developers', true, 'TRANSFORM-EXCELL-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FIELD-MEASURE', 'Assessments', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FINANCE-GLOBAL-BARTER', 'Global Barter', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FINANCE-REGIONAL-COMMUNITY', 'Finance Regional', false, 'FINANCE-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('WORKFORCE', 'Workforce', false, 'WORKFORCE-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FINANCE-HR-PAYROLL-TIME', 'HR Payroll & Time', false, 'FINANCE-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('LAB-MOLECULAR-TESTING', 'Molecular Analysis', false, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DESIGN-DESIGN', 'Design', false, 'WORKFORCE-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-PLATFORM-MATERIAL-MANAGEMENT', 'Logistics', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FINANCE-VALUE-CAPTURE', 'Value Capture', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OUTCOME-BASED-PRICING-COMMUNITY', 'Outcome Based Pricing', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DATA-OPS', 'Data Ops', true, 'DIGITAL-FOUNDATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-PLATFORM-PRODUCT-LIFECYCLE', 'Portfolio', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PLATFORM-ENABLEMENT', 'Platform Enablement', true, 'TRANSFORM-EXCELL-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PROD-DEV-STRATEGY-OPS', 'Product Development - LT & Ops', false, 'LT-OPS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FIELD-COMPARE', 'Decisions', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('CUSTOMER-EXPERIENCE', 'Customer Platform Experience', false, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('FINANCE-ACCOUNTING', 'Accounting', false, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PIPELINE-MATERIALS', 'Materials', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-CONNECTED-SUPPLY-CHAIN', 'Connected Supply Chain', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-PRICING', 'Operations Pricing', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-LT', 'Operations LT', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('IADT-NA-STEWARDSHIP', 'NA Stewardship', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('IADT-CO360-STEWARDSHIP', 'Co360 Stewardship', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('IADT-Ops', 'IADT Ops', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('IADT-TP-DATA', 'TP Data', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('IADT-COMPANY360', 'Company 360', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('IADT-STEWARDSHIP', 'Stewardship', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('IADT-CU260-STEWARDSHIP', 'CU360 Stewardship', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('IADT-P360-STEWARDSHIP', 'P360 Stewardship', true, 'IADT-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('CUSTOMER-SALES-SERVICE', 'Sales and Service', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PRICING-COMMUNITY', 'Pricing & Portfolio', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('LATAM-CUSTOMER', 'LATAM Customer Community', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('EMEA-CUSTOMER', 'EMEA Customer Community', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PIPELINE-PLANNING', 'Planning – Pipeline', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PIPELINE-LT', 'Pipeline LT', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('TALENT-AND-EXPERIENCE', 'Talent & Experience', true, 'TRANSFORM-EXCELL-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('COMM-AND-OPS', 'Comm & Ops', true, 'TRANSFORM-EXCELL-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('CHANGE-MGMNT', 'Change Mgmnt', true, 'TRANSFORM-EXCELL-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('TRANFORM-EXCELL', 'T&E LT', true, 'TRANSFORM-EXCELL-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PIPELINE-GERMANY', 'Pipeline - Germany', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PIPELINE-PRODUCT-SPECIALISTS', 'Product Specialists', true, 'FIELD-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PERFORMANCE-SERVICE-MANAGEMENT', 'Performance & Service Management', true, 'PERFORMANCE-SERVICE-MANAGEMENT');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DELIVERY-CHANGE-EXCELLENCE', 'Delivery & Change Excellence', true, 'TRANSFORM-EXCELL-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PMO-PRODUCT-SUPPLY', 'Product Supply', true, 'PMO-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PMO-R-AND-D-AND-IT', 'R&D & IT', true, 'PMO-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PMO-COMMERCIAL', 'Commercial', true, 'PMO-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PMO-EMEA-AA', 'EMEA & AA', true, 'PMO-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PMO-LATAM', 'PMO-LATAM', true, 'PMO-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PMO-NA-AND-VEG', 'PMO-NA & Veg', true, 'PMO-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('ERP-INTEGRATION', 'ERP Integration', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('MARKET-FUNDING-REBATE-MGMT', 'Market Funding & Rebate Mgmt', true, 'CUSTOMER-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('D-L-LT-MISC', 'D&L LT & Misc', true, 'LAB-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('D-L-PRODUCT-SPECIALISTS', 'D&L Product Specialists', true, 'LAB-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('D-L-DESIGN', 'D&L Design', true, 'DESIGN-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('CUSTOMER-DESIGN', 'Customer Design', true, 'DESIGN-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-MANUFACTURING', 'MFG MOM', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('ASSET-MANAGEMENT', 'MFG MAM', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('OPERATIONS-DESIGN', 'Operations Design', true, 'DESIGN-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('PIPELINE-DESIGN', 'Pipeline Design', true, 'DESIGN-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('LAB-GERMANY', 'Assemble', true, 'LAB-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('LAB-DISCOVERY-SYNTHESIS', 'Create', true, 'LAB-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('LAB-DATA-DECISIONS-GERMANY', 'Advance', true, 'LAB-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('LAB-LAB-MANAGEMENT', 'Test', true, 'LAB-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('MFG-MES', 'MFG MES', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('AUTOMATION', 'Automation', true, 'OPERATIONS-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('T-E-DESIGN', 'T&E Design', true, 'DESIGN-PLATFORM');
INSERT INTO public.community (community_id, community_name, is_active, platform_id) VALUES ('DESIGN-LT', 'Design LT', true, 'DESIGN-PLATFORM');


--
-- PostgreSQL database dump complete
--

