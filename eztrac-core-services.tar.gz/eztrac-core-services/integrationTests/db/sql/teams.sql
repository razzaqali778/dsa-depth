--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('Armageddon Dev Team', NULL, 'ARMAGEDDON-DEV-TEAM', true, 'FIELD-COMPARE');
INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('PAC - Edgewater Dev Team', '2017-01-01 00:00:00', 'PAC-EDGEWATER-DEV-TEAM', false, 'UNKNOWN-COMMUNITY');
INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('TP Security Dev Team', '2017-09-01 00:00:00', 'TP-SECURITY-DEV-TEAM', false, 'UNKNOWN-COMMUNITY');
INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('Analytics Customer Dev Team', NULL, 'ANALYTICS-CUSTOMER-DEV-TEAM', true, 'DS-CUSTOMER-CENTRICITY');
INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('test team123', NULL, 'TEST-TEAM123', true, 'FINANCE-GLOBAL-BARTER');
INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('301', NULL, '301', true, 'DIGITAL-COMMERCE');
INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('Data Delivery - Advancement', '2015-03-01 06:00:00', '11652', false, 'UNKNOWN-COMMUNITY');
INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('Data 360 - Customer 360 - Support', '2018-12-10 14:46:43.796009', 'DATA-360-CUSTOMER-360-SUPPORT-INTERNAL', false, 'INFORMATION-ASSETS');
INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('Data Delivery - Genomics', '2015-03-01 06:00:00', '11653', false, 'UNKNOWN-COMMUNITY');
INSERT INTO public.team (team_name, inactive_start_date, team_id, is_active, community_id) VALUES ('Data Delivery & Engineering', '2015-03-01 06:00:00', '11656', false, 'UNKNOWN-COMMUNITY');


--
-- PostgreSQL database dump complete
--

