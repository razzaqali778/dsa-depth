--
-- PostgreSQL database dump
--

-- Dumped from database version 12.14
-- Dumped by pg_dump version 14.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: team_cost; Type: TABLE DATA; Schema: public; Owner: EzTracAdminUser
--

-- generating team_cost_id from sequence --
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (32004, 88000, 'ARMAGEDDON-DEV-TEAM');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (32002, 19200, 'PAC-EDGEWATER-DEV-TEAM');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (32005, 110400, 'TP-SECURITY-DEV-TEAM');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (32004, 48000, 'ANALYTICS-CUSTOMER-DEV-TEAM');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42312, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42311, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42310, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42309, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42308, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42307, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42306, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42305, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42304, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42303, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42302, 3000, 'TEST-TEAM123');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42005, 145568, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42012, 59352, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42301, 15055, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42303, 26199, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42306, 54055, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42401, 40630, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42402, 310, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42403, 100, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42404, 100, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42405, 100, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42406, 100, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42407, 100, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42408, 100, '301');
INSERT INTO public.team_cost (timeframe_id, cost, team_id) VALUES (42412, 3000, 'TEST-TEAM123');

--
-- PostgreSQL database dump complete
--

