  DELETE FROM public.team_cost_allocation;
  DELETE FROM public.team_cost_member;
  DELETE FROM public.forecast_person;
  DELETE FROM public.team_cost_engagement;
  DELETE FROM public.team_cost_breakdown;
  DELETE FROM public.team_cost;