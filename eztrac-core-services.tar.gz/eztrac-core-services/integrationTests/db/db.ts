import config from '../../src/config/index';
import pgPromise, {IDatabase} from 'pg-promise';

let dbInstance: IDatabase<object> | undefined;

export const getDb = (): IDatabase<object> => {
  if (!dbInstance) {
    const credentials = config.get('coreDb') || '';
    const dbName = credentials.database;
    if (dbName !== 'CoreDb-IT') {
      throw Error('wrong database!');
    }
    const dbConfig = {
      ...credentials,
      allowExitOnIdle: true,
    };
    const pgp = pgPromise();
    dbInstance = pgp(dbConfig);
  }
  return dbInstance;
};
