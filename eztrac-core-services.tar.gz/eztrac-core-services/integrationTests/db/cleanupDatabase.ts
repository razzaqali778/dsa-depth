import {QueryFile} from 'pg-promise';
import {join as joinPath} from 'path';
import {getDb} from './db';

const cleanupAllSqlFilePath = 'sql/teardown.sql';
const cleanupEffortsSqlFilePath = 'sql/deleteEfforts.sql';

const cleanupAllQuery = new QueryFile(joinPath(__dirname, cleanupAllSqlFilePath), {minify: true});
const cleanupEffortsQuery = new QueryFile(joinPath(__dirname, cleanupEffortsSqlFilePath), {
  minify: true,
});

const cleanupDatabase = async () => {
  const dbInstance = getDb();
  await dbInstance.none(cleanupAllQuery);
};

const cleanupEfforts = async () => {
  const dbInstance = getDb();
  await dbInstance.none(cleanupEffortsQuery);
};

export const databaseCleaner = {
  cleanupDatabase,
  cleanupEfforts,
};
