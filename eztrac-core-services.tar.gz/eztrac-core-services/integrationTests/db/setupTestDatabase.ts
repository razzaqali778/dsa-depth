import config from '../../src/config/index';
import pgMigrationRunner from 'node-pg-migrate';
import {RunMigration} from 'node-pg-migrate/dist/migration';
import {MigrationDirection} from 'node-pg-migrate/dist/types';
import {Client} from 'pg';
import {seedData} from './dataSeed';
import {databaseCleaner} from './cleanupDatabase';

const runMigrations = async (): Promise<RunMigration[]> => {
  const credentials = config.get('coreDb') || '';
  const client = new Client(credentials);
  await client.connect();
  const pgMigrationOptions = {
    dbClient: client,
    dir: 'migrations',
    direction: 'up' as MigrationDirection,
    migrationsTable: 'pgmigrations',
  };
  const migrationResponse = await pgMigrationRunner(pgMigrationOptions);
  console.log(migrationResponse);

  await client.end();
  return migrationResponse;
};

export const setupIntegrationTestDatabase = async () => {
  await databaseCleaner.cleanupDatabase();
  await runMigrations();
  await seedData();
};
