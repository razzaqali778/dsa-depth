import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {testCommunity, testOrg, testPlatform} from '../db/dataSeed';
import {createTeam, unauthorizedUserHeader} from '../utils';
import {Team, TeamStructure} from '../../src/api/team/models';
import {Express} from 'express';
import {Community} from '../../src/api/community/models';
import {Platform} from '../../src/api/platform/models';

describe('Team, Community, Platform (GET)', () => {
  const activeTeamName = 'get tests active team';
  let activeTeamId = '';
  const inActiveTeamName = 'get tests inactive team qwerty';
  let inActiveTeamId = '';
  const otherTeamName = 'qwerty get tests other team';
  let otherTeamId = '';

  let app: Express;
  before(async () => {
    app = require('../../server').app;

    [activeTeamId, inActiveTeamId, otherTeamId] = await Promise.all([
      createTeam(activeTeamName),
      createTeam(inActiveTeamName, false),
      createTeam(otherTeamName),
    ]);
  });

  it('gets teams with structure', async () => {
    // Act
    const response = await supertest(app).get('/teamStructure');

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const team = response.body.find((t: TeamStructure) => t.teamId === activeTeamId);
    expect(team).to.deep.equal({
      teamName: activeTeamName,
      teamId: activeTeamId,
      communityId: testCommunity.id,
      communityName: testCommunity.name,
      platformId: testPlatform.id,
      platformName: testPlatform.name,
      orgId: testOrg.id,
      orgName: testOrg.name,
      isActive: true,
    });
  });

  it('gets communities', async () => {
    // Act
    const response = await supertest(app).get('/communities').set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const community = response.body.find((c: Community) => c.id === testCommunity.id);
    expect(community).to.deep.equal(testCommunity);
  });

  it('gets platforms', async () => {
    // Act
    const response = await supertest(app).get('/platforms').set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const platform = response.body.find((p: Platform) => p.id === testPlatform.id);
    expect(platform).to.deep.equal(testPlatform);
  });

  it('gets all teams', async () => {
    // Act
    const response = await supertest(app).get('/teams');

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const teams: Team[] = response.body;
    expect([activeTeamId, inActiveTeamId, otherTeamId].every(id => teams.find(t => t.id === id))).to
      .be.true;
  });

  it('gets active teams', async () => {
    // Act
    const response = await supertest(app).get('/teams').query({isActive: true});

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const teams: Team[] = response.body;
    expect(teams.every(t => t.isActive === true)).to.be.true;
  });

  it('gets inactive teams', async () => {
    // Act
    const response = await supertest(app).get('/teams').query({isActive: false});

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const teams: Team[] = response.body;
    expect(teams.every(t => t.isActive === false)).to.be.true;
  });

  it('gets teams by query filter', async () => {
    // Act
    const response = await supertest(app).get('/teams').query({q: 'qwerty'});

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    const teams: Team[] = response.body;
    expect(teams.map(t => t.id)).to.have.deep.members([otherTeamId]);
  });

  it('gets team by id', async () => {
    // Act
    const response = await supertest(app).get(`/team/${activeTeamId}`);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({
      id: activeTeamId,
      name: activeTeamName,
      communityId: testCommunity.id,
      isActive: true,
    });
  });

  it('throw error when team with given id does not exist', async () => {
    // Arrange
    const teamId = 'some wrong id';

    // Act
    const response = await supertest(app).get(`/team/${teamId}`);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.NOT_FOUND);
  });
});
