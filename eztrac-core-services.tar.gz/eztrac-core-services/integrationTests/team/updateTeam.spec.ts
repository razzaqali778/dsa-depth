import {TeamsPath} from '../constants';
import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {testCommunity, testTeam} from '../db/dataSeed';
import {createTeam, teamManagerUserHeader, unauthorizedUserHeader} from '../utils';
import {effortRepository} from '../../src/api/effort/effortRepository';
import {Express} from 'express';

describe('Team', () => {
  let app: Express;
  before(() => {
    app = require('../../server').app;
  });

  it('throws Unauthorized error when eztrac-manage-teams entitlement id not present in request headers', async () => {
    // Act
    const response = await supertest(app)
      .put(`${TeamsPath.Team}/${testTeam.id}`)
      .set(unauthorizedUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('updates team', async () => {
    // Arrange
    const teamToUpdate = {
      ...testTeam,
      name: 'Updated name',
      isActive: false,
    };

    // Act
    const response = await supertest(app)
      .put(`${TeamsPath.Team}/${testTeam.id}`)
      .send(teamToUpdate)
      .set(teamManagerUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal(teamToUpdate);
  });

  it('fails to set status to inactive, when there are future efforts on the team', async () => {
    // Arrange
    const teamName = 'update test team';
    const teamId = await createTeam(teamName);
    const teamToUpdate = {
      id: teamId,
      communityId: testCommunity.id,
      name: teamName + ' updated',
      isActive: false,
    };

    await effortRepository.updateEffort({
      teamId: teamId,
      timeFrameId: 42403n,
      engagements: [
        {
          engagementId: 'abc',
          amount: 12n,
        },
      ],
      costBreakdowns: [
        {
          costGroupId: 'cdf',
          cost: 12n,
          engagementId: 'abc',
        },
      ],
    });

    // Act
    const response = await supertest(app)
      .put(`${TeamsPath.Team}/${teamId}`)
      .send(teamToUpdate)
      .set(teamManagerUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });
});
