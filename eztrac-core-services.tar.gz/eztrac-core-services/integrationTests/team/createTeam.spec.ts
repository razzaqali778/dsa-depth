import {TeamsPath} from '../constants';
import {expect} from 'chai';
import supertest from 'supertest';
import {StatusCodes} from 'http-status-codes';
import {testTeam} from '../db/dataSeed';
import {teamManagerUserHeader, unauthorizedUserHeader} from '../utils';
import {Express} from 'express';

describe('Team', () => {
  let app: Express;
  before(() => {
    app = require('../../server').app;
  });

  it('throws Forbidden error when eztrac-manage-teams entitlement id not present in request headers', async () => {
    // Act
    const response = await supertest(app)
      .post(TeamsPath.Team)
      .set('user-profile', JSON.stringify(unauthorizedUserHeader));

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.FORBIDDEN);
  });

  it('throws Bad Request error when request body is malformed', async () => {
    // Arrange
    const teamToCreate = {
      communityId: 'E2E-TEST-COMMUNITY',
      isActive: 'not good',
    };

    // Act
    const response = await supertest(app)
      .post(TeamsPath.Team)
      .send(teamToCreate)
      .set(teamManagerUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
  });

  it('creates team', async () => {
    // Arrange
    const teamToCreate = {
      name: 'Equality test team',
      communityId: 'E2E-TEST-COMMUNITY',
      isActive: true,
    };

    // Act
    const response = await supertest(app)
      .post(TeamsPath.Team)
      .send(teamToCreate)
      .set(teamManagerUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.OK);
    expect(response.body).to.deep.equal({
      id: 'EQUALITY-TEST-TEAM',
      ...teamToCreate,
    });
  });

  it('fails to create team when team with given name already exists', async () => {
    // Arrange
    const teamToCreate = {
      name: testTeam.name,
      isActive: testTeam.isActive,
      communityId: testTeam.communityId,
    };
    // Act
    const response = await supertest(app)
      .post(TeamsPath.Team)
      .send(teamToCreate)
      .set(teamManagerUserHeader);

    // Assert
    expect(response.statusCode).to.equal(StatusCodes.BAD_REQUEST);
    expect(response.body.message).to.equal('Team with given name already exists');
  });
});
