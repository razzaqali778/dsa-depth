import {Request, Response, NextFunction} from 'express';

// Recursively converts Dates to epoch milliseconds so response payloads keep the
// existing wire format (many consumers rely on numeric startDate/endDate values)
// without mutating the global Date.prototype.toJSON, which would affect every Date
// in the process (logging, other libraries, etc.).
const serializeDates = (value: unknown): unknown => {
  if (value instanceof Date) return value.getTime();
  if (Array.isArray(value)) return value.map(serializeDates);
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).map(([key, val]) => [key, serializeDates(val)])
    );
  }
  return value;
};

// `any` is scoped to just this handler type (rather than disabled file-wide) because every
// route passes a differently-shaped `ValidatedRequest<Schema>`; typing this precisely would
// require threading a generic through every call site's `apiResponse<...>()` invocation.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type ApiRequestHandler = (req: any, res: Response) => any;

// with this wrapper function it is not needed to add try catch blocks in every request handler function
// it won't be needed if we start using express 5.x (now in beta), because then when a callback function throws an error or returns a rejected promise, `next(err)` will be invoked automatically
export const apiResponse =
  (fn: ApiRequestHandler) => async (req: Request, res: Response, next: NextFunction) => {
    const originalJson = res.json.bind(res);
    res.json = ((body?: unknown) => originalJson(serializeDates(body))) as Response['json'];
    try {
      await fn(req, res);
    } catch (err) {
      next(err);
    }
  };
