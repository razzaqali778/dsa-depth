const swagger = require('swagger-tools')
const swaggerConfig = require('../../swagger.json')
const costCalcApi = require('../api/costcalc/routes')
const fullEffortApi = require('../api/effort/effortRoute')
import GETExportApi from '../api/GETExport/routes'
import timeFrameApi from '../api/timeframe/routes'
import spendApi from '../api/spend/routes'
const effortAllocationApi = require('../api/effort/allocation/effortAllocationRoute')
const effortEngagementApi = require('../api/effort/engagement/effortEngagementRoute')
const effortMembersApi = require('../api/effort/members/effortMemberRoute')
import teamsApi from '../api/team/teamRoute'

const port = parseInt(process.env.PORT || 3560, 10)

swaggerConfig.host = process.env.HOST_NAME || `localhost:${port}`
swaggerConfig.paths = {
    ...costCalcApi.swaggerPaths,
    ...fullEffortApi.swaggerPaths,
    ...effortAllocationApi.swaggerPaths,
    ...effortEngagementApi.swaggerPaths,
    ...effortMembersApi.swaggerPaths,
    ...teamsApi.swaggerPaths,
    ...GETExportApi.swaggerPaths,
    ...timeFrameApi.swaggerPaths,
    ...spendApi.swaggerPaths
}
swaggerConfig.definitions = {
    ...costCalcApi.swaggerDefinitions,
    ...fullEffortApi.swaggerDefinitions,
    ...effortAllocationApi.swaggerDefinitions,
    ...effortEngagementApi.swaggerDefinitions,
    ...effortMembersApi.swaggerDefinitions,
    ...teamsApi.swaggerDefinitions,
    ...GETExportApi.swaggerDefinitions,
    ...timeFrameApi.swaggerDefinitions,
    ...spendApi.swaggerDefinitions,
}

module.exports = (app, appBaseUrl) =>
    swagger.initializeMiddleware(swaggerConfig, (middleware) => {
        app.use(
            middleware.swaggerUi({
                apiDocs: `${appBaseUrl}/v1/api-docs`,
                swaggerUi: `${appBaseUrl}/v1/docs`
            })
        )
    })
