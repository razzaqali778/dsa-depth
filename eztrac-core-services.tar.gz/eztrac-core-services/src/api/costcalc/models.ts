import {EffortCostingResult} from 'src/util/client/eztracCostingClient';
import {Engagement, EngagementId} from '../effort/engagement/models';
import {CostGroupId, EffortCostBreakdown, PersonId} from '../effort/models';
import {TeamId} from '../team/models';
import {TimeFrameId} from '../timeframe/models';
import {GenericParticipant, Participant} from '../person/models';

export type CostValue = bigint;

export interface EffortCostingDetails {
  teamId: TeamId;
  timeFrameId: TimeFrameId;
  participants: Participant[];
  genericParticipants: GenericParticipant[];
  engagements: Engagement[];
}

export interface CostGroupBreakdown {
  costGroupId: CostGroupId;
  cost: CostValue;
  engagementId?: EngagementId;
  personId?: PersonId;
}

export interface StandardTeamCostingResult {
  costCalcResponse: EffortCostingResult[];
  breakdownRows: EffortCostBreakdown[];
  numAffectedRows: number;
}

export interface CostingServiceAffectedRows {
  timeFrameId: TimeFrameId;
  numAffectedRows?: number;
}
