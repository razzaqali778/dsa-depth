import {EffortCostingDetails, StandardTeamCostingResult} from './models';
import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {TimeFrame, TimeFrameId} from '../timeframe/models';
import {EffortEntity, EffortCostBreakdown} from '../effort/models';
import {EffortCostingResult, batchCallCostingService} from '../../util/client/eztracCostingClient';
import {getFullEffortEntitiesByTimeFrames} from '../effort/effortService';

function parseToCostingServiceRequestBody(efforts: EffortEntity[]): EffortCostingDetails[] {
  return efforts.map(
    effort =>
      ({
        teamId: effort.teamId,
        timeFrameId: effort.timeFrameId,
        participants: effort.members?.map(m => ({userId: m.userId, percent: m.percent})),
        genericParticipants: effort.forecastPeople?.map(fp => ({
          numberOfPeople: fp.numberOfPeople,
          rateId: fp.rateId,
          costGroupId: fp.costGroupId,
        })),
        engagements: effort.engagements?.map(e => ({
          amount: e.amount,
          engagementId: e.engagementId,
          amountDetails: e.amountDetails,
        })),
      } as EffortCostingDetails)
  );
}

const processCostingServiceResponse = (
  costingResults: EffortCostingResult[],
  efforts: EffortEntity[]
): EffortCostBreakdown[] => {
  const effortCostBreakdowns: EffortCostBreakdown[] = [];

  efforts.forEach(effort => {
    const costingResult = costingResults.find(
      r => r.teamId === effort.teamId && r.timeFrameId === effort.timeFrameId
    );
    costingResult?.teamMemberCosts.forEach(cost => {
      effortCostBreakdowns.push({
        effortId: effort.id!,
        costGroupId: cost.costGroupId,
        cost: cost.cost,
        engagementId: cost.engagementId,
        personId: cost.personId,
      });
    });
  });

  return effortCostBreakdowns;
};

const costTimeFrameAllTeams = async (timeFrame: TimeFrame): Promise<StandardTeamCostingResult> => {
  const efforts = await getFullEffortEntitiesByTimeFrames([timeFrame.id]);
  const costingServiceRequest = parseToCostingServiceRequestBody(efforts);
  const costingResponse = await batchCallCostingService(costingServiceRequest);
  const costBreakdowns = processCostingServiceResponse(costingResponse, efforts);
  const rowsAffected = await updateEffortCostBreakdowns(costBreakdowns);
  return {
    costCalcResponse: costingResponse,
    breakdownRows: costBreakdowns,
    numAffectedRows: rowsAffected,
  };
};

const updateEffortCostBreakdowns = async (
  costBreakdowns: EffortCostBreakdown[]
): Promise<number> => {
  const r = container.resolve(AppContext).repositories;
  const costBreakdownsCount = await r.effortRepository.updateEffortCostBreakdowns(costBreakdowns);
  return costBreakdownsCount;
};

export const costAllTeams = async function (): Promise<
  Map<TimeFrameId, StandardTeamCostingResult>
> {
  const result = new Map();
  const r = container.resolve(AppContext).repositories;
  const timeFrames = await r.timeFrameRepository.getNonHistoricTimeFrames();

  // Each time frame's costing run is independent (its own efforts/costing-service call/DB
  // write), so run them concurrently instead of one-at-a-time to cut overall route latency
  // roughly in proportion to the number of time frames being recosted.
  const costingResults = await Promise.all(
    timeFrames.map(async timeFrame => ({
      timeFrameId: timeFrame.id,
      result: await costTimeFrameAllTeams(timeFrame),
    }))
  );

  for (const {timeFrameId, result: costingResult} of costingResults) {
    result.set(timeFrameId, costingResult);
  }
  return result;
};
