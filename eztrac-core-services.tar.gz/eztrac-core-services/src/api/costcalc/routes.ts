import express, {Request, Response} from 'express';
import {CostingServiceAffectedRows, StandardTeamCostingResult} from './models';
import {costAllTeams} from './standardTeamCosting';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {apiResponse} from '../../middleware/apiResponse';
import {TimeFrameId} from '../timeframe/models';
import {entitlements} from '../../config/entitlementsConfig';
const profileMiddleware = require('@monsantoit/profile-middleware');

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.effortWrite,
  methods: ['put'],
});

const router = express.Router();

const doc: SwaggerDoc = {};

const tags = ['cost', 'standard-teams'];

doc['/cost/standard-teams'] = {
  put: {
    tags,
    operationId: 'standard-teams',
    summary: 'standard-teams call',
    responses: {
      200: {description: 'Success'},
    },
  },
};

router.put(
  '/cost/standard-teams',
  entitlementMiddleware,
  apiResponse(async (req: Request, res: Response) => {
    const teams: Map<TimeFrameId, StandardTeamCostingResult> = await costAllTeams();
    const result: CostingServiceAffectedRows[] = [];
    teams.forEach((value, key) => {
      result.push({
        timeFrameId: key,
        numAffectedRows: value.numAffectedRows,
      });
    });
    res.send(result);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
