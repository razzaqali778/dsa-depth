import {CostGroupId, PersonId, RateId} from '../effort/models';

export type ParticipationPct = number;
export type NumberOfPeople = number;

export interface Participant {
  userId: PersonId;
  percent: ParticipationPct;
}

export interface GenericParticipant {
  numberOfPeople: NumberOfPeople;
  rateId: RateId;
  costGroupId: CostGroupId;
}
