import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';

const getSpendParams = Joi.object({
  startTimeFrame: Joi.number().integer().required(),
  endTimeFrame: Joi.number().integer().required(),
});

export interface GetSpendSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    startTimeFrame: bigint;
    endTimeFrame: bigint;
  };
}

export const schema = {
  getSpendParams,
};
