export type InitiativeId = string;
export type AllocationPct = bigint;

export class InitiativeAllocation {
  constructor(public initiativeId: InitiativeId, public percentageOfTeamCost: AllocationPct) {}
}
