import {StatusCodes} from 'http-status-codes';

export class BadRequestError extends Error {
  constructor(public message: string) {
    super();
    this.status = StatusCodes.BAD_REQUEST;
    this.message = message;
  }
}
