import {StatusCodes} from 'http-status-codes';

export class NotFoundError extends Error {
  constructor(public message: string) {
    super();
    this.status = StatusCodes.NOT_FOUND;
    this.message = message;
  }
}
