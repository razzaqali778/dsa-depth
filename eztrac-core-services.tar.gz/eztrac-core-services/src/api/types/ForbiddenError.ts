import {StatusCodes} from 'http-status-codes';

export class ForbiddenError extends Error {
  constructor(public message = 'User is not authorized to perform this operation') {
    super();
    this.status = StatusCodes.FORBIDDEN;
    this.message = message;
  }
}
