import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {Community, CreateCommunityModel, CommunityId} from './models';
import {PlatformId} from '../platform/models';

export interface CommunityRepository {
  getCommunities(isActive?: boolean, platformId?: PlatformId): Promise<Community[]>;
  getCommunityById(id: string): Promise<Community | null>;
  createCommunity(community: CreateCommunityModel, id: CommunityId): Promise<Community>;
  updateCommunity(community: Community): Promise<Community>;
}

function createCommunityFilter(isActive: boolean | undefined, platformId: string | undefined) {
  const hasActiveParameter = typeof isActive !== 'undefined';
  const hasPlatformIdParameter = typeof platformId !== 'undefined';
  const activeFilter = hasActiveParameter ? 'is_active = $<isActive>' : '';
  const platformFilter = hasPlatformIdParameter ? 'platform_id = $<platformId>' : '';

  if (hasActiveParameter && hasPlatformIdParameter) {
    return `WHERE ${activeFilter} AND ${platformFilter}`;
  } else if (hasActiveParameter) {
    return `WHERE ${activeFilter}`;
  } else if (hasPlatformIdParameter) {
    return `WHERE ${platformFilter}`;
  } else {
    return '';
  }
}

export const communityRepository: CommunityRepository = {
  getCommunities(isActive?: boolean, platformId?: PlatformId): Promise<Community[]> {
    const db = container.resolve(AppContext).db;
    const filter = createCommunityFilter(isActive, platformId);
    const sql = `SELECT community_id   as "id",
                        community_name as "name",
                        is_active      as "isActive",
                        platform_id    as "platformId"
                 FROM public.community ${filter}
    `;
    return db.any<Community>(sql, {isActive, platformId});
  },
  getCommunityById(id: string): Promise<Community | null> {
    const db = container.resolve(AppContext).db;
    const sql = `SELECT community_id   as "id",
                        community_name as "name",
                        is_active      as "isActive",
                        platform_id    as "platformId"
                 FROM public.community
                 WHERE community_id = $<id>
    `;
    return db.oneOrNone<Community>(sql, {id});
  },
  createCommunity(community: CreateCommunityModel, id: CommunityId): Promise<Community> {
    const db = container.resolve(AppContext).db;
    const sql = `INSERT INTO public.community (community_id, community_name, is_active, platform_id)
                 VALUES ($<id>, $<community.name>, $<community.isActive>, $<community.platformId>)
                 RETURNING community_id as "id", community_name as "name", is_active as "isActive", platform_id as "platformId"
    `;
    return db.one<Community>(sql, {id, community});
  },
  updateCommunity(community: Community): Promise<Community> {
    const db = container.resolve(AppContext).db;
    const sql = `UPDATE public.community
                 SET community_name = $<name>, is_active = $<isActive>, platform_id = $<platformId>
                 WHERE community_id = $<id>
                 RETURNING community_id as "id", community_name as "name", is_active as "isActive", platform_id as "platformId"
    `;
    return db.one<Community>(sql, community);
  },
};
