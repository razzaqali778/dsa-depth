import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {PlatformId} from '../platform/models';
import {Community, CommunityId, CreateCommunityModel} from './models';
import {NotFoundError} from '../types/NotFoundError';
import {NameToId} from '../../util/nameToId';
import {BadRequestError} from '../types/BadRequestError';
import {getPlatformByIdOrThrow} from '../platform/platformService';

const getCommunityByIdOrThrow = async function (communityId: CommunityId): Promise<Community> {
  const r = container.resolve(AppContext).repositories;
  const community = await r.communityRepository.getCommunityById(communityId);
  if (!community) {
    throw new NotFoundError(`Unable to find community with id of ${community}`);
  }
  return community;
};

export const getCommunities = function (
  isActive?: boolean,
  platformId?: PlatformId
): Promise<Community[]> {
  const r = container.resolve(AppContext).repositories;
  return r.communityRepository.getCommunities(isActive, platformId);
};

export const createCommunity = async function (
  community: CreateCommunityModel
): Promise<Community> {
  const id = NameToId(community.name);
  if (id === '') {
    throw new BadRequestError('Invalid community name was provided');
  }
  const r = container.resolve(AppContext).repositories;
  const communityExists = await r.communityRepository.getCommunityById(id);
  await getPlatformByIdOrThrow(community.platformId);
  if (communityExists) {
    throw new BadRequestError('Community with given name already exists');
  }
  return r.communityRepository.createCommunity(community, id);
};

export const updateCommunity = async function (community: Community): Promise<Community> {
  const r = container.resolve(AppContext).repositories;
  await getCommunityByIdOrThrow(community.id);
  await getPlatformByIdOrThrow(community.platformId);
  return r.communityRepository.updateCommunity(community);
};
