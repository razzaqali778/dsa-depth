import {TeamId} from '../team/models';

export type CommunityId = string;
export type CommunityName = string;

export interface Community {
  id: CommunityId;
  name: CommunityName;
  isActive: boolean;
  platformId: TeamId;
}

export interface CreateCommunityModel {
  name: CommunityName;
  isActive: boolean;
  platformId: TeamId;
}
