import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';
import Joi from 'joi';

const getCommunitiesQuery = Joi.object({
  platformId: Joi.string().allow(''),
  isActive: Joi.boolean(),
});

const createCommunityBody = Joi.object({
  name: Joi.string().required(),
  platformId: Joi.string().required(),
  isActive: Joi.boolean().required(),
});

const updateCommunityBody = Joi.object({
  name: Joi.string().required(),
  platformId: Joi.string().required(),
  isActive: Joi.boolean().required(),
});

export interface GetCommunitiesSchema extends ValidatedRequestSchema {
  [ContainerTypes.Query]: {
    platformId?: string;
    isActive?: boolean;
  };
}

export interface CreateCommunitySchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    name: string;
    platformId: string;
    isActive: boolean;
  };
}

export interface UpdateCommunitySchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    communityId: string;
  };
  [ContainerTypes.Body]: {
    name: string;
    platformId: string;
    isActive: boolean;
  };
}

export const schema = {
  getCommunitiesQuery,
  createCommunityBody,
  updateCommunityBody,
};
