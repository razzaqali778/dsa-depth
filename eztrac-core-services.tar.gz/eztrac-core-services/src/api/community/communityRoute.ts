import express, {Response} from 'express';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {apiResponse} from '../../middleware/apiResponse';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {entitlements} from '../../config/entitlementsConfig';
import {
  CreateCommunitySchema,
  GetCommunitiesSchema,
  schema,
  UpdateCommunitySchema,
} from './validationSchema';
import {createCommunity, getCommunities, updateCommunity} from './communityService';
const profileMiddleware = require('@monsantoit/profile-middleware');

const router = express.Router();
const validator = createValidator();

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.adminOnly,
  methods: ['post', 'put'],
});

const doc: SwaggerDoc = {};

const tags = ['community'];

doc['/communities'] = {
  get: {
    tags,
    operationId: 'communities',
    parameters: [
      {
        name: 'isActive',
        in: 'query',
        description: 'Selects active or inactive communities.',
        required: false,
        type: 'boolean',
      },
      {
        name: 'platformId',
        in: 'query',
        description: 'Id of the platform',
        required: false,
        type: 'boolean',
      },
    ],
    summary: 'communities call',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
    },
  },
  post: {
    tags,
    operationId: 'createCommunity',
    parameters: [
      {
        name: 'body',
        in: 'body',
        description: 'Community to create',
        required: true,
        type: 'object',
      },
    ],
    summary: 'Create a new community',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      404: {description: 'Platform Not found'},
    },
  },
  put: {
    tags,
    operationId: 'updateCommunity',
    parameters: [
      {
        name: 'communityId',
        in: 'path',
        description: 'Id of the community to update',
        required: true,
        type: 'string',
      },
      {
        name: 'body',
        in: 'body',
        description: 'Community data to update',
        required: true,
        type: 'object',
      },
    ],
    summary: 'Update an existing community',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      404: {description: 'Platform Not found'},
    },
  },
};

router.get(
  '/communities',
  entitlementMiddleware,
  validator.query(schema.getCommunitiesQuery),
  apiResponse(async (req: ValidatedRequest<GetCommunitiesSchema>, res: Response) => {
    const {isActive, platformId} = req.query;
    const result = await getCommunities(isActive, platformId);
    res.send(result);
  })
);

router.post(
  '/communities',
  entitlementMiddleware,
  validator.body(schema.createCommunityBody),
  apiResponse(async (req: ValidatedRequest<CreateCommunitySchema>, res: Response) => {
    const result = await createCommunity(req.body);
    res.send(result);
  })
);

router.put(
  '/communities/:communityId',
  entitlementMiddleware,
  validator.body(schema.updateCommunityBody),
  apiResponse(async (req: ValidatedRequest<UpdateCommunitySchema>, res: Response) => {
    const {communityId} = req.params;
    const result = await updateCommunity({...req.body, id: communityId});
    res.send(result);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
