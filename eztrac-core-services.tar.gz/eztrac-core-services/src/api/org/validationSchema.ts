import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';

const getOrgsQuery = Joi.object({
  isActive: Joi.boolean(),
});

export interface GetOrgsSchema extends ValidatedRequestSchema {
  [ContainerTypes.Query]: {
    isActive?: boolean;
  };
}

export const schema = {
  getOrgsQuery,
};
