import express, {Response} from 'express';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {apiResponse} from '../../middleware/apiResponse';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {getOrgs} from './orgService';
import {schema, GetOrgsSchema} from './validationSchema';

const router = express.Router();
const validator = createValidator();

const doc: SwaggerDoc = {};

const tags = ['orgs'];

doc['/orgs'] = {
  get: {
    tags,
    operationId: 'orgs',
    parameters: [
      {
        name: 'isActive',
        in: 'query',
        description: 'Selects active or inactive orgs.',
        required: false,
        type: 'boolean',
      },
    ],
    summary: 'orgs call',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
    },
  },
};

router.get(
  '/orgs',
  validator.query(schema.getOrgsQuery),
  apiResponse(async (req: ValidatedRequest<GetOrgsSchema>, res: Response) => {
    const {isActive} = req.query;
    const result = await getOrgs(isActive);
    res.send(result);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
