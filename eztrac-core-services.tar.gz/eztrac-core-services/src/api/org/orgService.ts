import {Org, OrgId} from './models';
import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {NotFoundError} from '../types/NotFoundError';

export const getOrgByIdOrThrow = async function (orgId: OrgId): Promise<Org> {
  const r = container.resolve(AppContext).repositories;
  const org = await r.orgRepository.getOrgById(orgId);
  if (!org) {
    throw new NotFoundError(`Unable to find org with id of ${orgId}`);
  }
  return org;
};

export const getOrgs = function (isActive?: boolean): Promise<Org[]> {
  const r = container.resolve(AppContext).repositories;
  return r.orgRepository.getOrgs(isActive);
};
