import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {Org, OrgId} from './models';

export interface OrgRepository {
  getOrgs(isActive?: boolean): Promise<Org[]>;
  getOrgById(id: OrgId): Promise<Org | null>;
}

function createOrgFilter(isActive: boolean | undefined) {
  return typeof isActive !== 'undefined' ? 'WHERE is_active =$<isActive>' : '';
}

const orgSelectQuery = `SELECT org_id    as "id",
                               org_name  as "name",
                               is_active as "isActive"
                        FROM public.org`;

export const orgRepository: OrgRepository = {
  getOrgs(isActive?: boolean): Promise<Org[]> {
    const db = container.resolve(AppContext).db;
    const filter = createOrgFilter(isActive);
    const sql = `${orgSelectQuery} ${filter}
    `;
    return db.any<Org>(sql, {isActive});
  },
  getOrgById(id: OrgId): Promise<Org | null> {
    const db = container.resolve(AppContext).db;

    const sql = `${orgSelectQuery}
           WHERE org_id = $<id>`;
    return db.oneOrNone<Org>(sql, {id});
  },
};
