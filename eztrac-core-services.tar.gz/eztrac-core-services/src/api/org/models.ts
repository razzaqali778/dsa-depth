export type OrgId = string;
export type OrgName = string;

export interface Org {
  id: OrgId;
  name: OrgName;
  isActive: boolean;
}
