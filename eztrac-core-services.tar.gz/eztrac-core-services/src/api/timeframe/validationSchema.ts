import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';
import {TimeFrameId} from './models';

const withOffsetParams = Joi.object({
  offset: Joi.number().integer().required(),
});

const byIdParams = Joi.object({
  timeFrameId: Joi.number().integer().required(),
});

const setLockdownStatusBody = Joi.object({
  lockdown: Joi.boolean().required(),
});

export interface CurrentTimeFrameWithOffsetSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    offset: number;
  };
}

export interface TimeFrameByIdSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
  };
}

export interface SetLockdownStatusSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    lockdown: boolean;
  };
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
  };
}

export const schema = {
  withOffsetParams,
  byIdParams,
  setLockdownStatusBody,
};
