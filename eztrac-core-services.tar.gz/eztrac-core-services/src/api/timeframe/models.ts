export type TimeFrameId = bigint;
export type TimeFrameName = string;

export interface TimeFrame {
  id: TimeFrameId;
  name: TimeFrameName;
  startDate: Date | string;
  endDate: Date | string;
  lockdown: boolean;
  isActive: boolean;
}

export interface Workday {
  date: Date;
  hours: number;
}
