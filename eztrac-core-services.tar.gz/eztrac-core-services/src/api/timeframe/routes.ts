import {Request, Response} from 'express';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {
  getCurrentTimeFrameWithOffset,
  getTimeFrameById,
  getTimeFrames,
  setTimeFrameLockdownStatus,
} from './timeFrameService';
import {apiResponse} from '../../middleware/apiResponse';
import {ValidatedRequest, createValidator} from 'express-joi-validation';
import {
  CurrentTimeFrameWithOffsetSchema,
  schema,
  SetLockdownStatusSchema,
  TimeFrameByIdSchema,
} from './validationSchema';
import {StatusCodes} from 'http-status-codes';
import {entitlements} from '../../config/entitlementsConfig';
const profileMiddleware = require('@monsantoit/profile-middleware');

const router = require('express').Router();
const validator = createValidator();

const doc: SwaggerDoc = {};

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.adminOnly,
  methods: ['patch'],
});

const tags = ['timeframe'];

doc['/timeframes'] = {
  get: {
    tags,
    operationId: 'getTimeFrames',
    summary: 'Get all time frames',
    responses: {
      200: {description: 'Success'},
    },
  },
};

router.get(
  '/timeframes',
  apiResponse(async (_: Request, res: Response) => {
    const result = await getTimeFrames();
    res.send(result);
  })
);

doc['/timeframes/current'] = {
  get: {
    tags,
    operationId: 'getCurrentTimeFrame',
    summary: 'Get current time frame',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
    },
  },
};

router.get(
  '/timeframes/current',
  apiResponse(async (_: Request, res: Response) => {
    const result = await getCurrentTimeFrameWithOffset();
    res.send(result);
  })
);

doc['/timeframes/current/offset/{offset}'] = {
  get: {
    tags,
    operationId: 'getTimeFramesWithOffset',
    parameters: [
      {
        name: 'offset',
        in: 'path',
        description: 'month offset',
        required: true,
        type: 'integer',
      },
    ],
    summary: 'Get current time frame with offset',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      404: {description: 'Not found'},
    },
  },
};

router.get(
  '/timeframes/current/offset/:offset',
  validator.params(schema.withOffsetParams),
  apiResponse(async (req: ValidatedRequest<CurrentTimeFrameWithOffsetSchema>, res: Response) => {
    const result = await getCurrentTimeFrameWithOffset(req.params.offset);
    res.send(result);
  })
);

doc['/timeframes/{timeFrameId}'] = {
  get: {
    tags,
    operationId: 'getTimeFramesById',
    parameters: [
      {
        name: 'timeFrameId',
        in: 'path',
        description: 'time frame id',
        required: true,
        type: 'integer',
      },
    ],
    summary: 'Get time frame by id',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      404: {description: 'Not found'},
    },
  },
  patch: {
    tags,
    operationId: 'setLockdownStatus',
    parameters: [
      {
        name: 'timeFrameId',
        in: 'path',
        description: 'time frame id',
        required: true,
        type: 'integer',
      },
    ],
    summary: 'Set time frame lockdown status',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      404: {description: 'Not found'},
    },
  },
};

router.get(
  '/timeframes/:timeFrameId',
  validator.params(schema.byIdParams),
  apiResponse(async (req: ValidatedRequest<TimeFrameByIdSchema>, res: Response) => {
    const result = await getTimeFrameById(req.params.timeFrameId);
    res.send(result);
  })
);

router.patch(
  '/timeframes/:timeFrameId',
  entitlementMiddleware,
  validator.params(schema.byIdParams),
  validator.body(schema.setLockdownStatusBody),
  apiResponse(async (req: ValidatedRequest<SetLockdownStatusSchema>, res: Response) => {
    await setTimeFrameLockdownStatus(req.params.timeFrameId, req.body.lockdown);
    res.sendStatus(StatusCodes.OK);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
