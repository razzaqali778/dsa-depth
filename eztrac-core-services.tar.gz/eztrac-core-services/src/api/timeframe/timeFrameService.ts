import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {NotFoundError} from '../types/NotFoundError';
import {TimeFrame, TimeFrameId} from './models';
import {throwNotFoundError} from '../effort/utils';
import {BadRequestError} from '../types/BadRequestError';

export function getTimeFrames(): Promise<TimeFrame[]> {
  const r = container.resolve(AppContext).repositories;
  return r.timeFrameRepository.getTimeFrames();
}

export async function getTimeFrameById(timeFrameId: TimeFrameId): Promise<TimeFrame> {
  const r = container.resolve(AppContext).repositories;
  const timeFrame = await r.timeFrameRepository.getTimeFrameById(timeFrameId);
  if (!timeFrame) {
    throw new NotFoundError(`Unable to find time frame with id ${timeFrameId}`);
  }
  return timeFrame;
}

export async function getCurrentTimeFrameWithOffset(offset = 0): Promise<TimeFrame> {
  const r = container.resolve(AppContext).repositories;
  const timeFrame = await r.timeFrameRepository.getCurrentTimeFrameWithOffset(offset);
  if (!timeFrame) {
    throw new NotFoundError(`Unable to find time frame at given offset ${offset}`);
  }
  return timeFrame;
}

export async function setTimeFrameLockdownStatus(
  timeFrameId: TimeFrameId,
  lockdownStatus: boolean
) {
  const r = container.resolve(AppContext).repositories;
  const timeFrame = await r.timeFrameRepository.getTimeFrameById(timeFrameId);
  if (!timeFrame) {
    throw new NotFoundError(`Unable to find time frame with id ${timeFrameId}`);
  }
  return r.timeFrameRepository.setTimeFrameLockdownStatus(timeFrameId, lockdownStatus);
}

export async function validateTimeFrameRange(
  startTimeFrameId: TimeFrameId,
  endTimeFrameId: TimeFrameId
) {
  const r = container.resolve(AppContext).repositories;
  const startTimeFrame = await r.timeFrameRepository.getTimeFrameById(startTimeFrameId);
  if (!startTimeFrame) throwNotFoundError('time frame', startTimeFrameId);
  if (startTimeFrameId === endTimeFrameId) return;
  const endOfStartTimeFrame = new Date(startTimeFrame?.endDate ?? '');

  const endTimeFrame = await r.timeFrameRepository.getTimeFrameById(endTimeFrameId);
  if (!endTimeFrame) throwNotFoundError('time frame', endTimeFrameId);
  const startOfEndTimeFrame = new Date(endTimeFrame?.startDate ?? '');

  if (endOfStartTimeFrame > startOfEndTimeFrame)
    throw new BadRequestError('start time frame must be before end time frame');
}
