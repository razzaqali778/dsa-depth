import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {TimeFrame, TimeFrameId, Workday} from './models';

const timeFrameQuery = `SELECT timeframe_id         as "id",
                               timeframe_name       as "name",
                               timeframe_start_date as "startDate",
                               timeframe_end_date   as "endDate",
                               lockdown             as "lockdown",
                               is_active            as "isActive"
                        FROM public.timeframe`;

export interface TimeframeRepository {
  getTimeFrames(): Promise<TimeFrame[]>;
  getCurrentTimeFrameWithOffset(offset: number): Promise<TimeFrame | null>;
  getNonHistoricTimeFrames(): Promise<TimeFrame[]>;
  getTimeFrameIdsInRange(
    startTimeFrameId: TimeFrameId,
    endTimeFrameId: TimeFrameId
  ): Promise<TimeFrameId[]>;
  getTimeFrameById(timeFrameId: TimeFrameId): Promise<TimeFrame | null>;
  getTimeFramesByIds(timeFrameIds: TimeFrameId[]): Promise<TimeFrame[] | null>;
  getWorkdaysByTimeFrameIdAndCountry(
    timeFrameId: TimeFrameId,
    country?: string
  ): Promise<Workday[]>;
  setTimeFrameLockdownStatus(timeFrameId: TimeFrameId, lockdownStatus: boolean): void;
  getTimeFrameAndAllFutureTimeFrameIds(timeFrameId: TimeFrameId): Promise<TimeFrameId[]>;
}

export const timeFrameRepository: TimeframeRepository = {
  getTimeFrames(): Promise<TimeFrame[]> {
    const db = container.resolve(AppContext).db;
    return db.any<TimeFrame>(`${timeFrameQuery} ORDER BY timeframe_start_date`);
  },
  getCurrentTimeFrameWithOffset(offset: number): Promise<TimeFrame | null> {
    const db = container.resolve(AppContext).db;
    const currentDateWithOffset = new Date();
    currentDateWithOffset.setDate(2);
    currentDateWithOffset.setMonth(currentDateWithOffset.getMonth() + offset);
    const sql = `${timeFrameQuery}
                WHERE timeframe_start_date < $<currentDateWithOffset> AND timeframe_end_date > $<currentDateWithOffset>
                ORDER BY timeframe_start_date`;
    return db.oneOrNone<TimeFrame>(sql, {currentDateWithOffset});
  },
  getNonHistoricTimeFrames(): Promise<TimeFrame[]> {
    const db = container.resolve(AppContext).db;

    const currentDate = new Date();
    const sql = `
        ${timeFrameQuery}
        WHERE timeframe_end_date > $<currentDate>
        ORDER BY timeframe_start_date
    `;
    return db.any<TimeFrame>(sql, {currentDate});
  },
  getTimeFrameIdsInRange(
    startTimeFrameId: TimeFrameId,
    endTimeFrameId: TimeFrameId
  ): Promise<TimeFrameId[]> {
    const db = container.resolve(AppContext).db;
    const sql = `
            SELECT timeframe_id as "id"
            FROM public.timeframe
            WHERE timeframe_start_date >=
                  (SELECT timeframe_start_date as "startDate" FROM public.timeframe WHERE timeframe_id = $<startTimeFrameId>)
              and timeframe_end_date <=
                (SELECT timeframe_end_date as "endDate" FROM public.timeframe WHERE timeframe_id = $<endTimeFrameId>)
            ORDER BY timeframe_start_date
        `;
    return db
      .any(sql, {startTimeFrameId, endTimeFrameId})
      .then(timeFrameIds => timeFrameIds.map(ids => ids.id as TimeFrameId));
  },
  getTimeFrameById(timeFrameId: TimeFrameId): Promise<TimeFrame | null> {
    const db = container.resolve(AppContext).db;
    const sql = `
            ${timeFrameQuery}
            WHERE timeframe_id = $<timeFrameId>`;
    return db.oneOrNone<TimeFrame>(sql, {timeFrameId});
  },
  getTimeFramesByIds(timeFrameIds: TimeFrameId[]): Promise<TimeFrame[] | null> {
    const db = container.resolve(AppContext).db;
    const sql = `
            ${timeFrameQuery}
            WHERE timeframe_id in ($1:csv)`;
    return db.any<TimeFrame>(sql, [timeFrameIds]);
  },
  getWorkdaysByTimeFrameIdAndCountry(timeFrameId, country = 'US') {
    const db = container.resolve(AppContext).db;
    const sql = `
            SELECT workday_hours as "workdayHours"
            FROM public.timeframe_workdays
            WHERE timeframe_id = $<timeFrameId> AND country = $<country>`;
    return db.oneOrNone(sql, {timeFrameId, country}).then(workdayRow => {
      // No workdays configured for this time frame/country is a valid state (e.g. new time
      // frames, uncommon countries), not an error - callers (e.g. GET export) already treat an
      // empty workday list as "nothing to allocate". Previously this dereferenced
      // `workdayRow.workdayHours` on a null row and crashed with a TypeError.
      if (!workdayRow) return [];

      return JSON.parse(workdayRow.workdayHours).map((workday: {day: string; hours: number}) => {
        const date = new Date(workday.day);
        date.setUTCHours(12);
        return {date: date, hours: workday.hours} as Workday;
      });
    });
  },
  setTimeFrameLockdownStatus(timeFrameId: TimeFrameId, lockdownStatus: boolean) {
    const db = container.resolve(AppContext).db;
    const sql = `UPDATE public.timeframe
                 SET lockdown = $<lockdownStatus>
                 WHERE timeframe_id = $<timeFrameId>`;
    return db.none(sql, {timeFrameId, lockdownStatus});
  },
  getTimeFrameAndAllFutureTimeFrameIds(timeFrameId) {
    const db = container.resolve(AppContext).db;
    const sql = `
      SELECT timeframe.timeframe_id as "id" FROM public.timeframe
      JOIN public.timeframe as startTimeFrame
        ON startTimeFrame.timeframe_id = $<timeFrameId>
      WHERE timeframe.timeframe_start_date >= startTimeFrame.timeframe_start_date`;
    return db
      .manyOrNone(sql, {timeFrameId})
      .then(timeFrameIds => timeFrameIds.map(ids => ids.id as TimeFrameId));
  },
};
