import express, {Response} from 'express';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {apiResponse} from '../../middleware/apiResponse';
import {getHealthCheck} from './healthCheckEffortsService';
import {ValidatedRequest, createValidator} from 'express-joi-validation';
import {HealthCheckSchema, schema} from './validationSchema';
import {entitlements} from '../../config/entitlementsConfig';
const profileMiddleware = require('@monsantoit/profile-middleware');

const router = express.Router();
const validator = createValidator();

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.adminOnly,
  methods: ['get'],
});

const doc: SwaggerDoc = {};

const tags = ['healthCheck'];

doc['healthCheck/efforts/timeFrameId'] = {
  get: {
    tags,
    operationId: 'healthCheck',
    parameters: [
      {
        name: 'timeFrameId',
        in: 'query',
        description: 'time frame id',
        required: false,
        type: 'string',
      },
    ],
    summary: 'get health check by time frame id',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      404: {description: 'Not found'},
    },
  },
};

router.get(
  '/healthCheck/efforts/timeFrameId/:timeFrameId',
  entitlementMiddleware,
  validator.params(schema.getByTimeFrameId),
  apiResponse(async (req: ValidatedRequest<HealthCheckSchema>, res: Response) => {
    const timeFrameId = req.params.timeFrameId;
    const result = await getHealthCheck(timeFrameId);
    res.send(result);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
