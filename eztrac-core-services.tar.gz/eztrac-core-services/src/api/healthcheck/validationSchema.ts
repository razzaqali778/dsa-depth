import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';

const getByTimeFrameId = Joi.object({
  timeFrameId: Joi.number().integer().required(),
});

export interface HealthCheckSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: bigint;
  };
}

export const schema = {
  getByTimeFrameId,
};
