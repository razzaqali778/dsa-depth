import {HealthCheck} from './models';
import {checkEffortsInternal, generateAllInitiatives} from './effortHealthCheck';
import {TimeFrameId} from '../timeframe/models';
import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {NotFoundError} from '../types/NotFoundError';
import {getFullEffortEntitiesByTimeFrames} from '../effort/effortService';

export const getHealthCheck = async function (timeFrameId: TimeFrameId): Promise<HealthCheck[]> {
  return checkEfforts(timeFrameId);
};

const checkEfforts = async function (timeFrameId: TimeFrameId): Promise<HealthCheck[]> {
  const r = container.resolve(AppContext).repositories;
  const timeFrame = await r.timeFrameRepository.getTimeFrameById(timeFrameId);

  if (!timeFrame) {
    throw new NotFoundError(`Unable to find time frame with id of ${timeFrameId}`);
  }
  const teams = await r.teamRepository.getTeamsWithStructureByTimeFrameId(timeFrameId);
  const allInitiatives = await generateAllInitiatives();
  let result: HealthCheck[] = [];

  if (teams && teams.length) {
    // Fetch every team's effort for this time frame in a single batched call instead of
    // issuing one round-trip per team (previously N+1 sequential DB calls for N teams).
    const teamIds = new Set(teams.map(team => team.teamId));
    const effortEntities = (await getFullEffortEntitiesByTimeFrames([timeFrameId])).filter(entity =>
      teamIds.has(entity.teamId)
    );
    result = await checkEffortsInternal(timeFrame, teams, allInitiatives, effortEntities);
  }

  return result;
};
