import {TimeFrameName} from '../timeframe/models';
import {TeamId, TeamName} from '../team/models';
import {PlatformName} from '../platform/models';
import {CommunityName} from '../community/models';

export interface HealthCheck {
  timeFrameName: TimeFrameName;
  teamName: TeamName;
  teamId: TeamId;
  communityName: CommunityName;
  platformName: PlatformName;
  errors: String[];
}
