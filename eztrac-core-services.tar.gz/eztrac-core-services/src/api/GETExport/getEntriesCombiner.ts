import _ from 'lodash';
import {FullGetEntry} from './models';
import {roundToDecimal} from './personToInitiativeMapper';

export function combineGETEntries(GETEntries: FullGetEntry[]) {
  return _.chain(GETEntries)
    .groupBy(entry => `${entry.person.id}&${entry.date.getTime()}&${entry.initiative.activityId}`)
    .map(group => {
      if (group.length === 1) {
        return group[0];
      }
      const sorted = _.sortBy(group, item => -item.hours);
      const hoursSum = sorted.reduce((sum, current) => sum + current.hours, 0);
      sorted[0].hours = roundToDecimal(hoursSum);
      return sorted[0];
    })
    .sortBy(entry => [entry.person.id, entry.date.getTime()])
    .value();
}
