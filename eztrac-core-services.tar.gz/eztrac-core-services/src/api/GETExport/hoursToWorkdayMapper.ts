import _ from 'lodash';
import {Workday} from '../timeframe/models';
import {FullGetEntry, PersonAllocation} from './models';
import {roundToDecimal} from './personToInitiativeMapper';

function mapPersonAllocationToWorkday(personAllocation: PersonAllocation[], workdays: Workday[]) {
  const getEntries: FullGetEntry[] = [];
  while (personAllocation.length !== 0 && workdays.length !== 0) {
    const pHours = personAllocation[0];
    const wHours = workdays[0];
    let hoursToAllocate = 0;
    if (pHours.hours > wHours.hours) {
      hoursToAllocate = wHours.hours;
      pHours.hours -= wHours.hours;
      workdays.shift();
    } else if (pHours.hours < wHours.hours) {
      hoursToAllocate = pHours.hours;
      wHours.hours -= pHours.hours;
      personAllocation.shift();
    } else {
      hoursToAllocate = pHours.hours;
      personAllocation.shift();
      workdays.shift();
    }
    getEntries.push({
      ...pHours,
      date: wHours.date,
      hours: roundToDecimal(hoursToAllocate),
    });
  }
  return getEntries;
}

export function mapHoursToWorkdays(personHours: PersonAllocation[], workdays: Workday[]) {
  return _.chain(personHours)
    .sortBy(h => h.initiative.activityId)
    .groupBy(h => h.person.id)
    .map(group => mapPersonAllocationToWorkday(_.cloneDeep(group), _.cloneDeep(workdays)))
    .flatMap()
    .value();
}
