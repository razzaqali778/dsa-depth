import express, {Response} from 'express';
import {GETExport} from './GETExportService';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {apiResponse} from '../../middleware/apiResponse';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {
  GetByAllSchema,
  GetByCommunitySchema,
  GetByPlatformSchema,
  GetByTeamIdsSchema,
  schema,
} from './validationSchema';
import {entitlements} from '../../config/entitlementsConfig';
const profileMiddleware = require('@monsantoit/profile-middleware');

const router = express.Router();
const validator = createValidator();

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.adminOnly,
  methods: ['get'],
});

const doc: SwaggerDoc = {};

const tags = ['getExport'];

doc['/getExport/timeFrameId/:timeFrameId/communityId/:communityId'] = {
  get: {
    tags,
    operationId: 'GETExportByCommunityId',
    summary: 'generate GET export by community id',
    responses: {
      200: {description: 'Success'},
    },
  },
};

router.get(
  '/getExport/timeFrameId/:timeFrameId/communityId/:communityId',
  entitlementMiddleware,
  validator.params(schema.getByCommunityId),
  validator.query(schema.countryCodeQuery),
  apiResponse(async (req: ValidatedRequest<GetByCommunitySchema>, res: Response) => {
    const {communityId, timeFrameId} = req.params;
    const {countryCode} = req.query;
    const result = await GETExport.byCommunityId(communityId, timeFrameId, countryCode);
    res.send(result);
  })
);

doc['/getExport/timeFrameId/:timeFrameId/platformId/:platformId'] = {
  get: {
    tags,
    operationId: 'GETExportByPlatformId',
    summary: 'generate GET export by platform id',
    responses: {
      200: {description: 'Success'},
    },
  },
};

router.get(
  '/getExport/timeFrameId/:timeFrameId/platformId/:platformId',
  entitlementMiddleware,
  validator.params(schema.getByPlatformId),
  validator.query(schema.countryCodeQuery),
  apiResponse(async (req: ValidatedRequest<GetByPlatformSchema>, res: Response) => {
    const {platformId, timeFrameId} = req.params;
    const {countryCode} = req.query;
    const result = await GETExport.byPlatformId(platformId, timeFrameId, countryCode);
    res.send(result);
  })
);

doc['/getExport/timeFrameId/:timeFrameId/teams?teamId=:teamId1$teamId=:teamId2'] = {
  get: {
    tags,
    operationId: 'GETExportByTeamIds',
    summary: 'generate GET export by team ids',
    responses: {
      200: {description: 'Success'},
    },
  },
};

router.get(
  '/getExport/timeFrameId/:timeFrameId/teams',
  entitlementMiddleware,
  validator.params(schema.getByTimeFrameId),
  validator.query(schema.getByTeamIds),
  apiResponse(async (req: ValidatedRequest<GetByTeamIdsSchema>, res: Response) => {
    const {timeFrameId} = req.params;
    const {teamId: teamIds, countryCode} = req.query;
    const result = await GETExport.byTeams(
      Array.isArray(teamIds) ? teamIds : [teamIds],
      timeFrameId,
      countryCode
    );
    res.send(result);
  })
);

doc['/getExport/timeFrameId/:timeFrameId/all'] = {
  get: {
    tags,
    operationId: 'GETExportForTimeFrame',
    summary: 'generate GET export for time frame',
    responses: {
      200: {description: 'Success'},
    },
  },
};

router.get(
  '/getExport/timeFrameId/:timeFrameId/all',
  entitlementMiddleware,
  validator.params(schema.getByTimeFrameId),
  validator.query(schema.countryCodeQuery),
  apiResponse(async (req: ValidatedRequest<GetByAllSchema>, res: Response) => {
    const {timeFrameId} = req.params;
    const {countryCode} = req.query;
    const result = await GETExport.all(timeFrameId, countryCode);
    res.send(result);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
