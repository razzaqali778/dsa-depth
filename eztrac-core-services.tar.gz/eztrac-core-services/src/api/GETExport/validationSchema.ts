import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';
import {convertToBigint} from '../../util/typeConverter';
import {TimeFrameId} from '../timeframe/models';

const getByTimeFrameId = Joi.object({
  timeFrameId: Joi.string().required().custom(convertToBigint),
});

const getByCommunityId = Joi.object({
  timeFrameId: Joi.string().required().custom(convertToBigint),
  communityId: Joi.string().required(),
});

const getByPlatformId = Joi.object({
  timeFrameId: Joi.string().required().custom(convertToBigint),
  platformId: Joi.string().required(),
});

const getByTeamIds = Joi.object({
  teamId: [Joi.string(), Joi.array().min(1).items(Joi.string())],
  countryCode: Joi.string(),
});

const countryCodeQuery = Joi.object({
  countryCode: Joi.string(),
});

export interface GetByTeamIdsSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
  };
  [ContainerTypes.Query]: {
    teamId: string | string[];
    countryCode: string;
  };
}

export interface GetByAllSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
  };
  [ContainerTypes.Query]: {
    countryCode: string;
  };
}

export interface GetByPlatformSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
    platformId: string;
  };
  [ContainerTypes.Query]: {
    countryCode: string;
  };
}

export interface GetByCommunitySchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
    communityId: string;
  };
  [ContainerTypes.Query]: {
    countryCode: string;
  };
}

export const schema = {
  getByCommunityId,
  getByPlatformId,
  getByTimeFrameId,
  getByTeamIds,
  countryCodeQuery,
};
