import {PersonCostingData} from 'src/util/client/eztracCostingClient';
import {Initiative} from 'src/util/client/eztracVipClient';
import {User} from 'src/util/client/papiClient';
import {TeamStructure} from '../team/models';

export interface PersonAllocation {
  hours: number;
  person: User;
  initiative: Initiative;
  team: TeamStructure;
  costingData: PersonCostingData;
}

export interface FullGetEntry {
  date: Date;
  hours: number;
  person: User;
  initiative: Initiative;
  team: TeamStructure;
  costingData: PersonCostingData;
}
