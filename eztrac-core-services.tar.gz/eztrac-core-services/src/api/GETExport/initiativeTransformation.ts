import {Initiative} from 'src/util/client/eztracVipClient';

function transformInitiatives(
  initiatives: Initiative[],
  fundingInitiative?: Initiative,
  inheritedActivityId?: string,
  inheritedStatus?: string
): Initiative[] {
  const transformed = initiatives.map(initiative => {
    const newFundingInitiative = initiative.financeCode ? initiative : fundingInitiative;
    const newActivityId = initiative.activityId ?? inheritedActivityId;
    const newStatus = initiative.status ?? inheritedStatus;
    const initiativeWithInherited: Initiative = {
      id: initiative.id,
      name: initiative.name,
      typeId: initiative.typeId,
      activityId: newActivityId,
      financeCode: newFundingInitiative?.financeCode,
      fundingInitiative: newFundingInitiative,
      status: newStatus,
      children: transformInitiatives(
        initiative.children ?? [],
        newFundingInitiative,
        newActivityId,
        newStatus
      ),
    };
    return initiativeWithInherited;
  });
  return transformed;
}

function flattenToMap(arr: Initiative[], map?: Map<string, Initiative>) {
  if (map === undefined) {
    map = new Map();
  }
  arr.forEach(item => {
    const {children, ...rest} = item;
    let fundingInitiative;
    if (rest.fundingInitiative) {
      const {children: _children, ...restOfFundingInitiative} = rest.fundingInitiative;
      fundingInitiative = restOfFundingInitiative;
    }
    const initiative = {
      ...rest,
      fundingInitiative: fundingInitiative,
    };
    if (map) {
      map.set(item.id, initiative);
    }
    if (children) {
      flattenToMap(children, map);
    }
  });
  return map;
}

export function transformAndFlatten(initiatives: Initiative[]): Map<string, Initiative> {
  const transformed = transformInitiatives(initiatives);
  return flattenToMap(transformed);
}
