import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {generateFullGetEntries} from './fullGetEntriesGenerator';
import {TeamId} from 'src/api/team/models';
import {TimeFrameId} from '../timeframe/models';
import {FullGetEntry} from './models';
import {PlatformId} from '../platform/models';
import {CommunityId} from '../community/models';

export const GETExport = {
  async byCommunityId(
    communityId: CommunityId,
    timeFrameId: TimeFrameId,
    countryCode?: string
  ): Promise<FullGetEntry[]> {
    const r = container.resolve(AppContext).repositories;

    const teams = await r.teamRepository.getTeamsWithStructureByCommunityId(communityId);

    return await generateFullGetEntries(teams, timeFrameId, countryCode);
  },
  async byPlatformId(
    platformId: PlatformId,
    timeFrameId: TimeFrameId,
    countryCode?: string
  ): Promise<FullGetEntry[]> {
    const r = container.resolve(AppContext).repositories;

    const teams = await r.teamRepository.getTeamsWithStructureByPlatformId(platformId);

    return generateFullGetEntries(teams, timeFrameId, countryCode);
  },
  async byTeams(
    teamIds: TeamId[],
    timeFrameId: TimeFrameId,
    countryCode?: string
  ): Promise<FullGetEntry[]> {
    const r = container.resolve(AppContext).repositories;

    const teams = await r.teamRepository.getTeamsWithStructureByTeamIds(teamIds);

    return generateFullGetEntries(teams, timeFrameId, countryCode);
  },
  async all(timeFrameId: TimeFrameId, countryCode?: string): Promise<FullGetEntry[]> {
    const r = container.resolve(AppContext).repositories;

    const teams = await r.teamRepository.getTeamsWithStructure();

    return generateFullGetEntries(teams, timeFrameId, countryCode);
  },
};
