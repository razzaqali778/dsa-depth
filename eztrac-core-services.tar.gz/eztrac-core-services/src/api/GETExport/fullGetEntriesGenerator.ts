import {eztracVipClient, Initiative} from '../../util/client/eztracVipClient';
import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {TeamId} from 'src/api/team/models';
import {EffortRowSetsToEntity} from '../effort/effortRowSetsToEntity';
import {mapHoursToWorkdays} from './hoursToWorkdayMapper';
import {eztracCostingClient} from '../../util/client/eztracCostingClient';
import {papiClient} from '../../util/client/papiClient';
import {transformAndFlatten} from './initiativeTransformation';
import {getPersonAllocations} from './personToInitiativeMapper';
import {combineGETEntries} from './getEntriesCombiner';
import {TeamStructure} from '../team/models';
import {TimeFrameId} from '../timeframe/models';
import {EffortMember, EffortEntity} from '../effort/models';
import {EffortAllocation} from '../effort/allocation/models';

function filterAllocations(
  allocations: EffortAllocation[],
  initiativesMap: Map<string, Initiative>
) {
  // sort by activity id, to match results from old ez-trac-core service

  return allocations
    .map((a): {activityId: string | undefined; allocation: EffortAllocation} => {
      const initiative = initiativesMap.get(a.initiativeId);
      return {activityId: initiative?.activityId, allocation: a};
    })
    .filter(ia => ia.activityId && ia.allocation.percentageOfTeamCost > 0)
    .sort((a, b) => (a.activityId ?? '').localeCompare(b.activityId ?? ''))
    .map(ia => ia.allocation);
}

const filterMembers = (members: EffortMember[]) => members.filter(member => member.percent > 0);

async function getEffortsForGETEntry(
  teamIds: TeamId[],
  timeFrameId: TimeFrameId,
  initiatives: Map<string, Initiative>
): Promise<EffortEntity[]> {
  const r = container.resolve(AppContext).repositories;

  const effortRows = await r.effortRepository.getEffortsByTeamsAndTimeFrames(teamIds, [
    timeFrameId,
  ]);
  const allocations = await r.effortAllocationsRepository
    .getEffortAllocationsByTeamsAndTimeFrames(teamIds, [timeFrameId])
    .then(allocations => filterAllocations(allocations, initiatives));
  const members = await r.effortRepository
    .getEffortMembersByTimeframes(teamIds, [timeFrameId])
    .then(members => filterMembers(members));
  return EffortRowSetsToEntity.parse(effortRows, allocations, members);
}

export async function generateFullGetEntries(
  teams: TeamStructure[],
  timeFrameId: TimeFrameId,
  countryCode?: string
) {
  const r = container.resolve(AppContext).repositories;

  const teamIds = teams.map(t => t.teamId);

  const initiatives = await eztracVipClient
    .getInitiativeHierarchy()
    .then(initiatives => transformAndFlatten(initiatives));

  const workdays = await r.timeFrameRepository.getWorkdaysByTimeFrameIdAndCountry(
    timeFrameId,
    countryCode
  );

  const efforts = await getEffortsForGETEntry(teamIds, timeFrameId, initiatives);

  const memberIds = efforts.reduce((acc, current) => {
    current.members?.forEach(m => acc.add(m.userId));
    return acc;
  }, new Set<string>());

  const people = await papiClient.getUsersById(Array.from(memberIds));
  const personCostingData = await eztracCostingClient.getPersonCostingData();

  const personAllocations = getPersonAllocations(
    efforts,
    workdays,
    people,
    initiatives,
    teams,
    personCostingData
  );

  const fullGetEntries = mapHoursToWorkdays(personAllocations, workdays);
  return combineGETEntries(fullGetEntries);
}
