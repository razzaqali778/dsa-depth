import {IDatabase} from 'pg-promise';
import {inject, injectable} from 'tsyringe';
import {AppRepositories} from './AppRepositories';

@injectable()
export class AppContext {
  constructor(
    @inject('Database') db: IDatabase<{}>,
    @inject('Repositories') repositories: AppRepositories
  ) {
    this.db = db;
    this.repositories = repositories;
  }
  db: IDatabase<{}>;
  repositories: AppRepositories;
}
