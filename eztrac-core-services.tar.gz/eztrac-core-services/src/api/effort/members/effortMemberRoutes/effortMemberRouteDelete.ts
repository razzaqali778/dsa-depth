import {Response, Router} from 'express';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {SwaggerDoc} from '../../../../util/swaggerTypes';
import {DeleteMembersByTimeframePersonAndTeam, schema} from '../validationSchema';
import {apiResponse} from '../../../../middleware/apiResponse';
import {deleteTeamMember} from '../effortMemberService';
import {entitlements} from '../../../../config/entitlementsConfig';
import {isAdmin} from '../../../../util/security/isAdmin';
import {StatusCodes} from 'http-status-codes';
const profileMiddleware = require('@monsantoit/profile-middleware');

const validator = createValidator();
const tags = ['efforts-members'];

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.effortWrite,
  methods: ['delete'],
});

const effortMemberDeleteActions = ({router, doc}: {router: Router; doc: SwaggerDoc}) => {
  doc['/efforts/timeframes/:timeFrameId/team/:teamId/user/:personId'] = {
    get: {
      tags,
      operationId: 'deleteEfforMembersForTimeFrameTeamAndPerson',
      summary: 'delete effort members for person, timeframe and team',
      parameters: [
        {
          name: 'timeFrameId',
          in: 'path',
          description: 'time frame ID',
          required: true,
          type: 'number',
        },
        {
          name: 'personId',
          in: 'path',
          description: 'user ID',
          required: true,
          type: 'string',
        },
        {
          name: 'teamId',
          in: 'path',
          description: 'team ID',
          required: true,
          type: 'string',
        },
      ],

      responses: {
        200: {description: 'Entry has been succesfully deleted'},
        400: {description: 'Bad request'},
      },
    },
  };

  router.delete(
    '/efforts/timeframes/:timeFrameId/team/:teamId/user/:personId',
    entitlementMiddleware,
    validator.params(schema.fullMembersParams),
    apiResponse(
      async (req: ValidatedRequest<DeleteMembersByTimeframePersonAndTeam>, res: Response) => {
        const {timeFrameId, personId, teamId} = req.params;
        const admin = isAdmin(req.headers['user-profile']);
        await deleteTeamMember(timeFrameId, personId, teamId, admin);
        res.sendStatus(StatusCodes.OK);
      }
    )
  );

  return {router, doc};
};

export default effortMemberDeleteActions;
