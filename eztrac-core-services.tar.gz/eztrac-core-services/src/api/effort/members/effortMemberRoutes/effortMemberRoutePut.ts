import {Response, Router} from 'express';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {SwaggerDoc} from '../../../../util/swaggerTypes';
import {PutMembersByTimeframePersonAndTeam, schema} from '../validationSchema';
import {apiResponse} from '../../../../middleware/apiResponse';
import {addOrUpdateTeamMember} from '../effortMemberService';
import {entitlements} from '../../../../config/entitlementsConfig';
import {isAdmin} from '../../../../util/security/isAdmin';
import {StatusCodes} from 'http-status-codes';
const profileMiddleware = require('@monsantoit/profile-middleware');

const validator = createValidator();
const tags = ['efforts-members'];

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.effortWrite,
  methods: ['put'],
});

const effortMemberPutActions = ({router, doc}: {router: Router; doc: SwaggerDoc}) => {
  doc['/efforts/timeframes/:timeFrameId/team/:teamId/user/:personId'] = {
    put: {
      tags,
      operationId: 'addOrUpdateEffortMember',
      summary: 'add or update Effort Member',
      parameters: [
        {
          name: 'timeFrameId',
          in: 'path',
          description: 'time frame ID',
          required: true,
          type: 'number',
        },
        {
          name: 'personId',
          in: 'path',
          description: 'new person ID',
          required: true,
          type: 'string',
        },
        {
          name: 'teamId',
          in: 'path',
          description: 'team ID',
          required: true,
          type: 'string',
        },
      ],

      responses: {
        200: {
          description: '',
        },
        400: {description: 'Bad request'},
      },
    },
  };

  router.put(
    '/efforts/timeframes/:timeFrameId/team/:teamId/user/:personId',
    entitlementMiddleware,
    validator.params(schema.fullMembersParams),
    validator.body(schema.putMembersBody),
    apiResponse(
      async (req: ValidatedRequest<PutMembersByTimeframePersonAndTeam>, res: Response) => {
        const {timeFrameId, personId, teamId} = req.params;
        const {percent} = req.body;

        const admin = isAdmin(req.headers['user-profile']);
        await addOrUpdateTeamMember(timeFrameId, teamId, {userId: personId, percent}, admin);

        res.sendStatus(StatusCodes.OK);
      }
    )
  );

  return {router, doc};
};

export default effortMemberPutActions;
