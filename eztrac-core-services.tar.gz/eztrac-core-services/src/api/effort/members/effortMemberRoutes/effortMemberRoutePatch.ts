import {Response, Router} from 'express';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {SwaggerDoc} from '../../../../util/swaggerTypes';
import {schema, UpdateMembersByTimeframeAndTeam, UpdateMembersMultiple} from '../validationSchema';
import {apiResponse} from '../../../../middleware/apiResponse';
import {updateTeamMembers} from '../effortMemberService';
import {entitlements} from '../../../../config/entitlementsConfig';
import {isAdmin} from '../../../../util/security/isAdmin';
import {getFullEffortEntityByTeamAndTimeFrame} from '../../effortService';
const profileMiddleware = require('@monsantoit/profile-middleware');

const validator = createValidator();
const tags = ['efforts-members'];

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.effortWrite,
  methods: ['patch'],
});

const effortMemberPatchActions = ({router, doc}: {router: Router; doc: SwaggerDoc}) => {
  doc['/efforts/timeframes/:timeFrameId/team/:teamId'] = {
    patch: {
      tags,
      operationId: 'updateEffortMembers',
      summary: 'update effort members for timeframe and team',
      parameters: [
        {
          name: 'timeFrameId',
          in: 'path',
          description: 'time frame ID',
          required: true,
          type: 'number',
        },
        {
          name: 'teamId',
          in: 'path',
          description: 'team ID',
          required: true,
          type: 'string',
        },
      ],

      responses: {
        200: {description: 'Entry has been succesfully updated'},
        400: {description: 'Bad request'},
        404: {
          description: 'Some content required for update has not been found',
        },
      },
    },
  };

  router.patch(
    '/efforts/timeframes/:timeFrameId/team/:teamId',
    entitlementMiddleware,
    validator.params(schema.updateMembersParams),
    validator.body(schema.updateMembersBody),
    apiResponse(async (req: ValidatedRequest<UpdateMembersByTimeframeAndTeam>, res: Response) => {
      const {timeFrameId, teamId} = req.params;
      const {participants, genericParticipants} = req.body;
      const admin = isAdmin(req.headers['user-profile']);
      await updateTeamMembers([timeFrameId], teamId, participants, genericParticipants, admin);

      const data = await getFullEffortEntityByTeamAndTimeFrame(teamId, timeFrameId);
      res.send(data);
    })
  );

  doc['/efforts/members/team/:teamId'] = {
    patch: {
      tags,
      operationId: 'updateEffortMembersMultiple',
      summary: 'update effort members for multiple timeframes and team',
      parameters: [
        {
          name: 'teamId',
          in: 'path',
          description: 'team ID',
          required: true,
          type: 'string',
        },
      ],

      responses: {
        200: {description: 'Entries has been successfully updated'},
        400: {description: 'Bad request'},
        404: {
          description: 'Some content required for update has not been found',
        },
      },
    },
  };

  router.patch(
    '/efforts/members/team/:teamId',
    entitlementMiddleware,
    validator.params(schema.updateMembersMultipleParams),
    validator.body(schema.updateMembersMultipleBody),
    apiResponse(async (req: ValidatedRequest<UpdateMembersMultiple>, res: Response) => {
      const {teamId} = req.params;
      const {specificPeople, genericPeople, timeFrameIds} = req.body;
      const admin = isAdmin(req.headers['user-profile']);
      await updateTeamMembers(timeFrameIds, teamId, specificPeople, genericPeople, admin);

      const data = await Promise.all(
        timeFrameIds.map(
          async timeFrameId => await getFullEffortEntityByTeamAndTimeFrame(teamId, timeFrameId)
        )
      );
      res.send(data);
    })
  );

  return {router, doc};
};

export default effortMemberPatchActions;
