import {Response, Router} from 'express';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {SwaggerDoc} from '../../../../util/swaggerTypes';
import {GetMembersByTimeframe, GetMembersByTimeframeAndPerson, schema} from '../validationSchema';
import {apiResponse} from '../../../../middleware/apiResponse';
import {byPersonAndTimeframe, byTimeFrame, byTimeFramePlaceholders} from '../effortMemberService';

const validator = createValidator();
const tags = ['efforts-members'];

const effortMemberGetActions = ({router, doc}: {router: Router; doc: SwaggerDoc}) => {
  doc['/efforts/timeframes/:timeFrameId/user/:personId'] = {
    get: {
      tags,
      operationId: 'getEffortMembersForTimeFrameAndPerson',
      summary: 'get effort members for person and timeframe',
      parameters: [
        {
          name: 'timeFrameId',
          in: 'path',
          description: 'time frame ID',
          required: true,
          type: 'number',
        },
        {
          name: 'personId',
          in: 'path',
          description: 'user ID',
          required: true,
          type: 'string',
        },
      ],

      responses: {
        200: {
          description: 'List of effort members for provided user and timeframe',
        },
        400: {description: 'Bad request'},
      },
    },
  };

  router.get(
    '/efforts/timeframes/:timeFrameId/user/:personId',
    validator.params(schema.getMembersByTimeFrameAndPersonParams),
    apiResponse(async (req: ValidatedRequest<GetMembersByTimeframeAndPerson>, res: Response) => {
      const {timeFrameId, personId} = req.params;
      const result = await byPersonAndTimeframe(timeFrameId, personId);
      res.send(result);
    })
  );

  doc['/efforts/timeframes/:timeFrameId'] = {
    get: {
      tags,
      operationId: 'getEffortMembersForTimeFrame',
      summary: 'get effort members for timeframe',
      parameters: [
        {
          name: 'timeFrameId',
          in: 'path',
          description: 'time frame ID',
          required: true,
          type: 'number',
        },
      ],

      responses: {
        200: {
          description: 'List of effort members for provided user and timeframe',
        },
        400: {description: 'Bad request'},
      },
    },
  };

  router.get(
    '/efforts/timeframes/:timeFrameId',
    validator.params(schema.getMembersByTimeFrameParams),
    apiResponse(async (req: ValidatedRequest<GetMembersByTimeframe>, res: Response) => {
      const {timeFrameId} = req.params;
      const result = await byTimeFrame(timeFrameId);
      res.send(result);
    })
  );

  doc['/efforts/timeframes/:timeFrameId/placeholders'] = {
    get: {
      tags,
      operationId: 'getForecastedEffortMembersForTimeFrame',
      summary: 'get forecasted effort members for timeframe',
      parameters: [
        {
          name: 'timeFrameId',
          in: 'path',
          description: 'time frame ID',
          required: true,
          type: 'number',
        },
      ],

      responses: {
        200: {
          description: 'List of forecasted effort members for provided user and timeframe',
        },
        400: {description: 'Bad request'},
      },
    },
  };

  router.get(
    '/efforts/timeframes/:timeFrameId/placeholders',
    validator.params(schema.getMembersByTimeFrameParams),
    apiResponse(async (req: ValidatedRequest<GetMembersByTimeframe>, res: Response) => {
      const {timeFrameId} = req.params;
      const result = await byTimeFramePlaceholders(timeFrameId);
      res.send(result);
    })
  );

  return {router, doc};
};

export default effortMemberGetActions;
