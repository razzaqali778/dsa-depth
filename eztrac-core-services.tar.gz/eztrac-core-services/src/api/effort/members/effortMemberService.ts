import {container} from 'tsyringe';
import {AppContext} from '../../AppContext';
import {TimeFrameId} from '../../../api/timeframe/models';
import {EffortEntity, EffortId, PersonId} from '../models';
import {Member, ForecastedTeamMemberDTO, MemberDTO} from './models';
import {TeamId} from '../../../api/team/models';
import {GenericParticipant, Participant} from '../../../api/person/models';
import {getTeamByIdOrThrow} from '../../team/teamService';
import {
  getOrCreateEfforts,
  updateEfforts,
  validateUserIsAuthorizedToModifyChosenTimeFrames,
} from '../effortService';
import {getOrCreatePeople} from '../../person/personService';

const mapToMemberDTO = (members: Member[]): MemberDTO[] =>
  members.map(m => {
    const {effortId: _effortId, ...member} = m;
    return member;
  });

export const byPersonAndTimeframe = async (
  timeFrameId: TimeFrameId,
  personId: PersonId
): Promise<MemberDTO[]> => {
  const repositories = container.resolve(AppContext).repositories;
  const members = await repositories.effortMembersRepository.getEffortMembersByTimeframeAndPerson(
    timeFrameId,
    personId
  );

  return mapToMemberDTO(members);
};

export const byTimeFrame = async (timeFrameId: TimeFrameId): Promise<MemberDTO[]> => {
  const repositories = container.resolve(AppContext).repositories;
  const members = await repositories.effortMembersRepository.getEffortMembersByTimeframe(
    timeFrameId
  );
  return mapToMemberDTO(members);
};

export const byTimeFramePlaceholders = async (
  timeFrameId: TimeFrameId
): Promise<ForecastedTeamMemberDTO[]> => {
  const repositories = container.resolve(AppContext).repositories;
  const forecastedMembers =
    await repositories.effortMembersRepository.getForecastedEffortMembersByTimeframe(timeFrameId);
  return forecastedMembers.map(fm => {
    const {effortId: _effortId, numberOfPeople, ...member} = fm;
    return {
      ...member,
      numberOfPeople: Number(numberOfPeople),
    };
  });
};

const validateAndUpdateMembers = async (
  timeFrameIds: TimeFrameId[],
  teamId: TeamId,
  userIds: PersonId[],
  modifiedEfforts: EffortEntity[],
  isAdmin: boolean
) => {
  const r = container.resolve(AppContext).repositories;

  await getTeamByIdOrThrow(teamId);
  await validateUserIsAuthorizedToModifyChosenTimeFrames(timeFrameIds, isAdmin, r);
  await getOrCreatePeople(userIds);

  return updateEfforts(modifiedEfforts);
};

export const deleteTeamMember = async (
  timeFrameId: TimeFrameId,
  personId: PersonId,
  teamId: TeamId,
  isAdmin: boolean
): Promise<EffortId[]> => {
  const efforts = await getOrCreateEfforts([timeFrameId], teamId);
  const modifiedEfforts: EffortEntity[] = efforts.map(effort => ({
    ...effort,
    members: effort.members?.filter(m => m.userId !== personId),
  }));

  return validateAndUpdateMembers([timeFrameId], teamId, [personId], modifiedEfforts, isAdmin);
};

export const updateTeamMembers = async (
  timeFrameIds: TimeFrameId[],
  teamId: TeamId,
  participants: Participant[],
  genericParticipants: GenericParticipant[],
  isAdmin: boolean
) => {
  const efforts = await getOrCreateEfforts(timeFrameIds, teamId);
  const modifiedEfforts: EffortEntity[] = efforts.map(effort => ({
    ...effort,
    members: participants,
    forecastPeople: genericParticipants,
  }));

  return validateAndUpdateMembers(
    timeFrameIds,
    teamId,
    participants.map(p => p.userId),
    modifiedEfforts,
    isAdmin
  );
};

export const addOrUpdateTeamMember = async (
  timeFrameId: TimeFrameId,
  teamId: TeamId,
  member: Participant,
  isAdmin: boolean
) => {
  const efforts = await getOrCreateEfforts([timeFrameId], teamId);
  const modifiedEfforts: EffortEntity[] = efforts.map(effort => ({
    ...effort,
    members: [...(effort.members?.filter(m => m.userId !== member.userId) ?? []), member],
  }));

  return validateAndUpdateMembers([timeFrameId], teamId, [member.userId], modifiedEfforts, isAdmin);
};
