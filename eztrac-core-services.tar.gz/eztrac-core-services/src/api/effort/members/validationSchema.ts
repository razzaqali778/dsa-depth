import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';
import Joi from 'joi';
import {GenericParticipant, Participant, ParticipationPct} from '../../../api/person/models';
import {TeamId} from '../../../api/team/models';
import {TimeFrameId} from '../../../api/timeframe/models';
import {PersonId} from '../models';
import {convertToBigint} from '../../../util/typeConverter';

export interface GetMembersByTimeframe extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
  };
}

export interface GetMembersByTimeframeAndPerson extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
    personId: PersonId;
  };
}

export interface DeleteMembersByTimeframePersonAndTeam extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
    personId: PersonId;
    teamId: TeamId;
  };
}

export interface PutMembersByTimeframePersonAndTeam extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
    personId: PersonId;
    teamId: TeamId;
  };
  [ContainerTypes.Body]: {
    percent: ParticipationPct;
  };
}

export interface UpdateMembersByTimeframeAndTeam extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    timeFrameId: TimeFrameId;
    teamId: TeamId;
  };
  [ContainerTypes.Body]: {
    genericParticipants: GenericParticipant[];
    participants: Participant[];
  };
}

export interface UpdateMembersMultiple extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    teamId: TeamId;
  };
  [ContainerTypes.Body]: {
    timeFrameIds: TimeFrameId[];
    specificPeople: Participant[];
    genericPeople: GenericParticipant[];
  };
}

const getMembersByTimeFrameParams = Joi.object({
  timeFrameId: Joi.number().required().custom(convertToBigint),
});

const getMembersByTimeFrameAndPersonParams = Joi.object({
  timeFrameId: Joi.number().required().custom(convertToBigint),
  personId: Joi.string().required(),
});

const fullMembersParams = Joi.object({
  timeFrameId: Joi.number().required().custom(convertToBigint),
  personId: Joi.string().required(),
  teamId: Joi.string().required(),
});

const putMembersBody = Joi.object({
  percent: Joi.number().required().custom(convertToBigint),
});

const participantSchema = Joi.object().keys({
  userId: Joi.string().required(),
  percent: Joi.number().required().min(0).max(100).custom(convertToBigint),
});

const genericParticipantSchema = Joi.object().keys({
  numberOfPeople: Joi.number().required(),
  rateId: Joi.string().required(),
  costGroupId: Joi.string().required(),
});

const updateMembersBody = Joi.object({
  genericParticipants: Joi.array().items(genericParticipantSchema),
  participants: Joi.array().items(participantSchema),
});

const updateMembersMultipleBody = Joi.object({
  genericPeople: Joi.array().items(genericParticipantSchema),
  specificPeople: Joi.array().items(participantSchema),
  timeFrameIds: Joi.array().min(1).items(Joi.number().custom(convertToBigint)),
});

const updateMembersParams = Joi.object({
  timeFrameId: Joi.number().required(),
  teamId: Joi.string().required(),
});

const updateMembersMultipleParams = Joi.object({
  teamId: Joi.string().required(),
});

export const schema = {
  getMembersByTimeFrameParams,
  getMembersByTimeFrameAndPersonParams,
  fullMembersParams,
  putMembersBody,
  updateMembersBody,
  updateMembersMultipleParams,
  updateMembersMultipleBody,
  updateMembersParams,
};
