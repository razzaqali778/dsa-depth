import {SwaggerDoc} from '../../../util/swaggerTypes';
import effortMemberGetActions from './effortMemberRoutes/effortMemberRouteGet';
import effortMemberDeleteActions from './effortMemberRoutes/effortMemberRouteDelete';
import effortMemberPatchActions from './effortMemberRoutes/effortMemberRoutePatch';
import effortMemberPutActions from './effortMemberRoutes/effortMemberRoutePut';
const router = require('express').Router();

const doc: SwaggerDoc = {};

const {router: extendedRouter} = effortMemberPutActions(
  effortMemberPatchActions(effortMemberDeleteActions(effortMemberGetActions({router, doc})))
);

export default {
  router: extendedRouter,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
