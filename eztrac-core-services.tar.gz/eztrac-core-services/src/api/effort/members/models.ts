import {TeamId, TeamName} from '../../../api/team/models';
import {TimeFrameId} from '../../../api/timeframe/models';
import {CostGroupId, EffortId, PersonId, RateId} from '../models';

export type ParticipationPct = number;
export type NumberOfPeople = number;

export interface Participant {
  userId: PersonId;
  percent: ParticipationPct;
}

export interface GenericParticipant {
  numberOfPeople: NumberOfPeople;
  rateId: RateId;
  costGroupId: CostGroupId;
}

export interface Member {
  effortId: EffortId;
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  userId: PersonId;
  percent: ParticipationPct;
}

export interface ForecastedMember {
  effortId: EffortId;
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  numberOfPeople: NumberOfPeople;
  costGroupId: CostGroupId;
  rateId: RateId;
}

export interface ForecastedTeamMember extends ForecastedMember {
  teamName: TeamName;
}

export interface ForecastedTeamMemberDTO {
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  teamName: TeamName;
  numberOfPeople: NumberOfPeople;
  costGroupId: CostGroupId;
  rateId: RateId;
}

export interface MemberDTO {
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  userId: PersonId;
  percent: ParticipationPct;
}
