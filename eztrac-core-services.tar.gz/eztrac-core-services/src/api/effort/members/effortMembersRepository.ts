import {container} from 'tsyringe';
import {AppContext} from '../../AppContext';
import {TimeFrameId} from '../../timeframe/models';
import {EffortId, PersonId} from '../models';
import {Member, ForecastedTeamMember, ForecastedMember} from './models';

export const teamMemberQuery = `SELECT
    team_cost.team_cost_id              as "effortId",
    team_cost.timeframe_id              as "timeFrameId",
    team_cost.team_id                   as "teamId",
    team_cost_member.user_id            as "userId",
    team_cost_member.participation_pct  as "percent"
FROM public.team_cost_member as team_cost_member
JOIN
    public.team_cost as team_cost
ON team_cost_member.team_cost_id = team_cost.team_cost_id
`;

export const forecastPersonTableQuery = `
SELECT
    team_cost.team_cost_id              as "effortId",
    team_cost.timeframe_id              as "timeFrameId",
    team_cost.team_id                   as "teamId",
    forecast_person.people_number       as "numberOfPeople",
    forecast_person.cost_group_id       as "costGroupId",
    forecast_person.external_rate_id    as "rateId"
FROM public.forecast_person as forecast_person
JOIN
    public.team_cost as team_cost
ON  forecast_person.team_cost_id = team_cost.team_cost_id
`;

export const forecastPersonTableQueryWithTeamName = `
SELECT
    team_cost.team_cost_id              as "effortId",
    team_cost.timeframe_id              as "timeFrameId",
    team.team_name                      as "teamName",
    team_cost.team_id                   as "teamId",
    forecast_person.people_number       as "numberOfPeople",
    forecast_person.cost_group_id       as "costGroupId",
    forecast_person.external_rate_id    as "rateId"
FROM public.forecast_person as forecast_person
JOIN
    public.team_cost as team_cost
ON  forecast_person.team_cost_id = team_cost.team_cost_id
JOIN
    public.team as team
ON team_cost.team_id = team.team_id
`;
export interface EffortMembersRepository {
  getEffortMembersByTimeframeAndPerson(
    timeFrameId: TimeFrameId,
    personId: PersonId
  ): Promise<Member[]>;
  getEffortMembersByTimeframe(timeFrameId: TimeFrameId): Promise<Member[]>;
  getForecastedEffortMembersByTimeframe(timeFrameId: TimeFrameId): Promise<ForecastedTeamMember[]>;
  getMembersByEffortIds(effortIds: EffortId[]): Promise<Member[]>;
  getForecastedMembersByEffortIds(effortIds: EffortId[]): Promise<ForecastedMember[]>;
}

export const effortMembersRepository: EffortMembersRepository = {
  getEffortMembersByTimeframeAndPerson(
    timeFrameId: TimeFrameId,
    personId: PersonId
  ): Promise<Member[]> {
    const db = container.resolve(AppContext).db;
    const sql = `${teamMemberQuery}
        WHERE timeframe_id=$<timeFrameId> AND user_id=$<personId>
    `;
    return db.manyOrNone<Member>(sql, {
      timeFrameId,
      personId: personId,
    });
  },
  getEffortMembersByTimeframe(timeFrameId: TimeFrameId): Promise<Member[]> {
    const db = container.resolve(AppContext).db;
    const sql = `${teamMemberQuery}
    WHERE timeframe_id=$<timeFrameId>
`;
    return db.manyOrNone<Member>(sql, {
      timeFrameId,
    });
  },
  getForecastedEffortMembersByTimeframe(timeFrameId: TimeFrameId): Promise<ForecastedTeamMember[]> {
    const db = container.resolve(AppContext).db;
    const sql = `${forecastPersonTableQueryWithTeamName}
    WHERE timeframe_id=$<timeFrameId>
`;
    return db.manyOrNone<ForecastedTeamMember>(sql, {
      timeFrameId,
    });
  },
  async getMembersByEffortIds(effortIds) {
    if (!effortIds?.length) return [];
    const db = container.resolve(AppContext).db;
    const sql = `
        ${teamMemberQuery}
        WHERE team_cost.team_cost_id in ($1:csv)
      `;
    return db.manyOrNone<Member>(sql, [effortIds]);
  },
  async getForecastedMembersByEffortIds(effortIds) {
    if (!effortIds?.length) return [];
    const db = container.resolve(AppContext).db;
    const sql = `
      ${forecastPersonTableQuery}
      WHERE team_cost.team_cost_id in ($1:csv)
    `;
    return db.manyOrNone<ForecastedMember>(sql, [effortIds]);
  },
};
