import express, {Response} from 'express';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {apiResponse} from '../../middleware/apiResponse';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {GetByTeamAndTimeFrameSchema, GetEffortSchema, schema} from './validationSchema';
import {
  getFullEffortEntitiesByTeamStartAndEndTimeFrameId,
  getFullEffortEntityByTeamAndTimeFrame,
} from './effortService';

const router = express.Router();
const validator = createValidator();

const doc: SwaggerDoc = {};

const tags = ['efforts'];

doc['/efforts/full/team/:teamId/timeframe/:timeFrameId'] = {
  get: {
    tags,
    operationId: 'getFullEffortByTeamAndTimeFrame',
    summary: 'full effort team call',
    responses: {
      200: {description: 'Success'},
      404: {description: 'Not found'},
    },
  },
};

router.get(
  '/efforts/full/team/:teamId/timeframe/:timeFrameId',
  validator.params(schema.getByTeamAndTimeFrame),
  apiResponse(async (req: ValidatedRequest<GetByTeamAndTimeFrameSchema>, res: Response) => {
    const {teamId, timeFrameId} = req.params;
    const result = await getFullEffortEntityByTeamAndTimeFrame(teamId, timeFrameId);
    res.send(result);
  })
);

doc['/efforts/full/team'] = {
  get: {
    tags,
    operationId: 'getFullEffortByStartAndEndTimeFrame',
    summary: 'full effort team call by start and end time frame',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      404: {description: 'Not found'},
    },
  },
};

router.get(
  '/efforts/full/team/:teamId',
  validator.params(schema.getByTeam),
  validator.query(schema.getEffortQuery),
  apiResponse(async (req: ValidatedRequest<GetEffortSchema>, res: Response) => {
    const {teamId} = req.params;
    const {startTimeFrame, endTimeFrame} = req.query;
    const result = await getFullEffortEntitiesByTeamStartAndEndTimeFrameId(
      teamId,
      startTimeFrame,
      endTimeFrame
    );
    res.send(result);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
