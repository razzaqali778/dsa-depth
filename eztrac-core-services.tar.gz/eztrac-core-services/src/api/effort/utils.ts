import {NotFoundError} from '../types/NotFoundError';

export const throwNotFoundError = (item: string, id: string | number | bigint) => {
  throw new NotFoundError(`Unable to find ${item} with id of ${id}`);
};
