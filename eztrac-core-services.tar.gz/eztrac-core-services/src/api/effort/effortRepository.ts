import {container} from 'tsyringe';
import {TeamId} from 'src/api/team/models';
import {AppContext} from '../AppContext';
import {TimeFrameId} from '../timeframe/models';
import {Effort, EffortMember, EffortCostBreakdown, EffortEntity, EffortId} from './models';
import pgPromise from 'pg-promise';
import {
  getAllocationInsertQueries,
  getBreakdownInsertQueries,
  getEngagementInsertQueries,
  getForecastMemberInsertQueries,
  getMemberInsertQueries,
} from '../../../src/db/tableHelper';
import {isEmpty} from 'lodash';

const pgp = pgPromise({capSQL: true});

const effortQuery = `SELECT team_cost.team_cost_id as "id",
                            team_cost.timeframe_id as "timeFrameId",
                            team_cost.team_id      as "teamId",
                            team_cost.cost
                    FROM public.team_cost as team_cost`;

export interface EffortRepository {
  getEffortByTimeFrames(timeFrameIds: TimeFrameId[]): Promise<Effort[]>;
  getEffortByTeamAndTimeframes(timeFrameIds: TimeFrameId[], teamId: TeamId): Promise<Effort[]>;
  getEffortsByTeamsAndTimeFrames(teamIds: TeamId[], timeFrameIds: TimeFrameId[]): Promise<Effort[]>;
  getEffortsByTeamAndStartDate(teamId: TeamId, startDate: Date): Promise<Effort[]>;
  getEffortMembersByTimeframes(
    teamIds: TeamId[],
    timeFrameIds: TimeFrameId[]
  ): Promise<EffortMember[]>;
  getEffortCostBreakdowns(
    teamIds: TeamId[],
    timeFrameIds: TimeFrameId[]
  ): Promise<EffortCostBreakdown[]>;
  getEffortCostBreakdownsByEffortIds(effortIds: EffortId[]): Promise<EffortCostBreakdown[]>;
  getEffortsByIds(effortIds: EffortId[]): Promise<Effort[]>;
  updateEffort(effort: EffortEntity): Promise<EffortId>;
  deleteEffort(effort: EffortEntity): void;
  updateEffortCostBreakdowns(costBreakdowns: EffortCostBreakdown[]): Promise<number>;
}

export const effortRepository: EffortRepository = {
  async getEffortCostBreakdowns(
    teamIds: TeamId[],
    timeFrameIds: TimeFrameId[]
  ): Promise<EffortCostBreakdown[]> {
    if (!teamIds?.length || !timeFrameIds?.length) return [];

    const db = container.resolve(AppContext).db;
    const sql = `SELECT team_cost.team_cost_id            as "effortId",
                            team_cost_breakdown.cost_group_id as "costGroupId",
                            team_cost_breakdown.cost          as "cost",
                            team_cost_breakdown.engagement_id as "engagementId",
                            team_cost_breakdown.person_id     as "personId"
                     FROM public.team_cost as team_cost
                              join
                          public.team_cost_breakdown as team_cost_breakdown
                          on team_cost.team_cost_id = team_cost_breakdown.team_cost_id
                     WHERE team_cost.timeframe_id in ($1:csv)
                       and team_cost.team_id in ($2:csv)`;
    return db.any<EffortCostBreakdown>(sql, [timeFrameIds.map(id => Number(id)), teamIds]);
  },
  async getEffortMembersByTimeframes(
    teamIds: TeamId[],
    timeFrameIds: TimeFrameId[]
  ): Promise<EffortMember[]> {
    if (!teamIds?.length || !timeFrameIds?.length) return [];

    const db = container.resolve(AppContext).db;
    const sql = `SELECT team_cost.team_cost_id             as "effortId",
                            team_cost_member.user_id           as "userId",
                            team_cost_member.participation_pct as "percent"
                     FROM public.team_cost as team_cost
                              join
                          public.team_cost_member as team_cost_member
                          on team_cost.team_cost_id = team_cost_member.team_cost_id
                     WHERE team_cost.timeframe_id in ($1:csv)
                     AND team_cost.team_id in ($2:csv)`;
    return db.any<EffortMember>(sql, [timeFrameIds.map(id => Number(id)), teamIds]);
  },
  async getEffortByTimeFrames(timeFrameIds: TimeFrameId[]): Promise<Effort[]> {
    if (!timeFrameIds?.length) return [];

    const db = container.resolve(AppContext).db;

    const sql = `
            ${effortQuery}
            WHERE timeframe_id in ($1:csv)
        `;
    return db.manyOrNone<Effort>(sql, [timeFrameIds]);
  },
  async getEffortByTeamAndTimeframes(
    timeFrameIds: TimeFrameId[],
    teamId: TeamId
  ): Promise<Effort[]> {
    if (!timeFrameIds?.length) return [];

    const db = container.resolve(AppContext).db;

    const sql = `
            ${effortQuery}
            WHERE timeframe_id in ($1:csv)
            AND team_id = $2
        `;
    return db.any<Effort>(sql, [timeFrameIds, teamId]);
  },

  async getEffortsByTeamsAndTimeFrames(
    teamIds: TeamId[],
    timeFrameIds: TimeFrameId[]
  ): Promise<Effort[]> {
    if (!teamIds?.length || !timeFrameIds?.length) return [];

    const db = container.resolve(AppContext).db;

    const sql = `
            ${effortQuery}
            WHERE team_cost.timeframe_id in ($1:csv)
            AND team_cost.team_id IN ($2:csv)
        `;
    return db.any<Effort>(sql, [timeFrameIds.map(id => Number(id)), teamIds]);
  },

  getEffortsByTeamAndStartDate(teamId: TeamId, startDate: Date): Promise<Effort[]> {
    const db = container.resolve(AppContext).db;
    const sql = `
        ${effortQuery}
        JOIN public.timeframe as timeframe
          ON team_cost.timeframe_id = timeframe.timeframe_id
        WHERE timeframe.timeframe_start_date > $<startDate>
          AND team_cost.team_id = $<teamId>
      `;
    return db.any<Effort>(sql, {teamId, startDate});
  },

  async getEffortsByIds(effortIds: EffortId[]): Promise<Effort[]> {
    if (!effortIds?.length) return [];

    const db = container.resolve(AppContext).db;
    const sql = `
      ${effortQuery}
      WHERE team_cost.team_cost_id in ($1:csv)
    `;
    return db.manyOrNone<Effort>(sql, [effortIds.map(id => Number(id))]);
  },

  async getEffortCostBreakdownsByEffortIds(effortIds) {
    if (!effortIds?.length) return [];

    const db = container.resolve(AppContext).db;
    const sql = `SELECT
      team_cost.team_cost_id            as "effortId",
      team_cost_breakdown.cost_group_id as "costGroupId",
      team_cost_breakdown.cost          as "cost",
      team_cost_breakdown.engagement_id as "engagementId",
      team_cost_breakdown.person_id     as "personId"
      FROM public.team_cost as team_cost
        join
      public.team_cost_breakdown as team_cost_breakdown
      on team_cost.team_cost_id = team_cost_breakdown.team_cost_id
      WHERE team_cost.team_cost_id in ($1:csv)`;
    return db.manyOrNone(sql, [effortIds]);
  },

  deleteEffort(effort) {
    const db = container.resolve(AppContext).db;
    const deleteSql = `
      DELETE FROM team_cost_allocation WHERE team_cost_id=$<effortId>;
      DELETE FROM team_cost_member WHERE team_cost_id=$<effortId>;
      DELETE FROM forecast_person WHERE team_cost_id=$<effortId>;
      DELETE FROM team_cost_engagement WHERE team_cost_id=$<effortId>;
      DELETE FROM team_cost_breakdown WHERE team_cost_id=$<effortId>;
      DELETE FROM team_cost WHERE team_cost_id=$<effortId>;
  `;
    return db.none(deleteSql, {effortId: effort.id});
  },

  async updateEffort(effort) {
    const db = container.resolve(AppContext).db;
    const {TransactionMode, isolationLevel} = pgp.txMode;
    const mode = new TransactionMode({
      tiLevel: isolationLevel.repeatableRead,
      readOnly: false,
    });
    return db.tx({mode}, async t => {
      let effortId = effort.id;

      // create new team_cost row if it doesn't exists for teamId, timeframeId combination
      if (!effortId) {
        const insertTeamCostRowSql =
          'INSERT INTO team_cost(timeframe_id, team_id) VALUES ($<timeFrameId>, $<teamId>) RETURNING team_cost_id';
        const result = await t.one(insertTeamCostRowSql, effort);
        effortId = result.team_cost_id;
        if (!effortId) throw new Error('Failed to create team_cost row: no id returned');
      }

      // delete allocations, members, forecasted members and engagements for effort before inserting updated values
      const deleteSql = `
        DELETE FROM team_cost_allocation WHERE team_cost_id=$<effortId>;
        DELETE FROM team_cost_member WHERE team_cost_id=$<effortId>;
        DELETE FROM forecast_person WHERE team_cost_id=$<effortId>;
        DELETE FROM team_cost_engagement WHERE team_cost_id=$<effortId>;
        DELETE FROM team_cost_breakdown WHERE team_cost_id=$<effortId>;
      `;
      await t.none(deleteSql, {effortId});

      // insert updated allocations, members, forecasted members and engagements
      const allocationsQuery = !isEmpty(effort.allocations)
        ? getAllocationInsertQueries(effort.allocations!, effortId)
        : null;
      const membersQuery = !isEmpty(effort.members)
        ? getMemberInsertQueries(effort.members!, effortId)
        : null;
      const forecastPeopleQuery = !isEmpty(effort.forecastPeople)
        ? getForecastMemberInsertQueries(effort.forecastPeople!, effortId)
        : null;
      const engagementQuery = !isEmpty(effort.engagements)
        ? getEngagementInsertQueries(effort.engagements!, effortId)
        : null;
      const breakdownQuery = !isEmpty(effort.costBreakdowns)
        ? getBreakdownInsertQueries(effort.costBreakdowns!.map(b => ({...b, effortId: effortId!})))
        : null;

      const queries = [
        allocationsQuery,
        membersQuery,
        forecastPeopleQuery,
        engagementQuery,
        breakdownQuery,
      ]
        .filter(query => query)
        .map(query => t.none(query!));

      await t.batch(queries);

      return effortId;
    });
  },
  async updateEffortCostBreakdowns(costBreakdowns) {
    if (!costBreakdowns?.length) return 0;

    const db = container.resolve(AppContext).db;
    const {TransactionMode, isolationLevel} = pgp.txMode;
    const mode = new TransactionMode({
      tiLevel: isolationLevel.repeatableRead,
      readOnly: false,
    });

    return db.tx({mode}, async t => {
      const effortIds = costBreakdowns.map(b => b.effortId);
      const deleteSql = `DELETE
        FROM team_cost_breakdown
        WHERE team_cost_id in ($1:csv)`;
      await t.none(deleteSql, [effortIds]);

      const insertQueries = getBreakdownInsertQueries(costBreakdowns);

      await t.none(insertQueries);

      return costBreakdowns.length;
    });
  },
};
