import {SwaggerDoc} from '../../../util/swaggerTypes';
import effortEngagementGetActions from './effortEngagementRoutes/effortEngagementRouteGet';
import effortEngagementDeleteActions from './effortEngagementRoutes/effortEngagementRouteDelete';
import effortEngagementPostActions from './effortEngagementRoutes/effortEngagementRoutePost';
import effortEngagementPatchActions from './effortEngagementRoutes/effortEngagementRoutePatch';
const router = require('express').Router();

const doc: SwaggerDoc = {};

const {router: extendedRouter} = effortEngagementPatchActions(
  effortEngagementPostActions(
    effortEngagementDeleteActions(effortEngagementGetActions({router, doc}))
  )
);

export default {
  router: extendedRouter,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
