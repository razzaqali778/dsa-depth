import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';
import Joi from 'joi';
import {TeamId} from '../../team/models';
import {TimeFrameId} from '../../timeframe/models';
import {EngagementCalcInfo, EngagementId} from './models';
import {convertToBigint} from '../../../util/typeConverter';

export interface GetTimeframesInRange extends ValidatedRequestSchema {
  [ContainerTypes.Query]: {
    startTimeFrame: TimeFrameId;
    endTimeFrame: TimeFrameId;
  };
}

export interface GetTimeframesInRangeByTeam extends ValidatedRequestSchema {
  [ContainerTypes.Query]: {
    startTimeFrame?: TimeFrameId;
    endTimeFrame?: TimeFrameId;
  };
  [ContainerTypes.Params]: {teamId: TeamId};
}

export interface DeleteEffortEngagement extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    teamId: TeamId;
    timeFrameId: TimeFrameId;
    engagementId: EngagementId;
  };
}

export interface CreateEngagementsWithCalcInfo extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    engagementCalcInfo: EngagementCalcInfo;
    endTimeFrameId: TimeFrameId;
    comment: string;
  };
  [ContainerTypes.Params]: {
    teamId: TeamId;
    timeFrameId: TimeFrameId;
    engagementId: EngagementId;
  };
}

export interface CreateEngagementsSimple extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    teamId: TeamId;
    startTimeFrameId: TimeFrameId;
    endTimeFrameId: TimeFrameId;
    amount: number;
    comment: string;
    engagementId: EngagementId;
    // not needed, added for backwards compatibility
    amountType: string;
  };
}

export interface UpdateEngagementsWithCalcInfo extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    calcInfo: EngagementCalcInfo;
    endTimeFrameId: TimeFrameId;
    comment: string;
  };
  [ContainerTypes.Query]: {
    all: boolean;
  };
  [ContainerTypes.Params]: {
    teamId: TeamId;
    timeFrameId: TimeFrameId;
    engagementId: EngagementId;
  };
}

export interface UpdateEngagementsDetails extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    amount: number;
    comment: string;
  };
  [ContainerTypes.Query]: {
    all: boolean;
  };
  [ContainerTypes.Params]: {
    teamId: TeamId;
    timeFrameId: TimeFrameId;
    engagementId: EngagementId;
  };
}

const getTimeframesInRangeQuery = Joi.object({
  startTimeFrame: Joi.number().required().custom(convertToBigint),
  endTimeFrame: Joi.number().required().custom(convertToBigint),
});

const getTimeframesInRangeOptionalQuery = Joi.object({
  startTimeFrame: Joi.number().custom(convertToBigint),
  endTimeFrame: Joi.number().custom(convertToBigint),
});

const createEngagementBody = Joi.object({
  teamId: Joi.string().required(),
  startTimeFrameId: Joi.number().required().custom(convertToBigint),
  endTimeFrameId: Joi.number().required().custom(convertToBigint),
  amount: Joi.number().required().min(0),
  engagementId: Joi.string().required(),
  comment: Joi.string().allow(null, ''),
  // not needed, added for backwards compatibility
  amountType: Joi.string().allow(null, ''),
});

const createEngagementWithCalcInfoBody = Joi.object({
  endTimeFrameId: Joi.number().required().custom(convertToBigint),
  engagementCalcInfo: Joi.object({
    calendarId: Joi.string().required(),
    rates: Joi.array().items(
      Joi.object({
        people: Joi.number().required(),
        hourlyRate: Joi.number().required(),
        comment: Joi.string().allow(null, ''),
      })
    ),
  }),
  comment: Joi.string().allow(null, ''),
});

const getByTeamId = Joi.object({
  teamId: Joi.string().required(),
});

const engagementQueryParams = Joi.object({
  teamId: Joi.string().required(),
  timeFrameId: Joi.number().required().custom(convertToBigint),
  engagementId: Joi.string().required(),
});

const updateEngagementParams = Joi.object({
  all: Joi.boolean(),
});

const updateEngagementWithCalcInfoBody = Joi.object({
  calcInfo: Joi.object({
    calendarId: Joi.string().required(),
    rates: Joi.array().items(
      Joi.object({
        people: Joi.number().required(),
        hourlyRate: Joi.number().required(),
        comment: Joi.string().allow(null, ''),
      })
    ),
  }).required(),
  comment: Joi.string().allow(null, ''),
});

const updateEngagementSimpleBody = Joi.object({
  amount: Joi.number().required(),
  comment: Joi.string().allow(null, ''),
});

export const schema = {
  getTimeframesInRangeQuery,
  getTimeframesInRangeOptionalQuery,
  getByTeamId,
  engagementQueryParams,
  createEngagementWithCalcInfoBody,
  createEngagementBody,
  updateEngagementParams,
  updateEngagementWithCalcInfoBody,
  updateEngagementSimpleBody,
};
