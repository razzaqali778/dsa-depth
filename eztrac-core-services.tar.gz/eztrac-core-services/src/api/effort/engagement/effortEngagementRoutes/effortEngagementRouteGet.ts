import {Response, Router} from 'express';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {SwaggerDoc} from '../../../../util/swaggerTypes';
import {GetTimeframesInRange, GetTimeframesInRangeByTeam, schema} from '../validationSchema';
import {apiResponse} from '../../../../middleware/apiResponse';
import {byTeam, byTeamAndTimeRange, byTimeFrameIds} from '../effortEngagementService';

const validator = createValidator();
const tags = ['efforts-engagements'];

const effortEngagementGetActions = ({router, doc}: {router: Router; doc: SwaggerDoc}) => {
  doc['/efforts/engagements/team/:teamId'] = {
    get: {
      tags,
      operationId: 'getEffortEngagementsByTeam',
      summary: 'get effort engagements by team id, and timeframes',
      parameters: [
        {
          name: 'teamId',
          in: 'path',
          description: 'team name',
          required: true,
          type: 'string',
        },
        {
          name: 'startTimeFrame',
          in: 'query',
          description: 'start time frame ID',
          required: false,
          type: 'number',
        },
        {
          name: 'endTimeFrame',
          in: 'query',
          description: 'end time frame ID',
          required: false,
          type: 'number',
        },
      ],

      responses: {
        200: {
          description: 'List of engagements for given time frame and time id',
        },
        400: {description: 'Bad request'},
        404: {
          description:
            'Time with given id was not foud, or no team with provided id in specified timeframe range',
        },
      },
    },
  };

  router.get(
    '/efforts/engagements/team/:teamId',
    validator.params(schema.getByTeamId),
    validator.query(schema.getTimeframesInRangeOptionalQuery),
    apiResponse(async (req: ValidatedRequest<GetTimeframesInRangeByTeam>, res: Response) => {
      const {startTimeFrame, endTimeFrame} = req.query;
      const {teamId} = req.params;

      if (startTimeFrame && endTimeFrame) {
        const engagements = await byTeamAndTimeRange(teamId, startTimeFrame, endTimeFrame);
        res.send(engagements);
      } else {
        const engagements = await byTeam(teamId);
        res.send(engagements);
      }
    })
  );

  doc['/efforts/engagements'] = {
    get: {
      tags,
      operationId: 'getEffortEngagements',
      summary: 'get effort engagements in timeframes range',
      parameters: [
        {
          name: 'startTimeFrame',
          in: 'query',
          description: 'start time frame ID',
          required: true,
          type: 'number',
        },
        {
          name: 'endTimeFrame',
          in: 'query',
          description: 'end time frame ID',
          required: true,
          type: 'number',
        },
      ],

      responses: {
        200: {description: 'List of allocations for given time frames'},
        400: {description: 'Bad request'},
        404: {description: 'Time frames with provided ids not found'},
      },
    },
  };

  router.get(
    '/efforts/engagements',
    validator.query(schema.getTimeframesInRangeQuery),
    apiResponse(async (req: ValidatedRequest<GetTimeframesInRange>, res: Response) => {
      const {startTimeFrame, endTimeFrame} = req.query;
      const engagements = await byTimeFrameIds(startTimeFrame, endTimeFrame);
      res.send(engagements);
    })
  );

  return {router, doc};
};

export default effortEngagementGetActions;
