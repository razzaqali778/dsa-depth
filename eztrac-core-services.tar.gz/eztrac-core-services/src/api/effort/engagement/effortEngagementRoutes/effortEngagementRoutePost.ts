import {Response, Router} from 'express';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {SwaggerDoc} from '../../../../util/swaggerTypes';
import {CreateEngagementsSimple, CreateEngagementsWithCalcInfo, schema} from '../validationSchema';
import {apiResponse} from '../../../../middleware/apiResponse';
import {isAdmin} from '../../../../util/security/isAdmin';
import {addEffortEngagements} from '../effortEngagementService';
import {entitlements} from '../../../../config/entitlementsConfig';
import {getEffortsByIds} from '../../effortService';
import {EffortEngagement, Engagement} from '../models';
const profileMiddleware = require('@monsantoit/profile-middleware');

const validator = createValidator();

const tags = ['efforts-engagements'];

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.effortWrite,
  methods: ['post'],
});

const effortEngagementPostActions = ({router, doc}: {router: Router; doc: SwaggerDoc}) => {
  doc[
    '/efforts/engagements/team/:teamId/timeFrame/:timeFrameId/engagement/:engagementId/calculated'
  ] = {
    post: {
      tags,
      operationId: 'createEffortEngagementsByTeam',
      summary: 'create effort engagements with calculated data',
      parameters: [
        {
          name: 'teamId',
          in: 'path',
          description: 'engagement team ID',
          required: true,
          type: 'string',
        },
        {
          name: 'timeFrameId',
          in: 'path',
          description: 'engagement time frame ID',
          required: true,
          type: 'number',
        },
        {
          name: 'engagementId',
          in: 'path',
          description: 'engagement ID',
          required: true,
          type: 'number',
        },
      ],

      responses: {
        200: {description: 'Engagements had been created'},
        400: {description: 'Bad request'},
        404: {
          description: 'No team with given id and timeframes has been found',
        },
      },
    },
  };

  router.post(
    '/efforts/engagements/team/:teamId/timeFrame/:timeFrameId/engagement/:engagementId/calculated',
    entitlementMiddleware,
    validator.params(schema.engagementQueryParams),
    validator.body(schema.createEngagementWithCalcInfoBody),
    apiResponse(async (req: ValidatedRequest<CreateEngagementsWithCalcInfo>, res: Response) => {
      const admin = isAdmin(req.headers['user-profile']);
      const engagement = {
        engagementId: req.params.engagementId,
        comment: req.body.comment,
        amountDetails: req.body.engagementCalcInfo,
      } as EffortEngagement;
      const {timeFrameId, teamId} = req.params;
      const endTimeFrameId = req.body.endTimeFrameId;
      const affectedEffortIds = await addEffortEngagements(
        timeFrameId,
        endTimeFrameId,
        teamId,
        engagement,
        admin
      );
      const efforts = await getEffortsByIds(affectedEffortIds);
      const cost = efforts.reduce((sum, current) => sum + Number(current.cost), 0);
      res.send({cost});
    })
  );

  doc['/efforts/engagements'] = {
    post: {
      tags,
      operationId: 'createEffortEngagements',
      summary: 'create effort engagements without calculations',
      parameters: [],

      responses: {
        200: {description: 'Engagement has been created'},
        400: {description: 'Bad request'},
        404: {description: 'Not able to find team with provided timeframes'},
      },
    },
  };

  router.post(
    '/efforts/engagements',
    entitlementMiddleware,
    validator.body(schema.createEngagementBody),
    apiResponse(async (req: ValidatedRequest<CreateEngagementsSimple>, res: Response) => {
      const admin = isAdmin(req.headers['user-profile']);
      const engagement = {
        ...req.body,
        amount: BigInt(req.body.amount),
      } as Engagement;
      const {endTimeFrameId, startTimeFrameId, teamId} = req.body;
      const affectedEffortIds = await addEffortEngagements(
        startTimeFrameId,
        endTimeFrameId,
        teamId,
        engagement,
        admin
      );
      const efforts = await getEffortsByIds(affectedEffortIds);
      const cost = efforts.reduce((sum, current) => sum + Number(current.cost), 0);
      res.send({cost});
    })
  );

  return {router, doc};
};

export default effortEngagementPostActions;
