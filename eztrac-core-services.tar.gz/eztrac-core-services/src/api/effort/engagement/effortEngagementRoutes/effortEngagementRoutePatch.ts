import {Response, Router} from 'express';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {SwaggerDoc} from '../../../../util/swaggerTypes';
import {schema, UpdateEngagementsDetails, UpdateEngagementsWithCalcInfo} from '../validationSchema';
import {apiResponse} from '../../../../middleware/apiResponse';
import {updateEngagements} from '../effortEngagementService';
import {isAdmin} from '../../../../util/security/isAdmin';
import {entitlements} from '../../../../config/entitlementsConfig';
import {getEffortsByIds} from '../../effortService';
const profileMiddleware = require('@monsantoit/profile-middleware');

const validator = createValidator();

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.effortWrite,
  methods: ['patch'],
});

const tags = ['efforts-engagements'];

const effortEngagementPatchActions = ({router, doc}: {router: Router; doc: SwaggerDoc}) => {
  doc[
    '/efforts/engagements/team/:teamId/timeFrame/:timeFrameId/engagement/:engagementId/calculated'
  ] = {
    patch: {
      tags,
      operationId: 'createEffortEngagementsByTeam',
      summary: 'create effort engagements with calculated data',
      parameters: [
        {
          name: 'teamId',
          in: 'path',
          description: 'engagement team ID',
          required: true,
          type: 'string',
        },
        {
          name: 'timeFrameId',
          in: 'path',
          description: 'engagement time frame ID',
          required: true,
          type: 'number',
        },
        {
          name: 'engagementId',
          in: 'path',
          description: 'engagement ID',
          required: true,
          type: 'number',
        },
      ],

      responses: {
        200: {description: 'Engagements had been created'},
        400: {description: 'Bad request'},
        404: {
          description: 'No team with given id and timeframes has been found',
        },
      },
    },
  };

  router.patch(
    '/efforts/engagements/team/:teamId/timeFrame/:timeFrameId/engagement/:engagementId/calculated',
    entitlementMiddleware,
    validator.params(schema.engagementQueryParams),
    validator.body(schema.updateEngagementWithCalcInfoBody),
    validator.query(schema.updateEngagementParams),
    apiResponse(async (req: ValidatedRequest<UpdateEngagementsWithCalcInfo>, res: Response) => {
      const {timeFrameId, engagementId, teamId} = req.params;
      const updateAll = !!req.query.all;
      const engagement = {
        engagementId,
        amountDetails: req.body.calcInfo,
        comment: req.body.comment,
      };
      const affectedEffortIds = await updateEngagements(
        timeFrameId,
        teamId,
        engagement,
        isAdmin(req.headers['user-profile']),
        updateAll
      );
      const efforts = await getEffortsByIds(affectedEffortIds);
      const cost = efforts.reduce((sum, current) => sum + Number(current.cost), 0);
      res.send({cost});
    })
  );

  doc['/efforts/engagements/team/:teamId/timeFrame/:timeFrameId/engagement/:engagementId'] = {
    patch: {
      tags,
      operationId: 'getEffortEngagements',
      summary: 'get effort engagements in timeframes range',
      parameters: [],

      responses: {
        200: {description: 'Engagement has been created'},
        400: {description: 'Bad request'},
        404: {description: 'Not able to find team with provided timeframes'},
      },
    },
  };

  router.patch(
    '/efforts/engagements/team/:teamId/timeFrame/:timeFrameId/engagement/:engagementId',
    entitlementMiddleware,
    validator.params(schema.engagementQueryParams),
    validator.body(schema.updateEngagementSimpleBody),
    validator.query(schema.updateEngagementParams),
    apiResponse(async (req: ValidatedRequest<UpdateEngagementsDetails>, res: Response) => {
      const {timeFrameId, engagementId, teamId} = req.params;
      const updateAll = !!req.query.all;
      const engagement = {
        engagementId,
        amount: BigInt(req.body.amount),
        comment: req.body.comment,
      };
      const affectedEffortIds = await updateEngagements(
        timeFrameId,
        teamId,
        engagement,
        isAdmin(req.headers['user-profile']),
        updateAll
      );
      const efforts = await getEffortsByIds(affectedEffortIds);
      const cost = efforts.reduce((sum, current) => sum + Number(current.cost), 0);
      res.send({cost});
    })
  );

  return {router, doc};
};

export default effortEngagementPatchActions;
