import {EngagementCalcInfo} from './models';

export const calculateCost = (arr: EngagementCalcInfo['rates'], hours: number) => {
  return arr && arr.reduce((acc, curr) => acc + curr.people * hours * curr.hourlyRate, 0);
};
