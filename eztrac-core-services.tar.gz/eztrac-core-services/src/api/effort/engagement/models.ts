import {TeamId} from 'src/api/team/models';
import {TimeFrameId} from 'src/api/timeframe/models';
import {EffortId} from '../models';

export type CalendarId = string;
export type NumberOfPeople = number;
export type HourlyRate = number;
export type EngagementComment = string;
export type EngagementCost = bigint;
export type EngagementId = string;

export interface EngagementCalcRate {
  people: NumberOfPeople;
  hourlyRate: HourlyRate;
  comment?: EngagementComment;
}

export interface Engagement {
  amount?: EngagementCost;
  engagementId: EngagementId;
  comment?: string;
  amountDetails?: EngagementCalcInfo;
}

export interface EffortEngagement extends Engagement {
  effortId?: EffortId;
  timeFrameId: TimeFrameId;
  teamId: TeamId;
}

export interface EngagementDTO extends Engagement {
  timeFrameId: TimeFrameId;
  teamId: TeamId;
}

export interface EngagementCalcInfo {
  calendarId: CalendarId;
  rates?: EngagementCalcRate[];
}
