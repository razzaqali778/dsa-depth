import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';
import {convertToBigint} from '../../util/typeConverter';
import {TimeFrameId} from '../timeframe/models';
import {TeamId} from '../team/models';

const getByTeamAndTimeFrame = Joi.object({
  timeFrameId: Joi.number().required().custom(convertToBigint),
  teamId: Joi.string().required(),
});

const getByTeam = Joi.object({
  teamId: Joi.string().required(),
});

const getEffortQuery = Joi.object({
  startTimeFrame: Joi.string().required().custom(convertToBigint),
  endTimeFrame: Joi.string().required().custom(convertToBigint),
});

export interface GetByTeamAndTimeFrameSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    teamId: TeamId;
    timeFrameId: TimeFrameId;
  };
}

export interface GetEffortSchema extends ValidatedRequestSchema {
  [ContainerTypes.Query]: {
    startTimeFrame: TimeFrameId;
    endTimeFrame: TimeFrameId;
  };
  [ContainerTypes.Params]: {
    teamId: TeamId;
  };
}

export const schema = {
  getByTeamAndTimeFrame,
  getByTeam,
  getEffortQuery,
};
