import {CostGroupBreakdown} from '../costcalc/models';
import {GenericParticipant, Participant} from '../person/models';
import {Allocation, EffortAllocation} from './allocation/models';
import {EffortEngagement, Engagement} from './engagement/models';
import {
  EffortId,
  EffortForecastPeople,
  Effort,
  EffortMember,
  EffortCostBreakdown,
  EffortEntity,
} from './models';

type EffortMap<Type> = Map<EffortId, Type[]>;

type WithEffortId = {
  effortId?: EffortId;
};

export class EffortRowSetsToEntity {
  static group<T extends WithEffortId>(values: T[]): EffortMap<T> {
    const resultMap: EffortMap<T> = new Map();
    values.forEach(v => {
      const arrayInMap = resultMap.get(v.effortId!);
      if (!arrayInMap) {
        const array = [v];
        resultMap.set(v.effortId!, array);
      } else {
        arrayInMap.push(v);
      }
    });
    return resultMap;
  }

  static mapToGenericParticipant(
    effortForecastPeople: EffortForecastPeople[] | undefined
  ): GenericParticipant[] {
    if (!effortForecastPeople) {
      return [];
    }
    return effortForecastPeople.map(p => {
      return {
        numberOfPeople: p.numberOfPeople,
        rateId: p.rateId,
        costGroupId: p.costGroupId,
      };
    });
  }

  static mapToParticipant(effortParticipants: EffortMember[]): Participant[] {
    return effortParticipants.map(participant => {
      const {effortId: _effortId, ...rest} = participant;
      return rest;
    });
  }

  static mapToEngagement(effortEngagements: EffortEngagement[]): Engagement[] {
    return effortEngagements.map(engagement => {
      const {effortId: _effortId, ...rest} = engagement;
      return rest;
    });
  }

  static mapToEffortValueObject(
    effortProperty:
      | EffortMember[]
      | EffortEngagement[]
      | EffortAllocation[]
      | EffortCostBreakdown[]
      | EffortForecastPeople[]
  ) {
    return effortProperty.map(property => {
      const {effortId: _effortId, ...rest} = property;
      return rest;
    });
  }

  static parse(
    efforts: Effort[],
    allocations: EffortAllocation[],
    members: EffortMember[],
    forecastPeople?: EffortForecastPeople[],
    engagements?: EffortEngagement[],
    costBreakdowns?: EffortCostBreakdown[]
  ): EffortEntity[] {
    const allocationMap = EffortRowSetsToEntity.group(allocations);
    const memberMap = EffortRowSetsToEntity.group(members);
    const forecastMap = EffortRowSetsToEntity.group(forecastPeople ?? []);
    const engagementMap = EffortRowSetsToEntity.group(engagements ?? []);
    const breakdownMap = EffortRowSetsToEntity.group(costBreakdowns ?? []);
    return (
      efforts.map(e => ({
        id: e.id,
        timeFrameId: e.timeFrameId,
        teamId: e.teamId,
        allocations: (
          EffortRowSetsToEntity.mapToEffortValueObject(
            allocationMap.get(e.id) ?? []
          ) as Allocation[]
        ).map(a => ({
          percentageOfTeamCost: a.percentageOfTeamCost,
          initiativeId: a.initiativeId,
        })),
        members: EffortRowSetsToEntity.mapToEffortValueObject(
          memberMap.get(e.id) ?? []
        ) as Participant[],
        forecastPeople: EffortRowSetsToEntity.mapToEffortValueObject(
          forecastMap.get(e.id) ?? []
        ) as GenericParticipant[],
        engagements: EffortRowSetsToEntity.mapToEffortValueObject(
          engagementMap.get(e.id) ?? []
        ) as Engagement[],
        costBreakdowns: EffortRowSetsToEntity.mapToEffortValueObject(
          breakdownMap.get(e.id) ?? []
        ) as CostGroupBreakdown[],
      })) ?? []
    );
  }
}
