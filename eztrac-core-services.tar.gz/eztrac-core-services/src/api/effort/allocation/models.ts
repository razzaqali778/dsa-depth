import {InitiativeId} from 'src/api/initiative/initiative';
import {TeamId} from 'src/api/team/models';
import {TimeFrameId} from 'src/api/timeframe/models';
import {EffortId} from '../models';

export type PercentageOfTeamCost = bigint;

export interface Allocation {
  initiativeId: InitiativeId;
  percentageOfTeamCost: PercentageOfTeamCost;
}
export interface EffortAllocation extends Allocation {
  effortId: EffortId;
  timeFrameId: TimeFrameId;
  teamId: TeamId;
}

export interface TimeFrameAllocation {
  timeFrameId: TimeFrameId;
  allocations: Allocation[];
}
