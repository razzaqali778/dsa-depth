import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';
import {TimeFrameAllocation} from './models';
import {convertToBigint} from '../../../util/typeConverter';
import {TimeFrameId} from '../../timeframe/models';

const allocationSchema = Joi.object().keys({
  initiativeId: Joi.string().required(),
  percentageOfTeamCost: Joi.number().integer().required().min(0).custom(convertToBigint),
});

const timeFrameAllocationSchema = Joi.object().keys({
  timeFrameId: Joi.number().required().custom(convertToBigint),
  allocations: Joi.array().items(allocationSchema),
});

const getEffortAllocationParamsSchema = Joi.object({
  timeFrameId: Joi.string().required().custom(convertToBigint),
});

const updateEffortAllocationBodySchema = Joi.array().min(1).items(timeFrameAllocationSchema);
const updateEffortAllocationParamsSchema = Joi.object({
  teamId: Joi.string().required(),
});

export interface GetEffortAllocationSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {timeFrameId: TimeFrameId};
}

export interface UpdateEffortAllocationSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: TimeFrameAllocation[];
  [ContainerTypes.Params]: {teamId: string};
}

export const schema = {
  getEffortAllocationParamsSchema,
  updateEffortAllocationBodySchema,
  updateEffortAllocationParamsSchema,
};
