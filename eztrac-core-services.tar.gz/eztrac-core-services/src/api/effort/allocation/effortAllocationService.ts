import {container} from 'tsyringe';
import {AppContext} from '../../AppContext';
import {Allocation, EffortAllocation} from './models';
import {NotFoundError} from '../../types/NotFoundError';
import {TimeFrameAllocation} from './models';
import {TimeFrameId} from '../../timeframe/models';
import {TeamId} from '../../team/models';
import {getTeamByIdOrThrow} from '../../team/teamService';
import {
  getOrCreateEfforts,
  updateEfforts,
  validateUserIsAuthorizedToModifyChosenTimeFrames,
} from '../effortService';
import {BadRequestError} from '../../types/BadRequestError';

const validateAllocations = (allocations: Allocation[]) => {
  const percentageSum = allocations.reduce(
    (sum, current) => sum + current.percentageOfTeamCost,
    0n
  );
  if (percentageSum < 0n) {
    throw new BadRequestError('Unable to assign negative percentage of team cost.');
  }
  if (percentageSum > 100n) {
    throw new BadRequestError('Unable to assign more than 100% to percentage of team cost.');
  }
};

const validateTimeFrameIdIsDuplicated = async (timeFrameIds: TimeFrameId[]) => {
  const set = new Set<TimeFrameId>();
  const duplicateEffortIdRequests: TimeFrameId[] = [];

  for (const t of timeFrameIds) {
    if (set.has(t)) {
      duplicateEffortIdRequests.push(t);
    } else {
      set.add(t);
    }
  }

  if (duplicateEffortIdRequests.length > 0) {
    throw new BadRequestError(
      `Unable to add a separate allocation with a duplicated timeFrameId (${duplicateEffortIdRequests.join(
        ', '
      )})`
    );
  }
};

const createOrUpdateAllocations = async (
  teamId: TeamId,
  timeFrameAllocations: TimeFrameAllocation[],
  isAdmin: boolean
) => {
  const r = container.resolve(AppContext).repositories;
  const timeFrameIds = timeFrameAllocations.map(tfa => tfa.timeFrameId);
  await validateUserIsAuthorizedToModifyChosenTimeFrames(timeFrameIds, isAdmin, r);
  await validateTimeFrameIdIsDuplicated(timeFrameIds);
  const efforts = await getOrCreateEfforts(timeFrameIds, teamId);

  const modifiedEfforts = efforts.map(effort => {
    const allocations = timeFrameAllocations.find(
      tfa => tfa.timeFrameId === effort.timeFrameId
    )?.allocations;
    return {
      ...effort,
      allocations: allocations,
    };
  });
  return updateEfforts(modifiedEfforts, false);
};

export const byTimeFrame = async function (timeFrameId: TimeFrameId): Promise<EffortAllocation[]> {
  const r = container.resolve(AppContext).repositories;
  const timeFrame = await r.timeFrameRepository.getTimeFrameById(timeFrameId);
  if (!timeFrame) {
    throw new NotFoundError(`Unable to find time frame with id of ${timeFrameId}`);
  }
  const effortAllocations = await r.effortAllocationsRepository.getEffortAllocationsByTimeFrame(
    timeFrameId
  );
  return effortAllocations;
};

export const updateEffortAllocations = async function (
  teamId: TeamId,
  timeFrameAllocations: TimeFrameAllocation[],
  isAdmin: boolean
) {
  timeFrameAllocations.forEach(tfa => validateAllocations(tfa.allocations));

  await getTeamByIdOrThrow(teamId);

  return createOrUpdateAllocations(teamId, timeFrameAllocations, isAdmin);
};
