import {Response} from 'express';
import {byTimeFrame, updateEffortAllocations} from './effortAllocationService';
import {SwaggerDoc} from '../../../util/swaggerTypes';
import {apiResponse} from '../../../middleware/apiResponse';
import {ValidatedRequest, createValidator} from 'express-joi-validation';
import {GetEffortAllocationSchema, schema, UpdateEffortAllocationSchema} from './validationSchema';
import {entitlements} from '../../../config/entitlementsConfig';
import {isAdmin} from '../../../util/security/isAdmin';
import {StatusCodes} from 'http-status-codes';
const profileMiddleware = require('@monsantoit/profile-middleware');

const router = require('express').Router();
const validator = createValidator();

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.effortWrite,
  methods: ['patch'],
});

const doc: SwaggerDoc = {};

const tags = ['efforts-allocations'];

doc['/efforts/allocations/timeframes/:timeFrameId'] = {
  get: {
    tags,
    operationId: 'getEffortAllocation',
    summary: 'get effort allocation by time frame id',
    parameters: [
      {
        name: 'timeFrameId',
        in: 'path',
        description: 'time frame id',
        required: true,
        type: 'string',
      },
    ],

    responses: {
      200: {description: 'List of allocations for given time frame'},
      400: {description: 'Bad request'},
      404: {description: 'Time frame with given id not found'},
    },
  },
};

router.get(
  '/efforts/allocations/timeframes/:timeFrameId',
  validator.params(schema.getEffortAllocationParamsSchema),
  apiResponse(async (req: ValidatedRequest<GetEffortAllocationSchema>, res: Response) => {
    const {timeFrameId} = req.params;
    const result = await byTimeFrame(timeFrameId);
    res.send(result);
  })
);

doc['/efforts/allocations/team/:teamId'] = {
  patch: {
    tags,
    operationId: 'update-allocation',
    summary: 'update allocations for a team and multiple timeframes',
    responses: {
      200: {description: 'Cost of updated efforts'},
      400: {description: 'Bad request'},
      404: {description: 'Team with given id not found'},
    },
  },
};

router.patch(
  '/efforts/allocations/team/:teamId',
  entitlementMiddleware,
  validator.params(schema.updateEffortAllocationParamsSchema),
  validator.body(schema.updateEffortAllocationBodySchema),
  apiResponse(async (req: ValidatedRequest<UpdateEffortAllocationSchema>, res: Response) => {
    const teamId = req.params.teamId;
    const effortAllocations = req.body;
    await updateEffortAllocations(teamId, effortAllocations, isAdmin(req.headers['user-profile']));

    res.sendStatus(StatusCodes.OK);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
