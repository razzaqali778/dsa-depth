import {container} from 'tsyringe';
import {AppContext} from '../../AppContext';
import {EffortAllocation} from './models';
import {TimeFrameId} from 'src/api/timeframe/models';
import {TeamId} from '../../team/models';
import {EffortId} from '../models';

const effortAllocationQuery = `SELECT team_cost.team_cost_id as "effortId",
                                      team_cost.timeFrame_id as "timeFrameId",
                                      team_cost.team_id as "teamId",
                                      team_cost_allocation.team_cost_pct as "percentageOfTeamCost",
                                      team_cost_allocation.vip_initiative_id as "initiativeId"
                              FROM public.team_cost as team_cost
                              JOIN public.team_cost_allocation as team_cost_allocation
                              ON team_cost.team_cost_id = team_cost_allocation.team_cost_id`;

export interface EffortAllocationsRepository {
  getEffortAllocationsByTeamsAndTimeFrames(
    teamIds: TeamId[],
    timeFrameIds: TimeFrameId[]
  ): Promise<EffortAllocation[]>;
  getEffortAllocationsByTimeFrame(timeFrameId: TimeFrameId): Promise<EffortAllocation[]>;
  getEffortAllocationsByTimeRange(
    startTimeFrame: TimeFrameId,
    endTimeFrame: TimeFrameId
  ): Promise<EffortAllocation[]>;
  getAllocationsByEffortIds(effortIds: EffortId[]): Promise<EffortAllocation[]>;
}

export const effortAllocationsRepository: EffortAllocationsRepository = {
  async getEffortAllocationsByTeamsAndTimeFrames(
    teamIds: TeamId[],
    timeFrameIds: TimeFrameId[]
  ): Promise<EffortAllocation[]> {
    if (!teamIds?.length || !timeFrameIds?.length) return [];

    const db = container.resolve(AppContext).db;
    const sql = `
      ${effortAllocationQuery}
      WHERE team_cost.timeframe_id in ($1:csv)
      AND team_cost.team_id in ($2:csv)`;
    return db.any<EffortAllocation>(sql, [timeFrameIds.map(id => Number(id)), teamIds]);
  },

  getEffortAllocationsByTimeFrame(timeFrameId: TimeFrameId): Promise<EffortAllocation[]> {
    const db = container.resolve(AppContext).db;
    const sql = `
      ${effortAllocationQuery}
      WHERE team_cost.timeFrame_id = $<timeFrameId>
      ORDER BY team_cost.team_id, team_cost_allocation.vip_initiative_id`;
    return db.any<EffortAllocation>(sql, {timeFrameId});
  },

  getEffortAllocationsByTimeRange(startTimeFrame, endTimeFrame): Promise<EffortAllocation[]> {
    const db = container.resolve(AppContext).db;
    const sql = `
      ${effortAllocationQuery}
      JOIN public.timeframe as startTimeFrame
        ON startTimeFrame.timeframe_id = $<startTimeFrame>
      JOIN public.timeframe as endTimeFrame
        ON endTimeFrame.timeframe_id = $<endTimeFrame>
      JOIN public.timeframe as timeframe
        ON timeframe.timeframe_start_date >= startTimeFrame.timeframe_start_date
          AND timeframe.timeframe_end_date <= endTimeFrame.timeframe_end_date
          AND timeframe.timeframe_id = team_cost.timeframe_id`;
    return db.any<EffortAllocation>(sql, {startTimeFrame, endTimeFrame});
  },

  async getAllocationsByEffortIds(effortIds) {
    if (!effortIds?.length) return [];

    const db = container.resolve(AppContext).db;
    const sql = `
        ${effortAllocationQuery}
        WHERE team_cost.team_cost_id in ($1:csv)
      `;
    return db.manyOrNone(sql, [effortIds]);
  },
};
