import {CostGroupBreakdown, CostValue} from '../costcalc/models';
import {GenericParticipant, Participant} from '../person/models';
import {TeamId} from '../team/models';
import {TimeFrameId} from '../timeframe/models';
import {Allocation} from './allocation/models';
import {EngagementId, Engagement} from './engagement/models';

export type EffortId = bigint;
export type PersonId = string;
export type RateId = string;
export type CostGroupId = string;

export interface EffortCostBreakdown {
  effortId: EffortId;
  costGroupId: CostGroupId;
  cost: CostValue;
  engagementId?: EngagementId;
  personId?: PersonId;
}

export interface EffortEntity {
  id?: EffortId;
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  allocations?: Allocation[];
  members?: Participant[];
  forecastPeople?: GenericParticipant[];
  engagements?: Engagement[];
  costBreakdowns?: CostGroupBreakdown[];
}

export interface Effort {
  id: EffortId;
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  cost: BigInt;
}

export interface EffortMember extends Participant {
  effortId: EffortId;
}

export interface EffortForecastPeople extends GenericParticipant {
  effortId: EffortId;
}

export interface CostBreakdownValueObject {
  timeFrameId: TimeFrameId;
  teamId: TeamId;
  cost?: number;
}
