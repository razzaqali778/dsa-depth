import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {CreateTeamModel, Team, TeamId, TeamStructure} from './models';
import {TimeFrameId} from '../timeframe/models';
import {ParameterizedQuery} from 'pg-promise';
import {PlatformId} from '../platform/models';
import {CommunityId} from '../community/models';

export interface TeamRepository {
  getTeamById(id: TeamId): Promise<Team | null>;

  getTeamsWithStructureByTimeFrameId(timeFrameId: TimeFrameId): Promise<TeamStructure[] | null>;

  getTeamsWithStructure(): Promise<TeamStructure[]>;

  getTeamsWithStructureByPlatformId(platformId: PlatformId): Promise<TeamStructure[]>;

  getTeamsWithStructureByCommunityId(communityId: CommunityId): Promise<TeamStructure[]>;

  getTeamsWithStructureByTeamIds(teamIds: TeamId[]): Promise<TeamStructure[]>;

  getTeamsWithQuery(q: string): Promise<Team[]>;

  getTeamsWithActiveFilter(isActive: boolean): Promise<Team[]>;

  getAllTeams(): Promise<Team[]>;

  update(teamId: TeamId, team: Team): Promise<null>;

  create(team: CreateTeamModel, id: TeamId): Promise<null>;
}

const teamStructureQuery = `SELECT team.team_id                as "teamId",
                                   team_name              as "teamName",
                                   community.community_id as "communityId",
                                   team.is_active         as "isActive",
                                   community_name         as "communityName",
                                   platform.platform_id   as "platformId",
                                   platform_name          as "platformName",
                                   org.org_id             as "orgId",
                                   org_name               as "orgName"
                            FROM public.team as team
                                   join public.community as community
                                        on team.community_id = community.community_id
                                   join public.platform as platform on community.platform_id = platform.platform_id
                                   join public.org as org on platform.org_id = org.org_id`;

export const teamRepository: TeamRepository = {
  getTeamById(teamId: TeamId): Promise<Team | null> {
    const db = container.resolve(AppContext).db;
    const sql = `SELECT team_id      as "id",
                        team_name    as "name",
                        community_id as "communityId",
                        is_active    as "isActive"
                 FROM public.team
                 WHERE team_id = $<teamId>`;
    return db.oneOrNone<Team>(sql, {teamId});
  },
  getTeamsWithStructureByTimeFrameId(timeFrameId: TimeFrameId): Promise<TeamStructure[] | null> {
    const db = container.resolve(AppContext).db;
    const sql = `${teamStructureQuery}
                 JOIN public.team_cost AS team_cost ON team.team_id = team_cost.team_id
                 WHERE team_cost.timeframe_id = $<timeFrameId>`;
    return db.any(sql, {timeFrameId});
  },
  getTeamsWithStructure(): Promise<TeamStructure[]> {
    const db = container.resolve(AppContext).db;
    const sql = `${teamStructureQuery}`;
    return db.any<TeamStructure>(sql);
  },
  getTeamsWithStructureByPlatformId(platformId: PlatformId): Promise<TeamStructure[]> {
    const db = container.resolve(AppContext).db;
    const sql = `${teamStructureQuery}
                     WHERE platform.platform_id = $<platformId>`;
    return db.any<TeamStructure>(sql, {platformId});
  },
  getTeamsWithStructureByCommunityId(communityId: CommunityId): Promise<TeamStructure[]> {
    const db = container.resolve(AppContext).db;
    const sql = `${teamStructureQuery}
                     WHERE community.community_id = $<communityId>`;
    return db.any<TeamStructure>(sql, {communityId});
  },
  async getTeamsWithStructureByTeamIds(teamIds: TeamId[]): Promise<TeamStructure[]> {
    if (!teamIds?.length) return [];
    const db = container.resolve(AppContext).db;
    const sql = `${teamStructureQuery}
                     WHERE team_id in ($1:csv)`;
    return db.any<TeamStructure>(sql, [teamIds]);
  },
  getTeamsWithQuery(queryString: string): Promise<Team[]> {
    const db = container.resolve(AppContext).db;
    const sql = `SELECT team_id      as "id",
                        team_name    as "name",
                        community_id as "communityId",
                        is_active    as "isActive"
                 FROM public.team
                 WHERE is_active = true
                   AND team_name ILIKE $1`;

    const query = new ParameterizedQuery({text: sql, values: [`%${queryString}%`]});
    return db.any<Team>(query);
  },
  getTeamsWithActiveFilter(isActive: boolean): Promise<Team[]> {
    const db = container.resolve(AppContext).db;
    const sql = `SELECT team_id      as "id",
                        team_name    as "name",
                        community_id as "communityId",
                        is_active    as "isActive"
                 FROM public.team
                 WHERE is_active = $<isActive>`;
    return db.any<Team>(sql, {isActive});
  },
  getAllTeams(): Promise<Team[]> {
    const db = container.resolve(AppContext).db;
    const sql = `SELECT team_id      as "id",
                        team_name    as "name",
                        community_id as "communityId",
                        is_active    as "isActive"
                 FROM public.team`;
    return db.any<Team>(sql);
  },

  update(teamId: TeamId, team: Team): Promise<null> {
    const db = container.resolve(AppContext).db;
    const sql = `UPDATE public.team
                 SET team_name = $<name>, community_id = $<communityId>, is_active = $<isActive>
                 WHERE team_id = $<teamId>`;
    return db.none(sql, {teamId, ...team});
  },

  create(team: CreateTeamModel, id: TeamId): Promise<null> {
    const db = container.resolve(AppContext).db;
    const sql = `INSERT INTO public.team (team_id, team_name, community_id, is_active)
      VALUES ($<id>, $<name>, $<communityId>, $<isActive>)`;
    return db.none(sql, {id, ...team});
  },
};
