import {NameToId} from '../../util/nameToId';
import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {AppRepositories} from '../AppRepositories';
import {BadRequestError} from '../types/BadRequestError';
import {NotFoundError} from '../types/NotFoundError';
import {TeamStructure, Team, TeamId, CreateTeamModel} from './models';

async function validateTeamCanBeDeactivated(r: AppRepositories, teamId: TeamId) {
  const futureEfforts = await r.effortRepository.getEffortsByTeamAndStartDate(teamId, new Date());
  if (futureEfforts && futureEfforts.length > 0) {
    throw new BadRequestError(
      `Team ${teamId} can't be deactivated because it is assigned to future efforts`
    );
  }
}

export const getTeamsWithStructure = function (): Promise<TeamStructure[]> {
  const r = container.resolve(AppContext).repositories;
  return r.teamRepository.getTeamsWithStructure();
};

export const getTeamsWithQuery = function (q: string): Promise<Team[]> {
  const r = container.resolve(AppContext).repositories;
  return r.teamRepository.getTeamsWithQuery(q);
};

export const getTeamsWithActiveFilter = function (isActive: boolean): Promise<Team[]> {
  const r = container.resolve(AppContext).repositories;
  return r.teamRepository.getTeamsWithActiveFilter(isActive);
};

export const getTeamByIdOrThrow = async function (teamId: TeamId): Promise<Team> {
  const r = container.resolve(AppContext).repositories;
  const team = await r.teamRepository.getTeamById(teamId);
  if (!team) {
    throw new NotFoundError(`Unable to find team with id of ${teamId}`);
  }
  return team;
};

export const updateTeam = async function (teamId: TeamId, updatedTeam: Team): Promise<Team> {
  const r = container.resolve(AppContext).repositories;
  const existingTeam = await getTeamByIdOrThrow(teamId);
  if (existingTeam.isActive && !updatedTeam.isActive) {
    await validateTeamCanBeDeactivated(r, teamId);
  }
  await r.teamRepository.update(teamId, updatedTeam);
  return getTeamByIdOrThrow(teamId);
};

export const createTeam = async function (team: CreateTeamModel): Promise<Team> {
  const id = NameToId(team.name);
  if (id === '') {
    throw new BadRequestError('Invalid team name was provided');
  }
  const r = container.resolve(AppContext).repositories;
  const teamExists = await r.teamRepository.getTeamById(id);
  if (teamExists) {
    throw new BadRequestError('Team with given name already exists');
  }
  await r.teamRepository.create(team, id);
  return getTeamByIdOrThrow(id);
};

export const getAllTeams = function (): Promise<Team[]> {
  const r = container.resolve(AppContext).repositories;
  return r.teamRepository.getAllTeams();
};
