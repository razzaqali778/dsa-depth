import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';
import {CreateTeamModel, Team} from './models';

const getTeamsQuery = Joi.object({
  q: Joi.string().allow(''),
  isActive: Joi.boolean(),
});

const getById = Joi.object({
  teamId: Joi.string().required(),
});

const updateTeamBody = Joi.object({
  id: Joi.string().required(),
  name: Joi.string().required(),
  communityId: Joi.string().required(),
  isActive: Joi.boolean().required(),
});

const createTeamBody = Joi.object({
  name: Joi.string().required(),
  communityId: Joi.string().required(),
  isActive: Joi.boolean().required(),
});

export interface GetTeamsSchema extends ValidatedRequestSchema {
  [ContainerTypes.Query]: {
    q?: string;
    isActive?: boolean;
  };
}

export interface GetTeamById extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    teamId: string;
  };
}

export interface UpdateTeamById extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    teamId: string;
  };
  [ContainerTypes.Body]: Team;
}

export interface CreateTeam extends ValidatedRequestSchema {
  [ContainerTypes.Body]: CreateTeamModel;
}

export const schema = {
  getTeamsQuery,
  getById,
  updateTeamBody,
  createTeamBody,
};
