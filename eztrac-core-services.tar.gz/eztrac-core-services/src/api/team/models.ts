import {CommunityId} from '../community/models';
import {OrgId, OrgName} from '../org/models';
import {PlatformId} from '../platform/models';

export type TeamName = string;
export type TeamId = string;

export interface Team {
  id: TeamId;
  name: TeamName;
  communityId: CommunityId;
  isActive: boolean;
}

export interface CreateTeamModel {
  name: TeamName;
  communityId: CommunityId;
  isActive: boolean;
}

export interface TeamStructure {
  teamId: TeamId;
  teamName: TeamName;
  communityId: CommunityId;
  communityName: TeamName;
  platformId: PlatformId;
  platformName: TeamName;
  orgId: OrgId;
  orgName: OrgName;
  isActive: boolean;
}
