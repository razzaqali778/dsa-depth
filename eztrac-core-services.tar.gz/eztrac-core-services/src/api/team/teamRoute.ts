import express, {Request, Response} from 'express';
import {
  getAllTeams,
  getTeamsWithActiveFilter,
  getTeamsWithQuery,
  getTeamsWithStructure,
  getTeamByIdOrThrow,
  updateTeam,
  createTeam,
} from './teamService';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {apiResponse} from '../../middleware/apiResponse';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {CreateTeam, GetTeamById, GetTeamsSchema, schema, UpdateTeamById} from './validationSchema';
import {entitlements} from '../../config/entitlementsConfig';
const profileMiddleware = require('@monsantoit/profile-middleware');

const router = express.Router();
const validator = createValidator();

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.modifyTeam,
  methods: ['post', 'put'],
});

const doc: SwaggerDoc = {};

const tags = ['team'];

doc['/teamStructure'] = {
  get: {
    tags,
    operationId: 'teamStructure',
    summary: 'team structure call',
    responses: {
      200: {description: 'Success'},
    },
  },
};

router.get(
  '/teamStructure',
  apiResponse(async (req: Request, res: Response) => {
    const result = await getTeamsWithStructure();
    res.send(result);
  })
);

doc['/teams'] = {
  get: {
    tags,
    operationId: 'teams',
    parameters: [
      {
        name: 'q',
        in: 'query',
        description: 'Query string',
        required: false,
        type: 'string',
      },
      {
        name: 'isActive',
        in: 'query',
        description: 'Selects active or inactive teams.',
        required: false,
        type: 'boolean',
      },
    ],
    summary: 'teams call',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
    },
  },
};

router.get(
  '/teams',
  validator.query(schema.getTeamsQuery),
  apiResponse(async (req: ValidatedRequest<GetTeamsSchema>, res: Response) => {
    let result;
    const {q, isActive} = req.query;
    if (q !== undefined) {
      result = await getTeamsWithQuery(q);
    } else if (isActive !== undefined) {
      result = await getTeamsWithActiveFilter(isActive);
    } else {
      result = await getAllTeams();
    }
    res.send(result);
  })
);

doc['/team/{teamId}'] = {
  get: {
    tags,
    operationId: 'teamById',
    parameters: [
      {
        name: 'teamId',
        in: 'path',
        description: 'teamId',
        required: true,
        type: 'string',
      },
    ],
    summary: 'get team by id',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      404: {description: 'Team not found'},
    },
  },
  put: {
    tags,
    operationId: 'updateTeam',
    parameters: [
      {
        name: 'teamId',
        in: 'path',
        description: 'teamId',
        required: true,
        type: 'string',
      },
    ],
    summary: 'update team by id',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      403: {description: 'Forbidden'},
      404: {description: 'Team not found'},
    },
  },
};

router.get(
  '/team/:teamId',
  validator.params(schema.getById),
  apiResponse(async (req: ValidatedRequest<GetTeamById>, res: Response) => {
    const result = await getTeamByIdOrThrow(req.params.teamId);
    res.send(result);
  })
);

router.put(
  '/team/:teamId',
  entitlementMiddleware,
  // validator.params(schema.getById),
  validator.body(schema.updateTeamBody),
  apiResponse(async (req: ValidatedRequest<UpdateTeamById>, res: Response) => {
    const result = await updateTeam(req.params.teamId, req.body);
    res.send(result);
  })
);

doc['/team'] = {
  post: {
    tags,
    operationId: 'createTeam',
    summary: 'create team',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
      403: {description: 'Forbidden'},
    },
  },
};

router.post(
  '/team',
  entitlementMiddleware,
  validator.body(schema.createTeamBody),
  apiResponse(async (req: ValidatedRequest<CreateTeam>, res: Response) => {
    const result = await createTeam(req.body);
    res.send(result);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
