import Joi from 'joi';
import {ContainerTypes, ValidatedRequestSchema} from 'express-joi-validation';

const getPlatformsQuery = Joi.object({
  isActive: Joi.boolean(),
});

const createPlatformBody = Joi.object({
  name: Joi.string().required(),
  isActive: Joi.boolean().required(),
  orgId: Joi.string().required(),
});

const updatePlatformBody = Joi.object({
  name: Joi.string().required(),
  isActive: Joi.boolean().required(),
  orgId: Joi.string().required(),
});

const updatePlatformParams = Joi.object({
  platformId: Joi.string().required(),
});

export interface GetPlatformsSchema extends ValidatedRequestSchema {
  [ContainerTypes.Query]: {
    isActive?: boolean;
  };
}

export interface CreatePlatformSchema extends ValidatedRequestSchema {
  [ContainerTypes.Body]: {
    name: string;
    isActive: boolean;
    orgId: string;
  };
}

export interface UpdatePlatformSchema extends ValidatedRequestSchema {
  [ContainerTypes.Params]: {
    platformId: string;
  };
  [ContainerTypes.Body]: {
    name: string;
    isActive: boolean;
    orgId: string;
  };
}

export const schema = {
  getPlatformsQuery,
  createPlatformBody,
  updatePlatformBody,
  updatePlatformParams,
};
