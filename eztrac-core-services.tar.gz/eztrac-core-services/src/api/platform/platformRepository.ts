import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {CreatePlatformModel, Platform, PlatformId} from './models';

export interface PlatformRepository {
  getPlatforms(isActive?: boolean): Promise<Platform[]>;
  getPlatformById(id: string): Promise<Platform | null>;
  createPlatform(platform: CreatePlatformModel, id: PlatformId): Promise<Platform>;
  updatePlatform(platform: Platform): Promise<Platform>;
}

function createPlatformFilter(isActive: boolean | undefined) {
  return typeof isActive !== 'undefined' ? 'WHERE is_active =$<isActive>' : '';
}

const platformSelectQuery = `SELECT platform_id   as "id",
                                    platform_name as "name",
                                    is_active     as "isActive",
                                    org_id        as "orgId"
                            FROM public.platform`;

export const platformRepository: PlatformRepository = {
  getPlatforms(isActive?: boolean): Promise<Platform[]> {
    const db = container.resolve(AppContext).db;
    const filter = createPlatformFilter(isActive);
    const sql = `${platformSelectQuery} ${filter}
    `;
    return db.any<Platform>(sql, {isActive});
  },
  getPlatformById(id: string): Promise<Platform | null> {
    const db = container.resolve(AppContext).db;

    const sql = `${platformSelectQuery}
           WHERE platform_id = $<id>`;
    return db.oneOrNone<Platform>(sql, {id});
  },
  createPlatform(platform: CreatePlatformModel, id: PlatformId): Promise<Platform> {
    const db = container.resolve(AppContext).db;
    const sql = `INSERT INTO public.platform (platform_id, platform_name, is_active, org_id)
                 VALUES ($<id>, $<platform.name>, $<platform.isActive>, $<platform.orgId>)
                 RETURNING platform_id as "id", platform_name as "name", is_active as "isActive", org_id as "orgId"
    `;
    return db.one<Platform>(sql, {id, platform});
  },
  updatePlatform(platform: Platform): Promise<Platform> {
    const db = container.resolve(AppContext).db;
    const sql = `UPDATE public.platform
                 SET platform_name = $<name>, is_active = $<isActive>, org_id = $<orgId>
                 WHERE platform_id = $<id>
                 RETURNING platform_id as "id", platform_name as "name", is_active as "isActive", org_id as "orgId"
    `;
    return db.one<Platform>(sql, platform);
  },
};
