import {container} from 'tsyringe';
import {AppContext} from '../AppContext';
import {CreatePlatformModel, Platform, PlatformId} from './models';
import {NameToId} from '../../util/nameToId';
import {BadRequestError} from '../types/BadRequestError';
import {NotFoundError} from '../types/NotFoundError';
import {getOrgByIdOrThrow} from '../org/orgService';

export const getPlatformByIdOrThrow = async function (platformId: PlatformId): Promise<Platform> {
  const r = container.resolve(AppContext).repositories;
  const platform = await r.platformRepository.getPlatformById(platformId);
  if (!platform) {
    throw new NotFoundError(`Unable to find platform with id of ${platformId}`);
  }
  return platform;
};

export const getPlatforms = function (isActive?: boolean): Promise<Platform[]> {
  const r = container.resolve(AppContext).repositories;
  return r.platformRepository.getPlatforms(isActive);
};

export const createPlatform = async function (platform: CreatePlatformModel): Promise<Platform> {
  const id = NameToId(platform.name);
  if (id === '') {
    throw new BadRequestError('Invalid platform name was provided');
  }
  const r = container.resolve(AppContext).repositories;
  const platformExists = await r.platformRepository.getPlatformById(id);
  if (platformExists) {
    throw new BadRequestError('Platform with given name already exists');
  }
  await getOrgByIdOrThrow(platform.orgId);
  return r.platformRepository.createPlatform(platform, id);
};

export const updatePlatform = async function (platform: Platform): Promise<Platform> {
  const r = container.resolve(AppContext).repositories;
  await getPlatformByIdOrThrow(platform.id);
  await getOrgByIdOrThrow(platform.orgId);
  return r.platformRepository.updatePlatform(platform);
};
