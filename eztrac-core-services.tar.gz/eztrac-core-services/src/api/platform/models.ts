import {OrgId} from '../org/models';

export type PlatformId = string;
export type PlatformName = string;

export interface Platform {
  id: PlatformId;
  name: PlatformName;
  isActive: boolean;
  orgId: OrgId;
}

export interface CreatePlatformModel {
  name: PlatformName;
  isActive: boolean;
  orgId: OrgId;
}
