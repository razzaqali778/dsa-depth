import express, {Response} from 'express';
import {SwaggerDoc} from '../../util/swaggerTypes';
import {apiResponse} from '../../middleware/apiResponse';
import {createValidator, ValidatedRequest} from 'express-joi-validation';
import {entitlements} from '../../config/entitlementsConfig';
import {
  CreatePlatformSchema,
  GetPlatformsSchema,
  schema,
  UpdatePlatformSchema,
} from './validationSchema';
import {createPlatform, getPlatforms, updatePlatform} from './platformService';
const profileMiddleware = require('@monsantoit/profile-middleware');

const router = express.Router();
const validator = createValidator();

const entitlementMiddleware = profileMiddleware({
  entitlements: entitlements.adminOnly,
  methods: ['post', 'put'],
});

const doc: SwaggerDoc = {};

const tags = ['platform'];

doc['/platforms'] = {
  get: {
    tags,
    operationId: 'platforms',
    parameters: [
      {
        name: 'isActive',
        in: 'query',
        description: 'Selects active or inactive platforms.',
        required: false,
        type: 'boolean',
      },
    ],
    summary: 'platforms call',
    responses: {
      200: {description: 'Success'},
      400: {description: 'Bad request'},
    },
  },
};

router.get(
  '/platforms',
  entitlementMiddleware,
  validator.query(schema.getPlatformsQuery),
  apiResponse(async (req: ValidatedRequest<GetPlatformsSchema>, res: Response) => {
    const {isActive} = req.query;
    const result = await getPlatforms(isActive);
    res.send(result);
  })
);

router.post(
  '/platforms',
  entitlementMiddleware,
  validator.body(schema.createPlatformBody),
  apiResponse(async (req: ValidatedRequest<CreatePlatformSchema>, res: Response) => {
    const result = await createPlatform(req.body);
    res.send(result);
  })
);

router.put(
  '/platforms/:platformId',
  entitlementMiddleware,
  validator.body(schema.updatePlatformBody),
  validator.params(schema.updatePlatformParams),
  apiResponse(async (req: ValidatedRequest<UpdatePlatformSchema>, res: Response) => {
    const {platformId} = req.params;
    const result = await updatePlatform({...req.body, id: platformId});
    res.send(result);
  })
);

export default {
  router,
  swaggerPaths: doc,
  swaggerDefinitions: {},
};
