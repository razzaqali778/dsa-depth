import {Config, source, processor, env} from '@monsantoit/config';
import {Config as ConfigType} from './files/default';
const {determineEnvironmentFileName, isFargate} = require('@monsantoit/config-velocity-store');

console.info(
  `NODE_ENV: ${process.env.NODE_ENV}, FARGATE_ENV: ${process.env.FARGATE_ENV}, isFargate: ${isFargate}`
);

// Build in Jenkins or CodeBuild
const inCI = process.argv.indexOf('--ci') > -1;

const environmentFileName =
  process.env.NODE_ENV === 'production' && isFargate
    ? `${determineEnvironmentFileName()}`
    : `${process.env.CONFIG_ENV || process.env.NODE_ENV || 'default'}`;

console.info(
  `Configuration Environment - IsFargate: ${isFargate}, environmentFileName: ${environmentFileName}`
);

const config = new Config<ConfigType>({
  sources: [
    source.fromJS({
      src: `${__dirname}/files/${environmentFileName || 'default'}`,
    }),
  ],
  processors: [
    processor.readVaultFromConfig({
      enabled: env.inDevelopment || (env.inIntegrationTest && !inCI),
      auth: {type: 'local'},
    }),
    processor.readVaultFromConfig({
      enabled: env.inIntegrationTest && inCI,
      auth: {
        type: 'appRole',
        roleId: process.env.APPROLE_ID,
        secretId: process.env.APPROLE_SECRET,
      },
    }),
    processor.readVaultFromConfig({
      enabled: env.inProduction && isFargate,
      auth: {
        type: 'awsRole',
        roleName: {inConfig: 'eztrac-approle.role_name'},
      },
    }),
  ],
  required: [],
});

export default config;
