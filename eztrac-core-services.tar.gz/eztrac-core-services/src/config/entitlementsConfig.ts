export const entitlementAppName = 'eztrac';

export const entitlements = {
  effortWrite: ['eztrac-write-user', 'eztrac-manage-efforts', 'eztrac-admin-user'],
  adminOnly: ['eztrac-admin-user'],
  modifyTeam: ['eztrac-manage-teams', 'eztrac-admin-user'],
};
