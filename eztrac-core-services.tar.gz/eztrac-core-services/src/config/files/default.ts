const config: Config = {
  'oauth-client': {
    id: 'vault://secret/ez-trac/core-services/np/oauth-azure/client-id',
    secret: 'vault://secret/ez-trac/core-services/np/oauth-azure/client-secret',
  },
  coreDb: {
    user: 'vault://secret/ez-trac/core-services/np/db/app-user-name',
    password: 'vault://secret/ez-trac/core-services/np/db/app-user-password',
    host: 'vault://secret/ez-trac/np/db/host',
    port: 5432,
    database: 'vault://secret/ez-trac/core-services/np/db/db-name',
    ssl: {rejectUnauthorized: false},
  },
  'ez-trac-urls': {
    'ez-trac-costing': 'https://ez-trac-costing-services.velocity-np.ag',
    'ez-trac-vip': 'https://ez-trac-vip-services.velocity-np.ag/ez-trac-vip/services',
  },
  'velocity-home': {
    value: 'velocity-np.ag',
  },
  'eztrac-approle': {
    role_name: '',
  },
};

export interface Config {
  'oauth-client': {
    id: string;
    secret: string;
  };
  coreDb: {
    user: string;
    password: string;
    host: string;
    port: number;
    database: string;
    ssl: {};
  };
  'ez-trac-urls': {
    'ez-trac-costing': string;
    'ez-trac-vip': string;
  };
  'velocity-home': {
    value: string;
  };
  'eztrac-approle': {
    role_name: string;
  };
}

module.exports = config;
