import _ from 'lodash';
const defaultConfig = require('./default');

module.exports = _.merge(defaultConfig, {});
