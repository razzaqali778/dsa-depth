import merge from 'lodash/merge';
import npConfig = require('./fargate-np');

module.exports = merge(npConfig, {
  'oauth-client': {
    id: 'vault://secret/ez-trac/core-services/prod/oauth-azure/client-id',
    secret: 'vault://secret/ez-trac/core-services/prod/oauth-azure/client-secret',
  },
  coreDb: {
    user: 'vault://secret/ez-trac/core-services/prod/db/app-user-name',
    password: 'vault://secret/ez-trac/core-services/prod/db/app-user-password',
    host: 'vault://secret/ez-trac/prod/db/host',
    database: 'vault://secret/ez-trac/core-services/prod/db/db-name',
  },
  'ez-trac-urls': {
    'ez-trac-costing': 'https://ez-trac-costing-services.velocity.ag',
    'ez-trac-vip': 'https://ez-trac-vip-services.velocity.ag/ez-trac-vip/services',
  },
  'velocity-home': {
    value: 'velocity.ag',
  },
  'eztrac-approle': {
    role_name: 'workforce-dev-admins-eztrac-prod',
  },
});
