import _ from 'lodash';
const defaultConfig = require('./default');

module.exports = _.merge(defaultConfig, {
  coreDb: {
    user: 'vault://secret/ez-trac/core-services/np/db/admin-user-name',
    password: 'vault://secret/ez-trac/np/db/admin-user-password',
    host: process.env.PGHOST || process.env.host || 'localhost',
    port: process.env.PGPORT || process.env.port || '5435',
    // Local Postgres copy (CoreDb_local) — set EZTRAC_LOCAL_DB=1; NP RDS untouched
    ...(process.env.EZTRAC_LOCAL_DB === '1'
      ? {
          user: process.env.PGUSER || 'eztrac',
          password: process.env.PGPASSWORD || 'eztrac_local',
          database: process.env.PGDATABASE || 'CoreDb_local',
          ssl: false,
        }
      : {}),
  },
});
