import merge from 'lodash/merge';
import defaultConfig = require('./default');

module.exports = merge(defaultConfig, {
  'eztrac-approle': {
    role_name: 'workforce-dev-admins-eztrac-np',
  },
});
