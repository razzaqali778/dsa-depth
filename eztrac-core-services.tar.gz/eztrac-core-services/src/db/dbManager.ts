import pgPromise from 'pg-promise';
import monitor from 'pg-monitor';
import config from '../config/index';

const MAX_REQUEST_DURATION = 10 * 60 * 1000;

const connectionConfig = () => {
  const credentials = config.get('coreDb');
  return {
    host: credentials.host,
    port: credentials.port,
    database: credentials.database,
    user: credentials.user,
    password: credentials.password,
    max: 200, // up to 800
    connectionTimeoutMillis: 50000,
    idleTimeoutMillis: MAX_REQUEST_DURATION,
    ssl: credentials.ssl,
  };
};

const initializationOptions = {
  capSQL: true,
};

const pgp = pgPromise(initializationOptions);

pgp.pg.types.setTypeParser(pgp.pg.types.builtins.INT8, BigInt);

export const db = () => pgp(connectionConfig());

if (process.env.NODE_ENV === 'development') monitor.attach(initializationOptions);
