import pgPromise from 'pg-promise';
import {Allocation} from 'src/api/effort/allocation/models';
import {Engagement} from 'src/api/effort/engagement/models';
import {EffortCostBreakdown, EffortId} from 'src/api/effort/models';
import {GenericParticipant, Participant} from 'src/api/person/models';

const pgp = pgPromise({capSQL: true});

export const allocationColumns = new pgp.helpers.ColumnSet(
  ['team_cost_id', 'team_cost_pct', 'vip_initiative_id'],
  {
    table: 'team_cost_allocation',
  }
);

export const membersColumns = new pgp.helpers.ColumnSet(
  ['team_cost_id', 'user_id', 'participation_pct'],
  {
    table: 'team_cost_member',
  }
);

export const forecastPeopleColumns = new pgp.helpers.ColumnSet(
  ['team_cost_id', 'people_number', 'external_rate_id', 'cost_group_id'],
  {
    table: 'forecast_person',
  }
);

export const engagementColumns = new pgp.helpers.ColumnSet(
  ['team_cost_id', 'engagement_id', 'amount', 'amount_details', 'comment'],
  {
    table: 'team_cost_engagement',
  }
);

export const breakdownColumns = new pgp.helpers.ColumnSet(
  ['team_cost_id', 'cost_group_id', 'cost', 'engagement_id', 'person_id'],
  {
    table: 'team_cost_breakdown',
  }
);

const mapToAllocationTableValues = (allocations: Allocation[], effortId: EffortId) =>
  allocations.map(allocation => ({
    team_cost_id: effortId,
    team_cost_pct: allocation.percentageOfTeamCost,
    vip_initiative_id: allocation.initiativeId,
  }));

const mapToMemberTableValues = (members: Participant[], effortId: EffortId) =>
  members.map(member => ({
    team_cost_id: effortId,
    user_id: member.userId,
    participation_pct: member.percent,
  }));

const mapToForecastPersonTableValues = (forecastPeople: GenericParticipant[], effortId: EffortId) =>
  forecastPeople.map(person => ({
    team_cost_id: effortId,
    people_number: person.numberOfPeople,
    external_rate_id: person.rateId,
    cost_group_id: person.costGroupId,
  }));

const mapToEngagementTableValues = (engagements: Engagement[], effortId: EffortId) =>
  engagements.map(engagement => ({
    team_cost_id: effortId,
    engagement_id: engagement.engagementId,
    amount: engagement.amount,
    amount_details: engagement.amountDetails,
    comment: engagement.comment,
  }));

const mapToBreakdownTableValues = (breakdowns: EffortCostBreakdown[]) =>
  breakdowns.map(breakdown => ({
    team_cost_id: breakdown.effortId,
    cost: breakdown.cost,
    cost_group_id: breakdown.costGroupId,
    engagement_id: breakdown.engagementId,
    person_id: breakdown.personId,
  }));

export const getAllocationInsertQueries = (allocations: Allocation[], effortId: EffortId) =>
  pgp.helpers.insert(mapToAllocationTableValues(allocations, effortId), allocationColumns);

export const getMemberInsertQueries = (members: Participant[], effortId: EffortId) =>
  pgp.helpers.insert(mapToMemberTableValues(members, effortId), membersColumns);

export const getForecastMemberInsertQueries = (
  forecastPeople: GenericParticipant[],
  effortId: EffortId
) =>
  pgp.helpers.insert(
    mapToForecastPersonTableValues(forecastPeople, effortId),
    forecastPeopleColumns
  );

export const getEngagementInsertQueries = (engagements: Engagement[], effortId: EffortId) =>
  pgp.helpers.insert(mapToEngagementTableValues(engagements, effortId), engagementColumns);

export const getBreakdownInsertQueries = (breakdowns: EffortCostBreakdown[]) =>
  pgp.helpers.insert(mapToBreakdownTableValues(breakdowns), breakdownColumns);
