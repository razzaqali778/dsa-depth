import _ from 'lodash';

function addSingleDash(name: string) {
  const dash = '-';
  if (_.endsWith(name, dash)) {
    return name;
  }
  return name.concat(dash);
}

export function NameToId(name: string): string {
  const toReplaceWithDash = "_:;+.,(){}[]<>|'`/\\ ".split('');
  const toRemove = '~!@#$%^&*?='.split('');
  const id = _.chain(name)
    .split('')
    .reduce((result, current) => {
      if (toReplaceWithDash.includes(current)) {
        return addSingleDash(result);
      } else if (toRemove.includes(current)) {
        return result;
      }
      return result.concat(current);
    }, '')
    .trim('-')
    .toUpper()
    .value();
  return id;
}
