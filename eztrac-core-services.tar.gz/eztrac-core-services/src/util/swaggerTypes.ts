import {Swagger20Operation} from 'swagger-tools';

export type PathName = string;
export type HttpMethodName = string;
export type SwaggerDoc = Record<PathName, Record<HttpMethodName, Swagger20Operation>>;
