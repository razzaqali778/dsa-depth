export const convertToBigint = (value: number | string) => BigInt(value);
