import {httpGetToken} from '@monsantoit/oauth-azure';
import config from '../config';

const getToken = () =>
  httpGetToken({
    clientId: config.get('oauth-client.id'),
    clientSecret: config.get('oauth-client.secret'),
  })();

export default getToken;
