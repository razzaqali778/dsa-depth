import {Response} from 'superagent';
import config from '../../config/index';
import authRequest from '../superagentWrapper';

const url = () => `https://profile.${config.get('velocity-home.value')}/v3/graphql`;

interface GraphQLPayload {
  query: string;
  variables: object | undefined;
}

export interface User {
  id: string;
  name: string;
  manager: {
    name: string;
  };
}

interface UserGraphQLModel {
  id: string;
  preferredName: {
    full: string;
  };
  manager: UserGraphQLModel;
}

export type Entitlement = {
  application: {
    id: string;
  };
  code: string;
};

const callGraphQl = (payload: GraphQLPayload): Promise<Response> => {
  return authRequest('POST', url(), payload);
};

export const papiClient = {
  async getUsersById(userIds: string[]): Promise<User[]> {
    const query = `query($userIds: [String!]!) {
          users: getUsersById(ids: $userIds) {
              id
              preferredName { full }
              manager { id preferredName { full }}
            }
        }`;
    const {body} = await callGraphQl({query, variables: {userIds}});
    return body.data.users
      .filter((u: UserGraphQLModel | null) => u !== null)
      .map((u: UserGraphQLModel) => ({
        id: u.id,
        name: u.preferredName.full,
        manager: {name: u.manager?.preferredName.full || 'no manager on file'},
      }));
  },

  async getEntitlementsForUser(userId: string, appIds: string[]): Promise<Entitlement[]> {
    const query = `query($userId:String!, $appIds:[String!]!){
            entitlements: getEntitlementsForUser(userId: $userId,appIds:$appIds){
              code
              application{
                id
              }
            }
          }
        `;
    const {body} = await callGraphQl({
      query,
      variables: {userId, appIds},
    });
    return body.data.entitlements;
  },
};
