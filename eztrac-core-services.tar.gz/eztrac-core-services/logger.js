import { env } from '@monsantoit/config'
const winston = require('winston')

const namespaceFormat = winston.format((info) => ({
    ...info,
    app: 'eztrac-core-services',
    space: 'ez-trac'
}))

const minimumLogLevel = env.inProduction || env.inDevelopment ? 'debug' : 'error'
const consoleTransport = new winston.transports.Console({
    level: minimumLogLevel,
    stderrLevels: ['error']
})

module.exports = winston.createLogger({
    transports: [consoleTransport],
    format: winston.format.combine(namespaceFormat(), winston.format.json())
})
