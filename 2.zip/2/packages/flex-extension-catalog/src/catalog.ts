export type ExtensionHost = 'web' | 'chrome' | 'vscode' | 'sidepanel';

export type ExtensionActionKind = 'consume' | 'produce' | 'navigate' | 'connect' | 'open-web';

export type ExtensionActionCategory =
  | 'overview'
  | 'governance'
  | 'cost'
  | 'partner'
  | 'navigation'
  | 'tools';

export interface ExtensionAction {
  id: string;
  label: string;
  description: string;
  kind: ExtensionActionKind;
  category: ExtensionActionCategory;
  hosts: ExtensionHost[];
  pluginId?: string;
  dataset?: string;
  /** Static produce payload (demo) */
  records?: unknown[];
  /** Side panel / browser route */
  route?: string;
  /** VS Code command id suffix (flex.<id>) */
  commandId?: string;
}

/** Single catalog — same plugin contracts across Chrome, VS Code, and web */
export const EXTENSION_ACTIONS: ExtensionAction[] = [
  {
    id: 'connect',
    label: 'Connect to Flex API',
    description: 'Verify flex-api is running (npm run api)',
    kind: 'connect',
    category: 'tools',
    hosts: ['vscode', 'chrome'],
    commandId: 'connect',
  },
  {
    id: 'open-web',
    label: 'Open Flex web app',
    description: 'Open the full Flex UI in the browser',
    kind: 'open-web',
    category: 'navigation',
    hosts: ['vscode', 'chrome'],
    commandId: 'openApp',
  },
  {
    id: 'get-kpis',
    label: 'Get dashboard KPIs',
    description: 'Spend, utilization, anomalies',
    kind: 'consume',
    category: 'overview',
    hosts: ['vscode', 'chrome', 'web'],
    pluginId: 'flex.dashboard',
    dataset: 'kpi_snapshot',
    commandId: 'getKpis',
  },
  {
    id: 'get-pending',
    label: 'Get pending approvals',
    description: 'Inbound requests in Governance',
    kind: 'consume',
    category: 'governance',
    hosts: ['vscode', 'chrome', 'web'],
    pluginId: 'flex.governance',
    dataset: 'data_requests',
    commandId: 'getPendingApprovals',
    route: '/govern/exchange',
  },
  {
    id: 'get-published',
    label: 'Get published datasets',
    description: 'Outbound datasets Flex published to partners',
    kind: 'consume',
    category: 'governance',
    hosts: ['vscode', 'chrome', 'web'],
    pluginId: 'flex.governance',
    dataset: 'published_datasets',
    commandId: 'getPublished',
  },
  {
    id: 'get-chargeback',
    label: 'Get team chargeback',
    description: 'Showback by team',
    kind: 'consume',
    category: 'cost',
    hosts: ['vscode', 'chrome', 'web'],
    pluginId: 'flex.chargeback',
    dataset: 'team_showback',
    commandId: 'getChargeback',
    route: '/chargeback',
  },
  {
    id: 'get-anomalies',
    label: 'Get open anomalies',
    description: 'Cost incidents for alerting',
    kind: 'consume',
    category: 'cost',
    hosts: ['vscode', 'chrome', 'web'],
    pluginId: 'flex.anomalies',
    dataset: 'anomaly_events',
    commandId: 'getAnomalies',
    route: '/anomalies',
  },
  {
    id: 'get-cloud-usage',
    label: 'Get cloud usage trend',
    description: 'Monthly usage by category',
    kind: 'consume',
    category: 'cost',
    hosts: ['vscode', 'chrome', 'web'],
    pluginId: 'flex.cloud-usage',
    dataset: 'usage_history',
    commandId: 'getCloudUsage',
    route: '/cloud',
  },
  {
    id: 'send-inbound',
    label: 'Send inbound data request',
    description: 'Partner → Flex governance queue',
    kind: 'produce',
    category: 'governance',
    hosts: ['vscode', 'chrome', 'web'],
    pluginId: 'flex.governance',
    dataset: 'inbound_request',
    records: [
      {
        fromApp: 'eztrac',
        dataset: 'forecast_variance',
        recordCount: 800,
        purpose: 'Inbound from extension host',
      },
    ],
    commandId: 'sendInboundRequest',
    route: '/govern/exchange',
  },
  {
    id: 'send-eztrac-sync',
    label: 'Simulate EzTrac sync',
    description: 'Creates pending approval in Flex',
    kind: 'produce',
    category: 'partner',
    hosts: ['vscode', 'chrome', 'web'],
    pluginId: 'flex.integrations',
    dataset: 'simulate_inbound_sync',
    records: [{ partner: 'eztrac' }],
    commandId: 'sendEzTracSync',
    route: '/govern/partners',
  },
  {
    id: 'send-dhub-sync',
    label: 'Simulate dhub-rpt sync',
    description: 'Creates pending approval in Flex',
    kind: 'produce',
    category: 'partner',
    hosts: ['vscode', 'chrome', 'web'],
    pluginId: 'flex.integrations',
    dataset: 'simulate_inbound_sync',
    records: [{ partner: 'dhub-rpt' }],
    commandId: 'sendDhubSync',
    route: '/govern/partners',
  },
  {
    id: 'nav-dashboard',
    label: 'Open dashboard',
    description: 'Flex overview',
    kind: 'navigate',
    category: 'navigation',
    hosts: ['chrome', 'sidepanel'],
    route: '/',
  },
  {
    id: 'nav-governance',
    label: 'Open governance',
    description: 'Approvals & publish',
    kind: 'navigate',
    category: 'navigation',
    hosts: ['chrome', 'sidepanel'],
    route: '/govern/exchange',
  },
  {
    id: 'nav-chargeback',
    label: 'Open chargeback',
    description: 'Team showback',
    kind: 'navigate',
    category: 'navigation',
    hosts: ['chrome', 'sidepanel'],
    route: '/chargeback',
  },
  {
    id: 'nav-workforce',
    label: 'Open workforce',
    description: 'Squad × infra matrix',
    kind: 'navigate',
    category: 'navigation',
    hosts: ['chrome', 'sidepanel'],
    route: '/workforce',
  },
  {
    id: 'nav-anomalies',
    label: 'Open anomalies',
    description: 'Cost incidents',
    kind: 'navigate',
    category: 'navigation',
    hosts: ['chrome', 'sidepanel'],
    route: '/anomalies',
  },
  {
    id: 'nav-assistant',
    label: 'Open Flex AI',
    description: 'Copilot across apps',
    kind: 'navigate',
    category: 'navigation',
    hosts: ['chrome', 'sidepanel'],
    route: '/assistant',
  },
  {
    id: 'nav-plugins',
    label: 'Open plugins',
    description: 'Extensions & APIs',
    kind: 'navigate',
    category: 'tools',
    hosts: ['chrome', 'sidepanel'],
    route: '/plugins',
  },
];

export function getActionsForHost(host: ExtensionHost): ExtensionAction[] {
  return EXTENSION_ACTIONS.filter((a) => a.hosts.includes(host));
}

export function getActionById(id: string): ExtensionAction | undefined {
  return EXTENSION_ACTIONS.find((a) => a.id === id);
}

export const DEFAULT_API_URL = 'http://localhost:3847';
export const DEFAULT_WEB_URL = 'http://localhost:5173';
